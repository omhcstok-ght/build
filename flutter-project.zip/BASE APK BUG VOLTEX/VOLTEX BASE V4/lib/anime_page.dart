import 'package:flutter/material.dart';

class HomeAnimePage extends StatelessWidget {
  const HomeAnimePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF06090F),
      appBar: AppBar(
        title: const Text('Anime List', style: TextStyle(color: Colors.white)),
        backgroundColor: const Color(0xFF0B1018),
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: const Center(
        child: Text(
          'Halaman Anime (Coming Soon)',
          style: TextStyle(color: Colors.white54, fontSize: 16),
        ),
      ),
    );
  }
}