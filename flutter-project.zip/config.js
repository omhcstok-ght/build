module.exports = {
    OWNER_ID: [8631765025],
    ADMIN_IDS: [8631765025],
    TOKEN: "9241483671:AAHWBKKHjH4zYDTK5BxuPzEHgklF-vi5Y9k",
    PORT: 3054,
    wsPort: 3054,
   
     bugs: [
      { bug_id: "trash", bug_name: "CRASH HOME" },
      { bug_id: "bugss", bug_name: "CRASH CLICK" },
      { bug_id: "clbug", bug_name: "CHAT LOCK" },
      { bug_id: "fbug", bug_name: "FREEZE CHAT" },
      { bug_id: "dslow", bug_name: "DELAY SLOW" },
      { bug_id: "oom", bug_name: "DELAY OOM"},
      { bug_id: "cios", bug_name: "CRASH IOS"},
    ],
    
   bugsgb: [
    { gb_id: "freezegb", gb_name: "FREEZE GB" },
    { gb_id: "trashgb",  gb_name: "CRASH GB" },
    { gb_id: "zazaza",   gb_name: "BANNED GB" },
   ],
   
    tqto: [
        {
            name: "ryszox",
            status: "Pemilik",
            ppUrl: "https://files.catbox.moe/8j06g1.jpg",
            contac: "t.me/ryszox"
        },
        {
            name: "zasta",
            status: "akun ke 2",
            ppUrl: "https://files.catbox.moe/8z6q1v.jpg",
            contac: "t.me/ryszox_zasta"
        }
    ],

    news: [
        {
          "image": "https://files.catbox.moe/93m7wj.jpg",
          "title": "NTED CRASHER", 
          "desc": "New Update: Fitur terbaru dari NTED Crasher telah dirilis!",
          "date": "2026-07-26"
        },
        {
          "image": "https://files.catbox.moe/j4g1xx.jpg",
          "title": "Protect By Nted",
          "desc": "Sistem keamanan terbaru dari Nted untuk melindungi data Anda.",
          "date": "2026-07-25"
        }
     ],
     
     XENTRALPAY: {
       API_KEY: "cpay_live_VdfPUOOA6gxbv0AuWUWLQ7UwsC3gEJ0l",
       BASE_URL: "https://api.xentralpay.com/v1",
       CALLBACK_URL: "",
     },
     
    PRICE: {
       PER_DAY: 10000,
       WEEKLY: 50000,
       MONTHLY: 150000,
       RESELLER_PRICE: 5000,
       ADMIN_PRICE: 1000
     },
     
    GOPAY: {
     NUMBER: "085136651376",
     ENABLED: true
    },
    
    OWNER_GROUP_ID: -1004491295306 
};