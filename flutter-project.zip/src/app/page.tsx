'use client'

import { useEffect, useRef } from 'react'
import { useApp } from '@/lib/store'
import { api, saveUserToken } from '@/lib/api'
import { SplashView } from '@/components/views/SplashView'
import { WelcomeView } from '@/components/views/WelcomeView'
import { LoginView, RegisterView, ForgotView } from '@/components/views/AuthViews'
import { AppShell } from '@/components/AppShell'
import { DashboardView } from '@/components/views/DashboardView'
import { QuizView } from '@/components/views/QuizView'
import { QuizPlayView } from '@/components/views/QuizPlayView'
import { QuizResultView } from '@/components/views/QuizResultView'
import { WatchEarnView } from '@/components/views/WatchEarnView'
import { RewardsView } from '@/components/views/RewardsView'
import { LeaderboardView } from '@/components/views/LeaderboardView'
import { MissionsView } from '@/components/views/MissionsView'
import { ProfileView } from '@/components/views/ProfileView'
import { HistoryView } from '@/components/views/HistoryView'
import { NotificationsView } from '@/components/views/NotificationsView'
import { InfoView } from '@/components/views/InfoView'
import { AdminView } from '@/components/views/AdminView'

const APP_VIEWS = new Set([
  'dashboard', 'quiz', 'quiz-play', 'quiz-result', 'watch', 'missions',
  'rewards', 'leaderboard', 'history', 'profile', 'notifications', 'info',
])

function AppRouter() {
  const { view, go, setAuthNotice } = useApp()

  // Tangkap query param hasil redirect OAuth (?login=google / ?authError=...)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const authError = params.get('authError')
    const login = params.get('login')
    if (authError) {
      setAuthNotice(authError)
      go('login')
      window.history.replaceState({}, '', '/')
    } else if (login === 'google') {
      go('dashboard')
      window.history.replaceState({}, '', '/')
    }
  }, [go, setAuthNotice])

  switch (view) {
    case 'splash':
      return <SplashView />
    case 'welcome':
      return <WelcomeView />
    case 'login':
      return <LoginView />
    case 'register':
      return <RegisterView />
    case 'forgot':
      return <ForgotView />
    case 'admin':
      return <AdminView />
    default: {
      if (!APP_VIEWS.has(view)) return <WelcomeView />
      return (
        <AppShell>
          {view === 'dashboard' && <DashboardView />}
          {view === 'quiz' && <QuizView />}
          {view === 'quiz-play' && <QuizPlayView />}
          {view === 'quiz-result' && <QuizResultView />}
          {view === 'watch' && <WatchEarnView />}
          {view === 'missions' && <MissionsView />}
          {view === 'rewards' && <RewardsView />}
          {view === 'leaderboard' && <LeaderboardView />}
          {view === 'history' && <HistoryView />}
          {view === 'profile' && <ProfileView />}
          {view === 'notifications' && <NotificationsView />}
          {view === 'info' && <InfoView />}
        </AppShell>
      )
    }
  }
}

export default function Home() {
  const { booted, setBooted, setUser, go } = useApp()
  const bootedRef = useRef(false)

  useEffect(() => {
    if (bootedRef.current) return
    bootedRef.current = true

    const t0 = Date.now()
    api<{ token?: string; user: unknown }>('/api/auth/me')
      .then((d) => {
        saveUserToken(d.token) // perbarui token sesi agar tetap segar
        const wait = Math.max(0, 1400 - (Date.now() - t0))
        setTimeout(() => {
          if (d.user) {
            setUser(d.user as never)
            go('dashboard')
          } else {
            go('welcome')
          }
          setBooted(true)
        }, wait)
      })
      .catch(() => {
        go('welcome')
        setBooted(true)
      })
  }, [setBooted, setUser, go])

  if (!booted && useApp.getState().view === 'splash') return <SplashView />
  return <AppRouter />
}
