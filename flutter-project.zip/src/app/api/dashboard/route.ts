import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'
import { ok, fail, todayKey } from '@/lib/api-utils'
import { getWalletRules, getQuizRules } from '@/lib/settings'

export async function GET(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)

  const user = await db.user.findUnique({ where: { id: session.sub }, include: { wallet: true } })
  if (!user) return fail('Pengguna tidak ditemukan.', 404)

  const [rules, walletRules, quizRules] = await Promise.all([
    getWalletRules(),
    getWalletRules(),
    getQuizRules(),
  ])

  const today = todayKey()
  const [activities, missions, announcements, promos, unreadCount, bonusReady] = await Promise.all([
    // Aktivitas terakhir (poin + pencairan)
    db.pointTransaction.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 6,
    }),
    db.missionProgress.findMany({ where: { userId: user.id, date: today } }),
    db.notification.findMany({
      where: { OR: [{ userId: user.id }, { userId: null }] },
      orderBy: { createdAt: 'desc' },
      take: 4,
    }),
    db.sponsorCampaign.findMany({
      where: { status: { in: ['ACTIVE', 'FUNDED'] } },
      include: { sponsor: true },
      take: 3,
    }),
    db.notification.count({
      where: {
        OR: [{ userId: user.id }, { userId: null }],
        ...(user.lastReadNotifications ? { createdAt: { gt: user.lastReadNotifications } } : {}),
      },
    }),
    // Lucky bonus tersedia bila belum klaim hari ini
    !user.lastBonusAt || user.lastBonusAt < new Date(new Date().setHours(0, 0, 0, 0)),
  ])

  return ok({
    user: {
      name: user.name,
      username: user.username,
      avatar: user.avatar,
      emailVerified: user.emailVerified,
      bonusStreak: user.bonusStreak,
    },
    points: {
      pending: user.pointsPending,
      available: user.pointsAvailable,
      estimate: user.pointsAvailable * rules.conversionRate,
    },
    wallet: {
      available: user.wallet?.available ?? 0,
      processing: user.wallet?.processing ?? 0,
      totalPaid: user.wallet?.totalPaid ?? 0,
    },
    rules: {
      conversionRate: rules.conversionRate,
      quizTimeSeconds: quizRules.timeSeconds,
      pointsEasy: quizRules.pointsEasy,
      luckyBonusPoints: walletRules.luckyBonusPoints,
    },
    activities: activities.map((a) => ({
      id: a.id,
      type: a.type,
      amount: a.amount,
      bucket: a.bucket,
      meta: a.meta ? JSON.parse(a.meta) : null,
      createdAt: a.createdAt,
    })),
    missions: missions.map((m) => ({ code: m.code, progress: m.progress, claimed: m.claimed })),
    announcements,
    promos: promos.map((p) => ({
      id: p.id,
      title: p.title,
      sponsor: p.sponsor.name,
      status: p.status,
    })),
    unreadCount,
    bonusReady,
  })
}
