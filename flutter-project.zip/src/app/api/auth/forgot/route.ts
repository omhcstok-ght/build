import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, readJson, str, isEmail } from '@/lib/api-utils'
import { rateLimit } from '@/lib/rate-limit'
import { clientIp } from '@/lib/auth'

/**
 * Lupa password. Layanan email belum terhubung, sehingga permintaan
 * diteruskan ke antrean admin (SupportMessage kategori RESET_PASSWORD)
 * dan admin dapat mereset password melalui Admin Panel. Pendekatan jujur,
 * tanpa simulasi pengiriman email palsu.
 */
export async function POST(req: NextRequest) {
  const ip = clientIp(req)
  if (!rateLimit(`forgot:${ip}`, 3, 60_000)) return fail('Terlalu banyak permintaan. Coba lagi nanti.', 429)

  const body = await readJson(req)
  const email = str(body.email, 120).toLowerCase()
  if (!isEmail(email)) return fail('Masukkan email yang valid.')

  const user = await db.user.findUnique({ where: { email } })
  // Selalu sukses agar tidak membocorkan keberadaan akun
  if (user) {
    const open = await db.supportMessage.findFirst({
      where: { userId: user.id, category: 'RESET_PASSWORD', status: 'OPEN' },
    })
    if (!open) {
      await db.supportMessage.create({
        data: {
          userId: user.id,
          name: user.name,
          email,
          category: 'RESET_PASSWORD',
          subject: 'Permintaan reset password',
          message: `Pengguna ${user.username} (${email}) meminta reset password. Verifikasi identitas lalu gunakan aksi "Reset Password" pada menu Manajemen Pengguna.`,
        },
      })
    }
  }
  return ok({
    success: true,
    message: 'Permintaan diterima. Layanan email otomatis belum terhubung, tim admin akan memverifikasi dan mereset password-mu. Pantau email balasan atau hubungi pusat laporan.',
  })
}
