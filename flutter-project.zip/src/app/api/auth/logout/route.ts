import { NextResponse } from 'next/server'
import { clearAuthCookies } from '@/lib/auth'
import { ok } from '@/lib/api-utils'

export async function POST() {
  const res = ok({ success: true })
  clearAuthCookies(res as NextResponse)
  return res
}
