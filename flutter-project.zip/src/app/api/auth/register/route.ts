import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { hashPassword, signToken, setUserCookie, clientIp } from '@/lib/auth'
import { ok, fail, readJson, isEmail, isUsername, str, todayKey } from '@/lib/api-utils'
import { rateLimit } from '@/lib/rate-limit'
import { NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  const ip = clientIp(req)
  if (!rateLimit(`register:${ip}`, 5, 60_000)) {
    return fail('Terlalu banyak percobaan. Coba lagi dalam semenit.', 429)
  }

  const body = await readJson(req)
  const name = str(body.name, 60)
  const username = str(body.username, 20).toLowerCase()
  const email = str(body.email, 120).toLowerCase()
  const password = typeof body.password === 'string' ? body.password : ''
  const confirmPassword = typeof body.confirmPassword === 'string' ? body.confirmPassword : ''

  if (!name || name.length < 3) return fail('Nama lengkap minimal 3 karakter.')
  if (!isUsername(username)) return fail('Username 3-20 karakter, hanya huruf, angka, dan underscore.')
  if (!isEmail(email)) return fail('Format email tidak valid.')
  if (password.length < 8) return fail('Password minimal 8 karakter.')
  if (password !== confirmPassword) return fail('Konfirmasi password tidak sama.')

  const [emailTaken, usernameTaken] = await Promise.all([
    db.user.findUnique({ where: { email } }),
    db.user.findUnique({ where: { username } }),
  ])
  if (emailTaken) return fail('Email sudah terdaftar.')
  if (usernameTaken) return fail('Username sudah dipakai.')

  // Deteksi multi akun sederhana berdasarkan IP
  const sameIpCount = await db.user.count({ where: { regIp: ip } })

  const passwordHash = await hashPassword(password)
  const user = await db.$transaction(async (tx) => {
    const u = await tx.user.create({
      data: {
        name,
        username,
        email,
        passwordHash,
        regIp: ip,
        lastLoginAt: new Date(),
        lastLoginIp: ip,
      },
    })
    await tx.wallet.create({ data: { userId: u.id } })
    await tx.notification.create({
      data: {
        userId: u.id,
        title: 'Selamat datang, ' + name + '!',
        body: 'Perjalananmu dimulai. Mainkan kuis, kumpulkan poin, dan tukarkan menjadi hadiah. PLAY. ANSWER. EARN. REPEAT.',
        kind: 'SUCCESS',
      },
    })
    await tx.missionProgress.create({
      data: { userId: u.id, code: 'LOGIN', date: todayKey(), progress: 1 },
    })
    return u
  })

  if (sameIpCount >= 3) {
    await db.fraudEvent.create({
      data: { userId: user.id, type: 'MULTI_ACCOUNT', severity: 'MEDIUM', detail: `Registrasi akun ke-${sameIpCount + 1} dari IP ${ip}` },
    })
  }

  const token = await signToken({ sub: user.id, role: 'user', name: user.name, username: user.username })
  const res = ok({
    token,
    user: { id: user.id, name: user.name, username: user.username, email: user.email, avatar: user.avatar },
  })
  setUserCookie(res as NextResponse, token)
  return res
}
