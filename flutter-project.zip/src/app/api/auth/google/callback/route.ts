import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { signToken, setUserCookie, clientIp } from '@/lib/auth'
import { todayKey } from '@/lib/api-utils'

/**
 * Callback Google OAuth: tukar code dengan access token, ambil profil,
 * temukan/buat user, lalu set session cookie. Redirect ke halaman utama.
 */
export async function GET(req: NextRequest) {
  const clientId = process.env.GOOGLE_CLIENT_ID
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET
  const origin = process.env.GOOGLE_REDIRECT_URI
    ? new URL(process.env.GOOGLE_REDIRECT_URI).origin
    : req.nextUrl.origin
  const redirectUri = process.env.GOOGLE_REDIRECT_URI || `${origin}/api/auth/google/callback`

  const failRedirect = (msg: string) =>
    NextResponse.redirect(`${origin}/?authError=${encodeURIComponent(msg)}`)

  if (!clientId || !clientSecret) return failRedirect('Google OAuth belum dikonfigurasi')

  const code = req.nextUrl.searchParams.get('code')
  const state = req.nextUrl.searchParams.get('state')
  const savedState = req.cookies.get('qe_oauth_state')?.value
  if (!code || !state || state !== savedState) return failRedirect('State OAuth tidak valid')

  try {
    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: clientId,
        client_secret: clientSecret,
        redirect_uri: redirectUri,
        grant_type: 'authorization_code',
      }),
    })
    if (!tokenRes.ok) return failRedirect('Penukaran token Google gagal')
    const tokenJson = (await tokenRes.json()) as { access_token?: string }
    if (!tokenJson.access_token) return failRedirect('Token Google tidak diterima')

    const infoRes = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
      headers: { Authorization: `Bearer ${tokenJson.access_token}` },
    })
    if (!infoRes.ok) return failRedirect('Gagal mengambil profil Google')
    const info = (await infoRes.json()) as { sub: string; email: string; name?: string; picture?: string }

    const email = info.email.toLowerCase()
    let user = await db.user.findUnique({ where: { googleId: info.sub } })
    if (!user) {
      const byEmail = await db.user.findUnique({ where: { email } })
      if (byEmail) {
        user = await db.user.update({ where: { id: byEmail.id }, data: { googleId: info.sub, emailVerified: true } })
      } else {
        const base = email.split('@')[0].replace(/[^a-zA-Z0-9_]/g, '').slice(0, 14) || 'pengguna'
        let username = base
        let n = 1
        while (await db.user.findUnique({ where: { username } })) {
          username = `${base}${n++}`.slice(0, 20)
        }
        user = await db.$transaction(async (tx) => {
          const u = await tx.user.create({
            data: {
              email,
              username,
              name: info.name || base,
              googleId: info.sub,
              avatar: null,
              emailVerified: true,
              regIp: clientIp(req),
              lastLoginAt: new Date(),
            },
          })
          await tx.wallet.create({ data: { userId: u.id } })
          await tx.missionProgress.create({
            data: { userId: u.id, code: 'LOGIN', date: todayKey(), progress: 1 },
          })
          return u
        })
      }
    }
    if (user.isBlocked) return failRedirect('Akun diblokir')

    const token = await signToken({ sub: user.id, role: 'user', name: user.name, username: user.username })
    const res = NextResponse.redirect(origin + '/?login=google')
    setUserCookie(res as NextResponse, token)
    res.cookies.set('qe_oauth_state', '', { maxAge: 0, path: '/' })
    return res
  } catch {
    return failRedirect('Terjadi kesalahan saat login dengan Google')
  }
}
