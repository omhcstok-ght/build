import { NextRequest, NextResponse } from 'next/server'
import { randomBytes } from 'crypto'

/**
 * Google OAuth 2.0 Authorization Code Flow.
 * Mengembalikan redirect NYATA ke Google jika kredensial tersedia di environment.
 * Jika belum dikonfigurasi, kembalikan status 501 agar UI menampilkan status "belum terhubung".
 * Konfigurasi: GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, (opsional) GOOGLE_REDIRECT_URI
 */
export async function GET(req: NextRequest) {
  const clientId = process.env.GOOGLE_CLIENT_ID
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET

  if (!clientId || !clientSecret) {
    return NextResponse.json(
      {
        error: 'Google OAuth belum terhubung. Tambahkan GOOGLE_CLIENT_ID dan GOOGLE_CLIENT_SECRET pada environment, lalu restart server.',
        configured: false,
      },
      { status: 501 }
    )
  }

  const origin = process.env.GOOGLE_REDIRECT_URI
    ? new URL(process.env.GOOGLE_REDIRECT_URI).origin
    : req.nextUrl.origin
  const redirectUri = process.env.GOOGLE_REDIRECT_URI || `${origin}/api/auth/google/callback`

  const state = randomBytes(16).toString('hex')
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: 'openid email profile',
    state,
    prompt: 'select_account',
  })

  const res = NextResponse.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`)
  res.cookies.set('qe_oauth_state', state, {
    httpOnly: true,
    sameSite: 'lax',
    maxAge: 600,
    path: '/',
    secure: process.env.NODE_ENV === 'production',
  })
  return res
}
