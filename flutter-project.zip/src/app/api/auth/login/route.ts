import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { verifyPassword, signToken, setUserCookie, clientIp } from '@/lib/auth'
import { ok, fail, readJson, str, todayKey } from '@/lib/api-utils'
import { rateLimit } from '@/lib/rate-limit'

export async function POST(req: NextRequest) {
  const ip = clientIp(req)
  const body = await readJson(req)
  const identifier = str(body.identifier, 120).toLowerCase()
  const password = typeof body.password === 'string' ? body.password : ''

  if (!identifier || !password) return fail('Email/username dan password wajib diisi.')
  if (!rateLimit(`login:${ip}:${identifier}`, 8, 60_000)) {
    return fail('Terlalu banyak percobaan login. Tunggu semenit.', 429)
  }

  const user = await db.user.findFirst({
    where: { OR: [{ email: identifier }, { username: identifier }] },
  })
  if (!user || !user.passwordHash) return fail('Kombinasi akun dan password tidak cocok.', 401)
  if (user.isBlocked) {
    return fail('Akun diblokir. ' + (user.blockReason || 'Hubungi dukungan.'), 403)
  }

  const valid = await verifyPassword(password, user.passwordHash)
  if (!valid) return fail('Kombinasi akun dan password tidak cocok.', 401)

  await Promise.all([
    db.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date(), lastLoginIp: ip },
    }),
    db.missionProgress.upsert({
      where: { userId_code_date: { userId: user.id, code: 'LOGIN', date: todayKey() } },
      update: { progress: { increment: 0 } },
      create: { userId: user.id, code: 'LOGIN', date: todayKey(), progress: 1 },
    }),
  ])

  const token = await signToken({ sub: user.id, role: 'user', name: user.name, username: user.username })
  const res = ok({
    token,
    user: { id: user.id, name: user.name, username: user.username, email: user.email, avatar: user.avatar },
  })
  setUserCookie(res as NextResponse, token)
  return res
}
