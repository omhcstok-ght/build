import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser, signToken } from '@/lib/auth'
import { ok } from '@/lib/api-utils'

export async function GET(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return ok({ user: null })

  const user = await db.user.findUnique({
    where: { id: session.sub },
    include: { wallet: true },
  })
  if (!user || user.isBlocked) return ok({ user: null })

  // Terbitkan token segar agar sesi berbasis localStorage tetap diperbarui.
  const token = await signToken({ sub: user.id, role: 'user', name: user.name, username: user.username })

  return ok({
    token,
    user: {
      id: user.id,
      name: user.name,
      username: user.username,
      email: user.email,
      avatar: user.avatar,
      emailVerified: user.emailVerified,
      pointsPending: user.pointsPending,
      pointsAvailable: user.pointsAvailable,
      bonusStreak: user.bonusStreak,
      wallet: user.wallet
        ? { available: user.wallet.available, processing: user.wallet.processing, totalPaid: user.wallet.totalPaid }
        : { available: 0, processing: 0, totalPaid: 0 },
    },
  })
}
