import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser, hashPassword, verifyPassword } from '@/lib/auth'
import { ok, fail, readJson, str } from '@/lib/api-utils'

export async function GET(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)

  const user = await db.user.findUnique({
    where: { id: session.sub },
    include: { wallet: true },
  })
  if (!user) return fail('Pengguna tidak ditemukan.', 404)

  const [quizAgg, txCount, wdCount] = await Promise.all([
    db.quizSession.aggregate({
      where: { userId: user.id, status: 'COMPLETED' },
      _count: { _all: true },
      _sum: { pointsEarned: true },
    }),
    db.pointTransaction.count({ where: { userId: user.id } }),
    db.withdrawalRequest.count({ where: { userId: user.id } }),
  ])

  return ok({
    profile: {
      name: user.name,
      username: user.username,
      email: user.email,
      avatar: user.avatar,
      emailVerified: user.emailVerified,
      googleLinked: Boolean(user.googleId),
      hasPassword: Boolean(user.passwordHash),
      createdAt: user.createdAt,
      lastLoginAt: user.lastLoginAt,
    },
    stats: {
      quizCompleted: quizAgg._count._all ?? 0,
      pointsEarned: quizAgg._sum.pointsEarned ?? 0,
      transactions: txCount,
      withdrawals: wdCount,
      pointsPending: user.pointsPending,
      pointsAvailable: user.pointsAvailable,
      walletAvailable: user.wallet?.available ?? 0,
      totalPaid: user.wallet?.totalPaid ?? 0,
    },
  })
}

/** Perbarui profil: nama & avatar. */
export async function PATCH(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)

  const body = await readJson(req)
  const name = str(body.name, 60)
  const avatar = str(body.avatar, 200)
  if (name && name.length < 3) return fail('Nama minimal 3 karakter.')

  const data: { name?: string; avatar?: string } = {}
  if (name) data.name = name
  if (avatar) data.avatar = avatar
  if (Object.keys(data).length === 0) return fail('Tidak ada perubahan.')

  await db.user.update({ where: { id: session.sub }, data })
  return ok({ success: true, message: 'Profil diperbarui.' })
}

/** Ganti password (butuh password saat ini). */
export async function POST(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)

  const body = await readJson(req)
  const currentPassword = typeof body.currentPassword === 'string' ? body.currentPassword : ''
  const newPassword = typeof body.newPassword === 'string' ? body.newPassword : ''
  const confirmPassword = typeof body.confirmPassword === 'string' ? body.confirmPassword : ''

  if (newPassword.length < 8) return fail('Password baru minimal 8 karakter.')
  if (newPassword !== confirmPassword) return fail('Konfirmasi password baru tidak sama.')

  const user = await db.user.findUnique({ where: { id: session.sub } })
  if (!user) return fail('Pengguna tidak ditemukan.', 404)

  if (user.passwordHash) {
    const valid = await verifyPassword(currentPassword, user.passwordHash)
    if (!valid) return fail('Password saat ini tidak cocok.')
  }

  await db.user.update({
    where: { id: session.sub },
    data: { passwordHash: await hashPassword(newPassword) },
  })
  return ok({ success: true, message: 'Password berhasil diperbarui.' })
}
