import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'
import { ok, fail, readJson, str, todayKey } from '@/lib/api-utils'
import { getMissionDefs } from '@/lib/settings'
import { creditPoints } from '@/lib/points'
import { rateLimit } from '@/lib/rate-limit'

/** Klaim hadiah misi harian yang progressnya sudah tercapai. */
export async function POST(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)
  if (!rateLimit(`mission-claim:${session.sub}`, 10, 60_000)) return fail('Terlalu sering.', 429)

  const body = await readJson(req)
  const code = str(body.code, 20)
  const date = todayKey()

  const defs = await getMissionDefs()
  const def = defs.find((d) => d.code === code)
  if (!def) return fail('Misi tidak ditemukan.', 404)

  const progress = await db.missionProgress.findUnique({
    where: { userId_code_date: { userId: session.sub, code, date } },
  })
  if (!progress || progress.progress < def.target) {
    return fail('Misi belum tercapai.')
  }
  if (progress.claimed) return fail('Hadiah misi ini sudah diklaim.')

  await db.$transaction(async (tx) => {
    await tx.missionProgress.update({ where: { id: progress.id }, data: { claimed: true } })
    await creditPoints(tx, {
      userId: session.sub,
      type: 'EARN_MISSION',
      bucket: 'AVAILABLE',
      amount: def.reward,
      meta: { mission: code },
    })
  })

  return ok({ success: true, reward: def.reward, message: `Misi "${def.title}" selesai! +${def.reward} poin.` })
}
