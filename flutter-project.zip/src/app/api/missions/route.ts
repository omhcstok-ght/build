import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'
import { ok, fail, todayKey } from '@/lib/api-utils'
import { getMissionDefs } from '@/lib/settings'

export async function GET(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)

  const user = await db.user.findUnique({ where: { id: session.sub } })
  if (!user) return fail('Pengguna tidak ditemukan.', 404)

  const date = todayKey()
  const defs = await getMissionDefs()
  const progress = await db.missionProgress.findMany({ where: { userId: user.id, date } })

  // Pastikan misi login hari ini tercatat
  await db.missionProgress.upsert({
    where: { userId_code_date: { userId: user.id, code: 'LOGIN', date } },
    update: {},
    create: { userId: user.id, code: 'LOGIN', date, progress: 1 },
  }).catch(() => {})

  const refreshed = await db.missionProgress.findMany({ where: { userId: user.id, date } })

  const bonusReady =
    !user.lastBonusAt || user.lastBonusAt < new Date(new Date().setHours(0, 0, 0, 0))

  return ok({
    missions: defs.map((d) => {
      const p = refreshed.find((x) => x.code === d.code)
      return {
        ...d,
        progress: Math.min(p?.progress ?? 0, d.target),
        claimed: p?.claimed ?? false,
        complete: (p?.progress ?? 0) >= d.target,
      }
    }),
    bonus: {
      ready: bonusReady,
      streak: user.bonusStreak,
      points: 0, // diisi oleh klien dari settings via dashboard rules
    },
  })
}
