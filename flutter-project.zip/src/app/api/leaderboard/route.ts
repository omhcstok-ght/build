import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'
import { ok, startOfWeek } from '@/lib/api-utils'

export async function GET(req: NextRequest) {
  const session = await getSessionUser(req)
  const range = req.nextUrl.searchParams.get('range') === 'all' ? 'all' : 'week'
  const since = range === 'week' ? startOfWeek() : new Date(0)

  const grouped = await db.pointTransaction.groupBy({
    by: ['userId'],
    where: { type: { in: ['EARN_QUIZ', 'EARN_STREAK', 'EARN_COMPLETION', 'EARN_PERFECT', 'EARN_MISSION', 'EARN_BONUS', 'EARN_AD'] }, createdAt: { gte: since } },
    _sum: { amount: true },
    orderBy: { _sum: { amount: 'desc' } },
    take: 50,
  })

  const users = await db.user.findMany({
    where: { id: { in: grouped.map((g) => g.userId) } },
    select: { id: true, name: true, username: true, avatar: true },
  })

  const rows = grouped.map((g, i) => {
    const u = users.find((x) => x.id === g.userId)
    return {
      rank: i + 1,
      userId: g.userId,
      name: u?.name ?? 'Pengguna',
      username: u?.username ?? '-',
      avatar: u?.avatar ?? null,
      points: g._sum.amount ?? 0,
      isMe: session?.sub === g.userId,
    }
  })

  return ok({ range, rows })
}
