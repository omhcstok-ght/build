import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'
import { ok, fail, readJson, str, rupiah } from '@/lib/api-utils'
import { rateLimit } from '@/lib/rate-limit'
import { getWalletRules } from '@/lib/settings'
import { creditPoints } from '@/lib/points'

/** Status lucky bonus harian. */
export async function GET(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)
  const user = await db.user.findUnique({ where: { id: session.sub } })
  if (!user) return fail('Pengguna tidak ditemukan.', 404)

  const rules = await getWalletRules()
  const ready = !user.lastBonusAt || user.lastBonusAt < new Date(new Date().setHours(0, 0, 0, 0))
  return ok({
    ready,
    streak: user.bonusStreak,
    points: rules.luckyBonusPoints,
    note: 'Bonus harian memberi poin langsung tersedia. Aturan nominal dapat diubah admin.',
  })
}

/** Klaim lucky bonus harian (1x per hari, streak bertambah). */
export async function POST(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)
  if (!rateLimit(`bonus:${session.sub}`, 3, 60_000)) return fail('Terlalu sering.', 429)
  readJson(req).catch(() => {})

  const user = await db.user.findUnique({ where: { id: session.sub } })
  if (!user) return fail('Pengguna tidak ditemukan.', 404)

  const startOfDay = new Date(new Date().setHours(0, 0, 0, 0))
  if (user.lastBonusAt && user.lastBonusAt >= startOfDay) {
    return fail('Bonus harian sudah diklaim. Kembali lagi besok!')
  }

  const rules = await getWalletRules()
  // streak bertambah bila klaim kemarin, else reset ke 1
  const yesterday = new Date(startOfDay)
  yesterday.setDate(yesterday.getDate() - 1)
  const isConsecutive = user.lastBonusAt && user.lastBonusAt >= yesterday
  const streak = isConsecutive ? user.bonusStreak + 1 : 1

  await db.$transaction(async (tx) => {
    await creditPoints(tx, {
      userId: user.id,
      type: 'EARN_BONUS',
      bucket: 'AVAILABLE',
      amount: rules.luckyBonusPoints,
      meta: { streak },
    })
    await tx.user.update({
      where: { id: user.id },
      data: { lastBonusAt: new Date(), bonusStreak: streak },
    })
  })

  return ok({
    success: true,
    reward: rules.luckyBonusPoints,
    streak,
    message: `Lucky Bonus ${rupiah(rules.luckyBonusPoints * 1)} setara +${rules.luckyBonusPoints} poin diterima! Streak: ${streak} hari.`,
  })
}
