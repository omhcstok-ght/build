import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, audit, ok, fail, int } from '@/lib/admin-core'
import { addLedgerEntry, getRevenueSummary } from '@/lib/finance'

export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const [summary, capital, ledger] = await Promise.all([
    getRevenueSummary(),
    db.capitalContribution.findMany({ orderBy: { createdAt: 'desc' }, take: 50 }),
    db.financialLedger.findMany({ orderBy: { createdAt: 'desc' }, take: 100 }),
  ])

  return ok({
    summary,
    capital,
    ledger,
  })
}

/** Tambah modal awal/operasional. Masuk ke buku besar (CAPITAL_IN). */
export async function POST(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const json = (await req.json().catch(() => ({}))) as { amount?: number; source?: string; note?: string }
  const amount = int(json.amount, 0)
  if (amount <= 0) return fail('Jumlah modal harus lebih dari 0.')
  const source = ['PEMILIK', 'INVESTOR', 'LAINNYA'].includes(String(json.source)) ? String(json.source) : 'PEMILIK'

  const created = await db.$transaction(async (tx) => {
    const c = await tx.capitalContribution.create({
      data: { amount, source, note: json.note?.slice(0, 200) ?? null, createdBy: admin.username },
    })
    await addLedgerEntry(tx, {
      type: 'CAPITAL_IN',
      amount,
      refType: 'CAPITAL',
      refId: c.id,
      note: `Modal ${source}: ${json.note?.slice(0, 150) ?? '-'}`,
      createdBy: admin.username,
    })
    return c
  })

  await audit(admin, 'TAMBAH_MODAL', 'Capital', created.id, `Rp${amount.toLocaleString('id-ID')}`)
  return ok({ success: true, message: `Modal Rp${amount.toLocaleString('id-ID')} dicatat.` })
}
