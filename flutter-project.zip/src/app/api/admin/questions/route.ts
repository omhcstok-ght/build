import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, audit, ok, fail, str, int } from '@/lib/admin-core'

export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const url = req.nextUrl
  const categoryId = url.searchParams.get('categoryId') || ''
  const q = url.searchParams.get('q') || ''
  const page = Math.max(1, int(url.searchParams.get('page'), 1))
  const pageSize = 15

  const where: { categoryId?: string; text?: { contains: string } } = {}
  if (categoryId) where.categoryId = categoryId
  if (q) where.text = { contains: q }

  const [total, questions, categories] = await Promise.all([
    db.question.count({ where }),
    db.question.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: { category: true },
    }),
    db.quizCategory.findMany({ orderBy: { sortOrder: 'asc' } }),
  ])

  return ok({
    page,
    pageSize,
    total,
    categories: categories.map((c) => ({ id: c.id, name: c.name, isActive: c.isActive })),
    questions: questions.map((q) => ({
      id: q.id,
      categoryId: q.categoryId,
      categoryName: q.category.name,
      difficulty: q.difficulty,
      text: q.text,
      imageUrl: q.imageUrl,
      options: JSON.parse(q.optionsJson) as string[],
      correctIndex: q.correctIndex,
      explanation: q.explanation,
      isActive: q.isActive,
    })),
  })
}

export async function POST(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const json = (await req.json().catch(() => ({}))) as {
    categoryId?: string
    difficulty?: string
    text?: string
    imageUrl?: string
    options?: string[]
    correctIndex?: number
    explanation?: string
  }
  const categoryId = str(json.categoryId, 40)
  const text = str(json.text, 500)
  const difficulty = ['EASY', 'MEDIUM', 'HARD'].includes(String(json.difficulty)) ? String(json.difficulty) : 'EASY'
  const options = Array.isArray(json.options) ? json.options.map((o) => str(o, 200)) : []
  const correctIndex = int(json.correctIndex, -1)
  const imageUrl = str(json.imageUrl, 300)

  if (!categoryId) return fail('Kategori wajib dipilih.')
  if (text.length < 5) return fail('Pertanyaan minimal 5 karakter.')
  if (options.length !== 4 || options.some((o) => !o)) return fail('Harus ada 4 pilihan jawaban yang terisi.')
  if (correctIndex < 0 || correctIndex > 3) return fail('Tandai jawaban yang benar (A-D).')

  const question = await db.question.create({
    data: {
      categoryId,
      difficulty,
      text,
      imageUrl: imageUrl || null,
      optionsJson: JSON.stringify(options),
      correctIndex,
      explanation: str(json.explanation, 500) || null,
    },
  })
  await audit(admin, 'TAMBAH_SOAL', 'Question', question.id, text.slice(0, 80))
  return ok({ success: true, id: question.id })
}

export async function PATCH(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const json = (await req.json().catch(() => ({}))) as {
    id?: string
    difficulty?: string
    text?: string
    imageUrl?: string
    options?: string[]
    correctIndex?: number
    explanation?: string
    isActive?: boolean
  }
  if (!json.id) return fail('id soal wajib.')

  const existing = await db.question.findUnique({ where: { id: json.id } })
  if (!existing) return fail('Soal tidak ditemukan.', 404)

  const data: Record<string, unknown> = {}
  if (json.difficulty && ['EASY', 'MEDIUM', 'HARD'].includes(json.difficulty)) data.difficulty = json.difficulty
  if (json.text) data.text = str(json.text, 500)
  if (json.imageUrl !== undefined) data.imageUrl = str(json.imageUrl, 300) || null
  if (Array.isArray(json.options)) {
    const options = json.options.map((o) => str(o, 200))
    if (options.length !== 4 || options.some((o) => !o)) return fail('Harus ada 4 pilihan jawaban yang terisi.')
    data.optionsJson = JSON.stringify(options)
  }
  if (json.correctIndex !== undefined) {
    if (json.correctIndex < 0 || json.correctIndex > 3) return fail('Jawaban benar tidak valid.')
    data.correctIndex = json.correctIndex
  }
  if (json.explanation !== undefined) data.explanation = str(json.explanation, 500) || null
  if (json.isActive !== undefined) data.isActive = json.isActive

  await db.question.update({ where: { id: json.id }, data })
  await audit(admin, 'UBAH_SOAL', 'Question', json.id, (json.text || existing.text).slice(0, 80))
  return ok({ success: true })
}

export async function DELETE(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const id = req.nextUrl.searchParams.get('id') || ''
  const existing = await db.question.findUnique({
    where: { id },
    include: { _count: { select: { answers: true } } },
  })
  if (!existing) return fail('Soal tidak ditemukan.', 404)

  if (existing._count.answers > 0) {
    // Sudah terpakai dalam permainan: nonaktifkan agar riwayat tetap konsisten
    await db.question.update({ where: { id }, data: { isActive: false } })
    await audit(admin, 'NONAKTIFKAN_SOAL', 'Question', id, 'Sudah memiliki riwayat jawaban')
    return ok({ success: true, soft: true, message: 'Soal dinonaktifkan (punya riwayat jawaban).' })
  }
  await db.question.delete({ where: { id } })
  await audit(admin, 'HAPUS_SOAL', 'Question', id, existing.text.slice(0, 80))
  return ok({ success: true, message: 'Soal dihapus.' })
}
