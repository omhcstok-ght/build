import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, fail, int } from '@/lib/admin-core'
import { getRevenueSummary } from '@/lib/finance'

/**
 * Laporan keuangan CSV: buku besar + pencairan.
 * Unduh via /api/admin/reports/csv?from=YYYY-MM-DD&to=YYYY-MM-DD
 */
export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const from = req.nextUrl.searchParams.get('from')
  const to = req.nextUrl.searchParams.get('to')
  const fromAt = from ? new Date(from + 'T00:00:00') : undefined
  const toAt = to ? new Date(to + 'T23:59:59') : undefined

  const where: { createdAt?: { gte?: Date; lte?: Date } } = {}
  if (fromAt || toAt) where.createdAt = {}
  if (fromAt) where.createdAt!.gte = fromAt
  if (toAt) where.createdAt!.lte = toAt

  const limit = Math.min(int(req.nextUrl.searchParams.get('limit'), 5000), 10000)
  const [ledger, withdrawals, summary] = await Promise.all([
    db.financialLedger.findMany({ where, orderBy: { createdAt: 'asc' }, take: limit }),
    db.withdrawalRequest.findMany({
      where,
      orderBy: { createdAt: 'asc' },
      take: limit,
      include: { user: { select: { username: true } } },
    }),
    getRevenueSummary(),
  ])

  const esc = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`
  const lines: string[] = []
  lines.push('QUIZ & EARN - LAPORAN KEUANGAN')
  lines.push(`Periode,${from ?? 'awal'},s/d,${to ?? 'sekarang'}`)
  lines.push('')
  lines.push('RINGKASAN')
  lines.push(`Modal,${summary.capital}`)
  lines.push(`Pendapatan Iklan,${summary.adRevenue}`)
  lines.push(`Pendapatan Sponsor,${summary.sponsorRevenue}`)
  lines.push(`Hadiah Dibayar,${summary.prizePayout}`)
  lines.push(`Saldo Anggaran Hadiah,${summary.budget}`)
  lines.push('')
  lines.push('BUKU BESAR')
  lines.push('Tanggal,Tipe,Jumlah,Saldo,Ref,Note,Oleh')
  for (const l of ledger) {
    lines.push(
      [l.createdAt.toISOString(), l.type, l.amount, l.balanceAfter, l.refId ?? '', l.note ?? '', l.createdBy ?? ''].map(esc).join(',')
    )
  }
  lines.push('')
  lines.push('PENCAIRAN')
  lines.push('Tanggal,Pengguna,Jumlah,Metode,Nama,NoTujuan,Status,Referensi')
  for (const w of withdrawals) {
    lines.push(
      [w.createdAt.toISOString(), w.user.username, w.amount, w.method, w.accountName, w.accountNumber, w.status, w.reference ?? ''].map(esc).join(',')
    )
  }

  const csv = '\uFEFF' + lines.join('\r\n')
  return new Response(csv, {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="laporan-quiz-earn-${new Date().toISOString().slice(0, 10)}.csv"`,
    },
  })
}
