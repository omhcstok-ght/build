import { NextRequest } from 'next/server'
import { requireAdmin, audit, ok, fail, int } from '@/lib/admin-core'
import { db } from '@/lib/db'

const ALLOWED_KEYS = new Set([
  'pointsPerCorrectEasy', 'pointsPerCorrectMedium', 'pointsPerCorrectHard',
  'streakEvery', 'streakBonus', 'completionBonus', 'perfectBonus',
  'quizQuestionsPerSession', 'quizTimeSeconds', 'answerAntiBotMs',
  'conversionRateRupiahPerPoint', 'minConvertPoints', 'minWithdrawal',
  'maxPendingWithdrawals', 'payoutMode',
  'dailyAdLimit', 'adRewardPoints',
  'enableDANA', 'enableOVO', 'enableGoPay',
  'feesJson', 'processingTimeJson',
  'luckyBonusPoints', 'allowDevSim',
])

export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const rows = await db.appSetting.findMany()
  return ok({
    settings: Object.fromEntries(rows.map((r) => [r.key, r.value])),
    allowedKeys: Array.from(ALLOWED_KEYS),
    automaticPayout: {
      disburseUrl: process.env.DISBURSE_API_URL ? true : false,
      disburseKey: process.env.DISBURSE_API_KEY ? true : false,
      webhookSecret: process.env.PAYMENT_WEBHOOK_SECRET ? true : false,
    },
  })
}

export async function PATCH(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const json = (await req.json().catch(() => ({}))) as Record<string, unknown>
  const changed: string[] = []

  for (const [key, value] of Object.entries(json)) {
    if (!ALLOWED_KEYS.has(key)) continue
    let final = ''
    if (key === 'payoutMode') {
      const v = String(value)
      if (!['manual', 'automatic'].includes(v)) continue
      final = v
    } else if (key === 'feesJson' || key === 'processingTimeJson') {
      try {
        const parsed = JSON.parse(String(value))
        final = JSON.stringify(parsed)
      } catch {
        continue
      }
    } else if (key === 'enableDANA' || key === 'enableOVO' || key === 'enableGoPay' || key === 'allowDevSim') {
      final = value === true || value === 'true' ? 'true' : 'false'
    } else {
      const n = int(value, -1)
      if (n < 0) continue
      final = String(n)
    }
    await db.appSetting.upsert({ where: { key }, update: { value: final }, create: { key, value: final } })
    changed.push(key)
  }

  if (changed.length > 0) {
    await audit(admin, 'UBAH_PENGATURAN', 'Settings', undefined, changed.join(', '))
  }
  return ok({ success: true, changed })
}
