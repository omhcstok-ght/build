import { NextResponse } from 'next/server'
import { ok } from '@/lib/api-utils'
import { clearAuthCookies } from '@/lib/auth'

export async function POST() {
  const res = ok({ success: true })
  clearAuthCookies(res as NextResponse)
  return res
}
