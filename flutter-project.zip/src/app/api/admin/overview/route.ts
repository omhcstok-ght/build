import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, audit, ok, fail } from '@/lib/admin-core'
import { startOfToday } from '@/lib/api-utils'
import { getRevenueSummary } from '@/lib/finance'

export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const today = startOfToday()
  const [
    usersTotal, usersToday, usersBlocked,
    sessionsToday, sessionsActive,
    pointsIssuedToday,
    withdrawalsAgg,
    adEvents,
    fraudEvents,
    supportOpen,
    revenue,
    convertAgg,
  ] = await Promise.all([
    db.user.count(),
    db.user.count({ where: { createdAt: { gte: today } } }),
    db.user.count({ where: { isBlocked: true } }),
    db.quizSession.count({ where: { startedAt: { gte: today } } }),
    db.quizSession.count({ where: { status: 'ACTIVE' } }),
    db.pointTransaction.aggregate({
      where: { type: { startsWith: 'EARN' }, createdAt: { gte: today } },
      _sum: { amount: true },
    }),
    db.withdrawalRequest.groupBy({ by: ['status'], _count: { _all: true }, _sum: { amount: true } }),
    db.adRewardEvent.count(),
    db.fraudEvent.count({ where: { createdAt: { gte: today } } }),
    db.supportMessage.count({ where: { status: 'OPEN' } }),
    getRevenueSummary(),
    db.pointTransaction.aggregate({
      where: { type: 'CONVERT_OUT' },
      _sum: { amount: true },
    }),
  ])

  const paid = withdrawalsAgg.find((w) => w.status === 'PAID')

  // Grafik 7 hari: poin diterbitkan & pencairan
  const days: { date: string; points: number; withdrawals: number }[] = []
  for (let i = 6; i >= 0; i--) {
    const start = new Date(today)
    start.setDate(start.getDate() - i)
    const end = new Date(start)
    end.setDate(end.getDate() + 1)
    const [pts, wds] = await Promise.all([
      db.pointTransaction.aggregate({
        where: { type: { startsWith: 'EARN' }, createdAt: { gte: start, lt: end } },
        _sum: { amount: true },
      }),
      db.withdrawalRequest.count({ where: { createdAt: { gte: start, lt: end } } }),
    ])
    days.push({
      date: start.toISOString().slice(5, 10),
      points: pts._sum.amount ?? 0,
      withdrawals: wds,
    })
  }

  return ok({
    users: { total: usersTotal, today: usersToday, blocked: usersBlocked },
    sessions: { today: sessionsToday, active: sessionsActive },
    pointsIssuedToday: pointsIssuedToday._sum.amount ?? 0,
    pointsConvertedTotal: Math.abs(convertAgg._sum.amount ?? 0),
    withdrawals: withdrawalsAgg.map((w) => ({
      status: w.status,
      count: w._count._all,
      amount: w._sum.amount ?? 0,
    })),
    paidTotal: paid?._sum.amount ?? 0,
    paidCount: paid?._count._all ?? 0,
    adEvents,
    fraudEvents,
    supportOpen,
    revenue,
    chart: days,
  })
}
