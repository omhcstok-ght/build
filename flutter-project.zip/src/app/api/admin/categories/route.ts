import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, audit, ok, fail, str, int } from '@/lib/admin-core'

export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const categories = await db.quizCategory.findMany({
    orderBy: { sortOrder: 'asc' },
    include: { _count: { select: { questions: true } } },
  })
  return ok({
    categories: categories.map((c) => ({
      id: c.id,
      name: c.name,
      slug: c.slug,
      icon: c.icon,
      gradient: c.gradient,
      description: c.description,
      isActive: c.isActive,
      sortOrder: c.sortOrder,
      questionCount: c._count.questions,
    })),
  })
}

export async function POST(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const json = (await req.json().catch(() => ({}))) as { name?: string; description?: string; icon?: string; gradient?: string }
  const name = str(json.name, 40)
  if (name.length < 3) return fail('Nama kategori minimal 3 karakter.')
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')
  const exists = await db.quizCategory.findUnique({ where: { slug } })
  if (exists) return fail('Kategori dengan nama serupa sudah ada.')

  const count = await db.quizCategory.count()
  const created = await db.quizCategory.create({
    data: {
      name,
      slug,
      description: str(json.description, 200) || null,
      icon: str(json.icon, 30) || 'Brain',
      gradient: str(json.gradient, 20) || 'blue',
      sortOrder: count,
    },
  })
  await audit(admin, 'TAMBAH_KATEGORI', 'QuizCategory', created.id, name)
  return ok({ success: true, id: created.id })
}

export async function PATCH(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const json = (await req.json().catch(() => ({}))) as {
    id?: string
    name?: string
    description?: string
    icon?: string
    gradient?: string
    isActive?: boolean
  }
  if (!json.id) return fail('id kategori wajib.')
  const data: Record<string, unknown> = {}
  if (json.name) data.name = str(json.name, 40)
  if (json.description !== undefined) data.description = str(json.description, 200) || null
  if (json.icon) data.icon = str(json.icon, 30)
  if (json.gradient) data.gradient = str(json.gradient, 20)
  if (json.isActive !== undefined) data.isActive = json.isActive

  await db.quizCategory.update({ where: { id: json.id }, data })
  await audit(admin, 'UBAH_KATEGORI', 'QuizCategory', json.id, JSON.stringify(json).slice(0, 150))
  return ok({ success: true })
}
