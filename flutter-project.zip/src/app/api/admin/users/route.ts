import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, audit, ok, fail, str, int } from '@/lib/admin-core'
import { hashPassword } from '@/lib/auth'
import { creditPoints } from '@/lib/points'

export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const url = req.nextUrl
  const q = url.searchParams.get('q') || ''
  const filter = url.searchParams.get('filter') || 'all' // all | blocked | active
  const page = Math.max(1, int(url.searchParams.get('page'), 1))
  const pageSize = 20

  const where: {
    OR?: { name?: { contains: string }; username?: { contains: string }; email?: { contains: string } }[]
    isBlocked?: boolean
  } = {}
  if (q) {
    where.OR = [
      { name: { contains: q } },
      { username: { contains: q } },
      { email: { contains: q } },
    ]
  }
  if (filter === 'blocked') where.isBlocked = true
  if (filter === 'active') where.isBlocked = false

  const [total, users] = await Promise.all([
    db.user.count({ where }),
    db.user.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: { wallet: true, _count: { select: { quizSessions: true, withdrawals: true, fraudEvents: true } } },
    }),
  ])

  return ok({
    page,
    pageSize,
    total,
    users: users.map((u) => ({
      id: u.id,
      name: u.name,
      username: u.username,
      email: u.email,
      avatar: u.avatar,
      isBlocked: u.isBlocked,
      blockReason: u.blockReason,
      emailVerified: u.emailVerified,
      pointsPending: u.pointsPending,
      pointsAvailable: u.pointsAvailable,
      wallet: u.wallet
        ? { available: u.wallet.available, processing: u.wallet.processing, totalPaid: u.wallet.totalPaid }
        : null,
      quizzes: u._count.quizSessions,
      withdrawals: u._count.withdrawals,
      fraudCount: u._count.fraudEvents,
      lastLoginAt: u.lastLoginAt,
      createdAt: u.createdAt,
    })),
  })
}

/** Aksi admin atas pengguna: blokir, buka blokir, sesuaikan poin, reset password, verifikasi email. */
export async function PATCH(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const json = (await req.json().catch(() => ({}))) as {
    userId?: string
    action?: string
    amount?: number
    note?: string
    reason?: string
    newPassword?: string
  }
  const { userId, action } = json
  if (!userId || !action) return fail('userId dan action wajib.')

  const user = await db.user.findUnique({ where: { id: userId } })
  if (!user) return fail('Pengguna tidak ditemukan.', 404)

  switch (action) {
    case 'block': {
      const reason = (json.reason || 'Pelanggaran ketentuan').slice(0, 200)
      await db.user.update({ where: { id: userId }, data: { isBlocked: true, blockReason: reason } })
      await audit(admin, 'BLOKIR_PENGGUNA', 'User', userId, `${user.username}: ${reason}`)
      await db.notification.create({
        data: { userId, title: 'Akun Diblokir', body: reason, kind: 'WARNING' },
      })
      return ok({ success: true, message: 'Pengguna diblokir.' })
    }
    case 'unblock': {
      await db.user.update({ where: { id: userId }, data: { isBlocked: false, blockReason: null } })
      await audit(admin, 'BUKA_BLOKIR_PENGGUNA', 'User', userId, user.username)
      return ok({ success: true, message: 'Blokir dibuka.' })
    }
    case 'adjustPoints': {
      const amount = int(json.amount, 0)
      if (amount === 0) return fail('Jumlah penyesuaian tidak boleh 0.')
      const note = (json.note || 'Penyesuaian oleh admin').slice(0, 200)
      if (amount > 0) {
        await db.$transaction(async (tx) => {
          await creditPoints(tx, { userId, type: 'ADJUST', bucket: 'AVAILABLE', amount, meta: { note } })
        })
      } else {
        const fresh = await db.user.findUnique({ where: { id: userId } })
        if (!fresh || fresh.pointsAvailable < -amount) return fail('Poin tersedia tidak mencukupi untuk dikurangi.')
        await db.$transaction(async (tx) => {
          await creditPoints(tx, { userId, type: 'ADJUST', bucket: 'AVAILABLE', amount, meta: { note } })
        })
      }
      await audit(admin, 'SESUAI_POIN', 'User', userId, `${user.username}: ${amount > 0 ? '+' : ''}${amount} poin - ${note}`)
      await db.notification.create({
        data: { userId, title: 'Poin Disesuaikan', body: `${amount > 0 ? '+' : ''}${amount} poin. ${note}`, kind: 'INFO' },
      })
      return ok({ success: true, message: 'Poin disesuaikan.' })
    }
    case 'resetPassword': {
      const newPassword = json.newPassword || ''
      if (newPassword.length < 8) return fail('Password baru minimal 8 karakter.')
      await db.user.update({ where: { id: userId }, data: { passwordHash: await hashPassword(newPassword) } })
      await audit(admin, 'RESET_PASSWORD', 'User', userId, user.username)
      await db.notification.create({
        data: { userId, title: 'Password Direset', body: 'Admin mereset password akunmu. Segera ganti melalui menu Keamanan.', kind: 'WARNING' },
      })
      return ok({ success: true, message: 'Password pengguna direset.' })
    }
    case 'verifyEmail': {
      await db.user.update({ where: { id: userId }, data: { emailVerified: true } })
      await audit(admin, 'VERIFIKASI_EMAIL', 'User', userId, user.username)
      return ok({ success: true, message: 'Email diverifikasi manual.' })
    }
    default:
      return fail('Aksi tidak dikenal.')
  }
}
