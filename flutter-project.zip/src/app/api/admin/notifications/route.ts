import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, audit, ok, fail, str } from '@/lib/admin-core'

export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const sent = await db.notification.findMany({
    where: { userId: null },
    orderBy: { createdAt: 'desc' },
    take: 30,
  })
  const support = await db.supportMessage.findMany({
    orderBy: { createdAt: 'desc' },
    take: 50,
  })
  return ok({ sent, support })
}

/** Kirim pengumuman broadcast ke seluruh pengguna. */
export async function POST(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const json = (await req.json().catch(() => ({}))) as { title?: string; body?: string; kind?: string }
  const title = str(json.title, 100)
  const body = str(json.body, 1000)
  const kind = ['INFO', 'SUCCESS', 'WARNING', 'PROMO'].includes(String(json.kind)) ? String(json.kind) : 'INFO'
  if (title.length < 3) return fail('Judul minimal 3 karakter.')
  if (body.length < 3) return fail('Isi minimal 3 karakter.')

  await db.notification.create({ data: { title, body, kind } })
  await audit(admin, 'BROADCAST_NOTIFIKASI', 'Notification', undefined, title)
  return ok({ success: true })
}

/** Tandai pesan dukungan selesai. */
export async function PATCH(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const json = (await req.json().catch(() => ({}))) as { id?: string; status?: string }
  if (!json.id) return fail('id wajib.')
  await db.supportMessage.update({
    where: { id: json.id },
    data: { status: json.status === 'OPEN' ? 'OPEN' : 'RESOLVED' },
  })
  await audit(admin, 'UBAH_STATUS_DUKUNGAN', 'SupportMessage', json.id, json.status)
  return ok({ success: true })
}
