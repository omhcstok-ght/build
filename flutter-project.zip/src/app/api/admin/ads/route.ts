import { NextRequest } from 'next/server'
import { requireAdmin, audit, ok, fail, str } from '@/lib/admin-core'
import { db } from '@/lib/db'
import { getSetting } from '@/lib/settings'

/**
 * Konfigurasi jaringan iklan berhadiah.
 * Dua mode integrasi:
 *  - ADMOB : SSV resmi Google, verifikasi kunci publik (tanpa shared secret),
 *            callback URL: /api/ads/ssv/admob
 *  - CUSTOM: HMAC shared secret via AD_CALLBACK_SECRET, callback URL: /api/ads/reward
 * PENTING: status "configured" hanya boleh aktif setelah unit iklan resmi siap
 * dan admin menekan "Aktifkan".
 */
export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const [configured, network, adUnitId, networkType] = await Promise.all([
    getSetting('adNetworkConfigured', 'false'),
    getSetting('adNetworkName', ''),
    getSetting('adUnitId', ''),
    getSetting('adNetworkType', 'CUSTOM'),
  ])

  return ok({
    configured: configured === 'true',
    network,
    adUnitId,
    networkType: networkType === 'ADMOB' ? 'ADMOB' : 'CUSTOM',
    ssvCallbackPath: networkType === 'ADMOB' ? '/api/ads/ssv/admob' : '/api/ads/reward',
    callbackSecretSet: Boolean(process.env.AD_CALLBACK_SECRET),
    dailyAdLimit: await getSetting('dailyAdLimit', '10'),
    adRewardPoints: await getSetting('adRewardPoints', '50'),
    allowDevSim: await getSetting('allowDevSim', 'true'),
  })
}

export async function PATCH(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const json = (await req.json().catch(() => ({}))) as {
    network?: string
    adUnitId?: string
    networkType?: string
    dailyAdLimit?: string
    adRewardPoints?: string
    allowDevSim?: string
    configured?: boolean
  }

  const upsert = async (key: string, value: string) => {
    await db.appSetting.upsert({ where: { key }, update: { value }, create: { key, value } })
  }

  if (json.network !== undefined) await upsert('adNetworkName', str(json.network, 40))
  if (json.adUnitId !== undefined) await upsert('adUnitId', str(json.adUnitId, 120))
  if (json.networkType !== undefined) {
    await upsert('adNetworkType', json.networkType === 'ADMOB' ? 'ADMOB' : 'CUSTOM')
  }
  if (json.dailyAdLimit !== undefined) await upsert('dailyAdLimit', String(Math.max(1, parseInt(json.dailyAdLimit, 10) || 10)))
  if (json.adRewardPoints !== undefined) await upsert('adRewardPoints', String(Math.max(1, parseInt(json.adRewardPoints, 10) || 50)))
  if (json.allowDevSim !== undefined) await upsert('allowDevSim', json.allowDevSim === 'true' ? 'true' : 'false')

  if (json.configured !== undefined) {
    const type = (json.networkType ?? (await getSetting('adNetworkType', 'CUSTOM'))) === 'ADMOB' ? 'ADMOB' : 'CUSTOM'
    if (json.configured) {
      if (type === 'CUSTOM' && !process.env.AD_CALLBACK_SECRET) {
        return fail('Tidak dapat mengaktifkan mode CUSTOM: AD_CALLBACK_SECRET belum diatur pada environment.')
      }
      if (type === 'ADMOB') {
        const unit = json.adUnitId !== undefined ? str(json.adUnitId, 120) : await getSetting('adUnitId', '')
        if (!unit) return fail('Tidak dapat mengaktifkan mode ADMOB: isi Ad Unit ID dari AdMob console terlebih dahulu.')
      }
    }
    await upsert('adNetworkConfigured', json.configured ? 'true' : 'false')
  }

  await audit(admin, 'UBAH_KONFIG_IKLAN', 'Settings', undefined, JSON.stringify(json).slice(0, 200))
  return ok({ success: true })
}
