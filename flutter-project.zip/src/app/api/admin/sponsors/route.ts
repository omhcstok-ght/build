import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, audit, ok, fail, int, str } from '@/lib/admin-core'
import { addLedgerEntry } from '@/lib/finance'

export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const sponsors = await db.sponsor.findMany({
    orderBy: { createdAt: 'desc' },
    include: { campaigns: true },
  })
  return ok({ sponsors })
}

export async function POST(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const json = (await req.json().catch(() => ({}))) as {
    kind?: 'sponsor' | 'campaign'
    name?: string
    logoUrl?: string
    contact?: string
    notes?: string
    sponsorId?: string
    title?: string
    description?: string
    budget?: number
  }

  if (json.kind === 'campaign') {
    if (!json.sponsorId || !json.title) return fail('Sponsor dan judul kampanye wajib.')
    const budget = int(json.budget, 0)
    if (budget <= 0) return fail('Anggaran kampanye harus lebih dari 0.')
    const sponsor = await db.sponsor.findUnique({ where: { id: json.sponsorId } })
    if (!sponsor) return fail('Sponsor tidak ditemukan.', 404)
    const c = await db.sponsorCampaign.create({
      data: {
        sponsorId: json.sponsorId,
        title: str(json.title, 100),
        description: str(json.description, 300) || null,
        budget,
        status: 'DRAFT',
      },
    })
    await audit(admin, 'TAMBAH_KAMPANYE', 'SponsorCampaign', c.id, c.title)
    return ok({ success: true, id: c.id })
  }

  const name = str(json.name, 60)
  if (name.length < 2) return fail('Nama sponsor minimal 2 karakter.')
  const s = await db.sponsor.create({
    data: {
      name,
      logoUrl: str(json.logoUrl, 300) || null,
      contact: str(json.contact, 100) || null,
      notes: str(json.notes, 300) || null,
    },
  })
  await audit(admin, 'TAMBAH_SPONSOR', 'Sponsor', s.id, name)
  return ok({ success: true, id: s.id })
}

/** Aksi kampanye: fund (dicatat sebagai pendapatan sponsor ke anggaran), aktifkan, akhiri. */
export async function PATCH(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const json = (await req.json().catch(() => ({}))) as {
    campaignId?: string
    action?: 'fund' | 'activate' | 'end'
    amount?: number
    sponsorId?: string
    isActive?: boolean
  }

  if (json.sponsorId && json.isActive !== undefined) {
    await db.sponsor.update({ where: { id: json.sponsorId }, data: { isActive: json.isActive } })
    await audit(admin, 'UBAH_SPONSOR', 'Sponsor', json.sponsorId, `isActive=${json.isActive}`)
    return ok({ success: true })
  }

  if (!json.campaignId || !json.action) return fail('campaignId dan action wajib.')
  const campaign = await db.sponsorCampaign.findUnique({ where: { id: json.campaignId } })
  if (!campaign) return fail('Kampanye tidak ditemukan.', 404)

  if (json.action === 'fund') {
    const amount = int(json.amount, 0)
    if (amount <= 0) return fail('Jumlah pendanaan harus lebih dari 0.')
    await db.$transaction(async (tx) => {
      await tx.sponsorCampaign.update({
        where: { id: campaign.id },
        data: {
          fundedAmount: { increment: amount },
          status: campaign.status === 'DRAFT' ? 'FUNDED' : campaign.status,
        },
      })
      await addLedgerEntry(tx, {
        type: 'SPONSOR_REVENUE',
        amount,
        refType: 'SPONSOR_CAMPAIGN',
        refId: campaign.id,
        note: `Pendanaan kampanye "${campaign.title}"`,
        createdBy: admin.username,
      })
    })
    await audit(admin, 'DANAI_KAMPANYE', 'SponsorCampaign', campaign.id, `Rp${amount.toLocaleString('id-ID')}`)
    return ok({ success: true, message: 'Pendanaan dicatat ke anggaran hadiah.' })
  }

  if (json.action === 'activate') {
    if (campaign.fundedAmount <= 0) return fail('Kampanye harus didanai lebih dahulu.')
    await db.sponsorCampaign.update({ where: { id: campaign.id }, data: { status: 'ACTIVE' } })
    await audit(admin, 'AKTIFKAN_KAMPANYE', 'SponsorCampaign', campaign.id)
    return ok({ success: true })
  }

  if (json.action === 'end') {
    await db.sponsorCampaign.update({ where: { id: campaign.id }, data: { status: 'ENDED' } })
    await audit(admin, 'AKHIRI_KAMPANYE', 'SponsorCampaign', campaign.id)
    return ok({ success: true })
  }

  return fail('Aksi tidak dikenal.')
}
