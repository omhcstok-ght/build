import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, audit, ok, fail, int, str } from '@/lib/admin-core'
import { addLedgerEntry } from '@/lib/finance'

export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const ledger = await db.financialLedger.findMany({
    where: { type: { in: ['AD_REVENUE', 'SPONSOR_REVENUE'] } },
    orderBy: { createdAt: 'desc' },
    take: 100,
  })
  const adEvents = await db.adRewardEvent.findMany({
    orderBy: { createdAt: 'desc' },
    take: 30,
    include: { user: { select: { username: true } } },
  })

  return ok({ ledger, adEvents })
}

/**
 * Catat pendapatan manual (buku) dari iklan/sponsor.
 * Catatan: pendapatan iklan otomatis hanya akan dicatat oleh integrasi jaringan iklan
 * setelah terhubung; entri manual dipakai untuk rekonsiliasi pembukuan nyata.
 */
export async function POST(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const json = (await req.json().catch(() => ({}))) as { type?: string; amount?: number; note?: string }
  const type = ['AD_REVENUE', 'SPONSOR_REVENUE'].includes(String(json.type)) ? String(json.type) : ''
  const amount = int(json.amount, 0)
  if (!type) return fail('Tipe pendapatan tidak valid.')
  if (amount <= 0) return fail('Jumlah harus lebih dari 0.')

  await db.$transaction(async (tx) => {
    await addLedgerEntry(tx, {
      type: type as 'AD_REVENUE' | 'SPONSOR_REVENUE',
      amount,
      note: json.note?.slice(0, 200) || 'Pencatatan manual oleh admin',
      createdBy: admin.username,
    })
  })
  await audit(admin, 'CATAT_PENDAPATAN', 'Ledger', type, `Rp${amount.toLocaleString('id-ID')}`)
  return ok({ success: true, message: 'Pendapatan dicatat ke anggaran hadiah.' })
}
