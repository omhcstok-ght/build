import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, audit, ok, fail, str } from '@/lib/admin-core'
import { getPrizeBudget, addLedgerEntry } from '@/lib/finance'
import { rupiah } from '@/lib/api-utils'

/** Daftar pengajuan pencairan untuk admin. */
export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const status = req.nextUrl.searchParams.get('status')
  const where = status && status !== 'ALL' ? { status } : {}

  const list = await db.withdrawalRequest.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: 100,
    include: { user: { select: { name: true, username: true, email: true, isBlocked: true } } },
  })
  const budget = await getPrizeBudget()
  const automaticAvailable = Boolean(process.env.DISBURSE_API_KEY && process.env.DISBURSE_API_URL)

  return ok({
    withdrawals: list.map((w) => ({
      id: w.id,
      user: w.user,
      amount: w.amount,
      fee: w.fee,
      method: w.method,
      accountName: w.accountName,
      accountNumber: w.accountNumber,
      status: w.status,
      mode: w.mode,
      reference: w.reference,
      adminNote: w.adminNote,
      processedAt: w.processedAt,
      createdAt: w.createdAt,
    })),
    prizeBudget: budget,
    payoutMode: await import('@/lib/settings').then((m) => m.getSetting('payoutMode', 'manual')),
    automaticAvailable,
  })
}

/**
 * Transisi status pencairan (mode manual):
 * review -> approve -> (pembayaran manual oleh admin) markPaid | reject | markFailed
 * Semua perubahan saldo & ledger dilakukan dalam transaksi database.
 */
export async function PATCH(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const json = (await req.json().catch(() => ({}))) as {
    id?: string
    action?: string
    reference?: string
    note?: string
  }
  if (!json.id || !json.action) return fail('id dan action wajib.')

  const wd = await db.withdrawalRequest.findUnique({ where: { id: json.id } })
  if (!wd) return fail('Pengajuan tidak ditemukan.', 404)

  const note = str(json.note, 300)
  const reference = str(json.reference, 80)

  const setProcessingStatuses = ['PENDING', 'REVIEWING', 'APPROVED']

  switch (json.action) {
    case 'review': {
      if (wd.status !== 'PENDING') return fail('Hanya pengajuan PENDING yang bisa ditinjau.')
      await db.withdrawalRequest.update({ where: { id: wd.id }, data: { status: 'REVIEWING' } })
      await audit(admin, 'TINJAU_PENCAIRAN', 'Withdrawal', wd.id, `${rupiah(wd.amount)} -> ${wd.method}`)
      return ok({ success: true })
    }
    case 'approve': {
      if (!setProcessingStatuses.includes(wd.status)) return fail('Status tidak dapat disetujui.')
      await db.withdrawalRequest.update({ where: { id: wd.id }, data: { status: 'APPROVED', adminNote: note || 'Disetujui, menunggu pembayaran.' } })
      await audit(admin, 'SETUJUI_PENCAIRAN', 'Withdrawal', wd.id, `${rupiah(wd.amount)} -> ${wd.method} ${wd.accountNumber}`)
      return ok({ success: true })
    }
    case 'startProcessing': {
      if (!['APPROVED', 'REVIEWING'].includes(wd.status)) return fail('Status tidak valid untuk mulai diproses.')
      await db.withdrawalRequest.update({ where: { id: wd.id }, data: { status: 'PROCESSING' } })
      await audit(admin, 'PROSES_PENCAIRAN', 'Withdrawal', wd.id, wd.id.slice(-8))
      return ok({ success: true })
    }
    case 'markPaid': {
      if (!['APPROVED', 'PROCESSING', 'REVIEWING'].includes(wd.status)) {
        return fail('Tandai dibayar hanya dari status REVIEWING/APPROVED/PROCESSING.')
      }
      if (!reference || reference.length < 3) return fail('Nomor referensi pembayaran wajib diisi.')
      const budget = await getPrizeBudget()
      if (budget < wd.amount) {
        return fail(`Anggaran hadiah tidak cukup (tersedia ${rupiah(budget)}). Tambahkan modal/pendapatan terlebih dahulu.`)
      }
      await db.$transaction(async (tx) => {
        const wallet = await tx.wallet.findUnique({ where: { userId: wd.userId } })
        if (!wallet) throw new Error('Dompet tidak ditemukan')
        await tx.wallet.update({
          where: { userId: wd.userId },
          data: {
            processing: Math.max(0, wallet.processing - wd.amount),
            totalPaid: { increment: wd.amount },
          },
        })
        await tx.paymentTransaction.create({
          data: {
            withdrawalId: wd.id,
            provider: 'MANUAL',
            amount: wd.amount,
            status: 'PAID',
            reference,
            meta: JSON.stringify({ admin: admin.username, note }),
          },
        })
        await tx.withdrawalRequest.update({
          where: { id: wd.id },
          data: {
            status: 'PAID',
            reference,
            processedBy: admin.username,
            processedAt: new Date(),
            adminNote: note || 'Pembayaran manual diverifikasi admin.',
          },
        })
        await addLedgerEntry(tx, {
          type: 'PRIZE_PAYOUT',
          amount: -wd.amount,
          refType: 'WITHDRAWAL',
          refId: wd.id,
          note: `Pembayaran manual ke ${wd.method} ${wd.accountNumber} (ref ${reference})`,
          createdBy: admin.username,
        })
        await tx.notification.create({
          data: {
            userId: wd.userId,
            title: 'Pencairan Berhasil',
            body: `Pencairan ${rupiah(wd.amount - wd.fee)} telah dikirim ke ${wd.method} ${wd.accountNumber}. Referensi: ${reference}`,
            kind: 'SUCCESS',
          },
        })
      })
      await audit(admin, 'BAYAR_PENCAIRAN', 'Withdrawal', wd.id, `${rupiah(wd.amount)} ref ${reference}`)
      return ok({ success: true, message: 'Pembayaran dicatat & anggaran hadiah terpotong.' })
    }
    case 'reject': {
      if (!['PENDING', 'REVIEWING', 'APPROVED'].includes(wd.status)) {
        return fail('Pengajuan dalam status ini tidak dapat ditolak.')
      }
      if (!note) return fail('Alasan penolakan wajib diisi.')
      await db.$transaction(async (tx) => {
        const wallet = await tx.wallet.findUnique({ where: { userId: wd.userId } })
        if (!wallet) throw new Error('Dompet tidak ditemukan')
        // Dana kembali dari processing ke available
        await tx.wallet.update({
          where: { userId: wd.userId },
          data: {
            processing: Math.max(0, wallet.processing - wd.amount),
            available: { increment: wd.amount },
          },
        })
        await tx.withdrawalRequest.update({
          where: { id: wd.id },
          data: { status: 'REJECTED', adminNote: note, processedBy: admin.username, processedAt: new Date() },
        })
        await tx.notification.create({
          data: {
            userId: wd.userId,
            title: 'Pencairan Ditolak',
            body: `Pengajuan ${rupiah(wd.amount)} ditolak. Alasan: ${note}. Dana dikembalikan ke saldo hadiah.`,
            kind: 'WARNING',
          },
        })
      })
      await audit(admin, 'TOLAK_PENCAIRAN', 'Withdrawal', wd.id, note)
      return ok({ success: true })
    }
    case 'markFailed': {
      if (!['PROCESSING', 'APPROVED'].includes(wd.status)) return fail('Status tidak valid.')
      await db.$transaction(async (tx) => {
        const wallet = await tx.wallet.findUnique({ where: { userId: wd.userId } })
        if (!wallet) throw new Error('Dompet tidak ditemukan')
        await tx.wallet.update({
          where: { userId: wd.userId },
          data: {
            processing: Math.max(0, wallet.processing - wd.amount),
            available: { increment: wd.amount },
          },
        })
        await tx.withdrawalRequest.update({
          where: { id: wd.id },
          data: { status: 'FAILED', adminNote: note || 'Gagal diproses; dana dikembalikan.', processedBy: admin.username },
        })
        await tx.notification.create({
          data: { userId: wd.userId, title: 'Pencairan Gagal', body: 'Dana dikembalikan ke saldo hadiahmu.', kind: 'WARNING' },
        })
      })
      await audit(admin, 'PENCAIRAN_GAGAL', 'Withdrawal', wd.id, note)
      return ok({ success: true })
    }
    default:
      return fail('Aksi tidak dikenal.')
  }
}
