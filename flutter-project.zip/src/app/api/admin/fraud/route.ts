import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, ok, fail, int } from '@/lib/admin-core'

export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return fail('Akses admin diperlukan.', 401)

  const page = Math.max(1, int(req.nextUrl.searchParams.get('page'), 1))
  const pageSize = 30
  const [total, events] = await Promise.all([
    db.fraudEvent.count(),
    db.fraudEvent.findMany({
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: { user: { select: { username: true, name: true, isBlocked: true } } },
    }),
  ])
  return ok({ page, total, events })
}
