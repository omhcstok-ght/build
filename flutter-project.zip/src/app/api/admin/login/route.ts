import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { signToken, setAdminCookie, verifyPassword, clientIp } from '@/lib/auth'
import { ok, fail, readJson, str } from '@/lib/api-utils'
import { rateLimit } from '@/lib/rate-limit'
import { NextResponse } from 'next/server'

/** Login administrator terpisah dari login pengguna (kuki & token berbeda). */
export async function POST(req: NextRequest) {
  const ip = clientIp(req)
  if (!rateLimit(`admin-login:${ip}`, 8, 60_000)) return fail('Terlalu banyak percobaan.', 429)

  const body = await readJson(req)
  const username = str(body.username, 40)
  const password = typeof body.password === 'string' ? body.password : ''
  if (!username || !password) return fail('Username dan password wajib diisi.')

  const admin = await db.adminUser.findUnique({ where: { username } })
  if (!admin) return fail('Kombinasi username dan password admin tidak cocok.', 401)

  const valid = await verifyPassword(password, admin.passwordHash)
  if (!valid) return fail('Kombinasi username dan password admin tidak cocok.', 401)

  await db.adminUser.update({ where: { id: admin.id }, data: { lastLoginAt: new Date() } })
  await db.adminAuditLog.create({
    data: { adminId: admin.id, adminName: admin.username, action: 'LOGIN', detail: `Login dari IP ${ip}` },
  })

  const token = await signToken({ sub: admin.id, role: 'admin', name: admin.name, username: admin.username }, 0.5)
  const res = ok({ token, admin: { id: admin.id, name: admin.name, username: admin.username } })
  setAdminCookie(res as NextResponse, token)
  return res
}
