import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'
import { ok, fail } from '@/lib/api-utils'
import { getWalletRules } from '@/lib/settings'

export async function GET(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)

  const user = await db.user.findUnique({ where: { id: session.sub }, include: { wallet: true } })
  if (!user) return fail('Pengguna tidak ditemukan.', 404)

  const rules = await getWalletRules()
  const pendingWd = await db.withdrawalRequest.aggregate({
    where: { userId: user.id, status: { in: ['PENDING', 'REVIEWING', 'APPROVED', 'PROCESSING'] } },
    _count: { _all: true },
    _sum: { amount: true },
  })

  return ok({
    pointsPending: user.pointsPending,
    pointsAvailable: user.pointsAvailable,
    estimateValue: user.pointsAvailable * rules.conversionRate,
    conversionRate: rules.conversionRate,
    conversionOptions: rules.conversionOptions,
    minConvertPoints: rules.minConvertPoints,
    wallet: {
      available: user.wallet?.available ?? 0,
      processing: user.wallet?.processing ?? 0,
      totalPaid: user.wallet?.totalPaid ?? 0,
    },
    withdrawals: {
      activeCount: pendingWd._count._all ?? 0,
      activeAmount: pendingWd._sum.amount ?? 0,
      maxPending: rules.maxPendingWithdrawals,
    },
  })
}
