import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'
import { ok, fail, readJson, int, str } from '@/lib/api-utils'
import { rateLimit } from '@/lib/rate-limit'
import { getWalletRules } from '@/lib/settings'
import { debitAvailablePoints } from '@/lib/points'
import { rupiah } from '@/lib/api-utils'

/**
 * Tukar poin menjadi saldo hadiah (Rp).
 * - Validasi penuh di server: poin tersedia, nominal diizinkan, laju permintaan.
 * - Poin di-debit dan saldo hadiah di-kredit dalam SATU transaksi database.
 */
export async function POST(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)

  if (!rateLimit(`convert:${session.sub}`, 10, 60_000)) {
    return fail('Terlalu banyak permintaan konversi. Tunggu sebentar.', 429)
  }

  const body = await readJson(req)
  const points = int(body.points, 0)
  const idempotencyKey = str(body.idempotencyKey, 60)
  if (!idempotencyKey) return fail('Kunci idempotensi diperlukan.')

  // Idempotensi: tolak kunci yang sudah dipakai
  const dup = await db.pointTransaction.findFirst({
    where: { type: 'CONVERT_OUT', meta: { contains: idempotencyKey } },
  })
  if (dup) return fail('Permintaan konversi ini sudah diproses sebelumnya.', 409)

  const rules = await getWalletRules()
  if (points < rules.minConvertPoints) {
    return fail(`Minimal penukaran ${rules.minConvertPoints.toLocaleString('id-ID')} poin.`)
  }
  const rupiahValue = points * rules.conversionRate
  const allowed = rules.conversionOptions.includes(points) || points % 100 === 0
  if (!allowed) return fail('Nominal penukaran tidak valid.')

  try {
    const result = await db.$transaction(async (tx) => {
      const user = await tx.user.findUnique({ where: { id: session.sub } })
      if (!user) throw new Error('Pengguna tidak ditemukan.')
      if (user.pointsAvailable < points) throw new Error('Poin tersedia tidak mencukupi.')

      await debitAvailablePoints(tx, user.id, points, 'CONVERT_OUT', {
        rupiah: rupiahValue,
        idempotencyKey,
        note: `Penukaran ${points.toLocaleString('id-ID')} poin`,
      })
      await tx.wallet.upsert({
        where: { userId: user.id },
        update: { available: { increment: rupiahValue } },
        create: { userId: user.id, available: rupiahValue },
      })
      const wallet = await tx.wallet.findUnique({ where: { userId: user.id } })
      await tx.notification.create({
        data: {
          userId: user.id,
          title: 'Penukaran Berhasil',
          body: `${points.toLocaleString('id-ID')} poin berhasil ditukar menjadi ${rupiah(rupiahValue)} saldo hadiah.`,
          kind: 'SUCCESS',
        },
      })
      return { available: wallet?.available ?? 0 }
    })

    return ok({
      success: true,
      rupiahValue,
      walletAvailable: result.available,
      message: `Berhasil menukar ${points.toLocaleString('id-ID')} poin menjadi ${rupiah(rupiahValue)}.`,
    })
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'Gagal menukar poin.'
    return fail(msg)
  }
}
