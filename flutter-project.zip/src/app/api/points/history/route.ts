import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'
import { ok, fail, int } from '@/lib/api-utils'

export async function GET(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)

  const limit = Math.min(int(req.nextUrl.searchParams.get('limit'), 30), 100)
  const txs = await db.pointTransaction.findMany({
    where: { userId: session.sub },
    orderBy: { createdAt: 'desc' },
    take: limit,
  })

  return ok({
    transactions: txs.map((t) => ({
      id: t.id,
      type: t.type,
      bucket: t.bucket,
      amount: t.amount,
      meta: t.meta ? JSON.parse(t.meta) : null,
      sessionId: t.sessionId,
      createdAt: t.createdAt,
    })),
  })
}
