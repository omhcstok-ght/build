import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser, clientIp } from '@/lib/auth'
import { ok, fail, readJson, int, str, isPhone, rupiah } from '@/lib/api-utils'
import { rateLimit } from '@/lib/rate-limit'
import { getWalletRules, getSetting } from '@/lib/settings'
import { getPrizeBudget } from '@/lib/finance'

/** Riwayat pencairan milik pengguna. */
export async function GET(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)

  const list = await db.withdrawalRequest.findMany({
    where: { userId: session.sub },
    orderBy: { createdAt: 'desc' },
    take: 50,
  })
  const rules = await getWalletRules()

  return ok({
    withdrawals: list,
    rules: {
      minWithdrawal: rules.minWithdrawal,
      payoutMode: rules.payoutMode,
      methods: {
        DANA: rules.enableDANA,
        OVO: rules.enableOVO,
        GOPAY: rules.enableGoPay,
      },
      fees: rules.fees,
      processingTime: rules.processingTime,
      automaticAvailable: Boolean(process.env.DISBURSE_API_KEY && process.env.DISBURSE_API_URL),
    },
  })
}

/**
 * Ajukan pencairan saldo hadiah ke dompet digital.
 * - Validasi saldo & aturan di server, di dalam transaksi DB (mencegah double withdrawal).
 * - Saldo dipindahkan available -> processing (tidak langsung hilang).
 * - Mode otomatis hanya diizinkan bila penyedia disbursement benar-benar terhubung.
 */
export async function POST(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)

  const ip = clientIp(req)
  if (!rateLimit(`withdraw:${session.sub}`, 5, 60_000)) {
    return fail('Terlalu banyak permintaan penarikan. Tunggu sebentar.', 429)
  }

  const body = await readJson(req)
  const amount = int(body.amount, 0)
  const method = ['DANA', 'OVO', 'GOPAY'].includes(String(body.method)) ? String(body.method) : ''
  const accountName = str(body.accountName, 60)
  const accountNumber = str(body.accountNumber, 15)
  const confirmAccountNumber = str(body.confirmAccountNumber, 15)
  const idempotencyKey = str(body.idempotencyKey, 60)

  if (!idempotencyKey) return fail('Kunci idempotensi diperlukan.')

  const rules = await getWalletRules()

  if (!method) return fail('Pilih metode pencairan.')
  const enabled = { DANA: rules.enableDANA, OVO: rules.enableOVO, GOPAY: rules.enableGoPay }[method]
  if (!enabled) return fail('Metode pencairan ini sedang dinonaktifkan admin.')
  if (!accountName || accountName.length < 3) return fail('Nama pemilik dompet wajib diisi.')
  if (!isPhone(accountNumber)) return fail('Nomor HP dompet digital tidak valid (9-15 digit).')
  if (confirmAccountNumber !== accountNumber) return fail('Konfirmasi nomor dompet tidak sama.')

  const fee = rules.fees[method] ?? 0
  const receive = amount - fee
  if (amount < rules.minWithdrawal) {
    return fail(`Minimal penarikan ${rupiah(rules.minWithdrawal)}.`)
  }

  // Batas jumlah pengajuan aktif (anti spam)
  const activeCount = await db.withdrawalRequest.count({
    where: { userId: session.sub, status: { in: ['PENDING', 'REVIEWING', 'APPROVED', 'PROCESSING'] } },
  })
  if (activeCount >= rules.maxPendingWithdrawals) {
    await db.fraudEvent.create({
      data: { userId: session.sub, type: 'WITHDRAW_SPAM', severity: 'MEDIUM', detail: `Pengajuan ke-${activeCount + 1} saat masih ada ${activeCount} pengajuan aktif (IP ${ip})` },
    })
    return fail(`Maksimal ${rules.maxPendingWithdrawals} pengajuan aktif. Tunggu pengajuan sebelumnya selesai.`)
  }

  const automaticConfigured = Boolean(process.env.DISBURSE_API_KEY && process.env.DISBURSE_API_URL)
  if (rules.payoutMode === 'automatic' && !automaticConfigured) {
    return fail(
      'Pencairan otomatis belum tersedia: penyedia pembayaran belum terhubung. Admin dapat memproses secara manual atau menghubungkan penyedia disbursement.',
      503
    )
  }

  try {
    const wd = await db.$transaction(async (tx) => {
      const wallet = await tx.wallet.findUnique({ where: { userId: session.sub } })
      if (!wallet || wallet.available < amount) throw new Error('Saldo hadiah tidak mencukupi.')

      // Pindahkan dana secara atomik: available -> processing
      await tx.wallet.update({
        where: { userId: session.sub },
        data: {
          available: { decrement: amount },
          processing: { increment: amount },
        },
      })

      return tx.withdrawalRequest.create({
        data: {
          userId: session.sub,
          amount,
          fee,
          method,
          accountName,
          accountNumber,
          mode: rules.payoutMode === 'automatic' ? 'AUTOMATIC' : 'MANUAL',
          status: 'PENDING',
          idempotencyKey,
          adminNote:
            rules.payoutMode === 'automatic'
              ? 'Mode otomatis aktif - menunggu pemrosesan penyedia pembayaran.'
              : 'Menunggu peninjauan admin.',
        },
      })
    })

    await db.notification.create({
      data: {
        userId: session.sub,
        title: 'Pengajuan Pencairan Diterima',
        body: `Permintaan ${rupiah(receive)} ke ${method} (${accountNumber}) sedang diproses. Nomor referensi: ${wd.id.slice(-8).toUpperCase()}`,
        kind: 'INFO',
      },
    })

    const budget = await getPrizeBudget()
    return ok({
      success: true,
      withdrawal: wd,
      receive,
      budgetNotice: budget < amount ? 'Anggaran hadiah saat ini lebih kecil dari pengajuan; pemrosesan menunggu ketersediaan dana.' : null,
      processingTime: rules.processingTime[method] ?? '1x24 jam',
    })
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'Gagal membuat pengajuan.'
    return fail(msg)
  }
}
