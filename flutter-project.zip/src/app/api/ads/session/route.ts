import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'
import { ok, fail } from '@/lib/api-utils'
import { getWalletRules, getSetting } from '@/lib/settings'
import { startOfToday } from '@/lib/api-utils'

/**
 * Membuat sesi iklan berhadiah (REWARDED) sebelum SDK iklan dijalankan.
 * Id event akan diverifikasi melalui SSV callback dari jaringan iklan di /api/ads/reward.
 * Hanya aktif bila jaringan iklan sudah dikonfigurasi.
 */
export async function POST(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)

  const configured = (await getSetting('adNetworkConfigured', 'false')) === 'true'
  if (!configured) return fail('Iklan berhadiah belum tersedia: jaringan iklan belum terhubung.', 503)

  const rules = await getWalletRules()
  const watchedToday = await db.adRewardEvent.count({
    where: { userId: session.sub, status: 'REWARDED', createdAt: { gte: startOfToday() } },
  })
  if (watchedToday >= rules.dailyAdLimit) {
    return fail(`Batas harian ${rules.dailyAdLimit} iklan sudah tercapai. Kembali lagi besok.`, 429)
  }

  const event = await db.adRewardEvent.create({
    data: {
      userId: session.sub,
      network: await getSetting('adNetworkName', 'unknown'),
      adEventId: crypto.randomUUID(),
      status: 'PENDING',
    },
  })

  return ok({
    adEventId: event.adEventId,
    rewardPoints: rules.adRewardPoints,
    note: 'Poin hanya diberikan setelah callback SSV yang valid diterima server.',
  })
}
