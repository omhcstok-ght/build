import { createPublicKey, verify as nodeVerify } from 'crypto'
import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail } from '@/lib/api-utils'
import { grantAdReward } from '@/lib/ads'
import { getSettingBool } from '@/lib/settings'

/**
 * SERVER-SIDE VERIFICATION (SSV) callback resmi Google AdMob - Rewarded Ads.
 *
 * Cara kerja (dokumentasi AdMob SSV):
 *  1. Klien memutar iklan rewarded; sebelum memutar, klien memanggil
 *     setUserId(<id pengguna kita>) dan setCustomData([<adEventId>]).
 *  2. Setelah tontonan selesai, server Google memanggil URL ini dengan
 *     query parameter (user_id, custom_data, ad_event_id, reward_amount,
 *     reward_item, timestamp, key_id, signature).
 *  3. Signature = ECDSA-SHA256 atas query string (tanpa signature & key_id),
 *     ditandatangani kunci privat Google; kami verifikasi dengan kunci
 *     publik dari https://www.gstatic.com/admob/reward/keys.json (cache 24 jam).
 *  4. Callback gagal dari AdMob membawa parameter error_code -> dicatat REJECTED.
 *
 * URL callback yang dipasang pada AdMob console:
 *   https://<domain-anda>/api/ads/ssv/admob
 *
 * Poin HANYA diberikan di sini setelah signature terverifikasi. Tidak ada
 * jalur lain. Idempoten per adEventId (lihat lib/ads.ts).
 */

const KEYS_TTL_MS = 24 * 60 * 60 * 1000
/**
 * Server kunci publik AdMob sesuai dokumentasi SSV (format JSON: key_id + pem EC).
 * Dapat dioverride via env ADMOB_KEY_SERVER_URL bila Google mengubah alamat.
 * Cek ulang di https://developers.google.com/admob/android/ssv saat go-live.
 */
const KEYS_URL = process.env.ADMOB_KEY_SERVER_URL || 'https://www.gstatic.com/admob/reward/keys.json'

let keysCache: { keys: Map<string, string>; fetchedAt: number } | null = null

async function fetchAdmobKeys(): Promise<Map<string, string>> {
  const res = await fetch(KEYS_URL, { cache: 'no-store' })
  if (!res.ok) throw new Error(`Gagal mengambil kunci publik AdMob (HTTP ${res.status})`)
  const data = (await res.json()) as { keys?: { key_id?: number | string; pem?: string }[] }
  const map = new Map<string, string>()
  for (const k of data.keys ?? []) {
    if (k.key_id !== undefined && k.pem) map.set(String(k.key_id), k.pem)
  }
  if (map.size === 0) throw new Error('Daftar kunci publik AdMob kosong.')
  keysCache = { keys: map, fetchedAt: Date.now() }
  return map
}

async function getAdmobKey(keyId: string): Promise<string | null> {
  if (!keysCache || Date.now() - keysCache.fetchedAt > KEYS_TTL_MS) {
    await fetchAdmobKeys()
  }
  return keysCache?.keys.get(keyId) ?? null
}

export async function GET(req: NextRequest) {
  // Harus aktif dari admin (berarti admin sudah memasang unit iklan resmi).
  const configured = await getSettingBool('adNetworkConfigured', false)
  if (!configured) {
    return fail('SSV AdMob belum diaktifkan oleh admin.', 503)
  }

  const url = new URL(req.url)
  const q = url.searchParams

  // Callback kegagalan dari AdMob (mis. pengguna menutup iklan sebelum selesai).
  const errorCode = q.get('error_code')
  if (errorCode) {
    const adEventId = (q.get('custom_data') ?? '').split(',')[0] || q.get('ad_event_id') || ''
    if (adEventId) {
      const event = await db.adRewardEvent.findUnique({ where: { adEventId } })
      if (event && event.status === 'PENDING') {
        await db.adRewardEvent.update({
          where: { adEventId },
          data: { status: 'REJECTED', meta: JSON.stringify({ reason: `AdMob error_code ${errorCode}` }) },
        })
      }
    }
    // Balas 2xx agar AdMob tidak mengulang callback gagal.
    return ok({ success: true, handled: 'error_callback', errorCode })
  }

  const signature = q.get('signature') ?? ''
  const keyId = q.get('key_id') ?? ''
  if (!signature || !keyId) return fail('Parameter signature/key_id tidak lengkap.', 400)

  // Susun pesan: seluruh query parameter sesuai urutan diterima,
  // KECUALI signature dan key_id (spesifikasi AdMob SSV).
  const parts: string[] = []
  q.forEach((value, key) => {
    if (key === 'signature' || key === 'key_id') return
    parts.push(`${key}=${value}`)
  })
  const message = parts.join('&')

  // Verifikasi ECDSA-SHA256 dengan kunci publik Google.
  let pem = await getAdmobKey(keyId)
  if (!pem) {
    // Kunci mungkin dirotasi: ambil daftar terbaru sekali lagi.
    try {
      await fetchAdmobKeys()
      pem = keysCache?.keys.get(keyId) ?? null
    } catch {
      return fail('Gagal mengambil kunci publik AdMob.', 503)
    }
    if (!pem) return fail('key_id tidak dikenal.', 401)
  }

  let valid = false
  try {
    const publicKey = createPublicKey(pem)
    valid = nodeVerify('sha256', Buffer.from(message, 'utf8'), publicKey, Buffer.from(signature, 'base64url'))
  } catch {
    valid = false
  }

  // Identitas pengguna & sesi iklan.
  const userId = (q.get('user_id') ?? '').trim()
  const adEventId = (q.get('custom_data') ?? '').split(',')[0].trim() || q.get('ad_event_id') || ''

  if (!userId || !adEventId) {
    return fail('user_id/custom_data tidak ada - pastikan klien memanggil setUserId dan setCustomData.', 400)
  }

  // Cocokkan dengan sesi resmi yang dibuat /api/ads/session.
  const sessionEvent = await db.adRewardEvent.findUnique({ where: { adEventId } })
  if (sessionEvent && sessionEvent.userId !== userId) {
    // user_id tidak cocok dengan sesi: tolak sebagai kejanggalan.
    return grantAdReward({
      userId,
      adEventId,
      network: 'ADMOB',
      signatureValid: false,
      note: 'user_id pada callback tidak cocok dengan sesi iklan',
    })
  }

  const result = await grantAdReward({
    userId,
    adEventId,
    network: 'ADMOB',
    signatureValid: valid,
    note: valid ? undefined : 'signature SSV AdMob tidak valid',
  })

  if (!result.ok) return fail(result.message, result.status)
  return ok({ success: true, rewarded: result.rewarded, alreadyRewarded: result.alreadyRewarded })
}
