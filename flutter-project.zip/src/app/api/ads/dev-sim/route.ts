import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'
import { ok, fail, startOfToday } from '@/lib/api-utils'
import { getWalletRules, getSetting } from '@/lib/settings'
import { creditPoints } from '@/lib/points'

/**
 * SIMULASI REWARD - HANYA MODE PENGEMBANGAN.
 * - Tidak berjalan di produksi (NODE_ENV=production menolak).
 * - Harus diizinkan lewat setting allowDevSim.
 * - Transaksi diberi label DEV_SIM agar dapat diaudit dan dihapus saat uji selesai.
 * Tujuannya menguji alur reward end-to-end tanpa menipu sistem produksi.
 */
export async function POST(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)

  if (process.env.NODE_ENV === 'production') {
    return fail('Simulasi dinonaktifkan pada mode produksi.', 403)
  }
  const allowed = (await getSetting('allowDevSim', 'true')) === 'true'
  if (!allowed) return fail('Simulasi reward dimatikan oleh admin.', 403)

  const rules = await getWalletRules()
  const watchedToday = await db.adRewardEvent.count({
    where: { userId: session.sub, status: 'REWARDED', createdAt: { gte: startOfToday() } },
  })
  if (watchedToday >= rules.dailyAdLimit) {
    return fail(`Batas harian ${rules.dailyAdLimit} iklan sudah tercapai.`, 429)
  }

  const points = rules.adRewardPoints
  await db.$transaction(async (tx) => {
    const event = await tx.adRewardEvent.create({
      data: {
        userId: session.sub,
        network: 'DEV_SIM',
        adEventId: crypto.randomUUID(),
        status: 'REWARDED',
        signatureValid: true,
        pointsAwarded: points,
        meta: JSON.stringify({ note: 'Reward simulasi mode pengembangan' }),
      },
    })
    await creditPoints(tx, {
      userId: session.sub,
      type: 'EARN_AD',
      bucket: 'AVAILABLE',
      amount: points,
      meta: { adEventId: event.adEventId, network: 'DEV_SIM', devSim: true },
    })
  })

  return ok({ success: true, rewarded: points, devSim: true })
}
