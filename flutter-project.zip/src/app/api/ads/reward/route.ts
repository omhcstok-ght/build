import { NextRequest } from 'next/server'
import { createHmac, timingSafeEqual } from 'crypto'
import { ok, fail, readJson, str } from '@/lib/api-utils'
import { grantAdReward } from '@/lib/ads'

/**
 * SERVER-SIDE VERIFICATION CALLBACK (server-to-server) untuk jaringan iklan
 * dengan verifikasi kustom (shared secret HMAC).
 * Untuk Google AdMob gunakan endpoint SSV resmi: /api/ads/ssv/admob.
 *
 * Autentikasi callback:
 *   Header: x-ad-signature
 *   Signature = HMAC_SHA256(AD_CALLBACK_SECRET, `${adEventId}.${userId}.${timestamp}`)
 *
 * Poin hanya diberikan di sini - TIDAK PERNAH dari tombol klien.
 * Idempoten: satu adEventId hanya bisa direward satu kali (unique constraint).
 */
export async function POST(req: NextRequest) {
  const secret = process.env.AD_CALLBACK_SECRET
  if (!secret) {
    return fail('Verifikasi reward belum aktif: AD_CALLBACK_SECRET belum diatur pada environment.', 503)
  }

  const body = await readJson(req)
  const adEventId = str(body.adEventId, 80)
  const userId = str(body.userId, 40)
  const timestamp = str(body.timestamp, 30)
  const signature = req.headers.get('x-ad-signature') || ''

  if (!adEventId || !userId || !timestamp) return fail('Parameter callback tidak lengkap.')

  const expected = createHmac('sha256', secret).update(`${adEventId}.${userId}.${timestamp}`).digest('hex')
  const a = Buffer.from(expected)
  const b = Buffer.from(signature)
  const valid = a.length === b.length && timingSafeEqual(a, b)

  const result = await grantAdReward({
    userId,
    adEventId,
    network: 'ssv-callback',
    signatureValid: valid,
    note: valid ? undefined : 'signature tidak valid',
  })

  if (!result.ok) return fail(result.message, result.status)
  return ok({ success: true, rewarded: result.rewarded, alreadyRewarded: result.alreadyRewarded })
}
