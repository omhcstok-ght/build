import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'
import { ok, fail } from '@/lib/api-utils'
import { getWalletRules, getSetting } from '@/lib/settings'
import { startOfToday } from '@/lib/api-utils'

/**
 * Status sistem Watch & Earn.
 * Jujur: bila jaringan iklan belum dikonfigurasi, status = false dan reward ditutup.
 * Tidak ada pendapatan iklan palsu.
 * Dua mode integrasi resmi:
 *  - ADMOB : SSV resmi Google (signature ECDSA kunci publik) via /api/ads/ssv/admob
 *  - CUSTOM: callback server-to-server dengan HMAC secret (AD_CALLBACK_SECRET)
 */
export async function GET(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)

  const rules = await getWalletRules()
  const configuredSetting = await getSetting('adNetworkConfigured', 'false')
  const network = await getSetting('adNetworkName', '')
  const adUnitId = await getSetting('adUnitId', '')
  const networkType = (await getSetting('adNetworkType', 'CUSTOM')) === 'ADMOB' ? 'ADMOB' : 'CUSTOM'
  const callbackSecretSet = Boolean(process.env.AD_CALLBACK_SECRET)

  const configured = configuredSetting === 'true' && (networkType === 'ADMOB' || callbackSecretSet)

  const watchedToday = await db.adRewardEvent.count({
    where: { userId: session.sub, status: 'REWARDED', createdAt: { gte: startOfToday() } },
  })

  return ok({
    configured,
    networkType,
    network: configured ? network : '',
    adUnitIdMasked: configured && adUnitId ? adUnitId.slice(0, 4) + '****' : '',
    ssvCallbackPath: networkType === 'ADMOB' ? '/api/ads/ssv/admob' : '/api/ads/reward',
    callbackSecretSet,
    dailyLimit: rules.dailyAdLimit,
    rewardPoints: rules.adRewardPoints,
    watchedToday,
    remaining: Math.max(0, rules.dailyAdLimit - watchedToday),
    allowDevSim: process.env.NODE_ENV !== 'production' && (await getSetting('allowDevSim', 'true')) === 'true',
    requirements:
      networkType === 'ADMOB'
        ? [
            'Daftarkan aplikasi pada akun Google AdMob dan menunggu persetujuan.',
            'Buat Ad Unit berformat Rewarded pada AdMob console.',
            'Pasang SDK AdMob pada klien aplikasi (web/PWA: GMA SDK via WebView/TPA).',
            'Sebelum memutar iklan, klien memanggil setUserId(id akun) dan setCustomData([adEventId] dari /api/ads/session).',
            'Pasang URL SSV callback pada AdMob console: https://<domain>/api/ads/ssv/admob',
            'Aktifkan iklan pada Admin Panel > Iklan setelah unit siap.',
          ]
        : [
            'Akun penerbit pada jaringan iklan (mis. Unity Ads/IronSource) dengan format Rewarded Ads.',
            'Jaringan iklan menyetujui model reward untuk aplikasi web.',
            'Server-side verification (SSV) callback secret diatur pada environment AD_CALLBACK_SECRET.',
            'Admin mengaktifkan konfigurasi pada Admin Panel > Iklan setelah pemasangan SDK.',
          ],
  })
}
