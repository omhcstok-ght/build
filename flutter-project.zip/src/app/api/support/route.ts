import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser, clientIp } from '@/lib/auth'
import { ok, fail, readJson, str } from '@/lib/api-utils'
import { rateLimit } from '@/lib/rate-limit'

/** Pusat laporan masalah: pesan dikirim ke antrean admin. */
export async function POST(req: NextRequest) {
  const ip = clientIp(req)
  if (!rateLimit(`support:${ip}`, 5, 300_000)) return fail('Terlalu banyak laporan. Coba lagi nanti.', 429)

  const session = await getSessionUser(req)
  const body = await readJson(req)
  const name = str(body.name, 60) || session?.name || 'Pengunjung'
  const email = str(body.email, 120)
  const category = ['LAPORAN', 'SARAN', 'RESET_PASSWORD', 'LAINNYA'].includes(String(body.category))
    ? String(body.category)
    : 'LAINNYA'
  const subject = str(body.subject, 100)
  const message = str(body.message, 2000)

  if (!subject || subject.length < 4) return fail('Judul laporan minimal 4 karakter.')
  if (!message || message.length < 10) return fail('Isi laporan minimal 10 karakter.')

  await db.supportMessage.create({
    data: {
      userId: session?.sub ?? null,
      name,
      email: email || null,
      category,
      subject,
      message,
    },
  })

  return ok({
    success: true,
    message: 'Laporan terkirim. Tim admin akan meninjau dan menghubungimu bila perlu.',
  })
}
