import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'
import { ok, fail, readJson } from '@/lib/api-utils'

export async function GET(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)

  const user = await db.user.findUnique({ where: { id: session.sub } })
  if (!user) return fail('Pengguna tidak ditemukan.', 404)

  const items = await db.notification.findMany({
    where: { OR: [{ userId: user.id }, { userId: null }] },
    orderBy: { createdAt: 'desc' },
    take: 30,
  })

  const unread = user.lastReadNotifications
    ? items.filter((n) => n.createdAt > user.lastReadNotifications!).length
    : items.length

  return ok({
    notifications: items.map((n) => ({
      id: n.id,
      title: n.title,
      body: n.body,
      kind: n.kind,
      broadcast: n.userId === null,
      createdAt: n.createdAt,
      unread: unread > 0 && n.createdAt > (user.lastReadNotifications ?? new Date(0)),
    })),
    unreadCount: unread,
  })
}

/** Tandai semua notifikasi dibaca. */
export async function POST(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)
  await readJson(req)
  await db.user.update({
    where: { id: session.sub },
    data: { lastReadNotifications: new Date() },
  })
  return ok({ success: true })
}
