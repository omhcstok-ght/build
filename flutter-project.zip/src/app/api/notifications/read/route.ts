import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'
import { ok } from '@/lib/api-utils'

export async function POST(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return ok({ success: false })
  await db.user.update({
    where: { id: session.sub },
    data: { lastReadNotifications: new Date() },
  })
  return ok({ success: true })
}
