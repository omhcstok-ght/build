import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'
import { ok, fail, readJson, str, todayKey } from '@/lib/api-utils'
import { getQuizRules } from '@/lib/settings'
import { creditPoints, releaseSessionPendingPoints } from '@/lib/points'

/**
 * Selesaikan sesi: poin PENDING pada sesi dirilis menjadi AVAILABLE,
 * beri bonus penyelesaian (dan bonus sempurna), perbarui misi harian.
 */
export async function POST(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)

  const body = await readJson(req)
  const sessionId = str(body.sessionId, 40)

  const s = await db.quizSession.findUnique({ where: { id: sessionId } })
  if (!s || s.userId !== session.sub) return fail('Sesi tidak ditemukan.', 404)

  if (s.status === 'COMPLETED') {
    // Idempoten: kembalikan ringkasan yang sama
    return ok({
      alreadyFinished: true,
      correctCount: s.correctCount,
      total: s.totalQuestions,
      pointsEarned: s.pointsEarned,
    })
  }
  if (s.status !== 'ACTIVE') return fail('Sesi tidak valid.')

  const rules = await getQuizRules()
  const allAnswered = s.answeredCount >= s.totalQuestions
  const isPerfect = allAnswered && s.correctCount === s.totalQuestions

  const summary = await db.$transaction(async (tx) => {
    // 1. Rilis poin pending milik sesi
    const released = await releaseSessionPendingPoints(tx, s.userId, s.id)

    let bonus = 0
    if (allAnswered) {
      bonus += rules.completionBonus
      if (isPerfect) bonus += rules.perfectBonus
      await creditPoints(tx, {
        userId: s.userId,
        type: 'EARN_COMPLETION',
        bucket: 'AVAILABLE',
        amount: bonus,
        sessionId: s.id,
        meta: { note: isPerfect ? 'Bonus penyelesaian + sempurna' : 'Bonus penyelesaian level' },
      })
    }

    await tx.quizSession.update({
      where: { id: s.id },
      data: {
        status: 'COMPLETED',
        finishedAt: new Date(),
        pointsEarned: { increment: bonus },
      },
    })

    // 2. Perbarui misi harian
    const date = todayKey()
    const defs: string[] = ['PLAY3', 'CORRECT10']
    for (const code of defs) {
      await tx.missionProgress.upsert({
        where: { userId_code_date: { userId: s.userId, code, date } },
        update: {},
        create: { userId: s.userId, code, date, progress: 0 },
      })
    }
    await tx.missionProgress.update({
      where: { userId_code_date: { userId: s.userId, code: 'PLAY3', date } },
      data: { progress: { increment: 1 } },
    })
    await tx.missionProgress.update({
      where: { userId_code_date: { userId: s.userId, code: 'CORRECT10', date } },
      data: { progress: { increment: s.correctCount } },
    })
    if (isPerfect) {
      await tx.missionProgress.upsert({
        where: { userId_code_date: { userId: s.userId, code: 'PERFECT1', date } },
        update: { progress: { increment: 1 } },
        create: { userId: s.userId, code: 'PERFECT1', date, progress: 1 },
      })
    }

    return { released, bonus, isPerfect }
  })

  const finalSession = await db.quizSession.findUnique({ where: { id: s.id } })

  return ok({
    correctCount: finalSession?.correctCount ?? s.correctCount,
    total: s.totalQuestions,
    pointsFromAnswers: summary.released,
    completionBonus: summary.bonus,
    isPerfect: summary.isPerfect,
    pointsEarned: (finalSession?.pointsEarned ?? 0),
  })
}
