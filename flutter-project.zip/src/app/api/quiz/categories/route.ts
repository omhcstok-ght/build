import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'
import { ok } from '@/lib/api-utils'

export async function GET(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return ok({ categories: [] })

  const categories = await db.quizCategory.findMany({
    where: { isActive: true },
    orderBy: { sortOrder: 'asc' },
    include: {
      _count: { select: { questions: { where: { isActive: true } } } },
    },
  })

  // Riwayat terbaik per kategori untuk user
  const best = await db.quizSession.groupBy({
    by: ['categoryId'],
    where: { userId: session.sub, status: 'COMPLETED' },
    _max: { correctCount: true },
    _count: { _all: true },
  })

  return ok({
    categories: categories.map((c) => {
      const b = best.find((x) => x.categoryId === c.id)
      return {
        id: c.id,
        name: c.name,
        slug: c.slug,
        icon: c.icon,
        gradient: c.gradient,
        description: c.description,
        questionCount: c._count.questions,
        playedCount: b?._count._all ?? 0,
        bestCorrect: b?._max.correctCount ?? null,
      }
    }),
  })
}
