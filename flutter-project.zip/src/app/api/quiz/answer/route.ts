import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'
import { ok, fail, readJson, str, int } from '@/lib/api-utils'
import { rateLimit } from '@/lib/rate-limit'
import { getQuizRules } from '@/lib/settings'
import { creditPoints } from '@/lib/points'

/**
 * Jawab soal: SEMUA validasi terjadi di server.
 * - Urutan soal divalidasi (tidak bisa mengulang/melompat).
 * - Waktu jawab divalidasi (jawab terlalu cepat = dicurigai bot, poin 0 + flag).
 * - Kunci jawaban tidak pernah dikirim ke klien.
 */
export async function POST(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)

  if (!rateLimit(`quiz-answer:${session.sub}`, 40, 60_000)) {
    return fail('Terlalu cepat mengirim jawaban.', 429)
  }

  const body = await readJson(req)
  const sessionId = str(body.sessionId, 40)
  const questionId = str(body.questionId, 40)
  const answerIndex = int(body.answerIndex, -1) // -1 = timeout
  const timeMs = int(body.timeMs, 0)

  const s = await db.quizSession.findUnique({ where: { id: sessionId } })
  if (!s || s.userId !== session.sub) return fail('Sesi tidak ditemukan.', 404)
  if (s.status !== 'ACTIVE') return fail('Sesi sudah selesai.')

  const ids = JSON.parse(s.questionIdsJson) as string[]
  const order = s.answeredCount
  if (order >= ids.length) return fail('Sesi sudah melebihi jumlah soal.')
  const expectedId = ids[order]
  if (expectedId !== questionId) return fail('Urutan soal tidak valid.', 400)

  const question = await db.question.findUnique({ where: { id: questionId } })
  if (!question) return fail('Soal tidak ditemukan.', 404)

  const rules = await getQuizRules()

  // Validasi waktu: lebih dari batas + grace dianggap timeout
  const timeLimitMs = rules.timeSeconds * 1000 + 3000
  const timedOut = timeMs > timeLimitMs
  // Anti-bot: jawaban benar di bawah ambang baca manusia
  const suspicious = timeMs > 0 && timeMs < rules.antiBotMs

  const isCorrect = !timedOut && answerIndex === question.correctIndex
  const flagged = suspicious && isCorrect
  let points = 0
  let streakHit = false

  if (isCorrect && !flagged) {
    points =
      question.difficulty === 'HARD'
        ? rules.pointsHard
        : question.difficulty === 'MEDIUM'
          ? rules.pointsMedium
          : rules.pointsEasy
  }

  const newStreak = isCorrect && !flagged ? s.currentStreak + 1 : 0
  if (newStreak > 0 && newStreak % rules.streakEvery === 0) {
    streakHit = true
    points += rules.streakBonus
  }

  const nextIndex = order + 1
  const hasNext = nextIndex < ids.length
  let nextQuestion: { id: string; text: string; imageUrl: string | null; options: string[]; difficulty: string } | null = null

  await db.$transaction(async (tx) => {
    await tx.quizAnswer.create({
      data: {
        sessionId: s.id,
        questionId,
        order,
        answerIndex: timedOut ? null : answerIndex,
        isCorrect: isCorrect && !flagged,
        pointsAwarded: points,
        timeMs: timeMs,
        flagged,
      },
    })
    if (points > 0) {
      await creditPoints(tx, {
        userId: s.userId,
        type: streakHit ? 'EARN_STREAK' : 'EARN_QUIZ',
        bucket: 'PENDING',
        amount: points,
        sessionId: s.id,
        meta: streakHit ? { note: `Bonus streak ${newStreak}x benar` } : undefined,
      })
    }
    if (flagged) {
      await tx.fraudEvent.create({
        data: {
          userId: s.userId,
          type: 'FAST_ANSWER',
          severity: 'MEDIUM',
          detail: `Jawaban benar hanya dalam ${timeMs} ms pada soal ${questionId}`,
        },
      })
    }
    await tx.quizSession.update({
      where: { id: s.id },
      data: {
        answeredCount: nextIndex,
        correctCount: isCorrect && !flagged ? { increment: 1 } : { increment: 0 },
        currentStreak: newStreak,
        bestStreak: Math.max(s.bestStreak, newStreak),
        pointsEarned: { increment: points },
      },
    })
    if (hasNext) {
      const nq = await tx.question.findUnique({ where: { id: ids[nextIndex] } })
      if (nq) {
        nextQuestion = {
          id: nq.id,
          text: nq.text,
          imageUrl: nq.imageUrl,
          options: JSON.parse(nq.optionsJson) as string[],
          difficulty: nq.difficulty,
        }
      }
    }
  })

  return ok({
    isCorrect: isCorrect && !flagged,
    flagged,
    correctIndex: question.correctIndex,
    explanation: question.explanation,
    pointsAwarded: points,
    streak: newStreak,
    streakHit,
    hasNext,
    nextQuestion,
    index: nextIndex,
  })
}
