import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'
import { ok, fail, readJson, str, int } from '@/lib/api-utils'
import { rateLimit } from '@/lib/rate-limit'
import { getQuizRules } from '@/lib/settings'

/**
 * Mulai sesi kuis. Server memilih & mengurutkan soal (disimpan di server),
 * dan HANYA mengirim soal pertama tanpa kunci jawaban.
 */
export async function POST(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)

  const user = await db.user.findUnique({ where: { id: session.sub } })
  if (!user || user.isBlocked) return fail('Akun tidak dapat bermain.', 403)

  if (!rateLimit(`quiz-start:${user.id}`, 6, 60_000)) {
    return fail('Terlalu sering memulai kuis. Tunggu sebentar.', 429)
  }

  const body = await readJson(req)
  const categoryId = str(body.categoryId, 40)
  const difficulty = ['MIXED', 'EASY', 'MEDIUM', 'HARD'].includes(String(body.difficulty))
    ? String(body.difficulty)
    : 'MIXED'

  const category = await db.quizCategory.findUnique({ where: { id: categoryId } })
  if (!category || !category.isActive) return fail('Kategori tidak tersedia.')

  const rules = await getQuizRules()

  // Akhiri sesi lama yang masih aktif (tidak mendapat poin)
  await db.quizSession.updateMany({
    where: { userId: user.id, status: 'ACTIVE' },
    data: { status: 'ABANDONED' },
  })

  const where: { categoryId: string; isActive: boolean; difficulty?: string } = {
    categoryId,
    isActive: true,
  }
  if (difficulty !== 'MIXED') where.difficulty = difficulty

  let pool = await db.question.findMany({ where, select: { id: true } })
  if (pool.length === 0 && difficulty !== 'MIXED') {
    // fallback ke campuran jika kategori kekurangan soal pada tingkat itu
    pool = await db.question.findMany({ where: { categoryId, isActive: true }, select: { id: true } })
  }
  if (pool.length === 0) return fail('Kategori ini belum memiliki soal. Hubungi admin.')

  // acak urutan
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[pool[i], pool[j]] = [pool[j], pool[i]]
  }
  const selected = pool.slice(0, Math.min(rules.questionsPerSession, pool.length))
  const questionIds = selected.map((q) => q.id)

  const created = await db.quizSession.create({
    data: {
      userId: user.id,
      categoryId,
      difficulty: pool === selected && difficulty !== 'MIXED' ? difficulty : difficulty,
      questionIdsJson: JSON.stringify(questionIds),
      totalQuestions: questionIds.length,
    },
  })

  // Ambil soal pertama
  const first = await db.question.findUnique({ where: { id: questionIds[0] } })
  if (!first) return fail('Soal tidak ditemukan.', 500)

  return ok({
    sessionId: created.id,
    total: questionIds.length,
    index: 0,
    timeSeconds: rules.timeSeconds,
    question: {
      id: first.id,
      text: first.text,
      imageUrl: first.imageUrl,
      options: JSON.parse(first.optionsJson) as string[],
      difficulty: first.difficulty,
    },
  })
}
