import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'
import { ok, fail, int } from '@/lib/api-utils'

export async function GET(req: NextRequest) {
  const session = await getSessionUser(req)
  if (!session) return fail('Harap masuk terlebih dahulu.', 401)

  const limit = Math.min(int(req.nextUrl.searchParams.get('limit'), 20), 50)

  const sessions = await db.quizSession.findMany({
    where: { userId: session.sub, status: { in: ['COMPLETED', 'ABANDONED'] } },
    orderBy: { startedAt: 'desc' },
    take: limit,
    include: { category: true },
  })

  const stats = await db.quizSession.aggregate({
    where: { userId: session.sub, status: 'COMPLETED' },
    _count: { _all: true },
    _sum: { correctCount: true, pointsEarned: true },
  })

  return ok({
    sessions: sessions.map((s) => ({
      id: s.id,
      category: s.category.name,
      icon: s.category.icon,
      difficulty: s.difficulty,
      status: s.status,
      correctCount: s.correctCount,
      total: s.totalQuestions,
      pointsEarned: s.pointsEarned,
      bestStreak: s.bestStreak,
      startedAt: s.startedAt,
    })),
    stats: {
      totalPlayed: stats._count._all ?? 0,
      totalCorrect: stats._sum.correctCount ?? 0,
      totalPoints: stats._sum.pointsEarned ?? 0,
    },
  })
}
