import { NextRequest } from 'next/server'
import { createHmac, timingSafeEqual } from 'crypto'
import { db } from '@/lib/db'
import { ok, fail } from '@/lib/api-utils'
import { addLedgerEntry } from '@/lib/finance'

/**
 * Webhook penyedia pembayaran/disbursement.
 * - Verifikasi signature HMAC (header x-webhook-signature = HMAC_SHA256(PAYMENT_WEBHOOK_SECRET, rawBody))
 * - Semua payload dicatat (PaymentWebhook) untuk audit, valid maupun tidak.
 * - Bila status pembayaran PAID: selesaikan pencairan mode otomatis secara idempoten.
 */
export async function POST(req: NextRequest) {
  const secret = process.env.PAYMENT_WEBHOOK_SECRET
  const raw = await req.text()

  const record = async (provider: string, valid: boolean, note: string, processed = false) => {
    await db.paymentWebhook.create({
      data: { provider, payload: raw.slice(0, 5000), signatureValid: valid, note, processed },
    })
  }

  if (!secret) {
    await record('unknown', false, 'PAYMENT_WEBHOOK_SECRET belum diatur')
    return fail('Webhook belum aktif: PAYMENT_WEBHOOK_SECRET belum diatur pada environment.', 503)
  }

  const signature = req.headers.get('x-webhook-signature') || ''
  const expected = createHmac('sha256', secret).update(raw).digest('hex')
  const a = Buffer.from(expected)
  const b = Buffer.from(signature)
  const valid = a.length === b.length && timingSafeEqual(a, b)
  if (!valid) {
    await record('unknown', false, 'Signature webhook tidak valid')
    return fail('Signature webhook tidak valid.', 401)
  }

  let payload: {
    provider?: string
    reference?: string
    withdrawalId?: string
    status?: string
    providerPaymentId?: string
  }
  try {
    payload = JSON.parse(raw)
  } catch {
    await record('unknown', true, 'Payload bukan JSON valid')
    return fail('Payload tidak valid.', 400)
  }

  const provider = payload.provider || 'payment-provider'
  if (!payload.reference || !payload.status) {
    await record(provider, true, 'Payload tidak memiliki reference/status')
    return fail('reference dan status wajib ada.', 400)
  }

  const payment = await db.paymentTransaction.findFirst({ where: { reference: payload.reference } })
  if (!payment) {
    await record(provider, true, `Referensi ${payload.reference} tidak ditemukan`)
    return fail('Referensi pembayaran tidak ditemukan.', 404)
  }

  await record(provider, true, `Status: ${payload.status}`, true)

  const withdrawalId = payment.withdrawalId
  if (!withdrawalId) return ok({ success: true, note: 'Tidak terkait pencairan.' })

  const wd = await db.withdrawalRequest.findUnique({ where: { id: withdrawalId } })
  if (!wd) return ok({ success: true, note: 'Pencairan tidak ditemukan.' })

  const status = payload.status.toUpperCase()

  if (status === 'PAID' && wd.status !== 'PAID') {
    await db.$transaction(async (tx) => {
      const wallet = await tx.wallet.findUnique({ where: { userId: wd.userId } })
      if (!wallet) throw new Error('Dompet tidak ditemukan')
      const proc = Math.max(0, wallet.processing - wd.amount)
      await tx.wallet.update({
        where: { userId: wd.userId },
        data: { processing: proc, totalPaid: { increment: wd.amount } },
      })
      await tx.paymentTransaction.update({
        where: { id: payment.id },
        data: { status: 'PAID', reference: payload.providerPaymentId || payment.reference },
      })
      await tx.withdrawalRequest.update({
        where: { id: wd.id },
        data: {
          status: 'PAID',
          reference: payload.providerPaymentId || payload.reference,
          processedAt: new Date(),
          adminNote: 'Dikonfirmasi otomatis via webhook penyedia pembayaran.',
        },
      })
      await addLedgerEntry(tx, {
        type: 'PRIZE_PAYOUT',
        amount: -wd.amount,
        refType: 'WITHDRAWAL',
        refId: wd.id,
        note: `Pembayaran hadiah via ${provider} (${payload.providerPaymentId || payload.reference})`,
        createdBy: 'webhook',
      })
      await tx.notification.create({
        data: {
          userId: wd.userId,
          title: 'Pencairan Berhasil',
          body: `Pencairan sebesar Rp${wd.amount.toLocaleString('id-ID')} telah dikirim ke ${wd.method} ${wd.accountNumber}.`,
          kind: 'SUCCESS',
        },
      })
    })
  } else if (status === 'FAILED' && ['PROCESSING', 'APPROVED'].includes(wd.status)) {
    await db.$transaction(async (tx) => {
      const wallet = await tx.wallet.findUnique({ where: { userId: wd.userId } })
      if (!wallet) throw new Error('Dompet tidak ditemukan')
      await tx.wallet.update({
        where: { userId: wd.userId },
        data: { processing: Math.max(0, wallet.processing - wd.amount), available: { increment: wd.amount } },
      })
      await tx.paymentTransaction.update({ where: { id: payment.id }, data: { status: 'FAILED' } })
      await tx.withdrawalRequest.update({
        where: { id: wd.id },
        data: { status: 'FAILED', adminNote: 'Gagal diproses penyedia; dana dikembalikan ke saldo.' },
      })
      await tx.notification.create({
        data: {
          userId: wd.userId,
          title: 'Pencairan Gagal',
          body: 'Penyedia pembayaran melaporkan kegagalan. Dana telah dikembalikan ke saldo hadiahmu.',
          kind: 'WARNING',
        },
      })
    })
  }

  return ok({ success: true })
}
