'use client'

/**
 * Klien API terpusat: selalu kirim kuki + token Authorization (fallback), parsing error backend.
 * Token disimpan di localStorage karena beberapa konteks pratinjau (iframe) memblokir kuki,
 * sehingga sesi tidak bisa hanya mengandalkan kuki.
 */

const USER_TOKEN_KEY = 'qe_user_token'
const ADMIN_TOKEN_KEY = 'qe_admin_token'

function safeGet(key: string): string | null {
  if (typeof window === 'undefined') return null
  try {
    return window.localStorage.getItem(key)
  } catch {
    return null
  }
}

function safeSet(key: string, value: string) {
  if (typeof window === 'undefined') return
  try {
    window.localStorage.setItem(key, value)
  } catch {
    /* penyimpanan tidak tersedia - kuki tetap menjadi jalur utama */
  }
}

function safeRemove(key: string) {
  if (typeof window === 'undefined') return
  try {
    window.localStorage.removeItem(key)
  } catch {
    /* abaikan */
  }
}

export function saveUserToken(t?: string | null) {
  if (t) safeSet(USER_TOKEN_KEY, t)
}

export function saveAdminToken(t?: string | null) {
  if (t) safeSet(ADMIN_TOKEN_KEY, t)
}

export function clearUserToken() {
  safeRemove(USER_TOKEN_KEY)
}

export function clearAdminToken() {
  safeRemove(ADMIN_TOKEN_KEY)
}

export async function api<T = unknown>(
  path: string,
  opts?: { method?: string; body?: unknown }
): Promise<T> {
  const isAdminPath = path.startsWith('/api/admin')
  const token = safeGet(isAdminPath ? ADMIN_TOKEN_KEY : USER_TOKEN_KEY)

  const headers: Record<string, string> = {}
  if (opts?.body !== undefined) headers['Content-Type'] = 'application/json'
  if (token) headers['Authorization'] = `Bearer ${token}`

  const res = await fetch(path, {
    method: opts?.method ?? 'GET',
    headers,
    body: opts?.body !== undefined ? JSON.stringify(opts.body) : undefined,
    credentials: 'include',
  })
  const text = await res.text()
  let json: Record<string, unknown> = {}
  try {
    json = text ? (JSON.parse(text) as Record<string, unknown>) : {}
  } catch {
    /* bukan JSON */
  }
  if (!res.ok) {
    // Token kedaluwarsa/tidak valid: bersihkan agar tidak dikirim berulang.
    if (res.status === 401) {
      if (isAdminPath) clearAdminToken()
      else clearUserToken()
    }
    const msg = (json.error as string) || `Kesalahan server (${res.status})`
    throw new Error(msg)
  }
  return json as T
}

export const rupiah = (n: number | undefined | null): string =>
  'Rp' + Math.round(n ?? 0).toLocaleString('id-ID')

export const fmtNum = (n: number | undefined | null): string =>
  (n ?? 0).toLocaleString('id-ID')

export const fmtDateTime = (d: string | Date | undefined | null): string => {
  if (!d) return '-'
  const date = typeof d === 'string' ? new Date(d) : d
  return date.toLocaleString('id-ID', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

export const fmtDate = (d: string | Date | undefined | null): string => {
  if (!d) return '-'
  const date = typeof d === 'string' ? new Date(d) : d
  return date.toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' })
}

export function uuid(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID()
  return `${Date.now()}-${Math.random().toString(36).slice(2)}`
}
