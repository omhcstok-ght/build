'use client'

import { create } from 'zustand'

export type ViewKey =
  | 'splash'
  | 'welcome'
  | 'login'
  | 'register'
  | 'forgot'
  | 'dashboard'
  | 'quiz'
  | 'quiz-play'
  | 'quiz-result'
  | 'watch'
  | 'missions'
  | 'rewards'
  | 'leaderboard'
  | 'history'
  | 'profile'
  | 'notifications'
  | 'info'
  | 'admin'

export interface SessionUser {
  id: string
  name: string
  username: string
  email: string
  avatar: string | null
  emailVerified?: boolean
  pointsPending?: number
  pointsAvailable?: number
  bonusStreak?: number
  wallet?: { available: number; processing: number; totalPaid: number }
}

interface AppState {
  booted: boolean
  user: SessionUser | null
  view: ViewKey
  viewParams: Record<string, unknown>
  authNotice: string | null
  setBooted: (v: boolean) => void
  setUser: (u: SessionUser | null) => void
  go: (view: ViewKey, params?: Record<string, unknown>) => void
  setAuthNotice: (e: string | null) => void
}

export const useApp = create<AppState>((set) => ({
  booted: false,
  user: null,
  view: 'splash',
  viewParams: {},
  authNotice: null,
  setBooted: (v) => set({ booted: v }),
  setUser: (u) => set({ user: u }),
  go: (view, params) => {
    set({ view, viewParams: params ?? {} })
    if (typeof window !== 'undefined') window.scrollTo({ top: 0 })
  },
  setAuthNotice: (e) => set({ authNotice: e }),
}))
