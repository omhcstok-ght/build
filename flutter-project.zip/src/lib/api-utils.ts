import { NextRequest, NextResponse } from 'next/server'

export function ok<T>(data: T, init?: number) {
  return NextResponse.json(data as object, { status: init ?? 200 })
}

export function fail(message: string, status = 400, extra?: Record<string, unknown>) {
  return NextResponse.json({ error: message, ...extra }, { status })
}

export async function readJson<T = Record<string, unknown>>(req: NextRequest): Promise<T> {
  try {
    return (await req.json()) as T
  } catch {
    return {} as T
  }
}

/** Validasi string sederhana. */
export function isEmail(s: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(s)
}

export function isUsername(s: string): boolean {
  return /^[a-zA-Z0-9_]{3,20}$/.test(s)
}

export function isPhone(s: string): boolean {
  return /^[0-9]{9,15}$/.test(s)
}

export function str(v: unknown, max = 500): string {
  return typeof v === 'string' ? v.trim().slice(0, max) : ''
}

export function int(v: unknown, fallback = 0): number {
  const n = typeof v === 'number' ? v : parseInt(String(v), 10)
  return Number.isFinite(n) ? n : fallback
}

export function todayKey(): string {
  const d = new Date()
  // gunakan waktu lokal server (Asia/Jakarta pada sandbox)
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

export function startOfWeek(): Date {
  const d = new Date()
  const day = d.getDay() // 0 = minggu
  const diff = (day + 6) % 7 // senin sebagai awal minggu
  d.setDate(d.getDate() - diff)
  d.setHours(0, 0, 0, 0)
  return d
}

export function startOfToday(): Date {
  const d = new Date()
  d.setHours(0, 0, 0, 0)
  return d
}

export function rupiah(n: number): string {
  return 'Rp' + n.toLocaleString('id-ID')
}
