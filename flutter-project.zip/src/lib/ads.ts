import { db } from '@/lib/db'
import { creditPoints } from '@/lib/points'
import { getWalletRules } from '@/lib/settings'
import { startOfToday, todayKey } from '@/lib/api-utils'

/**
 * Logika pemberian reward iklan bersama.
 * Dipakai oleh dua jalur verifikasi server-to-server:
 *  1. /api/ads/reward       -> callback kustom (HMAC shared secret)
 *  2. /api/ads/ssv/admob    -> AdMob SSV (signature ECDSA kunci publik Google)
 *
 * Prinsip: poin TIDAK PERNAH diberikan dari tombol klien; hanya dari callback
 * yang lolos verifikasi signature. Idempoten: satu adEventId = satu reward.
 */
export type GrantResult =
  | { ok: true; rewarded: number; alreadyRewarded?: boolean }
  | { ok: false; status: number; message: string }

export async function grantAdReward(o: {
  userId: string
  adEventId: string
  network: string
  signatureValid: boolean
  note?: string
}): Promise<GrantResult> {
  const rules = await getWalletRules()

  const event = await db.adRewardEvent.findUnique({ where: { adEventId: o.adEventId } })

  // Event tidak dikenal: callback bukan dari sesi resmi aplikasi.
  if (!event) {
    await db.adRewardEvent.create({
      data: {
        userId: o.userId || 'unknown',
        network: o.network,
        adEventId: o.adEventId,
        status: 'REJECTED',
        signatureValid: o.signatureValid,
        pointsAwarded: 0,
        meta: JSON.stringify({ reason: o.note ?? 'adEventId tidak ditemukan (bukan sesi resmi aplikasi)' }),
      },
    })
    return { ok: false, status: 404, message: 'adEventId tidak dikenal.' }
  }

  // Signature tidak valid: catat fraud dan tolak.
  if (!o.signatureValid) {
    await db.adRewardEvent.update({
      where: { adEventId: o.adEventId },
      data: {
        status: 'REJECTED',
        signatureValid: false,
        meta: JSON.stringify({ reason: o.note ?? 'signature tidak valid' }),
      },
    })
    await db.fraudEvent.create({
      data: {
        userId: event.userId,
        type: 'AD_INVALID',
        severity: 'HIGH',
        detail: `Callback signature tidak valid untuk adEventId ${o.adEventId}`,
      },
    })
    return { ok: false, status: 401, message: 'Signature callback tidak valid.' }
  }

  // Idempotensi: sudah pernah direward.
  if (event.status === 'REWARDED') {
    return { ok: true, rewarded: event.pointsAwarded, alreadyRewarded: true }
  }

  // Batas harian.
  const watchedToday = await db.adRewardEvent.count({
    where: { userId: event.userId, status: 'REWARDED', createdAt: { gte: startOfToday() } },
  })
  if (watchedToday >= rules.dailyAdLimit) {
    await db.adRewardEvent.update({
      where: { adEventId: o.adEventId },
      data: {
        status: 'REJECTED',
        signatureValid: true,
        meta: JSON.stringify({ reason: 'batas harian tercapai' }),
      },
    })
    return { ok: false, status: 429, message: `Batas harian ${rules.dailyAdLimit} iklan tercapai, reward ditolak.` }
  }

  await db.$transaction(async (tx) => {
    await tx.adRewardEvent.update({
      where: { adEventId: o.adEventId },
      data: { status: 'REWARDED', signatureValid: true, pointsAwarded: rules.adRewardPoints },
    })
    await creditPoints(tx, {
      userId: event.userId,
      type: 'EARN_AD',
      bucket: 'AVAILABLE',
      amount: rules.adRewardPoints,
      meta: { adEventId: o.adEventId, network: event.network },
    })
    await tx.missionProgress.upsert({
      where: { userId_code_date: { userId: event.userId, code: 'PLAY3', date: todayKey() } },
      update: {},
      create: { userId: event.userId, code: 'PLAY3', date: todayKey(), progress: 0 },
    })
  })

  return { ok: true, rewarded: rules.adRewardPoints }
}
