import { db } from './db'
import { Prisma } from '@prisma/client'

/**
 * Buku besar keuangan (FinancialLedger).
 * Mengelola ANGGARAN HADIAH perusahaan: modal awal + pendapatan iklan/sponsor - pembayaran hadiah.
 * Alokasi hadiah tidak boleh melebihi dana yang tersedia.
 */

export type LedgerType = 'CAPITAL_IN' | 'AD_REVENUE' | 'SPONSOR_REVENUE' | 'PRIZE_PAYOUT' | 'ADJUSTMENT'

/** Saldo anggaran hadiah saat ini = jumlah semua amount pada ledger. */
export async function getPrizeBudget(): Promise<number> {
  const agg = await db.financialLedger.aggregate({ _sum: { amount: true } })
  return agg._sum.amount ?? 0
}

/**
 * Catat entri ledger dengan saldo berjalan. Gunakan di dalam transaksi DB.
 * amount positif = dana masuk, negatif = dana keluar.
 */
export async function addLedgerEntry(
  tx: Prisma.TransactionClient,
  o: {
    type: LedgerType
    amount: number
    refType?: string
    refId?: string
    note?: string
    createdBy?: string
  }
) {
  // Kunci urutan entri agar balanceAfter akurat (SQLite serialisasi tulis).
  const last = await tx.financialLedger.findFirst({ orderBy: { createdAt: 'desc' } })
  const prev = last?.balanceAfter ?? 0
  const balanceAfter = prev + o.amount
  if (balanceAfter < 0) {
    throw new Error('ANGGARAN_TIDAK_CUKUP: dana hadiah yang tersedia tidak mencukupi')
  }
  return tx.financialLedger.create({
    data: {
      type: o.type,
      amount: o.amount,
      balanceAfter,
      refType: o.refType ?? null,
      refId: o.refId ?? null,
      note: o.note ?? null,
      createdBy: o.createdBy ?? null,
    },
  })
}

export interface RevenueSummary {
  capital: number
  adRevenue: number
  sponsorRevenue: number
  prizePayout: number
  adjustment: number
  budget: number
}

export async function getRevenueSummary(): Promise<RevenueSummary> {
  const grouped = await db.financialLedger.groupBy({ by: ['type'], _sum: { amount: true } })
  const get = (t: string) => grouped.find((g) => g.type === t)?._sum.amount ?? 0
  return {
    capital: get('CAPITAL_IN'),
    adRevenue: get('AD_REVENUE'),
    sponsorRevenue: get('SPONSOR_REVENUE'),
    prizePayout: Math.abs(get('PRIZE_PAYOUT')),
    adjustment: get('ADJUSTMENT'),
    budget: grouped.reduce((s, g) => s + (g._sum.amount ?? 0), 0),
  }
}
