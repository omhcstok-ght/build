import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { SignJWT, jwtVerify } from 'jose'

const SECRET = new TextEncoder().encode(
  process.env.AUTH_SECRET || 'qe_dev_secret_9f8e7d6c5b4a_change_in_production'
)

export const USER_COOKIE = 'qe_token'
export const ADMIN_COOKIE = 'qe_admin'

export interface SessionPayload {
  sub: string
  role: 'user' | 'admin'
  name?: string
  username?: string
}

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 10)
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash)
}

export async function signToken(payload: SessionPayload, days = 30): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(`${days}d`)
    .sign(SECRET)
}

export async function verifyToken(token: string): Promise<SessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, SECRET)
    return payload as unknown as SessionPayload
  } catch {
    return null
  }
}

function getCookie(req: NextRequest, name: string): string | null {
  return req.cookies.get(name)?.value ?? null
}

/**
 * Fallback sesi via header Authorization: Bearer.
 * Diperlukan karena beberapa konteks pratinjau (iframe lintas situs) memblokir kuki,
 * sehingga sesi berbasis kuki saja tidak dapat terbentuk.
 */
function getBearerToken(req: NextRequest): string | null {
  const header = req.headers.get('authorization')
  if (!header) return null
  const [scheme, token] = header.split(' ')
  if (!scheme || scheme.toLowerCase() !== 'bearer' || !token) return null
  return token.trim()
}

function extractToken(req: NextRequest, cookieName: string): string | null {
  return getBearerToken(req) ?? getCookie(req, cookieName)
}

export function setUserCookie(res: NextResponse, token: string) {
  res.cookies.set(USER_COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 60 * 60 * 24 * 30,
    path: '/',
  })
}

export function setAdminCookie(res: NextResponse, token: string) {
  res.cookies.set(ADMIN_COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 60 * 60 * 12,
    path: '/',
  })
}

export function clearAuthCookies(res: NextResponse) {
  res.cookies.set(USER_COOKIE, '', { httpOnly: true, maxAge: 0, path: '/' })
  res.cookies.set(ADMIN_COOKIE, '', { httpOnly: true, maxAge: 0, path: '/' })
}

/** Ambil payload user dari header Authorization atau kuki. null jika tidak valid. */
export async function getSessionUser(req: NextRequest): Promise<SessionPayload | null> {
  const token = extractToken(req, USER_COOKIE)
  if (!token) return null
  const payload = await verifyToken(token)
  if (!payload || payload.role !== 'user') return null
  return payload
}

/** Ambil payload admin dari header Authorization atau kuki khusus admin. */
export async function getSessionAdmin(req: NextRequest): Promise<SessionPayload | null> {
  const token = extractToken(req, ADMIN_COOKIE)
  if (!token) return null
  const payload = await verifyToken(token)
  if (!payload || payload.role !== 'admin') return null
  return payload
}

export function clientIp(req: NextRequest): string {
  return (
    req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
    req.headers.get('x-real-ip') ||
    'unknown'
  )
}
