import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSessionAdmin, signToken, setAdminCookie, verifyPassword, clientIp } from '@/lib/auth'
import { ok, fail, readJson, str, int, isEmail, isPhone } from '@/lib/api-utils'
import { rateLimit } from '@/lib/rate-limit'
import { NextResponse } from 'next/server'

export { db, ok, fail, readJson, str, int, isEmail, isPhone, rateLimit, clientIp, verifyPassword }

/** Guard: pastikan request berasal dari admin terautentikasi. */
export async function requireAdmin(req: NextRequest) {
  const session = await getSessionAdmin(req)
  if (!session) return null
  const admin = await db.adminUser.findUnique({ where: { id: session.sub } })
  if (!admin) return null
  return admin
}

/** Catat aksi admin ke audit log. */
export function audit(
  admin: { id: string; name: string; username: string },
  action: string,
  targetType?: string,
  targetId?: string,
  detail?: string
) {
  return db.adminAuditLog.create({
    data: {
      adminId: admin.id,
      adminName: admin.username,
      action,
      targetType: targetType ?? null,
      targetId: targetId ?? null,
      detail: detail ?? null,
    },
  })
}

export { signToken, setAdminCookie, NextResponse }
