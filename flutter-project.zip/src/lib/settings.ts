import { db } from './db'

/** Ambil nilai setting; kembali ke default bila tidak ada. */
export async function getSetting(key: string, fallback: string = ''): Promise<string> {
  const row = await db.appSetting.findUnique({ where: { key } })
  return row?.value ?? fallback
}

export async function getSettingInt(key: string, fallback: number): Promise<number> {
  const v = await getSetting(key)
  const n = parseInt(v, 10)
  return Number.isFinite(n) ? n : fallback
}

export async function getSettingBool(key: string, fallback: boolean = false): Promise<boolean> {
  const v = await getSetting(key)
  if (v === '') return fallback
  return v === 'true' || v === '1'
}

export async function getSettingJson<T>(key: string, fallback: T): Promise<T> {
  const v = await getSetting(key)
  try {
    return JSON.parse(v) as T
  } catch {
    return fallback
  }
}

export async function setSetting(key: string, value: string): Promise<void> {
  await db.appSetting.upsert({ where: { key }, update: { value }, create: { key, value } })
}

export interface QuizRules {
  pointsEasy: number
  pointsMedium: number
  pointsHard: number
  streakEvery: number
  streakBonus: number
  completionBonus: number
  perfectBonus: number
  questionsPerSession: number
  timeSeconds: number
  antiBotMs: number
}

export async function getQuizRules(): Promise<QuizRules> {
  const [e, m, h, se, sb, cb, pb, q, t, ab] = await Promise.all([
    getSettingInt('pointsPerCorrectEasy', 10),
    getSettingInt('pointsPerCorrectMedium', 15),
    getSettingInt('pointsPerCorrectHard', 20),
    getSettingInt('streakEvery', 3),
    getSettingInt('streakBonus', 20),
    getSettingInt('completionBonus', 50),
    getSettingInt('perfectBonus', 50),
    getSettingInt('quizQuestionsPerSession', 10),
    getSettingInt('quizTimeSeconds', 20),
    getSettingInt('answerAntiBotMs', 1000),
  ])
  return {
    pointsEasy: e, pointsMedium: m, pointsHard: h,
    streakEvery: se, streakBonus: sb,
    completionBonus: cb, perfectBonus: pb,
    questionsPerSession: q, timeSeconds: t, antiBotMs: ab,
  }
}

export interface WalletRules {
  conversionRate: number
  conversionOptions: number[]
  minConvertPoints: number
  minWithdrawal: number
  maxPendingWithdrawals: number
  payoutMode: 'manual' | 'automatic'
  enableDANA: boolean
  enableOVO: boolean
  enableGoPay: boolean
  fees: Record<string, number>
  processingTime: Record<string, string>
  luckyBonusPoints: number
  dailyAdLimit: number
  adRewardPoints: number
}

export async function getWalletRules(): Promise<WalletRules> {
  const [cr, co, mc, mw, mp, pm, d, o, g, f, pt, lb, dal, arp] = await Promise.all([
    getSettingInt('conversionRateRupiahPerPoint', 1),
    getSettingJson<number[]>('conversionOptionsJson', [1000, 5000, 10000, 25000]),
    getSettingInt('minConvertPoints', 1000),
    getSettingInt('minWithdrawal', 10000),
    getSettingInt('maxPendingWithdrawals', 3),
    getSetting('payoutMode', 'manual'),
    getSettingBool('enableDANA', true),
    getSettingBool('enableOVO', true),
    getSettingBool('enableGoPay', true),
    getSettingJson<Record<string, number>>('feesJson', { DANA: 0, OVO: 0, GOPAY: 0 }),
    getSettingJson<Record<string, string>>('processingTimeJson', { DANA: '1x24 jam kerja', OVO: '1x24 jam kerja', GOPAY: '1x24 jam kerja' }),
    getSettingInt('luckyBonusPoints', 25),
    getSettingInt('dailyAdLimit', 10),
    getSettingInt('adRewardPoints', 50),
  ])
  return {
    conversionRate: cr,
    conversionOptions: Array.isArray(co) ? co : [1000, 5000, 10000, 25000],
    minConvertPoints: mc,
    minWithdrawal: mw,
    maxPendingWithdrawals: mp,
    payoutMode: pm === 'automatic' ? 'automatic' : 'manual',
    enableDANA: d, enableOVO: o, enableGoPay: g,
    fees: f, processingTime: pt,
    luckyBonusPoints: lb,
    dailyAdLimit: dal,
    adRewardPoints: arp,
  }
}

export interface MissionDef {
  code: string
  title: string
  description: string
  target: number
  reward: number
  icon: string
}

export async function getMissionDefs(): Promise<MissionDef[]> {
  return getSettingJson<MissionDef[]>('missionDefsJson', [])
}
