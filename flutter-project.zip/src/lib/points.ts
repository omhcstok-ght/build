import { db } from './db'
import { Prisma } from '@prisma/client'

/**
 * Ledger poin terpusat.
 * Setiap perubahan saldo poin WAJIB melalui fungsi ini agar tercatat di PointTransaction.
 */

export type PointBucket = 'PENDING' | 'AVAILABLE'

export interface CreditOptions {
  userId: string
  type: string
  bucket: PointBucket
  amount: number // harus positif
  sessionId?: string
  meta?: Record<string, unknown>
}

/** Kredit poin (earn). amount > 0. */
export function creditPoints(tx: Prisma.TransactionClient, o: CreditOptions) {
  const data = { [o.bucket === 'PENDING' ? 'pointsPending' : 'pointsAvailable']: { increment: o.amount } }
  return Promise.all([
    tx.user.update({ where: { id: o.userId }, data }),
    tx.pointTransaction.create({
      data: {
        userId: o.userId,
        type: o.type,
        bucket: o.bucket,
        amount: o.amount,
        sessionId: o.sessionId ?? null,
        meta: o.meta ? JSON.stringify(o.meta) : null,
      },
    }),
  ])
}

/** Debit poin dari saldo tersedia (konversi/koreksi). amount > 0 -> dicatat negatif. */
export function debitAvailablePoints(
  tx: Prisma.TransactionClient,
  userId: string,
  amount: number,
  type: string,
  meta?: Record<string, unknown>
) {
  return Promise.all([
    tx.user.update({
      where: { id: userId },
      data: { pointsAvailable: { decrement: amount } },
    }),
    tx.pointTransaction.create({
      data: {
        userId,
        type,
        bucket: 'AVAILABLE',
        amount: -amount,
        meta: meta ? JSON.stringify(meta) : null,
      },
    }),
  ])
}

/** Alihkan semua poin PENDING milik sebuah sesi menjadi AVAILABLE. Kembalikan jumlah poin yang dialihkan. */
export async function releaseSessionPendingPoints(
  tx: Prisma.TransactionClient,
  userId: string,
  sessionId: string
): Promise<number> {
  const pendings = await tx.pointTransaction.findMany({
    where: { userId, sessionId, bucket: 'PENDING' },
  })
  const total = pendings.reduce((s, p) => s + p.amount, 0)
  if (total <= 0) return 0
  for (const p of pendings) {
    await tx.pointTransaction.update({ where: { id: p.id }, data: { bucket: 'AVAILABLE' } })
  }
  await tx.pointTransaction.create({
    data: {
      userId,
      type: 'RELEASE',
      bucket: 'AVAILABLE',
      amount: total,
      sessionId,
      meta: JSON.stringify({ note: 'Poin sesi kuis kini tersedia untuk ditukar' }),
    },
  })
  await tx.user.update({
    where: { id: userId },
    data: {
      pointsPending: { decrement: total },
      pointsAvailable: { increment: total },
    },
  })
  return total
}
