'use client'

import { useEffect } from 'react'
import { motion } from 'framer-motion'
import { useApp } from '@/lib/store'
import { GlassCard } from '@/components/shared'

interface Result {
  correctCount: number
  total: number
  pointsFromAnswers: number
  completionBonus: number
  isPerfect: boolean
  pointsEarned: number
}

export function QuizResultView() {
  const { viewParams, go, setUser } = useApp()
  const result = (viewParams.result ?? {}) as Result
  const pct = result.total > 0 ? Math.round((result.correctCount / result.total) * 100) : 0

  // Segarkan saldo user di store
  useEffect(() => {
    fetch('/api/auth/me', { credentials: 'include' })
      .then((r) => r.json())
      .then((d) => {
        if (d.user) setUser(d.user)
      })
      .catch(() => {})
  }, [setUser])

  if (result.correctCount === undefined) {
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4">
        <p className="text-sm text-white/50">Hasil tidak ditemukan.</p>
        <button onClick={() => go('quiz')} className="btn-grad rounded-xl px-6 py-2.5 text-sm font-bold">
          Kembali ke Kuis
        </button>
      </div>
    )
  }

  const circumference = 2 * Math.PI * 52

  return (
    <div className="float-in mx-auto flex max-w-md flex-col items-center pt-4">
      <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 0.5, ease: 'easeOut' }}>
        <div className="relative h-40 w-40">
          <svg className="h-full w-full -rotate-90" viewBox="0 0 120 120">
            <circle cx="60" cy="60" r="52" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="10" />
            <circle
              cx="60"
              cy="60"
              r="52"
              fill="none"
              stroke="url(#resGrad)"
              strokeWidth="10"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={circumference * (1 - pct / 100)}
              style={{ transition: 'stroke-dashoffset 1s ease 0.3s' }}
            />
            <defs>
              <linearGradient id="resGrad" x1="0" y1="0" x2="120" y2="120">
                <stop offset="0%" stopColor="#4f7cff" />
                <stop offset="100%" stopColor="#8b5cf6" />
              </linearGradient>
            </defs>
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <p className="text-3xl font-black text-white">
              {result.correctCount}
              <span className="text-lg text-white/40">/{result.total}</span>
            </p>
            <p className="text-[11px] font-semibold uppercase tracking-widest text-white/40">Jawaban Benar</p>
          </div>
        </div>
      </motion.div>

      <h1 className="mt-5 text-xl font-bold text-white">
        {result.isPerfect ? 'Sempurna! Luar biasa!' : pct >= 60 ? 'Kerja bagus!' : 'Terus berlatih!'}
      </h1>
      <p className="mt-1 text-center text-sm text-white/45">
        {result.isPerfect
          ? 'Kamu menjawab semua soal dengan benar + bonus sempurna.'
          : 'Kumpulkan streak jawaban benar untuk bonus tambahan.'}
      </p>

      <GlassCard className="mt-6 w-full space-y-3 p-5">
        <div className="flex items-center justify-between text-sm">
          <span className="text-white/55">Poin jawaban benar</span>
          <span className="font-bold text-emerald-300">+{result.pointsFromAnswers}</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-white/55">Bonus penyelesaian</span>
          <span className="font-bold text-emerald-300">+{result.completionBonus}</span>
        </div>
        <div className="divider-fade" />
        <div className="flex items-center justify-between">
          <span className="text-sm font-semibold text-white">Total poin sesi</span>
          <span className="gold-text text-xl font-black">+{result.pointsEarned}</span>
        </div>
        <p className="text-[11px] leading-relaxed text-white/35">
          Poin kini berstatus tersedia dan siap ditukar menjadi saldo hadiah.
        </p>
      </GlassCard>

      <div className="mt-6 grid w-full grid-cols-2 gap-3">
        <button onClick={() => go('quiz')} className="btn-grad rounded-2xl py-3.5 text-sm font-bold">
          Main Lagi
        </button>
        <button onClick={() => go('rewards', { tab: 'convert' })} className="glass rounded-2xl py-3.5 text-sm font-bold text-white transition hover:bg-white/10">
          Tukar Poin
        </button>
      </div>
      <button onClick={() => go('leaderboard')} className="mt-3 text-xs font-medium text-blue-300 hover:text-blue-200">
        Lihat posisimu di Leaderboard
      </button>
    </div>
  )
}
