'use client'

import { useEffect, useState } from 'react'
import { useApp } from '@/lib/store'
import { api } from '@/lib/api'
import { GlassCard, Loading, PageHeader, SectionTitle } from '@/components/shared'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { toast } from 'sonner'

type InfoTab = 'faq' | 'terms' | 'privacy' | 'help' | 'about'
type SupportCategory = 'LAPORAN' | 'SARAN' | 'RESET_PASSWORD' | 'LAINNYA'

interface SupportResponse {
  success: boolean
  message: string
}

const SUPPORT_CATEGORIES: { value: SupportCategory; label: string }[] = [
  { value: 'LAPORAN', label: 'Laporan Masalah' },
  { value: 'SARAN', label: 'Saran & Masukan' },
  { value: 'RESET_PASSWORD', label: 'Reset Password' },
  { value: 'LAINNYA', label: 'Lainnya' },
]

const FAQ_ITEMS: { q: string; a: string }[] = [
  {
    q: 'Bagaimana cara bermain kuis untuk mendapatkan poin?',
    a: 'Buka menu Play Quiz dari dashboard, pilih kategori dan tingkat kesulitan, lalu jawab soal sebelum waktu habis. Setiap jawaban benar memberi poin, ditambah bonus streak untuk jawaban beruntun, bonus penyelesaian sesi, dan bonus skor sempurna bila menjawab semua soal dengan benar.',
  },
  {
    q: 'Kenapa poin saya berstatus PENDING?',
    a: 'Poin yang baru kamu peroleh masuk ke bucket PENDING sebagai masa penahanan (holding period) untuk pemeriksaan kecurangan oleh sistem. Setelah melewati masa tersebut, poin otomatis dirilis menjadi AVAILABLE dan dapat ditukar menjadi saldo hadiah.',
  },
  {
    q: 'Bagaimana cara mengubah poin menjadi saldo hadiah?',
    a: 'Buka Reward Center, pilih menu Tukar Poin, pastikan poin AVAILABLE kamu memenuhi syarat minimum konversi, lalu konfirmasikan. Saldo hadiah akan muncul di dompet dan siap diajukan sebagai pencairan.',
  },
  {
    q: 'Berapa minimal penarikan dan biayanya?',
    a: 'Jumlah minimum penarikan dan biaya administrasi (bila ada) selalu ditampilkan pada halaman Reward Center sebelum kamu mengajukan pencairan. Biaya dipotong otomatis dari jumlah pencairan, jadi tidak ada potongan tersembunyi.',
  },
  {
    q: 'Metode pencairan apa saja yang didukung?',
    a: 'Pencairan menggunakan rekening bank atau dompet digital (e-wallet) yang didukung sistem. Pastikan nama pemilik rekening sesuai dengan identitasmu; pencairan ke rekening milik orang lain dapat ditolak oleh admin.',
  },
  {
    q: 'Apakah data saya aman?',
    a: 'Password disimpan dalam bentuk hash (bukan teks biasa) dan sesi login dilindungi kuki aman. Kami tidak menjual data pribadi. Data rekening hanya digunakan sebatas memproses pembayaranmu. Rincian lengkap tersedia di tab Privasi.',
  },
  {
    q: 'Mengapa fitur Watch & Earn (reward iklan) belum bisa dipakai?',
    a: 'Integrasi jaringan iklan masih dalam tahap pengembangan, sehingga reward iklan belum tersedia. Status integrasi selalu ditampilkan secara jujur di tab Tentang. Setelah aktif, reward iklan akan masuk otomatis ke poin kamu.',
  },
  {
    q: 'Akun saya diblokir, apa yang harus saya lakukan?',
    a: 'Pemblokiran umumnya terjadi karena indikasi multi akun atau kecurangan. Kirim pesan melalui tab Bantuan dengan kategori Laporan Masalah, sertakan username dan penjelasanmu. Admin akan meninjau dan menghubungi kamu melalui notifikasi dalam aplikasi.',
  },
  {
    q: 'Saya lupa password, bagaimana cara meresetnya?',
    a: 'Gunakan tautan Lupa Password pada halaman login untuk menerima instruksi reset melalui email. Bila email reset tidak kunjung tiba, kirim permintaan melalui tab Bantuan dengan kategori Reset Password.',
  },
]

const TERMS_SECTIONS: { title: string; paras: string[] }[] = [
  {
    title: '1. Ketentuan Umum',
    paras: [
      'QUIZ & EARN adalah aplikasi kuis berhadiah: kamu menjawab soal, mengumpulkan poin, menukarkan poin menjadi saldo hadiah, lalu mengajukan pencairan sesuai ketentuan yang berlaku.',
      'Dengan mendaftar dan menggunakan aplikasi, kamu dianggap telah membaca, memahami, dan menyetujui seluruh ketentuan pada halaman ini beserta Kebijakan Privasi kami.',
      'Kami berhak memperbarui ketentuan ini sewaktu-waktu. Perubahan berlaku sejak diumumkan melalui notifikasi di dalam aplikasi.',
    ],
  },
  {
    title: '2. Akun Pengguna',
    paras: [
      'Satu orang hanya boleh memiliki satu akun. Pembuatan akun ganda, baik untuk diri sendiri maupun orang lain, dilarang keras.',
      'Data pendaftaran (nama, username, email) harus benar dan merupakan milikmu sendiri.',
      'Kamu bertanggung jawab penuh menjaga kerahasiaan password dan atas seluruh aktivitas yang terjadi pada akunmu.',
      'Akun yang terindikasi duplikat (perangkat, email, atau identitas yang sama) dapat diblokir tanpa pemberitahuan sebelumnya.',
    ],
  },
  {
    title: '3. Poin dan Saldo Hadiah',
    paras: [
      'Poin adalah unit penghargaan di dalam aplikasi dan BUKAN uang elektronik. Poin baru memiliki nilai ekonomi setelah dikonversi menjadi saldo hadiah dan dicairkan melalui pencairan yang disetujui admin.',
      'Poin yang baru diperoleh berstatus PENDING dan akan dirilis menjadi AVAILABLE setelah melewati masa penahanan untuk pemeriksaan kecurangan.',
      'Nilai tukar, syarat konversi, dan jumlah poin per aktivitas dapat berubah sewaktu-waktu mengikuti ketersediaan anggaran hadiah serta pendapatan iklan dan sponsor.',
      'Kami berhak mengoreksi, menahan, atau membatalkan poin yang diperoleh dari aktivitas tidak wajar, kesalahan sistem, maupun eksploitasi bug.',
    ],
  },
  {
    title: '4. Hadiah dan Pencairan',
    paras: [
      'Pencairan hanya dapat diajukan setelah saldo hadiah memenuhi minimum penarikan dan data rekening atau e-wallet terisi dengan lengkap dan benar.',
      'Nama pemilik rekening atau e-wallet harus sesuai dengan identitas pengguna yang sah. Pencairan ke rekening milik orang lain dapat ditolak.',
      'Proses pencairan melewati tahap PENDING, REVIEWING, APPROVED, PROCESSING, hingga PAID. Waktu proses bergantung pada metode pembayaran dan volume antrean.',
      'Kami berhak menahan atau menolak pencairan bila terdapat indikasi kecurangan, pelanggaran ketentuan, atau data yang tidak valid. Keputusan akhir berada pada admin.',
    ],
  },
  {
    title: '5. Kecurangan dan Penyalahgunaan',
    paras: [
      'Dilarang membuat atau menggunakan multi akun, bot, script, atau alat otomatisasi, memanipulasi jawaban maupun timer, mengeksploitasi bug, dan melakukan aktivitas lain yang merugikan sistem.',
      'Sanksi atas pelanggaran meliputi penghapusan poin atau saldo, pemblokiran sementara, pemblokiran permanen, dan pencabutan hak hadiah.',
      'Kami dapat memantau pola permainan, perangkat, dan log aktivitas untuk mendeteksi kecurangan.',
    ],
  },
  {
    title: '6. Iklan, Sponsor, dan Ketersediaan Layanan',
    paras: [
      'Penghasilan iklan dan sponsor digunakan untuk membiayai hadiah pengguna. Reward per iklan atau per aktivitas dapat berubah mengikuti pendapatan yang tersedia.',
      'Beberapa fitur, seperti reward iklan atau pembayaran otomatis, mungkin belum aktif. Status ketersediaan selalu dijelaskan secara jujur pada tab Tentang.',
      'Layanan dapat dihentikan sementara untuk perbaikan. Bila layanan dihentikan permanen, saldo hadiah sah yang telah lolos verifikasi akan diupayakan dibayarkan sesuai kemampuan.',
    ],
  },
  {
    title: '7. Pembatasan Tanggung Jawab',
    paras: [
      'Layanan disediakan sebagaimana adanya. Kami tidak menjamin layanan sepenuhnya bebas gangguan atau kesalahan.',
      'Kami tidak bertanggung jawab atas kerugian akibat kelalaian pengguna, misalnya membagikan password atau salah memasukkan nomor rekening.',
    ],
  },
  {
    title: '8. Kontak',
    paras: [
      'Pertanyaan mengenai ketentuan ini dapat dikirim melalui tab Bantuan di dalam aplikasi. Balasan dikirim melalui notifikasi dalam aplikasi.',
    ],
  },
]

const PRIVACY_SECTIONS: { title: string; paras: string[] }[] = [
  {
    title: '1. Data yang Kami Kumpulkan',
    paras: [
      'Data akun: nama, username, email, avatar, status verifikasi, serta metode login yang kamu gunakan (password atau Google).',
      'Data aktivitas: sesi kuis, jawaban, skor, streak, progres misi, dan interaksi dengan iklan.',
      'Data transaksi: poin, konversi, dan pencairan, termasuk nama pemilik serta nomor rekening atau e-wallet yang kamu masukkan untuk pembayaran.',
      'Data teknis: waktu akses, informasi perangkat, dan indikator keamanan seperti deteksi multi akun.',
    ],
  },
  {
    title: '2. Cara Kami Menggunakan Data',
    paras: [
      'Menjalankan fitur inti aplikasi: kuis, perhitungan poin, konversi, dan pencairan.',
      'Memverifikasi pencairan dan mencegah kecurangan atau penyalahgunaan sistem.',
      'Mengirim notifikasi penting, seperti status pencairan, pengumuman, dan balasan dukungan.',
      'Menyusun statistik agregat untuk pengembangan produk. Data agregat tidak mengidentifikasi individu.',
    ],
  },
  {
    title: '3. Berbagi Data kepada Pihak Ketiga',
    paras: [
      'Kami tidak menjual data pribadimu kepada pihak mana pun.',
      'Data nama dan nomor rekening hanya dibagikan kepada penyedia layanan pembayaran atau disbursement sebatas yang diperlukan untuk memproses pencairanmu.',
      'Kami dapat mengungkapkan data bila diwajibkan oleh hukum yang berlaku atau permintaan resmi dari otoritas yang berwenang.',
    ],
  },
  {
    title: '4. Penyimpanan dan Keamanan',
    paras: [
      'Password disimpan dalam bentuk hash yang tidak dapat dibaca manusia, bukan teks biasa.',
      'Sesi login dikelola menggunakan kuki aman. Kamu dapat mengakhiri sesi kapan saja melalui menu Keluar di halaman Profil.',
      'Meskipun kami menerapkan langkah pengamanan yang wajar, tidak ada sistem yang sepenuhnya aman. Lindungi akunmu dengan password yang kuat dan unik.',
    ],
  },
  {
    title: '5. Hak Kamu',
    paras: [
      'Kamu berhak meminta salinan, koreksi, atau penghapusan data pribadi, termasuk penghapusan akun, melalui tab Bantuan.',
      'Permintaan kami proses dalam waktu yang wajar setelah identitas pemilik akun terverifikasi.',
    ],
  },
  {
    title: '6. Kuki dan Penyimpanan Lokal',
    paras: [
      'Aplikasi menggunakan kuki sesi untuk menjaga status login dan menyimpan preferensi tampilan. Kamu dapat menghapus kuki melalui pengaturan peramban, namun hal itu akan mengakhiri sesi loginmu.',
    ],
  },
  {
    title: '7. Privasi Anak',
    paras: [
      'QUIZ & EARN tidak ditujukan bagi anak di bawah 13 tahun atau usia minimum lain sesuai hukum setempat. Akun yang diketahui milik anak di bawah usia tersebut akan kami hapus.',
    ],
  },
  {
    title: '8. Perubahan Kebijakan',
    paras: [
      'Kebijakan privasi ini dapat kami perbarui sewaktu-waktu. Perubahan penting akan diumumkan melalui notifikasi di dalam aplikasi.',
    ],
  },
  {
    title: '9. Kontak',
    paras: [
      'Pertanyaan seputar privasi dapat dikirim melalui tab Bantuan dengan kategori Lainnya atau Laporan Masalah.',
    ],
  },
]

function LegalSection({ title, paras }: { title: string; paras: string[] }) {
  return (
    <div>
      <h3 className="text-sm font-bold text-white">{title}</h3>
      <ul className="mt-2 space-y-2">
        {paras.map((p, i) => (
          <li key={i} className="flex gap-2">
            <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-blue-400/60" />
            <p className="text-xs leading-relaxed text-white/55">{p}</p>
          </li>
        ))}
      </ul>
    </div>
  )
}

function StatusDot({ state, label, desc }: { state: 'live' | 'auto' | 'off'; label: string; desc: string }) {
  const dot =
    state === 'live' ? (
      <span className="h-2.5 w-2.5 rounded-full bg-emerald-400" />
    ) : state === 'auto' ? (
      <span className="pulse-dot h-2.5 w-2.5 rounded-full bg-amber-400" />
    ) : (
      <span className="h-2.5 w-2.5 rounded-full bg-white/25" />
    )
  return (
    <div className="flex items-start gap-3">
      <span className="mt-1.5 shrink-0">{dot}</span>
      <div className="min-w-0 flex-1">
        <p className="text-xs font-semibold text-white/85">{label}</p>
        <p className="text-[11px] leading-relaxed text-white/40">{desc}</p>
      </div>
    </div>
  )
}

export function InfoView() {
  const { go, viewParams, user } = useApp()
  const raw = viewParams.tab
  const initialTab: InfoTab =
    raw === 'terms' || raw === 'privacy' || raw === 'help' || raw === 'about' ? raw : 'faq'

  const [tab, setTab] = useState<InfoTab>(initialTab)

  // Form bantuan
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [category, setCategory] = useState<SupportCategory>('LAPORAN')
  const [subject, setSubject] = useState('')
  const [message, setMessage] = useState('')
  const [sending, setSending] = useState(false)

  useEffect(() => {
    if (user) {
      setName((prev) => prev || user.name)
      setEmail((prev) => prev || user.email)
    }
  }, [user])

  async function submitSupport() {
    if (sending) return
    if (subject.trim().length < 3) {
      toast.error('Subjek minimal 3 karakter.')
      return
    }
    if (message.trim().length < 10) {
      toast.error('Pesan minimal 10 karakter agar kami memahami masalahmu.')
      return
    }
    setSending(true)
    try {
      const res = await api<SupportResponse>('/api/support', {
        method: 'POST',
        body: {
          name: name.trim() || undefined,
          email: email.trim() || undefined,
          category,
          subject: subject.trim(),
          message: message.trim(),
        },
      })
      toast.success(res.message || 'Pesan terkirim. Terima kasih!')
      setSubject('')
      setMessage('')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal mengirim pesan.')
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="float-in space-y-5">
      <PageHeader title="Bantuan & Info" subtitle="FAQ, ketentuan, privasi, dan kontak" onBack={() => go('dashboard')} />

      <Tabs value={tab} onValueChange={(v) => setTab(v as InfoTab)}>
        <TabsList className="grid h-auto w-full grid-cols-3 gap-1 rounded-xl border border-white/10 bg-white/5 p-1">
          <TabsTrigger value="faq" className="h-9 rounded-lg text-xs data-[state=active]:bg-white/10 data-[state=active]:text-white">
            FAQ
          </TabsTrigger>
          <TabsTrigger value="terms" className="h-9 rounded-lg text-xs data-[state=active]:bg-white/10 data-[state=active]:text-white">
            Syarat
          </TabsTrigger>
          <TabsTrigger value="privacy" className="h-9 rounded-lg text-xs data-[state=active]:bg-white/10 data-[state=active]:text-white">
            Privasi
          </TabsTrigger>
          <TabsTrigger value="help" className="h-9 rounded-lg text-xs data-[state=active]:bg-white/10 data-[state=active]:text-white">
            Bantuan
          </TabsTrigger>
          <TabsTrigger value="about" className="h-9 rounded-lg text-xs data-[state=active]:bg-white/10 data-[state=active]:text-white">
            Tentang
          </TabsTrigger>
        </TabsList>

        {/* FAQ */}
        <TabsContent value="faq" className="mt-4">
          <GlassCard className="p-2">
            <Accordion type="single" collapsible className="w-full">
              {FAQ_ITEMS.map((item, i) => (
                <AccordionItem key={i} value={`faq-${i}`} className="border-white/10">
                  <AccordionTrigger className="px-3 py-3.5 text-left text-xs font-semibold text-white/85 hover:text-white hover:no-underline">
                    {item.q}
                  </AccordionTrigger>
                  <AccordionContent className="px-3 text-xs leading-relaxed text-white/55">
                    {item.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </GlassCard>
        </TabsContent>

        {/* SYARAT & KETENTUAN */}
        <TabsContent value="terms" className="mt-4">
          <SectionTitle>Syarat & Ketentuan</SectionTitle>
          <GlassCard className="p-5">
            <div className="qe-scroll max-h-96 space-y-5 overflow-y-auto pr-2">
              <p className="text-[11px] italic text-white/35">
                Terakhir diperbarui: berlaku sejak penggunaan aplikasi. Dengan mendaftar, kamu menyetujui seluruh isi halaman ini.
              </p>
              {TERMS_SECTIONS.map((s) => (
                <LegalSection key={s.title} title={s.title} paras={s.paras} />
              ))}
            </div>
          </GlassCard>
        </TabsContent>

        {/* PRIVASI */}
        <TabsContent value="privacy" className="mt-4">
          <SectionTitle>Kebijakan Privasi</SectionTitle>
          <GlassCard className="p-5">
            <div className="qe-scroll max-h-96 space-y-5 overflow-y-auto pr-2">
              <p className="text-[11px] italic text-white/35">
                Privasi kamu penting. Halaman ini menjelaskan data apa yang kami kumpulkan, alasan penggunaannya, dan hak-hakmu.
              </p>
              {PRIVACY_SECTIONS.map((s) => (
                <LegalSection key={s.title} title={s.title} paras={s.paras} />
              ))}
            </div>
          </GlassCard>
        </TabsContent>

        {/* BANTUAN */}
        <TabsContent value="help" className="mt-4 space-y-4">
          <SectionTitle>Pusat Laporan & Dukungan</SectionTitle>
          <GlassCard className="space-y-3 p-4">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <p className="mb-1.5 text-xs font-medium text-white/60">Nama</p>
                <input
                  className="qe-input"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Namamu"
                  maxLength={40}
                />
              </div>
              <div>
                <p className="mb-1.5 text-xs font-medium text-white/60">Email (opsional)</p>
                <input
                  className="qe-input"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="untuk balasan via email"
                  maxLength={60}
                />
              </div>
            </div>
            <div>
              <p className="mb-1.5 text-xs font-medium text-white/60">Kategori</p>
              <Select value={category} onValueChange={(v) => setCategory(v as SupportCategory)}>
                <SelectTrigger className="h-11 w-full rounded-xl border-white/12 bg-white/5 text-sm text-white data-[placeholder]:text-white/40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="border-white/10 bg-[#101630] text-white">
                  {SUPPORT_CATEGORIES.map((c) => (
                    <SelectItem key={c.value} value={c.value} className="text-sm focus:bg-white/10 focus:text-white">
                      {c.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <p className="mb-1.5 text-xs font-medium text-white/60">Subjek</p>
              <input
                className="qe-input"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Ringkasan masalah atau pertanyaan"
                maxLength={80}
              />
            </div>
            <div>
              <p className="mb-1.5 text-xs font-medium text-white/60">Pesan</p>
              <textarea
                className="qe-input min-h-28 resize-y"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Jelaskan masalahmu sedetail mungkin. Sertakan username bila terkait akun."
                maxLength={1000}
              />
              <p className="mt-1 text-right text-[10px] text-white/30">{message.length}/1000</p>
            </div>
            <button
              onClick={submitSupport}
              disabled={sending}
              className="btn-grad h-11 w-full rounded-xl text-sm font-bold"
            >
              {sending ? 'Mengirim...' : 'Kirim Pesan'}
            </button>
            <p className="text-[11px] leading-relaxed text-white/35">
              Balasan dikirim melalui notifikasi dalam aplikasi atau email yang kamu cantumkan. Untuk masalah pencairan, sertakan juga nama metode dan tanggal pengajuan.
            </p>
          </GlassCard>
        </TabsContent>

        {/* TENTANG */}
        <TabsContent value="about" className="mt-4 space-y-4">
          <SectionTitle>Tentang QUIZ & EARN</SectionTitle>
          <GlassCard className="p-5">
            <p className="text-sm font-bold brand-text">QUIZ & EARN</p>
            <p className="mt-2 text-xs leading-relaxed text-white/55">
              Platform kuis berhadiah tempat kamu bermain, menjawab, dan mengumpulkan poin dari pengetahuanmu. Poin dapat ditukar menjadi saldo hadiah dan dicairkan sesuai ketentuan yang berlaku. Penghasilan iklan dan sponsor kami gunakan untuk membiayai hadiah pengguna secara transparan.
            </p>
            <div className="divider-fade my-4" />
            <p className="text-center text-sm font-black tracking-[0.3em] gold-text">
              PLAY. ANSWER. EARN. REPEAT.
            </p>
          </GlassCard>

          <GlassCard className="space-y-4 p-5">
            <p className="text-sm font-semibold text-white/85">Status Integrasi</p>
            <p className="-mt-2 text-[11px] leading-relaxed text-white/35">
              Kami menampilkan status koneksi secara jujur, tanpa klaim berlebihan.
            </p>
            <div className="space-y-4">
              <StatusDot
                state="auto"
                label="Google Login (OAuth)"
                desc="Terdeteksi otomatis saat GOOGLE_CLIENT_ID diatur"
              />
              <StatusDot
                state="off"
                label="Jaringan Iklan"
                desc="Belum terhubung. Reward iklan belum tersedia sampai integrasi selesai."
              />
              <StatusDot
                state="off"
                label="Payment Gateway / Disbursement"
                desc="Belum terhubung. Saat ini pencairan diproses manual oleh admin melalui panel admin."
              />
            </div>
            <div className="divider-fade" />
            <p className="text-[10px] text-white/30">
              Versi aplikasi 1.0.0 - Dibangun dengan standar keamanan dan transparansi untuk pengguna di Indonesia.
            </p>
          </GlassCard>
        </TabsContent>
      </Tabs>
    </div>
  )
}
