'use client'

import { useEffect, useState } from 'react'
import { useApp } from '@/lib/store'
import { api, fmtNum } from '@/lib/api'
import { GlassCard, PageHeader, Loading, Avatar } from '@/components/shared'
import { toast } from 'sonner'
import { motion } from 'framer-motion'

interface Row {
  rank: number
  userId: string
  name: string
  username: string
  avatar: string | null
  points: number
  isMe: boolean
}

const MEDALS = ['text-amber-300', 'text-slate-300', 'text-orange-300']

export function LeaderboardView() {
  const { go } = useApp()
  const [range, setRange] = useState<'week' | 'all'>('week')
  const [rows, setRows] = useState<Row[] | null>(null)

  function fetchBoard(r: 'week' | 'all') {
    api<{ rows: Row[] }>(`/api/leaderboard?range=${r}`)
      .then((d) => setRows(d.rows))
      .catch((e) => {
        toast.error(e.message)
        setRows([])
      })
  }

  useEffect(() => {
    fetchBoard('week')
  }, [])

  function switchRange(r: 'week' | 'all') {
    setRange(r)
    setRows(null)
    fetchBoard(r)
  }

  const top3 = rows?.slice(0, 3) ?? []
  const rest = rows?.slice(3) ?? []

  return (
    <div className="float-in">
      <PageHeader title="Leaderboard" subtitle="Peringkat pengumpul poin teratas." onBack={() => go('dashboard')} />

      <div className="glass mb-6 flex rounded-2xl p-1">
        {(['week', 'all'] as const).map((r) => (
          <button
            key={r}
            onClick={() => switchRange(r)}
            className={`flex-1 rounded-xl py-2.5 text-xs font-bold transition ${
              range === r ? 'btn-grad' : 'text-white/50 hover:text-white'
            }`}
          >
            {r === 'week' ? 'Minggu Ini' : 'Semua Waktu'}
          </button>
        ))}
      </div>

      {!rows ? (
        <Loading label="Memuat peringkat..." />
      ) : rows.length === 0 ? (
        <p className="py-16 text-center text-sm text-white/40">Belum ada poin tercatat pada periode ini.</p>
      ) : (
        <>
          {/* Podium */}
          <div className="mb-6 flex items-end justify-center gap-3">
            {top3.map((r, i) => {
              const heights = ['h-24', 'h-20', 'h-16']
              const order = i === 0 ? 0 : i === 1 ? 1 : 2 // urutan tampil: 1-0-2
              void order
              const pos = i === 0 ? 'order-2' : i === 1 ? 'order-1' : 'order-3'
              return (
                <motion.div
                  key={r.userId}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className={`flex flex-col items-center ${pos}`}
                >
                  <Avatar name={r.name} avatar={r.avatar} size={i === 0 ? 56 : 44} className={r.isMe ? 'ring-2 ring-amber-300' : ''} />
                  <p className="mt-2 max-w-20 truncate text-[11px] font-semibold text-white/85">{r.name.split(' ')[0]}</p>
                  <p className={`text-xs font-black ${MEDALS[i]}`}>#{r.rank}</p>
                  <GlassCard className={`mt-2 flex w-24 items-center justify-center rounded-t-2xl border-b-0 ${heights[i === 0 ? 0 : i === 1 ? 1 : 2]} ${r.isMe ? '!border-amber-300/40' : ''}`}>
                    <div className="text-center">
                      <p className={`text-sm font-black ${i === 0 ? 'gold-text' : 'text-white'}`}>{fmtNum(r.points)}</p>
                      <p className="text-[9px] text-white/35">poin</p>
                    </div>
                  </GlassCard>
                </motion.div>
              )
            })}
          </div>

          {/* Sisanya */}
          <GlassCard className="divide-y divide-white/5 p-1">
            {rest.map((r) => (
              <div key={r.userId} className={`flex items-center gap-3 px-3 py-3 ${r.isMe ? 'rounded-xl bg-amber-400/8' : ''}`}>
                <span className={`w-7 text-center text-sm font-black ${r.rank <= 10 ? 'text-white/80' : 'text-white/35'}`}>
                  {r.rank}
                </span>
                <Avatar name={r.name} avatar={r.avatar} size={34} className={r.isMe ? 'ring-2 ring-amber-300' : ''} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-xs font-semibold text-white/85">
                    {r.name} {r.isMe && <span className="ml-1 rounded bg-amber-400/15 px-1.5 py-0.5 text-[9px] font-bold text-amber-300">KAMU</span>}
                  </p>
                  <p className="text-[10px] text-white/30">@{r.username}</p>
                </div>
                <span className="text-sm font-bold text-white">{fmtNum(r.points)}</span>
              </div>
            ))}
          </GlassCard>
        </>
      )}
    </div>
  )
}
