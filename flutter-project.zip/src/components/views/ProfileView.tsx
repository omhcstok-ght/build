'use client'

import { useEffect, useState } from 'react'
import { useApp } from '@/lib/store'
import { api, clearUserToken, rupiah, fmtNum, fmtDate } from '@/lib/api'
import {
  Avatar,
  AVATAR_PRESETS,
  EmptyState,
  GlassCard,
  Loading,
  PageHeader,
  SectionTitle,
  StatTile,
} from '@/components/shared'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { toast } from 'sonner'

interface ProfileData {
  profile: {
    name: string
    username: string
    email: string
    avatar: string | null
    emailVerified: boolean
    googleLinked: boolean
    hasPassword: boolean
    createdAt: string
    lastLoginAt: string
  }
  stats: {
    quizCompleted: number
    pointsEarned: number
    transactions: number
    withdrawals: number
    pointsPending: number
    pointsAvailable: number
    walletAvailable: number
    totalPaid: number
  }
}

interface MenuRow {
  key: string
  label: string
  desc: string
  danger?: boolean
  onClick: () => void
}

function ChevronRight() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 6l6 6-6 6" />
    </svg>
  )
}

export function ProfileView() {
  const { go, user, setUser } = useApp()
  const [data, setData] = useState<ProfileData | null>(null)
  const [loading, setLoading] = useState(true)

  // Edit nama
  const [name, setName] = useState('')
  const [savingName, setSavingName] = useState(false)

  // Pilih avatar
  const [avatarKey, setAvatarKey] = useState<string>('')
  const [savingAvatar, setSavingAvatar] = useState(false)

  // Ganti password
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [savingPassword, setSavingPassword] = useState(false)

  // Keluar
  const [logoutOpen, setLogoutOpen] = useState(false)
  const [loggingOut, setLoggingOut] = useState(false)

  useEffect(() => {
    let active = true
    api<ProfileData>('/api/profile')
      .then((d) => {
        if (!active) return
        setData(d)
        setName(d.profile.name)
        setAvatarKey(d.profile.avatar ?? '')
      })
      .catch((e) => {
        toast.error(e instanceof Error ? e.message : 'Gagal memuat profil.')
      })
      .finally(() => {
        if (active) setLoading(false)
      })
    return () => {
      active = false
    }
  }, [])

  async function saveName() {
    const trimmed = name.trim()
    if (trimmed.length < 2) {
      toast.error('Nama minimal 2 karakter.')
      return
    }
    if (savingName) return
    setSavingName(true)
    try {
      const res = await api<{ success: boolean; message: string }>('/api/profile', {
        method: 'PATCH',
        body: { name: trimmed },
      })
      toast.success(res.message || 'Nama berhasil diperbarui.')
      setData((prev) => (prev ? { ...prev, profile: { ...prev.profile, name: trimmed } } : prev))
      if (user) setUser({ ...user, name: trimmed })
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal menyimpan nama.')
    } finally {
      setSavingName(false)
    }
  }

  async function chooseAvatar(key: string) {
    if (savingAvatar) return
    const prev = avatarKey
    setAvatarKey(key)
    setSavingAvatar(true)
    try {
      await api<{ success: boolean; message: string }>('/api/profile', {
        method: 'PATCH',
        body: { avatar: key },
      })
      toast.success('Avatar diperbarui.')
      setData((p) => (p ? { ...p, profile: { ...p.profile, avatar: key } } : p))
      if (user) setUser({ ...user, avatar: key })
    } catch (e) {
      setAvatarKey(prev)
      toast.error(e instanceof Error ? e.message : 'Gagal mengubah avatar.')
    } finally {
      setSavingAvatar(false)
    }
  }

  async function savePassword() {
    if (savingPassword) return
    if (!currentPassword) {
      toast.error('Password saat ini wajib diisi.')
      return
    }
    if (newPassword.length < 8) {
      toast.error('Password baru minimal 8 karakter.')
      return
    }
    if (newPassword !== confirmPassword) {
      toast.error('Konfirmasi password tidak sama.')
      return
    }
    setSavingPassword(true)
    try {
      const res = await api<{ success: boolean; message: string }>('/api/profile', {
        method: 'POST',
        body: { currentPassword, newPassword, confirmPassword },
      })
      toast.success(res.message || 'Password berhasil diubah.')
      setCurrentPassword('')
      setNewPassword('')
      setConfirmPassword('')
      setData((p) => (p ? { ...p, profile: { ...p.profile, hasPassword: true } } : p))
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal mengubah password.')
    } finally {
      setSavingPassword(false)
    }
  }

  async function handleLogout() {
    if (loggingOut) return
    setLoggingOut(true)
    try {
      await api('/api/auth/logout', { method: 'POST' })
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal keluar dari akun.')
    } finally {
      setLoggingOut(false)
      setLogoutOpen(false)
      clearUserToken()
      setUser(null)
      go('welcome')
    }
  }

  if (loading) return <Loading label="Memuat profil..." />

  if (!data) {
    return (
      <div className="float-in">
        <PageHeader title="Profil" onBack={() => go('dashboard')} />
        <EmptyState title="Profil tidak dapat dimuat" description="Terjadi kesalahan saat mengambil data profil. Coba buka halaman ini kembali." />
      </div>
    )
  }

  const { profile, stats } = data

  const menus: MenuRow[] = [
    { key: 'history', label: 'Riwayat', desc: 'Kuis, poin, dan pencairan', onClick: () => go('history') },
    { key: 'notifications', label: 'Notifikasi', desc: 'Pengumuman dan status transaksi', onClick: () => go('notifications') },
    { key: 'info', label: 'Bantuan & Info', desc: 'FAQ, syarat, privasi, kontak', onClick: () => go('info') },
  ]

  return (
    <div className="float-in space-y-6">
      <PageHeader title="Profil" subtitle="Kelola akun dan preferensimu" onBack={() => go('dashboard')} />

      {/* Kartu profil */}
      <GlassCard className="p-5">
        <div className="flex items-center gap-4">
          <Avatar name={profile.name} avatar={profile.avatar} size={64} />
          <div className="min-w-0 flex-1">
            <p className="truncate text-lg font-bold text-white">{profile.name}</p>
            <p className="truncate text-sm text-white/50">@{profile.username}</p>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              {profile.emailVerified ? (
                <span className="inline-flex items-center gap-1 rounded-full border border-emerald-400/25 bg-emerald-400/10 px-2 py-0.5 text-[10px] font-semibold text-emerald-300">
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20 6L9 17l-5-5" />
                  </svg>
                  Email terverifikasi
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 rounded-full border border-amber-400/25 bg-amber-400/10 px-2 py-0.5 text-[10px] font-semibold text-amber-300">
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round">
                    <path d="M12 8v5M12 16.5h.01" />
                  </svg>
                  Belum terverifikasi
                </span>
              )}
              <span className="rounded-full bg-white/8 px-2 py-0.5 text-[10px] text-white/50">
                Member sejak {fmtDate(profile.createdAt)}
              </span>
            </div>
          </div>
        </div>
        <div className="divider-fade my-4" />
        <div className="grid grid-cols-1 gap-1 text-xs text-white/50 sm:grid-cols-2">
          <p className="truncate">
            Email: <span className="text-white/80">{profile.email}</span>
          </p>
          <p className="truncate">Login terakhir: {fmtDate(profile.lastLoginAt)}</p>
        </div>
      </GlassCard>

      {/* Statistik ringkas */}
      <section>
        <SectionTitle>Statistik Akun</SectionTitle>
        <div className="grid grid-cols-2 gap-3">
          <StatTile label="Kuis Selesai" value={fmtNum(stats.quizCompleted)} icon={
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01" /></svg>
          } />
          <StatTile label="Total Poin" value={fmtNum(stats.pointsEarned)} gold sub={`${fmtNum(stats.pointsAvailable)} tersedia`} icon={
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2l2.6 6.6L21 11l-6.4 2.4L12 20l-2.6-6.6L3 11l6.4-2.4L12 2z" /></svg>
          } />
          <StatTile label="Transaksi" value={fmtNum(stats.transactions)} sub={`${fmtNum(stats.pointsPending)} poin pending`} icon={
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M7 16V4m0 0L3 8m4-4l4 4M17 8v12m0 0l4-4m-4 4l-4-4" /></svg>
          } />
          <StatTile label="Pencairan" value={fmtNum(stats.withdrawals)} sub={`${rupiah(stats.totalPaid)} dibayarkan`} icon={
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="5" width="20" height="14" rx="3" /><path d="M2 10h20" /></svg>
          } />
        </div>
      </section>

      {/* Edit profil */}
      <section>
        <SectionTitle>Edit Profil</SectionTitle>
        <GlassCard className="space-y-4 p-4">
          <div>
            <p className="mb-1.5 text-xs font-medium text-white/60">Nama Tampilan</p>
            <div className="flex gap-2">
              <input
                className="qe-input flex-1"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Nama tampilan"
                maxLength={40}
              />
              <button
                onClick={saveName}
                disabled={savingName || name.trim() === profile.name}
                className="btn-grad h-11 shrink-0 rounded-xl px-4 text-sm font-bold"
              >
                {savingName ? 'Menyimpan...' : 'Simpan'}
              </button>
            </div>
          </div>
          <div>
            <p className="mb-2 text-xs font-medium text-white/60">Avatar</p>
            <div className="grid grid-cols-4 gap-2 sm:grid-cols-8">
              {Object.keys(AVATAR_PRESETS).map((key) => (
                <button
                  key={key}
                  onClick={() => chooseAvatar(key)}
                  disabled={savingAvatar}
                  aria-label={`Pilih avatar ${key}`}
                  className={`flex h-12 items-center justify-center rounded-xl border transition active:scale-95 disabled:opacity-60 ${
                    avatarKey === key
                      ? 'border-amber-300/70 bg-amber-300/10'
                      : 'border-white/10 bg-white/5 hover:border-white/25'
                  }`}
                >
                  <Avatar name={profile.name} avatar={key} size={32} />
                </button>
              ))}
            </div>
          </div>
        </GlassCard>
      </section>

      {/* Keamanan */}
      <section>
        <SectionTitle>Keamanan</SectionTitle>
        <GlassCard className="space-y-4 p-4">
          <div className="flex flex-wrap gap-2 text-[11px]">
            <span className={`rounded-full border px-2.5 py-1 font-semibold ${profile.hasPassword ? 'border-emerald-400/25 bg-emerald-400/10 text-emerald-300' : 'border-white/15 bg-white/5 text-white/50'}`}>
              Password {profile.hasPassword ? 'aktif' : 'belum diatur'}
            </span>
            <span className={`rounded-full border px-2.5 py-1 font-semibold ${profile.googleLinked ? 'border-blue-400/25 bg-blue-400/10 text-blue-300' : 'border-white/15 bg-white/5 text-white/50'}`}>
              Google {profile.googleLinked ? 'terhubung' : 'belum terhubung'}
            </span>
          </div>
          <div className="space-y-3">
            <input
              className="qe-input"
              type="password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              placeholder="Password saat ini"
              autoComplete="current-password"
            />
            <input
              className="qe-input"
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="Password baru (min. 8 karakter)"
              autoComplete="new-password"
            />
            <input
              className="qe-input"
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Konfirmasi password baru"
              autoComplete="new-password"
            />
            <button
              onClick={savePassword}
              disabled={savingPassword}
              className="btn-grad h-11 w-full rounded-xl text-sm font-bold"
            >
              {savingPassword ? 'Menyimpan...' : 'Ubah Password'}
            </button>
            <p className="text-[11px] leading-relaxed text-white/35">
              Gunakan password minimal 8 karakter. Jangan bagikan password kepada siapa pun, termasuk pihak yang mengaku admin.
            </p>
          </div>
        </GlassCard>
      </section>

      {/* Menu tautan */}
      <section>
        <SectionTitle>Lainnya</SectionTitle>
        <GlassCard className="overflow-hidden p-1">
          {menus.map((m) => (
            <button
              key={m.key}
              onClick={m.onClick}
              className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left transition hover:bg-white/5 active:scale-[0.99]"
            >
              <span className="flex-1 min-w-0">
                <span className="block text-sm font-medium text-white/90">{m.label}</span>
                <span className="block text-[11px] text-white/40">{m.desc}</span>
              </span>
              <span className="text-white/30">
                <ChevronRight />
              </span>
            </button>
          ))}
          <div className="divider-fade mx-3" />
          <button
            onClick={() => setLogoutOpen(true)}
            className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left transition hover:bg-rose-500/10 active:scale-[0.99]"
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-rose-400/10 text-rose-300">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9" />
              </svg>
            </span>
            <span className="flex-1">
              <span className="block text-sm font-medium text-rose-300">Keluar</span>
              <span className="block text-[11px] text-white/40">Akhiri sesi di perangkat ini</span>
            </span>
          </button>
        </GlassCard>
      </section>

      {/* Konfirmasi keluar */}
      <AlertDialog open={logoutOpen} onOpenChange={setLogoutOpen}>
        <AlertDialogContent className="glass-strong border-white/10">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">Keluar dari akun?</AlertDialogTitle>
            <AlertDialogDescription>
              Sesi kamu di perangkat ini akan diakhiri. Poin dan saldo yang sudah tersimpan tetap aman dan bisa diakses lagi setelah login.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-white/15 bg-white/5 text-white/80 hover:bg-white/10 hover:text-white">
              Batal
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleLogout}
              disabled={loggingOut}
              className="bg-rose-500 text-white hover:bg-rose-500/90"
            >
              {loggingOut ? 'Memproses...' : 'Ya, Keluar'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
