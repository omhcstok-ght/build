'use client'

import { useEffect, useState } from 'react'
import { useApp } from '@/lib/store'
import { api } from '@/lib/api'
import { GlassCard, PageHeader, Loading, ProgressBar } from '@/components/shared'
import { toast } from 'sonner'

interface Mission {
  code: string
  title: string
  description: string
  target: number
  reward: number
  icon: string
  progress: number
  claimed: boolean
  complete: boolean
}

interface BonusInfo {
  ready: boolean
  streak: number
  points: number
}

function MissionIcon({ code }: { code: string }) {
  const cls = 'h-5 w-5'
  switch (code) {
    case 'LOGIN':
      return <svg className={cls} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" /><path d="M16 2v4M8 2v4M3 10h18M9 16l2 2 4-4" /></svg>
    case 'PLAY3':
      return <svg className={cls} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><path d="M10 8l6 4-6 4V8z" /></svg>
    case 'CORRECT10':
      return <svg className={cls} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 18h6M10 22h4M12 2a7 7 0 0 1 4 12.7c-.6.5-1 1.2-1 2V18h-6v-1.3c0-.8-.4-1.5-1-2A7 7 0 0 1 12 2z" /></svg>
    case 'PERFECT1':
      return <svg className={cls} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0V4z" /><path d="M7 6H4a3 3 0 0 0 3 6M17 6h3a3 3 0 0 1-3 6" /></svg>
    default:
      return <svg className={cls} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9" /><path d="M8 12l3 3 5-6" /></svg>
  }
}

export function MissionsView() {
  const { go } = useApp()
  const [missions, setMissions] = useState<Mission[] | null>(null)
  const [bonus, setBonus] = useState<BonusInfo | null>(null)
  const [claiming, setClaiming] = useState<string | null>(null)
  const [bonusBusy, setBonusBusy] = useState(false)

  async function load() {
    try {
      const [m, b] = await Promise.all([
        api<{ missions: Mission[] }>('/api/missions'),
        api<BonusInfo>('/api/bonus'),
      ])
      setMissions(m.missions)
      setBonus(b)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal memuat misi.')
      setMissions([])
    }
  }

  useEffect(() => {
    load()
  }, [])

  async function claim(code: string) {
    setClaiming(code)
    try {
      const d = await api<{ message: string }>('/api/missions/claim', { method: 'POST', body: { code } })
      toast.success(d.message)
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal klaim misi.')
    } finally {
      setClaiming(null)
    }
  }

  async function claimBonus() {
    setBonusBusy(true)
    try {
      const d = await api<{ message: string }>('/api/bonus', { method: 'POST', body: {} })
      toast.success(d.message)
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal klaim bonus.')
    } finally {
      setBonusBusy(false)
    }
  }

  if (!missions || !bonus) return <Loading label="Memuat misi harian..." />

  return (
    <div className="float-in">
      <PageHeader title="Daily Challenge" subtitle="Misi harian & Lucky Bonus - poin langsung tersedia." onBack={() => go('dashboard')} />

      {/* Lucky Bonus */}
      <div className="relative mb-6 overflow-hidden rounded-3xl border border-amber-400/25 bg-gradient-to-br from-amber-950/50 via-[#141530] to-[#101a3c] p-5">
        <div className="pointer-events-none absolute -right-8 -top-8 h-32 w-32 rounded-full bg-amber-400/15 blur-3xl" />
        <div className="flex items-center gap-4">
          <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-amber-400/15 text-amber-300">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="8" width="18" height="4" rx="1" /><path d="M5 12v8h14v-8M12 8c-2 0-4-1-4-2.5S10 2 12 5c2-3 6-1.5 4 .5C14.5 7 13 8 12 8z" /></svg>
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white">Lucky Bonus</h2>
              {bonus.streak > 0 && (
                <span className="rounded-full bg-orange-400/15 px-2 py-0.5 text-[10px] font-bold text-orange-300">
                  Streak {bonus.streak} hari
                </span>
              )}
            </div>
            <p className="mt-0.5 text-xs text-white/50">
              Klaim +{bonus.points} poin gratis setiap hari. Kembali berurutan untuk menjaga streak.
            </p>
          </div>
        </div>
        <button
          onClick={claimBonus}
          disabled={!bonus.ready || bonusBusy}
          className="btn-gold mt-4 w-full rounded-2xl py-3.5 text-sm font-bold"
        >
          {bonus.ready ? (bonusBusy ? 'Mengklaim...' : `Klaim +${bonus.points} Poin`) : 'Sudah Diklaim - Kembali Besok'}
        </button>
      </div>

      {/* Misi */}
      <p className="mb-3 text-sm font-semibold text-white/80">Misi Hari Ini</p>
      <div className="space-y-3">
        {missions.map((m) => (
          <GlassCard key={m.code} className="p-4">
            <div className="flex items-center gap-3">
              <span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${m.claimed ? 'bg-emerald-400/15 text-emerald-300' : 'bg-blue-500/15 text-blue-300'}`}>
                <MissionIcon code={m.code} />
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm font-bold text-white">{m.title}</p>
                  <span className="shrink-0 rounded-full bg-amber-400/10 px-2.5 py-0.5 text-[11px] font-bold text-amber-300">
                    +{m.reward} poin
                  </span>
                </div>
                <p className="mt-0.5 text-[11px] text-white/45">{m.description}</p>
                <div className="mt-2 flex items-center gap-2.5">
                  <ProgressBar value={m.progress} max={m.target} gold={m.claimed} className="flex-1" />
                  <span className="shrink-0 text-[10px] font-semibold text-white/40">
                    {Math.min(m.progress, m.target)}/{m.target}
                  </span>
                </div>
              </div>
            </div>
            {m.complete && !m.claimed && (
              <button
                onClick={() => claim(m.code)}
                disabled={claiming === m.code}
                className="btn-gold mt-3 w-full rounded-xl py-2.5 text-xs font-bold"
              >
                {claiming === m.code ? 'Mengklaim...' : 'Klaim Hadiah Misi'}
              </button>
            )}
            {m.claimed && (
              <p className="mt-3 rounded-xl bg-emerald-400/10 py-2 text-center text-[11px] font-semibold text-emerald-300">
                Hadiah telah diklaim
              </p>
            )}
          </GlassCard>
        ))}
      </div>

      <p className="mt-5 text-center text-[11px] leading-relaxed text-white/30">
        Misi direset setiap hari pada tengah malam. Hadiah misi dan bonus dikonfigurasi admin dan
        dapat berubah sewaktu-waktu.
      </p>
    </div>
  )
}
