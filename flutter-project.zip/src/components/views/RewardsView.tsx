'use client'

import { useCallback, useEffect, useState } from 'react'
import { useApp } from '@/lib/store'
import { api, rupiah, fmtNum, fmtDateTime, uuid } from '@/lib/api'
import { GlassCard, PageHeader, Loading, EmptyState, StatusBadge, ProgressBar } from '@/components/shared'
import { toast } from 'sonner'

interface Summary {
  pointsPending: number
  pointsAvailable: number
  estimateValue: number
  conversionRate: number
  conversionOptions: number[]
  minConvertPoints: number
  wallet: { available: number; processing: number; totalPaid: number }
  withdrawals: { activeCount: number; maxPending: number }
}

interface WdRules {
  minWithdrawal: number
  payoutMode: 'manual' | 'automatic'
  methods: { DANA: boolean; OVO: boolean; GOPAY: boolean }
  fees: Record<string, number>
  processingTime: Record<string, string>
  automaticAvailable: boolean
}

interface Withdrawal {
  id: string
  amount: number
  fee: number
  method: string
  accountName: string
  accountNumber: string
  status: string
  reference: string | null
  createdAt: string
}

const TABS = [
  { key: 'convert', label: 'Konversi' },
  { key: 'withdraw', label: 'Tarik Dana' },
  { key: 'history', label: 'Riwayat' },
]

const METHODS: { key: string; name: string; color: string }[] = [
  { key: 'DANA', name: 'DANA', color: 'from-sky-400 to-blue-500' },
  { key: 'OVO', name: 'OVO', color: 'from-violet-500 to-purple-600' },
  { key: 'GOPAY', name: 'GoPay', color: 'from-teal-400 to-emerald-500' },
]

export function RewardsView() {
  const { go, setUser, viewParams } = useApp()
  const [tab, setTab] = useState<string>((viewParams.tab as string) || 'convert')
  const [summary, setSummary] = useState<Summary | null>(null)
  const [rules, setRules] = useState<WdRules | null>(null)
  const [withdrawals, setWithdrawals] = useState<Withdrawal[] | null>(null)
  const [converts, setConverts] = useState<{ id: string; amount: number; createdAt: string }[] | null>(null)

  // form konversi
  const [convertPoints, setConvertPoints] = useState<number | ''>('')
  const [converting, setConverting] = useState(false)

  // form penarikan
  const [method, setMethod] = useState('DANA')
  const [accountName, setAccountName] = useState('')
  const [accountNumber, setAccountNumber] = useState('')
  const [confirmNumber, setConfirmNumber] = useState('')
  const [amount, setAmount] = useState<number | ''>('')
  const [withdrawing, setWithdrawing] = useState(false)

  const load = useCallback(async () => {
    try {
      const [s, w] = await Promise.all([
        api<Summary>('/api/points/summary'),
        api<{ withdrawals: Withdrawal[]; rules: WdRules }>('/api/withdrawals'),
      ])
      setSummary(s)
      setRules(w.rules)
      setWithdrawals(w.withdrawals)
      const h = await api<{ transactions: { id: string; amount: number; createdAt: string; type: string }[] }>(
        '/api/points/history?limit=100'
      )
      setConverts(h.transactions.filter((t) => t.type === 'CONVERT_OUT').slice(0, 15))
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal memuat data hadiah.')
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  async function doConvert() {
    const pts = Number(convertPoints)
    if (!pts || !summary) return
    setConverting(true)
    try {
      const d = await api<{ message: string }>('/api/points/convert', {
        method: 'POST',
        body: { points: pts, idempotencyKey: uuid() },
      })
      toast.success(d.message)
      setConvertPoints('')
      await load()
      const me = await api<{ user: never }>('/api/auth/me')
      if (me.user) setUser(me.user)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal menukar poin.')
    } finally {
      setConverting(false)
    }
  }

  async function doWithdraw() {
    if (!amount || !method || !rules) return
    setWithdrawing(true)
    try {
      const d = await api<{ processingTime: string }>('/api/withdrawals', {
        method: 'POST',
        body: { amount: Number(amount), method, accountName, accountNumber, confirmAccountNumber: confirmNumber, idempotencyKey: uuid() },
      })
      toast.success(`Pengajuan terkirim. Estimasi proses: ${d.processingTime}.`)
      setAmount('')
      setAccountNumber('')
      setConfirmNumber('')
      await load()
      setTab('history')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal membuat pengajuan.')
    } finally {
      setWithdrawing(false)
    }
  }

  if (!summary || !rules) return <Loading label="Memuat Reward Center..." />

  const fee = rules.fees[method] ?? 0
  const wdAmount = Number(amount) || 0
  const receive = Math.max(0, wdAmount - fee)
  const methodEnabled = rules.methods[method as keyof typeof rules.methods]

  return (
    <div className="float-in">
      <PageHeader title="Reward Center" subtitle="Tukar poin & cairkan saldo hadiah." onBack={() => go('dashboard')} />

      {/* Ringkasan saldo */}
      <div className="mb-5 grid grid-cols-3 gap-3">
        <GlassCard className="p-3.5">
          <p className="text-[10px] uppercase tracking-wider text-white/40">Poin Tersedia</p>
          <p className="mt-1 text-lg font-black text-white">{fmtNum(summary.pointsAvailable)}</p>
          <p className="text-[10px] text-amber-300/70">{rupiah(summary.estimateValue)}</p>
        </GlassCard>
        <GlassCard className="p-3.5">
          <p className="text-[10px] uppercase tracking-wider text-white/40">Saldo Siap Tarik</p>
          <p className="mt-1 text-lg font-black text-emerald-300">{rupiah(summary.wallet.available)}</p>
          <p className="text-[10px] text-white/35">+ pending {fmtNum(summary.pointsPending)} poin</p>
        </GlassCard>
        <GlassCard className="p-3.5">
          <p className="text-[10px] uppercase tracking-wider text-white/40">Diproses / Dibayar</p>
          <p className="mt-1 text-lg font-black text-violet-300">{rupiah(summary.wallet.processing)}</p>
          <p className="text-[10px] text-amber-300/70">total dibayar {rupiah(summary.wallet.totalPaid)}</p>
        </GlassCard>
      </div>

      {/* Tab */}
      <div className="glass mb-4 flex rounded-2xl p-1">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex-1 rounded-xl py-2.5 text-xs font-bold transition ${
              tab === t.key ? 'btn-grad' : 'text-white/50 hover:text-white'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* KONVERSI */}
      {tab === 'convert' && (
        <div className="float-in space-y-4">
          <GlassCard className="p-5">
            <div className="flex items-center justify-between">
              <p className="text-sm font-semibold text-white">Tukar Poin ke Saldo</p>
              <span className="rounded-full bg-amber-400/10 px-3 py-1 text-[11px] font-bold text-amber-300">
                {summary.conversionRate} poin = Rp{summary.conversionRate}
              </span>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-3">
              {summary.conversionOptions.map((opt) => (
                <button
                  key={opt}
                  onClick={() => setConvertPoints(opt)}
                  className={`rounded-2xl border p-4 text-left transition active:scale-[0.98] ${
                    convertPoints === opt
                      ? 'border-amber-400/60 bg-amber-400/10'
                      : 'border-white/10 bg-white/4 hover:border-white/25'
                  }`}
                >
                  <p className="text-sm font-bold text-white">{fmtNum(opt)} poin</p>
                  <p className="gold-text text-xs font-semibold">{rupiah(opt * summary.conversionRate)}</p>
                </button>
              ))}
            </div>

            <div className="mt-4">
              <label htmlFor="custom-convert" className="mb-1.5 block text-xs font-medium text-white/60">
                Atau nominal kustom (kelipatan 100, min {fmtNum(summary.minConvertPoints)} poin)
              </label>
              <input
                id="custom-convert"
                type="number"
                inputMode="numeric"
                className="qe-input"
                placeholder={`Min ${fmtNum(summary.minConvertPoints)}`}
                value={convertPoints}
                onChange={(e) => setConvertPoints(e.target.value === '' ? '' : Number(e.target.value))}
              />
            </div>

            <div className="mt-3 flex items-center justify-between text-xs text-white/45">
              <span>Poin kamu: {fmtNum(summary.pointsAvailable)}</span>
              {convertPoints !== '' && Number(convertPoints) > 0 && (
                <span className="font-semibold text-white/70">
                  = <span className="gold-text">{rupiah(Number(convertPoints) * summary.conversionRate)}</span>
                </span>
              )}
            </div>

            <button
              onClick={doConvert}
              disabled={
                converting ||
                !convertPoints ||
                Number(convertPoints) < summary.minConvertPoints ||
                Number(convertPoints) > summary.pointsAvailable
              }
              className="btn-gold mt-4 w-full rounded-2xl py-3.5 text-sm font-bold"
            >
              {converting ? 'Menukar...' : 'Tukar Sekarang'}
            </button>
            <p className="mt-2.5 text-center text-[11px] leading-relaxed text-white/30">
              Poin belum memenuhi syarat ({fmtNum(summary.pointsPending)}) dirilis otomatis saat sesi kuis selesai.
            </p>
          </GlassCard>
        </div>
      )}

      {/* PENARIKAN */}
      {tab === 'withdraw' && (
        <div className="float-in space-y-4">
          <GlassCard className="p-5">
            <div className="mb-1 flex items-center justify-between">
              <p className="text-sm font-semibold text-white">Cairkan ke Dompet Digital</p>
              <span className={`rounded-full px-3 py-1 text-[10px] font-bold ${
                rules.payoutMode === 'automatic'
                  ? rules.automaticAvailable ? 'bg-emerald-400/15 text-emerald-300' : 'bg-amber-400/15 text-amber-300'
                  : 'bg-sky-400/15 text-sky-300'
              }`}>
                Mode {rules.payoutMode === 'automatic' ? (rules.automaticAvailable ? 'Otomatis (aktif)' : 'Otomatis (provider belum terhubung)') : 'Manual (diverifikasi admin)'}
              </span>
            </div>
            <p className="text-[11px] leading-relaxed text-white/40">
              Saldo akan dipindah ke status diproses saat pengajuan dibuat. Minimal penarikan{' '}
              <b className="text-white/70">{rupiah(rules.minWithdrawal)}</b>.
              Maksimal {summary.withdrawals.maxPending} pengajuan aktif.
            </p>

            <p className="mb-2 mt-5 text-xs font-medium text-white/60">Pilih Metode</p>
            <div className="grid grid-cols-3 gap-3">
              {METHODS.map((m) => {
                const enabled = rules.methods[m.key as keyof typeof rules.methods]
                return (
                  <button
                    key={m.key}
                    onClick={() => enabled && setMethod(m.key)}
                    disabled={!enabled}
                    className={`rounded-2xl border p-3 text-center transition active:scale-[0.98] ${
                      method === m.key && enabled ? 'border-blue-400/60 bg-blue-400/10' : 'border-white/10 bg-white/4'
                    } ${!enabled ? 'cursor-not-allowed opacity-35' : 'hover:border-white/25'}`}
                  >
                    <span className={`mx-auto mb-2 flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br ${m.color} text-[10px] font-black text-white`}>
                      {m.name}
                    </span>
                    <p className="text-[11px] font-semibold text-white/80">{m.name}</p>
                    {!enabled && <p className="text-[9px] text-rose-300">nonaktif</p>}
                  </button>
                )
              })}
            </div>

            <div className="mt-4 space-y-3.5">
              <div>
                <label htmlFor="wd-name" className="mb-1.5 block text-xs font-medium text-white/60">Nama Pemilik Dompet</label>
                <input id="wd-name" className="qe-input" placeholder="Sesuai akun dompet digital" value={accountName} onChange={(e) => setAccountName(e.target.value)} />
              </div>
              <div>
                <label htmlFor="wd-number" className="mb-1.5 block text-xs font-medium text-white/60">Nomor HP Terdaftar</label>
                <input id="wd-number" inputMode="numeric" className="qe-input" placeholder="08xxxxxxxxxx" value={accountNumber} onChange={(e) => setAccountNumber(e.target.value.replace(/\D/g, ''))} />
              </div>
              <div>
                <label htmlFor="wd-confirm" className="mb-1.5 block text-xs font-medium text-white/60">Konfirmasi Nomor</label>
                <input id="wd-confirm" inputMode="numeric" className="qe-input" placeholder="Ulangi nomor" value={confirmNumber} onChange={(e) => setConfirmNumber(e.target.value.replace(/\D/g, ''))} />
                {confirmNumber && confirmNumber !== accountNumber && (
                  <p className="mt-1 text-[10px] text-rose-300">Konfirmasi nomor tidak sama.</p>
                )}
              </div>
              <div>
                <label htmlFor="wd-amount" className="mb-1.5 block text-xs font-medium text-white/60">
                  Jumlah Penarikan (saldo: {rupiah(summary.wallet.available)})
                </label>
                <input
                  id="wd-amount"
                  type="number"
                  inputMode="numeric"
                  className="qe-input"
                  placeholder={`Min ${rules.minWithdrawal.toLocaleString('id-ID')}`}
                  value={amount}
                  onChange={(e) => setAmount(e.target.value === '' ? '' : Number(e.target.value))}
                />
                <div className="mt-2 flex gap-2">
                  {[rules.minWithdrawal, 25000, 50000, 100000].map((v, i) => (
                    <button
                      key={i}
                      onClick={() => setAmount(v)}
                      className="glass flex-1 rounded-lg py-1.5 text-[10px] font-semibold text-white/60 transition hover:text-white"
                    >
                      {fmtNum(v)}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {wdAmount > 0 && (
              <div className="mt-4 space-y-1.5 rounded-xl border border-white/10 bg-white/4 p-4 text-xs">
                <div className="flex justify-between text-white/55"><span>Biaya transaksi</span><span className="font-semibold text-white/80">{fee === 0 ? 'Gratis' : rupiah(fee)}</span></div>
                <div className="flex justify-between text-white/55"><span>Estimasi waktu</span><span className="font-semibold text-white/80">{rules.processingTime[method] ?? '1x24 jam'}</span></div>
                <div className="divider-fade my-2" />
                <div className="flex justify-between"><span className="font-semibold text-white">Diterima</span><span className="gold-text text-base font-black">{rupiah(receive)}</span></div>
              </div>
            )}

            <button
              onClick={doWithdraw}
              disabled={
                withdrawing ||
                !methodEnabled ||
                wdAmount < rules.minWithdrawal ||
                wdAmount > summary.wallet.available ||
                !accountName ||
                accountNumber.length < 9 ||
                accountNumber !== confirmNumber
              }
              className="btn-grad mt-4 w-full rounded-2xl py-3.5 text-sm font-bold"
            >
              {withdrawing ? 'Mengirim...' : 'Ajukan Pencairan'}
            </button>
            {rules.payoutMode === 'automatic' && !rules.automaticAvailable && (
              <p className="mt-2 text-center text-[11px] text-amber-300/80">
                Penyedia disbursement belum terhubung - pengajuan otomatis ditahan sampai tersedia atau diproses manual admin.
              </p>
            )}
          </GlassCard>
        </div>
      )}

      {/* RIWAYAT */}
      {tab === 'history' && (
        <div className="float-in space-y-4">
          <div>
            <p className="mb-2.5 text-sm font-semibold text-white/80">Pencairan</p>
            {!withdrawals ? (
              <Loading label="Memuat..." />
            ) : withdrawals.length === 0 ? (
              <EmptyState title="Belum ada pencairan" description="Ajukan penarikan pertamamu di tab Tarik Dana." />
            ) : (
              <GlassCard className="divide-y divide-white/5 p-1">
                {withdrawals.map((w) => (
                  <div key={w.id} className="px-3 py-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-white">{rupiah(w.amount)}</span>
                      <StatusBadge status={w.status} />
                    </div>
                    <p className="mt-1 text-[11px] text-white/45">
                      {w.method} &middot; {w.accountNumber} &middot; {fmtDateTime(w.createdAt)}
                    </p>
                    {w.reference && (
                      <p className="mt-0.5 text-[10px] text-amber-300/70">Ref: {w.reference}</p>
                    )}
                  </div>
                ))}
              </GlassCard>
            )}
          </div>

          <div>
            <p className="mb-2.5 text-sm font-semibold text-white/80">Penukaran Poin</p>
            {!converts ? (
              <Loading label="Memuat..." />
            ) : converts.length === 0 ? (
              <EmptyState title="Belum ada penukaran" description="Tukar poinmu di tab Konversi." />
            ) : (
              <GlassCard className="divide-y divide-white/5 p-1">
                {converts.map((c) => (
                  <div key={c.id} className="flex items-center justify-between px-3 py-2.5">
                    <div>
                      <p className="text-xs font-semibold text-white/85">-{fmtNum(Math.abs(c.amount))} poin</p>
                      <p className="text-[10px] text-white/30">{fmtDateTime(c.createdAt)}</p>
                    </div>
                    <span className="gold-text text-sm font-bold">{rupiah(Math.abs(c.amount) * summary.conversionRate)}</span>
                  </div>
                ))}
              </GlassCard>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
