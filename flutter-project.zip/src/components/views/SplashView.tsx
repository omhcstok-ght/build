'use client'

import { motion } from 'framer-motion'

export function SplashView() {
  return (
    <main className="qe-bg flex min-h-svh flex-col items-center justify-center">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
        className="flex flex-col items-center"
      >
        <div className="relative">
          <div className="absolute inset-0 -z-10 animate-pulse rounded-3xl bg-blue-500/30 blur-2xl" />
          <div className="glass-strong flex h-24 w-24 items-center justify-center rounded-3xl">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none">
              <defs>
                <linearGradient id="lg" x1="0" y1="0" x2="24" y2="24">
                  <stop offset="0%" stopColor="#7fb0ff" />
                  <stop offset="100%" stopColor="#b18cff" />
                </linearGradient>
              </defs>
              <path d="M20 12a8 8 0 1 1-8-8" stroke="url(#lg)" strokeWidth="2.6" strokeLinecap="round" />
              <path d="M9.5 12l2 2 3.5-4.5" stroke="#f6c453" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M20 4v4h-4" stroke="url(#lg)" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
        </div>
        <h1 className="mt-6 text-3xl font-black tracking-tight">
          <span className="brand-text">QUIZ</span>
          <span className="text-white"> & </span>
          <span className="gold-text">EARN</span>
        </h1>
        <p className="mt-2 text-[11px] font-semibold tracking-[0.3em] text-white/40">
          PLAY SMART, EARN REWARDS
        </p>
      </motion.div>
      <div className="absolute bottom-10 flex items-center gap-2 text-[11px] text-white/30">
        <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-blue-400" />
        Menyiapkan pengalaman terbaikmu...
      </div>
    </main>
  )
}
