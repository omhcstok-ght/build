'use client'

import { useEffect, useState } from 'react'
import { useApp } from '@/lib/store'
import { api, fmtDateTime } from '@/lib/api'
import { EmptyState, GlassCard, Loading, PageHeader } from '@/components/shared'
import { toast } from 'sonner'

type NotificationKind = 'INFO' | 'SUCCESS' | 'WARNING' | 'PROMO'

interface NotificationItem {
  id: string
  title: string
  body: string
  kind: NotificationKind | string
  broadcast: boolean
  createdAt: string
  unread: boolean
}

interface NotificationsData {
  notifications: NotificationItem[]
  unreadCount: number
}

function kindIcon(kind: string) {
  if (kind === 'SUCCESS')
    return (
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-400/10 text-emerald-300">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><path d="M8 12.5l2.5 2.5L16 9.5" /></svg>
      </span>
    )
  if (kind === 'WARNING')
    return (
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-400/10 text-amber-300">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M10.3 3.8L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.8a2 2 0 0 0-3.4 0z" /><path d="M12 9v4M12 17h.01" /></svg>
      </span>
    )
  if (kind === 'PROMO')
    return (
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-violet-400/10 text-violet-300">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 11l18-7-7 18-2.5-8.5L3 11z" /></svg>
      </span>
    )
  return (
    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-blue-400/10 text-blue-300">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><path d="M12 16v-4M12 8h.01" /></svg>
    </span>
  )
}

export function NotificationsView() {
  const { go } = useApp()
  const [data, setData] = useState<NotificationsData | null>(null)
  const [loading, setLoading] = useState(true)
  const [marking, setMarking] = useState(false)

  useEffect(() => {
    let active = true
    api<NotificationsData>('/api/notifications')
      .then((d) => {
        if (active) setData(d)
      })
      .catch((e) => {
        toast.error(e instanceof Error ? e.message : 'Gagal memuat notifikasi.')
      })
      .finally(() => {
        if (active) setLoading(false)
      })
    return () => {
      active = false
    }
  }, [])

  async function markAllRead() {
    if (marking) return
    setMarking(true)
    try {
      await api<{ success: boolean }>('/api/notifications/read', { method: 'POST' })
      setData((prev) =>
        prev
          ? {
              notifications: prev.notifications.map((n) => ({ ...n, unread: false })),
              unreadCount: 0,
            }
          : prev
      )
      toast.success('Semua notifikasi ditandai sudah dibaca.')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal menandai notifikasi.')
    } finally {
      setMarking(false)
    }
  }

  if (loading) return <Loading label="Memuat notifikasi..." />

  const notifications = data?.notifications ?? []
  const unreadCount = data?.unreadCount ?? 0

  return (
    <div className="float-in space-y-5">
      <PageHeader
        title="Notifikasi"
        subtitle={
          unreadCount > 0
            ? `${unreadCount} notifikasi belum dibaca`
            : 'Semua notifikasi sudah dibaca'
        }
        onBack={() => go('dashboard')}
        right={
          <button
            onClick={markAllRead}
            disabled={marking || unreadCount === 0}
            className="btn-grad h-11 shrink-0 rounded-xl px-3 text-xs font-bold disabled:opacity-40"
          >
            {marking ? 'Memproses...' : 'Tandai Dibaca'}
          </button>
        }
      />

      {notifications.length === 0 ? (
        <EmptyState
          icon={
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.7 21a2 2 0 0 1-3.4 0" /></svg>
          }
          title="Belum ada notifikasi"
          description="Pengumuman, status pencairan, dan info hadiah akan muncul di sini."
        />
      ) : (
        <div className="qe-scroll max-h-96 space-y-3 overflow-y-auto pr-1">
          {notifications.map((n) => (
            <GlassCard
              key={n.id}
              className={`p-4 ${n.unread ? 'border-blue-400/25 bg-blue-400/5' : ''}`}
            >
              <div className="flex items-start gap-3">
                {kindIcon(n.kind)}
                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-sm font-semibold text-white">{n.title}</p>
                    {n.unread && (
                      <span
                        aria-label="Belum dibaca"
                        className="pulse-dot mt-1.5 h-2 w-2 shrink-0 rounded-full bg-blue-400"
                      />
                    )}
                  </div>
                  <p className="mt-1 text-xs leading-relaxed text-white/55">{n.body}</p>
                  <div className="mt-2 flex flex-wrap items-center gap-2">
                    {n.broadcast && (
                      <span className="rounded-full border border-violet-400/25 bg-violet-400/10 px-2 py-0.5 text-[9px] font-semibold text-violet-300">
                        Pengumuman
                      </span>
                    )}
                    <span className="text-[10px] text-white/30">{fmtDateTime(n.createdAt)}</span>
                  </div>
                </div>
              </div>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  )
}
