'use client'

import { useEffect, useState } from 'react'
import { useApp } from '@/lib/store'
import { api } from '@/lib/api'
import { GlassCard, PageHeader, Loading, EmptyState } from '@/components/shared'
import { toast } from 'sonner'
import { motion } from 'framer-motion'

interface Category {
  id: string
  name: string
  slug: string
  icon: string
  gradient: string
  description: string
  questionCount: number
  playedCount: number
  bestCorrect: number | null
}

const GRADIENTS: Record<string, string> = {
  blue: 'from-blue-500/30 to-blue-700/10 text-blue-300',
  purple: 'from-violet-500/30 to-violet-700/10 text-violet-300',
  green: 'from-emerald-500/30 to-emerald-700/10 text-emerald-300',
  amber: 'from-amber-500/30 to-amber-700/10 text-amber-300',
  cyan: 'from-cyan-500/30 to-cyan-700/10 text-cyan-300',
  rose: 'from-rose-500/30 to-rose-700/10 text-rose-300',
  gold: 'from-yellow-400/30 to-amber-600/10 text-yellow-300',
  indigo: 'from-indigo-500/30 to-indigo-700/10 text-indigo-300',
}

function CatIcon({ name, className }: { name: string; className?: string }) {
  const common = 'w-6 h-6'
  switch (name) {
    case 'Calculator':
      return <svg className={className ?? common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="2" width="16" height="20" rx="2" /><path d="M8 6h8M8 11h.01M12 11h.01M16 11h.01M8 15h.01M12 15h.01M16 15v4M8 19h4" /></svg>
    case 'FlaskConical':
      return <svg className={className ?? common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10 2v7L4.5 19a2 2 0 0 0 1.8 3h11.4a2 2 0 0 0 1.8-3L14 9V2M8.5 2h7M7 15h10" /></svg>
    case 'Landmark':
      return <svg className={className ?? common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 22h18M6 18v-7M10 18v-7M14 18v-7M18 18v-7M12 2l9 5H3l9-5z" /></svg>
    case 'Cpu':
      return <svg className={className ?? common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="5" y="5" width="14" height="14" rx="2" /><rect x="9" y="9" width="6" height="6" /><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3" /></svg>
    case 'Languages':
      return <svg className={className ?? common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 8l6 6M4 14l6-6 2-3M2 5h12M7 2h1M22 22l-5-10-5 10M14 18h6" /></svg>
    case 'Image':
      return <svg className={className ?? common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="9" cy="9" r="2" /><path d="M21 15l-5-5L5 21" /></svg>
    case 'Globe':
      return <svg className={className ?? common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><path d="M2 12h20M12 2a15 15 0 0 1 4 10 15 15 0 0 1-4 10 15 15 0 0 1-4-10 15 15 0 0 1 4-10z" /></svg>
    default:
      return <svg className={className ?? common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2a7 7 0 0 1 4 12.7c-.6.5-1 1.2-1 2V18a2 2 0 0 1-2 2h-2a2 2 0 0 1-2-2v-1.3c0-.8-.4-1.5-1-2A7 7 0 0 1 12 2zM9 21h6" /></svg>
  }
}

const DIFFS = [
  { key: 'MIXED', label: 'Campuran' },
  { key: 'EASY', label: 'Mudah' },
  { key: 'MEDIUM', label: 'Sedang' },
  { key: 'HARD', label: 'Sulit' },
]

export function QuizView() {
  const { go } = useApp()
  const [cats, setCats] = useState<Category[] | null>(null)
  const [diff, setDiff] = useState('MIXED')
  const [starting, setStarting] = useState<string | null>(null)

  useEffect(() => {
    api<{ categories: Category[] }>('/api/quiz/categories')
      .then((d) => setCats(d.categories))
      .catch((e) => {
        toast.error(e.message)
        setCats([])
      })
  }, [])

  async function start(categoryId: string) {
    if (starting) return
    setStarting(categoryId)
    try {
      const session = await api<{ sessionId: string }>('/api/quiz/start', {
        method: 'POST',
        body: { categoryId, difficulty: diff },
      })
      go('quiz-play', { ...session, difficulty: diff })
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal memulai kuis.')
      setStarting(null)
    }
  }

  return (
    <div className="float-in">
      <PageHeader title="Play Quiz" subtitle="Pilih kategori & tingkat kesulitan. Poin divalidasi server." onBack={() => go('dashboard')} />

      <div className="mb-5 flex gap-2 overflow-x-auto pb-1 qe-scroll">
        {DIFFS.map((d) => (
          <button
            key={d.key}
            onClick={() => setDiff(d.key)}
            className={`shrink-0 rounded-full px-4 py-2 text-xs font-semibold transition ${
              diff === d.key ? 'btn-grad' : 'glass text-white/60 hover:text-white'
            }`}
          >
            {d.label}
          </button>
        ))}
      </div>

      {!cats ? (
        <Loading label="Memuat kategori..." />
      ) : cats.length === 0 ? (
        <EmptyState title="Belum ada kategori aktif" description="Admin belum mengaktifkan kategori kuis." />
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {cats.map((c, i) => (
            <motion.div
              key={c.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.04 }}
            >
              <GlassCard className="flex flex-col gap-3 p-4 transition hover:border-white/20">
                <div className="flex items-start gap-3">
                  <span className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${GRADIENTS[c.gradient] ?? GRADIENTS.blue}`}>
                    <CatIcon name={c.icon} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-bold text-white">{c.name}</p>
                    <p className="mt-0.5 line-clamp-2 text-[11px] leading-relaxed text-white/40">{c.description}</p>
                  </div>
                </div>
                <div className="flex items-center justify-between text-[11px] text-white/40">
                  <span>{c.questionCount} soal</span>
                  {c.bestCorrect !== null && (
                    <span className="text-amber-300/80">Terbaik: {c.bestCorrect} benar</span>
                  )}
                </div>
                <button
                  onClick={() => start(c.id)}
                  disabled={starting !== null}
                  className="btn-grad w-full rounded-xl py-2.5 text-xs font-bold"
                >
                  {starting === c.id ? 'Menyiapkan...' : 'Mulai Main'}
                </button>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  )
}
