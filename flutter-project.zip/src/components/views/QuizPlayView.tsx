'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useApp } from '@/lib/store'
import { api } from '@/lib/api'
import { GlassCard } from '@/components/shared'
import { toast } from 'sonner'
import { AnimatePresence, motion } from 'framer-motion'

interface Q {
  id: string
  text: string
  imageUrl: string | null
  options: string[]
  difficulty: string
}

interface StartPayload {
  sessionId: string
  total: number
  index: number
  timeSeconds: number
  question: Q
}

const DIFF_COLORS: Record<string, string> = {
  EASY: 'bg-emerald-400/15 text-emerald-300',
  MEDIUM: 'bg-amber-400/15 text-amber-300',
  HARD: 'bg-rose-400/15 text-rose-300',
}

export function QuizPlayView() {
  const { viewParams, go } = useApp()
  const router = useRouter()
  const start = viewParams as unknown as StartPayload

  const [question, setQuestion] = useState<Q | null>(start?.question ?? null)
  const [index, setIndex] = useState(start?.index ?? 0)
  const [points, setPoints] = useState(0)
  const [streak, setStreak] = useState(0)
  const [selected, setSelected] = useState<number | null>(null)
  const [correctIndex, setCorrectIndex] = useState<number | null>(null)
  const [answered, setAnswered] = useState(false)
  const [timeLeft, setTimeLeft] = useState(start?.timeSeconds ?? 20)
  const [finishing, setFinishing] = useState(false)

  const timeLimit = start?.timeSeconds ?? 20
  const startedAt = useRef<number>(Date.now())
  const submitting = useRef(false)

  useEffect(() => {
    if (!start?.sessionId) {
      go('quiz')
    }
  }, [start?.sessionId, go])

  const finish = useCallback(
    async (sessionId: string) => {
      setFinishing(true)
      try {
        const result = await api<Record<string, number | boolean>>('/api/quiz/finish', {
          method: 'POST',
          body: { sessionId },
        })
        go('quiz-result', { result, sessionId })
      } catch (e) {
        toast.error(e instanceof Error ? e.message : 'Gagal menyelesaikan sesi.')
        go('quiz')
      }
    },
    [go]
  )

  const submitAnswer = useCallback(
    async (answerIndex: number) => {
      if (!question || !start?.sessionId || submitting.current || answered || finishing) return
      submitting.current = true
      setSelected(answerIndex)
      const timeMs = Date.now() - startedAt.current
      try {
        const d = await api<{
          isCorrect: boolean
          correctIndex: number
          explanation: string | null
          pointsAwarded: number
          streak: number
          streakHit: boolean
          hasNext: boolean
          nextQuestion: Q | null
          index: number
        }>('/api/quiz/answer', {
          method: 'POST',
          body: { sessionId: start.sessionId, questionId: question.id, answerIndex, timeMs },
        })
        setCorrectIndex(d.correctIndex)
        setAnswered(true)
        setPoints((p) => p + d.pointsAwarded)
        setStreak(d.streak)

        const delay = d.hasNext ? 1400 : 1100
        setTimeout(() => {
          if (d.hasNext && d.nextQuestion) {
            setQuestion(d.nextQuestion)
            setIndex(d.index)
            setSelected(null)
            setCorrectIndex(null)
            setAnswered(false)
            setTimeLeft(timeLimit)
            startedAt.current = Date.now()
            submitting.current = false
          } else {
            finish(start.sessionId)
          }
        }, delay)
      } catch (e) {
        toast.error(e instanceof Error ? e.message : 'Gagal mengirim jawaban.')
        submitting.current = false
      }
    },
    [question, start?.sessionId, answered, finishing, timeLimit, finish]
  )

  // Timer
  useEffect(() => {
    if (answered || finishing) return
    const t = setInterval(() => {
      setTimeLeft((v) => {
        if (v <= 1) {
          clearInterval(t)
          void submitAnswer(-1)
          return 0
        }
        return v - 1
      })
    }, 1000)
    return () => clearInterval(t)
  }, [answered, finishing, submitAnswer])

  if (!question || !start?.sessionId) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="h-10 w-10 animate-spin rounded-full border-2 border-white/10 border-t-blue-400" />
      </div>
    )
  }

  const timePct = (timeLeft / timeLimit) * 100
  const isTimeout = answered && selected === -1

  return (
    <div className="float-in flex min-h-[calc(100svh-9rem)] flex-col">
      {/* Header sesi */}
      <div className="mb-4 flex items-center justify-between gap-3">
        <button
          onClick={() => {
            if (confirm('Keluar dari sesi? Poin sesi ini tidak akan dirilis.')) {
              router.back()
              go('quiz')
            }
          }}
          className="glass flex h-9 w-9 items-center justify-center rounded-full text-white/60 transition hover:text-white"
          aria-label="Keluar sesi"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12" /></svg>
        </button>
        <div className="flex items-center gap-2 text-xs font-semibold">
          <span className="glass rounded-full px-3 py-1.5 text-white/70">
            Soal {index + 1}/{start.total}
          </span>
          <span className="glass rounded-full px-3 py-1.5 text-amber-300">+{points} poin</span>
          {streak >= 2 && (
            <motion.span
              initial={{ scale: 0.6 }}
              animate={{ scale: 1 }}
              className="rounded-full bg-orange-500/20 px-3 py-1.5 text-orange-300"
            >
              Streak {streak}x
            </motion.span>
          )}
        </div>
      </div>

      {/* Timer bar */}
      <div className="mb-5 h-1.5 w-full overflow-hidden rounded-full bg-white/8">
        <div
          className={`h-full rounded-full transition-all duration-1000 ease-linear ${
            timeLeft > 5 ? 'bg-gradient-to-r from-blue-500 to-violet-500' : 'bg-gradient-to-r from-rose-500 to-orange-500'
          }`}
          style={{ width: `${answered ? 0 : timePct}%` }}
        />
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={question.id}
          initial={{ opacity: 0, x: 24 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -24 }}
          transition={{ duration: 0.25 }}
          className="flex flex-1 flex-col"
        >
          {/* Kartu soal */}
          <GlassCard className="p-5">
            <div className="mb-3 flex items-center gap-2">
              <span className={`rounded-full px-2.5 py-0.5 text-[10px] font-bold ${DIFF_COLORS[question.difficulty] ?? DIFF_COLORS.EASY}`}>
                {question.difficulty}
              </span>
              <span className="text-[10px] text-white/30">Sisa {timeLeft} detik</span>
            </div>
            {question.imageUrl && (
              <div className="mb-4 overflow-hidden rounded-xl border border-white/10">
                <img src={question.imageUrl} alt="Gambar soal" className="max-h-56 w-full object-cover" />
              </div>
            )}
            <p className="text-base font-semibold leading-relaxed text-white">{question.text}</p>
          </GlassCard>

          {/* Pilihan jawaban */}
          <div className="mt-4 grid gap-3">
            {question.options.map((opt, i) => {
              const isPicked = selected === i
              const isRight = answered && i === correctIndex
              const isWrongPick = answered && isPicked && i !== correctIndex
              return (
                <button
                  key={i}
                  onClick={() => submitAnswer(i)}
                  disabled={answered}
                  className={`glass flex items-center gap-3 rounded-2xl p-4 text-left transition-all active:scale-[0.99] ${
                    isRight
                      ? '!border-emerald-400/60 !bg-emerald-400/15'
                      : isWrongPick
                        ? '!border-rose-400/60 !bg-rose-400/15'
                        : isPicked
                          ? '!border-blue-400/60 !bg-blue-400/15'
                          : 'hover:border-white/25 hover:bg-white/8'
                  } ${answered && !isRight && !isWrongPick ? 'opacity-40' : ''}`}
                >
                  <span
                    className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-sm font-black ${
                      isRight ? 'bg-emerald-400 text-emerald-950' : isWrongPick ? 'bg-rose-400 text-rose-950' : 'bg-white/10 text-white/80'
                    }`}
                  >
                    {isRight ? (
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5" /></svg>
                    ) : isWrongPick ? (
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12" /></svg>
                    ) : (
                      String.fromCharCode(65 + i)
                    )}
                  </span>
                  <span className="text-sm font-medium text-white/90">{opt}</span>
                </button>
              )
            })}
          </div>

          {/* Feedback */}
          <div className="mt-4 min-h-12">
            {answered && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className={`rounded-xl border px-4 py-3 text-xs leading-relaxed ${
                  isTimeout
                    ? 'border-rose-400/30 bg-rose-400/10 text-rose-200'
                    : correctIndex === selected
                      ? 'border-emerald-400/30 bg-emerald-400/10 text-emerald-200'
                      : 'border-rose-400/30 bg-rose-400/10 text-rose-200'
                }`}
              >
                {isTimeout
                  ? 'Waktu habis!'
                  : correctIndex === selected
                    ? 'Benar! Poin dikreditkan ke saldo pending-mu.'
                    : 'Belum tepat. Semangat, lanjut ke soal berikutnya!'}
              </motion.div>
            )}
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  )
}
