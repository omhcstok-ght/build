'use client'

import { useEffect, useState } from 'react'
import { useApp } from '@/lib/store'
import { api, fmtDateTime } from '@/lib/api'
import { GlassCard, PageHeader, Loading, EmptyState } from '@/components/shared'
import { toast } from 'sonner'

interface AdStatus {
  configured: boolean
  network: string
  adUnitIdMasked: string
  callbackSecretSet: boolean
  dailyLimit: number
  rewardPoints: number
  watchedToday: number
  remaining: number
  allowDevSim: boolean
  requirements: string[]
}

interface AdHistoryTx {
  id: string
  type: string
  amount: number
  createdAt: string
  meta: { network?: string; devSim?: boolean } | null
}

export function WatchEarnView() {
  const { go } = useApp()
  const [status, setStatus] = useState<AdStatus | null>(null)
  const [events, setEvents] = useState<AdHistoryTx[] | null>(null)
  const [busy, setBusy] = useState(false)

  async function load() {
    try {
      const [s, h] = await Promise.all([
        api<AdStatus>('/api/ads/status'),
        api<{ transactions: AdHistoryTx[] }>('/api/points/history?limit=100'),
      ])
      const e = { events: (h.transactions ?? []).filter((t) => t.type === 'EARN_AD').slice(0, 10) }
      setStatus(s)
      setEvents(e.events)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Gagal memuat status iklan.')
      setStatus(null)
      setEvents([])
    }
  }

  useEffect(() => {
    load()
  }, [])

  async function startAdSession() {
    if (busy) return
    setBusy(true)
    try {
      await api('/api/ads/session', { method: 'POST', body: {} })
      // Bila SDK jaringan iklan terpasang, iklan diputar di sini;
      // reward diberikan melalui callback SSV server-to-server.
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Sesi iklan gagal dibuat.')
    } finally {
      setBusy(false)
    }
  }

  async function devSim() {
    if (busy) return
    setBusy(true)
    try {
      const d = await api<{ rewarded: number }>('/api/ads/dev-sim', { method: 'POST', body: {} })
      toast.success(`Reward simulasi +${d.rewarded} poin diterima (MODE PENGEMBANGAN).`)
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Simulasi gagal.')
    } finally {
      setBusy(false)
    }
  }

  if (!status) return <Loading label="Memuat status iklan..." />

  return (
    <div className="float-in">
      <PageHeader title="Watch & Earn" subtitle="Tonton iklan berhadiah dengan verifikasi server." onBack={() => go('dashboard')} />

      {/* Status jaringan iklan */}
      <div
        className={`relative overflow-hidden rounded-3xl border p-5 ${
          status.configured
            ? 'border-emerald-400/30 bg-gradient-to-br from-emerald-900/40 via-[#101a3c] to-[#141530]'
            : 'border-amber-400/25 bg-gradient-to-br from-amber-950/40 via-[#141530] to-[#101a3c]'
        }`}
      >
        <div className="flex items-start gap-4">
          <span
            className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl ${
              status.configured ? 'bg-emerald-400/15 text-emerald-300' : 'bg-amber-400/15 text-amber-300'
            }`}
          >
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="2" y="5" width="20" height="14" rx="3" />
              <path d="M10 9.5l5 2.5-5 2.5z" />
            </svg>
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white">
                {status.configured ? `Siap - ${status.network}` : 'Iklan Belum Tersedia'}
              </h2>
              <span className={`pulse-dot h-2 w-2 rounded-full ${status.configured ? 'bg-emerald-400' : 'bg-amber-400'}`} />
            </div>
            <p className="mt-1 text-xs leading-relaxed text-white/50">
              {status.configured
                ? `Unit iklan ${status.adUnitIdMasked || '-'} aktif. Poin diberikan HANYA setelah callback verifikasi server valid.`
                : 'Jaringan iklan berhadiah belum terhubung. Kami tidak menampilkan pendapatan iklan palsu - sistem reward akan aktif setelah integrasi resmi.'}
            </p>
          </div>
        </div>

        <div className="mt-4 flex items-center gap-3">
          <div className="flex-1">
            <div className="mb-1 flex justify-between text-[11px] text-white/50">
              <span>Iklan hari ini</span>
              <span>{status.watchedToday}/{status.dailyLimit}</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-white/8">
              <div
                className="h-full rounded-full bg-gradient-to-r from-violet-500 to-blue-500 transition-all"
                style={{ width: `${Math.min(100, (status.watchedToday / Math.max(1, status.dailyLimit)) * 100)}%` }}
              />
            </div>
          </div>
          <span className="glass rounded-full px-3 py-1.5 text-[11px] font-bold text-amber-300">
            +{status.rewardPoints} poin/iklan
          </span>
        </div>

        {status.configured && status.remaining > 0 && (
          <button onClick={startAdSession} disabled={busy} className="btn-grad mt-4 w-full rounded-2xl py-3.5 text-sm font-bold">
            {busy ? 'Menyiapkan iklan...' : 'Tonton Iklan Berhadiah'}
          </button>
        )}
      </div>

      {/* Persyaratan integrasi */}
      {!status.configured && (
        <GlassCard className="mt-4 p-5">
          <p className="mb-3 text-xs font-bold uppercase tracking-wider text-white/60">Syarat Aktivasi Reward Iklan</p>
          <ul className="space-y-2.5">
            {status.requirements.map((r, i) => (
              <li key={i} className="flex items-start gap-2.5 text-xs leading-relaxed text-white/50">
                <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-white/10 text-[9px] font-bold text-white/60">
                  {i + 1}
                </span>
                {r}
              </li>
            ))}
          </ul>
          <p className="mt-4 rounded-xl border border-white/10 bg-white/5 px-3.5 py-2.5 text-[11px] leading-relaxed text-white/40">
            Prinsip kebijakan kami: tanpa paksaan klik, tanpa traffic palsu, tanpa reward untuk
            aktivitas yang melanggar kebijakan penyedia iklan. Poin hanya dari verifikasi server.
          </p>
        </GlassCard>
      )}

      {/* Simulasi mode pengembangan */}
      {status.allowDevSim && (
        <div className="mt-4 rounded-2xl border border-rose-400/30 bg-rose-950/30 p-4">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="flex items-center gap-2 text-xs font-bold text-rose-200">
                <span className="rounded bg-rose-400/20 px-1.5 py-0.5 text-[9px]">MODE PENGEMBANGAN</span>
                Simulasi Reward Iklan
              </p>
              <p className="mt-1 text-[11px] leading-relaxed text-rose-200/60">
                Uji alur reward tanpa jaringan iklan. Dinonaktifkan otomatis di produksi & dapat dimatikan admin.
              </p>
            </div>
            <button onClick={devSim} disabled={busy} className="shrink-0 rounded-xl border border-rose-400/40 px-4 py-2.5 text-xs font-bold text-rose-200 transition hover:bg-rose-400/10 active:scale-95">
              {busy ? '...' : 'Simulasikan'}
            </button>
          </div>
        </div>
      )}

      {/* Cara kerja */}
      <GlassCard className="mt-4 p-5">
        <p className="mb-3 text-xs font-bold uppercase tracking-wider text-white/60">Cara Kerja</p>
        <ol className="space-y-2.5 text-xs leading-relaxed text-white/50">
          <li><b className="text-white/75">1.</b> Server membuat sesi iklan dengan ID unik.</li>
          <li><b className="text-white/75">2.</b> Kamu menonton iklan rewarded dari jaringan resmi.</li>
          <li><b className="text-white/75">3.</b> Jaringan iklan mengirim konfirmasi ke server kami (SSV callback + signature).</li>
          <li><b className="text-white/75">4.</b> Poin dikreditkan otomatis setelah verifikasi lolos - sekali per iklan.</li>
        </ol>
      </GlassCard>

      {/* Riwayat */}
      <div className="mt-5">
        <p className="mb-3 text-sm font-semibold text-white/80">Riwayat Reward Iklan</p>
        {!events ? (
          <Loading label="Memuat riwayat..." />
        ) : events.length === 0 ? (
          <EmptyState title="Belum ada reward iklan" description="Reward akan muncul di sini setelah sistem iklan aktif." />
        ) : (
          <GlassCard className="divide-y divide-white/5 p-1">
            {events.map((ev) => (
              <div key={ev.id} className="flex items-center gap-3 px-3 py-2.5">
                <span className={`rounded-full px-2 py-0.5 text-[9px] font-bold ${ev.meta?.devSim ? 'bg-rose-400/15 text-rose-300' : 'bg-emerald-400/15 text-emerald-300'}`}>
                  {ev.meta?.devSim ? 'SIMULASI' : 'IKLAN'}
                </span>
                <span className="flex-1 text-xs text-white/60">+{ev.amount} poin</span>
                <span className="text-[10px] text-white/25">{fmtDateTime(ev.createdAt)}</span>
              </div>
            ))}
          </GlassCard>
        )}
      </div>
    </div>
  )
}
