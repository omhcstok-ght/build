'use client'

import { useCallback, useEffect, useState } from 'react'
import { useApp } from '@/lib/store'
import { api, rupiah, fmtNum, fmtDateTime } from '@/lib/api'
import {
  EmptyState,
  GlassCard,
  Loading,
  PageHeader,
  StatusBadge,
  StatTile,
} from '@/components/shared'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { toast } from 'sonner'

type HistoryTab = 'quiz' | 'points' | 'withdrawals'

interface QuizSession {
  id: string
  category: string
  icon: string
  difficulty: string
  status: string
  correctCount: number
  total: number
  pointsEarned: number
  bestStreak: number
  startedAt: string
}

interface QuizHistoryData {
  sessions: QuizSession[]
  stats: { totalPlayed: number; totalCorrect: number; totalPoints: number }
}

interface PointTransaction {
  id: string
  type: string
  bucket: 'PENDING' | 'AVAILABLE'
  amount: number
  meta: string | null
  sessionId: string | null
  createdAt: string
}

interface PointsHistoryData {
  transactions: PointTransaction[]
}

interface Withdrawal {
  id: string
  amount: number
  fee: number
  method: string
  accountName: string
  accountNumber: string
  status: string
  reference: string | null
  createdAt: string
}

interface WithdrawalsData {
  withdrawals: Withdrawal[]
}

const TYPE_LABEL: Record<string, string> = {
  EARN_QUIZ: 'Jawaban benar',
  EARN_STREAK: 'Bonus streak',
  EARN_COMPLETION: 'Bonus penyelesaian',
  EARN_PERFECT: 'Bonus skor sempurna',
  EARN_MISSION: 'Hadiah misi',
  EARN_BONUS: 'Lucky bonus',
  EARN_AD: 'Reward iklan',
  RELEASE: 'Poin dirilis ke saldo tersedia',
  CONVERT_OUT: 'Tukar poin ke saldo hadiah',
  ADJUST: 'Penyesuaian admin',
}

const DIFFICULTY_LABEL: Record<string, string> = {
  EASY: 'Mudah',
  MEDIUM: 'Sedang',
  HARD: 'Sulit',
}

function listIcon(type: string) {
  if (type.startsWith('EARN'))
    return (
      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-400/10 text-emerald-300">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M12 19V5M5 12l7-7 7 7" /></svg>
      </span>
    )
  if (type === 'CONVERT_OUT')
    return (
      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-amber-400/10 text-amber-300">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M6 3h12M6 8h12M6 13l6 8 6-8H6z" /></svg>
      </span>
    )
  return (
    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-white/10 text-white/50">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 3" /></svg>
    </span>
  )
}

function accuracy(correct: number, total: number): string {
  if (total <= 0) return '0%'
  return `${Math.round((correct / total) * 100)}%`
}

export function HistoryView() {
  const { go, viewParams } = useApp()
  const rawTab = viewParams.tab
  const initialTab: HistoryTab = rawTab === 'points' || rawTab === 'withdrawals' ? rawTab : 'quiz'

  const [tab, setTab] = useState<HistoryTab>(initialTab)
  const [loading, setLoading] = useState(true)
  const [failed, setFailed] = useState(false)
  const [quiz, setQuiz] = useState<QuizHistoryData | null>(null)
  const [points, setPoints] = useState<PointsHistoryData | null>(null)
  const [withdrawals, setWithdrawals] = useState<WithdrawalsData | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    setFailed(false)
    try {
      const [q, p, w] = await Promise.all([
        api<QuizHistoryData>('/api/quiz/history?limit=20'),
        api<PointsHistoryData>('/api/points/history?limit=50'),
        api<WithdrawalsData>('/api/withdrawals'),
      ])
      setQuiz(q)
      setPoints(p)
      setWithdrawals(w)
    } catch (e) {
      setFailed(true)
      toast.error(e instanceof Error ? e.message : 'Gagal memuat riwayat.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  if (loading) return <Loading label="Memuat riwayat..." />

  return (
    <div className="float-in space-y-5">
      <PageHeader title="Riwayat" subtitle="Rekap kuis, poin, dan pencairan" onBack={() => go('dashboard')} />

      {failed && (
        <GlassCard className="p-4">
          <button onClick={() => void load()} className="btn-grad h-11 w-full rounded-xl text-sm font-bold">
            Coba Muat Ulang
          </button>
        </GlassCard>
      )}

      <Tabs value={tab} onValueChange={(v) => setTab(v as HistoryTab)}>
        <TabsList className="glass h-11 w-full rounded-xl border-white/10 p-1">
          <TabsTrigger value="quiz" className="h-9 flex-1 rounded-lg text-xs data-[state=active]:bg-white/10 data-[state=active]:text-white">
            Kuis
          </TabsTrigger>
          <TabsTrigger value="points" className="h-9 flex-1 rounded-lg text-xs data-[state=active]:bg-white/10 data-[state=active]:text-white">
            Poin
          </TabsTrigger>
          <TabsTrigger value="withdrawals" className="h-9 flex-1 rounded-lg text-xs data-[state=active]:bg-white/10 data-[state=active]:text-white">
            Pencairan
          </TabsTrigger>
        </TabsList>

        {/* TAB KUIS */}
        <TabsContent value="quiz" className="mt-4 space-y-4">
          {quiz && (
            <div className="grid grid-cols-3 gap-3">
              <StatTile label="Dimainkan" value={fmtNum(quiz.stats.totalPlayed)} />
              <StatTile label="Jawaban Benar" value={fmtNum(quiz.stats.totalCorrect)} />
              <StatTile label="Poin Didapat" value={fmtNum(quiz.stats.totalPoints)} gold />
            </div>
          )}
          {!quiz || quiz.sessions.length === 0 ? (
            <EmptyState
              icon={
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01" /></svg>
              }
              title="Belum ada riwayat kuis"
              description="Mainkan kuis pertamamu untuk mulai mengumpulkan poin dan hadiah."
            />
          ) : (
            <div className="qe-scroll max-h-96 space-y-3 overflow-y-auto pr-1">
              {quiz.sessions.map((s) => (
                <GlassCard key={s.id} className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-white">{s.category}</p>
                      <p className="mt-0.5 text-[11px] text-white/40">
                        {DIFFICULTY_LABEL[s.difficulty] ?? s.difficulty} · {fmtDateTime(s.startedAt)}
                      </p>
                    </div>
                    <StatusBadge status={s.status} />
                  </div>
                  <div className="mt-3 flex items-center justify-between text-xs">
                    <span className="text-white/50">
                      Akurasi <b className="text-white/85">{s.correctCount}/{s.total}</b> ({accuracy(s.correctCount, s.total)})
                    </span>
                    <span className="flex items-center gap-1 font-bold text-amber-300">
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2l2.6 6.6L21 11l-6.4 2.4L12 20l-2.6-6.6L3 11l6.4-2.4L12 2z" /></svg>
                      +{fmtNum(s.pointsEarned)}
                    </span>
                  </div>
                  <p className="mt-1.5 text-[11px] text-white/35">Streak terbaik: {fmtNum(s.bestStreak)} jawaban beruntun</p>
                </GlassCard>
              ))}
            </div>
          )}
        </TabsContent>

        {/* TAB POIN */}
        <TabsContent value="points" className="mt-4">
          {!points || points.transactions.length === 0 ? (
            <EmptyState
              icon={
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2l2.6 6.6L21 11l-6.4 2.4L12 20l-2.6-6.6L3 11l6.4-2.4L12 2z" /></svg>
              }
              title="Belum ada transaksi poin"
              description="Poin dari kuis, misi, dan bonus akan tercatat di sini."
            />
          ) : (
            <GlassCard className="divide-y divide-white/5 p-1">
              <div className="qe-scroll max-h-96 overflow-y-auto">
                {points.transactions.map((t) => {
                  const debit = t.amount < 0
                  return (
                    <div key={t.id} className="flex items-center gap-3 px-3 py-3">
                      {listIcon(t.type)}
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <p className="text-xs font-medium text-white/85">{TYPE_LABEL[t.type] ?? t.type}</p>
                          <span
                            className={`rounded-full border px-1.5 py-0.5 text-[9px] font-semibold ${
                              t.bucket === 'PENDING'
                                ? 'border-amber-400/25 bg-amber-400/10 text-amber-300'
                                : 'border-emerald-400/25 bg-emerald-400/10 text-emerald-300'
                            }`}
                          >
                            {t.bucket}
                          </span>
                        </div>
                        <p className="mt-0.5 text-[10px] text-white/30">{fmtDateTime(t.createdAt)}</p>
                      </div>
                      <span className={`shrink-0 text-sm font-bold ${debit ? 'text-rose-300' : 'text-emerald-300'}`}>
                        {debit ? '' : '+'}
                        {fmtNum(t.amount)}
                      </span>
                    </div>
                  )
                })}
              </div>
            </GlassCard>
          )}
        </TabsContent>

        {/* TAB PENCAIRAN */}
        <TabsContent value="withdrawals" className="mt-4">
          {!withdrawals || withdrawals.withdrawals.length === 0 ? (
            <EmptyState
              icon={
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="5" width="20" height="14" rx="3" /><path d="M2 10h20" /></svg>
              }
              title="Belum ada pencairan"
              description="Tukar poin ke saldo hadiah, lalu ajukan pencairan pertamamu di Reward Center."
            />
          ) : (
            <div className="qe-scroll max-h-96 space-y-3 overflow-y-auto pr-1">
              {withdrawals.withdrawals.map((w) => (
                <GlassCard key={w.id} className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-base font-bold text-emerald-300">{rupiah(w.amount)}</p>
                      <p className="mt-0.5 text-[11px] text-white/40">
                        {w.method} · {w.accountName}
                      </p>
                      <p className="text-[11px] text-white/30">{w.accountNumber}</p>
                    </div>
                    <StatusBadge status={w.status} />
                  </div>
                  <div className="divider-fade my-3" />
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-white/40">
                      Biaya {rupiah(w.fee)} · {fmtDateTime(w.createdAt)}
                    </span>
                    {w.reference && <span className="truncate text-white/50">Ref: {w.reference}</span>}
                  </div>
                </GlassCard>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
