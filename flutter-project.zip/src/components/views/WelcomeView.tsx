'use client'

import { motion } from 'framer-motion'
import { useApp } from '@/lib/store'
import { GlassCard } from '@/components/shared'

const FEATURES = [
  {
    title: 'Play Quiz',
    desc: '8 kategori, 3 tingkat kesulitan, poin dihitung & divalidasi server.',
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10" />
        <path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01" />
      </svg>
    ),
  },
  {
    title: 'Watch & Earn',
    desc: 'Iklan berhadiah dengan verifikasi server. Tanpa reward palsu.',
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="5" width="20" height="14" rx="3" />
        <path d="M10 9.5l5 2.5-5 2.5z" />
      </svg>
    ),
  },
  {
    title: 'Tarik Hadiah',
    desc: 'Konversi poin ke saldo, cair ke DANA, OVO, atau GoPay.',
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M6 3h12M6 8h12M6 13l6 8 6-8H6z" />
      </svg>
    ),
  },
]

export function WelcomeView() {
  const go = useApp((s) => s.go)

  return (
    <main className="qe-bg relative flex min-h-svh flex-col overflow-hidden">
      <div className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-blue-600/20 blur-3xl" />
      <div className="pointer-events-none absolute bottom-10 -right-20 h-72 w-72 rounded-full bg-violet-600/20 blur-3xl" />

      <div className="mx-auto flex w-full max-w-md flex-1 flex-col px-5 pt-16">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex items-center gap-3"
        >
          <div className="glass-strong flex h-14 w-14 items-center justify-center rounded-2xl">
            <svg width="30" height="30" viewBox="0 0 24 24" fill="none">
              <path d="M20 12a8 8 0 1 1-8-8" stroke="#7fb0ff" strokeWidth="2.6" strokeLinecap="round" />
              <path d="M9.5 12l2 2 3.5-4.5" stroke="#f6c453" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M20 4v4h-4" stroke="#b18cff" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <div>
            <h1 className="text-2xl font-black tracking-tight">
              <span className="brand-text">QUIZ</span>
              <span className="text-white"> & </span>
              <span className="gold-text">EARN</span>
            </h1>
            <p className="text-[10px] font-semibold tracking-[0.28em] text-white/40">
              PLAY SMART, EARN REWARDS
            </p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15, duration: 0.5 }}
          className="mt-10"
        >
          <h2 className="text-[26px] font-bold leading-snug text-white">
            Ubah waktumu jadi <span className="gold-text">hadiah nyata</span>.
          </h2>
          <p className="mt-3 text-sm leading-relaxed text-white/55">
            Jawab kuis, kumpulkan poin, tukarkan menjadi saldo, dan tarik ke dompet digital.
            Semua transaksi dicatat pada buku besar yang dapat diaudit.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="mt-8 space-y-3"
        >
          {FEATURES.map((f) => (
            <GlassCard key={f.title} className="flex items-center gap-4 p-4">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500/20 to-violet-500/20 text-blue-300">
                {f.icon}
              </div>
              <div>
                <p className="text-sm font-semibold text-white">{f.title}</p>
                <p className="text-xs leading-relaxed text-white/45">{f.desc}</p>
              </div>
            </GlassCard>
          ))}
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.45, duration: 0.5 }}
        className="mx-auto w-full max-w-md px-5 pb-10 pt-8"
      >
        <button
          onClick={() => go('register')}
          className="btn-grad w-full rounded-2xl py-3.5 text-sm font-bold"
        >
          Buat Akun Gratis
        </button>
        <button
          onClick={() => go('login')}
          className="glass mt-3 w-full rounded-2xl py-3.5 text-sm font-bold text-white transition hover:bg-white/10 active:scale-[0.98]"
        >
          Masuk
        </button>
        <p className="mt-5 text-center text-[11px] leading-relaxed text-white/30">
          Dengan melanjutkan, kamu menyetujui Syarat &amp; Ketentuan serta Kebijakan Privasi kami.
        </p>
        <div className="mt-4 text-center">
          <button
            onClick={() => go('admin')}
            className="text-[11px] text-white/25 underline-offset-2 hover:text-white/50 hover:underline"
          >
            Portal Administrator
          </button>
        </div>
      </motion.div>
    </main>
  )
}
