'use client'

/**
 * Panel Administrator - QUIZ & EARN
 * Standalone view (tidak dibungkus AppShell). Login admin via kuki.
 * Semua data diambil dari /api/admin/* melalui api<T>().
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
  Activity,
  Ban,
  Bell,
  BookOpen,
  Coins,
  FolderOpen,
  Landmark,
  LayoutDashboard,
  LogOut,
  Megaphone,
  RefreshCw,
  Settings,
  ShieldAlert,
  Users,
  Wallet,
  Zap,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { toast } from 'sonner'
import { api, clearAdminToken, fmtDateTime, fmtNum, rupiah, saveAdminToken } from '@/lib/api'
import { useApp } from '@/lib/store'
import { cn } from '@/lib/utils'
import {
  Avatar,
  EmptyState,
  GlassCard,
  Loading,
  ProgressBar,
  SectionTitle,
  StatTile,
  StatusBadge,
} from '@/components/shared'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'

// ============================================================
// TYPES
// ============================================================

type SectionKey =
  | 'overview'
  | 'users'
  | 'categories'
  | 'questions'
  | 'withdrawals'
  | 'finance'
  | 'ads'
  | 'settings'
  | 'audit'
  | 'support'

interface OverviewData {
  users: { total: number; today: number; blocked: number }
  sessions: { today: number; active: number }
  pointsIssuedToday: number
  pointsConvertedTotal: number
  withdrawals: { status: string; count: number; amount: number }[]
  paidTotal: number
  paidCount: number
  adEvents: number
  fraudEvents: number
  supportOpen: number
  revenue: {
    capital: number
    adRevenue: number
    sponsorRevenue: number
    prizePayout: number
    adjustment: number
    budget: number
  }
  chart: { date: string; points: number; withdrawals: number }[]
}

interface AdminUser {
  id: string
  name: string
  username: string
  email: string
  avatar: string | null
  isBlocked: boolean
  blockReason: string | null
  emailVerified: boolean
  pointsPending: number
  pointsAvailable: number
  wallet: { available: number; processing: number; totalPaid: number } | null
  quizzes: number
  withdrawals: number
  fraudCount: number
  lastLoginAt: string | null
  createdAt: string
}

interface UsersData {
  page: number
  pageSize: number
  total: number
  users: AdminUser[]
}

interface AdminCategory {
  id: string
  name: string
  slug: string
  icon: string
  gradient: string
  description: string | null
  isActive: boolean
  sortOrder: number
  questionCount: number
}

interface AdminQuestion {
  id: string
  categoryId: string
  categoryName: string
  difficulty: string
  text: string
  imageUrl: string | null
  options: string[]
  correctIndex: number
  explanation: string | null
  isActive: boolean
}

interface QuestionsData {
  page: number
  pageSize: number
  total: number
  categories: { id: string; name: string; isActive: boolean }[]
  questions: AdminQuestion[]
}

interface AdminWithdrawal {
  id: string
  user: { name: string; username: string; email: string; isBlocked: boolean }
  amount: number
  fee: number
  method: string
  accountName: string
  accountNumber: string
  status: string
  mode: string
  reference: string | null
  adminNote: string | null
  processedAt: string | null
  createdAt: string
}

interface WithdrawalsData {
  withdrawals: AdminWithdrawal[]
  prizeBudget: number
  payoutMode: string
  automaticAvailable: boolean
}

interface LedgerEntry {
  id: string
  type: string
  amount: number
  balanceAfter: number
  note: string | null
  createdBy: string
  createdAt: string
}

interface CapitalSummary {
  capital: number
  adRevenue: number
  sponsorRevenue: number
  prizePayout: number
  adjustment: number
  budget: number
}

interface CapitalData {
  summary: CapitalSummary
  capital: { id: string; amount: number; source: string; note: string | null; createdBy: string; createdAt: string }[]
  ledger: LedgerEntry[]
}

interface RevenueData {
  ledger: LedgerEntry[]
  adEvents: {
    id: string
    network: string
    status: string
    pointsAwarded: number
    createdAt: string
    user: { username: string }
  }[]
}

interface Campaign {
  id: string
  title: string
  budget: number
  fundedAmount: number
  status: string
}

interface Sponsor {
  id: string
  name: string
  logoUrl: string | null
  contact: string | null
  notes: string | null
  isActive: boolean
  campaigns: Campaign[]
}

interface AdsData {
  configured: boolean
  network: string
  adUnitId: string
  networkType: 'ADMOB' | 'CUSTOM'
  ssvCallbackPath: string
  callbackSecretSet: boolean
  dailyAdLimit: number
  adRewardPoints: number
  allowDevSim: boolean
}

interface SettingsData {
  settings: Record<string, string>
  allowedKeys: string[]
  automaticPayout: { disburseUrl: boolean; disburseKey: boolean; webhookSecret: boolean }
}

interface AuditLog {
  id: string
  adminName: string
  action: string
  targetType: string
  targetId: string
  detail: string | null
  createdAt: string
}

interface AuditData {
  page: number
  total: number
  logs: AuditLog[]
}

interface FraudEvent {
  id: string
  type: string
  detail: string | null
  severity: string
  createdAt: string
  user: { username: string; name: string; isBlocked: boolean } | null
}

interface FraudData {
  page: number
  total: number
  events: FraudEvent[]
}

interface SupportMessage {
  id: string
  name: string
  email: string
  category: string
  subject: string
  message: string
  status: string
  createdAt: string
}

interface NotifAdminData {
  sent: { id: string; title: string; body: string; kind: string; createdAt: string }[]
  support: SupportMessage[]
}

// ============================================================
// KONSTANTA
// ============================================================

const SECTIONS: { key: SectionKey; label: string; icon: LucideIcon }[] = [
  { key: 'overview', label: 'Overview', icon: LayoutDashboard },
  { key: 'users', label: 'Pengguna', icon: Users },
  { key: 'categories', label: 'Kategori Kuis', icon: FolderOpen },
  { key: 'questions', label: 'Soal', icon: BookOpen },
  { key: 'withdrawals', label: 'Pencairan', icon: Wallet },
  { key: 'finance', label: 'Keuangan', icon: Landmark },
  { key: 'ads', label: 'Iklan', icon: Megaphone },
  { key: 'settings', label: 'Pengaturan', icon: Settings },
  { key: 'audit', label: 'Audit & Fraud', icon: ShieldAlert },
  { key: 'support', label: 'Notifikasi & Dukungan', icon: Bell },
]

const GRADIENT_OPTIONS = ['blue', 'purple', 'green', 'amber', 'cyan', 'rose', 'gold', 'indigo'] as const

const GRADIENT_CLASSES: Record<string, string> = {
  blue: 'from-blue-500 to-cyan-400',
  purple: 'from-violet-500 to-purple-400',
  green: 'from-emerald-500 to-green-400',
  amber: 'from-amber-400 to-orange-400',
  cyan: 'from-cyan-400 to-teal-300',
  rose: 'from-rose-500 to-pink-400',
  gold: 'from-amber-300 to-yellow-500',
  indigo: 'from-indigo-500 to-violet-400',
}

const DIFFICULTY_OPTIONS = [
  { value: 'EASY', label: 'Mudah' },
  { value: 'MEDIUM', label: 'Sedang' },
  { value: 'HARD', label: 'Sulit' },
]

const DIFFICULTY_STYLES: Record<string, string> = {
  EASY: 'bg-emerald-400/15 text-emerald-300 border-emerald-400/25',
  MEDIUM: 'bg-amber-400/15 text-amber-300 border-amber-400/25',
  HARD: 'bg-rose-400/15 text-rose-300 border-rose-400/25',
}

const DIFFICULTY_LABELS: Record<string, string> = { EASY: 'Mudah', MEDIUM: 'Sedang', HARD: 'Sulit' }

const KIND_OPTIONS = [
  { value: 'INFO', label: 'Info' },
  { value: 'SUCCESS', label: 'Sukses' },
  { value: 'WARNING', label: 'Peringatan' },
  { value: 'PROMO', label: 'Promo' },
]

const KIND_STYLES: Record<string, string> = {
  INFO: 'bg-blue-400/15 text-blue-300 border-blue-400/25',
  SUCCESS: 'bg-emerald-400/15 text-emerald-300 border-emerald-400/25',
  WARNING: 'bg-amber-400/15 text-amber-300 border-amber-400/25',
  PROMO: 'bg-violet-400/15 text-violet-300 border-violet-400/25',
}

const LEDGER_STYLES: Record<string, string> = {
  CAPITAL: 'bg-emerald-400/15 text-emerald-300 border-emerald-400/25',
  AD_REVENUE: 'bg-blue-400/15 text-blue-300 border-blue-400/25',
  SPONSOR_REVENUE: 'bg-violet-400/15 text-violet-300 border-violet-400/25',
  PRIZE_PAYOUT: 'bg-rose-400/15 text-rose-300 border-rose-400/25',
  ADJUSTMENT: 'bg-amber-400/15 text-amber-300 border-amber-400/25',
}

const LEDGER_LABELS: Record<string, string> = {
  CAPITAL: 'Modal',
  AD_REVENUE: 'Pendapatan Iklan',
  SPONSOR_REVENUE: 'Pendapatan Sponsor',
  PRIZE_PAYOUT: 'Hadiah Dibayar',
  ADJUSTMENT: 'Penyesuaian',
}

const WD_STATUS_OPTIONS = [
  { value: 'ALL', label: 'Semua Status' },
  { value: 'PENDING', label: 'Pending' },
  { value: 'REVIEWING', label: 'Ditinjau' },
  { value: 'APPROVED', label: 'Disetujui' },
  { value: 'PROCESSING', label: 'Diproses' },
  { value: 'PAID', label: 'Dibayar' },
  { value: 'REJECTED', label: 'Ditolak' },
  { value: 'FAILED', label: 'Gagal' },
]

const NUMBER_SETTINGS: { key: string; label: string }[] = [
  { key: 'pointsPerCorrectEasy', label: 'Poin per jawaban benar (Mudah)' },
  { key: 'pointsPerCorrectMedium', label: 'Poin per jawaban benar (Sedang)' },
  { key: 'pointsPerCorrectHard', label: 'Poin per jawaban benar (Sulit)' },
  { key: 'streakEvery', label: 'Bonus streak setiap (jawaban benar)' },
  { key: 'streakBonus', label: 'Nilai bonus streak' },
  { key: 'completionBonus', label: 'Bonus penyelesaian sesi' },
  { key: 'perfectBonus', label: 'Bonus skor sempurna' },
  { key: 'quizQuestionsPerSession', label: 'Jumlah soal per sesi' },
  { key: 'quizTimeSeconds', label: 'Waktu jawab per soal (detik)' },
  { key: 'answerAntiBotMs', label: 'Anti-bot minimal jawab (ms)' },
  { key: 'conversionRateRupiahPerPoint', label: 'Konversi (Rp per poin)' },
  { key: 'minConvertPoints', label: 'Minimal poin untuk konversi' },
  { key: 'minWithdrawal', label: 'Minimal pencairan (Rp)' },
  { key: 'maxPendingWithdrawals', label: 'Maksimal pencairan pending' },
  { key: 'dailyAdLimit', label: 'Limit iklan harian' },
  { key: 'adRewardPoints', label: 'Poin hadiah per iklan' },
  { key: 'luckyBonusPoints', label: 'Lucky bonus (poin)' },
]

const BOOL_SETTINGS: { key: string; label: string }[] = [
  { key: 'enableDANA', label: 'Aktifkan pencairan DANA' },
  { key: 'enableOVO', label: 'Aktifkan pencairan OVO' },
  { key: 'enableGoPay', label: 'Aktifkan pencairan GoPay' },
  { key: 'allowDevSim', label: 'Izinkan simulasi iklan (dev)' },
]

// ============================================================
// KOMPONEN KECIL BERSAMA
// ============================================================

function QeInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={cn('qe-input', props.className)} />
}

function QeTextarea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={cn('qe-input h-auto min-h-[76px] resize-y py-2.5', props.className)} />
}

function Field({
  label,
  hint,
  children,
}: {
  label: string
  hint?: string
  children: React.ReactNode
}) {
  return (
    <div className="space-y-1.5">
      <span className="block text-xs font-medium text-white/60">{label}</span>
      {children}
      {hint && <span className="block text-[11px] text-white/35">{hint}</span>}
    </div>
  )
}

type BtnTone = 'default' | 'gold' | 'grad' | 'danger' | 'emerald' | 'ghost'

function SmallBtn({
  tone = 'default',
  className,
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { tone?: BtnTone }) {
  const tones: Record<BtnTone, string> = {
    default: 'border-white/12 bg-white/8 text-white/80 hover:bg-white/14',
    gold: 'btn-gold border-transparent',
    grad: 'btn-grad border-transparent',
    danger: 'border-rose-400/25 bg-rose-500/15 text-rose-300 hover:bg-rose-500/25',
    emerald: 'border-emerald-400/25 bg-emerald-500/15 text-emerald-300 hover:bg-emerald-500/25',
    ghost: 'border-transparent bg-transparent text-white/60 hover:bg-white/8 hover:text-white',
  }
  return (
    <button
      type="button"
      {...props}
      className={cn(
        'inline-flex h-9 shrink-0 items-center justify-center gap-1.5 rounded-lg border px-3 text-xs font-semibold transition active:scale-[0.97] disabled:cursor-not-allowed disabled:opacity-50',
        tones[tone],
        className
      )}
    />
  )
}

function ReloadBtn({ onClick, loading }: { onClick: () => void; loading?: boolean }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={loading}
      aria-label="Muat ulang"
      className="glass flex h-9 w-9 items-center justify-center rounded-full text-white/60 transition hover:text-white disabled:opacity-50"
    >
      <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
    </button>
  )
}

function ErrorRetry({ onRetry }: { onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center gap-3 py-10">
      <p className="text-sm text-white/55">Gagal memuat data.</p>
      <SmallBtn tone="grad" onClick={onRetry}>
        Coba Lagi
      </SmallBtn>
    </div>
  )
}

function QeSelect({
  value,
  onValueChange,
  options,
  placeholder,
  disabled,
  className,
}: {
  value: string
  onValueChange: (v: string) => void
  options: { value: string; label: string }[]
  placeholder?: string
  disabled?: boolean
  className?: string
}) {
  return (
    <Select value={value} onValueChange={onValueChange} disabled={disabled}>
      <SelectTrigger
        className={cn(
          'w-full rounded-xl border-white/12 bg-white/5 text-sm text-white data-[placeholder]:text-white/40',
          className
        )}
      >
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent className="rounded-xl border-white/10">
        {options.map((o) => (
          <SelectItem key={o.value} value={o.value} className="text-white/80 focus:bg-white/10 focus:text-white">
            {o.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}

function TypeBadge({ type }: { type: string }) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-semibold',
        LEDGER_STYLES[type] ?? 'border-white/15 bg-white/10 text-white/60'
      )}
    >
      {LEDGER_LABELS[type] ?? type}
    </span>
  )
}

function KindChip({ kind }: { kind: string }) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-semibold',
        KIND_STYLES[kind] ?? 'border-white/15 bg-white/10 text-white/60'
      )}
    >
      {kind}
    </span>
  )
}

function Chip({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-semibold',
        className
      )}
    >
      {children}
    </span>
  )
}

function signedRupiah(n: number): string {
  return `${n < 0 ? '-' : '+'}${rupiah(Math.abs(n))}`
}

function shortDate(s: string): string {
  const parts = s.split('-')
  return parts.length === 3 ? `${parts[2]}/${parts[1]}` : s
}

function toNum(v: string): number | null {
  if (!v.trim()) return null
  const n = Number(v)
  return Number.isFinite(n) ? n : null
}

function MiniBarChart({ data }: { data: { date: string; points: number }[] }) {
  const max = Math.max(1, ...data.map((d) => d.points))
  return (
    <div className="mt-4 flex h-36 items-end gap-2">
      {data.map((d) => (
        <div key={d.date} className="flex h-full flex-1 flex-col items-center justify-end gap-1.5">
          <span className="text-[9px] font-semibold text-white/45">{fmtNum(d.points)}</span>
          <div className="flex h-full w-full items-end">
            <div
              className="w-full rounded-t-md bg-gradient-to-t from-blue-600/80 to-violet-400/90 transition-all"
              style={{ height: `${Math.max(4, (d.points / max) * 100)}%` }}
              title={`${shortDate(d.date)}: ${fmtNum(d.points)} poin`}
            />
          </div>
          <span className="text-[9px] text-white/35">{shortDate(d.date)}</span>
        </div>
      ))}
    </div>
  )
}

function StatusDot({ ok, label }: { ok: boolean | undefined; label: string }) {
  return (
    <div className="flex items-center gap-2 text-xs">
      <span className={cn('h-2 w-2 shrink-0 rounded-full', ok ? 'bg-emerald-400' : 'bg-white/25')} />
      <span className="truncate text-white/60">{label}</span>
      <span className={cn('ml-auto shrink-0 font-semibold', ok ? 'text-emerald-300' : 'text-white/35')}>
        {ok ? 'Terhubung' : 'Belum diatur'}
      </span>
    </div>
  )
}

function LedgerTable({ entries }: { entries: LedgerEntry[] }) {
  if (entries.length === 0) return <EmptyState title="Buku besar masih kosong" />
  return (
    <div className="qe-scroll max-h-96 overflow-auto rounded-xl border border-white/8">
      <div className="min-w-[640px]">
        <div className="grid grid-cols-[140px_130px_110px_110px_1fr_80px] items-center gap-2 border-b border-white/8 bg-white/5 px-3 py-2 text-[10px] font-semibold uppercase tracking-wider text-white/40">
          <span>Waktu</span>
          <span>Tipe</span>
          <span>Jumlah</span>
          <span>Saldo</span>
          <span>Catatan</span>
          <span>Oleh</span>
        </div>
        {entries.map((l) => (
          <div
            key={l.id}
            className="grid grid-cols-[140px_130px_110px_110px_1fr_80px] items-center gap-2 border-b border-white/5 px-3 py-2.5 text-xs last:border-0"
          >
            <span className="text-white/45">{fmtDateTime(l.createdAt)}</span>
            <span>
              <TypeBadge type={l.type} />
            </span>
            <span className={cn('font-bold', l.amount >= 0 ? 'text-emerald-300' : 'text-rose-300')}>
              {signedRupiah(l.amount)}
            </span>
            <span className="text-white/75">{rupiah(l.balanceAfter)}</span>
            <span className="truncate text-white/50" title={l.note ?? undefined}>
              {l.note ?? '-'}
            </span>
            <span className="truncate text-white/45">{l.createdBy}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

// ============================================================
// LOGIN
// ============================================================

function LoginScreen({ onLogin }: { onLogin: (name: string) => void }) {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (busy) return
    if (!username.trim() || !password) {
      toast.error('Username dan password wajib diisi.')
      return
    }
    setBusy(true)
    try {
      const r = await api<{ token?: string; admin: { id: string; name: string; username: string } }>('/api/admin/login', {
        method: 'POST',
        body: { username: username.trim(), password },
      })
      saveAdminToken(r.token)
      toast.success(`Selamat datang, ${r.admin.name}.`)
      onLogin(r.admin.name)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Login gagal.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <main className="qe-bg flex min-h-svh items-center justify-center px-4 py-10">
      <div className="glass-strong float-in w-full max-w-sm rounded-3xl p-6 sm:p-8">
        <div className="flex flex-col items-center text-center">
          <div className="btn-grad flex h-12 w-12 items-center justify-center rounded-2xl">
            <Zap size={22} />
          </div>
          <h1 className="mt-4 text-xl font-bold text-white">Panel Administrator</h1>
          <p className="mt-1 text-xs text-white/45">Masuk untuk mengelola platform QUIZ &amp; EARN.</p>
        </div>
        <form onSubmit={submit} className="mt-6 space-y-3">
          <div className="space-y-1.5">
            <Label className="text-xs text-white/60">Username</Label>
            <QeInput
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Username admin"
              autoComplete="username"
              disabled={busy}
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs text-white/60">Password</Label>
            <QeInput
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password admin"
              autoComplete="current-password"
              disabled={busy}
            />
          </div>
          <button
            type="submit"
            disabled={busy}
            className="btn-grad mt-1 h-11 w-full rounded-xl text-sm font-semibold"
          >
            {busy ? 'Memeriksa...' : 'Masuk'}
          </button>
        </form>
        <p className="mt-5 text-center text-[11px] text-white/30">Kredensial seed: ForgeTrhexs</p>
      </div>
    </main>
  )
}

// ============================================================
// SECTION: OVERVIEW
// ============================================================

function OverviewSection({ active }: { active: boolean }) {
  const [data, setData] = useState<OverviewData | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      setData(await api<OverviewData>('/api/admin/overview'))
    } catch (e) {
      setError(true)
      toast.error(e instanceof Error ? e.message : 'Gagal memuat overview.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (active) void load()
  }, [active, load])

  return (
    <div className="space-y-5">
      <SectionTitle
        icon={<LayoutDashboard size={15} className="text-blue-300" />}
        action={<ReloadBtn onClick={() => void load()} loading={loading} />}
      >
        Overview
      </SectionTitle>

      {loading && !data ? (
        <Loading label="Memuat overview..." />
      ) : error && !data ? (
        <ErrorRetry onRetry={() => void load()} />
      ) : data ? (
        <>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            <StatTile
              label="Total Pengguna"
              value={fmtNum(data.users.total)}
              sub={`+${fmtNum(data.users.today)} hari ini`}
              icon={<Users size={16} />}
            />
            <StatTile label="Diblokir" value={fmtNum(data.users.blocked)} icon={<Ban size={16} />} />
            <StatTile
              label="Sesi Hari Ini"
              value={fmtNum(data.sessions.today)}
              sub={`${fmtNum(data.sessions.active)} sesi aktif`}
              icon={<Activity size={16} />}
            />
            <StatTile
              label="Poin Diterbitkan Hari Ini"
              value={fmtNum(data.pointsIssuedToday)}
              icon={<Coins size={16} />}
            />
            <StatTile label="Poin Ditukar" value={fmtNum(data.pointsConvertedTotal)} icon={<Coins size={16} />} />
            <StatTile
              label="Hadiah Dibayar"
              value={rupiah(data.paidTotal)}
              sub={`${fmtNum(data.paidCount)} pencairan`}
              gold
              icon={<Wallet size={16} />}
            />
            <StatTile label="Event Iklan" value={fmtNum(data.adEvents)} icon={<Megaphone size={16} />} />
            <StatTile label="Fraud Hari Ini" value={fmtNum(data.fraudEvents)} icon={<ShieldAlert size={16} />} />
            <StatTile label="Dukungan Terbuka" value={fmtNum(data.supportOpen)} icon={<Bell size={16} />} />
          </div>

          <div className="glass-strong rounded-2xl p-5">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <p className="text-[11px] font-medium uppercase tracking-wider text-white/45">Anggaran Hadiah</p>
                <p className="gold-text mt-1 text-3xl font-extrabold">{rupiah(data.revenue.budget)}</p>
              </div>
              <div className="text-right text-[11px] text-white/45">
                <p>
                  Terpakai: <b className="text-white/80">{rupiah(data.revenue.prizePayout)}</b>
                </p>
                <p className="mt-0.5">
                  Total dibayar: <b className="text-white/80">{rupiah(data.paidTotal)}</b> ({fmtNum(data.paidCount)}x)
                </p>
              </div>
            </div>
            <ProgressBar
              value={data.revenue.prizePayout}
              max={data.revenue.budget > 0 ? data.revenue.budget : 1}
              gold
              className="mt-4"
            />
            <p className="mt-1.5 text-[11px] text-white/40">
              {data.revenue.budget > 0
                ? `${Math.min(100, Math.round((data.revenue.prizePayout / data.revenue.budget) * 100))}% anggaran terpakai untuk hadiah.`
                : 'Belum ada anggaran hadiah. Tambahkan modal atau pendapatan di menu Keuangan.'}
            </p>
            <div className="divider-fade my-4" />
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <div className="rounded-xl bg-white/5 p-3">
                <p className="text-[10px] uppercase tracking-wider text-white/40">Modal</p>
                <p className="mt-1 text-sm font-bold text-white">{rupiah(data.revenue.capital)}</p>
              </div>
              <div className="rounded-xl bg-white/5 p-3">
                <p className="text-[10px] uppercase tracking-wider text-white/40">Pendapatan Iklan</p>
                <p className="mt-1 text-sm font-bold text-white">{rupiah(data.revenue.adRevenue)}</p>
              </div>
              <div className="rounded-xl bg-white/5 p-3">
                <p className="text-[10px] uppercase tracking-wider text-white/40">Pendapatan Sponsor</p>
                <p className="mt-1 text-sm font-bold text-white">{rupiah(data.revenue.sponsorRevenue)}</p>
              </div>
              <div className="rounded-xl bg-white/5 p-3">
                <p className="text-[10px] uppercase tracking-wider text-white/40">Penyesuaian</p>
                <p className="mt-1 text-sm font-bold text-white">{rupiah(data.revenue.adjustment)}</p>
              </div>
            </div>
          </div>

          <GlassCard className="p-5">
            <p className="text-xs font-semibold text-white/70">Poin Diterbitkan - 7 Hari Terakhir</p>
            <p className="mt-0.5 text-[11px] text-white/35">Tinggi batang mengikuti poin tertinggi pada periode ini.</p>
            {data.chart.length === 0 ? (
              <EmptyState title="Belum ada data grafik" />
            ) : (
              <MiniBarChart data={data.chart} />
            )}
          </GlassCard>

          <GlassCard className="p-5">
            <p className="mb-3 text-xs font-semibold text-white/70">Pencairan per Status</p>
            {data.withdrawals.length === 0 ? (
              <EmptyState title="Belum ada pencairan" description="Data pencairan pengguna akan muncul di sini." />
            ) : (
              <div className="space-y-2">
                {data.withdrawals.map((w) => (
                  <div
                    key={w.status}
                    className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-white/5 px-3 py-2.5"
                  >
                    <StatusBadge status={w.status} />
                    <span className="text-xs text-white/45">{fmtNum(w.count)} transaksi</span>
                    <span className="ml-auto text-sm font-semibold text-white">{rupiah(w.amount)}</span>
                  </div>
                ))}
              </div>
            )}
          </GlassCard>
        </>
      ) : null}
    </div>
  )
}

// ============================================================
// SECTION: PENGGUNA
// ============================================================

type UserDialogMode = 'block' | 'pointsPlus' | 'pointsMinus' | 'resetPassword'

function UsersSection({ active }: { active: boolean }) {
  const [q, setQ] = useState('')
  const [filter, setFilter] = useState('all')
  const [users, setUsers] = useState<AdminUser[] | null>(null)
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(false)
  const [busyId, setBusyId] = useState<string | null>(null)
  const [dialog, setDialog] = useState<{ user: AdminUser; mode: UserDialogMode } | null>(null)
  const [reason, setReason] = useState('')
  const [amount, setAmount] = useState('')
  const [note, setNote] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [dialogBusy, setDialogBusy] = useState(false)

  const load = useCallback(
    async (targetPage = 1, append = false) => {
      setLoading(true)
      try {
        const params = new URLSearchParams({ page: String(targetPage) })
        if (filter !== 'all') params.set('filter', filter)
        if (q.trim()) params.set('q', q.trim())
        const r = await api<UsersData>(`/api/admin/users?${params.toString()}`)
        setUsers((prev) => (append && prev ? [...prev, ...r.users] : r.users))
        setTotal(r.total)
        setPage(targetPage)
        setError(false)
      } catch (e) {
        setError(true)
        toast.error(e instanceof Error ? e.message : 'Gagal memuat pengguna.')
      } finally {
        setLoading(false)
      }
    },
    [filter, q]
  )

  useEffect(() => {
    if (!active) return
    const t = setTimeout(() => void load(1), q.trim() ? 350 : 0)
    return () => clearTimeout(t)
  }, [active, q, filter, load])

  async function directAction(u: AdminUser, payload: Record<string, unknown>, msg: string) {
    setBusyId(u.id)
    try {
      const r = await api<{ success?: boolean; message?: string }>('/api/admin/users', {
        method: 'PATCH',
        body: { userId: u.id, ...payload },
      })
      toast.success(r.message || msg)
      await load(page)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Aksi gagal.')
    } finally {
      setBusyId(null)
    }
  }

  async function submitDialog() {
    if (!dialog) return
    const u = dialog.user
    const mode = dialog.mode
    if (mode === 'block' && !reason.trim()) {
      toast.error('Alasan blokir wajib diisi.')
      return
    }
    if (mode === 'pointsPlus' || mode === 'pointsMinus') {
      const n = toNum(amount)
      if (n === null || n <= 0) {
        toast.error('Jumlah poin harus berupa angka positif.')
        return
      }
    }
    if (mode === 'resetPassword' && newPassword.trim().length < 6) {
      toast.error('Password baru minimal 6 karakter.')
      return
    }
    setDialogBusy(true)
    try {
      let body: Record<string, unknown> = { userId: u.id }
      let fallback = 'Berhasil'
      if (mode === 'block') {
        body = { ...body, action: 'block', reason: reason.trim() }
        fallback = 'Pengguna diblokir.'
      } else if (mode === 'pointsPlus') {
        body = { ...body, action: 'adjustPoints', amount: toNum(amount), note: note.trim() || undefined }
        fallback = 'Poin berhasil ditambahkan.'
      } else if (mode === 'pointsMinus') {
        body = { ...body, action: 'adjustPoints', amount: -toNum(amount)!, note: note.trim() || undefined }
        fallback = 'Poin berhasil dikurangi.'
      } else {
        body = { ...body, action: 'resetPassword', newPassword: newPassword.trim() }
        fallback = 'Password berhasil direset.'
      }
      const r = await api<{ success?: boolean; message?: string }>('/api/admin/users', {
        method: 'PATCH',
        body,
      })
      toast.success(r.message || fallback)
      setDialog(null)
      setReason('')
      setAmount('')
      setNote('')
      setNewPassword('')
      await load(page)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Aksi gagal.')
    } finally {
      setDialogBusy(false)
    }
  }

  const dialogMeta = dialog
    ? dialog.mode === 'block'
      ? { title: 'Blokir Pengguna', desc: `Blokir akun ${dialog.user.name} (@${dialog.user.username}).` }
      : dialog.mode === 'pointsPlus'
        ? { title: 'Tambah Poin', desc: `Tambahkan poin ke ${dialog.user.name} (@${dialog.user.username}).` }
        : dialog.mode === 'pointsMinus'
          ? { title: 'Kurangi Poin', desc: `Kurangi poin milik ${dialog.user.name} (@${dialog.user.username}).` }
          : { title: 'Reset Password', desc: `Tetapkan password baru untuk ${dialog.user.name}.` }
    : null

  return (
    <div className="space-y-4">
      <SectionTitle
        icon={<Users size={15} className="text-blue-300" />}
        action={<ReloadBtn onClick={() => void load(page)} loading={loading} />}
      >
        Pengguna
      </SectionTitle>

      <div className="flex flex-col gap-2 sm:flex-row">
        <QeInput
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Cari nama, username, atau email..."
          aria-label="Cari pengguna"
        />
        <QeSelect
          value={filter}
          onValueChange={setFilter}
          className="sm:w-44"
          options={[
            { value: 'all', label: 'Semua Status' },
            { value: 'active', label: 'Aktif' },
            { value: 'blocked', label: 'Diblokir' },
          ]}
        />
      </div>

      {loading && !users ? (
        <Loading label="Memuat pengguna..." />
      ) : error && !users ? (
        <ErrorRetry onRetry={() => void load(1)} />
      ) : users && users.length === 0 ? (
        <EmptyState title="Pengguna tidak ditemukan" description="Coba kata kunci atau filter lain." />
      ) : users ? (
        <>
          <div className="space-y-3">
            {users.map((u) => (
              <div key={u.id} className="glass rounded-2xl p-4">
                <div className="flex items-start gap-3">
                  <Avatar name={u.name} avatar={u.avatar} size={40} />
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <p className="truncate text-sm font-semibold text-white">{u.name}</p>
                      {u.isBlocked && (
                        <Chip className="border-rose-400/25 bg-rose-500/15 text-rose-300">DIBLOKIR</Chip>
                      )}
                      {u.fraudCount > 0 && (
                        <Chip className="border-rose-400/20 bg-rose-500/10 text-rose-300">
                          Fraud: {u.fraudCount}
                        </Chip>
                      )}
                    </div>
                    <p className="truncate text-xs text-white/45">
                      @{u.username} · {u.email}
                    </p>
                    <div className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-white/50">
                      <span>
                        Poin: <b className="text-white/80">{fmtNum(u.pointsAvailable)}</b> (pending{' '}
                        {fmtNum(u.pointsPending)})
                      </span>
                      <span>
                        Saldo: <b className="text-white/80">{u.wallet ? rupiah(u.wallet.available) : '-'}</b>
                      </span>
                      <span>Kuis: {fmtNum(u.quizzes)}</span>
                      <span>Pencairan: {fmtNum(u.withdrawals)}</span>
                      {!u.emailVerified && <span className="text-amber-300/80">Email belum terverifikasi</span>}
                    </div>
                    {u.isBlocked && u.blockReason && (
                      <p className="mt-1.5 rounded-lg bg-rose-500/10 px-2 py-1 text-[11px] text-rose-300/90">
                        Alasan blokir: {u.blockReason}
                      </p>
                    )}
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  {u.isBlocked ? (
                    <SmallBtn
                      tone="emerald"
                      disabled={busyId === u.id}
                      onClick={() => void directAction(u, { action: 'unblock' }, 'Blokir dibuka.')}
                    >
                      Buka Blokir
                    </SmallBtn>
                  ) : (
                    <SmallBtn
                      tone="danger"
                      disabled={busyId === u.id}
                      onClick={() => {
                        setReason('')
                        setDialog({ user: u, mode: 'block' })
                      }}
                    >
                      Blokir
                    </SmallBtn>
                  )}
                  <SmallBtn
                    tone="emerald"
                    disabled={busyId === u.id}
                    onClick={() => {
                      setAmount('')
                      setNote('')
                      setDialog({ user: u, mode: 'pointsPlus' })
                    }}
                  >
                    Poin +
                  </SmallBtn>
                  <SmallBtn
                    disabled={busyId === u.id}
                    onClick={() => {
                      setAmount('')
                      setNote('')
                      setDialog({ user: u, mode: 'pointsMinus' })
                    }}
                  >
                    Poin -
                  </SmallBtn>
                  <SmallBtn
                    disabled={busyId === u.id}
                    onClick={() => {
                      setNewPassword('')
                      setDialog({ user: u, mode: 'resetPassword' })
                    }}
                  >
                    Reset Password
                  </SmallBtn>
                  {!u.emailVerified && (
                    <SmallBtn
                      tone="gold"
                      disabled={busyId === u.id}
                      onClick={() => void directAction(u, { action: 'verifyEmail' }, 'Email diverifikasi.')}
                    >
                      Verifikasi Email
                    </SmallBtn>
                  )}
                </div>
              </div>
            ))}
          </div>
          {users.length < total && (
            <div className="flex justify-center">
              <SmallBtn onClick={() => void load(page + 1, true)} disabled={loading}>
                Muat Lagi ({users.length}/{fmtNum(total)})
              </SmallBtn>
            </div>
          )}
        </>
      ) : null}

      <Dialog
        open={dialog !== null}
        onOpenChange={(o) => {
          if (!o && !dialogBusy) setDialog(null)
        }}
      >
        <DialogContent className="border-white/10">
          <DialogHeader>
            <DialogTitle className="text-white">{dialogMeta?.title ?? ''}</DialogTitle>
            <DialogDescription>{dialogMeta?.desc ?? ''}</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            {dialog?.mode === 'block' && (
              <Field label="Alasan blokir" hint="Ditampilkan kepada pengguna.">
                <QeTextarea
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Contoh: aktivitas curang terdeteksi"
                  aria-label="Alasan blokir"
                />
              </Field>
            )}
            {(dialog?.mode === 'pointsPlus' || dialog?.mode === 'pointsMinus') && (
              <>
                <Field label="Jumlah poin">
                  <QeInput
                    type="number"
                    min={1}
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="Contoh: 100"
                    aria-label="Jumlah poin"
                  />
                </Field>
                <Field label="Catatan (opsional)">
                  <QeInput
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    placeholder="Alasan penyesuaian poin"
                    aria-label="Catatan penyesuaian"
                  />
                </Field>
              </>
            )}
            {dialog?.mode === 'resetPassword' && (
              <Field label="Password baru" hint="Sampaikan password baru kepada pengguna secara aman.">
                <QeInput
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Password baru"
                  aria-label="Password baru"
                />
              </Field>
            )}
          </div>
          <DialogFooter>
            <SmallBtn tone="ghost" onClick={() => setDialog(null)} disabled={dialogBusy}>
              Batal
            </SmallBtn>
            <SmallBtn tone="grad" onClick={() => void submitDialog()} disabled={dialogBusy}>
              {dialogBusy ? 'Menyimpan...' : 'Simpan'}
            </SmallBtn>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// SECTION: KATEGORI KUIS
// ============================================================

function CategoriesSection({ active }: { active: boolean }) {
  const [categories, setCategories] = useState<AdminCategory[] | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(false)
  const [togglingId, setTogglingId] = useState<string | null>(null)
  const [addOpen, setAddOpen] = useState(false)
  const [busy, setBusy] = useState(false)
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [icon, setIcon] = useState('')
  const [gradient, setGradient] = useState<string>('blue')

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      const r = await api<{ categories: AdminCategory[] }>('/api/admin/categories')
      setCategories(r.categories)
    } catch (e) {
      setError(true)
      toast.error(e instanceof Error ? e.message : 'Gagal memuat kategori.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (active) void load()
  }, [active, load])

  async function toggleActive(c: AdminCategory, next: boolean) {
    setTogglingId(c.id)
    try {
      const r = await api<{ success?: boolean; message?: string }>('/api/admin/categories', {
        method: 'PATCH',
        body: { id: c.id, isActive: next },
      })
      toast.success(r.message || 'Status kategori diperbarui.')
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal mengubah status kategori.')
    } finally {
      setTogglingId(null)
    }
  }

  async function submitAdd() {
    if (!name.trim()) {
      toast.error('Nama kategori wajib diisi.')
      return
    }
    setBusy(true)
    try {
      const r = await api<{ success?: boolean; message?: string }>('/api/admin/categories', {
        method: 'POST',
        body: {
          name: name.trim(),
          description: description.trim() || undefined,
          icon: icon.trim() || undefined,
          gradient,
        },
      })
      toast.success(r.message || 'Kategori dibuat.')
      setAddOpen(false)
      setName('')
      setDescription('')
      setIcon('')
      setGradient('blue')
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal membuat kategori.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="space-y-4">
      <SectionTitle
        icon={<FolderOpen size={15} className="text-blue-300" />}
        action={
          <div className="flex items-center gap-2">
            <SmallBtn tone="grad" onClick={() => setAddOpen(true)}>
              Tambah Kategori
            </SmallBtn>
            <ReloadBtn onClick={() => void load()} loading={loading} />
          </div>
        }
      >
        Kategori Kuis
      </SectionTitle>

      {loading && !categories ? (
        <Loading label="Memuat kategori..." />
      ) : error && !categories ? (
        <ErrorRetry onRetry={() => void load()} />
      ) : categories && categories.length === 0 ? (
        <EmptyState title="Belum ada kategori" description="Tambahkan kategori untuk mulai mengisi soal." />
      ) : categories ? (
        <div className="space-y-3">
          {categories.map((c) => (
            <div key={c.id} className="glass flex items-center gap-3 rounded-2xl p-4">
              <div
                className={cn(
                  'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br text-sm font-bold text-white',
                  GRADIENT_CLASSES[c.gradient] ?? 'from-blue-500 to-violet-500'
                )}
                aria-hidden
              >
                {c.icon ? c.icon.slice(0, 2).toUpperCase() : c.name.slice(0, 2).toUpperCase()}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold text-white">{c.name}</p>
                <p className="truncate text-[11px] text-white/45">
                  {c.slug} · {fmtNum(c.questionCount)} soal
                  {c.description ? ` · ${c.description}` : ''}
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <span className={cn('text-[11px] font-medium', c.isActive ? 'text-emerald-300' : 'text-white/40')}>
                  {c.isActive ? 'Aktif' : 'Nonaktif'}
                </span>
                <Switch
                  checked={c.isActive}
                  disabled={togglingId === c.id}
                  onCheckedChange={(v) => void toggleActive(c, v)}
                  aria-label={`Aktifkan kategori ${c.name}`}
                />
              </div>
            </div>
          ))}
        </div>
      ) : null}

      <Dialog
        open={addOpen}
        onOpenChange={(o) => {
          if (!o && !busy) setAddOpen(false)
        }}
      >
        <DialogContent className="border-white/10">
          <DialogHeader>
            <DialogTitle className="text-white">Tambah Kategori</DialogTitle>
            <DialogDescription>Buat kategori kuis baru untuk mengelompokkan soal.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <Field label="Nama kategori">
              <QeInput
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Contoh: Sains Umum"
                aria-label="Nama kategori"
              />
            </Field>
            <Field label="Deskripsi (opsional)">
              <QeTextarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Deskripsi singkat kategori"
                aria-label="Deskripsi kategori"
              />
            </Field>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Ikon (teks singkat)" hint="Contoh: Sci, Bio, Mtk.">
                <QeInput
                  value={icon}
                  onChange={(e) => setIcon(e.target.value)}
                  placeholder="Kode ikon"
                  aria-label="Ikon kategori"
                />
              </Field>
              <Field label="Gradien">
                <QeSelect
                  value={gradient}
                  onValueChange={setGradient}
                  options={GRADIENT_OPTIONS.map((g) => ({ value: g, label: g }))}
                />
              </Field>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-white/40">
              Pratinjau:
              <span
                className={cn(
                  'h-6 w-6 rounded-lg bg-gradient-to-br',
                  GRADIENT_CLASSES[gradient] ?? 'from-blue-500 to-violet-500'
                )}
                aria-hidden
              />
            </div>
          </div>
          <DialogFooter>
            <SmallBtn tone="ghost" onClick={() => setAddOpen(false)} disabled={busy}>
              Batal
            </SmallBtn>
            <SmallBtn tone="grad" onClick={() => void submitAdd()} disabled={busy}>
              {busy ? 'Menyimpan...' : 'Simpan'}
            </SmallBtn>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// SECTION: SOAL
// ============================================================

function QuestionsSection({ active }: { active: boolean }) {
  const [catFilter, setCatFilter] = useState('all')
  const [q, setQ] = useState('')
  const [data, setData] = useState<QuestionsData | null>(null)
  const [page, setPage] = useState(1)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(false)
  const [busyId, setBusyId] = useState<string | null>(null)
  const [editorOpen, setEditorOpen] = useState(false)
  const [editing, setEditing] = useState<AdminQuestion | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<AdminQuestion | null>(null)
  const [busy, setBusy] = useState(false)
  const [fCat, setFCat] = useState('')
  const [fDiff, setFDiff] = useState('EASY')
  const [fText, setFText] = useState('')
  const [fImage, setFImage] = useState('')
  const [fOptions, setFOptions] = useState<string[]>(['', '', '', ''])
  const [fCorrect, setFCorrect] = useState(0)
  const [fExpl, setFExpl] = useState('')

  const load = useCallback(
    async (targetPage = 1, append = false) => {
      setLoading(true)
      try {
        const params = new URLSearchParams({ page: String(targetPage) })
        if (catFilter !== 'all') params.set('categoryId', catFilter)
        if (q.trim()) params.set('q', q.trim())
        const r = await api<QuestionsData>(`/api/admin/questions?${params.toString()}`)
        setData((prev) =>
          append && prev ? { ...r, questions: [...prev.questions, ...r.questions] } : r
        )
        setPage(targetPage)
        setError(false)
      } catch (e) {
        setError(true)
        toast.error(e instanceof Error ? e.message : 'Gagal memuat soal.')
      } finally {
        setLoading(false)
      }
    },
    [catFilter, q]
  )

  useEffect(() => {
    if (!active) return
    const t = setTimeout(() => void load(1), q.trim() ? 350 : 0)
    return () => clearTimeout(t)
  }, [active, catFilter, q, load])

  const categoryOptions = useMemo(() => {
    const opts = (data?.categories ?? []).map((c) => ({ value: c.id, label: c.name }))
    if (editing && !opts.some((o) => o.value === editing.categoryId)) {
      opts.unshift({ value: editing.categoryId, label: `${editing.categoryName} (nonaktif)` })
    }
    return opts
  }, [data, editing])

  function setOptionAt(i: number, v: string) {
    setFOptions((prev) => prev.map((o, idx) => (idx === i ? v : o)))
  }

  function openEditor(question?: AdminQuestion) {
    if (question) {
      setEditing(question)
      setFCat(question.categoryId)
      setFDiff(question.difficulty)
      setFText(question.text)
      setFImage(question.imageUrl ?? '')
      setFOptions(question.options.length === 4 ? [...question.options] : ['', '', '', ''])
      setFCorrect(question.correctIndex)
      setFExpl(question.explanation ?? '')
    } else {
      setEditing(null)
      setFCat('')
      setFDiff('EASY')
      setFText('')
      setFImage('')
      setFOptions(['', '', '', ''])
      setFCorrect(0)
      setFExpl('')
    }
    setEditorOpen(true)
  }

  async function submitEditor() {
    if (!fCat) {
      toast.error('Pilih kategori soal.')
      return
    }
    if (!fText.trim()) {
      toast.error('Teks soal wajib diisi.')
      return
    }
    if (fOptions.some((o) => !o.trim())) {
      toast.error('Semua 4 opsi jawaban wajib diisi.')
      return
    }
    setBusy(true)
    try {
      const payload = {
        categoryId: fCat,
        difficulty: fDiff,
        text: fText.trim(),
        imageUrl: fImage.trim() || undefined,
        options: fOptions.map((o) => o.trim()),
        correctIndex: fCorrect,
        explanation: fExpl.trim() || undefined,
      }
      const r = await api<{ success?: boolean; message?: string }>('/api/admin/questions', {
        method: editing ? 'PATCH' : 'POST',
        body: editing ? { id: editing.id, ...payload } : payload,
      })
      toast.success(r.message || (editing ? 'Soal diperbarui.' : 'Soal dibuat.'))
      setEditorOpen(false)
      await load(1)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal menyimpan soal.')
    } finally {
      setBusy(false)
    }
  }

  async function toggleActive(question: AdminQuestion) {
    setBusyId(question.id)
    try {
      const r = await api<{ success?: boolean; message?: string }>('/api/admin/questions', {
        method: 'PATCH',
        body: { id: question.id, isActive: !question.isActive },
      })
      toast.success(r.message || 'Status soal diperbarui.')
      await load(page)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal mengubah status soal.')
    } finally {
      setBusyId(null)
    }
  }

  async function submitDelete() {
    if (!deleteTarget) return
    setBusy(true)
    try {
      const r = await api<{ success: boolean; soft?: boolean; message: string }>(
        `/api/admin/questions?id=${encodeURIComponent(deleteTarget.id)}`,
        { method: 'DELETE' }
      )
      toast.success(r.soft ? `${r.message} (soft delete)` : r.message)
      setDeleteTarget(null)
      await load(1)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal menghapus soal.')
    } finally {
      setBusy(false)
    }
  }

  const questions = data?.questions ?? null

  return (
    <div className="space-y-4">
      <SectionTitle
        icon={<BookOpen size={15} className="text-blue-300" />}
        action={
          <div className="flex items-center gap-2">
            <SmallBtn tone="grad" onClick={() => openEditor()}>
              Buat Soal
            </SmallBtn>
            <ReloadBtn onClick={() => void load(page)} loading={loading} />
          </div>
        }
      >
        Soal
      </SectionTitle>

      <div className="flex flex-col gap-2 sm:flex-row">
        <QeSelect
          value={catFilter}
          onValueChange={setCatFilter}
          className="sm:w-52"
          options={[
            { value: 'all', label: 'Semua Kategori' },
            ...(data?.categories ?? []).map((c) => ({ value: c.id, label: c.name })),
          ]}
        />
        <QeInput
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Cari teks soal..."
          aria-label="Cari soal"
        />
      </div>

      {loading && !data ? (
        <Loading label="Memuat soal..." />
      ) : error && !data ? (
        <ErrorRetry onRetry={() => void load(1)} />
      ) : questions && questions.length === 0 ? (
        <EmptyState title="Soal tidak ditemukan" description="Ubah filter atau buat soal baru." />
      ) : questions ? (
        <>
          <p className="text-[11px] text-white/40">
            Menampilkan {fmtNum(questions.length)} dari {fmtNum(data?.total ?? 0)} soal.
          </p>
          <div className="space-y-3">
            {questions.map((item) => (
              <div key={item.id} className="glass rounded-2xl p-4">
                <div className="flex flex-wrap items-center gap-1.5">
                  <Chip className="border-white/15 bg-white/10 text-white/60">{item.categoryName}</Chip>
                  <Chip className={DIFFICULTY_STYLES[item.difficulty] ?? 'border-white/15 bg-white/10 text-white/60'}>
                    {DIFFICULTY_LABELS[item.difficulty] ?? item.difficulty}
                  </Chip>
                  {item.isActive ? (
                    <Chip className="border-emerald-400/25 bg-emerald-500/15 text-emerald-300">AKTIF</Chip>
                  ) : (
                    <Chip className="border-white/15 bg-white/10 text-white/50">NONAKTIF</Chip>
                  )}
                </div>
                <p className="mt-2 text-sm font-medium text-white">{item.text}</p>
                {item.imageUrl && (
                  <a
                    href={item.imageUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-1 inline-block text-[11px] text-blue-300 underline underline-offset-2"
                  >
                    Lihat gambar soal
                  </a>
                )}
                <div className="mt-2.5 grid gap-1.5 sm:grid-cols-2">
                  {item.options.map((opt, i) => (
                    <div
                      key={i}
                      className={cn(
                        'rounded-lg border px-2.5 py-1.5 text-xs',
                        i === item.correctIndex
                          ? 'border-emerald-400/30 bg-emerald-500/10 text-emerald-200'
                          : 'border-white/8 bg-white/5 text-white/60'
                      )}
                    >
                      <span className="mr-1.5 font-bold">{String.fromCharCode(65 + i)}.</span>
                      {opt}
                      {i === item.correctIndex && (
                        <span className="ml-1.5 text-[10px] font-bold tracking-wide">JAWABAN BENAR</span>
                      )}
                    </div>
                  ))}
                </div>
                {item.explanation && (
                  <p className="mt-2 rounded-lg bg-white/5 px-2.5 py-1.5 text-[11px] text-white/50">
                    Penjelasan: {item.explanation}
                  </p>
                )}
                <div className="mt-3 flex flex-wrap gap-2">
                  <SmallBtn onClick={() => openEditor(item)}>Edit</SmallBtn>
                  <SmallBtn
                    tone={item.isActive ? 'default' : 'emerald'}
                    disabled={busyId === item.id}
                    onClick={() => void toggleActive(item)}
                  >
                    {item.isActive ? 'Nonaktifkan' : 'Aktifkan'}
                  </SmallBtn>
                  <SmallBtn tone="danger" disabled={busyId === item.id} onClick={() => setDeleteTarget(item)}>
                    Hapus
                  </SmallBtn>
                </div>
              </div>
            ))}
          </div>
          {data && questions.length < data.total && (
            <div className="flex justify-center">
              <SmallBtn onClick={() => void load(page + 1, true)} disabled={loading}>
                Muat Lagi ({questions.length}/{fmtNum(data.total)})
              </SmallBtn>
            </div>
          )}
        </>
      ) : null}

      <Dialog
        open={editorOpen}
        onOpenChange={(o) => {
          if (!o && !busy) setEditorOpen(false)
        }}
      >
        <DialogContent className="qe-scroll max-h-[90svh] overflow-y-auto border-white/10">
          <DialogHeader>
            <DialogTitle className="text-white">{editing ? 'Edit Soal' : 'Buat Soal Baru'}</DialogTitle>
            <DialogDescription>Lengkapi detail soal beserta jawaban yang benar.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Kategori">
                <QeSelect
                  value={fCat}
                  onValueChange={setFCat}
                  placeholder="Pilih kategori"
                  options={categoryOptions}
                />
              </Field>
              <Field label="Tingkat kesulitan">
                <QeSelect value={fDiff} onValueChange={setFDiff} options={DIFFICULTY_OPTIONS} />
              </Field>
            </div>
            <Field label="Teks soal">
              <QeTextarea
                value={fText}
                onChange={(e) => setFText(e.target.value)}
                placeholder="Tulis pertanyaan soal"
                aria-label="Teks soal"
              />
            </Field>
            <Field label="URL gambar (opsional)">
              <QeInput
                value={fImage}
                onChange={(e) => setFImage(e.target.value)}
                placeholder="https://contoh.com/gambar.jpg"
                aria-label="URL gambar soal"
              />
            </Field>
            <Field label="Opsi jawaban" hint="Tandai radio pada jawaban yang benar.">
              <RadioGroup
                value={String(fCorrect)}
                onValueChange={(v) => setFCorrect(Number(v))}
                className="space-y-2"
              >
                {fOptions.map((opt, i) => (
                  <div key={i} className="flex items-center gap-2.5 rounded-xl border border-white/10 bg-white/5 p-2 pl-3.5">
                    <RadioGroupItem
                      value={String(i)}
                      id={`qopt-${i}`}
                      aria-label={`Tandai opsi ${i + 1} sebagai jawaban benar`}
                    />
                    <QeInput
                      value={opt}
                      onChange={(e) => setOptionAt(i, e.target.value)}
                      placeholder={`Teks opsi ${String.fromCharCode(65 + i)}`}
                      aria-label={`Teks opsi ${i + 1}`}
                    />
                  </div>
                ))}
              </RadioGroup>
            </Field>
            <Field label="Penjelasan (opsional)">
              <QeTextarea
                value={fExpl}
                onChange={(e) => setFExpl(e.target.value)}
                placeholder="Penjelasan mengapa jawaban tersebut benar"
                aria-label="Penjelasan soal"
              />
            </Field>
          </div>
          <DialogFooter>
            <SmallBtn tone="ghost" onClick={() => setEditorOpen(false)} disabled={busy}>
              Batal
            </SmallBtn>
            <SmallBtn tone="grad" onClick={() => void submitEditor()} disabled={busy}>
              {busy ? 'Menyimpan...' : 'Simpan Soal'}
            </SmallBtn>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={deleteTarget !== null}
        onOpenChange={(o) => {
          if (!o && !busy) setDeleteTarget(null)
        }}
      >
        <AlertDialogContent className="border-white/10">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">Hapus soal ini?</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteTarget?.text ?? 'Soal akan dihapus dan tidak dapat ditampilkan kembali.'}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={busy}>Batal</AlertDialogCancel>
            <AlertDialogAction
              className="bg-rose-500/90 text-white hover:bg-rose-500"
              disabled={busy}
              onClick={(e) => {
                e.preventDefault()
                void submitDelete()
              }}
            >
              {busy ? 'Menghapus...' : 'Hapus'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ============================================================
// SECTION: PENCAIRAN
// ============================================================

function WithdrawalsSection({ active }: { active: boolean }) {
  const [status, setStatus] = useState('ALL')
  const [data, setData] = useState<WithdrawalsData | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(false)
  const [busyId, setBusyId] = useState<string | null>(null)
  const [paidTarget, setPaidTarget] = useState<AdminWithdrawal | null>(null)
  const [reference, setReference] = useState('')
  const [paidNote, setPaidNote] = useState('')
  const [rejectTarget, setRejectTarget] = useState<AdminWithdrawal | null>(null)
  const [rejectReason, setRejectReason] = useState('')
  const [dialogBusy, setDialogBusy] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      const r = await api<WithdrawalsData>(
        `/api/admin/withdrawals?status=${encodeURIComponent(status)}`
      )
      setData(r)
    } catch (e) {
      setError(true)
      toast.error(e instanceof Error ? e.message : 'Gagal memuat pencairan.')
    } finally {
      setLoading(false)
    }
  }, [status])

  useEffect(() => {
    if (active) void load()
  }, [active, load])

  async function runAction(w: AdminWithdrawal, action: string, extra?: { reference?: string; note?: string }) {
    setBusyId(w.id)
    try {
      const r = await api<{ success?: boolean; message?: string }>('/api/admin/withdrawals', {
        method: 'PATCH',
        body: { id: w.id, action, ...extra },
      })
      toast.success(r.message || 'Aksi berhasil.')
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Aksi gagal.')
    } finally {
      setBusyId(null)
    }
  }

  function handleAction(w: AdminWithdrawal, action: string) {
    if (action === 'markPaid') {
      setReference('')
      setPaidNote('')
      setPaidTarget(w)
      return
    }
    if (action === 'reject') {
      setRejectReason('')
      setRejectTarget(w)
      return
    }
    void runAction(w, action)
  }

  async function submitMarkPaid() {
    if (!paidTarget) return
    if (!reference.trim()) {
      toast.error('Nomor referensi pembayaran wajib diisi.')
      return
    }
    setDialogBusy(true)
    try {
      const r = await api<{ success?: boolean; message?: string }>('/api/admin/withdrawals', {
        method: 'PATCH',
        body: {
          id: paidTarget.id,
          action: 'markPaid',
          reference: reference.trim(),
          note: paidNote.trim() || undefined,
        },
      })
      toast.success(r.message || 'Pencairan ditandai dibayar.')
      setPaidTarget(null)
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal menandai dibayar.')
    } finally {
      setDialogBusy(false)
    }
  }

  async function submitReject() {
    if (!rejectTarget) return
    if (!rejectReason.trim()) {
      toast.error('Alasan penolakan wajib diisi.')
      return
    }
    setDialogBusy(true)
    try {
      const r = await api<{ success?: boolean; message?: string }>('/api/admin/withdrawals', {
        method: 'PATCH',
        body: { id: rejectTarget.id, action: 'reject', note: rejectReason.trim() },
      })
      toast.success(r.message || 'Pencairan ditolak.')
      setRejectTarget(null)
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal menolak pencairan.')
    } finally {
      setDialogBusy(false)
    }
  }

  const ACTION_MAP: Record<string, { action: string; label: string; tone: BtnTone }[]> = {
    PENDING: [
      { action: 'review', label: 'Review', tone: 'default' },
      { action: 'reject', label: 'Tolak', tone: 'danger' },
    ],
    REVIEWING: [
      { action: 'approve', label: 'Setujui', tone: 'emerald' },
      { action: 'reject', label: 'Tolak', tone: 'danger' },
    ],
    APPROVED: [
      { action: 'startProcessing', label: 'Proses', tone: 'default' },
      { action: 'reject', label: 'Tolak', tone: 'danger' },
    ],
    PROCESSING: [
      { action: 'markPaid', label: 'Tandai Dibayar', tone: 'gold' },
      { action: 'markFailed', label: 'Tandai Gagal', tone: 'danger' },
    ],
  }

  const rows = data?.withdrawals ?? null
  const outstanding = (rows ?? [])
    .filter((w) => ['PENDING', 'REVIEWING', 'APPROVED', 'PROCESSING'].includes(w.status))
    .reduce((s, w) => s + w.amount, 0)
  const budgetShort = data != null && data.prizeBudget < outstanding

  return (
    <div className="space-y-4">
      <SectionTitle
        icon={<Wallet size={15} className="text-blue-300" />}
        action={<ReloadBtn onClick={() => void load()} loading={loading} />}
      >
        Pencairan
      </SectionTitle>

      {loading && !data ? (
        <Loading label="Memuat pencairan..." />
      ) : error && !data ? (
        <ErrorRetry onRetry={() => void load()} />
      ) : data ? (
        <>
          <div className="glass-strong rounded-2xl p-5">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <p className="text-[11px] font-medium uppercase tracking-wider text-white/45">Anggaran Hadiah</p>
                <p className="gold-text mt-1 text-2xl font-extrabold">{rupiah(data.prizeBudget)}</p>
              </div>
              <div className="space-y-1.5 text-right">
                <div className="flex justify-end">
                  <Chip
                    className={
                      data.payoutMode === 'automatic'
                        ? 'border-emerald-400/25 bg-emerald-500/15 text-emerald-300'
                        : 'border-amber-400/25 bg-amber-500/15 text-amber-300'
                    }
                  >
                    MODE: {data.payoutMode.toUpperCase()}
                  </Chip>
                </div>
                <div className="flex items-center justify-end gap-1.5 text-[11px]">
                  <span
                    className={cn(
                      'h-2 w-2 rounded-full',
                      data.automaticAvailable ? 'bg-emerald-400 pulse-dot' : 'bg-white/25'
                    )}
                  />
                  <span className={data.automaticAvailable ? 'text-emerald-300' : 'text-white/40'}>
                    Pembayaran otomatis {data.automaticAvailable ? 'tersedia' : 'belum tersedia'}
                  </span>
                </div>
              </div>
            </div>
            {budgetShort && (
              <p className="mt-3 rounded-xl border border-amber-400/25 bg-amber-500/10 px-3 py-2 text-[11px] text-amber-300">
                Peringatan: total pencairan yang menunggu ({rupiah(outstanding)}) melebihi Anggaran Hadiah (
                {rupiah(data.prizeBudget)}). Tambahkan modal atau pendapatan sebelum memproses pembayaran.
              </p>
            )}
          </div>

          <QeSelect value={status} onValueChange={setStatus} options={WD_STATUS_OPTIONS} />

          {rows && rows.length === 0 ? (
            <EmptyState title="Tidak ada pencairan" description="Belum ada transaksi dengan filter ini." />
          ) : rows ? (
            <div className="space-y-3">
              {rows.map((w) => (
                <div key={w.id} className="glass rounded-2xl p-4">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-white">
                        {w.user.name}{' '}
                        <span className="font-normal text-white/40">@{w.user.username}</span>
                        {w.user.isBlocked && (
                          <Chip className="ml-1.5 border-rose-400/25 bg-rose-500/15 text-rose-300">DIBLOKIR</Chip>
                        )}
                      </p>
                      <p className="truncate text-[11px] text-white/40">{w.user.email}</p>
                    </div>
                    <StatusBadge status={w.status} />
                  </div>
                  <div className="mt-2 grid gap-x-4 gap-y-1 text-xs text-white/60 sm:grid-cols-2">
                    <span>
                      Jumlah:{' '}
                      <b className="text-white">
                        {rupiah(w.amount)}
                        {w.fee > 0 && <span className="font-normal text-white/40"> (fee {rupiah(w.fee)})</span>}
                      </b>
                    </span>
                    <span>
                      Metode: <b className="text-white/85">{w.method}</b>
                    </span>
                    <span className="truncate">
                      Penerima: {w.accountName} - {w.accountNumber}
                    </span>
                    <span>Mode: {w.mode === 'automatic' ? 'Otomatis' : 'Manual'}</span>
                    <span>Diajukan: {fmtDateTime(w.createdAt)}</span>
                    {w.processedAt && <span>Diproses: {fmtDateTime(w.processedAt)}</span>}
                  </div>
                  {w.reference && (
                    <p className="mt-1.5 text-[11px] text-emerald-300/85">Referensi: {w.reference}</p>
                  )}
                  {w.adminNote && (
                    <p className="mt-1.5 rounded-lg bg-white/5 px-2.5 py-1.5 text-[11px] text-white/55">
                      Catatan admin: {w.adminNote}
                    </p>
                  )}
                  {(ACTION_MAP[w.status]?.length ?? 0) > 0 && (
                    <div className="mt-3 flex flex-wrap gap-2">
                      {(ACTION_MAP[w.status] ?? []).map((a) => (
                        <SmallBtn
                          key={a.action}
                          tone={a.tone}
                          disabled={busyId === w.id}
                          onClick={() => handleAction(w, a.action)}
                        >
                          {a.label}
                        </SmallBtn>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : null}
        </>
      ) : null}

      <Dialog
        open={paidTarget !== null}
        onOpenChange={(o) => {
          if (!o && !dialogBusy) setPaidTarget(null)
        }}
      >
        <DialogContent className="border-white/10">
          <DialogHeader>
            <DialogTitle className="text-white">Tandai Dibayar</DialogTitle>
            <DialogDescription>
              Konfirmasi pembayaran {paidTarget ? rupiah(paidTarget.amount) : ''} ke{' '}
              {paidTarget?.accountName ?? ''}.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <Field label="Nomor referensi pembayaran" hint="Wajib. Contoh: ID transaksi DANA/OVO/GoPay.">
              <QeInput
                value={reference}
                onChange={(e) => setReference(e.target.value)}
                placeholder="Nomor referensi"
                aria-label="Nomor referensi pembayaran"
              />
            </Field>
            <Field label="Catatan (opsional)">
              <QeInput
                value={paidNote}
                onChange={(e) => setPaidNote(e.target.value)}
                placeholder="Catatan admin"
                aria-label="Catatan pembayaran"
              />
            </Field>
          </div>
          <DialogFooter>
            <SmallBtn tone="ghost" onClick={() => setPaidTarget(null)} disabled={dialogBusy}>
              Batal
            </SmallBtn>
            <SmallBtn tone="gold" onClick={() => void submitMarkPaid()} disabled={dialogBusy}>
              {dialogBusy ? 'Menyimpan...' : 'Konfirmasi Dibayar'}
            </SmallBtn>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog
        open={rejectTarget !== null}
        onOpenChange={(o) => {
          if (!o && !dialogBusy) setRejectTarget(null)
        }}
      >
        <DialogContent className="border-white/10">
          <DialogHeader>
            <DialogTitle className="text-white">Tolak Pencairan</DialogTitle>
            <DialogDescription>
              Alasan akan tercatat dan dapat dilihat pengguna sebagai catatan admin.
            </DialogDescription>
          </DialogHeader>
          <Field label="Alasan penolakan" hint="Wajib.">
            <QeTextarea
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="Contoh: data rekening tidak cocok"
              aria-label="Alasan penolakan"
            />
          </Field>
          <DialogFooter>
            <SmallBtn tone="ghost" onClick={() => setRejectTarget(null)} disabled={dialogBusy}>
              Batal
            </SmallBtn>
            <SmallBtn tone="danger" onClick={() => void submitReject()} disabled={dialogBusy}>
              {dialogBusy ? 'Menyimpan...' : 'Tolak'}
            </SmallBtn>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// SECTION: KEUANGAN
// ============================================================

function CapitalTab({ active }: { active: boolean }) {
  const [data, setData] = useState<CapitalData | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(false)
  const [amount, setAmount] = useState('')
  const [source, setSource] = useState('PEMILIK')
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      setData(await api<CapitalData>('/api/admin/capital'))
    } catch (e) {
      setError(true)
      toast.error(e instanceof Error ? e.message : 'Gagal memuat buku besar.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (active) void load()
  }, [active, load])

  async function submit() {
    const n = toNum(amount)
    if (n === null || n <= 0) {
      toast.error('Jumlah modal harus berupa angka positif.')
      return
    }
    setBusy(true)
    try {
      const r = await api<{ success?: boolean; message?: string }>('/api/admin/capital', {
        method: 'POST',
        body: { amount: n, source, note: note.trim() || undefined },
      })
      toast.success(r.message || 'Modal berhasil dicatat.')
      setAmount('')
      setNote('')
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal mencatat modal.')
    } finally {
      setBusy(false)
    }
  }

  const s = data?.summary
  const tiles: { label: string; value: number; gold?: boolean }[] = [
    { label: 'Modal', value: s?.capital ?? 0 },
    { label: 'Pendapatan Iklan', value: s?.adRevenue ?? 0 },
    { label: 'Pendapatan Sponsor', value: s?.sponsorRevenue ?? 0 },
    { label: 'Hadiah Dibayar', value: s?.prizePayout ?? 0 },
    { label: 'Penyesuaian', value: s?.adjustment ?? 0 },
    { label: 'Anggaran Hadiah', value: s?.budget ?? 0, gold: true },
  ]

  return (
    <div className="space-y-4">
      <GlassCard className="p-5">
        <p className="text-xs font-semibold text-white/70">Tambah Modal</p>
        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          <Field label="Jumlah (Rp)">
            <QeInput
              type="number"
              min={1}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Contoh: 1000000"
              aria-label="Jumlah modal"
            />
          </Field>
          <Field label="Sumber">
            <QeSelect
              value={source}
              onValueChange={setSource}
              options={[
                { value: 'PEMILIK', label: 'Pemilik' },
                { value: 'INVESTOR', label: 'Investor' },
                { value: 'LAINNYA', label: 'Lainnya' },
              ]}
            />
          </Field>
          <Field label="Catatan (opsional)">
            <QeInput
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Keterangan modal"
              aria-label="Catatan modal"
            />
          </Field>
        </div>
        <SmallBtn tone="grad" className="mt-3" onClick={() => void submit()} disabled={busy}>
          {busy ? 'Menyimpan...' : 'Catat Modal'}
        </SmallBtn>
      </GlassCard>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {tiles.map((t) => (
          <StatTile key={t.label} label={t.label} value={rupiah(t.value)} gold={t.gold} />
        ))}
      </div>

      <GlassCard className="p-5">
        <p className="mb-3 text-xs font-semibold text-white/70">Buku Besar</p>
        {data ? <LedgerTable entries={data.ledger} /> : null}
      </GlassCard>
    </div>
  )
}

function RevenueTab({ active }: { active: boolean }) {
  const [data, setData] = useState<RevenueData | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(false)
  const [type, setType] = useState('AD_REVENUE')
  const [amount, setAmount] = useState('')
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      setData(await api<RevenueData>('/api/admin/revenue'))
    } catch (e) {
      setError(true)
      toast.error(e instanceof Error ? e.message : 'Gagal memuat pendapatan.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (active) void load()
  }, [active, load])

  async function submit() {
    const n = toNum(amount)
    if (n === null || n <= 0) {
      toast.error('Jumlah pendapatan harus berupa angka positif.')
      return
    }
    setBusy(true)
    try {
      const r = await api<{ success?: boolean; message?: string }>('/api/admin/revenue', {
        method: 'POST',
        body: { type, amount: n, note: note.trim() || undefined },
      })
      toast.success(r.message || 'Pendapatan dicatat.')
      setAmount('')
      setNote('')
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal mencatat pendapatan.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="space-y-4">
      <GlassCard className="p-5">
        <p className="text-xs font-semibold text-white/70">Catat Pendapatan Manual</p>
        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          <Field label="Tipe pendapatan">
            <QeSelect
              value={type}
              onValueChange={setType}
              options={[
                { value: 'AD_REVENUE', label: 'Pendapatan Iklan' },
                { value: 'SPONSOR_REVENUE', label: 'Pendapatan Sponsor' },
              ]}
            />
          </Field>
          <Field label="Jumlah (Rp)">
            <QeInput
              type="number"
              min={1}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Contoh: 250000"
              aria-label="Jumlah pendapatan"
            />
          </Field>
          <Field label="Catatan (opsional)">
            <QeInput
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Keterangan pendapatan"
              aria-label="Catatan pendapatan"
            />
          </Field>
        </div>
        <p className="mt-3 text-[11px] text-white/35">
          Pencatatan buku manual. Pendapatan iklan otomatis hanya tercatat setelah jaringan iklan terhubung.
        </p>
        <SmallBtn tone="grad" className="mt-3" onClick={() => void submit()} disabled={busy}>
          {busy ? 'Menyimpan...' : 'Catat Pendapatan'}
        </SmallBtn>
      </GlassCard>

      <GlassCard className="p-5">
        <p className="mb-3 text-xs font-semibold text-white/70">Buku Besar Pendapatan</p>
        {data ? <LedgerTable entries={data.ledger} /> : null}
      </GlassCard>

      <GlassCard className="p-5">
        <p className="mb-3 text-xs font-semibold text-white/70">Event Iklan Terakhir</p>
        {data && data.adEvents.length === 0 ? (
          <EmptyState title="Belum ada event iklan" />
        ) : data ? (
          <div className="qe-scroll max-h-96 space-y-2 overflow-y-auto">
            {data.adEvents.map((ev) => (
              <div
                key={ev.id}
                className="flex flex-wrap items-center gap-2 rounded-xl bg-white/5 px-3 py-2.5 text-xs"
              >
                <Chip className="border-white/15 bg-white/10 text-white/60">{ev.network}</Chip>
                <StatusBadge status={ev.status} />
                <span className="font-semibold text-emerald-300">+{fmtNum(ev.pointsAwarded)} poin</span>
                <span className="text-white/45">@{ev.user.username}</span>
                <span className="ml-auto text-white/35">{fmtDateTime(ev.createdAt)}</span>
              </div>
            ))}
          </div>
        ) : null}
      </GlassCard>
    </div>
  )
}

function SponsorTab({ active }: { active: boolean }) {
  const [sponsors, setSponsors] = useState<Sponsor[] | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(false)
  const [busy, setBusy] = useState(false)
  const [sName, setSName] = useState('')
  const [sLogo, setSLogo] = useState('')
  const [sContact, setSContact] = useState('')
  const [sNotes, setSNotes] = useState('')
  const [cSponsor, setCSponsor] = useState('')
  const [cTitle, setCTitle] = useState('')
  const [cBudget, setCBudget] = useState('')
  const [fundTarget, setFundTarget] = useState<Campaign | null>(null)
  const [fundAmount, setFundAmount] = useState('')
  const [switchingId, setSwitchingId] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      const r = await api<{ sponsors: Sponsor[] }>('/api/admin/sponsors')
      setSponsors(r.sponsors)
    } catch (e) {
      setError(true)
      toast.error(e instanceof Error ? e.message : 'Gagal memuat sponsor.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (active) void load()
  }, [active, load])

  async function submitSponsor() {
    if (!sName.trim()) {
      toast.error('Nama sponsor wajib diisi.')
      return
    }
    setBusy(true)
    try {
      const r = await api<{ success?: boolean; message?: string }>('/api/admin/sponsors', {
        method: 'POST',
        body: {
          kind: 'sponsor',
          name: sName.trim(),
          logoUrl: sLogo.trim() || undefined,
          contact: sContact.trim() || undefined,
          notes: sNotes.trim() || undefined,
        },
      })
      toast.success(r.message || 'Sponsor ditambahkan.')
      setSName('')
      setSLogo('')
      setSContact('')
      setSNotes('')
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal menambahkan sponsor.')
    } finally {
      setBusy(false)
    }
  }

  async function submitCampaign() {
    const n = toNum(cBudget)
    if (!cSponsor) {
      toast.error('Pilih sponsor untuk kampanye.')
      return
    }
    if (!cTitle.trim()) {
      toast.error('Judul kampanye wajib diisi.')
      return
    }
    if (n === null || n <= 0) {
      toast.error('Anggaran kampanye harus berupa angka positif.')
      return
    }
    setBusy(true)
    try {
      const r = await api<{ success?: boolean; message?: string }>('/api/admin/sponsors', {
        method: 'POST',
        body: { kind: 'campaign', sponsorId: cSponsor, title: cTitle.trim(), budget: n },
      })
      toast.success(r.message || 'Kampanye dibuat.')
      setCTitle('')
      setCBudget('')
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal membuat kampanye.')
    } finally {
      setBusy(false)
    }
  }

  async function patchCampaign(campaignId: string, payload: Record<string, unknown>, msg: string) {
    setBusy(true)
    try {
      const r = await api<{ success?: boolean; message?: string }>('/api/admin/sponsors', {
        method: 'PATCH',
        body: { campaignId, ...payload },
      })
      toast.success(r.message || msg)
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Aksi kampanye gagal.')
    } finally {
      setBusy(false)
    }
  }

  async function submitFund() {
    if (!fundTarget) return
    const n = toNum(fundAmount)
    if (n === null || n <= 0) {
      toast.error('Jumlah dana harus berupa angka positif.')
      return
    }
    await patchCampaign(fundTarget.id, { action: 'fund', amount: n }, 'Kampanye didanai.')
    setFundTarget(null)
    setFundAmount('')
  }

  async function toggleSponsor(s: Sponsor, next: boolean) {
    setSwitchingId(s.id)
    try {
      const r = await api<{ success?: boolean; message?: string }>('/api/admin/sponsors', {
        method: 'PATCH',
        body: { sponsorId: s.id, isActive: next },
      })
      toast.success(r.message || 'Status sponsor diperbarui.')
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal mengubah status sponsor.')
    } finally {
      setSwitchingId(null)
    }
  }

  return (
    <div className="space-y-4">
      <div className="grid gap-4 lg:grid-cols-2">
        <GlassCard className="p-5">
          <p className="text-xs font-semibold text-white/70">Tambah Sponsor</p>
          <div className="mt-3 space-y-3">
            <Field label="Nama sponsor">
              <QeInput
                value={sName}
                onChange={(e) => setSName(e.target.value)}
                placeholder="Nama brand atau sponsor"
                aria-label="Nama sponsor"
              />
            </Field>
            <Field label="URL logo (opsional)">
              <QeInput
                value={sLogo}
                onChange={(e) => setSLogo(e.target.value)}
                placeholder="https://contoh.com/logo.png"
                aria-label="URL logo sponsor"
              />
            </Field>
            <Field label="Kontak (opsional)">
              <QeInput
                value={sContact}
                onChange={(e) => setSContact(e.target.value)}
                placeholder="Email atau nomor kontak"
                aria-label="Kontak sponsor"
              />
            </Field>
            <Field label="Catatan (opsional)">
              <QeInput
                value={sNotes}
                onChange={(e) => setSNotes(e.target.value)}
                placeholder="Catatan kerja sama"
                aria-label="Catatan sponsor"
              />
            </Field>
            <SmallBtn tone="grad" onClick={() => void submitSponsor()} disabled={busy}>
              {busy ? 'Menyimpan...' : 'Tambah Sponsor'}
            </SmallBtn>
          </div>
        </GlassCard>

        <GlassCard className="p-5">
          <p className="text-xs font-semibold text-white/70">Tambah Kampanye</p>
          <div className="mt-3 space-y-3">
            <Field label="Sponsor">
              <QeSelect
                value={cSponsor}
                onValueChange={setCSponsor}
                placeholder="Pilih sponsor"
                options={(sponsors ?? []).map((s) => ({ value: s.id, label: s.name }))}
              />
            </Field>
            <Field label="Judul kampanye">
              <QeInput
                value={cTitle}
                onChange={(e) => setCTitle(e.target.value)}
                placeholder="Contoh: Kampanye Kuis Kopi"
                aria-label="Judul kampanye"
              />
            </Field>
            <Field label="Anggaran (Rp)">
              <QeInput
                type="number"
                min={1}
                value={cBudget}
                onChange={(e) => setCBudget(e.target.value)}
                placeholder="Contoh: 500000"
                aria-label="Anggaran kampanye"
              />
            </Field>
            <SmallBtn tone="grad" onClick={() => void submitCampaign()} disabled={busy}>
              {busy ? 'Menyimpan...' : 'Buat Kampanye'}
            </SmallBtn>
          </div>
        </GlassCard>
      </div>

      {loading && !sponsors ? (
        <Loading label="Memuat sponsor..." />
      ) : error && !sponsors ? (
        <ErrorRetry onRetry={() => void load()} />
      ) : sponsors && sponsors.length === 0 ? (
        <EmptyState title="Belum ada sponsor" description="Tambahkan sponsor untuk membuat kampanye." />
      ) : sponsors ? (
        <div className="space-y-3">
          {sponsors.map((s) => (
            <div key={s.id} className="glass rounded-2xl p-4">
              <div className="flex flex-wrap items-center gap-3">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-white">{s.name}</p>
                  <p className="truncate text-[11px] text-white/45">
                    {s.contact ?? 'Tanpa kontak'}
                    {s.notes ? ` · ${s.notes}` : ''}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className={cn('text-[11px] font-medium', s.isActive ? 'text-emerald-300' : 'text-white/40')}>
                    {s.isActive ? 'Aktif' : 'Nonaktif'}
                  </span>
                  <Switch
                    checked={s.isActive}
                    disabled={switchingId === s.id}
                    onCheckedChange={(v) => void toggleSponsor(s, v)}
                    aria-label={`Aktifkan sponsor ${s.name}`}
                  />
                </div>
              </div>
              {s.campaigns.length === 0 ? (
                <p className="mt-3 rounded-xl bg-white/5 px-3 py-2.5 text-[11px] text-white/40">
                  Belum ada kampanye untuk sponsor ini.
                </p>
              ) : (
                <div className="mt-3 space-y-2">
                  {s.campaigns.map((c) => (
                    <div key={c.id} className="rounded-xl border border-white/8 bg-white/5 p-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="text-xs font-semibold text-white/85">{c.title}</p>
                        <StatusBadge status={c.status} />
                      </div>
                      <p className="mt-1 text-[11px] text-white/50">
                        Anggaran: <b className="text-white/80">{rupiah(c.budget)}</b> · Terdanai:{' '}
                        <b className="text-white/80">{rupiah(c.fundedAmount)}</b>
                      </p>
                      <div className="mt-2 flex flex-wrap gap-2">
                        <SmallBtn
                          tone="gold"
                          disabled={busy}
                          onClick={() => {
                            setFundAmount('')
                            setFundTarget(c)
                          }}
                        >
                          Danai
                        </SmallBtn>
                        {c.status !== 'ACTIVE' && c.status !== 'ENDED' && (
                          <SmallBtn
                            tone="emerald"
                            disabled={busy}
                            onClick={() => void patchCampaign(c.id, { action: 'activate' }, 'Kampanye diaktifkan.')}
                          >
                            Aktifkan
                          </SmallBtn>
                        )}
                        {c.status !== 'ENDED' && (
                          <SmallBtn
                            disabled={busy}
                            onClick={() => void patchCampaign(c.id, { action: 'end' }, 'Kampanye diakhiri.')}
                          >
                            Akhiri
                          </SmallBtn>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      ) : null}

      <Dialog
        open={fundTarget !== null}
        onOpenChange={(o) => {
          if (!o && !busy) setFundTarget(null)
        }}
      >
        <DialogContent className="border-white/10">
          <DialogHeader>
            <DialogTitle className="text-white">Danai Kampanye</DialogTitle>
            <DialogDescription>{fundTarget?.title ?? ''}</DialogDescription>
          </DialogHeader>
          <Field label="Jumlah dana (Rp)">
            <QeInput
              type="number"
              min={1}
              value={fundAmount}
              onChange={(e) => setFundAmount(e.target.value)}
              placeholder="Contoh: 100000"
              aria-label="Jumlah dana kampanye"
            />
          </Field>
          <DialogFooter>
            <SmallBtn tone="ghost" onClick={() => setFundTarget(null)} disabled={busy}>
              Batal
            </SmallBtn>
            <SmallBtn tone="gold" onClick={() => void submitFund()} disabled={busy}>
              {busy ? 'Menyimpan...' : 'Danai'}
            </SmallBtn>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function FinanceSection({ active }: { active: boolean }) {
  const [tab, setTab] = useState<'capital' | 'revenue' | 'sponsor'>('capital')

  return (
    <div className="space-y-4">
      <SectionTitle icon={<Landmark size={15} className="text-blue-300" />}>Keuangan</SectionTitle>

      <div className="qe-scroll flex gap-2 overflow-x-auto pb-1">
        {(
          [
            { key: 'capital', label: 'Modal & Buku Besar' },
            { key: 'revenue', label: 'Pendapatan' },
            { key: 'sponsor', label: 'Sponsor' },
          ] as const
        ).map((t) => (
          <button
            key={t.key}
            type="button"
            onClick={() => setTab(t.key)}
            role="tab"
            aria-selected={tab === t.key}
            className={cn(
              'shrink-0 rounded-full border px-3.5 py-2 text-xs font-medium transition',
              tab === t.key
                ? 'glass-strong border-white/15 text-white'
                : 'border-white/10 bg-white/5 text-white/50 hover:text-white'
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className={tab === 'capital' ? 'float-in' : 'hidden'}>
        <CapitalTab active={active && tab === 'capital'} />
      </div>
      <div className={tab === 'revenue' ? 'float-in' : 'hidden'}>
        <RevenueTab active={active && tab === 'revenue'} />
      </div>
      <div className={tab === 'sponsor' ? 'float-in' : 'hidden'}>
        <SponsorTab active={active && tab === 'sponsor'} />
      </div>
    </div>
  )
}

// ============================================================
// SECTION: IKLAN
// ============================================================

function AdsSection({ active }: { active: boolean }) {
  const [data, setData] = useState<AdsData | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(false)
  const [busy, setBusy] = useState(false)
  const [network, setNetwork] = useState('')
  const [adUnitId, setAdUnitId] = useState('')
  const [networkType, setNetworkType] = useState<'ADMOB' | 'CUSTOM'>('CUSTOM')
  const [dailyAdLimit, setDailyAdLimit] = useState('')
  const [adRewardPoints, setAdRewardPoints] = useState('')
  const [allowDevSim, setAllowDevSim] = useState(false)
  const [configured, setConfigured] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      const r = await api<AdsData>('/api/admin/ads')
      setData(r)
      setNetwork(r.network ?? '')
      setAdUnitId(r.adUnitId ?? '')
      setNetworkType(r.networkType ?? 'CUSTOM')
      setDailyAdLimit(r.dailyAdLimit != null ? String(r.dailyAdLimit) : '')
      setAdRewardPoints(r.adRewardPoints != null ? String(r.adRewardPoints) : '')
      setAllowDevSim(r.allowDevSim)
      setConfigured(r.configured)
    } catch (e) {
      setError(true)
      toast.error(e instanceof Error ? e.message : 'Gagal memuat pengaturan iklan.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (active) void load()
  }, [active, load])

  async function save() {
    const limit = toNum(dailyAdLimit)
    const reward = toNum(adRewardPoints)
    if (dailyAdLimit.trim() && (limit === null || limit < 0)) {
      toast.error('Limit iklan harian tidak valid.')
      return
    }
    if (adRewardPoints.trim() && (reward === null || reward < 0)) {
      toast.error('Poin per iklan tidak valid.')
      return
    }
    setBusy(true)
    try {
      const r = await api<{ success?: boolean; message?: string }>('/api/admin/ads', {
        method: 'PATCH',
        body: {
          network: network.trim() || undefined,
          adUnitId: adUnitId.trim() || undefined,
          networkType,
          dailyAdLimit: limit ?? undefined,
          adRewardPoints: reward ?? undefined,
          allowDevSim,
        },
      })
      toast.success(r.message || 'Pengaturan iklan disimpan.')
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal menyimpan pengaturan iklan.')
    } finally {
      setBusy(false)
    }
  }

  async function toggleConfigured(next: boolean) {
    setBusy(true)
    const prev = configured
    setConfigured(next)
    try {
      const r = await api<{ success?: boolean; message?: string }>('/api/admin/ads', {
        method: 'PATCH',
        body: { configured: next },
      })
      toast.success(r.message || (next ? 'Iklan diaktifkan.' : 'Iklan dinonaktifkan.'))
      await load()
    } catch (e) {
      setConfigured(prev)
      toast.error(e instanceof Error ? e.message : 'Gagal mengubah status iklan.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="space-y-4">
      <SectionTitle
        icon={<Megaphone size={15} className="text-blue-300" />}
        action={<ReloadBtn onClick={() => void load()} loading={loading} />}
      >
        Iklan
      </SectionTitle>

      {loading && !data ? (
        <Loading label="Memuat pengaturan iklan..." />
      ) : error && !data ? (
        <ErrorRetry onRetry={() => void load()} />
      ) : data ? (
        <GlassCard className="space-y-4 p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-sm font-semibold text-white">Status Jaringan Iklan</p>
              <p className="mt-0.5 text-[11px] text-white/40">
                {networkType === 'ADMOB'
                  ? 'Mode AdMob SSV - verifikasi signature kunci publik Google (tanpa shared secret).'
                  : `Mode Kustom HMAC - AD_CALLBACK_SECRET: ${data.callbackSecretSet ? 'diatur' : 'belum diatur'}`}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className={cn('text-xs font-medium', configured ? 'text-emerald-300' : 'text-white/40')}>
                {configured ? 'Aktif' : 'Nonaktif'}
              </span>
              <Switch
                checked={configured}
                disabled={busy}
                onCheckedChange={(v) => void toggleConfigured(v)}
                aria-label="Aktifkan iklan"
              />
            </div>
          </div>
          <div className="divider-fade" />
          <Field label="Mode Integrasi">
            <div className="grid grid-cols-2 gap-2">
              {(['ADMOB', 'CUSTOM'] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setNetworkType(t)}
                  aria-pressed={networkType === t}
                  className={cn(
                    'rounded-xl border px-3 py-2.5 text-left text-[11px] font-semibold transition',
                    networkType === t
                      ? 'border-blue-400/50 bg-blue-400/10 text-blue-200'
                      : 'border-white/10 bg-white/5 text-white/50 hover:text-white/80'
                  )}
                >
                  {t === 'ADMOB' ? 'Google AdMob (SSV resmi)' : 'Kustom (HMAC secret)'}
                  <span className="mt-0.5 block text-[9px] font-normal text-white/35">
                    {t === 'ADMOB' ? 'Callback: /api/ads/ssv/admob' : 'Callback: /api/ads/reward'}
                  </span>
                </button>
              ))}
            </div>
          </Field>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Nama Jaringan">
              <QeInput
                value={network}
                onChange={(e) => setNetwork(e.target.value)}
                placeholder={networkType === 'ADMOB' ? 'ADMOB' : 'Contoh: unity'}
                aria-label="Jaringan iklan"
              />
            </Field>
            <Field label="Ad Unit ID">
              <QeInput
                value={adUnitId}
                onChange={(e) => setAdUnitId(e.target.value)}
                placeholder="ID unit iklan"
                aria-label="Ad unit ID"
              />
            </Field>
            <Field label="Limit iklan harian per pengguna">
              <QeInput
                type="number"
                min={0}
                value={dailyAdLimit}
                onChange={(e) => setDailyAdLimit(e.target.value)}
                placeholder="Contoh: 20"
                aria-label="Limit iklan harian"
              />
            </Field>
            <Field label="Poin hadiah per iklan">
              <QeInput
                type="number"
                min={0}
                value={adRewardPoints}
                onChange={(e) => setAdRewardPoints(e.target.value)}
                placeholder="Contoh: 5"
                aria-label="Poin per iklan"
              />
            </Field>
          </div>
          {networkType === 'ADMOB' && (
            <div className="rounded-xl border border-blue-400/25 bg-blue-400/5 px-3.5 py-3">
              <p className="text-[11px] font-bold text-blue-200">Langkah aktivasi AdMob:</p>
              <ol className="mt-1.5 space-y-1 text-[10px] leading-relaxed text-white/50">
                <li>1. Buat Ad Unit Rewarded di AdMob console, isi Ad Unit ID di atas.</li>
                <li>2. Pasang URL SSV callback berikut pada AdMob console (Server-side verification):</li>
              </ol>
              <code className="mt-1.5 block break-all rounded-lg bg-black/40 px-2.5 py-1.5 text-[10px] text-blue-200">
                https://domain-anda.com/api/ads/ssv/admob
              </code>
              <p className="mt-1.5 text-[10px] leading-relaxed text-white/50">
                3. Pada klien: setUserId(id akun) + setCustomData([adEventId]) sebelum memutar iklan. 4. Aktifkan sakelar di atas.
              </p>
            </div>
          )}
          <div className="flex items-center justify-between rounded-xl bg-white/5 px-3 py-2.5">
            <span className="text-xs text-white/70">Izinkan simulasi iklan (mode dev)</span>
            <Switch
              checked={allowDevSim}
              disabled={busy}
              onCheckedChange={setAllowDevSim}
              aria-label="Izinkan simulasi iklan"
            />
          </div>
          <SmallBtn tone="grad" onClick={() => void save()} disabled={busy}>
            {busy ? 'Menyimpan...' : 'Simpan Perubahan'}
          </SmallBtn>
        </GlassCard>
      ) : null}
    </div>
  )
}

// ============================================================
// SECTION: PENGATURAN
// ============================================================

function SettingsSection({ active }: { active: boolean }) {
  const [meta, setMeta] = useState<SettingsData | null>(null)
  const [form, setForm] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(false)
  const [busy, setBusy] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      const r = await api<SettingsData>('/api/admin/settings')
      setMeta(r)
      setForm({ ...r.settings })
    } catch (e) {
      setError(true)
      toast.error(e instanceof Error ? e.message : 'Gagal memuat pengaturan.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (active) void load()
  }, [active, load])

  function updateField(key: string, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }))
  }

  async function save() {
    const allowed = meta?.allowedKeys ?? []
    const keyEnabled = (k: string) => allowed.length === 0 || allowed.includes(k)
    const payload: Record<string, string> = {}
    for (const item of NUMBER_SETTINGS) {
      if (keyEnabled(item.key)) payload[item.key] = form[item.key] ?? ''
    }
    for (const item of BOOL_SETTINGS) {
      if (keyEnabled(item.key)) payload[item.key] = form[item.key] === 'true' ? 'true' : 'false'
    }
    if (keyEnabled('payoutMode')) payload.payoutMode = form.payoutMode ?? 'manual'
    setBusy(true)
    try {
      await api<{ success?: boolean; message?: string }>('/api/admin/settings', {
        method: 'PATCH',
        body: payload,
      })
      toast.success('Pengaturan disimpan.')
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal menyimpan pengaturan.')
    } finally {
      setBusy(false)
    }
  }

  const allowed = meta?.allowedKeys ?? []
  const keyEnabled = (k: string) => allowed.length === 0 || allowed.includes(k)
  const auto = meta?.automaticPayout

  return (
    <div className="space-y-4">
      <SectionTitle
        icon={<Settings size={15} className="text-blue-300" />}
        action={<ReloadBtn onClick={() => void load()} loading={loading} />}
      >
        Pengaturan
      </SectionTitle>

      {loading && !meta ? (
        <Loading label="Memuat pengaturan..." />
      ) : error && !meta ? (
        <ErrorRetry onRetry={() => void load()} />
      ) : meta ? (
        <>
          <GlassCard className="space-y-4 p-5">
            <p className="text-xs font-semibold text-white/70">Ekonomi & Kuis</p>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {NUMBER_SETTINGS.filter((k) => keyEnabled(k.key)).map((k) => (
                <Field key={k.key} label={k.label}>
                  <QeInput
                    type="number"
                    inputMode="numeric"
                    value={form[k.key] ?? ''}
                    onChange={(e) => updateField(k.key, e.target.value)}
                    aria-label={k.label}
                  />
                </Field>
              ))}
            </div>
          </GlassCard>

          <GlassCard className="space-y-4 p-5">
            <p className="text-xs font-semibold text-white/70">Metode & Fitur</p>
            <div className="grid gap-2 sm:grid-cols-2">
              {BOOL_SETTINGS.filter((k) => keyEnabled(k.key)).map((k) => (
                <div key={k.key} className="flex items-center justify-between rounded-xl bg-white/5 px-3 py-2.5">
                  <span className="text-xs text-white/70">{k.label}</span>
                  <Switch
                    checked={form[k.key] === 'true'}
                    disabled={busy}
                    onCheckedChange={(v) => updateField(k.key, String(v))}
                    aria-label={k.label}
                  />
                </div>
              ))}
            </div>
            {keyEnabled('payoutMode') && (
              <Field label="Mode pembayaran pencairan" hint="manual: diproses admin. automatic: via API disbursement.">
                <QeSelect
                  value={form.payoutMode ?? 'manual'}
                  onValueChange={(v) => updateField('payoutMode', v)}
                  options={[
                    { value: 'manual', label: 'Manual' },
                    { value: 'automatic', label: 'Otomatis' },
                  ]}
                />
              </Field>
            )}
          </GlassCard>

          <GlassCard className="p-5">
            <p className="text-xs font-semibold text-white/70">Status Integrasi Pembayaran Otomatis</p>
            <div className="mt-3 space-y-2.5">
              <StatusDot ok={auto?.disburseUrl} label="DISBURSE_API_URL" />
              <StatusDot ok={auto?.disburseKey} label="DISBURSE_API_KEY" />
              <StatusDot ok={auto?.webhookSecret} label="PAYMENT_WEBHOOK_SECRET" />
            </div>
          </GlassCard>

          <SmallBtn tone="grad" className="w-full sm:w-auto" onClick={() => void save()} disabled={busy}>
            {busy ? 'Menyimpan...' : 'Simpan Pengaturan'}
          </SmallBtn>
        </>
      ) : null}
    </div>
  )
}

// ============================================================
// SECTION: AUDIT & FRAUD
// ============================================================

function AuditTab({ active }: { active: boolean }) {
  const [logs, setLogs] = useState<AuditLog[] | null>(null)
  const [page, setPage] = useState(1)
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(false)
  const initRef = useRef(false)

  const loadPage = useCallback(async (p: number, append: boolean) => {
    setLoading(true)
    setError(false)
    try {
      const r = await api<AuditData>(`/api/admin/audit?page=${p}`)
      setLogs((prev) => (append && prev ? [...prev, ...r.logs] : r.logs))
      setPage(p)
      setTotal(r.total)
    } catch (e) {
      setError(true)
      toast.error(e instanceof Error ? e.message : 'Gagal memuat log audit.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (active && !initRef.current) {
      initRef.current = true
      void loadPage(1, false)
    }
  }, [active, loadPage])

  return (
    <div className="space-y-3">
      {logs === null && !error ? (
        <Loading label="Memuat log audit..." />
      ) : logs === null && error ? (
        <ErrorRetry onRetry={() => void loadPage(1, false)} />
      ) : logs && logs.length === 0 ? (
        <EmptyState title="Belum ada log audit" />
      ) : logs ? (
        <>
          <div className="space-y-2">
            {logs.map((l) => (
              <div key={l.id} className="rounded-xl bg-white/5 px-3 py-2.5 text-xs">
                <div className="flex flex-wrap items-center gap-2">
                  <Chip className="border-white/15 bg-white/10 text-white/70">{l.action}</Chip>
                  <span className="text-white/50">
                    {l.targetType ? `${l.targetType} #${l.targetId ? l.targetId.slice(0, 8) : '-'}` : 'Sistem'}
                  </span>
                  <span className="ml-auto text-white/35">{fmtDateTime(l.createdAt)}</span>
                </div>
                <p className="mt-1 text-white/60">
                  Oleh <b className="text-white/80">{l.adminName}</b>
                  {l.detail ? ` - ${l.detail}` : ''}
                </p>
              </div>
            ))}
          </div>
          {logs.length < total && (
            <div className="flex justify-center">
              <SmallBtn onClick={() => void loadPage(page + 1, true)} disabled={loading}>
                Muat Lagi ({logs.length}/{fmtNum(total)})
              </SmallBtn>
            </div>
          )}
        </>
      ) : null}
    </div>
  )
}

function FraudTab({ active }: { active: boolean }) {
  const [events, setEvents] = useState<FraudEvent[] | null>(null)
  const [page, setPage] = useState(1)
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(false)
  const initRef = useRef(false)

  const loadPage = useCallback(async (p: number, append: boolean) => {
    setLoading(true)
    setError(false)
    try {
      const r = await api<FraudData>(`/api/admin/fraud?page=${p}`)
      setEvents((prev) => (append && prev ? [...prev, ...r.events] : r.events))
      setPage(p)
      setTotal(r.total)
    } catch (e) {
      setError(true)
      toast.error(e instanceof Error ? e.message : 'Gagal memuat event fraud.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (active && !initRef.current) {
      initRef.current = true
      void loadPage(1, false)
    }
  }, [active, loadPage])

  const SEVERITY_STYLES: Record<string, string> = {
    HIGH: 'border-rose-400/25 bg-rose-500/15 text-rose-300',
    MEDIUM: 'border-amber-400/25 bg-amber-500/15 text-amber-300',
    LOW: 'border-emerald-400/25 bg-emerald-500/15 text-emerald-300',
  }

  return (
    <div className="space-y-3">
      {events === null && !error ? (
        <Loading label="Memuat event fraud..." />
      ) : events === null && error ? (
        <ErrorRetry onRetry={() => void loadPage(1, false)} />
      ) : events && events.length === 0 ? (
        <EmptyState title="Tidak ada event fraud" description="Sistem tidak mendeteksi aktivitas mencurigakan." />
      ) : events ? (
        <>
          <div className="space-y-2">
            {events.map((ev) => (
              <div key={ev.id} className="rounded-xl bg-white/5 px-3 py-2.5 text-xs">
                <div className="flex flex-wrap items-center gap-2">
                  <Chip className={SEVERITY_STYLES[ev.severity] ?? 'border-white/15 bg-white/10 text-white/60'}>
                    {ev.severity}
                  </Chip>
                  <Chip className="border-white/15 bg-white/10 text-white/70">{ev.type}</Chip>
                  {ev.user && (
                    <span className="text-white/50">
                      @{ev.user.username}
                      {ev.user.isBlocked ? ' (diblokir)' : ''}
                    </span>
                  )}
                  <span className="ml-auto text-white/35">{fmtDateTime(ev.createdAt)}</span>
                </div>
                {ev.detail && <p className="mt-1 text-white/60">{ev.detail}</p>}
              </div>
            ))}
          </div>
          {events.length < total && (
            <div className="flex justify-center">
              <SmallBtn onClick={() => void loadPage(page + 1, true)} disabled={loading}>
                Muat Lagi ({events.length}/{fmtNum(total)})
              </SmallBtn>
            </div>
          )}
        </>
      ) : null}
    </div>
  )
}

function AuditFraudSection({ active }: { active: boolean }) {
  const [tab, setTab] = useState<'audit' | 'fraud'>('audit')

  return (
    <div className="space-y-4">
      <SectionTitle icon={<ShieldAlert size={15} className="text-blue-300" />}>Audit &amp; Fraud</SectionTitle>

      <div className="flex gap-2">
        {(
          [
            { key: 'audit', label: 'Log Audit' },
            { key: 'fraud', label: 'Event Fraud' },
          ] as const
        ).map((t) => (
          <button
            key={t.key}
            type="button"
            onClick={() => setTab(t.key)}
            role="tab"
            aria-selected={tab === t.key}
            className={cn(
              'rounded-full border px-3.5 py-2 text-xs font-medium transition',
              tab === t.key
                ? 'glass-strong border-white/15 text-white'
                : 'border-white/10 bg-white/5 text-white/50 hover:text-white'
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className={tab === 'audit' ? 'float-in' : 'hidden'}>
        <AuditTab active={active && tab === 'audit'} />
      </div>
      <div className={tab === 'fraud' ? 'float-in' : 'hidden'}>
        <FraudTab active={active && tab === 'fraud'} />
      </div>
    </div>
  )
}

// ============================================================
// SECTION: NOTIFIKASI & DUKUNGAN
// ============================================================

function SupportSection({ active }: { active: boolean }) {
  const [data, setData] = useState<NotifAdminData | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(false)
  const [title, setTitle] = useState('')
  const [body, setBody] = useState('')
  const [kind, setKind] = useState('INFO')
  const [busy, setBusy] = useState(false)
  const [resolvingId, setResolvingId] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(false)
    try {
      setData(await api<NotifAdminData>('/api/admin/notifications'))
    } catch (e) {
      setError(true)
      toast.error(e instanceof Error ? e.message : 'Gagal memuat notifikasi & dukungan.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (active) void load()
  }, [active, load])

  async function submitBroadcast() {
    if (!title.trim() || !body.trim()) {
      toast.error('Judul dan isi broadcast wajib diisi.')
      return
    }
    setBusy(true)
    try {
      const r = await api<{ success?: boolean; message?: string }>('/api/admin/notifications', {
        method: 'POST',
        body: { title: title.trim(), body: body.trim(), kind },
      })
      toast.success(r.message || 'Broadcast terkirim.')
      setTitle('')
      setBody('')
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal mengirim broadcast.')
    } finally {
      setBusy(false)
    }
  }

  async function resolveSupport(m: SupportMessage) {
    setResolvingId(m.id)
    try {
      const r = await api<{ success?: boolean; message?: string }>('/api/admin/notifications', {
        method: 'PATCH',
        body: { id: m.id, status: 'RESOLVED' },
      })
      toast.success(r.message || 'Pesan dukungan ditandai selesai.')
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal menandai selesai.')
    } finally {
      setResolvingId(null)
    }
  }

  return (
    <div className="space-y-4">
      <SectionTitle
        icon={<Bell size={15} className="text-blue-300" />}
        action={<ReloadBtn onClick={() => void load()} loading={loading} />}
      >
        Notifikasi &amp; Dukungan
      </SectionTitle>

      {loading && !data ? (
        <Loading label="Memuat data..." />
      ) : error && !data ? (
        <ErrorRetry onRetry={() => void load()} />
      ) : data ? (
        <>
          <GlassCard className="p-5">
            <p className="text-xs font-semibold text-white/70">Broadcast ke Semua Pengguna</p>
            <div className="mt-3 space-y-3">
              <Field label="Judul">
                <QeInput
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Judul pengumuman"
                  aria-label="Judul broadcast"
                />
              </Field>
              <Field label="Isi pesan">
                <QeTextarea
                  value={body}
                  onChange={(e) => setBody(e.target.value)}
                  placeholder="Tulis isi pengumuman"
                  aria-label="Isi broadcast"
                />
              </Field>
              <Field label="Jenis">
                <QeSelect value={kind} onValueChange={setKind} options={KIND_OPTIONS} />
              </Field>
              <SmallBtn tone="grad" onClick={() => void submitBroadcast()} disabled={busy}>
                {busy ? 'Mengirim...' : 'Kirim Broadcast'}
              </SmallBtn>
            </div>
          </GlassCard>

          <GlassCard className="p-5">
            <p className="mb-3 text-xs font-semibold text-white/70">Broadcast Terkirim</p>
            {data.sent.length === 0 ? (
              <EmptyState title="Belum ada broadcast" />
            ) : (
              <div className="qe-scroll max-h-96 space-y-2 overflow-y-auto">
                {data.sent.map((s) => (
                  <div key={s.id} className="rounded-xl bg-white/5 px-3 py-2.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-xs font-semibold text-white/85">{s.title}</p>
                      <KindChip kind={s.kind} />
                      <span className="ml-auto text-[10px] text-white/35">{fmtDateTime(s.createdAt)}</span>
                    </div>
                    <p className="mt-1 text-[11px] text-white/55">{s.body}</p>
                  </div>
                ))}
              </div>
            )}
          </GlassCard>

          <GlassCard className="p-5">
            <p className="mb-3 text-xs font-semibold text-white/70">Pesan Dukungan</p>
            {data.support.length === 0 ? (
              <EmptyState title="Tidak ada pesan dukungan" />
            ) : (
              <div className="qe-scroll max-h-96 space-y-2 overflow-y-auto">
                {data.support.map((m) => (
                  <div key={m.id} className="rounded-xl bg-white/5 px-3 py-2.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-xs font-semibold text-white/85">{m.subject}</p>
                      <Chip className="border-white/15 bg-white/10 text-white/60">{m.category}</Chip>
                      <StatusBadge status={m.status} />
                      <span className="ml-auto text-[10px] text-white/35">{fmtDateTime(m.createdAt)}</span>
                    </div>
                    <p className="mt-1 text-[11px] text-white/50">
                      {m.name} · {m.email}
                    </p>
                    <p className="mt-1 text-[11px] text-white/60">{m.message}</p>
                    {m.status !== 'RESOLVED' && (
                      <SmallBtn
                        tone="emerald"
                        className="mt-2"
                        disabled={resolvingId === m.id}
                        onClick={() => void resolveSupport(m)}
                      >
                        {resolvingId === m.id ? 'Menyimpan...' : 'Tandai Selesai'}
                      </SmallBtn>
                    )}
                  </div>
                ))}
              </div>
            )}
          </GlassCard>
        </>
      ) : null}
    </div>
  )
}

// ============================================================
// ROOT: ADMIN VIEW
// ============================================================

export function AdminView() {
  const { go } = useApp()
  const [checking, setChecking] = useState(true)
  const [adminName, setAdminName] = useState<string | null>(null)
  const [section, setSection] = useState<SectionKey>('overview')

  // Pulihkan sesi admin bila kuki masih valid.
  useEffect(() => {
    let cancelled = false
    api<OverviewData>('/api/admin/overview')
      .then(() => {
        if (!cancelled) setAdminName('Administrator')
      })
      .catch(() => {
        /* belum login - tampilkan form login */
      })
      .finally(() => {
        if (!cancelled) setChecking(false)
      })
    return () => {
      cancelled = true
    }
  }, [])

  async function logout() {
    try {
      await api<{ success: boolean }>('/api/admin/logout', { method: 'POST', body: {} })
    } catch {
      /* tetap keluar secara lokal */
    }
    clearAdminToken()
    setAdminName(null)
    setSection('overview')
    toast.success('Anda telah keluar dari panel admin.')
    go('welcome')
  }

  if (checking) {
    return (
      <main className="qe-bg flex min-h-svh items-center justify-center">
        <Loading label="Memeriksa sesi admin..." />
      </main>
    )
  }

  if (!adminName) return <LoginScreen onLogin={setAdminName} />

  return (
    <main className="qe-bg min-h-svh">
      <header className="glass-strong sticky top-0 z-40 border-b border-white/10">
        <div className="mx-auto flex h-14 w-full max-w-5xl items-center gap-3 px-4">
          <div className="btn-grad flex h-8 w-8 shrink-0 items-center justify-center rounded-lg" aria-hidden>
            <Zap size={15} />
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-bold text-white">Panel Administrator</p>
            <p className="text-[10px] uppercase tracking-widest text-white/35">QUIZ &amp; EARN</p>
          </div>
          <div className="ml-auto flex items-center gap-2.5">
            <span className="hidden text-xs text-white/55 sm:block">{adminName}</span>
            <button
              type="button"
              onClick={() => void logout()}
              className="glass flex h-9 items-center gap-1.5 rounded-xl px-3 text-xs font-semibold text-white/70 transition hover:text-white"
            >
              <LogOut size={13} />
              Keluar
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto w-full max-w-5xl px-4 py-5">
        {/* Navigasi mobile: chips horizontal */}
        <div className="qe-scroll -mx-4 mb-4 flex gap-2 overflow-x-auto px-4 pb-1 md:hidden" role="tablist" aria-label="Menu admin">
          {SECTIONS.map((s) => (
            <button
              key={s.key}
              type="button"
              role="tab"
              aria-selected={section === s.key}
              onClick={() => setSection(s.key)}
              className={cn(
                'flex shrink-0 items-center gap-1.5 rounded-full border px-3.5 py-2 text-xs font-medium transition',
                section === s.key
                  ? 'glass-strong border-white/15 text-white'
                  : 'border-white/10 bg-white/5 text-white/50'
              )}
            >
              <s.icon size={13} />
              {s.label}
            </button>
          ))}
        </div>

        <div className="flex gap-6">
          {/* Sidebar desktop */}
          <aside className="sticky top-[72px] hidden h-fit w-56 shrink-0 md:block">
            <nav className="glass rounded-2xl p-2" aria-label="Menu admin">
              {SECTIONS.map((s) => (
                <button
                  key={s.key}
                  type="button"
                  onClick={() => setSection(s.key)}
                  aria-current={section === s.key ? 'page' : undefined}
                  className={cn(
                    'flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-left text-[13px] transition',
                    section === s.key
                      ? 'glass-strong font-semibold text-white'
                      : 'text-white/55 hover:bg-white/5 hover:text-white'
                  )}
                >
                  <s.icon size={15} className={section === s.key ? 'text-amber-300' : 'text-white/40'} />
                  {s.label}
                </button>
              ))}
            </nav>
          </aside>

          {/* Konten */}
          <div className="min-w-0 max-w-4xl flex-1">
            {SECTIONS.map((s) => (
              <div key={s.key} className={section === s.key ? 'float-in' : 'hidden'}>
                {s.key === 'overview' && <OverviewSection active={section === 'overview'} />}
                {s.key === 'users' && <UsersSection active={section === 'users'} />}
                {s.key === 'categories' && <CategoriesSection active={section === 'categories'} />}
                {s.key === 'questions' && <QuestionsSection active={section === 'questions'} />}
                {s.key === 'withdrawals' && <WithdrawalsSection active={section === 'withdrawals'} />}
                {s.key === 'finance' && <FinanceSection active={section === 'finance'} />}
                {s.key === 'ads' && <AdsSection active={section === 'ads'} />}
                {s.key === 'settings' && <SettingsSection active={section === 'settings'} />}
                {s.key === 'audit' && <AuditFraudSection active={section === 'audit'} />}
                {s.key === 'support' && <SupportSection active={section === 'support'} />}
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}
