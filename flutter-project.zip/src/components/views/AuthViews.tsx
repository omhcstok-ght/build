'use client'

import { useState } from 'react'
import Link from 'next/link'
import { toast } from 'sonner'
import { useApp } from '@/lib/store'
import { api, saveUserToken } from '@/lib/api'
import { motion } from 'framer-motion'

function AuthShell({
  title,
  subtitle,
  children,
}: {
  title: string
  subtitle: string
  children: React.ReactNode
}) {
  const go = useApp((s) => s.go)
  return (
    <main className="qe-bg flex min-h-svh flex-col">
      <div className="mx-auto flex w-full max-w-md flex-1 flex-col px-5 py-8">
        <button
          onClick={() => go('welcome')}
          className="glass mb-6 flex h-10 w-10 items-center justify-center rounded-full text-white/70 transition hover:text-white active:scale-95"
          aria-label="Kembali"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
            <path d="M15 18l-6-6 6-6" />
          </svg>
        </button>
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
          <h1 className="text-2xl font-bold text-white">{title}</h1>
          <p className="mt-1.5 text-sm text-white/50">{subtitle}</p>
          <div className="mt-7 space-y-4">{children}</div>
        </motion.div>
      </div>
    </main>
  )
}

export function LoginView() {
  const go = useApp((s) => s.go)
  const setUser = useApp((s) => s.setUser)
  const authNotice = useApp((s) => s.authNotice)
  const [identifier, setIdentifier] = useState('')
  const [password, setPassword] = useState('')
  const [showPw, setShowPw] = useState(false)
  const [busy, setBusy] = useState(false)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (busy) return
    setBusy(true)
    try {
      const d = await api<{ token?: string; user: { id: string; name: string; username: string; email: string; avatar: string | null } }>(
        '/api/auth/login',
        { method: 'POST', body: { identifier, password } }
      )
      saveUserToken(d.token)
      setUser(d.user)
      go('dashboard')
      toast.success(`Selamat datang kembali, ${d.user.name}!`)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Gagal masuk.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <AuthShell title="Masuk" subtitle="Lanjutkan perjalanan mengumpulkan hadiahmu.">
      {authNotice && (
        <div className="rounded-xl border border-amber-400/25 bg-amber-400/10 px-4 py-3 text-xs text-amber-200">
          {authNotice}
        </div>
      )}
      <form onSubmit={submit} className="space-y-4" autoComplete="on">
        <div>
          <label htmlFor="identifier" className="mb-1.5 block text-xs font-medium text-white/60">Email atau Username</label>
          <input
            id="identifier"
            className="qe-input"
            placeholder="nama@email.com"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            autoComplete="username"
            required
          />
        </div>
        <div>
          <label htmlFor="password" className="mb-1.5 block text-xs font-medium text-white/60">Password</label>
          <div className="relative">
            <input
              id="password"
              type={showPw ? 'text' : 'password'}
              className="qe-input pr-12"
              placeholder="Password kamu"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
              required
            />
            <button
              type="button"
              onClick={() => setShowPw(!showPw)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-medium text-white/40 hover:text-white/70"
            >
              {showPw ? 'Sembunyi' : 'Lihat'}
            </button>
          </div>
        </div>
        <div className="text-right">
          <button type="button" onClick={() => go('forgot')} className="text-xs font-medium text-blue-300 hover:text-blue-200">
            Lupa password?
          </button>
        </div>
        <button type="submit" disabled={busy} className="btn-grad w-full rounded-2xl py-3.5 text-sm font-bold">
          {busy ? 'Memproses...' : 'Masuk'}
        </button>
      </form>

      <div className="flex items-center gap-3">
        <div className="divider-fade flex-1" />
        <span className="text-[10px] uppercase tracking-widest text-white/30">atau</span>
        <div className="divider-fade flex-1" />
      </div>

      {/* Google OAuth: tombol nyata, aktif hanya bila server terkonfigurasi.
          Bila belum, server mengembalikan status dan UI menjelaskannya dengan jujur. */}
      <a
        href="/api/auth/google"
        className="glass flex w-full items-center justify-center gap-3 rounded-2xl py-3.5 text-sm font-bold text-white transition hover:bg-white/10 active:scale-[0.98]"
      >
        <svg width="18" height="18" viewBox="0 0 24 24">
          <path fill="#4285F4" d="M23.5 12.3c0-.9-.1-1.5-.3-2.2H12v4.1h6.5c-.1 1.1-.8 2.7-2.4 3.8l3.7 2.9c2.3-2.1 3.7-5.1 3.7-8.6z" />
          <path fill="#34A853" d="M12 24c3.2 0 5.9-1.1 7.9-2.9l-3.7-2.9c-1 .7-2.4 1.2-4.2 1.2-3.1 0-5.8-2.1-6.8-5l-3.9 3C3.3 21.3 7.3 24 12 24z" />
          <path fill="#FBBC05" d="M5.2 14.4c-.2-.7-.4-1.5-.4-2.4s.1-1.7.4-2.4l-3.9-3C.5 8.2 0 10 0 12s.5 3.8 1.3 5.4l3.9-3z" />
          <path fill="#EA4335" d="M12 4.7c2.2 0 3.7.9 4.5 1.7l3.3-3.2C17.9 1.2 15.2 0 12 0 7.3 0 3.3 2.7 1.3 6.6l3.9 3c1-2.9 3.7-4.9 6.8-4.9z" />
        </svg>
        Masuk dengan Google
      </a>
      <p className="text-center text-[11px] leading-relaxed text-white/30">
        Google OAuth terintegrasi penuh. Bila akun Google belum terhubung pada server, tombol akan
        menampilkan pesan konfigurasi - tanpa login palsu.
      </p>

      <p className="pt-2 text-center text-sm text-white/50">
        Belum punya akun?{' '}
        <button onClick={() => go('register')} className="font-semibold text-blue-300 hover:text-blue-200">
          Daftar sekarang
        </button>
      </p>

      <p className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-center text-[11px] leading-relaxed text-white/40">
        Halaman ini khusus akun <b className="text-white/60">pemain</b>. Akun admin/developer masuk melalui{' '}
        <b className="text-white/60">Portal Administrator</b> di layar awal.
      </p>
    </AuthShell>
  )
}

export function RegisterView() {
  const go = useApp((s) => s.go)
  const setUser = useApp((s) => s.setUser)
  const [form, setForm] = useState({ name: '', username: '', email: '', password: '', confirmPassword: '' })
  const [busy, setBusy] = useState(false)

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm({ ...form, [k]: e.target.value })

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (busy) return
    setBusy(true)
    try {
      const d = await api<{ token?: string; user: { id: string; name: string; username: string; email: string; avatar: string | null } }>(
        '/api/auth/register',
        { method: 'POST', body: form }
      )
      saveUserToken(d.token)
      setUser(d.user)
      go('dashboard')
      toast.success('Akun berhasil dibuat. Selamat datang!')
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Gagal mendaftar.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <AuthShell title="Buat Akun" subtitle="Gratis, satu menit selesai. Mulai menang hari ini.">
      <form onSubmit={submit} className="space-y-4" autoComplete="on">
        <div>
          <label htmlFor="name" className="mb-1.5 block text-xs font-medium text-white/60">Nama Lengkap</label>
          <input id="name" className="qe-input" placeholder="Nama sesuai identitas" value={form.name} onChange={set('name')} autoComplete="name" required />
        </div>
        <div>
          <label htmlFor="username" className="mb-1.5 block text-xs font-medium text-white/60">Username</label>
          <input id="username" className="qe-input" placeholder="username_unik" value={form.username} onChange={set('username')} autoComplete="username" required />
        </div>
        <div>
          <label htmlFor="email" className="mb-1.5 block text-xs font-medium text-white/60">Email</label>
          <input id="email" type="email" className="qe-input" placeholder="nama@email.com" value={form.email} onChange={set('email')} autoComplete="email" required />
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="reg-password" className="mb-1.5 block text-xs font-medium text-white/60">Password</label>
            <input id="reg-password" type="password" className="qe-input" placeholder="Minimal 8 karakter" value={form.password} onChange={set('password')} autoComplete="new-password" required />
          </div>
          <div>
            <label htmlFor="confirm" className="mb-1.5 block text-xs font-medium text-white/60">Konfirmasi</label>
            <input id="confirm" type="password" className="qe-input" placeholder="Ulangi password" value={form.confirmPassword} onChange={set('confirmPassword')} autoComplete="new-password" required />
          </div>
        </div>
        <button type="submit" disabled={busy} className="btn-grad w-full rounded-2xl py-3.5 text-sm font-bold">
          {busy ? 'Mendaftarkan...' : 'Daftar Sekarang'}
        </button>
      </form>
      <p className="pt-2 text-center text-sm text-white/50">
        Sudah punya akun?{' '}
        <button onClick={() => go('login')} className="font-semibold text-blue-300 hover:text-blue-200">
          Masuk
        </button>
      </p>
      <p className="text-center text-[11px] leading-relaxed text-white/30">
        Dengan mendaftar, kamu menyetujui Syarat &amp; Ketentuan dan Kebijakan Privasi.
      </p>
    </AuthShell>
  )
}

export function ForgotView() {
  const go = useApp((s) => s.go)
  const [email, setEmail] = useState('')
  const [busy, setBusy] = useState(false)
  const [done, setDone] = useState<string | null>(null)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (busy) return
    setBusy(true)
    try {
      const d = await api<{ message: string }>('/api/auth/forgot', { method: 'POST', body: { email } })
      setDone(d.message)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Gagal mengirim permintaan.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <AuthShell title="Lupa Password" subtitle="Kami bantu pulihkan akses akunmu.">
      {done ? (
        <div className="space-y-5">
          <div className="rounded-xl border border-emerald-400/25 bg-emerald-400/10 px-4 py-4 text-sm leading-relaxed text-emerald-200">
            {done}
          </div>
          <button onClick={() => go('login')} className="btn-grad w-full rounded-2xl py-3.5 text-sm font-bold">
            Kembali ke Masuk
          </button>
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-4">
          <div>
            <label htmlFor="fp-email" className="mb-1.5 block text-xs font-medium text-white/60">Email Terdaftar</label>
            <input id="fp-email" type="email" className="qe-input" placeholder="nama@email.com" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-[11px] leading-relaxed text-white/45">
            Layanan email otomatis belum terhubung pada server ini. Permintaanmu masuk ke antrean
            admin dan password akan direset setelah verifikasi identitas - tanpa simulasi email palsu.
          </div>
          <button type="submit" disabled={busy} className="btn-grad w-full rounded-2xl py-3.5 text-sm font-bold">
            {busy ? 'Mengirim...' : 'Kirim Permintaan Reset'}
          </button>
        </form>
      )}
    </AuthShell>
  )
}
