'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { useApp } from '@/lib/store'
import { api, rupiah, fmtNum, fmtDateTime } from '@/lib/api'
import { GlassCard, SectionTitle, StatTile, ProgressBar, Loading, Avatar } from '@/components/shared'
import { toast } from 'sonner'

interface DashboardData {
  user: { name: string; username: string; avatar: string | null; emailVerified: boolean; bonusStreak: number }
  points: { pending: number; available: number; estimate: number }
  wallet: { available: number; processing: number; totalPaid: number }
  rules: { conversionRate: number; quizTimeSeconds: number; pointsEasy: number; luckyBonusPoints: number }
  activities: { id: string; type: string; amount: number; bucket: string; createdAt: string }[]
  missions: { code: string; progress: number; claimed: boolean }[]
  announcements: { id: string; title: string; body: string; kind: string; createdAt: string }[]
  promos: { id: string; title: string; sponsor: string; status: string }[]
  unreadCount: number
  bonusReady: boolean
}

const MISSION_TITLES: Record<string, string> = {
  LOGIN: 'Login Harian',
  PLAY3: 'Selesaikan 3 Sesi',
  CORRECT10: 'Jawab 10 Soal Benar',
  PERFECT1: 'Skor Sempurna',
}

const MISSION_TARGETS: Record<string, number> = { LOGIN: 1, PLAY3: 3, CORRECT10: 10, PERFECT1: 1 }

const ACTIVITY_LABEL: Record<string, string> = {
  EARN_QUIZ: 'Jawaban benar',
  EARN_STREAK: 'Bonus streak',
  EARN_COMPLETION: 'Bonus penyelesaian',
  EARN_PERFECT: 'Bonus sempurna',
  EARN_MISSION: 'Hadiah misi',
  EARN_BONUS: 'Lucky bonus',
  EARN_AD: 'Reward iklan',
  RELEASE: 'Poin dirilis',
  CONVERT_OUT: 'Tukar ke saldo',
  ADJUST: 'Penyesuaian admin',
}

function activityIcon(type: string) {
  if (type.startsWith('EARN'))
    return (
      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-400/10 text-emerald-300">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M12 19V5M5 12l7-7 7 7" /></svg>
      </span>
    )
  if (type === 'CONVERT_OUT')
    return (
      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-400/10 text-amber-300">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M6 3h12M6 8h12M6 13l6 8 6-8H6z" /></svg>
      </span>
    )
  return (
    <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/10 text-white/50">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 3" /></svg>
    </span>
  )
}

export function DashboardView() {
  const { go, user, setUser } = useApp()
  const [data, setData] = useState<DashboardData | null>(null)
  const [claiming, setClaiming] = useState(false)

  useEffect(() => {
    api<DashboardData>('/api/dashboard')
      .then(setData)
      .catch((e) => toast.error(e.message))
  }, [])

  async function claimBonus() {
    if (claiming) return
    setClaiming(true)
    try {
      const d = await api<{ reward: number; message: string }>('/api/bonus', { method: 'POST', body: {} })
      toast.success(d.message)
      const [dash, me] = await Promise.all([api<DashboardData>('/api/dashboard'), api<{ user: typeof user }>('/api/auth/me')])
      setData(dash)
      if (me.user) setUser(me.user)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Gagal klaim bonus.')
    } finally {
      setClaiming(false)
    }
  }

  if (!data) return <Loading label="Memuat dashboard..." />

  const hour = new Date().getHours()
  const greeting = hour < 11 ? 'Selamat pagi' : hour < 15 ? 'Selamat siang' : hour < 19 ? 'Selamat sore' : 'Selamat malam'

  return (
    <div className="float-in space-y-6">
      {/* Sapaan */}
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-white/50">{greeting},</p>
          <h1 className="text-xl font-bold text-white">{data.user.name.split(' ')[0]}</h1>
        </div>
        {data.bonusReady && (
          <button
            onClick={claimBonus}
            disabled={claiming}
            className="btn-gold flex items-center gap-2 rounded-full px-4 py-2 text-xs font-bold"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="8" width="18" height="4" rx="1" /><path d="M5 12v8h14v-8M12 8c-2 0-4-1-4-2.5S10 2 12 5c2-3 6-1.5 4 .5C14.5 7 13 8 12 8z" /></svg>
            {claiming ? 'Mengklaim...' : 'Lucky Bonus'}
          </button>
        )}
      </div>

      {/* Saldo utama */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
        <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-[#101a3c] via-[#141530] to-[#1a1030] p-5">
          <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-blue-500/20 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-12 -left-6 h-36 w-36 rounded-full bg-violet-500/20 blur-3xl" />

          <div className="flex items-start justify-between">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-widest text-white/40">Poin Tersedia</p>
              <p className="mt-1 text-4xl font-black tracking-tight text-white">
                {fmtNum(data.points.available)}
                <span className="ml-2 align-middle text-sm font-semibold text-white/40">poin</span>
              </p>
              <p className="mt-1 text-xs text-amber-200/80">
                Estimasi nilai: <span className="font-bold gold-text">{rupiah(data.points.estimate)}</span>
              </p>
            </div>
            <button
              onClick={() => go('rewards', { tab: 'convert' })}
              className="btn-grad rounded-xl px-4 py-2 text-xs font-bold"
            >
              Tukar Poin
            </button>
          </div>

          <div className="mt-5 flex items-center gap-2 text-xs">
            <span className="rounded-full bg-white/8 px-3 py-1.5 text-white/60">
              Belum layak tukar: <b className="text-white">{fmtNum(data.points.pending)}</b>
            </span>
            <span className="text-white/25">1.000 poin = Rp1.000</span>
          </div>

          <div className="mt-5 grid grid-cols-3 gap-3 border-t border-white/10 pt-4">
            <div>
              <p className="text-[10px] uppercase tracking-wider text-white/35">Saldo Hadiah</p>
              <p className="mt-0.5 text-sm font-bold text-emerald-300">{rupiah(data.wallet.available)}</p>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-white/35">Diproses</p>
              <p className="mt-0.5 text-sm font-bold text-violet-300">{rupiah(data.wallet.processing)}</p>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-white/35">Sudah Dibayar</p>
              <p className="mt-0.5 text-sm font-bold text-amber-300">{rupiah(data.wallet.totalPaid)}</p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Menu utama */}
      <section>
        <SectionTitle>Menu Utama</SectionTitle>
        <div className="grid grid-cols-3 gap-3">
          {[
            { key: 'quiz', label: 'Play Quiz', grad: 'from-blue-500/25 to-blue-600/10', icon: 'quiz' },
            { key: 'watch', label: 'Watch & Earn', grad: 'from-violet-500/25 to-violet-600/10', icon: 'watch' },
            { key: 'missions', label: 'Daily Challenge', grad: 'from-amber-500/25 to-amber-600/10', icon: 'target' },
            { key: 'rewards', label: 'Reward Center', grad: 'from-emerald-500/25 to-emerald-600/10', icon: 'gift' },
            { key: 'leaderboard', label: 'Leaderboard', grad: 'from-rose-500/25 to-rose-600/10', icon: 'trophy' },
            { key: 'history', label: 'Riwayat', grad: 'from-cyan-500/25 to-cyan-600/10', icon: 'clock' },
          ].map((m) => (
            <button
              key={m.key}
              onClick={() => go(m.key as never)}
              className="glass group flex flex-col items-center gap-2 rounded-2xl p-4 transition hover:border-white/20 hover:bg-white/8 active:scale-95"
            >
              <span className={`flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br ${m.grad} text-white`}>
                {m.icon === 'quiz' && <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01" /></svg>}
                {m.icon === 'watch' && <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="5" width="20" height="14" rx="3" /><path d="M10 9.5l5 2.5-5 2.5z" /></svg>}
                {m.icon === 'target' && <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><circle cx="12" cy="12" r="6" /><circle cx="12" cy="12" r="2" /></svg>}
                {m.icon === 'gift' && <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 3h12M6 8h12M6 13l6 8 6-8H6z" /></svg>}
                {m.icon === 'trophy' && <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0V4z" /><path d="M7 6H4a3 3 0 0 0 3 6M17 6h3a3 3 0 0 1-3 6" /></svg>}
                {m.icon === 'clock' && <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 3" /></svg>}
              </span>
              <span className="text-[11px] font-semibold text-white/80">{m.label}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Misi harian ringkas */}
      <section>
        <SectionTitle
          action={
            <button onClick={() => go('missions')} className="text-xs font-medium text-blue-300 hover:text-blue-200">
              Lihat semua
            </button>
          }
        >
          Misi Harian
        </SectionTitle>
        <GlassCard className="space-y-3 p-4">
          {data.missions.length === 0 && (
            <p className="py-2 text-center text-xs text-white/40">Belum ada progres misi hari ini. Mulai bermain kuis!</p>
          )}
          {data.missions.slice(0, 3).map((m) => {
            const target = MISSION_TARGETS[m.code] ?? 1
            return (
              <div key={m.code} className="flex items-center gap-3">
                <div className="flex-1">
                  <div className="mb-1 flex items-center justify-between text-xs">
                    <span className="font-medium text-white/80">{MISSION_TITLES[m.code] ?? m.code}</span>
                    <span className={m.claimed ? 'font-semibold text-emerald-300' : 'text-white/40'}>
                      {m.claimed ? 'Diklaim' : `${Math.min(m.progress, target)}/${target}`}
                    </span>
                  </div>
                  <ProgressBar value={m.progress} max={target} gold={m.claimed} />
                </div>
              </div>
            )
          })}
        </GlassCard>
      </section>

      {/* Promo sponsor */}
      {data.promos.length > 0 && (
        <section>
          <SectionTitle>Promo Sponsor</SectionTitle>
          <div className="qe-scroll flex max-h-44 flex-col gap-3 overflow-y-auto pr-1">
            {data.promos.map((p) => (
              <GlassCard key={p.id} className="flex items-center gap-3 border-amber-400/20 bg-gradient-to-r from-amber-500/10 to-transparent p-4">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-400/15 text-amber-300">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 11l18-7-7 18-2.5-8.5L3 11z" /></svg>
                </span>
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-white">{p.title}</p>
                  <p className="text-xs text-white/40">oleh {p.sponsor}</p>
                </div>
              </GlassCard>
            ))}
          </div>
        </section>
      )}

      {/* Pengumuman */}
      {data.announcements.length > 0 && (
        <section>
          <SectionTitle>Pengumuman</SectionTitle>
          <div className="space-y-3">
            {data.announcements.slice(0, 2).map((a) => (
              <GlassCard key={a.id} className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <p className="text-sm font-semibold text-white">{a.title}</p>
                  <span className="shrink-0 text-[10px] text-white/30">{fmtDateTime(a.createdAt)}</span>
                </div>
                <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-white/50">{a.body}</p>
              </GlassCard>
            ))}
          </div>
        </section>
      )}

      {/* Aktivitas terakhir */}
      <section>
        <SectionTitle
          action={
            <button onClick={() => go('history', { tab: 'points' })} className="text-xs font-medium text-blue-300 hover:text-blue-200">
              Riwayat poin
            </button>
          }
        >
          Aktivitas Terakhir
        </SectionTitle>
        <GlassCard className="divide-y divide-white/5 p-1">
          {data.activities.length === 0 && (
            <p className="py-6 text-center text-xs text-white/40">Belum ada aktivitas. Mainkan kuis pertamamu!</p>
          )}
          {data.activities.map((a) => (
            <div key={a.id} className="flex items-center gap-3 px-3 py-2.5">
              {activityIcon(a.type)}
              <div className="min-w-0 flex-1">
                <p className="text-xs font-medium text-white/85">{ACTIVITY_LABEL[a.type] ?? a.type}</p>
                <p className="text-[10px] text-white/30">{fmtDateTime(a.createdAt)}</p>
              </div>
              <span className={`text-sm font-bold ${a.amount >= 0 ? 'text-emerald-300' : 'text-rose-300'}`}>
                {a.amount >= 0 ? '+' : ''}{fmtNum(a.amount)}
              </span>
            </div>
          ))}
        </GlassCard>
      </section>
    </div>
  )
}
