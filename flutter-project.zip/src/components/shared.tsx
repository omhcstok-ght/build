'use client'

import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { cn } from '@/lib/utils'

/** Komponen bersama untuk seluruh view QUIZ & EARN. */

export const AVATAR_PRESETS: Record<string, string> = {
  aurora: 'from-blue-400 to-cyan-300',
  nova: 'from-violet-500 to-fuchsia-400',
  ember: 'from-orange-400 to-rose-400',
  mint: 'from-emerald-400 to-teal-300',
  ocean: 'from-sky-500 to-indigo-400',
  gold: 'from-amber-300 to-yellow-500',
  rose: 'from-pink-400 to-rose-500',
  slate: 'from-slate-400 to-slate-600',
}

export function initials(name: string): string {
  return (name || '?')
    .split(' ')
    .map((p) => p[0])
    .filter(Boolean)
    .slice(0, 2)
    .join('')
    .toUpperCase()
}

export function Avatar({
  name,
  avatar,
  size = 40,
  className,
}: {
  name: string
  avatar?: string | null
  size?: number
  className?: string
}) {
  const grad = AVATAR_PRESETS[avatar ?? ''] ?? 'from-blue-500 to-violet-500'
  return (
    <div
      className={cn(
        'flex items-center justify-center rounded-full bg-gradient-to-br font-bold text-white select-none shrink-0',
        grad,
        className
      )}
      style={{ width: size, height: size, fontSize: size * 0.36 }}
      aria-label={`Avatar ${name}`}
    >
      {initials(name)}
    </div>
  )
}

export function GlassCard({
  children,
  className,
  strong,
}: {
  children: React.ReactNode
  className?: string
  strong?: boolean
}) {
  return (
    <div className={cn(strong ? 'glass-strong' : 'glass', 'rounded-2xl', className)}>
      {children}
    </div>
  )
}

export function PageHeader({
  title,
  subtitle,
  onBack,
  right,
}: {
  title: string
  subtitle?: string
  onBack?: () => void
  right?: React.ReactNode
}) {
  return (
    <div className="mb-5 flex items-center gap-3">
      {onBack && (
        <button
          onClick={onBack}
          aria-label="Kembali"
          className="glass flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-white/80 transition hover:text-white active:scale-95"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
            <path d="M15 18l-6-6 6-6" />
          </svg>
        </button>
      )}
      <div className="min-w-0 flex-1">
        <h1 className="truncate text-xl font-bold text-white">{title}</h1>
        {subtitle && <p className="mt-0.5 text-xs text-white/50">{subtitle}</p>}
      </div>
      {right}
    </div>
  )
}

export function SectionTitle({
  icon,
  children,
  action,
}: {
  icon?: React.ReactNode
  children: React.ReactNode
  action?: React.ReactNode
}) {
  return (
    <div className="mb-3 flex items-center justify-between">
      <h2 className="flex items-center gap-2 text-sm font-semibold tracking-wide text-white/80">
        {icon}
        {children}
      </h2>
      {action}
    </div>
  )
}

export function Loading({ label = 'Memuat...' }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-16">
      <div className="h-10 w-10 animate-spin rounded-full border-2 border-white/10 border-t-blue-400" />
      <p className="text-sm text-white/40">{label}</p>
    </div>
  )
}

export function SkeletonBlock({ className }: { className?: string }) {
  return <Skeleton className={cn('shimmer rounded-2xl bg-white/5', className)} />
}

export function EmptyState({
  icon,
  title,
  description,
}: {
  icon?: React.ReactNode
  title: string
  description?: string
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 py-12 text-center">
      <div className="glass flex h-14 w-14 items-center justify-center rounded-2xl text-white/30">
        {icon ?? (
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
            <circle cx="12" cy="12" r="9" />
            <path d="M9 10h.01M15 10h.01M9 15c.9.9 1.8 1 3 1s2.1-.1 3-1" strokeLinecap="round" />
          </svg>
        )}
      </div>
      <p className="text-sm font-medium text-white/70">{title}</p>
      {description && <p className="max-w-xs text-xs text-white/40">{description}</p>}
    </div>
  )
}

const STATUS_STYLES: Record<string, string> = {
  PENDING: 'bg-amber-400/15 text-amber-300 border-amber-400/25',
  REVIEWING: 'bg-sky-400/15 text-sky-300 border-sky-400/25',
  APPROVED: 'bg-teal-400/15 text-teal-300 border-teal-400/25',
  PROCESSING: 'bg-violet-400/15 text-violet-300 border-violet-400/25',
  PAID: 'bg-emerald-400/15 text-emerald-300 border-emerald-400/25',
  REJECTED: 'bg-rose-400/15 text-rose-300 border-rose-400/25',
  FAILED: 'bg-rose-500/15 text-rose-300 border-rose-500/25',
  ACTIVE: 'bg-blue-400/15 text-blue-300 border-blue-400/25',
  COMPLETED: 'bg-emerald-400/15 text-emerald-300 border-emerald-400/25',
  ABANDONED: 'bg-white/10 text-white/50 border-white/15',
  DRAFT: 'bg-white/10 text-white/50 border-white/15',
  FUNDED: 'bg-teal-400/15 text-teal-300 border-teal-400/25',
  ENDED: 'bg-white/10 text-white/50 border-white/15',
}

export function StatusBadge({ status, className }: { status: string; className?: string }) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-semibold tracking-wide',
        STATUS_STYLES[status] ?? 'bg-white/10 text-white/60 border-white/15',
        className
      )}
    >
      {status}
    </span>
  )
}

export function StatTile({
  label,
  value,
  sub,
  icon,
  gold,
  className,
}: {
  label: string
  value: string
  sub?: string
  icon?: React.ReactNode
  gold?: boolean
  className?: string
}) {
  return (
    <Card className={cn('glass rounded-2xl border-white/10 p-4', className)}>
      <div className="flex items-start justify-between gap-2">
        <p className="text-[11px] font-medium uppercase tracking-wider text-white/45">{label}</p>
        {icon && <span className={cn(gold ? 'text-amber-300' : 'text-blue-300')}>{icon}</span>}
      </div>
      <p className={cn('mt-1.5 text-lg font-bold', gold ? 'gold-text' : 'text-white')}>{value}</p>
      {sub && <p className="mt-0.5 text-[11px] text-white/40">{sub}</p>}
    </Card>
  )
}

export function ProgressBar({
  value,
  max,
  className,
  gold,
}: {
  value: number
  max: number
  className?: string
  gold?: boolean
}) {
  const pct = Math.min(100, max > 0 ? (value / max) * 100 : 0)
  return (
    <div className={cn('h-2 w-full overflow-hidden rounded-full bg-white/8', className)}>
      <div
        className={cn(
          'h-full rounded-full transition-all duration-500',
          gold ? 'bg-gradient-to-r from-amber-300 to-orange-400' : 'bg-gradient-to-r from-blue-500 to-violet-500'
        )}
        style={{ width: `${pct}%` }}
      />
    </div>
  )
}
