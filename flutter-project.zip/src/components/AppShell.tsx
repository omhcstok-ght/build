'use client'

import { useApp, type ViewKey } from '@/lib/store'
import { Avatar } from '@/components/shared'
import { useEffect, useState } from 'react'
import { api } from '@/lib/api'

const NAV: { key: ViewKey; label: string; icon: React.ReactNode }[] = [
  {
    key: 'dashboard',
    label: 'Beranda',
    icon: (
      <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M3 10.5L12 3l9 7.5" />
        <path d="M5 9.5V21h14V9.5" />
      </svg>
    ),
  },
  {
    key: 'quiz',
    label: 'Kuis',
    icon: (
      <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10" />
        <path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01" />
      </svg>
    ),
  },
  {
    key: 'watch',
    label: 'Watch',
    icon: (
      <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="5" width="20" height="14" rx="3" />
        <path d="M10 9.5l5 2.5-5 2.5z" />
      </svg>
    ),
  },
  {
    key: 'rewards',
    label: 'Hadiah',
    icon: (
      <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M6 3h12M6 8h12M6 13l6 8 6-8H6z" />
      </svg>
    ),
  },
  {
    key: 'profile',
    label: 'Profil',
    icon: (
      <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="8" r="4" />
        <path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6" />
      </svg>
    ),
  },
]

export function AppShell({ children }: { children: React.ReactNode }) {
  const { view, go, user } = useApp()
  const [unread, setUnread] = useState(0)

  useEffect(() => {
    let alive = true
    api<{ unreadCount: number }>('/api/notifications')
      .then((d) => {
        if (alive) setUnread(d.unreadCount)
      })
      .catch(() => {})
    return () => {
      alive = false
    }
  }, [view])

  const hour = new Date().getHours()
  const greeting = hour < 11 ? 'Selamat pagi' : hour < 15 ? 'Selamat siang' : hour < 19 ? 'Selamat sore' : 'Selamat malam'

  return (
    <div className="qe-bg flex min-h-svh flex-col">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-white/5 bg-[#05070f]/80 backdrop-blur-xl">
        <div className="mx-auto flex h-14 w-full max-w-3xl items-center gap-3 px-4">
          <button onClick={() => go('dashboard')} className="flex items-center gap-2" aria-label="Beranda QUIZ & EARN">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-violet-600">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path d="M20 12a8 8 0 1 1-8-8" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" />
                <path d="M9.5 12l2 2 3.5-4.5" stroke="#f6c453" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <div className="text-left leading-none">
              <p className="text-sm font-black tracking-tight">
                <span className="brand-text">QUIZ</span>
                <span className="text-white"> & </span>
                <span className="gold-text">EARN</span>
              </p>
              <p className="mt-0.5 hidden text-[8px] font-semibold tracking-[0.22em] text-white/30 sm:block">
                PLAY SMART, EARN REWARDS
              </p>
            </div>
          </button>

          <div className="ml-auto flex items-center gap-2.5">
            <p className="hidden text-right text-xs text-white/50 sm:block">
              {greeting}, <span className="font-semibold text-white">{user?.name?.split(' ')[0]}</span>
            </p>
            <button
              onClick={() => go('notifications')}
              className="glass relative flex h-9 w-9 items-center justify-center rounded-full text-white/70 transition hover:text-white active:scale-95"
              aria-label={`Notifikasi${unread > 0 ? `, ${unread} belum dibaca` : ''}`}
            >
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
                <path d="M13.7 21a2 2 0 0 1-3.4 0" />
              </svg>
              {unread > 0 && (
                <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 px-1 text-[9px] font-bold text-white">
                  {unread > 9 ? '9+' : unread}
                </span>
              )}
            </button>
            <button onClick={() => go('profile')} aria-label="Profil" className="transition active:scale-95">
              <Avatar name={user?.name ?? '?'} avatar={user?.avatar} size={36} />
            </button>
          </div>
        </div>
      </header>

      {/* Konten */}
      <main className="mx-auto w-full max-w-3xl flex-1 px-4 pb-28 pt-5 md:pb-32">{children}</main>

      {/* Footer (desktop) - sticky bottom saat konten pendek, terdorong saat panjang */}
      <footer className="mt-auto hidden border-t border-white/5 py-5 text-center md:block">
        <p className="text-[11px] text-white/30">
          QUIZ &amp; EARN &copy; {new Date().getFullYear()} &middot; PLAY. ANSWER. EARN. REPEAT. &middot;{' '}
          <button onClick={() => go('info', { tab: 'terms' })} className="hover:text-white/50 hover:underline">Syarat &amp; Ketentuan</button>
          {' '}&middot;{' '}
          <button onClick={() => go('info', { tab: 'privacy' })} className="hover:text-white/50 hover:underline">Kebijakan Privasi</button>
          {' '}&middot;{' '}
          <button onClick={() => go('admin')} className="hover:text-white/50 hover:underline">Portal Admin</button>
        </p>
      </footer>

      {/* Navigasi bawah - mobile: bar penuh; desktop: pil mengambang */}
      <nav
        aria-label="Navigasi utama"
        className="fixed inset-x-0 bottom-0 z-40 border-t border-white/8 bg-[#070b18]/90 backdrop-blur-xl md:inset-x-0 md:bottom-4 md:border-0 md:bg-transparent md:backdrop-blur-none"
      >
        <div className="glass-strong mx-auto mb-[env(safe-area-inset-bottom)] flex w-full max-w-md items-center justify-around px-2 py-1.5 md:mb-0 md:w-fit md:rounded-full md:px-3">
          {NAV.map((n) => {
            const active = view === n.key || (n.key === 'dashboard' && view === 'quiz-result') || (n.key === 'quiz' && view === 'quiz-play') || (n.key === 'profile' && ['history', 'info'].includes(view))
            return (
              <button
                key={n.key}
                onClick={() => go(n.key)}
                className={`relative flex min-w-[56px] flex-col items-center gap-0.5 rounded-xl px-3 py-2 text-[10px] font-semibold transition-all ${
                  active ? 'text-white' : 'text-white/35 hover:text-white/60'
                }`}
              >
                {active && (
                  <span className="absolute inset-x-3 top-0.5 h-0.5 rounded-full bg-gradient-to-r from-blue-400 to-violet-400" />
                )}
                {n.icon}
                {n.label}
              </button>
            )
          })}
        </div>
      </nav>
    </div>
  )
}
