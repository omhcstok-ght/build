module.exports = {
  tokens: "8433004914:AAHGGoa8SpCqK7C-meljLCBOc4pfT1r0f-s",  // Ubah Jadi Token Bot Mu !!!
  owner: "8066922815", // Ubah Jadi Id Mu !!!
  port: "2137", // Ubah Jadi Port Panel Mu !!!
  ipvps: "206.189.150.230" // Ubah Jadi Ip Vps Mu !!!
};