// #Whatsapp Bot Nika V27

global.owner = [
  "6287770920524"
]
global.usePairingCode = true


let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})
