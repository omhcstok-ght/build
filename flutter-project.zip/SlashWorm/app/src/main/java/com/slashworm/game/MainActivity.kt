package com.slashworm.game

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.*
import android.view.*
import android.widget.*
import kotlin.math.*
import kotlin.random.Random

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("slashworm", Context.MODE_PRIVATE) }
    private lateinit var root: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 12, 25)
        window.navigationBarColor = Color.rgb(8, 12, 25)
        showAuth()
    }

    private fun showAuth() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(30, 36, 30, 36)
            setBackgroundColor(Color.rgb(8, 12, 25))
        }
        val title = TextView(this).apply {
            text = "SLASHWORM"
            textSize = 34f; setTextColor(Color.rgb(0, 235, 190))
            gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        }
        val sub = TextView(this).apply {
            text = "GROW BIG. MOVE FAST. RULE THE ARENA."
            textSize = 11f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        }
        val user = EditText(this).apply {
            hint = "Username"; setSingleLine(); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(0, 210, 180)))
        }
        val pass = EditText(this).apply {
            hint = "Password"; inputType = 129; setSingleLine(); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(0, 210, 180)))
        }
        val login = Button(this).apply { text = "LOGIN"; setOnClickListener {
            val u = user.text.toString().trim()
            val p = pass.text.toString()
            if (u.isBlank() || p.length < 4) toast("Isi username dan password (min. 4 karakter)")
            else {
                // Demo lokal: akun disimpan di perangkat, bukan autentikasi server.
                prefs.edit().putString("user", u).apply()
                showMenu()
            }
        } }
        val register = Button(this).apply { text = "REGISTER"; setOnClickListener {
            val u = user.text.toString().trim()
            val p = pass.text.toString()
            if (u.isBlank() || p.length < 4) toast("Username wajib diisi, password minimal 4 karakter")
            else {
                prefs.edit().putString("user", u).apply()
                toast("Akun lokal dibuat!")
                showMenu()
            }
        } }
        panel.addView(title); panel.addView(sub)
        panel.addView(space(24)); panel.addView(user, lp()); panel.addView(pass, lp())
        panel.addView(login, lp()); panel.addView(register, lp())
        setContentView(panel)
    }

    private fun showMenu() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(28, 30, 28, 30); setBackgroundColor(Color.rgb(8, 12, 25))
        }
        val name = prefs.getString("user", "Player") ?: "Player"
        val title = TextView(this).apply {
            text = "SLASHWORM"; textSize = 36f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(0, 235, 190)); typeface = Typeface.DEFAULT_BOLD
        }
        val welcome = TextView(this).apply {
            text = "WELCOME, $name"; textSize = 15f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }
        fun menuButton(label: String, action: () -> Unit) = Button(this).apply {
            text = label; setOnClickListener { action() }
        }
        panel.addView(title); panel.addView(welcome); panel.addView(space(24))
        panel.addView(menuButton("PLAY", { showGame() }), lp())
        panel.addView(menuButton("SKINS  •  SOON", { toast("Skin tambahan akan hadir!") }), lp())
        panel.addView(menuButton("LEADERBOARD", { toast("Leaderboard lokal segera hadir!") }), lp())
        panel.addView(menuButton("LOG OUT", { prefs.edit().remove("user").apply(); showAuth() }), lp())
        setContentView(panel)
    }

    private fun showGame() {
        val game = WormGameView(this) { score ->
            prefs.edit().putInt("best", max(score, prefs.getInt("best", 0))).apply()
        }
        setContentView(game)
    }

    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, h) }
    private fun lp() = LinearLayout.LayoutParams(-1, 58).apply { setMargins(0, 8, 0, 8) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

private class WormGameView(context: Context, val onScore: (Int) -> Unit) : View(context) {
    private data class Dot(var x: Float, var y: Float)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val worm = ArrayList<Dot>()
    private val food = ArrayList<Dot>()
    private var angle = -Math.PI.toFloat()/2f
    private var score = 0
    private var boost = false
    private var last = System.nanoTime()
    private var running = true
    private var touchX = 0f
    private var touchY = 0f
    private var steer = false
    private val bg = Color.rgb(8, 12, 25)

    init {
        repeat(24) { i -> worm.add(Dot(500f - i*17f, 800f)) }
        repeat(45) { food.add(Dot(Random.nextFloat()*1000f, Random.nextFloat()*1600f)) }
        isFocusable = true
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        val dt = ((System.nanoTime()-last)/1e9).toFloat().coerceIn(0f, .04f); last = System.nanoTime()
        val scale = min(w/1000f, h/1600f)
        c.drawColor(bg)
        c.save()
        c.scale(scale, scale)
        val worldW = w/scale; val worldH = h/scale
        // Grid
        paint.color = Color.rgb(20, 31, 50); paint.strokeWidth = 1f
        var gx = 0f
        while (gx < worldW) { c.drawLine(gx,0f,gx,worldH,paint); gx += 60f }
        var gy = 0f
        while (gy < worldH) { c.drawLine(0f,gy,worldW,gy,paint); gy += 60f }

        val head = worm.first()
        if (steer) {
            val target = atan2(touchY/scale-head.y, touchX/scale-head.x)
            var diff = ((target-angle+Math.PI*3)%(Math.PI*2)-Math.PI).toFloat()
            angle += diff.coerceIn(-2.7f*dt, 2.7f*dt)
        }
        val speed = if (boost) 390f else 245f
        val nx = (head.x + cos(angle)*speed*dt).coerceIn(18f, worldW-18f)
        val ny = (head.y + sin(angle)*speed*dt).coerceIn(18f, worldH-18f)
        worm.add(0, Dot(nx,ny))
        val spacing = if (boost) 15f else 17f
        while (worm.size > max(24, 24 + score/2)) worm.removeAt(worm.lastIndex)
        for (i in 1 until worm.size) {
            val a = worm[i-1]; val b = worm[i]
            val dx=a.x-b.x; val dy=a.y-b.y; val d=sqrt(dx*dx+dy*dy)
            if (d > spacing) { b.x += dx/d*(d-spacing); b.y += dy/d*(d-spacing) }
        }

        food.forEach { f ->
            paint.color = Color.rgb(255, 190, 70)
            c.drawCircle(f.x,f.y,8f,paint)
            val dx=f.x-nx; val dy=f.y-ny
            if (dx*dx+dy*dy < 28f*28f) {
                f.x=Random.nextFloat()*worldW; f.y=Random.nextFloat()*worldH
                score++; onScore(score)
            }
        }
        worm.asReversed().forEachIndexed { i, d ->
            paint.color = if (i%3==0) Color.rgb(0,220,190) else Color.rgb(0,160,170)
            c.drawCircle(d.x,d.y, if(i==0) 17f else 15f,paint)
        }
        paint.color = Color.WHITE
        c.drawCircle(nx+cos(angle-.45f)*6f,ny+sin(angle-.45f)*6f,3.2f,paint)
        c.drawCircle(nx+cos(angle+.45f)*6f,ny+sin(angle+.45f)*6f,3.2f,paint)
        paint.color = Color.WHITE; paint.textSize=30f; paint.typeface=Typeface.DEFAULT_BOLD
        c.drawText("SCORE  $score",24f,48f,paint)
        c.drawText("BEST  ${max(score, context.getSharedPreferences("slashworm",0).getInt("best",0))}",24f,84f,paint)
        c.restore()
        postInvalidateOnAnimation()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when(e.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                touchX=e.x; touchY=e.y; steer=true
                boost = e.y > height*0.72f && e.x > width*0.55f
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { boost=false; steer=false; return true }
        }
        return true
    }
}
