# SlashWorm

Project Android Studio untuk game cacing bergaya arena arcade.

## Fitur prototipe
- Halaman login dan register (akun demo disimpan lokal di perangkat)
- Menu utama, gameplay cacing, orb makanan, skor dan best score
- Gerakan halus berbasis frame animation
- Sentuh/geser layar untuk mengarahkan cacing; tahan area kanan bawah untuk boost
- Placeholder menu skin dan leaderboard

## Build APK
1. Ekstrak ZIP.
2. Buka folder `SlashWorm` dari Android Studio.
3. Tunggu Gradle Sync selesai (butuh koneksi internet untuk mengunduh Gradle/Android plugin).
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
Ini prototipe offline. Login/register belum memakai server, password tidak diverifikasi/disimpan, dan leaderboard belum online. Untuk akun sungguhan, multiplayer, leaderboard lintas perangkat, dan keamanan produksi perlu backend + autentikasi.
