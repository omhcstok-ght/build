import 'dart:convert';
import 'dart:ui'; // ✅ PENTING: Buat efek blur modal
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'dart:math' as math;
import 'package:Fiona/Qaxer/.dart';

final _baseUrl = Api.api;

class _C {
  static const bg        = Color(0xFFF5F9FF);
  static const surface   = Color(0xFFFFFFFF);
  static const card      = Color(0xFFFFFFFF);
  static const cardAlt   = Color(0xFFEFF6FF);

  static const border    = Color(0xFFD6E4F5);
  static const borderLit = Color(0xFFB6CDE8);
  static const glass     = Color(0x1A3B82F6);

  static const accent1   = Color(0xFF2563EB);
  static const accent2   = Color(0xFF3B82F6);
  static const accent3   = Color(0xFFEC4899);
  static const cyan      = Color(0xFF0EA5E9);
  static const emerald   = Color(0xFF10B981);
  static const amber     = Color(0xFFF59E0B);
  static const rose      = Color(0xFFEF4444);

  static const text      = Color(0xFF0F172A);
  static const textSub   = Color(0xFF475569);
  static const textDim   = Color(0xFF94A3B8);

  static const red       = rose;
  static const redMid    = accent2;
  static const redLight  = accent1;
  static const redFrost  = cyan;
  static const green     = emerald;
  static const greenDim  = Color(0xFF059669);
  static const warning   = amber;

  static const LinearGradient primaryGrad = LinearGradient(
    colors: [Color(0xFF60A5FA), Color(0xFF3B82F6), Color(0xFF2563EB)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient dangerGrad = LinearGradient(
    colors: [Color(0xFFF87171), Color(0xFFEF4444), Color(0xFFDC2626)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient textGrad = LinearGradient(
    colors: [Color(0xFF0F172A), Color(0xFF475569)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient btnGrad = primaryGrad;
}

Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'developer': return const Color(0xFFF59E0B);
    case 'owner':     return const Color(0xFFF59E0B);
    case 'admin':     return const Color(0xFFEF4444);
    case 'moderator': return const Color(0xFF10B981);
    case 'partner':   return const Color(0xFF8B5CF6);
    case 'vip':       return const Color(0xFFEC4899);
    case 'reseller':  return const Color(0xFF0EA5E9);
    default:          return _C.accent1;
  }
}

class BanGroupPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGroup;
  final String role;
  final String expiredDate;

  const BanGroupPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.listBugGroup,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<BanGroupPage> createState() => _BanGroupPageState();
}

class _BanGroupPageState extends State<BanGroupPage>
    with TickerProviderStateMixin {
  final targetCtrl = TextEditingController();
  String selectedBugId = '';

  bool _isSending = false;
  String? _responseMsg;

  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _sendBtnCtrl;
  late AnimationController _resultCtrl;
  late AnimationController _waveCtrl;
  late Animation<double> _entrance;
  late Animation<double> _sendPulse;
  late Animation<double> _sendGlow;
  late Animation<double> _resultFade;
  late Animation<Offset> _resultSlide;

  // ✅ Variabel untuk Loading Modal
  bool _showLoadingModal = false;
  int _loadingStep = 0;
  final List<String> _loadingTexts = [
    "Checking group...",
    "Join in the group...",
    "Proses...",
    "Banned successfully!"
  ];

  @override
  void initState() {
    super.initState();
    if (widget.listBugGroup.isNotEmpty) {
      selectedBugId = "BanGroupwaa";
    }
    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 20))
      ..repeat();
    _entranceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));
    _entrance =
        CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic);
    _sendBtnCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);
    _sendPulse = Tween<double>(begin: 1.0, end: 1.03)
        .animate(CurvedAnimation(parent: _sendBtnCtrl, curve: Curves.easeInOut));
    _sendGlow = Tween<double>(begin: 0.3, end: 0.8)
        .animate(CurvedAnimation(parent: _sendBtnCtrl, curve: Curves.easeInOut));
    _resultCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 450));
    _resultFade =
        CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOut);
    _resultSlide =
        Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
            .animate(CurvedAnimation(
                parent: _resultCtrl, curve: Curves.easeOutCubic));
    _waveCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 3))
      ..repeat();
    _entranceCtrl.forward();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _sendBtnCtrl.dispose();
    _resultCtrl.dispose();
    _waveCtrl.dispose();
    targetCtrl.dispose();
    super.dispose();
  }

  // ✅ LOGIKA LOADING MODAL (Ganti step tiap 1.5 detik)
  Future<void> _runLoadingSequence() async {
    setState(() {
      _showLoadingModal = true;
      _loadingStep = 0;
    });

    await Future.delayed(const Duration(milliseconds: 1500));
    if (mounted) setState(() => _loadingStep = 1);

    await Future.delayed(const Duration(milliseconds: 1500));
    if (mounted) setState(() => _loadingStep = 2);
  }

  Future<void> _sendBug() async {
    final rawInput = targetCtrl.text.trim();
    final key = widget.sessionKey;

    if (!isValidGroupLink(rawInput)) {
      _showAlert('Link Tidak Valid',
          'Masukkan link grup WhatsApp yang valid.\nContoh: https://chat.whatsapp.com/XXX');
      return;
    }

    if (selectedBugId.isEmpty) {
      _showAlert('Error', 'Bug tidak tersedia. Hubungi @xyzyanzzi');
      return;
    }

    // ✅ Mulai animasi loading modal
    _runLoadingSequence();

    setState(() {
      _isSending = true;
      _responseMsg = null;
    });
    _resultCtrl.reset();

    try {
      final encodedTarget = Uri.encodeComponent(rawInput);
      final url = Uri.parse(
        '$_baseUrl/sendBug'
        '?key=$key'
        '&target=$encodedTarget'
        '&bug=$selectedBugId',
      );
      final res = await http.get(url).timeout(const Duration(seconds: 20));
      final data = jsonDecode(res.body);

      if (data['valid'] == false) {
        _setResponse('error', 'Session key tidak valid. Silakan login ulang.');
      } else if (data['cooldown'] == true) {
        final wait = data['wait'] ?? 0;
        _setResponse('warning', 'Cooldown aktif! Tunggu $wait detik lagi.');
      } else if (data['sended'] == true) {
        final role = data['role'] ?? widget.role;
        final senderCount = data['senders_used'] ?? 'N/A';
        _setResponse('success',
            'BAN GROUP BERHASIL!\nSender: $senderCount | Role: $role');
        targetCtrl.clear();
      } else {
        _setResponse('error', 'Gagal mengirim. Server maintenance.');
      }
    } on Exception catch (e) {
      if (e.toString().contains('TimeoutException')) {
        _setResponse('error', 'Request timeout. Periksa koneksi internet.');
      } else {
        _setResponse('error', 'Koneksi error. Periksa jaringan dan coba lagi.');
      }
    } finally {
      if (mounted) {
        setState(() {
          _isSending = false;
          _loadingStep = 3; // ✅ Step terakhir: Banned successfully
        });
      }
    }
  }

  void _setResponse(String type, String msg) {
    if (!mounted) return;
    setState(() => _responseMsg = '$type|$msg');
    _resultCtrl.forward(from: 0);
  }

  bool isValidGroupLink(String s) =>
      s.startsWith('https://') && s.contains('chat.whatsapp.com');

  void _showAlert(String title, String msg) {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black.withOpacity(0.4),
      transitionDuration: const Duration(milliseconds: 300),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: _C.amber.withOpacity(0.4), width: 1.5),
            boxShadow: [
              BoxShadow(
                  color: _C.amber.withOpacity(0.15),
                  blurRadius: 60,
                  spreadRadius: 8),
            ],
          ),
          padding: const EdgeInsets.all(26),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.amber.withOpacity(0.1),
                border: Border.all(color: _C.amber.withOpacity(0.5), width: 1.5),
                boxShadow: [
                  BoxShadow(color: _C.amber.withOpacity(0.2), blurRadius: 24),
                ],
              ),
              child: const Icon(Icons.warning_amber_rounded,
                  color: _C.amber, size: 28),
            ),
            const SizedBox(height: 16),
            Text(title,
                style: const TextStyle(
                    color: _C.text,
                    fontSize: 18,
                    fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            Text(msg,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: _C.textSub, fontSize: 13, height: 1.55)),
            const SizedBox(height: 24),
            _GradBtn(label: 'OK', fullWidth: true, onTap: () => Navigator.pop(ctx)),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          Positioned.fill(child: _AnimatedBg(controller: _bgCtrl)),
          SafeArea(
            child: FadeTransition(
              opacity: _entrance,
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
                child: Column(
                  children: [
                    _buildHeroCard(),
                    const SizedBox(height: 16),
                    _buildWarningBanner(),
                    const SizedBox(height: 16),
                    _buildGroupInput(),
                    const SizedBox(height: 16),
                    _buildSenderCard(),
                    const SizedBox(height: 24),
                    _buildSendButton(),
                    if (_responseMsg != null) ...[
                      const SizedBox(height: 12),
                      _buildResultBanner(),
                    ],
                  ],
                ),
              ),
            ),
          ),
          // ✅ LOADING MODAL OVERLAY
          if (_showLoadingModal)
            _buildLoadingModal(),
        ],
      ),
    );
  }

  // ✅ UI LOADING MODAL
  Widget _buildLoadingModal() {
    return Positioned.fill(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Container(
          color: Colors.black.withOpacity(0.3),
          child: Center(
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 30),
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                color: _C.card,
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: _C.accent1.withOpacity(0.15),
                    blurRadius: 40,
                    spreadRadius: 10,
                  ),
                ],
                border: Border.all(color: _C.border, width: 1.5),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Ikon Animasi
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    child: _loadingStep == 3
                        ? const Icon(Icons.check_circle_rounded,
                            key: ValueKey('check'), color: _C.emerald, size: 60)
                        : SizedBox(
                            key: const ValueKey('loading'),
                            width: 60,
                            height: 60,
                            child: CircularProgressIndicator(
                              strokeWidth: 4,
                              color: _C.accent2,
                              backgroundColor: _C.border,
                            ),
                          ),
                  ),
                  const SizedBox(height: 24),
                  
                  // Teks Step
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    child: Text(
                      _loadingTexts[_loadingStep],
                      key: ValueKey(_loadingStep),
                      style: TextStyle(
                        color: _loadingStep == 3 ? _C.emerald : _C.text,
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _loadingStep == 3 
                        ? "Proses ban group telah selesai." 
                        : "Mohon tunggu sebentar...",
                    style: const TextStyle(color: _C.textSub, fontSize: 12),
                  ),

                  // Tombol Selesai
                  if (_loadingStep == 3) ...[
                    const SizedBox(height: 24),
                    _GradBtn(
                      label: 'SELESAI',
                      fullWidth: true,
                      onTap: () {
                        setState(() => _showLoadingModal = false);
                      },
                    ),
                  ]
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeroCard() {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: _C.border, width: 1.2),
        boxShadow: [
          BoxShadow(
            color: _C.accent2.withOpacity(0.08),
            blurRadius: 40,
            spreadRadius: 4,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: _C.primaryGrad,
                  boxShadow: [
                    BoxShadow(
                      color: _C.accent2.withOpacity(0.3),
                      blurRadius: 24,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: const Icon(Icons.person_rounded,
                    color: Colors.white, size: 26),
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ShaderMask(
                      shaderCallback: (b) => _C.textGrad.createShader(b),
                      child: Text(
                        widget.username,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 21,
                          letterSpacing: -0.3,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 3),
                          decoration: BoxDecoration(
                            color: _roleColor(widget.role).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                                color: _roleColor(widget.role)
                                    .withOpacity(0.3)),
                          ),
                          child: Text(
                            widget.role.toUpperCase(),
                            style: TextStyle(
                              color: _roleColor(widget.role),
                              fontSize: 10,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Flexible(
                          child: Text(
                            'Exp: ${widget.expiredDate}',
                            style: const TextStyle(
                                color: _C.textSub, fontSize: 10.5),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(
                  color: _C.emerald.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                      color: _C.emerald.withOpacity(0.3), width: 1.2),
                  boxShadow: [
                    BoxShadow(
                        color: _C.emerald.withOpacity(0.1), blurRadius: 12),
                  ],
                ),
                child: Row(
                  children: const [
                    Icon(Icons.fiber_manual_record,
                        color: _C.emerald, size: 8),
                    SizedBox(width: 5),
                    Text('LIVE',
                        style: TextStyle(
                          color: _C.emerald,
                          fontSize: 9.5,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1,
                        )),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: _StatCard(
                  icon: Icons.bug_report_rounded,
                  value: 'BanGroupwaa',
                  label: 'Mode Aktif',
                  color: _C.accent3,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _StatCard(
                  icon: Icons.person_rounded,
                  value: 'PRIVATE',
                  label: 'Sender',
                  color: _C.cyan,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _StatCard(
                  icon: Icons.check_circle_rounded,
                  value: 'READY',
                  label: 'Status',
                  color: _C.emerald,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildWarningBanner() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _C.amber.withOpacity(0.06),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _C.amber.withOpacity(0.25), width: 1.2),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.amber.withOpacity(0.15),
              border: Border.all(color: _C.amber.withOpacity(0.4), width: 1.2),
            ),
            child: const Icon(Icons.warning_amber_rounded,
                color: _C.amber, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  'PERINGATAN',
                  style: TextStyle(
                      color: _C.amber,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.5),
                ),
                SizedBox(height: 5),
                Text(
                  'Tidak semua grup berhasil di-ban. Efektivitas tergantung keamanan grup dan bug yang digunakan.',
                  style: TextStyle(
                      color: _C.textSub, fontSize: 11.5, height: 1.45),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGroupInput() {
    return Container(
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _C.border, width: 1.2),
        boxShadow: [
          BoxShadow(
              color: _C.accent1.withOpacity(0.05),
              blurRadius: 20,
              offset: const Offset(0, 6)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
            decoration: BoxDecoration(
              border: Border(
                  bottom: BorderSide(
                      color: _C.border, width: 1)),
            ),
            child: Row(
              children: [
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    gradient: _C.primaryGrad,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                          color: _C.accent2.withOpacity(0.3),
                          blurRadius: 12),
                    ],
                  ),
                  child: const Icon(Icons.link_rounded,
                      color: Colors.white, size: 16),
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: Text(
                    'LINK GRUP WHATSAPP',
                    style: TextStyle(
                        color: _C.text,
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _C.accent3.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: _C.accent3.withOpacity(0.3)),
                  ),
                  child: const Text('BanGroupwaa',
                      style: TextStyle(
                        color: _C.accent3,
                        fontSize: 9,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1,
                      )),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: _BugInput(
              controller: targetCtrl,
              hint: 'https://chat.whatsapp.com/...',
              keyboardType: TextInputType.url,
              icon: Icons.link_rounded,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSenderCard() {
    return Container(
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _C.border, width: 1.2),
        boxShadow: [
          BoxShadow(
              color: _C.accent1.withOpacity(0.05),
              blurRadius: 20,
              offset: const Offset(0, 6)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
            decoration: BoxDecoration(
              border: Border(
                  bottom: BorderSide(
                      color: _C.border, width: 1)),
            ),
            child: Row(
              children: [
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: _C.cyan.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: _C.cyan.withOpacity(0.3), width: 1.2),
                  ),
                  child: const Icon(FontAwesomeIcons.server,
                      color: _C.cyan, size: 14),
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Sender Type',
                          style: TextStyle(
                            color: _C.text,
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                          )),
                      Text('Locked ke Private',
                          style: TextStyle(
                            color: _C.textSub,
                            fontSize: 10.5,
                          )),
                    ],
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _C.amber.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: _C.amber.withOpacity(0.3)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Icon(Icons.lock_rounded, color: _C.amber, size: 10),
                      SizedBox(width: 4),
                      Text('LOCKED',
                          style: TextStyle(
                            color: _C.amber,
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1,
                          )),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Expanded(
                  child: _SenderOption(
                    icon: FontAwesomeIcons.globe,
                    label: 'Global',
                    sublabel: 'Locked • Bug Group',
                    selected: false,
                    locked: true,
                    onTap: () {
                      _showAlert(
                        'Sender Global Dikunci',
                        'Bug Group hanya bisa pakai Sender Private.\n\nSender Global hanya tersedia di Bug Number.',
                      );
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _SenderOption(
                    icon: FontAwesomeIcons.userShield,
                    label: 'Private',
                    sublabel: 'Session sendiri',
                    selected: true,
                    locked: false,
                    onTap: () {},
                  ),
                ),
              ],
            ),
          ),
          Container(
            margin: const EdgeInsets.fromLTRB(14, 0, 14, 14),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _C.cyan.withOpacity(0.05),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _C.cyan.withOpacity(0.2), width: 1),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    color: _C.cyan.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.info_outline_rounded,
                      color: _C.cyan, size: 12),
                ),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text(
                    'Bug Group otomatis pakai Sender Private milik session lu. Sender Global khusus Bug Number.',
                    style: TextStyle(
                        color: _C.textSub, fontSize: 10.5, height: 1.4),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _sendBtnCtrl,
      builder: (_, __) => GestureDetector(
        onTap: _isSending ? null : _sendBug,
        child: Transform.scale(
          scale: _isSending ? 1.0 : _sendPulse.value,
          child: Container(
            height: 60,
            width: double.infinity,
            decoration: BoxDecoration(
              gradient: _C.dangerGrad,
              borderRadius: BorderRadius.circular(18),
              boxShadow: _isSending
                  ? []
                  : [
                      BoxShadow(
                        color: _C.rose.withOpacity(_sendGlow.value * 0.3),
                        blurRadius: 32,
                        offset: const Offset(0, 10),
                      ),
                      BoxShadow(
                        color: _C.accent3.withOpacity(_sendGlow.value * 0.15),
                        blurRadius: 48,
                        offset: const Offset(0, 6),
                      ),
                    ],
            ),
            child: Stack(
              children: [
                if (_isSending)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: AnimatedBuilder(
                      animation: _waveCtrl,
                      builder: (_, __) => CustomPaint(
                        painter: _WavePainter(_waveCtrl.value),
                        size: const Size(double.infinity, 60),
                      ),
                    ),
                  ),
                Center(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 250),
                    child: _isSending
                        ? const Row(
                            key: ValueKey('sending'),
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2.5, color: Colors.white),
                              ),
                              SizedBox(width: 14),
                              Text(
                                'Mengirim Ban...',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 15,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          )
                        : const Row(
                            key: ValueKey('idle'),
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.rocket_launch_rounded,
                                  color: Colors.white, size: 22),
                              SizedBox(width: 12),
                              Text(
                                'SEND BAN GROUP',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w900,
                                  fontSize: 15,
                                  letterSpacing: 1.8,
                                ),
                              ),
                            ],
                          ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildResultBanner() {
    if (_responseMsg == null) return const SizedBox();
    final parts = _responseMsg!.split('|');
    final type = parts[0];
    final msg = parts.length > 1 ? parts[1] : '';

    Color color;
    IconData icon;
    switch (type) {
      case 'success':
        color = _C.emerald;
        icon = Icons.check_circle_rounded;
        break;
      case 'warning':
        color = _C.amber;
        icon = Icons.warning_rounded;
        break;
      default:
        color = _C.rose;
        icon = Icons.error_rounded;
    }

    return FadeTransition(
      opacity: _resultFade,
      child: SlideTransition(
        position: _resultSlide,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: color.withOpacity(0.08),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: color.withOpacity(0.3), width: 1.2),
            boxShadow: [
              BoxShadow(color: color.withOpacity(0.1), blurRadius: 24),
            ],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withOpacity(0.1),
                  border: Border.all(color: color.withOpacity(0.3)),
                ),
                child: Icon(icon, color: color, size: 18),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      type == 'success'
                          ? 'Berhasil'
                          : type == 'warning'
                              ? 'Peringatan'
                              : 'Gagal',
                      style: TextStyle(
                          color: color,
                          fontSize: 13,
                          fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 4),
                    Text(msg,
                        style: const TextStyle(
                            color: _C.textSub, fontSize: 11.5, height: 1.45)),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () {
                  setState(() => _responseMsg = null);
                  _resultCtrl.reset();
                },
                child: const Icon(Icons.close_rounded,
                    color: _C.textDim, size: 16),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  final Color color;

  const _StatCard({
    required this.icon,
    required this.value,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
      decoration: BoxDecoration(
        color: _C.bg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.2), width: 1),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(height: 6),
          Text(
            value,
            style: const TextStyle(
              color: _C.text,
              fontSize: 15,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.3,
            ),
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 2),
          Text(label,
              style: const TextStyle(color: _C.textSub, fontSize: 9.5),
              overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }
}

class _BugInput extends StatefulWidget {
  final TextEditingController controller;
  final String hint;
  final TextInputType keyboardType;
  final IconData icon;
  const _BugInput({
    required this.controller,
    required this.hint,
    required this.keyboardType,
    required this.icon,
  });

  @override
  State<_BugInput> createState() => _BugInputState();
}

class _BugInputState extends State<_BugInput> {
  bool _focused = false;
  final _focus = FocusNode();

  @override
  void initState() {
    super.initState();
    _focus.addListener(() => setState(() => _focused = _focus.hasFocus));
  }

  @override
  void dispose() {
    _focus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      decoration: BoxDecoration(
        color: _C.bg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _focused ? _C.accent2 : _C.border,
          width: _focused ? 1.8 : 1.2,
        ),
        boxShadow: _focused
            ? [BoxShadow(color: _C.accent2.withOpacity(0.15), blurRadius: 20)]
            : [],
      ),
      child: TextField(
        controller: widget.controller,
        focusNode: _focus,
        keyboardType: widget.keyboardType,
        style: const TextStyle(
            color: _C.text, fontSize: 14, fontWeight: FontWeight.w500),
        cursorColor: _C.accent2,
        decoration: InputDecoration(
          hintText: widget.hint,
          hintStyle: const TextStyle(color: _C.textDim, fontSize: 13),
          prefixIcon: Icon(
            widget.icon,
            color: _focused ? _C.accent2 : _C.textSub,
            size: 18,
          ),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
      ),
    );
  }
}

class _SenderOption extends StatefulWidget {
  final IconData icon;
  final String label;
  final String sublabel;
  final bool selected;
  final bool locked;
  final VoidCallback onTap;

  const _SenderOption({
    required this.icon,
    required this.label,
    required this.sublabel,
    required this.selected,
    required this.locked,
    required this.onTap,
  });

  @override
  State<_SenderOption> createState() => _SenderOptionState();
}

class _SenderOptionState extends State<_SenderOption> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final baseColor = widget.locked && !widget.selected
        ? _C.textDim
        : widget.selected
            ? _C.accent2
            : _C.textSub;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
          decoration: BoxDecoration(
            color: widget.selected
                ? _C.accent2.withOpacity(0.08)
                : _C.bg,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: widget.selected
                  ? _C.accent2.withOpacity(0.4)
                  : _C.border,
              width: widget.selected ? 1.6 : 1.2,
            ),
            boxShadow: widget.selected
                ? [
                    BoxShadow(
                        color: _C.accent2.withOpacity(0.15), blurRadius: 20)
                  ]
                : [],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  Icon(widget.icon, color: baseColor, size: 20),
                  if (widget.locked)
                    Positioned(
                      right: -4,
                      top: -4,
                      child: Container(
                        width: 12,
                        height: 12,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _C.amber,
                          border: Border.all(color: _C.card, width: 1.5),
                        ),
                        child: const Icon(Icons.lock_rounded,
                            color: Colors.white, size: 6),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                widget.label,
                style: TextStyle(
                    color: baseColor,
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 3),
              Text(
                widget.sublabel,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: widget.locked && !widget.selected
                      ? _C.textDim.withOpacity(0.7)
                      : _C.textDim,
                  fontSize: 9.5,
                  height: 1.2,
                ),
              ),
              if (widget.selected) ...[
                const SizedBox(height: 6),
                Container(
                  width: 20,
                  height: 2.5,
                  decoration: BoxDecoration(
                    gradient: _C.primaryGrad,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _WavePainter extends CustomPainter {
  final double t;
  _WavePainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.15)
      ..style = PaintingStyle.fill;
    final path = Path();
    path.moveTo(0, size.height);
    for (double x = 0; x <= size.width; x++) {
      final y = size.height * 0.5 +
          math.sin((x / size.width * 4 * math.pi) + (t * math.pi * 2)) *
              size.height *
              0.15;
      path.lineTo(x, y);
    }
    path.lineTo(size.width, size.height);
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(_WavePainter old) => old.t != t;
}

class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) => CustomPaint(painter: _BgPainter(controller.value)),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final bgPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFFF5F9FF), Color(0xFFEAF2FF), Color(0xFFF5F9FF)],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), bgPaint);

    final orb1X = size.width * 0.2 + math.sin(t * math.pi * 2) * 40;
    final orb1Y = size.height * 0.15 + math.cos(t * math.pi * 2) * 40;
    canvas.drawCircle(
      Offset(orb1X, orb1Y),
      size.width * 0.6,
      Paint()
        ..shader = RadialGradient(colors: [
          _C.accent2.withOpacity(0.06 + math.sin(t * math.pi * 2) * 0.02),
          Colors.transparent,
        ]).createShader(Rect.fromCircle(
            center: Offset(orb1X, orb1Y), radius: size.width * 0.6)),
    );

    final orb2X = size.width * 0.8 + math.cos(t * math.pi * 2 + 1) * 30;
    final orb2Y = size.height * 0.7 + math.sin(t * math.pi * 2 + 1) * 30;
    canvas.drawCircle(
      Offset(orb2X, orb2Y),
      size.width * 0.55,
      Paint()
        ..shader = RadialGradient(colors: [
          _C.rose.withOpacity(0.04),
          Colors.transparent,
        ]).createShader(Rect.fromCircle(
            center: Offset(orb2X, orb2Y), radius: size.width * 0.55)),
    );

    final dotPaint = Paint()..color = _C.borderLit.withOpacity(0.15);
    const spacing = 36.0;
    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), 0.7, dotPaint);
      }
    }
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}

class _GradBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final bool fullWidth;

  const _GradBtn({
    required this.label,
    required this.onTap,
    this.fullWidth = false,
  });

  @override
  State<_GradBtn> createState() => _GradBtnState();
}

class _GradBtnState extends State<_GradBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 48,
          width: widget.fullWidth ? double.infinity : null,
          decoration: BoxDecoration(
            gradient: _C.primaryGrad,
            borderRadius: BorderRadius.circular(14),
            boxShadow: _down
                ? []
                : [
                    BoxShadow(
                      color: _C.accent2.withOpacity(0.3),
                      blurRadius: 18,
                      offset: const Offset(0, 6),
                    ),
                  ],
          ),
          child: Center(
            child: Text(
              widget.label,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w800,
                fontSize: 14,
                letterSpacing: 0.5,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
      ),
    );
  }
}