class BenefitModel {
  final String id;
  final String link;
  final String deskripsi;
  final String uploader;
  final String role;
  final DateTime createdAt;

  BenefitModel({
    required this.id,
    required this.link,
    required this.deskripsi,
    required this.uploader,
    required this.role,
    required this.createdAt,
  });

  factory BenefitModel.fromMap(Map<String, dynamic> map, String id) {
    return BenefitModel(
      id: id,
      link: map['link'] ?? '',
      deskripsi: map['deskripsi'] ?? '',
      uploader: map['uploader'] ?? 'Anonim',
      role: map['role'] ?? 'member',
      createdAt: _parseDate(map['createdAt']),
    );
  }

  static DateTime _parseDate(dynamic val) {
    if (val == null) return DateTime.now();
    if (val is int) return DateTime.fromMillisecondsSinceEpoch(val);
    if (val is String) return DateTime.tryParse(val) ?? DateTime.now();
    return DateTime.now();
  }
}