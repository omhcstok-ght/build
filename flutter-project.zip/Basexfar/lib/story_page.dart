import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:http_parser/http_parser.dart' as http_parser;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:Fiona/Qaxer/.dart';
final baseUrl = Api.api;

// ─── Light Theme Colors ───────────────────────────────────────────────────────
const Color _kBg      = Color(0xFFF5F9FF);
const Color _kCard    = Color(0xFFFFFFFF);
const Color _kBorder  = Color(0xFFD6E4F5);
const Color _kCyan    = Color(0xFF2563EB);
const Color _kGreen   = Color(0xFF10B981);
const Color _kWhite   = Color(0xFF0F172A);
const Color _kWhite54 = Color(0xFF475569);
const Color _kPurple  = Color(0xFF8B5CF6);
const Color _kRed     = Color(0xFFEF4444);

// ─── Helper: Format waktu story ───────────────────────────────────────────────
String _formatStoryTime(String raw) {
  if (raw.isEmpty) return '';
  try {
    final dt = DateTime.parse(raw).toLocal();
    final now = DateTime.now();
    final diff = now.difference(dt);

    if (diff.isNegative || diff.inSeconds < 60) return 'Baru saja';
    if (diff.inMinutes < 60) return '${diff.inMinutes} menit lalu';
    if (diff.inHours < 24) return '${diff.inHours} jam lalu';
    if (diff.inDays < 7) return '${diff.inDays} hari lalu';
    return '${dt.day}/${dt.month}/${dt.year}';
  } catch (_) {
    return raw;
  }
}

// ─── Story Model ──────────────────────────────────────────────────────────────
class StoryItem {
  final String storyId;
  final String username;
  final String mediaUrl;
  final String mediaType;
  final String caption;
  final int likeCount;
  final int viewCount;
  final bool isLiked;
  final bool isOwner;
  final String createdAt;

  StoryItem({
    required this.storyId,
    required this.username,
    required this.mediaUrl,
    required this.mediaType,
    required this.caption,
    required this.likeCount,
    required this.viewCount,
    required this.isLiked,
    required this.isOwner,
    required this.createdAt,
  });

  static String _pick(Map<String, dynamic> j, List<String> keys, [String fallback = '']) {
    for (final k in keys) {
      if (j[k] != null && j[k].toString().isNotEmpty) return j[k].toString();
    }
    return fallback;
  }

  static int _pickInt(Map<String, dynamic> j, List<String> keys) {
    for (final k in keys) {
      final v = j[k];
      if (v == null) continue;
      if (v is int) return v;
      if (v is double) return v.toInt();
      final parsed = int.tryParse(v.toString());
      if (parsed != null) return parsed;
    }
    return 0;
  }

  static bool _pickBool(Map<String, dynamic> j, List<String> keys) {
    for (final k in keys) {
      final v = j[k];
      if (v == null) continue;
      if (v is bool) return v;
      final s = v.toString().toLowerCase();
      return s == 'true' || s == '1';
    }
    return false;
  }

  factory StoryItem.fromJson(Map<String, dynamic> j) {
    String rawUrl = _pick(j, ['media_url', 'mediaUrl', 'url', 'file_url', 'image_url', 'video_url', 'media', 'file']);
    if (rawUrl.startsWith('/')) rawUrl = '$baseUrl$rawUrl';
    return StoryItem(
      storyId:   _pick(j, ['story_id', 'id', 'storyId', '_id']),
      username:  _pick(j, ['username', 'user', 'name', 'user_name']),
      mediaUrl:  rawUrl,
      mediaType: _pick(j, ['media_type', 'mediaType', 'type'], 'image'),
      caption:   _pick(j, ['caption', 'text', 'desc', 'description']),
      likeCount: _pickInt(j, ['like_count', 'likeCount', 'likes', 'total_likes']),
      viewCount: _pickInt(j, ['view_count', 'viewCount', 'views', 'total_views']),
      isLiked:   _pickBool(j, ['is_liked', 'isLiked', 'liked']),
      isOwner:   _pickBool(j, ['is_owner', 'isOwner', 'owner']),
      createdAt: _pick(j, ['created_at', 'createdAt', 'timestamp', 'date', 'time']),
    );
  }
}

class UserStoryGroup {
  final String username;
  final List<StoryItem> stories;
  final bool hasUnviewed;

  UserStoryGroup({
    required this.username,
    required this.stories,
    required this.hasUnviewed,
  });
}

// ─── Comment Model ────────────────────────────────────────────────────────────
class StoryComment {
  final String commentId;
  final String username;
  final String message;
  final String createdAt;

  StoryComment({
    required this.commentId,
    required this.username,
    required this.message,
    required this.createdAt,
  });

  factory StoryComment.fromJson(Map<String, dynamic> j) {
    String pick(List<String> keys, [String fb = '']) {
      for (final k in keys) {
        if (j[k] != null && j[k].toString().isNotEmpty) return j[k].toString();
      }
      return fb;
    }
    return StoryComment(
      commentId: pick(['comment_id', 'id', '_id', 'commentId']),
      username:  pick(['username', 'user', 'name'], 'Anonim'),
      message:   pick(['message', 'comment', 'text', 'content'], ''),
      createdAt: pick(['created_at', 'createdAt', 'time', 'date', 'timestamp']),
    );
  }
}

// ─── Story Page ───────────────────────────────────────────────────────────────
class StoryPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const StoryPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<StoryPage> createState() => _StoryPageState();
}

class _StoryPageState extends State<StoryPage> {
  List<StoryItem> _myStories = [];
  List<UserStoryGroup> _otherStories = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetchStories();
  }

  List<Map<String, dynamic>> _extractStoryMaps(dynamic data) {
    final List<Map<String, dynamic>> flat = [];
    List rawList = [];
    if (data['data'] is List) {
      rawList = data['data'];
    } else if (data['stories'] is List) {
      rawList = data['stories'];
    }
    for (final entry in rawList) {
      if (entry is! Map) continue;
      final e = Map<String, dynamic>.from(entry);
      if (e['stories'] is List) {
        for (final s in (e['stories'] as List)) {
          if (s is Map) flat.add(Map<String, dynamic>.from(s));
        }
      } else {
        flat.add(e);
      }
    }
    return flat;
  }

  Future<void> _fetchStories() async {
    setState(() { _loading = true; _error = null; });
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/getStories?key=${widget.sessionKey}&_t=${DateTime.now().millisecondsSinceEpoch}'),
      ).timeout(const Duration(seconds: 12));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true || data['status'] == 'ok') {
          final List<Map<String, dynamic>> flat = _extractStoryMaps(data);
          final items = flat.map((e) => StoryItem.fromJson(e)).toList();

          final mine = items.where((s) => s.username == widget.username).toList();

          final Map<String, List<StoryItem>> grouped = {};
          for (final s in items.where((s) => s.username != widget.username)) {
            grouped.putIfAbsent(s.username, () => []).add(s);
          }

          final others = grouped.entries.map((e) => UserStoryGroup(
            username: e.key,
            stories: e.value,
            hasUnviewed: e.value.any((s) => s.viewCount == 0),
          )).toList();

          setState(() {
            _myStories = mine;
            _otherStories = others;
            _loading = false;
          });
        } else {
          setState(() { _error = data['message'] ?? 'Gagal memuat story'; _loading = false; });
        }
      } else {
        setState(() { _error = 'Server error ${res.statusCode}'; _loading = false; });
      }
    } catch (e) {
      setState(() { _error = 'Koneksi gagal'; _loading = false; });
    }
  }

  Future<void> _uploadStory({required File file, required String type, String caption = ''}) async {
    if (mounted) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => Dialog(
          backgroundColor: Colors.transparent,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
              child: Container(
                padding: const EdgeInsets.all(32),
                decoration: BoxDecoration(
                  color: _kCard,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: _kBorder),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(
                      width: 60, height: 60,
                      child: CircularProgressIndicator(
                        color: _kCyan,
                        strokeWidth: 3,
                        valueColor: AlwaysStoppedAnimation(_kCyan),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text('Mengunggah Story...',
                        style: TextStyle(color: _kWhite, fontFamily: 'ShareTechMono', fontSize: 14, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    const Text('Mohon tunggu',
                        style: TextStyle(color: _kWhite54, fontFamily: 'ShareTechMono', fontSize: 12)),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    }

    try {
      final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/uploadStory'));
      req.fields['key']        = widget.sessionKey;
      req.fields['caption']    = caption;
      req.fields['media_type'] = type;
      req.fields['type']       = type;
      req.fields['_t']         = DateTime.now().millisecondsSinceEpoch.toString();

      String mimeType;
      final ext = file.path.split('.').last.toLowerCase();
      if (type == 'video') {
        mimeType = ext == 'mov' ? 'video/quicktime' : 'video/mp4';
      } else {
        mimeType = ext == 'png' ? 'image/png' : ext == 'webp' ? 'image/webp' : 'image/jpeg';
      }

      req.files.add(await http.MultipartFile.fromPath(
        'file',
        file.path,
        contentType: http_parser.MediaType.parse(mimeType),
      ));

      final streamed = await req.send().timeout(const Duration(seconds: 180));
      final res = await http.Response.fromStream(streamed);

      if (mounted) Navigator.pop(context);

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true || data['status'] == 'ok' || data['success'] == true) {
          _showSnack('✅ Story berhasil diunggah!', _kGreen);
          await Future.delayed(const Duration(milliseconds: 800));
          _fetchStories();
        } else {
          _showSnack('❌ ${data['message'] ?? 'Gagal upload'}', _kRed);
        }
      } else {
        _showSnack('❌ Server error ${res.statusCode}', _kRed);
      }
    } catch (e) {
      if (mounted) Navigator.pop(context);
      _showSnack('❌ Upload gagal: cek koneksi', _kRed);
    }
  }

  Future<void> _deleteStory(String storyId) async {
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/deleteStory'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey, 'story_id': storyId}),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true || data['status'] == 'ok') {
        _showSnack('Story dihapus', _kCyan);
        _fetchStories();
      } else {
        _showSnack(data['message'] ?? 'Gagal hapus', _kRed);
      }
    } catch (_) {
      _showSnack('Gagal menghapus', _kRed);
    }
  }

  void _showSnack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 13)),
        backgroundColor: color.withOpacity(0.9),
        elevation: 0,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  Future<void> _pickAndUpload(ImageSource source, String type) async {
    final picker = ImagePicker();
    XFile? picked;
    if (type == 'image') {
      picked = await picker.pickImage(source: source, imageQuality: 80);
    } else {
      picked = await picker.pickVideo(source: source);
    }
    if (picked == null) return;

    final previewBytes = type == 'image' ? await picked.readAsBytes() : null;

    String caption = '';
    if (mounted) {
      final ctrl = TextEditingController();
      await showDialog(
        context: context,
        barrierColor: Colors.black.withOpacity(0.4),
        builder: (_) => Dialog(
          backgroundColor: Colors.transparent,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
              child: Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: _kCard,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _kBorder, width: 1.5),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 24)],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(14),
                      child: previewBytes != null
                          ? Image.memory(
                              previewBytes,
                              height: 220,
                              width: double.infinity,
                              fit: BoxFit.cover,
                            )
                          : Container(
                              height: 140,
                              width: double.infinity,
                              color: _kBg,
                              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                                const Icon(Icons.videocam_rounded, color: _kCyan, size: 48),
                                const SizedBox(height: 8),
                                Text(
                                  picked?.name ?? 'video',
                                  style: const TextStyle(color: _kWhite54, fontSize: 12, fontFamily: 'ShareTechMono'),
                                  textAlign: TextAlign.center,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ]),
                            ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Tambah Keterangan',
                      style: TextStyle(color: _kWhite, fontFamily: 'ShareTechMono', fontSize: 15, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: ctrl,
                      style: const TextStyle(color: _kWhite, fontFamily: 'ShareTechMono', fontSize: 14),
                      cursorColor: _kCyan,
                      decoration: InputDecoration(
                        hintText: 'Tulis sesuatu... (opsional)',
                        hintStyle: TextStyle(color: _kWhite54.withOpacity(0.6)),
                        filled: true,
                        fillColor: _kBg,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: _kBorder),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: _kBorder),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: _kCyan, width: 1.5),
                        ),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      ),
                      maxLines: 2,
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: GestureDetector(
                            onTap: () => Navigator.pop(context),
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              decoration: BoxDecoration(
                                color: _kBg,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: _kBorder),
                              ),
                              child: const Center(
                                  child: Text('Batal',
                                      style: TextStyle(color: _kWhite54, fontFamily: 'ShareTechMono', fontSize: 13))),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: GestureDetector(
                            onTap: () {
                              caption = ctrl.text.trim();
                              Navigator.pop(context);
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(colors: [_kCyan, _kPurple]),
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: [BoxShadow(color: _kCyan.withOpacity(0.3), blurRadius: 12)],
                              ),
                              child: const Center(
                                  child: Text('Unggah ✓',
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontFamily: 'ShareTechMono',
                                          fontSize: 13,
                                          fontWeight: FontWeight.bold))),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    }

    _uploadStory(file: File(picked.path), type: type, caption: caption);
  }

  void _showAddStorySheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.4),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            decoration: BoxDecoration(
              color: _kCard,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
              border: Border(
                top: BorderSide(color: _kBorder, width: 1.5),
                left: BorderSide(color: _kBorder, width: 1),
                right: BorderSide(color: _kBorder, width: 1),
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(width: 40, height: 4,
                      decoration: BoxDecoration(color: _kBorder, borderRadius: BorderRadius.circular(4))),
                  const SizedBox(height: 20),
                  const Text('Tambah Status',
                      style: TextStyle(color: _kWhite, fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'ShareTechMono')),
                  const SizedBox(height: 20),
                  _sheetOption(Icons.photo_camera_rounded, 'Foto dari Kamera', _kCyan, () {
                    Navigator.pop(context);
                    _pickAndUpload(ImageSource.camera, 'image');
                  }),
                  const SizedBox(height: 12),
                  _sheetOption(Icons.photo_library_rounded, 'Foto dari Galeri', _kGreen, () {
                    Navigator.pop(context);
                    _pickAndUpload(ImageSource.gallery, 'image');
                  }),
                  const SizedBox(height: 12),
                  _sheetOption(Icons.videocam_rounded, 'Video dari Kamera', _kPurple, () {
                    Navigator.pop(context);
                    _pickAndUpload(ImageSource.camera, 'video');
                  }),
                  const SizedBox(height: 12),
                  _sheetOption(Icons.video_library_rounded, 'Video dari Galeri', const Color(0xFFF59E0B), () {
                    Navigator.pop(context);
                    _pickAndUpload(ImageSource.gallery, 'video');
                  }),
                  const SizedBox(height: 8),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _sheetOption(IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
            decoration: BoxDecoration(
              color: color.withOpacity(0.08),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: color.withOpacity(0.3), width: 1.2),
            ),
            child: Row(
              children: [
                Container(
                  width: 42, height: 42,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: color.withOpacity(0.12),
                    border: Border.all(color: color.withOpacity(0.3), width: 1),
                  ),
                  child: Icon(icon, color: color, size: 20),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(label,
                      style: TextStyle(color: color, fontFamily: 'ShareTechMono', fontSize: 14, fontWeight: FontWeight.w600, letterSpacing: 0.3)),
                ),
                Icon(Icons.arrow_forward_rounded, color: color.withOpacity(0.6), size: 18),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _openStoryViewer(List<StoryItem> stories, int startIndex, {bool canDelete = false}) {
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => StoryViewer(
        stories: stories,
        startIndex: startIndex,
        sessionKey: widget.sessionKey,
        currentUser: widget.username,
        onDelete: canDelete ? _deleteStory : null,
      ),
    )).then((_) => _fetchStories());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: _kCard.withOpacity(0.95),
        foregroundColor: _kWhite,
        elevation: 0,
        flexibleSpace: ClipRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
            child: Container(color: Colors.transparent),
          ),
        ),
        title: const Text('Story',
            style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 20, fontWeight: FontWeight.bold)),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: _kCyan),
            onPressed: _fetchStories,
          ),
        ],
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset('assets/images/latar_xyra.jpg', fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(color: _kBg)),
          Container(color: _kBg.withOpacity(0.85)),
          _loading
              ? const Center(child: CircularProgressIndicator(color: _kCyan))
              : _error != null
                  ? Center(child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 72, height: 72,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _kRed.withOpacity(0.1),
                            border: Border.all(color: _kRed.withOpacity(0.3), width: 2),
                          ),
                          child: const Icon(Icons.error_outline, color: _kRed, size: 40),
                        ),
                        const SizedBox(height: 20),
                        const Text('Gagal Memuat Story',
                            style: TextStyle(color: _kWhite, fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'ShareTechMono')),
                        const SizedBox(height: 8),
                        Text(_error!, style: const TextStyle(color: _kWhite54, fontFamily: 'ShareTechMono', fontSize: 12)),
                        const SizedBox(height: 24),
                        GestureDetector(
                          onTap: _fetchStories,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(14),
                            child: BackdropFilter(
                              filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                                decoration: BoxDecoration(
                                  color: _kCyan.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(color: _kCyan.withOpacity(0.4), width: 1.5),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: const [
                                    Icon(Icons.refresh_rounded, color: _kCyan, size: 18),
                                    SizedBox(width: 8),
                                    Text('Coba Lagi',
                                        style: TextStyle(
                                            color: _kCyan,
                                            fontSize: 14,
                                            fontWeight: FontWeight.bold,
                                            fontFamily: 'ShareTechMono',
                                            letterSpacing: 1)),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ))
                  : RefreshIndicator(
                      color: _kCyan,
                      onRefresh: _fetchStories,
                      child: ListView(
                        padding: const EdgeInsets.fromLTRB(0, kToolbarHeight + 8, 0, 24),
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                            child: Text('Story Saya',
                                style: TextStyle(
                                    color: _kWhite54,
                                    fontSize: 11,
                                    fontFamily: 'ShareTechMono',
                                    letterSpacing: 1.5)),
                          ),
                          _buildMyStoryTile(),
                          if (_otherStories.isNotEmpty) ...[
                            const SizedBox(height: 20),
                            Padding(
                              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                              child: Row(
                                children: [
                                  Expanded(child: Divider(color: _kBorder, thickness: 0.8)),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 12),
                                    child: Text('Story Terbaru',
                                        style: TextStyle(
                                            color: _kWhite54,
                                            fontSize: 11,
                                            fontFamily: 'ShareTechMono',
                                            letterSpacing: 1.5)),
                                  ),
                                  Expanded(child: Divider(color: _kBorder, thickness: 0.8)),
                                ],
                              ),
                            ),
                            ..._otherStories.map(_buildOtherStoryTile),
                          ] else ...[
                            const SizedBox(height: 40),
                            const Center(
                                child: Text('Belum ada story dari pengguna lain',
                                    style: TextStyle(color: _kWhite54, fontFamily: 'ShareTechMono', fontSize: 13))),
                          ],
                        ],
                      ),
                    ),
        ],
      ),
    );
  }

  Widget _buildMyStoryTile() {
    final hasStories = _myStories.isNotEmpty;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: InkWell(
        onTap: hasStories ? () => _openStoryViewer(_myStories, 0, canDelete: true) : _showAddStorySheet,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(
            color: _kCard,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: hasStories ? _kGreen.withOpacity(0.5) : _kBorder),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10)],
          ),
          child: Row(
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    width: 60, height: 60,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: hasStories
                          ? const LinearGradient(colors: [_kGreen, Color(0xFF00BFA5)])
                          : null,
                      color: hasStories ? null : _kBorder,
                    ),
                    padding: const EdgeInsets.all(2.5),
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _kBg,
                      ),
                      padding: const EdgeInsets.all(2),
                      child: ClipOval(
                        child: hasStories && _myStories.first.mediaType == 'image'
                            ? CachedNetworkImage(
                                imageUrl: _myStories.first.mediaUrl,
                                fit: BoxFit.cover,
                                memCacheWidth: 200,
                                errorWidget: (_, __, ___) =>
                                    const Icon(Icons.person, color: _kWhite54, size: 28),
                              )
                            : const Icon(Icons.person, color: _kWhite54, size: 28),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: -2, right: -2,
                    child: GestureDetector(
                      onTap: _showAddStorySheet,
                      child: Container(
                        width: 22, height: 22,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle, color: _kCyan, border: Border.all(color: _kCard, width: 2)),
                        child: const Icon(Icons.add, size: 14, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Story Saya',
                        style: TextStyle(color: _kWhite, fontWeight: FontWeight.bold, fontFamily: 'ShareTechMono', fontSize: 15)),
                    const SizedBox(height: 2),
                    Text(
                      hasStories ? '${_myStories.length} story aktif' : 'Ketuk untuk menambah status',
                      style: TextStyle(color: hasStories ? _kGreen : _kWhite54, fontSize: 12, fontFamily: 'ShareTechMono'),
                    ),
                  ],
                ),
              ),
              if (hasStories)
                Container(
                  width: 10, height: 10,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _kGreen,
                    boxShadow: [BoxShadow(color: _kGreen.withOpacity(0.6), blurRadius: 6)],
                  ),
                )
              else
                const Icon(Icons.chevron_right_rounded, color: _kWhite54),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildOtherStoryTile(UserStoryGroup group) {
    final first = group.stories.first;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: InkWell(
        onTap: () => _openStoryViewer(group.stories, 0),
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: _kCard,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _kBorder),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8)],
          ),
          child: Row(
            children: [
              Container(
                width: 52, height: 52,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: group.hasUnviewed
                      ? const LinearGradient(colors: [_kPurple, _kCyan])
                      : null,
                  color: group.hasUnviewed ? null : _kBorder,
                ),
                padding: const EdgeInsets.all(2),
                child: ClipOval(
                  child: first.mediaType == 'image'
                      ? CachedNetworkImage(
                          imageUrl: first.mediaUrl,
                          fit: BoxFit.cover,
                          memCacheWidth: 200,
                          errorWidget: (_, __, ___) =>
                              Container(color: _kBorder, child: const Icon(Icons.person, color: _kWhite54, size: 24)),
                        )
                      : Container(
                          color: _kBorder,
                          child: const Icon(Icons.play_circle_outline, color: _kWhite54, size: 24)),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(group.username,
                        style: const TextStyle(color: _kWhite, fontWeight: FontWeight.bold, fontFamily: 'ShareTechMono', fontSize: 14)),
                    const SizedBox(height: 2),
                    Text('${group.stories.length} story',
                        style: const TextStyle(color: _kWhite54, fontSize: 12, fontFamily: 'ShareTechMono')),
                  ],
                ),
              ),
              if (group.hasUnviewed)
                Container(
                  width: 10, height: 10,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _kCyan,
                      boxShadow: [BoxShadow(color: _kCyan.withOpacity(0.5), blurRadius: 6)]),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Story Viewer (FIXED) ─────────────────────────────────────────────────────
class StoryViewer extends StatefulWidget {
  final List<StoryItem> stories;
  final int startIndex;
  final String sessionKey;
  final String currentUser;
  final void Function(String)? onDelete;

  const StoryViewer({
    super.key,
    required this.stories,
    required this.startIndex,
    required this.sessionKey,
    required this.currentUser,
    this.onDelete,
  });

  @override
  State<StoryViewer> createState() => _StoryViewerState();
}

class _StoryViewerState extends State<StoryViewer> with SingleTickerProviderStateMixin {
  late int _current;
  late AnimationController _progressCtrl;
  VideoPlayerController? _videoCtrl;
  ChewieController? _chewieCtrl;
  bool _videoReady = false;

  int _commentCount = 0;

  final Map<String, VideoPlayerController> _videoCache = {};

  static const Duration _imageDuration = Duration(seconds: 15);

  @override
  void initState() {
    super.initState();
    _current = widget.startIndex;
    _progressCtrl = AnimationController(vsync: this);
    _loadCurrent();
    _recordView();
    _loadCommentCount();
    _preloadAdjacent();
  }

  void _preloadAdjacent() {
    final indices = <int>{_current - 1, _current + 1}
        .where((i) => i >= 0 && i < widget.stories.length);
    for (final i in indices) {
      final s = widget.stories[i];
      if (s.mediaType == 'video') _preloadVideo(s.mediaUrl);
    }
  }

  Future<void> _preloadVideo(String url) async {
    if (_videoCache.containsKey(url)) return;
    try {
      final ctrl = VideoPlayerController.networkUrl(Uri.parse(url));
      await ctrl.initialize();
      _videoCache[url] = ctrl;
    } catch (_) {}
  }

  @override
  void dispose() {
    _progressCtrl.removeStatusListener(_onProgressEnd);
    _progressCtrl.dispose();
    _chewieCtrl?.dispose();
    _videoCtrl?.dispose();
    for (final c in _videoCache.values) {
      c.dispose();
    }
    _videoCache.clear();
    super.dispose();
  }

  Future<void> _recordView() async {
    final story = widget.stories[_current];
    try {
      await http.post(
        Uri.parse('$baseUrl/viewStory'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey, 'story_id': story.storyId}),
      ).timeout(const Duration(seconds: 5));
    } catch (_) {}
  }

  Future<void> _loadCommentCount() async {
    final story = widget.stories[_current];
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/getComments?key=${widget.sessionKey}&story_id=${story.storyId}'),
      ).timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        List raw = [];
        if (data['data'] is List) raw = data['data'];
        else if (data['comments'] is List) raw = data['comments'];
        if (mounted) setState(() => _commentCount = raw.length);
      }
    } catch (_) {}
  }

  void _openCommentSheet() {
    final story = widget.stories[_current];
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      barrierColor: Colors.black.withOpacity(0.4),
      builder: (_) => _CommentSheet(
        sessionKey: widget.sessionKey,
        storyId: story.storyId,
        currentUser: widget.currentUser,
        onCommentAdded: () {
          if (mounted) setState(() => _commentCount++);
        },
      ),
    );
  }

  void _loadCurrent() {
    _progressCtrl.stop();
    _progressCtrl.removeStatusListener(_onProgressEnd);

    _chewieCtrl?.dispose();
    _chewieCtrl = null;
    _videoCtrl = null;
    _videoReady = false;

    final story = widget.stories[_current];

    if (story.mediaType == 'video') {
      _videoCtrl = _videoCache[story.mediaUrl] ??
          VideoPlayerController.networkUrl(Uri.parse(story.mediaUrl));

      _videoCtrl!.initialize().then((_) {
        if (!mounted) return;
        _chewieCtrl = ChewieController(
          videoPlayerController: _videoCtrl!,
          autoPlay: true,
          looping: false,
          showControls: false,
        );
        setState(() => _videoReady = true);
        final videoDur = _videoCtrl!.value.duration;
        final dur = videoDur.inSeconds < 3 ? const Duration(seconds: 3) : videoDur;
        _progressCtrl.duration = dur;
        _progressCtrl.addStatusListener(_onProgressEnd);
        _progressCtrl.forward(from: 0);
        _preloadAdjacent();
      });
    } else {
      _progressCtrl.duration = _imageDuration;
      _progressCtrl.addStatusListener(_onProgressEnd);
      _progressCtrl.forward(from: 0);
      _preloadAdjacent();
    }

    _loadCommentCount();
  }

  void _onProgressEnd(AnimationStatus status) {
    if (status == AnimationStatus.completed) _next();
  }

  void _next() {
    if (_current < widget.stories.length - 1) {
      setState(() => _current++);
      _loadCurrent();
      _recordView();
    } else {
      Navigator.pop(context);
    }
  }

  void _prev() {
    if (_current > 0) {
      setState(() => _current--);
      _loadCurrent();
    }
  }

  Future<void> _toggleLike() async {
    final story = widget.stories[_current];
    try {
      await http.post(
        Uri.parse('$baseUrl/likeStory'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey, 'story_id': story.storyId}),
      ).timeout(const Duration(seconds: 5));
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final story = widget.stories[_current];
    final isOwner = story.isOwner || story.username == widget.currentUser;

    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTapDown: (d) {
          final w = MediaQuery.of(context).size.width;
          if (d.globalPosition.dx < w / 3) _prev();
          else _next();
        },
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (story.mediaType == 'video')
              _buildVideoLayer()
            else
              _buildImageLayer(story),

            Positioned(
              top: 0, left: 0, right: 0, height: 120,
              child: IgnorePointer(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter, end: Alignment.bottomCenter,
                      colors: [Colors.black.withOpacity(0.7), Colors.transparent],
                    ),
                  ),
                ),
              ),
            ),

            Positioned(
              top: MediaQuery.of(context).padding.top + 8,
              left: 8, right: 8,
              child: Row(
                children: List.generate(widget.stories.length, (i) {
                  return Expanded(
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      height: 3,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(2),
                        child: i < _current
                            ? Container(color: Colors.white)
                            : i == _current
                                ? AnimatedBuilder(
                                    animation: _progressCtrl,
                                    builder: (_, __) => LinearProgressIndicator(
                                      value: _progressCtrl.value,
                                      backgroundColor: Colors.white.withOpacity(0.3),
                                      valueColor: const AlwaysStoppedAnimation(Colors.white),
                                    ),
                                  )
                                : Container(color: Colors.white.withOpacity(0.3)),
                      ),
                    ),
                  );
                }),
              ),
            ),

            Positioned(
              top: MediaQuery.of(context).padding.top + 20,
              left: 12, right: 12,
              child: Row(
                children: [
                  CircleAvatar(
                      radius: 18,
                      backgroundColor: _kBorder,
                      child: const Icon(Icons.person, color: _kWhite54, size: 18)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(story.username,
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                                fontFamily: 'ShareTechMono')),
                        Text(_formatStoryTime(story.createdAt),
                            style: const TextStyle(
                                color: Colors.white70, fontSize: 11, fontFamily: 'ShareTechMono')),
                      ],
                    ),
                  ),
                  IconButton(
                      icon: const Icon(Icons.close, color: Colors.white),
                      onPressed: () => Navigator.pop(context)),
                  if (isOwner)
                    IconButton(
                      icon: const Icon(Icons.delete_outline, color: _kRed),
                      onPressed: () {
                        Navigator.pop(context);
                        widget.onDelete?.call(story.storyId);
                      },
                    ),
                ],
              ),
            ),

            Positioned(
              bottom: 0, left: 0, right: 0,
              child: Container(
                padding: EdgeInsets.fromLTRB(16, 24, 16, MediaQuery.of(context).padding.bottom + 16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [Colors.black.withOpacity(0.8), Colors.transparent],
                  ),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Expanded(
                      child: story.caption.isNotEmpty
                          ? Text(story.caption,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'ShareTechMono',
                                  fontSize: 14,
                                  shadows: [Shadow(blurRadius: 4, color: Colors.black)]))
                          : const SizedBox.shrink(),
                    ),
                    const SizedBox(width: 16),
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        GestureDetector(
                          onTap: _toggleLike,
                          child: Icon(
                            story.isLiked ? Icons.favorite : Icons.favorite_border,
                            color: story.isLiked ? _kRed : Colors.white,
                            size: 28,
                          ),
                        ),
                        Text('${story.likeCount}',
                            style: const TextStyle(color: Colors.white, fontSize: 12, fontFamily: 'ShareTechMono')),
                        const SizedBox(height: 12),
                        GestureDetector(
                          onTap: _openCommentSheet,
                          child: const Icon(Icons.chat_bubble_outline_rounded, color: Colors.white, size: 26),
                        ),
                        Text('$_commentCount',
                            style: const TextStyle(color: Colors.white, fontSize: 12, fontFamily: 'ShareTechMono')),
                        const SizedBox(height: 12),
                        const Icon(Icons.visibility_outlined, color: Colors.white, size: 24),
                        Text('${story.viewCount}',
                            style: const TextStyle(color: Colors.white, fontSize: 12, fontFamily: 'ShareTechMono')),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVideoLayer() {
    if (_videoReady && _chewieCtrl != null) {
      return Chewie(controller: _chewieCtrl!);
    }
    return const Center(child: CircularProgressIndicator(color: _kCyan));
  }

  Widget _buildImageLayer(StoryItem story) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Positioned.fill(
          child: CachedNetworkImage(
            imageUrl: story.mediaUrl,
            fit: BoxFit.cover,
            memCacheWidth: 400,
            placeholder: (_, __) => Container(color: Colors.black),
            errorWidget: (_, __, ___) => Container(color: Colors.black),
            fadeInDuration: Duration.zero,
          ),
        ),
        Positioned.fill(
          child: Container(color: Colors.black.withOpacity(0.55)),
        ),
        Center(
          child: CachedNetworkImage(
            imageUrl: story.mediaUrl,
            fit: BoxFit.contain,
            memCacheWidth: 1080,
            fadeInDuration: const Duration(milliseconds: 200),
            fadeOutDuration: const Duration(milliseconds: 100),
            placeholder: (_, __) => const SizedBox(
              width: 44,
              height: 44,
              child: Center(child: CircularProgressIndicator(color: _kCyan, strokeWidth: 2.5)),
            ),
            errorWidget: (_, __, ___) => const Center(
              child: Icon(Icons.broken_image, color: _kWhite54, size: 64),
            ),
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// COMMENT SHEET
// ═══════════════════════════════════════════════════════════════════════════════
class _CommentSheet extends StatefulWidget {
  final String sessionKey;
  final String storyId;
  final String currentUser;
  final VoidCallback? onCommentAdded;

  const _CommentSheet({
    required this.sessionKey,
    required this.storyId,
    required this.currentUser,
    this.onCommentAdded,
  });

  @override
  State<_CommentSheet> createState() => _CommentSheetState();
}

class _CommentSheetState extends State<_CommentSheet> {
  final TextEditingController _ctrl = TextEditingController();
  final FocusNode _focus = FocusNode();
  final ScrollController _scroll = ScrollController();

  List<StoryComment> _comments = [];
  bool _loading = true;
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _loadComments();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _focus.requestFocus();
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _focus.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _loadComments() async {
    setState(() => _loading = true);
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/getComments?key=${widget.sessionKey}&story_id=${widget.storyId}'),
      ).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        List raw = [];
        if (data['data'] is List) raw = data['data'];
        else if (data['comments'] is List) raw = data['comments'];
        final list = raw
            .whereType<Map>()
            .map((e) => StoryComment.fromJson(Map<String, dynamic>.from(e)))
            .toList();
        setState(() {
          _comments = list;
          _loading = false;
        });
      } else {
        setState(() => _loading = false);
      }
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  Future<void> _send() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty || _sending) return;

    setState(() => _sending = true);
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/sendComment'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'story_id': widget.storyId,
          'message': text,
        }),
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true || data['status'] == 'ok') {
          _ctrl.clear();
          setState(() {
            _comments.add(StoryComment(
              commentId: '',
              username: widget.currentUser,
              message: text,
              createdAt: 'Baru saja',
            ));
            _sending = false;
          });
          widget.onCommentAdded?.call();
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (_scroll.hasClients) {
              _scroll.animateTo(
                _scroll.position.maxScrollExtent,
                duration: const Duration(milliseconds: 250),
                curve: Curves.easeOut,
              );
            }
          });
          _loadComments();
        } else {
          setState(() => _sending = false);
        }
      } else {
        setState(() => _sending = false);
      }
    } catch (_) {
      setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;
    return Padding(
      padding: EdgeInsets.only(bottom: bottomInset),
      child: Container(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.75,
        ),
        decoration: BoxDecoration(
          color: _kCard,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border(
            top: BorderSide(color: _kCyan.withOpacity(0.3), width: 1.5),
            left: BorderSide(color: _kBorder),
            right: BorderSide(color: _kBorder),
          ),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 30, spreadRadius: 2),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 10, bottom: 4),
              child: Container(
                width: 40, height: 4,
                decoration: BoxDecoration(
                  color: _kCyan.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
              child: Row(
                children: [
                  const Icon(Icons.chat_bubble_rounded, color: _kCyan, size: 20),
                  const SizedBox(width: 10),
                  const Text(
                    'Komentar',
                    style: TextStyle(
                      color: _kWhite,
                      fontFamily: 'ShareTechMono',
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    '${_comments.length}',
                    style: const TextStyle(color: _kWhite54, fontFamily: 'ShareTechMono', fontSize: 13),
                  ),
                ],
              ),
            ),
            Divider(color: _kBorder, height: 1),
            Flexible(
              child: _loading
                  ? const Padding(
                      padding: EdgeInsets.symmetric(vertical: 40),
                      child: Center(child: CircularProgressIndicator(color: _kCyan, strokeWidth: 2)),
                    )
                  : _comments.isEmpty
                      ? Padding(
                          padding: const EdgeInsets.symmetric(vertical: 40),
                          child: Column(
                            children: [
                              Icon(Icons.chat_bubble_outline, color: _kWhite54.withOpacity(0.3), size: 42),
                              const SizedBox(height: 12),
                              const Text('Belum ada komentar',
                                  style: TextStyle(color: _kWhite54, fontFamily: 'ShareTechMono', fontSize: 13)),
                              const SizedBox(height: 4),
                              Text('Jadilah yang pertama!',
                                  style: TextStyle(color: _kWhite54.withOpacity(0.6), fontFamily: 'ShareTechMono', fontSize: 11)),
                            ],
                          ),
                        )
                      : ListView.builder(
                          controller: _scroll,
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          shrinkWrap: true,
                          itemCount: _comments.length,
                          itemBuilder: (_, i) {
                            final c = _comments[i];
                            final isMe = c.username == widget.currentUser;
                            return Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    width: 36, height: 36,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: isMe
                                          ? const LinearGradient(colors: [_kCyan, _kPurple])
                                          : LinearGradient(colors: [_kBorder, _kBorder.withOpacity(0.5)]),
                                      border: Border.all(color: isMe ? _kCyan.withOpacity(0.4) : _kBorder, width: 1.2),
                                    ),
                                    child: Center(
                                      child: Text(
                                        c.username.isNotEmpty ? c.username[0].toUpperCase() : '?',
                                        style: TextStyle(
                                          color: isMe ? Colors.white : _kWhite,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: 'ShareTechMono',
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            Text(
                                              c.username,
                                              style: TextStyle(
                                                color: isMe ? _kCyan : _kWhite,
                                                fontFamily: 'ShareTechMono',
                                                fontSize: 12,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            if (isMe) ...[
                                              const SizedBox(width: 6),
                                              Container(
                                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                                                decoration: BoxDecoration(
                                                  color: _kCyan.withOpacity(0.1),
                                                  borderRadius: BorderRadius.circular(4),
                                                  border: Border.all(color: _kCyan.withOpacity(0.3)),
                                                ),
                                                child: const Text('Kamu',
                                                    style: TextStyle(
                                                        color: _kCyan,
                                                        fontSize: 9,
                                                        fontFamily: 'ShareTechMono',
                                                        fontWeight: FontWeight.bold)),
                                              ),
                                            ],
                                            const Spacer(),
                                            Text(_formatStoryTime(c.createdAt),
                                                style: const TextStyle(
                                                    color: _kWhite54, fontSize: 10, fontFamily: 'ShareTechMono')),
                                          ],
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          c.message,
                                          style: const TextStyle(
                                              color: _kWhite, fontFamily: 'ShareTechMono', fontSize: 13, height: 1.4),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
            ),
            Divider(color: _kBorder, height: 1),
            Padding(
              padding: EdgeInsets.fromLTRB(12, 10, 12, 10 + MediaQuery.of(context).padding.bottom),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: _kBg,
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: _kBorder),
                      ),
                      child: TextField(
                        controller: _ctrl,
                        focusNode: _focus,
                        style: const TextStyle(color: _kWhite, fontFamily: 'ShareTechMono', fontSize: 13),
                        cursorColor: _kCyan,
                        textInputAction: TextInputAction.send,
                        onSubmitted: (_) => _send(),
                        maxLines: null,
                        decoration: const InputDecoration(
                          hintText: 'Tulis komentar...',
                          hintStyle: TextStyle(color: _kWhite54, fontFamily: 'ShareTechMono', fontSize: 13),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: _send,
                    child: Container(
                      width: 44, height: 44,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: _sending
                            ? const LinearGradient(colors: [_kBorder, _kBorder])
                            : const LinearGradient(colors: [_kCyan, _kPurple]),
                        boxShadow: _sending
                            ? []
                            : [BoxShadow(color: _kCyan.withOpacity(0.3), blurRadius: 12, spreadRadius: 1)],
                      ),
                      child: _sending
                          ? const Padding(
                              padding: EdgeInsets.all(12),
                              child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                            )
                          : const Icon(Icons.send_rounded, color: Colors.white, size: 20),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}