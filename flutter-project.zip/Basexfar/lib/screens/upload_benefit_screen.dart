import 'package:flutter/material.dart';
import '../services/benefit_service.dart';
import '../helpers/session_helper.dart';

class _C {
  static const bg        = Color(0xFFF5F9FF);
  static const surface   = Color(0xFFFFFFFF);
  static const card      = Color(0xFFFFFFFF);
  static const border    = Color(0xFFD6E4F5);
  static const borderLit = Color(0xFFB6CDE8);
  static const text      = Color(0xFF0F172A);
  static const textSub   = Color(0xFF475569);
  static const textDim   = Color(0xFF94A3B8);
  static const cyan      = Color(0xFF2563EB);
  static const blueLight = Color(0xFF3B82F6);
}

class UploadBenefitScreen extends StatefulWidget {
  final String? sessionKey;
  const UploadBenefitScreen({super.key, this.sessionKey});

  @override
  State<UploadBenefitScreen> createState() => _UploadBenefitScreenState();
}

class _UploadBenefitScreenState extends State<UploadBenefitScreen> {
  final _linkCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  final _service = BenefitService();
  bool _loading = false;
  String _sessionKey = '';
  bool _loadingSession = true;

  @override
  void initState() {
    super.initState();
    _initSession();
  }

  Future<void> _initSession() async {
    if (widget.sessionKey != null && widget.sessionKey!.isNotEmpty) {
      setState(() {
        _sessionKey = widget.sessionKey!;
        _loadingSession = false;
      });
      return;
    }

    final key = await SessionHelper.getSessionKey();
    setState(() {
      _sessionKey = key;
      _loadingSession = false;
    });
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    if (_sessionKey.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('❌ Session tidak ditemukan. Login ulang ya.')),
      );
      return;
    }

    setState(() => _loading = true);
    try {
      final result = await _service.uploadBenefit(
        sessionKey: _sessionKey,
        link: _linkCtrl.text.trim(),
        deskripsi: _descCtrl.text.trim(),
      );

      if (!mounted) return;

      if (result['valid'] == true) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('✅ Benefit berhasil diupload!')),
        );
        _linkCtrl.clear();
        _descCtrl.clear();
        Navigator.pop(context, true);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('❌ ${result['message']}')),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('❌ Gagal upload: $e')),
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _linkCtrl.dispose();
    _descCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        backgroundColor: _C.surface,
        foregroundColor: _C.text,
        elevation: 0,
        title: const Text(
          'Upload Benefit',
          style: TextStyle(
            fontFamily: 'ShareTechMono',
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      body: _loadingSession
          ? const Center(
              child: CircularProgressIndicator(color: _C.blueLight, strokeWidth: 2),
            )
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Info card
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: _C.card,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: _C.border, width: 1.5),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.03),
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: _C.bg,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: _C.borderLit),
                            ),
                            child: const Icon(
                              Icons.card_giftcard,
                              color: _C.cyan,
                              size: 20,
                            ),
                          ),
                          const SizedBox(width: 12),
                          const Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Bagikan Benefit',
                                  style: TextStyle(
                                    color: _C.text,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                SizedBox(height: 2),
                                Text(
                                  'Upload link & deskripsi untuk pengguna lain',
                                  style: TextStyle(
                                    color: _C.textSub,
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Label Link
                    const _FieldLabel(icon: Icons.link, text: 'Link Benefit'),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: _linkCtrl,
                      style: const TextStyle(
                        color: _C.text,
                        fontSize: 14,
                        fontFamily: 'ShareTechMono',
                      ),
                      decoration: InputDecoration(
                        hintText: 'https://contoh.com/benefit',
                        hintStyle: const TextStyle(color: _C.textDim, fontSize: 13),
                        prefixIcon: const Icon(Icons.link, color: _C.textSub, size: 20),
                        filled: true,
                        fillColor: _C.card,
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: _C.border),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: _C.blueLight, width: 2),
                        ),
                        errorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: Colors.red),
                        ),
                        focusedErrorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: Colors.red, width: 2),
                        ),
                      ),
                      keyboardType: TextInputType.url,
                      validator: (v) {
                        if (v == null || v.isEmpty) return 'Link wajib diisi';
                        final uri = Uri.tryParse(v);
                        if (uri == null || !uri.hasScheme) {
                          return 'Link tidak valid (harus pakai http/https)';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 20),

                    // Label Deskripsi
                    const _FieldLabel(
                        icon: Icons.description, text: 'Deskripsi'),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: _descCtrl,
                      maxLines: 5,
                      style: const TextStyle(
                        color: _C.text,
                        fontSize: 14,
                        height: 1.5,
                      ),
                      decoration: InputDecoration(
                        hintText:
                            'Contoh: Ini benefit untuk kalian, buruan ambil!',
                        hintStyle:
                            const TextStyle(color: _C.textDim, fontSize: 13),
                        alignLabelWithHint: true,
                        filled: true,
                        fillColor: _C.card,
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: _C.border),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: _C.blueLight, width: 2),
                        ),
                        errorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: Colors.red),
                        ),
                        focusedErrorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: Colors.red, width: 2),
                        ),
                      ),
                      validator: (v) => (v == null || v.isEmpty)
                          ? 'Deskripsi wajib diisi'
                          : null,
                    ),
                    const SizedBox(height: 28),

                    // Tombol Upload
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: ElevatedButton.icon(
                        onPressed: _loading ? null : _submit,
                        icon: _loading
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Icon(Icons.cloud_upload, size: 20),
                        label: Text(
                          _loading ? 'Mengupload...' : 'Upload Benefit',
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.8,
                            fontSize: 14,
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _C.blueLight,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}

class _FieldLabel extends StatelessWidget {
  final IconData icon;
  final String text;
  const _FieldLabel({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 15, color: _C.cyan),
        const SizedBox(width: 6),
        Text(
          text,
          style: const TextStyle(
            color: _C.text,
            fontSize: 13,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}