import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:intl/intl.dart';
import '../models/benefit_model.dart';
import '../services/benefit_service.dart';
import '../helpers/session_helper.dart';
import 'upload_benefit_screen.dart';

class _C {
  static const bg        = Color(0xFFF5F9FF);
  static const surface   = Color(0xFFFFFFFF);
  static const card      = Color(0xFFFFFFFF);
  static const border    = Color(0xFFD6E4F5);
  static const borderLit = Color(0xFFB6CDE8);
  static const text      = Color(0xFF0F172A);
  static const textSub   = Color(0xFF475569);
  static const textDim   = Color(0xFF94A3B8);
  static const cyan      = Color(0xFF2563EB);
  static const blueLight = Color(0xFF3B82F6);
}

class ListBenefitScreen extends StatefulWidget {
  final String? sessionKey;
  const ListBenefitScreen({super.key, this.sessionKey});

  @override
  State<ListBenefitScreen> createState() => _ListBenefitScreenState();
}

class _ListBenefitScreenState extends State<ListBenefitScreen> {
  final _service = BenefitService();
  List<BenefitModel> _benefits = [];
  bool _loading = true;
  String _sessionKey = '';
  String? _error;

  @override
  void initState() {
    super.initState();
    _initAndLoad();
  }

  Future<void> _initAndLoad() async {
    if (widget.sessionKey != null && widget.sessionKey!.isNotEmpty) {
      _sessionKey = widget.sessionKey!;
    } else {
      _sessionKey = await SessionHelper.getSessionKey();
    }

    await _loadBenefits();
  }

  Future<void> _loadBenefits() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    if (_sessionKey.isEmpty) {
      setState(() {
        _loading = false;
        _error = 'Session tidak ditemukan. Silakan login ulang.';
      });
      return;
    }

    try {
      final list = await _service.getBenefits(sessionKey: _sessionKey);
      if (!mounted) return;
      setState(() {
        _benefits = list;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'Gagal memuat: $e';
        _loading = false;
      });
    }
  }

  Future<void> _copyLink(BuildContext ctx, String link) async {
    await Clipboard.setData(ClipboardData(text: link));
    if (!ctx.mounted) return;
    ScaffoldMessenger.of(ctx).showSnackBar(
      const SnackBar(content: Text('📋 Link berhasil dicopy!')),
    );
  }

  Future<void> _openLink(BuildContext ctx, String link) async {
    final uri = Uri.tryParse(link);
    if (uri == null) return;
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      if (!ctx.mounted) return;
      ScaffoldMessenger.of(ctx).showSnackBar(
        const SnackBar(content: Text('❌ Tidak bisa membuka link')),
      );
    }
  }

  Future<void> _openUpload() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => UploadBenefitScreen(sessionKey: _sessionKey),
      ),
    );
    if (result == true) {
      _loadBenefits();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        backgroundColor: _C.surface,
        foregroundColor: _C.text,
        elevation: 0,
        title: const Text(
          'Ambil Benefit',
          style: TextStyle(
            fontFamily: 'ShareTechMono',
            fontWeight: FontWeight.w600,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadBenefits,
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: _C.blueLight,
        foregroundColor: Colors.white,
        elevation: 0,
        onPressed: _openUpload,
        icon: const Icon(Icons.add_link),
        label: const Text(
          'Upload',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
      ),
      body: RefreshIndicator(
        color: _C.blueLight,
        backgroundColor: _C.card,
        onRefresh: _loadBenefits,
        child: _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(
        child: CircularProgressIndicator(color: _C.blueLight, strokeWidth: 2),
      );
    }

    if (_error != null) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          SizedBox(height: MediaQuery.of(context).size.height * 0.3),
          Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.error_outline, size: 60, color: _C.textDim),
                  const SizedBox(height: 16),
                  Text(
                    _error!,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: _C.textSub),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton.icon(
                    onPressed: _loadBenefits,
                    icon: const Icon(Icons.refresh, size: 16),
                    label: const Text('Coba Lagi'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _C.blueLight,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      );
    }

    if (_benefits.isEmpty) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          SizedBox(height: MediaQuery.of(context).size.height * 0.28),
          const Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.card_giftcard, size: 64, color: _C.textDim),
                SizedBox(height: 16),
                Text(
                  'Belum ada benefit 😴',
                  style: TextStyle(color: _C.textSub, fontSize: 14),
                ),
                SizedBox(height: 6),
                Text(
                  'Klik tombol + untuk upload link',
                  style: TextStyle(color: _C.textDim, fontSize: 12),
                ),
                SizedBox(height: 20),
                Text(
                  'Tarik ke bawah untuk refresh',
                  style: TextStyle(color: _C.textDim, fontSize: 11),
                ),
              ],
            ),
          ),
        ],
      );
    }

    return ListView.builder(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(12),
      itemCount: _benefits.length,
      itemBuilder: (ctx, i) {
        final b = _benefits[i];
        return _BenefitCard(
          benefit: b,
          onCopy: () => _copyLink(context, b.link),
          onOpen: () => _openLink(context, b.link),
        );
      },
    );
  }
}

class _BenefitCard extends StatelessWidget {
  final BenefitModel benefit;
  final VoidCallback onCopy;
  final VoidCallback onOpen;

  const _BenefitCard({
    required this.benefit,
    required this.onCopy,
    required this.onOpen,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _C.border, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              benefit.deskripsi,
              style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w600,
                color: _C.text,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: _C.bg,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _C.border),
              ),
              child: Row(
                children: [
                  const Icon(Icons.link, size: 16, color: _C.cyan),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      benefit.link,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                      style: const TextStyle(
                        color: _C.cyan,
                        fontSize: 12,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                const Icon(Icons.person, size: 13, color: _C.textDim),
                const SizedBox(width: 4),
                Text(
                  benefit.uploader,
                  style: const TextStyle(fontSize: 11, color: _C.textSub),
                ),
                const Spacer(),
                const Icon(Icons.access_time, size: 12, color: _C.textDim),
                const SizedBox(width: 4),
                Text(
                  DateFormat('dd MMM yyyy, HH:mm').format(benefit.createdAt),
                  style: const TextStyle(fontSize: 11, color: _C.textDim),
                ),
              ],
            ),
            const Divider(height: 22, color: _C.border),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: onCopy,
                    icon: const Icon(Icons.copy, size: 16),
                    label: const Text('Copy Link'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: _C.textSub,
                      side: const BorderSide(color: _C.borderLit),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: onOpen,
                    icon: const Icon(Icons.open_in_new, size: 16),
                    label: const Text('Buka'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _C.blueLight,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}