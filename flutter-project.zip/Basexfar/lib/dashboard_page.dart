import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'dart:ui'; 
import 'dart:math' as math;

import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:system_info2/system_info2.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http_parser/http_parser.dart' as http_parser;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:audioplayers/audioplayers.dart'; 
import 'package:glaze_nav_bar/glaze_nav_bar.dart'; // ✅ GlazeNavBar 1.2.1

// ═══════════════════════════════════════════════════════════════
// IMPORT FILE KAMU
// ═══════════════════════════════════════════════════════════════
import 'package:Fiona/Qaxer/.dart'; // ✅ Tempat Api.api kamu

import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'partner_page.dart';
import 'developer_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'device_dashboard.dart';
import 'publik_chat.dart';
import 'webtoapk_page.dart';
import 'BanGroup_page.dart';
import 'telegram.dart';
import 'pasarOnline_page.dart';
import 'sendNotification_page.dart';
import 'up_role.dart';
import 'story_page.dart';
import 'audio_manager.dart';
import 'screens/list_benefit_screen.dart';
import 'spambot.dart';
import 'ai_chat_page.dart';

final _baseUrl = Api.api; 

// ═══════════════════════════════════════════════════════════════
// PALETTE — LIGHT CYBER (PUTIH & BIRU)
// ═══════════════════════════════════════════════════════════════
class _C {
  static const bg        = Color(0xFFF5F9FF);
  static const surface   = Color(0xFFFFFFFF);
  static const card      = Color(0xFFFFFFFF);
  static const cardAlt   = Color(0xFFEFF6FF);
  static const cardHi    = Color(0xFFE0E7FF);
  static const cardDarker = Color(0xFF0B0D13); // ✅ FIX ERROR
  static const border    = Color(0xFFD6E4F5);
  static const borderLit = Color(0xFFB6CDE8);
  static const glass     = Color(0x1A3B82F6);

  static const text      = Color(0xFF0F172A);
  static const textSub   = Color(0xFF475569);
  static const textDim   = Color(0xFF94A3B8);

  static const hud       = Color(0xFF2563EB);
  static const hudDim    = Color(0xFF3B82F6);
  static const neon      = Color(0xFF10B981);
  static const alert     = Color(0xFFEF4444);
  static const warn      = Color(0xFFF59E0B);
  static const purple    = Color(0xFF8B5CF6);
  static const violet    = Color(0xFF7C4DFF);
  static const magenta   = Color(0xFFEC4899);

  static const LinearGradient hudGrad = LinearGradient(
    colors: [Color(0xFF60A5FA), Color(0xFF3B82F6)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );

  static const LinearGradient btnGrad = LinearGradient(
    colors: [Color(0xFF3B82F6), Color(0xFF2563EB)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );

  static const LinearGradient textGrad = LinearGradient(
    colors: [Color(0xFF0F172A), Color(0xFF2563EB)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );

  // ✅ FIX ERROR primaryGrad
  static const LinearGradient primaryGrad = LinearGradient(
    colors: [Color(0xFF60A5FA), Color(0xFF3B82F6), Color(0xFF2563EB)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );

  // ✅ FIX ERROR auroraGrad
  static const LinearGradient auroraGrad = LinearGradient(
    colors: [Color(0xFF38BDF8), Color(0xFF8B5CF6), Color(0xFFEC4899)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );
}

Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'developer':
    case 'owner':
    case 'moderator':
    case 'partner':   return const Color(0xFFF59E0B);
    case 'admin':     return const Color(0xFF2563EB);
    case 'reseller':  return const Color(0xFF10B981);
    case 'vip':       return const Color(0xFF8B5CF6);
    default:          return const Color(0xFF0F172A);
  }
}

IconData _roleIcon(String role) {
  switch (role.toLowerCase()) {
    case 'developer':
    case 'owner':
    case 'moderator':
    case 'partner':   return Icons.workspace_premium_rounded;
    case 'admin':     return Icons.admin_panel_settings_rounded;
    case 'reseller':  return Icons.storefront_rounded;
    case 'vip':       return Icons.star_rounded;
    default:          return Icons.person_rounded;
  }
}

Route _slideRoute(Widget page) {
  return PageRouteBuilder(
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, anim, __, child) {
      final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutCubic);
      return SlideTransition(
        position: Tween<Offset>(begin: const Offset(0.0, 0.08), end: Offset.zero).animate(curved),
        child: FadeTransition(opacity: anim, child: child),
      );
    },
  );
}

// ═══════════════════════════════════════════════════════════════
// DASHBOARD PAGE
// ═══════════════════════════════════════════════════════════════
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGroup;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;
  final List<dynamic> jjVideos;
  final List<dynamic> thanksTo;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listBugGroup,
    required this.listDoos,
    required this.news,
    required this.jjVideos,
    required this.thanksTo,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  bool _is3DNeo = false;

  List<Map<String, dynamic>> get quickActions => [
    {"title": "Manage Sender","subtitle": "Kelola WhatsApp sender","icon": Icons.wifi_tethering_error_rounded,"color": const Color(0xFF10B981),
      "onTap": () => Navigator.push(context, _slideRoute(BugSenderPage(sessionKey: sessionKey, username: username, role: role)))},

    {"title": "Ambil Benefit","subtitle": "Link & tools gratis dari user lain","icon": Icons.card_giftcard_rounded,"color": const Color(0xFF8B5CF6),
      "onTap": () => Navigator.pushNamed(context, '/benefit')},

    {"title": "RAT","subtitle": "Control Devices Someone","icon": Icons.security,"color": const Color(0xFFEF4444),
      "onTap": () => Navigator.push(context, _slideRoute(DeviceDashboardPage(sessionKey: sessionKey, username: username, role: role)))},

    {"title": "Pasar Online","subtitle": "Marketplace jasa online","icon": Icons.storefront_rounded,"color": const Color(0xFFD4A843),
      "onTap": () => Navigator.push(context, _slideRoute(PasarOnlinePage(sessionKey: sessionKey, username: username, role: role)))},

    {"title": "Ban Group","subtitle": "Ban Group Whatsapp Fresh","icon": Icons.groups,"color": const Color(0xFFD32F2F),
      "onTap": () => Navigator.push(context, _slideRoute(BanGroupPage(username: username, password: password, listBug: listBug, listBugGroup: listBugGroup, role: role, expiredDate: expiredDate, sessionKey: sessionKey)))},

    {"title": "Public Chat","subtitle": "Chat Global User Apps","icon": Icons.forum_rounded,"color": const Color(0xFFFF9800),
      "onTap": () => Navigator.push(context, _slideRoute(CommunityPage(username: username, role: role, sessionKey: sessionKey)))},

    {"title": "Web To APK","subtitle": "Build website menjadi APK","icon": Icons.android_rounded,"color": const Color(0xFF10B981),
      "onTap": () => Navigator.push(context, _slideRoute(WebToApkPage()))},

    {"title": "Telegram Ban","subtitle": "Telegram Report Spam","icon": FontAwesomeIcons.telegram,"color": const Color(0xFF0EA5E9),
      "onTap": () => Navigator.push(context, _slideRoute(TelegramSpamPage(sessionKey: sessionKey)))},

    {"title": "Spam Bot Tele","subtitle": "Auto spam pesan Telegram","icon": FontAwesomeIcons.robot,"color": const Color(0xFF1A73E8),
      "onTap": () => Navigator.push(context, _slideRoute(SpamBotPage(sessionKey: sessionKey)))},

    {"title": "AI Chat","subtitle": "X-FAR AI Copilot","icon": Icons.smart_toy_rounded,"color": const Color(0xFF2F6FED),
      "onTap": () => Navigator.push(context, _slideRoute(AiChatPage(username: username)))},

    {"title": "Telegram","subtitle": "Join X-FAR Channel","icon": FontAwesomeIcons.telegram,"color": const Color(0xFF2AABEE),
      "onTap": () => _openUrl("https://t.me/xfar3")},

    {"title": "upgrade role","subtitle": "up role system","icon": Icons.sell_rounded,"color": const Color(0xFFD4AF37),
      "onTap": () => Navigator.push(context, _slideRoute(const BuyPage()))},
  ];

  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listBugGroup, listDoos;
  late List<dynamic> newsList, jjVideosList, thanksToList;
  late PageController _jjCtrl;
  String? _displayName, _bio, _networkProfileUrl;
  WebSocketChannel? channel;
  String androidId = 'unknown';
  File? _profileImage;
  Widget _body = const SizedBox();
  int onlineUsers = 0, activeConns = 0;
  DateTime _now = DateTime.now();
  Timer? _clockTimer;
  Timer? _storyRefreshTimer;
  String _timezoneLabel = 'WIB';
  
  late AnimationController _bgCtrl, _pageCtrl, _drawerHeaderCtrl, _pulseCtrl;
  late AnimationController _floatCtrl;
  
  late Animation<double> _floatAnim;
  late Animation<double> _pageFade, _pulseAnim;
  late Animation<Offset> _pageSlide;
  final PageController _newsPageCtrl = PageController(viewportFraction: 0.88);
  int _navIndex = 0;
  bool _bugPressed = false;

  final AudioPlayer _sfxPlayer = AudioPlayer(); 
  final AudioPlayer _bgmPlayer = AudioPlayer(); 
  bool _isBgmPlaying = false; 

  List<Map<String, dynamic>> _storyUsers = [];
  bool _loadingStories = false;
  bool _uploadingStory = false;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listBugGroup = widget.listBugGroup;
    listDoos = widget.listDoos;
    newsList = widget.news;
    thanksToList = widget.thanksTo;
    jjVideosList = widget.jjVideos;

    _jjCtrl = jjVideosList.length > 1
        ? PageController(viewportFraction: 0.65, initialPage: 5000)
        : PageController(viewportFraction: 1.0);

    _bgCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 25))..repeat();
    _pageCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _pageFade = CurvedAnimation(parent: _pageCtrl, curve: Curves.easeOut);
    _pageSlide = Tween<Offset>(begin: const Offset(0, 0.05), end: Offset.zero)
        .animate(CurvedAnimation(parent: _pageCtrl, curve: Curves.easeOutCubic));
    _drawerHeaderCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat(reverse: true);
    _pulseAnim = CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut);

    _floatCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat(reverse: true);
    _floatAnim = Tween<double>(begin: -4.0, end: 4.0).animate(
      CurvedAnimation(parent: _floatCtrl, curve: Curves.easeInOut),
    );

    _body = _newsPage_();
    _pageCtrl.forward();
    
    _initSfx();
    _initBgm(); 

    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });

    _initAndroidId();
    _loadProfileImage();
    _fetchUserProfile();
    _fetchStoryUsers();

    _storyRefreshTimer = Timer.periodic(const Duration(seconds: 25), (_) {
      if (mounted && !_uploadingStory) _fetchStoryUsers(silent: true);
    });
  }

  Future<void> _initSfx() async {
    try {
      await _sfxPlayer.setSource(AssetSource('sounds/zero.mp3'));
      await _sfxPlayer.setReleaseMode(ReleaseMode.stop);
      await _sfxPlayer.setVolume(1.0);
    } catch (e) {}
  }

  Future<void> _playSfx() async {
    try {
      await _sfxPlayer.stop();
      await _sfxPlayer.resume();
    } catch (e) {}
  }

  Future<void> _initBgm() async {
    try {
      await _bgmPlayer.setSource(AssetSource('audio/breakbeat_dream.mp3')); 
      await _bgmPlayer.setReleaseMode(ReleaseMode.loop); 
      await _bgmPlayer.setVolume(0.3);
      await _bgmPlayer.resume();
      if (mounted) setState(() => _isBgmPlaying = true);
    } catch (e) {}
  }

  Future<void> _toggleBgm() async {
    try {
      if (_isBgmPlaying) {
        await _bgmPlayer.pause();
      } else {
        await _bgmPlayer.resume();
      }
      if (mounted) setState(() => _isBgmPlaying = !_isBgmPlaying);
    } catch (e) {}
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    _storyRefreshTimer?.cancel();
    try { channel?.sink.close(status.goingAway); } catch (_) {}
    _bgCtrl.dispose(); 
    _pageCtrl.dispose();
    _drawerHeaderCtrl.dispose(); 
    _pulseCtrl.dispose();
    _floatCtrl.dispose();
    _newsPageCtrl.dispose(); 
    _jjCtrl.dispose();
    
    _sfxPlayer.dispose();
    _bgmPlayer.dispose();
    super.dispose();
  }

  void _toggle3DNeo() {
    HapticFeedback.mediumImpact();
    setState(() => _is3DNeo = !_is3DNeo);
  }

  void _showTimezonePicker() {
    showModalBottomSheet(
      context: context, backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.vertical(top: Radius.circular(_is3DNeo ? 0 : 24)),
          border: Border.all(color: _C.border, width: 2),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 44, height: 4, decoration: BoxDecoration(color: _C.border, borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 18),
          const Row(children: [
            Icon(Icons.access_time_rounded, color: _C.hud, size: 22),
            SizedBox(width: 10),
            Text('PILIH ZONA WAKTU', style: TextStyle(color: _C.text, fontSize: 16, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
          ]),
          const SizedBox(height: 20),
          _tzItem('WIB', 'Waktu Indonesia Barat (UTC+7)'),
          const SizedBox(height: 10),
          _tzItem('WITA', 'Waktu Indonesia Tengah (UTC+8)'),
          const SizedBox(height: 10),
          _tzItem('WIT', 'Waktu Indonesia Timur (UTC+9)'),
          const SizedBox(height: 16),
        ]),
      ),
    );
  }

  Widget _tzItem(String code, String label) {
    final active = _timezoneLabel == code;
    return GestureDetector(
      onTap: () { Navigator.pop(context); setState(() => _timezoneLabel = code); },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: active ? _C.hud.withOpacity(0.1) : _C.cardAlt,
          borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 14),
          border: Border.all(color: active ? _C.hud : _C.border, width: 1.5),
        ),
        child: Row(children: [
          Container(width: 20, height: 20,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: active ? _C.hud : Colors.transparent,
              border: Border.all(color: _C.hud, width: 1.5)),
            child: active ? const Icon(Icons.check, size: 12, color: Colors.white) : null),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(code, style: const TextStyle(color: _C.text, fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 2)),
            Text(label, style: const TextStyle(color: _C.textSub, fontSize: 11)),
          ])),
        ]),
      ),
    );
  }

  void _showXSpyderSheet() {
    showModalBottomSheet(
      context: context, backgroundColor: Colors.transparent, isScrollControlled: true,
      builder: (_) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.vertical(top: Radius.circular(_is3DNeo ? 0 : 24)),
          border: Border.all(color: _C.border, width: 2),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 44, height: 4, decoration: BoxDecoration(color: _C.border, borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 18),
          ShaderMask(
            shaderCallback: (bounds) => _C.textGrad.createShader(bounds),
            child: const Text('X-FAR',
              style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w900, fontFamily: 'Qaxer', letterSpacing: 6)),
          ),
          const SizedBox(height: 8),
          const Text('MENU CEPAT', style: TextStyle(color: _C.textSub, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 2)),
          const SizedBox(height: 24),
          _xMenuBtn(icon: Icons.account_circle_outlined, label: 'My Profile',
            onTap: () { Navigator.pop(context); Navigator.push(context, _slideRoute(ProfilePage(
              username: username, password: password, role: role, expiredDate: expiredDate, sessionKey: sessionKey))); }),
          const SizedBox(height: 10),
          _xMenuBtn(icon: Icons.history_rounded, label: 'Riwayat Aktivitas',
            onTap: () { Navigator.pop(context); Navigator.push(context, _slideRoute(RiwayatPage(sessionKey: sessionKey, role: role))); }),
          const SizedBox(height: 10),
          _xMenuBtn(icon: Icons.lock_outline_rounded, label: 'Ubah Password',
            onTap: () { Navigator.pop(context); Navigator.push(context, _slideRoute(ChangePasswordPage(username: username, sessionKey: sessionKey))); }),
          const SizedBox(height: 10),
          _xMenuBtn(icon: Icons.support_agent_rounded, label: 'Contact Support',
            onTap: () { Navigator.pop(context); Navigator.push(context, _slideRoute(const ContactPage())); }),
          const SizedBox(height: 10),
          _xMenuBtn(icon: Icons.logout_rounded, label: 'Keluar', isDanger: true,
            onTap: () async {
              Navigator.pop(context);
              await AudioManager().stop();
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              if (!mounted) return;
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false);
            }),
          const SizedBox(height: 16),
        ]),
      ),
    );
  }

  Widget _xMenuBtn({required IconData icon, required String label, required VoidCallback onTap, bool isDanger = false}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 14),
          border: Border.all(color: isDanger ? _C.alert : _C.border, width: 1.5),
        ),
        child: Row(children: [
          Icon(icon, color: isDanger ? _C.alert : _C.hud, size: 20),
          const SizedBox(width: 14),
          Expanded(child: Text(label, style: TextStyle(
            color: isDanger ? _C.alert : _C.text, fontSize: 14, fontWeight: FontWeight.w800))),
          Icon(Icons.chevron_right_rounded, color: _C.border, size: 20),
        ]),
      ),
    );
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  Future<void> _fetchUserProfile() async {
    try {
      final res = await http.get(Uri.parse("$_baseUrl/api/getProfile?username=$username&key=$sessionKey"));
      final json = jsonDecode(res.body);
      if (json["success"] == true && mounted) {
        setState(() {
          _displayName = json["displayName"] ?? "";
          _bio = json["bio"] ?? "";
          _networkProfileUrl = json["profileImageUrl"];
        });
      }
    } catch (_) {}
  }

  Future<void> _initAndroidId() async {
    try {
      final info = await DeviceInfoPlugin().androidInfo;
      androidId = info.id;
      _connectWS();
    } catch (_) {}
  }

  void _connectWS() {
    try {
      channel = WebSocketChannel.connect(Uri.parse('$_baseUrl'));
      channel!.sink.add(jsonEncode({'type': 'validate', 'key': sessionKey, 'androidId': androidId}));
      channel!.sink.add(jsonEncode({'type': 'stats'}));
      channel!.stream.listen((event) {
        final data = jsonDecode(event);
        if (data['type'] == 'myInfo' && data['valid'] == false) {
          final reason = data['reason'];
          _handleInvalidSession(reason == 'androidIdMismatch'
              ? 'Akun ini login di perangkat lain.' : 'Sesi tidak valid. Silakan login ulang.');
        }
        if (data['type'] == 'stats' && mounted) {
          setState(() {
            onlineUsers = data['onlineUsers'] ?? 0;
            activeConns = data['activeConnections'] ?? 0;
          });
        }
      }, onError: (_) {});
    } catch (_) {}
  }

  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    _showSystemDialog(
      title: 'SESI BERAKHIR', message: message,
      icon: Icons.lock_outline_rounded, color: _C.alert,
      onOk: () => Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false),
    );
  }

  void _navigate(Widget page) {
    setState(() => _body = page);
    _pageCtrl.forward(from: 0);
  }

  void _onNavTap(int index) {
    if (_navIndex == index) return; 
    _playSfx(); 

    setState(() => _navIndex = index);
    switch (index) {
      case 0: _navigate(_newsPage_()); break; 
      case 1: _navigate(InfoPage(sessionKey: sessionKey)); break; 
      case 2: _navigate(HomePage(username: username, password: password, listBug: listBug, listBugGroup: listBugGroup, role: role, expiredDate: expiredDate, sessionKey: sessionKey)); break; 
      case 3: _navigate(ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos)); break; 
    }
  }

  void _onDrawerNav(int index) {
    Navigator.pop(context);
    switch (index) {
      case 1: _navigate(SellerPage(keyToken: sessionKey)); break;
      case 2: _navigate(AdminPage(sessionKey: sessionKey)); break;
      case 3: _navigate(PartnerPage(sessionKey: sessionKey, username: username)); break;
      case 4: _navigate(OwnerPage(sessionKey: sessionKey, username: username)); break;
      case 5: _navigate(DeveloperPage(sessionKey: sessionKey, username: username)); break;
    }
  }

  void _showSystemDialog({required String title, required String message,
    required IconData icon, required Color color, VoidCallback? onOk}) {
    showGeneralDialog(
      context: context, barrierDismissible: false, barrierLabel: '',
      barrierColor: Colors.black.withOpacity(0.4),
      transitionDuration: const Duration(milliseconds: 350),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: Tween<double>(begin: 0.85, end: 1.0).animate(
          CurvedAnimation(parent: anim, curve: Curves.easeOutBack)),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 24),
            border: Border.all(color: _C.border, width: 1.5),
            boxShadow: _is3DNeo
                ? [BoxShadow(color: _C.hud.withOpacity(0.5), offset: const Offset(8, 8), blurRadius: 0)]
                : [BoxShadow(color: _C.hud.withOpacity(0.1), blurRadius: 40, spreadRadius: 6)],
          ),
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 64, height: 64,
              decoration: BoxDecoration(
                shape: _is3DNeo ? BoxShape.rectangle : BoxShape.circle,
                borderRadius: _is3DNeo ? BorderRadius.circular(0) : null,
                color: color.withOpacity(0.15),
                border: Border.all(color: color, width: 2)),
              child: Icon(icon, color: color, size: 30)),
            const SizedBox(height: 18),
            Text(title, style: const TextStyle(color: _C.text, fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
            const SizedBox(height: 8),
            Text(message, textAlign: TextAlign.center,
              style: const TextStyle(color: _C.textSub, fontSize: 14, height: 1.5, fontWeight: FontWeight.w600)),
            const SizedBox(height: 26),
            _GradBtn(label: 'OK', fullWidth: true, is3DNeo: _is3DNeo,
              onTap: () { Navigator.pop(ctx); onOk?.call(); }),
          ]),
        ),
      ),
    );
  }

  Widget _buildKremBackground() {
    return _ImageBackground(assetPath: 'assets/images/bg.jpg', is3DNeo: _is3DNeo);
  }

  Future<void> _fetchStoryUsers({bool silent = false}) async {
    if (!silent && mounted) setState(() => _loadingStories = true);
    try {
      final res = await http.get(
        Uri.parse("$_baseUrl/getStories?key=$sessionKey&_t=${DateTime.now().millisecondsSinceEpoch}"),
        headers: {'Cache-Control': 'no-cache'},
      ).timeout(const Duration(seconds: 12));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        List raw = [];
        if (data['data'] is List) raw = data['data'];
        else if (data['stories'] is List) raw = data['stories'];

        final Map<String, Map<String, dynamic>> grouped = {};
        grouped[username] = <String, dynamic>{
          "username": username, "imageUrl": null, "isMe": true,
          "hasStory": false, "storyCount": 0,
          "initial": username.isNotEmpty ? username[0].toUpperCase() : "?",
          "latestAt": null,
        };

        for (final entry in raw) {
          if (entry is! Map) continue;
          final e = Map<String, dynamic>.from(entry);
          if (e['stories'] is List) {
            final uname = (e['username'] ?? '').toString();
            if (uname.isEmpty) continue;
            final stories = e['stories'] as List;
            if (stories.isEmpty) continue;
            final first = stories.first is Map ? Map<String, dynamic>.from(stories.first) : <String, dynamic>{};
            String img = (first['media_url'] ?? first['mediaUrl'] ?? '').toString();
            if (img.startsWith('/')) img = '$_baseUrl$img';
            final latestAt = (first['created_at'] ?? first['createdAt'] ?? '').toString();
            if (uname == username) {
              grouped[username]!["imageUrl"] = img.isNotEmpty ? img : null;
              grouped[username]!["hasStory"] = true;
              grouped[username]!["storyCount"] = stories.length;
              grouped[username]!["latestAt"] = latestAt;
            } else {
              grouped[uname] = <String, dynamic>{
                "username": uname, "imageUrl": img.isNotEmpty ? img : null,
                "isMe": false, "hasStory": true, "storyCount": stories.length,
                "initial": uname.isNotEmpty ? uname[0].toUpperCase() : "?",
                "latestAt": latestAt,
              };
            }
          } else {
            final uname = (e['username'] ?? '').toString();
            if (uname.isEmpty) continue;
            String img = (e['media_url'] ?? e['mediaUrl'] ?? '').toString();
            if (img.startsWith('/')) img = '$_baseUrl$img';
            final latestAt = (e['created_at'] ?? e['createdAt'] ?? '').toString();
            if (uname == username) {
              grouped[username]!["imageUrl"] = img.isNotEmpty ? img : null;
              grouped[username]!["hasStory"] = true;
              grouped[username]!["storyCount"] = 1;
              grouped[username]!["latestAt"] = latestAt;
            } else {
              grouped.putIfAbsent(uname, () => <String, dynamic>{
                "username": uname, "imageUrl": img.isNotEmpty ? img : null,
                "isMe": false, "hasStory": true, "storyCount": 1,
                "initial": uname.isNotEmpty ? uname[0].toUpperCase() : "?",
                "latestAt": latestAt,
              });
              if (img.isNotEmpty) grouped[uname]!["imageUrl"] = img;
            }
          }
        }

        final me = grouped.remove(username);
        final list = <Map<String, dynamic>>[];
        if (me != null) list.add(me);
        final others = grouped.values.toList()
          ..sort((a, b) => (b["latestAt"] ?? '').toString().compareTo((a["latestAt"] ?? '').toString()));
        list.addAll(others);

        if (mounted) setState(() { _storyUsers = list; _loadingStories = false; });
      } else {
        if (mounted && !silent) setState(() => _loadingStories = false);
      }
    } catch (e) {
      debugPrint("Fetch story users error: $e");
      if (mounted && !silent) setState(() => _loadingStories = false);
    }
  }

  Future<void> _openStoryViewer(String targetUser) async {
    if (mounted) {
      showDialog(
        context: context, barrierDismissible: false,
        builder: (_) => Center(child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: _C.card, borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _C.border)),
          child: const SizedBox(width: 40, height: 40,
            child: CircularProgressIndicator(color: _C.hud, strokeWidth: 3)),
        )),
      );
    }
    try {
      final res = await http.get(
        Uri.parse("$_baseUrl/getStories?key=$sessionKey&_t=${DateTime.now().millisecondsSinceEpoch}"),
      ).timeout(const Duration(seconds: 12));
      if (mounted) Navigator.pop(context);
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        List raw = [];
        if (data['data'] is List) raw = data['data'];
        else if (data['stories'] is List) raw = data['stories'];
        final List<StoryItem> userStories = [];
        for (final entry in raw) {
          if (entry is! Map) continue;
          final e = Map<String, dynamic>.from(entry);
          if (e['stories'] is List) {
            final uname = (e['username'] ?? '').toString();
            if (uname != targetUser) continue;
            for (final s in (e['stories'] as List)) {
              if (s is Map) userStories.add(StoryItem.fromJson(Map<String, dynamic>.from(s)));
            }
          } else {
            final uname = (e['username'] ?? '').toString();
            if (uname == targetUser) userStories.add(StoryItem.fromJson(e));
          }
        }
        if (userStories.isEmpty) {
          _showSnack('Tidak ada story untuk user ini', _C.warn);
          return;
        }
        if (!mounted) return;
        Navigator.push(context, MaterialPageRoute(
          builder: (_) => StoryViewer(
            stories: userStories, startIndex: 0,
            sessionKey: sessionKey, currentUser: username,
            onDelete: targetUser == username
                ? (storyId) async {
                    try {
                      await http.post(Uri.parse('$_baseUrl/deleteStory'),
                        headers: {'Content-Type': 'application/json'},
                        body: jsonEncode({'key': sessionKey, 'story_id': storyId}));
                      _fetchStoryUsers();
                    } catch (_) {}
                  }
                : null,
          ),
        )).then((_) => _fetchStoryUsers(silent: true));
      } else {
        _showSnack('Gagal memuat story (${res.statusCode})', _C.alert);
      }
    } catch (e) {
      if (mounted) Navigator.pop(context);
      _showSnack('Gagal memuat story: cek koneksi', _C.alert);
    }
  }

  void _showAddStorySheet() {
    showModalBottomSheet(
      context: context, backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.5),
      builder: (_) => Container(
        padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 20),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border.all(color: _C.border, width: 1.5),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(color: _C.border, borderRadius: BorderRadius.circular(4))),
          const SizedBox(height: 20),
          const Text('TAMBAH STATUS',
            style: TextStyle(color: _C.text, fontSize: 15, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
          const SizedBox(height: 20),
          _sheetOption(Icons.photo_camera_rounded, 'Foto dari Kamera', _C.hud,
            () { Navigator.pop(context); _pickAndUpload(ImageSource.camera, 'image'); }),
          const SizedBox(height: 12),
          _sheetOption(Icons.photo_library_rounded, 'Foto dari Galeri', _C.neon,
            () { Navigator.pop(context); _pickAndUpload(ImageSource.gallery, 'image'); }),
          const SizedBox(height: 12),
          _sheetOption(Icons.videocam_rounded, 'Video dari Kamera', _C.violet,
            () { Navigator.pop(context); _pickAndUpload(ImageSource.camera, 'video'); }),
          const SizedBox(height: 12),
          _sheetOption(Icons.video_library_rounded, 'Video dari Galeri', _C.warn,
            () { Navigator.pop(context); _pickAndUpload(ImageSource.gallery, 'video'); }),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  Widget _sheetOption(IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.35), width: 1.2),
        ),
        child: Row(children: [
          Container(width: 42, height: 42,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(0.15),
              border: Border.all(color: color.withOpacity(0.4), width: 1)),
            child: Icon(icon, color: color, size: 20)),
          const SizedBox(width: 14),
          Expanded(child: Text(label,
            style: TextStyle(color: color, fontSize: 14, fontWeight: FontWeight.w700))),
          Icon(Icons.arrow_forward_rounded, color: color.withOpacity(0.6), size: 18),
        ]),
      ),
    );
  }

  Future<void> _pickAndUpload(ImageSource source, String type) async {
    final picker = ImagePicker();
    XFile? picked;
    if (type == 'image') {
      picked = await picker.pickImage(source: source, imageQuality: 80);
    } else {
      picked = await picker.pickVideo(source: source);
    }
    if (picked == null) return;

    final previewBytes = type == 'image' ? await picked.readAsBytes() : null;
    String caption = '';
    if (mounted) {
      final ctrl = TextEditingController();
      await showDialog(
        context: context, barrierColor: Colors.black.withOpacity(0.6),
        builder: (_) => Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: _C.card, borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _C.border, width: 1.5)),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: previewBytes != null
                    ? Image.memory(previewBytes, height: 200, width: double.infinity, fit: BoxFit.cover)
                    : Container(height: 130, width: double.infinity, color: _C.surface,
                        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          const Icon(Icons.videocam_rounded, color: _C.hud, size: 42),
                          const SizedBox(height: 8),
                          Text(picked?.name ?? 'video',
                            style: const TextStyle(color: _C.textSub, fontSize: 11),
                            textAlign: TextAlign.center, overflow: TextOverflow.ellipsis),
                        ])),
              ),
              const SizedBox(height: 16),
              const Text('Tambah Keterangan',
                style: TextStyle(color: _C.text, fontSize: 15, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              TextField(
                controller: ctrl,
                style: const TextStyle(color: _C.text, fontSize: 14),
                cursorColor: _C.hud,
                decoration: InputDecoration(
                  hintText: 'Tulis sesuatu... (opsional)',
                  hintStyle: TextStyle(color: _C.textDim.withOpacity(0.6)),
                  filled: true, fillColor: _C.surface,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: _C.border)),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: _C.border)),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: _C.hud, width: 1.5)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                ),
                maxLines: 2,
              ),
              const SizedBox(height: 16),
              Row(children: [
                Expanded(child: GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      color: _C.surface,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _C.border)),
                    child: const Center(child: Text('Batal',
                      style: TextStyle(color: _C.textSub, fontSize: 13))))),
                ),
                const SizedBox(width: 10),
                Expanded(child: GestureDetector(
                  onTap: () { caption = ctrl.text.trim(); Navigator.pop(context); },
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      gradient: _C.btnGrad,
                      borderRadius: BorderRadius.circular(10)),
                    child: const Center(child: Text('Unggah',
                      style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w800))))),
                ),
              ]),
            ]),
          ),
        ),
      );
    }
    _uploadStory(file: File(picked.path), type: type, caption: caption);
  }

  Future<void> _uploadStory({required File file, required String type, String caption = ''}) async {
    if (mounted) {
      setState(() => _uploadingStory = true);
      showDialog(
        context: context, barrierDismissible: false,
        builder: (_) => PopScope(
          canPop: false,
          child: Dialog(
            backgroundColor: Colors.transparent,
            child: Container(
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                color: _C.card, borderRadius: BorderRadius.circular(18),
                border: Border.all(color: _C.border)),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const SizedBox(width: 50, height: 50,
                  child: CircularProgressIndicator(color: _C.hud, strokeWidth: 3)),
                const SizedBox(height: 20),
                const Text('MENGUNGGAH STORY...',
                  style: TextStyle(color: _C.text, fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
              ]),
            ),
          ),
        ),
      );
    }
    try {
      final req = http.MultipartRequest('POST', Uri.parse('$_baseUrl/uploadStory'));
      req.fields['key'] = sessionKey;
      req.fields['caption'] = caption;
      req.fields['media_type'] = type;
      req.fields['type'] = type;
      req.fields['_t'] = DateTime.now().millisecondsSinceEpoch.toString();

      String mimeType;
      final ext = file.path.split('.').last.toLowerCase();
      if (type == 'video') {
        mimeType = ext == 'mov' ? 'video/quicktime' : 'video/mp4';
      } else {
        mimeType = ext == 'png' ? 'image/png' : ext == 'webp' ? 'image/webp' : 'image/jpeg';
      }
      req.files.add(await http.MultipartFile.fromPath(
        'file', file.path,
        contentType: http_parser.MediaType.parse(mimeType),
      ));
      final streamed = await req.send().timeout(const Duration(seconds: 180));
      final res = await http.Response.fromStream(streamed);
      if (mounted) Navigator.pop(context);
      if (mounted) setState(() => _uploadingStory = false);
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true || data['status'] == 'ok' || data['success'] == true) {
          _showSnack('Story berhasil diunggah', _C.neon);
          await Future.delayed(const Duration(milliseconds: 800));
          await _fetchStoryUsers();
        } else {
          _showSnack('${data['message'] ?? 'Gagal upload'}', _C.alert);
        }
      } else {
        _showSnack('Server error ${res.statusCode}', _C.alert);
      }
    } catch (e) {
      if (mounted) Navigator.pop(context);
      if (mounted) setState(() => _uploadingStory = false);
      _showSnack('Upload gagal: cek koneksi', _C.alert);
    }
  }

  void _showSnack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
        backgroundColor: color.withOpacity(0.9),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  Widget _buildStoryRow() {
    final List<Map<String, dynamic>> list = _storyUsers.isNotEmpty
        ? _storyUsers
        : <Map<String, dynamic>>[
            <String, dynamic>{
              "username": username, "imageUrl": null, "isMe": true,
              "hasStory": false, "storyCount": 0,
              "initial": username.isNotEmpty ? username[0].toUpperCase() : "?",
            }
          ];
    return SizedBox(
      height: 116,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        itemCount: list.length,
        cacheExtent: 500,
        addAutomaticKeepAlives: false,
        addRepaintBoundaries: true,
        itemBuilder: (context, index) {
          final user = list[index];
          return RepaintBoundary(
            child: _StoryAvatarItem(
              user: user, username: username,
              onTap: (uname, hasStory) {
                HapticFeedback.mediumImpact();
                if (hasStory) { _openStoryViewer(uname); } else { _showAddStorySheet(); }
              },
              onAddTap: () { HapticFeedback.mediumImpact(); _showAddStorySheet(); },
            ),
          );
        },
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // HALAMAN UTAMA
  // ═══════════════════════════════════════════════════════════════
  Widget _newsPage_() {
    return RefreshIndicator(
      color: _C.hud,
      backgroundColor: _C.card,
      onRefresh: () async {
        await _fetchStoryUsers();
        _fetchUserProfile();
      },
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: RepaintBoundary(child: _TopHudBar(
              now: _now, onlineUsers: onlineUsers, activeConns: activeConns,
              timezone: _timezoneLabel, onTimezoneTap: _showTimezonePicker,
              username: username, role: role, expiredDate: expiredDate,
            )),
          ),
          const SizedBox(height: 16),
          RepaintBoundary(child: _buildStoryRow()),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: RepaintBoundary(child: _NeoBanner(is3DNeo: _is3DNeo)),
          ),
          const SizedBox(height: 20),
          RepaintBoundary(child: _HudDivider(label: 'X-FAR SYSTEM')),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: RepaintBoundary(
              child: DashboardProfileCard(
                username: username, role: role, expired: expiredDate,
                profileImage: _profileImage, networkImageUrl: _networkProfileUrl,
                androidId: androidId, sessionKey: sessionKey, is3DNeo: _is3DNeo,
                clockWidget: _AnalogClock(
                  now: _now, timezoneLabel: _timezoneLabel,
                  onTap: _showTimezonePicker, is3DNeo: _is3DNeo,
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: RepaintBoundary(
              child: _XSpyderMovingButton(is3DNeo: _is3DNeo, onTap: _showXSpyderSheet),
            ),
          ),
          const SizedBox(height: 28),

          // ═══ QUICK ACTIONS GRID ═══
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _HudSectionHeader(
                title: "Quick Actions",
                subtitle: "Menu Langsung",
                badge: "${quickActions.length}",
                badgeColor: _C.neon,
              ),
              const SizedBox(height: 16),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                padding: EdgeInsets.zero,
                itemCount: quickActions.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 0.98,
                ),
                itemBuilder: (_, i) {
                  return RepaintBoundary(
                    child: _QuickGridCard(
                      data: quickActions[i],
                      is3DNeo: _is3DNeo,
                    ),
                  );
                },
              ),
            ]),
          ),
          const SizedBox(height: 28),

          // ═══ THANKS TO ═══
          if (thanksToList.isNotEmpty) ...[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                _HudSectionHeader(
                  title: "Thanks To", subtitle: "Special Credits",
                  badge: "${thanksToList.length}", badgeColor: _C.purple,
                ),
                const SizedBox(height: 16),
                SizedBox(
                  height: 145,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.only(right: 20),
                    itemCount: thanksToList.length,
                    cacheExtent: 500,
                    itemBuilder: (_, i) {
                      final item = thanksToList[i];
                      return RepaintBoundary(child: Padding(
                        padding: const EdgeInsets.only(right: 12),
                        child: _ThanksCard(
                          username: item["username"] ?? "Unknown",
                          role: item["role"] ?? "User",
                          link: item["link"] ?? "",
                          is3DNeo: _is3DNeo,
                        ),
                      ));
                    },
                  ),
                ),
              ]),
            ),
            const SizedBox(height: 28),
          ],

          // ═══ QAXER TEAM CARD ═══
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: RepaintBoundary(child: _QaxerTeamCard(is3DNeo: _is3DNeo)),
          ),
          const SizedBox(height: 40),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Stack(children: [
        Positioned.fill(child: _buildKremBackground()),
        if (_is3DNeo) ...[
          const Positioned(top: 180, left: 20, child: _XSpyderTiltedBoard(rotation: -0.35)),
          const Positioned(bottom: 280, right: 30, child: _XSpyderTiltedBoard(rotation: 0.28)),
        ],
        SafeArea(child: FadeTransition(
          opacity: _pageFade,
          child: SlideTransition(position: _pageSlide, child: _body))),
      ]),
      extendBody: true,
      bottomNavigationBar: _buildGlazeNavBar(), // ✅ Pakai GlazeNavBar 1.2.1
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      titleSpacing: 0,
      leading: Builder(
        builder: (ctx) => _MenuBtn(onTap: () => Scaffold.of(ctx).openDrawer()),
      ),
      title: Padding(
        padding: const EdgeInsets.only(left: 4),
        child: Row(children: [
          // Tombol BGM
          GestureDetector(
            onTap: () { HapticFeedback.mediumImpact(); _toggleBgm(); },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
              margin: const EdgeInsets.only(right: 10),
              decoration: BoxDecoration(
                color: _C.card,
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: _C.hud.withOpacity(0.4), width: 1),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Container(width: 20, height: 20,
                  decoration: BoxDecoration(
                    gradient: _C.hudGrad,
                    borderRadius: BorderRadius.circular(3)),
                  child: const Icon(Icons.music_note, size: 12, color: Colors.white)),
                const SizedBox(width: 8),
                const Text("BREAKBEAT",
                  style: TextStyle(color: _C.text, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                const SizedBox(width: 8),
                Row(mainAxisSize: MainAxisSize.min,
                  children: List.generate(3, (i) => AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    margin: const EdgeInsets.symmetric(horizontal: 1),
                    width: 2,
                    height: _isBgmPlaying ? (i == 1 ? 12 : 7) : 4,
                    decoration: BoxDecoration(
                      color: _C.hud,
                      borderRadius: BorderRadius.circular(1)),
                  ))),
                const SizedBox(width: 8),
                Icon(_isBgmPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                  color: _C.text, size: 16),
              ]),
            ),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('HOLLA, $username'.toUpperCase(),
                  style: const TextStyle(
                    color: _C.text, fontSize: 13, fontFamily: "Aktura",
                    fontWeight: FontWeight.w800, letterSpacing: 1.2),
                  overflow: TextOverflow.ellipsis),
                Row(children: [
                  AnimatedBuilder(
                    animation: _pulseAnim,
                    builder: (context, _) => Container(
                      width: 6, height: 6,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle, color: _C.neon,
                        boxShadow: [BoxShadow(
                          color: _C.neon.withOpacity(0.6 - (0.4 * _pulseAnim.value)),
                          blurRadius: 10)]),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(role.toUpperCase(),
                    style: TextStyle(color: _roleColor(role), fontSize: 9,
                      fontWeight: FontWeight.w900, letterSpacing: 1.5)),
                ]),
              ],
            ),
          ),
        ]),
      ),
      actions: [
        GestureDetector(
          onTap: _toggle3DNeo,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
              gradient: _is3DNeo ? _C.hudGrad : null,
              color: _is3DNeo ? null : _C.card,
              borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 4),
              border: Border.all(color: _is3DNeo ? _C.hud : _C.border, width: 1.2),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.view_in_ar_rounded,
                color: _is3DNeo ? Colors.white : _C.hud, size: 14),
              const SizedBox(width: 4),
              Text('3D', style: TextStyle(
                color: _is3DNeo ? Colors.white : _C.hud,
                fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1)),
            ]),
          ),
        ),
        _AppBarIconBtn(icon: Icons.headset_mic_outlined,
          onTap: () => Navigator.push(context, _slideRoute(const ContactPage())),
          is3DNeo: _is3DNeo),
        _AppBarIconBtn(icon: Icons.account_circle_outlined,
          onTap: () async {
            await Navigator.push(context, _slideRoute(ProfilePage(
              username: username, password: password, role: role,
              expiredDate: expiredDate, sessionKey: sessionKey)));
            _loadProfileImage();
            _fetchUserProfile();
          }, is3DNeo: _is3DNeo),
        const SizedBox(width: 8),
      ],
    );
  }

  // ✅ GLAZE NAVBAR 1.2.1 (PUTIH & BIRU)
  Widget _buildGlazeNavBar() {
    const activeWhite = Color(0xFFFFFFFF);
    
    // Map index bottom nav ke index konten
    // UI: 0=Home, 1=WA, 2=Info, 3=Tools
    // _onNavTap: 0=News, 1=Info, 2=WA, 3=Tools
    int uiIndex = 0;
    if (_navIndex == 0) uiIndex = 0;
    else if (_navIndex == 2) uiIndex = 1;
    else if (_navIndex == 1) uiIndex = 2;
    else if (_navIndex == 3) uiIndex = 3;

    return GlazeNavBar(
      index: uiIndex,
      backgroundColor: _C.bg,
      color: _C.cardAlt,
      glassBlur: 20,
      glassOpacity: 0.35,
      glassBorderRadius: 0,
      glassBorderWidth: 1.5,
      glassBorderColor: _C.border,
      // ✅ TOMBOL FLOATING PUTIH
      buttonBackgroundColor: activeWhite,
      buttonBorderColor: _C.hud,
      buttonBorderWidth: 3.0,
      buttonGradient: const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFFFFFFFF), Color(0xFFE0E0E0)],
      ),
      animationDuration: const Duration(milliseconds: 600),
      animationCurve: Curves.easeOut,
      onTap: (index) {
        if (index == 0) _onNavTap(0); // Home
        if (index == 1) _onNavTap(2); // WA
        if (index == 2) _onNavTap(1); // Info
        if (index == 3) _onNavTap(3); // Tools
      },
      items: [
        GlazeNavBarItem(
          child: Icon(
            Icons.home_rounded,
            color: uiIndex == 0 ? _C.hud : _C.textSub,
            size: 24,
          ),
          label: 'Home',
          labelStyle: TextStyle(
            color: uiIndex == 0 ? _C.hud : _C.textSub,
            fontSize: 10,
            fontWeight: FontWeight.w700,
          ),
        ),
        GlazeNavBarItem(
          child: Icon(
            FontAwesomeIcons.whatsapp,
            color: uiIndex == 1 ? _C.hud : _C.textSub,
            size: 20,
          ),
          label: 'WA',
          labelStyle: TextStyle(
            color: uiIndex == 1 ? _C.hud : _C.textSub,
            fontSize: 10,
            fontWeight: FontWeight.w700,
          ),
        ),
        GlazeNavBarItem(
          child: Icon(
            Icons.notifications_rounded,
            color: uiIndex == 2 ? _C.hud : _C.textSub,
            size: 24,
          ),
          label: 'Info',
          labelStyle: TextStyle(
            color: uiIndex == 2 ? _C.hud : _C.textSub,
            fontSize: 10,
            fontWeight: FontWeight.w700,
          ),
        ),
        GlazeNavBarItem(
          child: Icon(
            Icons.build_circle,
            color: uiIndex == 3 ? _C.hud : _C.textSub,
            size: 24,
          ),
          label: 'Tools',
          labelStyle: TextStyle(
            color: uiIndex == 3 ? _C.hud : _C.textSub,
            fontSize: 10,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }

  Widget _buildDrawer() {
  return Drawer(
    backgroundColor: Colors.transparent,
    width: MediaQuery.of(context).size.width * 0.85,
    child: Container(
      decoration: BoxDecoration(
        color: _C.card, // ✅ Background Putih
        border: Border(right: BorderSide(color: _C.border, width: 1.5)),
        boxShadow: [BoxShadow(color: _C.hud.withOpacity(0.1), blurRadius: 30, offset: const Offset(4, 0))],
      ),
      child: Column(
        children: [
          _DrawerHeader(
            username: username, 
            role: role, 
            expiredDate: expiredDate,
            profileImage: _profileImage, 
            is3DNeo: _is3DNeo,
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              children: [
                _DrawerItem(
                  icon: Icons.account_circle_outlined, 
                  label: 'My Profile', 
                  is3DNeo: _is3DNeo,
                  onTap: () { 
                    Navigator.pop(context);
                    Navigator.push(context, _slideRoute(ProfilePage(
                      username: username, password: password, role: role,
                      expiredDate: expiredDate, sessionKey: sessionKey))).then((_) {
                        _loadProfileImage(); 
                        _fetchUserProfile();
                    }); 
                  },
                ),
                const SizedBox(height: 8),
                _DrawerItem(
                  icon: Icons.card_giftcard_rounded, 
                  label: 'Ambil Benefit', 
                  is3DNeo: _is3DNeo,
                  onTap: () { 
                    Navigator.pop(context); 
                    Navigator.pushNamed(context, '/benefit'); 
                  },
                ),
                const SizedBox(height: 8),
                if (role == 'reseller')
                  _DrawerItem(
                    icon: Icons.storefront_rounded, 
                    label: 'Seller Page', 
                    is3DNeo: _is3DNeo, 
                    onTap: () => _onDrawerNav(1),
                  ),
                if (role == 'admin')
                  _DrawerItem(
                    icon: Icons.admin_panel_settings_rounded, 
                    label: 'Admin Page', 
                    is3DNeo: _is3DNeo, 
                    onTap: () => _onDrawerNav(2),
                  ),
                if (role == 'partner')
                  _DrawerItem(
                    icon: Icons.workspace_premium_rounded, 
                    label: 'Partner Page', 
                    is3DNeo: _is3DNeo, 
                    onTap: () => _onDrawerNav(3),
                  ),
                if (role == 'owner')
                  _DrawerItem(
                    icon: Icons.workspace_premium_rounded, 
                    label: 'Owner Page', 
                    is3DNeo: _is3DNeo, 
                    onTap: () => _onDrawerNav(4),
                  ),
                if (role == 'developer')
                  _DrawerItem(
                    icon: Icons.workspace_premium_rounded, 
                    label: 'Developer Page', 
                    is3DNeo: _is3DNeo, 
                    onTap: () => _onDrawerNav(5),
                  ),
                const SizedBox(height: 8),
                _DrawerItem(
                  icon: Icons.history_rounded, 
                  label: 'Riwayat Aktivitas', 
                  is3DNeo: _is3DNeo,
                  onTap: () { 
                    Navigator.pop(context);
                    Navigator.push(context, _slideRoute(RiwayatPage(sessionKey: sessionKey, role: role))); 
                  },
                ),
                const SizedBox(height: 8),
                _DrawerItem(
                  icon: Icons.lock_outline_rounded, 
                  label: 'Ubah Password', 
                  is3DNeo: _is3DNeo,
                  onTap: () { 
                    Navigator.pop(context);
                    Navigator.push(context, _slideRoute(ChangePasswordPage(username: username, sessionKey: sessionKey))); 
                  },
                ),
              ], // ✅ Penutup ListView children
            ), // ✅ Penutup ListView
          ), // ✅ Penutup Expanded
                    Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
            child: _DrawerItem(
              icon: Icons.logout_rounded, 
              label: 'Keluar',
              isDestructive: true, 
              is3DNeo: _is3DNeo,
              onTap: () async {
                Navigator.pop(context);
                await AudioManager().stop();
                final prefs = await SharedPreferences.getInstance();
                await prefs.clear();
                if (!mounted) return;
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false);
              },
            ),
          ),
        ], // Penutup Column children
      ),   // Penutup Column
    ),     // Penutup Container Drawer
  );       // Penutup return Drawer
  }        // ✅ PENUTUP METHOD _buildDrawer()
}          // ✅ PENUTUP CLASS _DashboardPageState

// ═══════════════════════════════════════════════════════════════
// TOP HUD BAR
// ═══════════════════════════════════════════════════════════════
class _TopHudBar extends StatelessWidget {
  final DateTime now;
  final int onlineUsers, activeConns;
  final String timezone, username, role, expiredDate;
  final VoidCallback onTimezoneTap;
  
  const _TopHudBar({
    required this.now, required this.onlineUsers, required this.activeConns,
    required this.timezone, required this.onTimezoneTap,
    required this.username, required this.role, required this.expiredDate,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: _C.card.withOpacity(0.85),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: _C.border, width: 1),
      ),
      child: Column(children: [
        Row(children: [
          Container(width: 10, height: 10,
            decoration: BoxDecoration(
              border: Border(
                left: BorderSide(color: _C.hud, width: 2),
                top: BorderSide(color: _C.hud, width: 2)))),
          const SizedBox(width: 10),
          Container(width: 6, height: 6,
            decoration: BoxDecoration(
              shape: BoxShape.circle, color: _C.neon,
              boxShadow: [BoxShadow(color: _C.neon.withOpacity(0.7), blurRadius: 6)])),
          const SizedBox(width: 6),
          Text("$onlineUsers ONLINE",
            style: const TextStyle(color: _C.text, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
          const SizedBox(width: 12),
          Container(width: 1, height: 10, color: _C.border),
          const SizedBox(width: 12),
          const Icon(Icons.wifi_tethering_rounded, size: 12, color: _C.hud),
          const SizedBox(width: 4),
          Text("$activeConns",
            style: const TextStyle(color: _C.text, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1)),
          const Spacer(),
          GestureDetector(
            onTap: onTimezoneTap,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: _C.cardAlt,
                borderRadius: BorderRadius.circular(3),
                border: Border.all(color: _C.border)),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.access_time_rounded, size: 10, color: _C.hud),
                const SizedBox(width: 4),
                Text(
                  "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')} $timezone",
                  style: const TextStyle(color: _C.text, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1)),
              ]),
            ),
          ),
          const SizedBox(width: 10),
          Container(width: 10, height: 10,
            decoration: BoxDecoration(
              border: Border(
                right: BorderSide(color: _C.hud, width: 2),
                top: BorderSide(color: _C.hud, width: 2)))),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: Container(height: 1,
            decoration: BoxDecoration(gradient: LinearGradient(
              colors: [_C.hud, _C.hud.withOpacity(0.0)])))),
          const SizedBox(width: 8),
          Container(width: 3, height: 3, color: _C.hud),
          const SizedBox(width: 8),
          Container(
            constraints: const BoxConstraints(maxWidth: 190),
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
            decoration: BoxDecoration(
              color: _C.cardAlt,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: _C.border),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.event_available_rounded, size: 11, color: _C.hud),
              const SizedBox(width: 5),
              Flexible(child: Text(
                'EXP: $expiredDate',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: _C.text, fontSize: 9,
                  fontWeight: FontWeight.w900, letterSpacing: 0.4),
              )),
            ]),
          ),
          const SizedBox(width: 8),
          Container(width: 3, height: 3, color: _C.hud),
          const SizedBox(width: 8),
          Expanded(child: Container(height: 1,
            decoration: BoxDecoration(gradient: LinearGradient(
              colors: [_C.hud.withOpacity(0.0), _C.hud])))),
        ]),
      ]),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// NEO BANNER
// ═══════════════════════════════════════════════════════════════
class _NeoBanner extends StatelessWidget {
  final bool is3DNeo;
  const _NeoBanner({this.is3DNeo = false});

  @override
  Widget build(BuildContext context) {
    return ClipPath(
      clipper: _CornerCutClipper(),
      child: Container(
        height: 230,
        decoration: BoxDecoration(
          color: _C.card,
          boxShadow: [
            BoxShadow(color: _C.hud.withOpacity(0.1), blurRadius: 30, spreadRadius: 2, offset: const Offset(0, 10)),
          ],
        ),
        child: Stack(fit: StackFit.expand, children: [
          Image.asset('assets/images/banner.jpg', fit: BoxFit.cover,
            cacheWidth: 1080, filterQuality: FilterQuality.low, gaplessPlayback: true,
            errorBuilder: (_, __, ___) => Container(decoration: const BoxDecoration(gradient: _C.primaryGrad))),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.white.withOpacity(0.8), Colors.transparent, _C.hud.withOpacity(0.1)],
                begin: Alignment.bottomCenter, end: Alignment.topCenter,
                stops: const [0.0, 0.5, 1.0]),
            ),
          ),
          CustomPaint(painter: _TechGridPainter(), size: Size.infinite),
          Positioned(top: 16, left: 16,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: _C.hud.withOpacity(0.1),
                border: Border.all(color: _C.hud, width: 1)),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Container(width: 6, height: 6,
                  decoration: const BoxDecoration(shape: BoxShape.circle, color: _C.neon)),
                const SizedBox(width: 6),
                const Text("LIVE FEED", style: TextStyle(
                  color: _C.hud, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.8)),
              ]),
            )),
          Positioned(top: 16, right: 16,
            child: Container(width: 24, height: 24,
              decoration: BoxDecoration(
                border: Border(
                  right: BorderSide(color: _C.hud, width: 2),
                  top: BorderSide(color: _C.hud, width: 2))))),
          Positioned(bottom: 18, left: 20, right: 20,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Container(width: 4, height: 20, color: _C.hud),
                const SizedBox(width: 10),
                const Text('X-FAR N.T.E',
                  style: TextStyle(
                    color: _C.text, fontSize: 22,
                    fontFamily: "Aktura", fontWeight: FontWeight.w900,
                    letterSpacing: 2, height: 1.1,
                    shadows: [Shadow(color: Colors.white, blurRadius: 12)])),
              ]),
              const SizedBox(height: 8),
              Text('NEXT-GEN CYBERPUNK MARKETPLACE',
                style: TextStyle(color: _C.textSub,
                  fontSize: 10, letterSpacing: 2, fontWeight: FontWeight.w700)),
            ]),
          ),
        ]),
      ),
    );
  }
}

class _CornerCutClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    const cut = 28.0;
    final path = Path();
    path.moveTo(cut, 0);
    path.lineTo(size.width - cut, 0);
    path.lineTo(size.width, cut);
    path.lineTo(size.width, size.height - cut);
    path.lineTo(size.width - cut, size.height);
    path.lineTo(cut, size.height);
    path.lineTo(0, size.height - cut);
    path.lineTo(0, cut);
    path.close();
    return path;
  }
  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}

class _TechGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = _C.hud.withOpacity(0.08)..strokeWidth = 0.7;
    const s = 30.0;
    for (double x = 0; x < size.width; x += s) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += s) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }
  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

// ═══════════════════════════════════════════════════════════════
// HUD DIVIDER
// ═══════════════════════════════════════════════════════════════
class _HudDivider extends StatelessWidget {
  final String label;
  const _HudDivider({required this.label});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(children: [
        Container(width: 8, height: 8,
          decoration: BoxDecoration(
            border: Border(
              left: BorderSide(color: _C.hud, width: 2),
              bottom: BorderSide(color: _C.hud, width: 2)))),
        const SizedBox(width: 8),
        Expanded(child: Container(height: 1,
          decoration: BoxDecoration(gradient: LinearGradient(
            colors: [_C.hud, _C.hud.withOpacity(0.0)])))),
        const SizedBox(width: 14),
        ShaderMask(
          shaderCallback: (bounds) => _C.textGrad.createShader(bounds),
          child: Text(label,
            style: const TextStyle(
              color: Colors.white, fontSize: 12,
              fontWeight: FontWeight.w900, letterSpacing: 4,
              fontFamily: 'Roboto')),
        ),
        const SizedBox(width: 14),
        Expanded(child: Container(height: 1,
          decoration: BoxDecoration(gradient: LinearGradient(
            colors: [_C.hud.withOpacity(0.0), _C.hud])))),
        const SizedBox(width: 8),
        Container(width: 8, height: 8,
          decoration: BoxDecoration(
            border: Border(
              right: BorderSide(color: _C.hud, width: 2),
              bottom: BorderSide(color: _C.hud, width: 2)))),
      ]),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// HUD SECTION HEADER
// ═══════════════════════════════════════════════════════════════
class _HudSectionHeader extends StatelessWidget {
  final String title, subtitle, badge;
  final Color badgeColor;
  const _HudSectionHeader({
    required this.title, required this.subtitle, required this.badge,
    required this.badgeColor,
  });

  @override
  Widget build(BuildContext context) {
    return Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 3, height: 22, color: _C.hud),
          const SizedBox(width: 8),
          Text(title, style: const TextStyle(
            color: _C.text, fontSize: 18,
            fontFamily: "Aktura", fontWeight: FontWeight.w900,
            letterSpacing: 2)),
        ]),
        const SizedBox(height: 6),
        Padding(
          padding: const EdgeInsets.only(left: 11),
          child: Text(subtitle.toUpperCase(),
            style: const TextStyle(color: _C.textSub, fontWeight: FontWeight.w700, fontSize: 10, letterSpacing: 1.5))),
      ]),
      const Spacer(),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: badgeColor.withOpacity(0.15),
          borderRadius: BorderRadius.circular(3),
          border: Border.all(color: badgeColor.withOpacity(0.7), width: 1.2)),
        child: Text(badge, style: TextStyle(
          color: badgeColor, fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
      ),
    ]);
  }
}

// ═══════════════════════════════════════════════════════════════
// QUICK GRID CARD
// ═══════════════════════════════════════════════════════════════
class _QuickGridCard extends StatelessWidget {
  final Map<String, dynamic> data;
  final bool is3DNeo;
  const _QuickGridCard({required this.data, this.is3DNeo = false});

  @override
  Widget build(BuildContext context) {
    final Color base = data["color"] as Color;
    final Color dark = Color.lerp(base, Colors.black, 0.55)!;

    return GestureDetector(
      onTap: data["onTap"],
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          gradient: LinearGradient(
            colors: [base, dark],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: base.withOpacity(0.35),
              blurRadius: 12,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Stack(
            children: [
              Positioned(
                right: -16, top: -16,
                child: Icon(
                  data["icon"],
                  size: 110,
                  color: Colors.white.withOpacity(0.10),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 40, height: 40,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.4),
                          width: 1.2,
                        ),
                      ),
                      child: Icon(
                        data["icon"],
                        color: Colors.white,
                        size: 22,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      data["title"],
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        height: 1.15,
                        letterSpacing: 0.2,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      data["subtitle"],
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.85),
                        fontSize: 10,
                        height: 1.2,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// STORY AVATAR ITEM
// ═══════════════════════════════════════════════════════════════
class _StoryAvatarItem extends StatelessWidget {
  final Map<String, dynamic> user;
  final String username;
  final void Function(String uname, bool hasStory) onTap;
  final VoidCallback onAddTap;

  const _StoryAvatarItem({
    required this.user, required this.username,
    required this.onTap, required this.onAddTap,
  });

  @override
  Widget build(BuildContext context) {
    final bool isMe = (user["isMe"] as bool?) ?? false;
    final bool hasStory = (user["hasStory"] as bool?) ?? false;
    final String? imageUrl = user["imageUrl"] as String?;
    final String initial = (user["initial"] as String?) ?? "";
    final String uname = (user["username"] as String?) ?? "";
    final int storyCount = (user["storyCount"] as int?) ?? 0;

    return GestureDetector(
      onTap: () => onTap(uname, hasStory),
      child: Container(
        width: 84,
        margin: const EdgeInsets.only(right: 10),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Stack(clipBehavior: Clip.none, children: [
            Container(
              width: 74, height: 74,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: (isMe && !hasStory) ? null : _C.auroraGrad,
                color: (isMe && !hasStory) ? _C.border : null,
                boxShadow: (isMe && !hasStory) ? [] : [
                  BoxShadow(color: _C.hud.withOpacity(0.45),
                    blurRadius: 14, spreadRadius: 0.5),
                ],
              ),
              padding: const EdgeInsets.all(2.5),
              child: Container(
                decoration: const BoxDecoration(shape: BoxShape.circle, color: _C.bg),
                padding: const EdgeInsets.all(2),
                child: ClipOval(
                  child: (isMe && !hasStory)
                      ? Container(color: _C.cardAlt,
                          child: const Icon(Icons.add, color: _C.hud, size: 28))
                      : imageUrl != null
                          ? CachedNetworkImage(
                              imageUrl: imageUrl, fit: BoxFit.cover,
                              memCacheWidth: 160, memCacheHeight: 160,
                              fadeInDuration: const Duration(milliseconds: 150),
                              placeholder: (_, __) => _initialBox(initial),
                              errorWidget: (_, __, ___) => _initialBox(initial))
                          : _initialBox(initial),
                ),
              ),
            ),
            if (isMe)
              Positioned(bottom: 0, right: 0,
                child: GestureDetector(
                  onTap: onAddTap,
                  child: Container(
                    width: 26, height: 26,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: _C.hudGrad,
                      border: Border.all(color: _C.bg, width: 2),
                      boxShadow: [BoxShadow(
                        color: _C.hud.withOpacity(0.6), blurRadius: 8)]),
                    child: const Icon(Icons.add, size: 16, color: Colors.white),
                  ),
                )),
            if (hasStory && storyCount > 1)
              Positioned(top: -2, right: -2,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: _C.alert,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _C.bg, width: 1.5)),
                  child: Text('$storyCount',
                    style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w900)),
                )),
          ]),
          const SizedBox(height: 8),
          Text(
            (isMe ? "CERITA SAYA" : uname).toUpperCase(),
            maxLines: 1, overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: hasStory ? _C.text : _C.textSub,
              fontSize: 9,
              letterSpacing: 0.8,
              fontWeight: hasStory ? FontWeight.w900 : FontWeight.w600),
          ),
        ]),
      ),
    );
  }

  Widget _initialBox(String initial) => Container(
    color: _C.cardAlt,
    child: Center(child: Text(initial,
      style: const TextStyle(color: _C.hud, fontSize: 22, fontWeight: FontWeight.w900))),
  );
}

// ═══════════════════════════════════════════════════════════════
// IMAGE BACKGROUND
// ═══════════════════════════════════════════════════════════════
class _ImageBackground extends StatelessWidget {
  final String assetPath;
  final bool is3DNeo;
  const _ImageBackground({required this.assetPath, this.is3DNeo = false});

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: Container(
        color: _C.bg,
        child: Stack(fit: StackFit.expand, children: [
          Image.asset(assetPath, fit: BoxFit.cover, alignment: Alignment.center,
            cacheWidth: 1080, filterQuality: FilterQuality.low, gaplessPlayback: true,
            errorBuilder: (_, __, ___) => Container(color: _C.bg,
              child: CustomPaint(painter: _KremGridPainter(), size: Size.infinite))),
          Container(color: _C.bg.withOpacity(0.85)),
          RepaintBoundary(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  colors: [_C.bg.withOpacity(0.5), Colors.transparent, _C.bg.withOpacity(0.6)],
                  stops: const [0.0, 0.5, 1.0]),
              ),
            ),
          ),
          IgnorePointer(child: RepaintBoundary(
            child: CustomPaint(painter: _KremGridPainter(), size: Size.infinite))),
          IgnorePointer(child: RepaintBoundary(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.center, radius: 1.0,
                  colors: [Colors.transparent, _C.bg.withOpacity(0.5)],
                  stops: const [0.55, 1.0]),
              ),
            ),
          )),
        ]),
      ),
    );
  }
}

class _KremGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = _C.border.withOpacity(0.15)..strokeWidth = 0.6;
    const step = 32.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
  }
  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

// ═══════════════════════════════════════════════════════════════
// X-SPYDER MOVING BUTTON
// ═══════════════════════════════════════════════════════════════
class _XSpyderMovingButton extends StatefulWidget {
  final bool is3DNeo;
  final VoidCallback onTap;
  const _XSpyderMovingButton({required this.is3DNeo, required this.onTap});
  @override
  State<_XSpyderMovingButton> createState() => _XSpyderMovingButtonState();
}

class _XSpyderMovingButtonState extends State<_XSpyderMovingButton>
    with TickerProviderStateMixin {
  late AnimationController _textCtrl, _borderCtrl, _glowCtrl;

  @override
  void initState() {
    super.initState();
    _textCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 3000))..repeat();
    _borderCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 4000))..repeat();
    _glowCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat(reverse: true);
  }

  @override
  void dispose() { _textCtrl.dispose(); _borderCtrl.dispose(); _glowCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(onTap: widget.onTap,
      child: AnimatedBuilder(
        animation: Listenable.merge([_textCtrl, _borderCtrl, _glowCtrl]),
        builder: (context, _) {
          final rotate = _borderCtrl.value;
          final glow = _glowCtrl.value;
          final textSweep = _textCtrl.value;
          return Container(
            height: 62,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6),
              boxShadow: [BoxShadow(color: _C.hud.withOpacity(0.15 + glow * 0.15),
                blurRadius: 20 + glow * 12, spreadRadius: 2, offset: const Offset(0, 6))]),
            child: Stack(children: [
              Positioned.fill(child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  gradient: SweepGradient(transform: GradientRotation(rotate * 2 * math.pi),
                    colors: const [Color(0xFF60A5FA), Color(0xFF3B82F6), Color(0xFF8B5CF6), Color(0xFF3B82F6), Color(0xFF60A5FA)],
                    stops: const [0.0, 0.25, 0.5, 0.75, 1.0])))),
              Positioned.fill(child: Container(
                margin: const EdgeInsets.all(3),
                decoration: BoxDecoration(color: _C.card,
                  borderRadius: BorderRadius.circular(4)),
                child: Center(child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Icon(Icons.security_rounded, color: _C.hud, size: 22),
                  const SizedBox(width: 12),
                  ShaderMask(
                    shaderCallback: (bounds) => LinearGradient(
                      begin: Alignment(-1.0 + textSweep * 2, 0.0),
                      end: Alignment(1.0 + textSweep * 2, 0.0),
                      colors: const [Color(0xFF8B5CF6), Color(0xFF2563EB), Color(0xFF3B82F6), Color(0xFF2563EB), Color(0xFF8B5CF6)],
                      stops: const [0.0, 0.3, 0.5, 0.7, 1.0]).createShader(bounds),
                    child: const Text('X-FAR',
                      style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900,
                        fontFamily: 'Qaxer', letterSpacing: 6,
                        shadows: [Shadow(color: Color(0xFF2563EB), blurRadius: 8)]))),
                  const SizedBox(width: 12),
                  const Icon(Icons.arrow_forward_ios_rounded, color: _C.hud, size: 14),
                ])))),
            ]),
          );
        },
      ));
  }
}

// ═══════════════════════════════════════════════════════════════
// ANALOG CLOCK
// ═══════════════════════════════════════════════════════════════
class _AnalogClock extends StatelessWidget {
  final DateTime now;
  final String timezoneLabel;
  final VoidCallback onTap;
  final bool is3DNeo;
  const _AnalogClock({required this.now, required this.timezoneLabel,
    required this.onTap, required this.is3DNeo});

  @override
  Widget build(BuildContext context) {
    const size = 78.0;
    return GestureDetector(onTap: onTap,
      child: Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: is3DNeo ? BoxShape.rectangle : BoxShape.circle,
          borderRadius: is3DNeo ? BorderRadius.circular(6) : null,
          color: _C.card,
          border: Border.all(color: _C.border, width: 2),
          boxShadow: [BoxShadow(color: _C.hud.withOpacity(0.15), blurRadius: 14, spreadRadius: 1)]),
        child: Stack(alignment: Alignment.center, children: [
          CustomPaint(size: const Size(size, size), painter: _ClockPainter(now)),
          Positioned(bottom: 4, child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
            decoration: BoxDecoration(color: _C.hud, borderRadius: BorderRadius.circular(2)),
            child: Text(timezoneLabel,
              style: const TextStyle(color: Colors.white, fontSize: 7, fontWeight: FontWeight.w900, letterSpacing: 0.8)))),
        ]),
      ));
  }
}

class _ClockPainter extends CustomPainter {
  final DateTime time;
  _ClockPainter(this.time);
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 6;
    for (int i = 1; i <= 12; i++) {
      final angle = (i * 30 - 90) * math.pi / 180;
      final x = center.dx + (radius - 10) * math.cos(angle);
      final y = center.dy + (radius - 10) * math.sin(angle);
      final tp = TextPainter(
        text: TextSpan(text: '$i', style: const TextStyle(color: _C.text, fontSize: 8, fontWeight: FontWeight.w900)),
        textDirection: TextDirection.ltr)..layout();
      tp.paint(canvas, Offset(x - tp.width / 2, y - tp.height / 2));
    }
    canvas.drawCircle(center, 3.5, Paint()..color = _C.border);
    final hourAngle = ((time.hour % 12) * 30 + time.minute * 0.5 - 90) * math.pi / 180;
    canvas.drawLine(center, Offset(center.dx + (radius * 0.5) * math.cos(hourAngle),
      center.dy + (radius * 0.5) * math.sin(hourAngle)),
      Paint()..color = _C.hud..strokeWidth = 3.5..strokeCap = StrokeCap.round);
    final minAngle = (time.minute * 6 + time.second * 0.1 - 90) * math.pi / 180;
    canvas.drawLine(center, Offset(center.dx + (radius * 0.72) * math.cos(minAngle),
      center.dy + (radius * 0.72) * math.sin(minAngle)),
      Paint()..color = _C.hud..strokeWidth = 2.2..strokeCap = StrokeCap.round);
    final secAngle = (time.second * 6 - 90) * math.pi / 180;
    canvas.drawLine(center, Offset(center.dx + (radius * 0.82) * math.cos(secAngle),
      center.dy + (radius * 0.82) * math.sin(secAngle)),
      Paint()..color = _C.alert..strokeWidth = 1..strokeCap = StrokeCap.round);
  }
  @override
  bool shouldRepaint(_ClockPainter old) => old.time.second != time.second;
}

// ═══════════════════════════════════════════════════════════════
// X-SPYDER TILTED BOARD
// ═══════════════════════════════════════════════════════════════
class _XSpyderTiltedBoard extends StatelessWidget {
  final double rotation;
  const _XSpyderTiltedBoard({required this.rotation});
  @override
  Widget build(BuildContext context) {
    return Transform.rotate(angle: rotation,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        decoration: BoxDecoration(
          color: _C.card,
          border: Border.all(color: _C.border, width: 1.8),
          boxShadow: [BoxShadow(color: _C.hud.withOpacity(0.2), offset: const Offset(3, 3), blurRadius: 0)]),
        child: const Text('X-FAR',
          style: TextStyle(color: _C.hud, fontSize: 10, fontWeight: FontWeight.w900,
            letterSpacing: 2, fontFamily: 'Qaxer'))));
  }
}

// ═══════════════════════════════════════════════════════════════
// THANKS CARD
// ═══════════════════════════════════════════════════════════════
class _ThanksCard extends StatelessWidget {
  final String username, role, link;
  final bool is3DNeo;
  const _ThanksCard({required this.username, required this.role,
    required this.link, this.is3DNeo = false});

  Future<void> _openUrl() async {
    if (link.isEmpty) return;
    await launchUrl(Uri.parse(link), mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(onTap: _openUrl,
      child: Container(
        width: 140, height: 140,
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: _C.border, width: 1.2),
          boxShadow: [BoxShadow(color: _C.purple.withOpacity(0.1), blurRadius: 16)]),
        child: Padding(padding: const EdgeInsets.all(10),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Container(width: 44, height: 44,
              decoration: BoxDecoration(
                gradient: _C.hudGrad,
                shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: _C.hud.withOpacity(0.3), blurRadius: 12)]),
              child: const Icon(Icons.person, color: Colors.white, size: 22)),
            const SizedBox(height: 8),
            Text(username.toUpperCase(), maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center,
              style: const TextStyle(color: _C.text, fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: 1)),
            const SizedBox(height: 3),
            Text(role.toUpperCase(), maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center,
              style: const TextStyle(color: _C.textSub, fontSize: 8, fontWeight: FontWeight.w700, letterSpacing: 1.5)),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: _C.hud.withOpacity(.12),
                borderRadius: BorderRadius.circular(3),
                border: Border.all(color: _C.hud.withOpacity(0.5))),
              child: const Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.open_in_new_rounded, color: _C.hud, size: 10),
                SizedBox(width: 3),
                Text("VISIT", style: TextStyle(color: _C.hud, fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: 1)),
              ])),
          ])),
      ));
  }
}

// ═══════════════════════════════════════════════════════════════
// QAXER TEAM CARD
// ═══════════════════════════════════════════════════════════════
class _QaxerTeamCard extends StatelessWidget {
  final bool is3DNeo;
  const _QaxerTeamCard({this.is3DNeo = false});

  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: _C.border, width: 1.2),
        boxShadow: [BoxShadow(color: _C.hud.withOpacity(0.1), blurRadius: 24, offset: const Offset(0, 10))]),
      child: Column(children: [
        RichText(textAlign: TextAlign.center, text: const TextSpan(children: [
          TextSpan(text: "CONNECT WITH ", style: TextStyle(color: _C.text, fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 2)),
          TextSpan(text: "X-FAR", style: TextStyle(color: _C.hud, fontSize: 16, fontWeight: FontWeight.w900, fontFamily: "Qaxer", letterSpacing: 2)),
        ])),
        const SizedBox(height: 22),
        Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          _SocialItem(icon: FontAwesomeIcons.telegram, color: const Color(0xFF29B6F6),
            title: "Telegram", is3DNeo: is3DNeo,
            onTap: () => _openUrl("https://t.me/Orgggaja")),
          _SocialItem(icon: FontAwesomeIcons.whatsapp, color: const Color(0xFF25D366),
            title: "WhatsApp", is3DNeo: is3DNeo,
            onTap: () => _openUrl("https://wa.me/81284569513")),
          _SocialItem(icon: FontAwesomeIcons.tiktok, color: _C.text,
            title: "TikTok", is3DNeo: is3DNeo,
            onTap: () => _openUrl("https://tiktok.com/xfar_zeck")),
        ]),
        const SizedBox(height: 20),
        RichText(textAlign: TextAlign.center, text: const TextSpan(children: [
          TextSpan(text: "SELALU NANTIKAN PROJECT TERBARU DARI ", style: TextStyle(color: _C.textSub, fontSize: 10, letterSpacing: 1)),
          TextSpan(text: "X-FAR N.T.E", style: TextStyle(color: _C.hud, fontSize: 10, fontFamily: "Qaxer", letterSpacing: 1)),
        ])),
      ]),
    );
  }
}

class _SocialItem extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final VoidCallback onTap;
  final bool is3DNeo;
  const _SocialItem({required this.icon, required this.color,
    required this.title, required this.onTap, this.is3DNeo = false});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(6),
      onTap: onTap,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(
          width: 72, height: 72,
          decoration: BoxDecoration(
            shape: BoxShape.rectangle,
            borderRadius: BorderRadius.circular(6),
            color: color.withOpacity(.08),
            border: Border.all(color: _C.border, width: 1.2),
            boxShadow: [BoxShadow(color: color.withOpacity(.15),
              blurRadius: 16, spreadRadius: 1)]),
          child: Center(child: FaIcon(icon, color: color, size: 30))),
        const SizedBox(height: 10),
        Text(title.toUpperCase(), style: const TextStyle(color: _C.text, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
      ]),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// MENU BUTTON
// ═══════════════════════════════════════════════════════════════
class _MenuBtn extends StatelessWidget {
  final VoidCallback onTap;
  const _MenuBtn({required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(onTap: onTap,
      child: Container(
        margin: const EdgeInsets.all(8), padding: const EdgeInsets.all(9),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: _C.border, width: 1.2),
          boxShadow: [BoxShadow(color: _C.hud.withOpacity(0.1), blurRadius: 12)]),
        child: const Icon(Icons.menu_rounded, color: _C.text, size: 20)));
  }
}

// ═══════════════════════════════════════════════════════════════
// APPBAR ICON BUTTON
// ═══════════════════════════════════════════════════════════════
class _AppBarIconBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool is3DNeo;
  const _AppBarIconBtn({required this.icon, required this.onTap, this.is3DNeo = false});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
        padding: const EdgeInsets.all(9),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: _C.border, width: 1.2),
          boxShadow: [BoxShadow(color: _C.hud.withOpacity(0.1), blurRadius: 10)]),
        child: Icon(icon, color: _C.text, size: 18)));
  }
}

// ═══════════════════════════════════════════════════════════════
// DRAWER HEADER
// ═══════════════════════════════════════════════════════════════
class _DrawerHeader extends StatefulWidget {
  final String username, role, expiredDate;
  final File? profileImage;
  final bool is3DNeo;
  const _DrawerHeader({required this.username, required this.role,
    required this.expiredDate, required this.profileImage, this.is3DNeo = false});
  @override
  State<_DrawerHeader> createState() => _DrawerHeaderState();
}

class _DrawerHeaderState extends State<_DrawerHeader>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _fade = CurvedAnimation(parent: _c, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeOutCubic));
    _c.forward();
  }

  @override
  void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final rColor = _roleColor(widget.role);
    return Container(
      height: 250, clipBehavior: Clip.hardEdge,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [rColor.withOpacity(0.15), _C.card, _C.surface]),
        border: Border(bottom: BorderSide(color: _C.border, width: 1.2))),
      child: Stack(children: [
        Positioned.fill(child: CustomPaint(painter: _StripePainter(), size: Size.infinite)),
        Positioned(top: -60, right: -60,
          child: Container(width: 200, height: 200,
            decoration: BoxDecoration(shape: BoxShape.circle,
              gradient: RadialGradient(colors: [
                rColor.withOpacity(0.35), rColor.withOpacity(0.0)])))),
        Positioned.fill(child: SafeArea(child: FadeTransition(
          opacity: _fade, child: SlideTransition(position: _slide,
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Container(width: 84, height: 84,
                decoration: BoxDecoration(
                  shape: widget.is3DNeo ? BoxShape.rectangle : BoxShape.circle,
                  borderRadius: widget.is3DNeo ? BorderRadius.circular(6) : null,
                  border: Border.all(color: rColor, width: 2.5),
                  boxShadow: [BoxShadow(color: rColor.withOpacity(0.3), blurRadius: 22, spreadRadius: 3)]),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(widget.is3DNeo ? 6 : 100),
                  child: widget.profileImage != null
                      ? Image.file(widget.profileImage!, fit: BoxFit.cover)
                      : Container(color: _C.surface,
                          child: Icon(_roleIcon(widget.role), size: 38, color: rColor)))),
              const SizedBox(height: 14),
              Text(widget.username.toUpperCase(),
                style: const TextStyle(color: _C.text, fontSize: 16,
                  fontWeight: FontWeight.w900, letterSpacing: 2)),
              const SizedBox(height: 6),
              Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: rColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(3),
                  border: Border.all(color: rColor, width: 1.2)),
                child: Text(widget.role.toUpperCase(),
                  style: TextStyle(color: rColor, fontSize: 10,
                    fontWeight: FontWeight.w900, letterSpacing: 2))),
              const SizedBox(height: 8),
                            Text('EXP: ${widget.expiredDate}',
                style: const TextStyle(
                  color: _C.text, // ✅ DIUBAH: Menjadi gelap agar terbaca di background putih
                  fontSize: 10, 
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1
                )),
            ]))))),
      ]),
    );
  }
}

class _StripePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = _C.hud.withOpacity(0.03)..strokeWidth = 1;
    for (double i = -size.height; i < size.width; i += 14) {
      canvas.drawLine(Offset(i, 0), Offset(i + size.height, size.height), p);
    }
  }
  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

// ═══════════════════════════════════════════════════════════════
// DRAWER ITEM
// ═══════════════════════════════════════════════════════════════
class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isDestructive, is3DNeo;
  final VoidCallback onTap;
  const _DrawerItem({required this.icon, required this.label,
    required this.onTap, this.isDestructive = false, this.is3DNeo = false});

  @override
  Widget build(BuildContext context) {
    final color = isDestructive ? _C.alert : _C.text; // <--- Ini yang bikin error tadi

    return Padding(padding: const EdgeInsets.only(bottom: 6),
      child: Container(
        decoration: BoxDecoration(
          color: _C.cardAlt, // Warna drawer item kamu
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: _C.border, width: 1),
        ),
        child: Material(color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(6),
            onTap: onTap,
            child: Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
              child: Row(children: [
                Container(width: 32, height: 32,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: color.withOpacity(0.35), width: 1)),
                  child: Icon(icon, color: color, size: 16)),
                const SizedBox(width: 14),
                Text(label.toUpperCase(), style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                const Spacer(),
                Icon(Icons.chevron_right_rounded, color: _C.textDim, size: 18),
              ])))),
      ));
  }
}

// ═══════════════════════════════════════════════════════════════
// NAV BUTTON (bottom nav)
// ═══════════════════════════════════════════════════════════════
class _NavButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;
  const _NavButton({super.key, required this.icon, required this.label,
    required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(borderRadius: BorderRadius.circular(8), onTap: onTap,
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          decoration: BoxDecoration(
            color: active ? _C.hud.withOpacity(0.15) : Colors.transparent,
            borderRadius: BorderRadius.circular(6),
            boxShadow: active ? [BoxShadow(color: _C.hud.withOpacity(0.3), blurRadius: 12)] : null),
          padding: const EdgeInsets.all(5),
          child: Icon(icon, size: 22, color: active ? _C.hud : _C.textSub)),
        const SizedBox(height: 4),
        Text(label, style: TextStyle(fontSize: 9,
          letterSpacing: 1.2,
          color: active ? _C.hud : _C.textSub,
          fontWeight: active ? FontWeight.w900 : FontWeight.w600)),
      ]));
  }
}

// ═══════════════════════════════════════════════════════════════
// GRAD BUTTON
// ═══════════════════════════════════════════════════════════════
class _GradBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final bool fullWidth, is3DNeo;
  const _GradBtn({required this.label, required this.onTap,
    this.fullWidth = false, this.is3DNeo = false});
  @override
  State<_GradBtn> createState() => _GradBtnState();
}

class _GradBtnState extends State<_GradBtn> {
  bool _down = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) { setState(() => _down = false); widget.onTap(); },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 46,
          width: widget.fullWidth ? double.infinity : null,
          padding: widget.fullWidth ? null : const EdgeInsets.symmetric(horizontal: 24),
          decoration: BoxDecoration(
            gradient: _C.hudGrad,
            borderRadius: BorderRadius.circular(4),
            boxShadow: _down ? []
                : [BoxShadow(color: _C.hud.withOpacity(0.3), blurRadius: 16, spreadRadius: 2, offset: const Offset(0, 4))]),
          child: Center(child: Text(widget.label.toUpperCase(),
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 2)))),
      ));
  }
}

// ═══════════════════════════════════════════════════════════════
// NEWS MEDIA
// ═══════════════════════════════════════════════════════════════
class NewsMedia extends StatelessWidget {
  final String url;
  const NewsMedia({required this.url});
  @override
  Widget build(BuildContext context) {
    return Image.network(url, fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => const SizedBox(),
      loadingBuilder: (_, child, loading) {
        if (loading == null) return child;
        return const Center(child: CircularProgressIndicator(color: _C.hud, strokeWidth: 2));
      });
  }
}

// ═══════════════════════════════════════════════════════════════
// DASHBOARD PROFILE CARD (hero card) — ✅ TANPA BLUR & TEKS TEBAL
// ═══════════════════════════════════════════════════════════════
class DashboardProfileCard extends StatefulWidget {
  final String username, role, expired, androidId, sessionKey;
  final File? profileImage;
  final String? networkImageUrl;
  final bool is3DNeo;
  final Widget? clockWidget;
  
  const DashboardProfileCard({
    super.key,
    required this.username,
    required this.role,
    required this.expired,
    this.profileImage,
    this.networkImageUrl,
    required this.androidId,
    required this.sessionKey,
    this.is3DNeo = false,
    this.clockWidget,
  });
  
  @override
  State<DashboardProfileCard> createState() => _DashboardProfileCardState();
}

class _DashboardProfileCardState extends State<DashboardProfileCard> {
  Timer? _timer;
  Timer? _deviceTimer;
  String _currentTime = '';
  int _batteryLevel = 0;
  double _ramUsage = 0.0, _storageUsage = 0.0;
  String _systemInfo = 'Loading...';
  final String _networkStatus = "Connected";

  @override
  void initState() {
    super.initState();
    _loadDeviceInfo();
    _updateTime();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) => _updateTime());
    _deviceTimer = Timer.periodic(const Duration(seconds: 10), (t) {
      if (mounted) _loadDeviceInfo();
    });
  }

  void _updateTime() {
    if (!mounted) return;
    final now = DateTime.now();
    setState(() {
      _currentTime =
          "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}";
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _deviceTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadDeviceInfo() async {
    try {
      final battery = Battery();
      final batteryLevel = await battery.batteryLevel;
      final androidInfo = await DeviceInfoPlugin().androidInfo;
      final totalRam = SysInfo.getTotalPhysicalMemory();
      final freeRam = SysInfo.getFreePhysicalMemory();
      final usedRam = totalRam - freeRam;
      final ramUsage = totalRam > 0 ? usedRam / totalRam : 0.0;
      final totalStorage = SysInfo.getTotalStorage();
      final freeStorage = SysInfo.getFreeStorage();
      final usedStorage = totalStorage - freeStorage;
      final storageUsage = totalStorage > 0 ? usedStorage / totalStorage : 0.0;
      
      if (!mounted) return;
      setState(() {
        _batteryLevel = batteryLevel;
        _ramUsage = ramUsage.clamp(0.0, 1.0);
        _storageUsage = storageUsage.clamp(0.0, 1.0);
        _systemInfo = '${androidInfo.model} (API ${androidInfo.version.sdkInt})';
      });
    } catch (e) {
      debugPrint('Failed to load device info: $e');
    }
  }

  // ✅ TEKS INFO BAR (BATTERY, RAM, STORAGE) DIBIKIN TEBAL & HITAM
  Widget _buildInfoBar(String label, String value, double progress, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              label,
              style: const TextStyle(
                color: Color(0xFF0F172A), 
                fontSize: 10,
                fontFamily: "ready",
                letterSpacing: 1.5,
                fontWeight: FontWeight.w900, 
                shadows: [Shadow(color: Colors.white, blurRadius: 4)], 
              ),
            ),
            Text(
              value.toUpperCase(),
              style: const TextStyle(
                color: Color(0xFF0F172A), 
                fontSize: 11,
                fontWeight: FontWeight.w900, 
                fontFamily: "ready",
                letterSpacing: 1,
                shadows: [Shadow(color: Colors.white, blurRadius: 4)],
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(2),
          child: LinearProgressIndicator(
            value: progress,
            backgroundColor: Colors.white.withOpacity(0.5), 
            valueColor: AlwaysStoppedAnimation<Color>(color),
            minHeight: 5,
          ),
        ),
      ],
    );
  }

  // ✅ TEKS INFO TILE (DEVICE ID, NETWORK, DLL) DIBIKIN TEBAL & HITAM
  Widget _buildInfoTile(String label, String value, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: const Color(0xFF0F172A), size: 14), 
        const SizedBox(width: 8),
        Text(
          label.toUpperCase(),
          style: const TextStyle(
            color: Color(0xFF0F172A), 
            fontSize: 10,
            fontFamily: "ready",
            letterSpacing: 1.5,
            fontWeight: FontWeight.w900, 
            shadows: [Shadow(color: Colors.white, blurRadius: 4)],
          ),
        ),
        const Spacer(),
        Flexible(
          child: Text(
            value,
            style: const TextStyle(
              color: Color(0xFF0F172A), 
              fontSize: 11,
              fontWeight: FontWeight.w900, 
              fontFamily: "ready",
              letterSpacing: 0.5,
              shadows: [Shadow(color: Colors.white, blurRadius: 4)],
            ),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final ramPct = (_ramUsage * 100).toInt();
    
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: _C.border, width: 1.2),
        boxShadow: [
          BoxShadow(
            color: _C.hud.withOpacity(0.1),
            blurRadius: 24,
            spreadRadius: 1,
          )
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: Stack(
          children: [
            // 1. Background Gambar Res.jpg
            Positioned.fill(
              child: Image.asset(
                'assets/images/res.jpg',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(color: _C.card),
              ),
            ),
            
            // 2. OVERLAY PUTIH TRANSPARAN (TANPA BLUR)
            Positioned.fill(
              child: Container(
                color: Colors.white.withOpacity(0.15), 
              ),
            ),
            
            // 3. Konten Asli Card
            Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Foto Profil
                      Container(
                        width: 68,
                        height: 68,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: _C.hud, width: 2.5),
                          boxShadow: [
                            BoxShadow(
                              color: _C.hud.withOpacity(.3),
                              blurRadius: 16,
                            )
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(100),
                          child: widget.profileImage != null
                              ? Image.file(widget.profileImage!, fit: BoxFit.cover)
                              : widget.networkImageUrl != null && widget.networkImageUrl!.isNotEmpty
                                  ? CachedNetworkImage(
                                      imageUrl: widget.networkImageUrl!,
                                      fit: BoxFit.cover,
                                      memCacheWidth: 200,
                                      memCacheHeight: 200,
                                      placeholder: (_, __) => Container(
                                        color: _C.surface,
                                        child: const Icon(Icons.person, color: _C.hud, size: 34),
                                      ),
                                      errorWidget: (_, __, ___) => Container(
                                        color: _C.surface,
                                        child: const Icon(Icons.person, color: _C.hud, size: 34),
                                      ),
                                    )
                                  : Container(
                                      color: _C.surface,
                                      child: const Icon(Icons.person, color: _C.hud, size: 34),
                                    ),
                        ),
                      ),
                      const SizedBox(width: 14),
                      
                      // Teks Nama & Role
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "SELAMAT DATANG",
                              style: TextStyle(
                                color: Color(0xFF0F172A), 
                                fontFamily: "ready",
                                fontSize: 10,
                                letterSpacing: 1.5,
                                fontWeight: FontWeight.w900, 
                                shadows: [Shadow(color: Colors.white, blurRadius: 4)],
                              ),
                            ),
                            const SizedBox(height: 3),
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Flexible(
                                  child: Text(
                                    widget.username.toUpperCase(),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: Color(0xFF0F172A), 
                                      fontWeight: FontWeight.w900, 
                                      fontFamily: "Aktura",
                                      fontSize: 20, 
                                      letterSpacing: 1.5,
                                      shadows: [Shadow(color: Colors.white, blurRadius: 6)],
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Transform.translate(
                                  offset: const Offset(0, -3),
                                  child: const VerifiedBadge(size: 18),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: _C.hud.withOpacity(.12),
                                borderRadius: BorderRadius.circular(3),
                                border: Border.all(color: _C.hud.withOpacity(0.6), width: 1.2),
                              ),
                              child: Text(
                                widget.role.toUpperCase(),
                                style: const TextStyle(
                                  color: Color(0xFF2563EB), 
                                  fontSize: 10,
                                  fontWeight: FontWeight.w900, 
                                  letterSpacing: 2,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (widget.clockWidget != null) widget.clockWidget!,
                    ],
                  ),
                  const SizedBox(height: 20),
                  const Divider(color: Colors.white54, height: 1),
                  const SizedBox(height: 20),
                  
                  _buildInfoBar("BATTERY", "$_batteryLevel%", _batteryLevel / 100, _C.neon),
                  const SizedBox(height: 12),
                  _buildInfoBar("RAM MEMORY", "$ramPct% USAGE", _ramUsage, _C.hud),
                  const SizedBox(height: 12),
                  _buildInfoBar("STORAGE", "${(_storageUsage * 100).toInt()}% USAGE", _storageUsage, _C.warn),
                  
                  const SizedBox(height: 20),
                  const Divider(color: Colors.white54, height: 1),
                  const SizedBox(height: 16),
                  
                  _buildInfoTile("Device ID", widget.androidId, Icons.phone_android_rounded),
                  const SizedBox(height: 10),
                  _buildInfoTile("Network", _networkStatus, Icons.wifi_rounded),
                  const SizedBox(height: 10),
                  _buildInfoTile("System", _systemInfo, Icons.system_update_alt_rounded),
                  const SizedBox(height: 10),
                  _buildInfoTile("Session Key", "${widget.sessionKey.substring(0, 8)}********", Icons.vpn_key_rounded),
                  const SizedBox(height: 10),
                  _buildInfoTile("Time", _currentTime, Icons.timer_rounded),
                  
                  const SizedBox(height: 20),
                  
                  // Footer
                  Container(
                    height: 38,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.3), 
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(color: Colors.white54, width: 1),
                    ),
                    child: Center(
                      child: RichText(
                        textAlign: TextAlign.center,
                        text: const TextSpan(
                          children: [
                            TextSpan(
                              text: "● POWERED BY ",
                              style: TextStyle(
                                color: Color(0xFF0F172A),
                                fontWeight: FontWeight.w900,
                                fontSize: 10,
                                letterSpacing: 1.5,
                              ),
                            ),
                            TextSpan(
                              text: "X-FAR",
                              style: TextStyle(
                                color: Color(0xFF2563EB),
                                fontWeight: FontWeight.w900,
                                fontSize: 10,
                                letterSpacing: 1.5,
                                fontFamily: "Qaxer",
                              ),
                            ),
                            TextSpan(
                              text: " ●",
                              style: TextStyle(
                                color: Color(0xFF0F172A),
                                fontWeight: FontWeight.w900,
                                fontSize: 10,
                                letterSpacing: 1.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// VERIFIED BADGE
// ═══════════════════════════════════════════════════════════════
class VerifiedBadge extends StatelessWidget {
  final double size;
  final Color color;
  const VerifiedBadge({super.key, this.size = 18, this.color = const Color(0xFF2563EB)});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle, color: color,
        boxShadow: [BoxShadow(color: color.withOpacity(0.6), blurRadius: 10, spreadRadius: 1)]),
      child: Icon(Icons.check_rounded, color: Colors.white, size: size * 0.72));
  }
}

// ═══════════════════════════════════════════════════════════════
// STORY ITEM (model)
// ═══════════════════════════════════════════════════════════════
class StoryItem {
  final String id;
  final String username;
  final String mediaUrl;
  final String mediaType;
  final String caption;
  final String createdAt;
  StoryItem({
    required this.id, required this.username, required this.mediaUrl,
    required this.mediaType, required this.caption, required this.createdAt,
  });
  factory StoryItem.fromJson(Map<String, dynamic> json) {
    final raw = (json['media_url'] ?? json['mediaUrl'] ?? '').toString();
    return StoryItem(
      id: (json['id'] ?? json['story_id'] ?? '').toString(),
      username: (json['username'] ?? '').toString(),
      mediaUrl: raw.startsWith('/') ? '$_baseUrl$raw' : raw,
      mediaType: (json['media_type'] ?? json['mediaType'] ?? 'image').toString(),
      caption: (json['caption'] ?? '').toString(),
      createdAt: (json['created_at'] ?? json['createdAt'] ?? '').toString(),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// STORY VIEWER
// ═══════════════════════════════════════════════════════════════
class StoryViewer extends StatefulWidget {
  final List<StoryItem> stories;
  final int startIndex;
  final String sessionKey;
  final String currentUser;
  final Future<void> Function(String storyId)? onDelete;
  const StoryViewer({
    super.key, required this.stories, required this.startIndex,
    required this.sessionKey, required this.currentUser, this.onDelete,
  });

  @override
  State<StoryViewer> createState() => _StoryViewerState();
}

class _StoryViewerState extends State<StoryViewer>
    with SingleTickerProviderStateMixin {
  late int _index;
  late AnimationController _progressCtrl;

  @override
  void initState() {
    super.initState();
    _index = widget.startIndex;
    _progressCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 5));
    _progressCtrl.forward();
    _progressCtrl.addStatusListener((st) {
      if (st == AnimationStatus.completed) _next();
    });
  }

  @override
  void dispose() { _progressCtrl.dispose(); super.dispose(); }

  void _next() {
    if (_index < widget.stories.length - 1) {
      setState(() => _index++);
      _progressCtrl.reset();
      _progressCtrl.forward();
    } else {
      Navigator.pop(context);
    }
  }

  void _prev() {
    if (_index > 0) {
      setState(() => _index--);
      _progressCtrl.reset();
      _progressCtrl.forward();
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.stories[_index];
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [
        Positioned.fill(
          child: GestureDetector(
            onTapUp: (d) {
              final w = MediaQuery.of(context).size.width;
              if (d.localPosition.dx < w / 2) { _prev(); } else { _next(); }
            },
            child: s.mediaType == 'video'
                ? Container(
                    color: Colors.black,
                    child: const Center(child: Icon(Icons.play_circle_fill,
                      color: Colors.white, size: 80)))
                : CachedNetworkImage(
                    imageUrl: s.mediaUrl, fit: BoxFit.contain,
                    placeholder: (_, __) => const Center(
                      child: CircularProgressIndicator(color: _C.hud)),
                    errorWidget: (_, __, ___) => const Center(
                      child: Icon(Icons.broken_image, color: Colors.white, size: 60))),
          ),
        ),
        Positioned(top: 44, left: 12, right: 12, child: Row(
          children: List.generate(widget.stories.length, (i) => Expanded(
            child: Container(
              height: 3, margin: const EdgeInsets.symmetric(horizontal: 2),
              decoration: BoxDecoration(
                color: Colors.white24, borderRadius: BorderRadius.circular(2)),
              child: i == _index
                  ? AnimatedBuilder(
                      animation: _progressCtrl,
                      builder: (_, __) => FractionallySizedBox(
                        alignment: Alignment.centerLeft,
                        widthFactor: _progressCtrl.value,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(2)),
                        ),
                      ),
                    )
                  : i < _index
                      ? Container(color: Colors.white)
                      : null,
            ),
          )),
        )),
        Positioned(top: 56, left: 16, right: 16, child: Row(children: [
          Container(width: 34, height: 34,
            decoration: const BoxDecoration(
              shape: BoxShape.circle, color: _C.card),
            child: const Icon(Icons.person, color: _C.hud, size: 18)),
          const SizedBox(width: 10),
          Expanded(child: Text(s.username,
            maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white,
              fontWeight: FontWeight.w800, fontSize: 14))),
          IconButton(
            icon: const Icon(Icons.close, color: Colors.white),
            onPressed: () => Navigator.pop(context)),
        ])),
        if (s.caption.isNotEmpty)
          Positioned(bottom: 60, left: 20, right: 20,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.5),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(s.caption,
                style: const TextStyle(color: Colors.white, fontSize: 14)),
            )),
        if (widget.onDelete != null && s.username == widget.currentUser)
          Positioned(bottom: 20, right: 20,
            child: GestureDetector(
              onTap: () async {
                await widget.onDelete!(s.id);
                if (!mounted) return;
                Navigator.pop(context);
              },
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _C.alert.withOpacity(0.9),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.delete_outline, color: Colors.white, size: 20),
              ),
            )),
      ]),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// HONEYCOMB PAINTER
// ═══════════════════════════════════════════════════════════════
class HoneycombPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = _C.border.withOpacity(.1)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    const r = 24.0;
    final h = math.sqrt(3) * r;
    for (double y = 0; y < size.height + h; y += h) {
      for (double x = 0; x < size.width + r; x += r * 3) {
        final dx = ((y ~/ h).isEven) ? x : x + r * 1.5;
        final path = Path();
        for (int i = 0; i < 6; i++) {
          final angle = (60 * i - 30) * math.pi / 180;
          final px = dx + r * math.cos(angle);
          final py = y + r * math.sin(angle);
          if (i == 0) path.moveTo(px, py); else path.lineTo(px, py);
        }
        path.close();
        canvas.drawPath(path, paint);
      }
    }
  }
  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

// ═══════════════════════════════════════════════════════════════
// BOTTOM NAV CLIPPER (optional)
// ═══════════════════════════════════════════════════════════════
class BottomNavClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.moveTo(24, 0);
    path.lineTo(size.width - 24, 0);
    path.lineTo(size.width, 24);
    path.lineTo(size.width, size.height - 24);
    path.lineTo(size.width - 24, size.height);
    path.lineTo(24, size.height);
    path.lineTo(0, size.height - 24);
    path.lineTo(0, 24);
    path.close();
    return path;
  }
  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}