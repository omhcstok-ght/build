import 'package:shared_preferences/shared_preferences.dart';

class SessionHelper {
  /// Coba ambil session key dari beberapa kemungkinan nama key
  static Future<String> getSessionKey() async {
    final prefs = await SharedPreferences.getInstance();

    // ⭐ Cek berbagai kemungkinan nama key yang umum
    const possibleKeys = [
      'sessionKey',
      'session_key',
      'key',
      'userKey',
      'user_key',
      'FionaKey',
      'fiona_key',
      'token',
      'authKey',
    ];

    for (final k in possibleKeys) {
      final val = prefs.getString(k);
      if (val != null && val.isNotEmpty) {
        return val;
      }
    }

    return '';
  }

  /// Ambil username
  static Future<String> getUsername() async {
    final prefs = await SharedPreferences.getInstance();
    const possibleKeys = ['username', 'user', 'userName', 'FionaUser'];
    for (final k in possibleKeys) {
      final val = prefs.getString(k);
      if (val != null && val.isNotEmpty) return val;
    }
    return '';
  }

  /// Ambil role
  static Future<String> getRole() async {
    final prefs = await SharedPreferences.getInstance();
    const possibleKeys = ['role', 'userRole', 'user_role'];
    for (final k in possibleKeys) {
      final val = prefs.getString(k);
      if (val != null && val.isNotEmpty) return val;
    }
    return 'member';
  }

  /// Debug: print semua key yang tersimpan
  static Future<void> debugPrintAll() async {
    final prefs = await SharedPreferences.getInstance();
    final keys = prefs.getKeys();
    print('═══════════════════════════════════');
    print('📦 SharedPreferences Keys:');
    for (final k in keys) {
      print('  $k = ${prefs.get(k)}');
    }
    print('═══════════════════════════════════');
  }
}