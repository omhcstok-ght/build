import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart'; // TAMBAHAN
import 'package:device_info_plus/device_info_plus.dart';      // TAMBAHAN
import 'dart:convert';

// ─── LIGHT PALETTE ────────────────────────────────
class _C {
  static const bg        = Color(0xFFF5F9FF);
  static const surface   = Color(0xFFFFFFFF);
  static const card      = Color(0xFFFFFFFF);
  static const border    = Color(0xFFD6E4F5);
  static const primary   = Color(0xFF2563EB);
  static const primaryLight = Color(0xFF3B82F6);
  static const accent    = Color(0xFF0EA5E9);
  static const emerald   = Color(0xFF10B981);
  static const gold      = Color(0xFFF59E0B);
  static const rose      = Color(0xFFEF4444);
  static const text      = Color(0xFF0F172A);
  static const textSub   = Color(0xFF475569);
  static const textDim   = Color(0xFF94A3B8);

  static const LinearGradient luxeGrad = LinearGradient(
    colors: [Color(0xFF60A5FA), Color(0xFF3B82F6), Color(0xFF2563EB)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class FreeTrialPage extends StatefulWidget {
  const FreeTrialPage({super.key});

  @override
  State<FreeTrialPage> createState() => _FreeTrialPageState();
}

class _FreeTrialPageState extends State<FreeTrialPage>
    with SingleTickerProviderStateMixin {
  final _usernameCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool _isLoading = false;
  bool _isCheckingStatus = true; // TAMBAHAN
  bool _hasClaimed = false;      // TAMBAHAN
  bool _obscurePass = true;
  
  String? _resultUser;
  String? _resultPass;
  String? _expiresAt;
  String? _errorMsg;
  String? _androidId; // TAMBAHAN

  late AnimationController _glowCtrl;
  late Animation<double> _glow;

  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);
    _glow = Tween<double>(begin: 0.3, end: 0.8).animate(
      CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOutSine),
    );

    _initData(); // Panggil fungsi inisialisasi
  }

  // 🔥 FUNGSI BARU: Cek status klaim & ambil Device ID
  Future<void> _initData() async {
    // 1. Ambil Android ID
    try {
      final androidInfo = await DeviceInfoPlugin().androidInfo;
      _androidId = androidInfo.id;
    } catch (_) {
      _androidId = null;
    }

    // 2. Cek apakah sudah pernah klaim
    final prefs = await SharedPreferences.getInstance();
    final hasClaimed = prefs.getBool('has_claimed_free_trial') ?? false;
    final savedUser = prefs.getString('trial_username');
    final savedPass = prefs.getString('trial_password');
    final savedExp = prefs.getString('trial_expires');

    if (mounted) {
      setState(() {
        _hasClaimed = hasClaimed;
        if (hasClaimed && savedUser != null) {
          _resultUser = savedUser;
          _resultPass = savedPass;
          _expiresAt = savedExp;
        }
        _isCheckingStatus = false;
      });
    }
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    _usernameCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  Future<void> _createFreeAccount() async {
    if (!_formKey.currentState!.validate()) return;
    if (_hasClaimed) return;

    setState(() {
      _isLoading = true;
      _errorMsg = null;
    });

    try {
      const apiUrl = 'http://swight.rexypediaa.my.id:4737/api/free-trial';

      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': _usernameCtrl.text.trim(),
          'password': _passwordCtrl.text.trim(),
          'duration_hours': 3,
          'androidId': _androidId, // 🔥 KIRIM DEVICE ID KE BACKEND
        }),
      ).timeout(const Duration(seconds: 20));

      final data = jsonDecode(response.body);

      if (response.statusCode == 200 || response.statusCode == 201) {
        final newUser = data['username'] ?? _usernameCtrl.text.trim();
        final newPass = data['password'] ?? _passwordCtrl.text.trim();
        final newExp = data['expires_at'] ?? '3 jam dari sekarang';

        // 🔥 SIMPAN STATUS KE SHARED PREFERENCES
        final prefs = await SharedPreferences.getInstance();
        await prefs.setBool('has_claimed_free_trial', true);
        await prefs.setString('trial_username', newUser);
        await prefs.setString('trial_password', newPass);
        await prefs.setString('trial_expires', newExp);

        setState(() {
          _resultUser = newUser;
          _resultPass = newPass;
          _expiresAt = newExp;
          _isLoading = false;
          _hasClaimed = true;
        });
      } else {
        setState(() {
          _errorMsg = data['message'] ?? 'Gagal membuat akun (${response.statusCode})';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMsg = 'Koneksi gagal: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  void _copyToClipboard(String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$label disalin!', style: const TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: _C.emerald,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        backgroundColor: _C.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _C.text, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'FREE TRIAL 3H',
          style: TextStyle(
            color: _C.text,
            fontSize: 16,
            fontWeight: FontWeight.w900,
            fontFamily: 'Aktura',
            letterSpacing: 2,
          ),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: _isCheckingStatus
            ? const Center(child: CircularProgressIndicator(color: _C.primary))
            : SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.all(20),
                child: _hasClaimed ? _buildAlreadyClaimedView() : _buildFormView(),
              ),
      ),
    );
  }

  // ==========================================
  // TAMPILAN JIKA SUDAH PERNAH KLAIM
  // ==========================================
  Widget _buildAlreadyClaimedView() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: _C.rose.withOpacity(0.3), width: 1.5),
            boxShadow: [
              BoxShadow(color: _C.rose.withOpacity(0.08), blurRadius: 25, offset: const Offset(0, 8)),
            ],
          ),
          child: Column(
            children: [
              Container(
                width: 70, height: 70,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _C.rose.withOpacity(0.1),
                ),
                child: const Icon(Icons.gpp_bad_rounded, color: _C.rose, size: 34),
              ),
              const SizedBox(height: 16),
              const Text(
                'AKSES DITOLAK',
                style: TextStyle(
                  color: _C.text,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Aktura',
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Anda sudah pernah membuat akun Free Trial di perangkat ini. Setiap perangkat hanya diperbolehkan membuat 1 akun.',
                textAlign: TextAlign.center,
                style: TextStyle(color: _C.textSub, fontSize: 12, height: 1.5, fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        if (_resultUser != null) ...[
          const Text(
            'AKUN ANDA SEBELUMNYA:',
            style: TextStyle(color: _C.textSub, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.5),
          ),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: _C.emerald.withOpacity(0.05),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: _C.emerald.withOpacity(0.4), width: 1.5),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildResultRow('Username', _resultUser!),
                const SizedBox(height: 10),
                _buildResultRow('Password', _resultPass!),
                const SizedBox(height: 10),
                _buildResultRow('Berlaku Hingga', _expiresAt!),
              ],
            ),
          ),
        ],
        const SizedBox(height: 30),
        _buildLoginNowButton(),
      ],
    );
  }

  // ==========================================
  // TAMPILAN FORM ASLI
  // ==========================================
  Widget _buildFormView() {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: _C.card,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: _C.emerald.withOpacity(0.4), width: 1.5),
              boxShadow: [
                BoxShadow(color: _C.emerald.withOpacity(0.1), blurRadius: 25, offset: const Offset(0, 8)),
              ],
            ),
            child: Column(
              children: [
                AnimatedBuilder(
                  animation: _glow,
                  builder: (_, __) => Container(
                    width: 70, height: 70,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _C.emerald.withOpacity(0.1),
                      border: Border.all(color: _C.emerald.withOpacity(_glow.value), width: 2),
                      boxShadow: [
                        BoxShadow(color: _C.emerald.withOpacity(_glow.value * 0.2), blurRadius: 30, spreadRadius: 2),
                      ],
                    ),
                    child: const Icon(Icons.card_giftcard_rounded, color: _C.emerald, size: 34),
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'AKUN GRATIS 3 HARI',
                  style: TextStyle(color: _C.text, fontSize: 20, fontWeight: FontWeight.w900, fontFamily: 'Aktura', letterSpacing: 2),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Coba semua fitur premium gratis selama 3 hari.\nTanpa kartu kredit. Tanpa komitmen.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: _C.textSub, fontSize: 12, height: 1.5, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          _buildLabel('USERNAME'),
          const SizedBox(height: 8),
          _buildTextField(
            controller: _usernameCtrl,
            hint: 'Masukkan username',
            icon: Icons.person_outline_rounded,
            validator: (v) {
              if (v == null || v.trim().isEmpty) return 'Username wajib diisi';
              if (v.trim().length < 3) return 'Minimal 3 karakter';
              return null;
            },
          ),
          const SizedBox(height: 18),
          _buildLabel('PASSWORD'),
          const SizedBox(height: 8),
          _buildTextField(
            controller: _passwordCtrl,
            hint: 'Masukkan password',
            icon: Icons.lock_outline_rounded,
            obscure: _obscurePass,
            suffix: IconButton(
              icon: Icon(_obscurePass ? Icons.visibility_off_rounded : Icons.visibility_rounded, color: _C.textDim, size: 20),
              onPressed: () => setState(() => _obscurePass = !_obscurePass),
            ),
            validator: (v) {
              if (v == null || v.trim().isEmpty) return 'Password wajib diisi';
              if (v.trim().length < 4) return 'Minimal 4 karakter';
              return null;
            },
          ),
          const SizedBox(height: 24),
          if (_errorMsg != null) ...[
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _C.rose.withOpacity(0.08),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _C.rose.withOpacity(0.4), width: 1.5),
              ),
              child: Row(
                children: [
                  const Icon(Icons.error_outline_rounded, color: _C.rose, size: 20),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(_errorMsg!, style: const TextStyle(color: _C.rose, fontSize: 12, fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
          ],
          _buildSubmitButton(),
        ],
      ),
    );
  }

  Widget _buildLabel(String text) {
    return Text(
      text,
      style: const TextStyle(color: _C.textSub, fontSize: 11, fontWeight: FontWeight.w900, fontFamily: 'Aktura', letterSpacing: 1.5),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool obscure = false,
    Widget? suffix,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      obscureText: obscure,
      validator: validator,
      style: const TextStyle(color: _C.text, fontSize: 14, fontWeight: FontWeight.w600),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: _C.textDim, fontSize: 13),
        prefixIcon: Icon(icon, color: _C.textSub, size: 20),
        suffixIcon: suffix,
        filled: true,
        fillColor: _C.bg,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: _C.border, width: 1.5)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: _C.border, width: 1.5)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: _C.primaryLight, width: 2)),
        errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: _C.rose, width: 1.5)),
        focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: _C.rose, width: 2)),
        errorStyle: const TextStyle(color: _C.rose, fontSize: 11),
      ),
    );
  }

  Widget _buildResultRow(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: _C.bg,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _C.border, width: 1),
      ),
      child: Row(
        children: [
          Text('$label:', style: const TextStyle(color: _C.textSub, fontSize: 11, fontWeight: FontWeight.w800)),
          const SizedBox(width: 10),
          Expanded(
            child: Text(value, style: const TextStyle(color: _C.text, fontSize: 13, fontWeight: FontWeight.w900, fontFamily: 'Ready')),
          ),
          GestureDetector(
            onTap: () => _copyToClipboard(value, label),
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: _C.emerald.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _C.emerald.withOpacity(0.3), width: 1),
              ),
              child: const Icon(Icons.copy_rounded, color: _C.emerald, size: 14),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSubmitButton() {
    return SizedBox(
      width: double.infinity,
      height: 58,
      child: ElevatedButton(
        onPressed: _isLoading ? null : _createFreeAccount,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          padding: EdgeInsets.zero,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
        child: Ink(
          decoration: BoxDecoration(
            gradient: _C.luxeGrad,
            borderRadius: BorderRadius.circular(18),
            boxShadow: [BoxShadow(color: _C.primary.withOpacity(0.3), blurRadius: 25, offset: const Offset(0, 8))],
          ),
          child: Center(
            child: _isLoading
                ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 22),
                      SizedBox(width: 12),
                      Text('BUAT AKUN GRATIS', style: TextStyle(color: Colors.white, fontSize: 16, fontFamily: 'Aktura', fontWeight: FontWeight.w900, letterSpacing: 1.5)),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  Widget _buildLoginNowButton() {
    return SizedBox(
      width: double.infinity,
      height: 58,
      child: ElevatedButton(
        onPressed: () {
          Navigator.pop(context);
          // Sesuaikan route login aplikasi Anda
          // Navigator.pushNamed(context, '/login');
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: _C.card,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
            side: const BorderSide(color: _C.emerald, width: 2),
          ),
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.login_rounded, color: _C.emerald, size: 22),
            SizedBox(width: 12),
            Text('KEMBALI KE LOGIN', style: TextStyle(color: _C.text, fontSize: 16, fontFamily: 'Aktura', fontWeight: FontWeight.w900, letterSpacing: 1.5)),
          ],
        ),
      ),
    );
  }
}