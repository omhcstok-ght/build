import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:Fiona/Qaxer/.dart';

final _baseUrl = Api.api;

// ═══════════════════════════════════════════════════════════════════
// LIGHT CYBER PALETTE
// ═══════════════════════════════════════════════════════════════════
class _C {
  static const bg        = Color(0xFFF5F9FF);
  static const surface   = Color(0xFFFFFFFF);
  static const card      = Color(0xFFFFFFFF);
  static const cardAlt   = Color(0xFFEFF6FF);

  static const border    = Color(0xFFD6E4F5);
  static const borderLit = Color(0xFFB6CDE8);

  static const accent1   = Color(0xFF2563EB);
  static const accent2   = Color(0xFF1D4ED8);
  static const accent3   = Color(0xFF1E40AF);
  static const cyan      = Color(0xFF0EA5E9);
  static const emerald   = Color(0xFF10B981);
  static const amber     = Color(0xFFF59E0B);
  static const rose      = Color(0xFFEF4444);

  static const cardPurple = Color(0xFF8B5CF6);
  static const cardGreen  = Color(0xFF10B981);
  static const cardPink   = Color(0xFFEC4899);

  static const text      = Color(0xFF0F172A);
  static const textSub   = Color(0xFF475569);
  static const textDim   = Color(0xFF94A3B8);

  static const LinearGradient primaryGrad = LinearGradient(
    colors: [Color(0xFF60A5FA), Color(0xFF3B82F6), Color(0xFF2563EB)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient btnGrad = LinearGradient(
    colors: [Color(0xFF3B82F6), Color(0xFF2563EB)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient cardGrad = LinearGradient(
    colors: [Color(0xFFFFFFFF), Color(0xFFF1F6FF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class _QuotaConfig {
  static const int maxPerDay = 5;
  static const Duration resetWindow = Duration(hours: 24);
}

// ═══════════════════════════════════════════════════════════════════
// HOME PAGE
// ═══════════════════════════════════════════════════════════════════
class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGroup;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.listBugGroup,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetCtrl = TextEditingController();
  final loopCtrl = TextEditingController();
  final codeCtrl = TextEditingController();

  late final PageController _modeController;
  int _currentPage = 0;

  String selectedBugId = '';
  String _bugMode = 'number';
  String _senderType = 'private';
  bool _isSending = false;
  String? _responseMsg;

  List<String> _globalSenders = [];
  bool _isLoadingSenders = false;
  bool _modeSelected = false;

  bool _is3DNeo = false;

  String _countryCode = '+62';
  String _countryFlag = '🇮🇩';

  int _globalQuotaUsed = 0;
  DateTime? _globalQuotaResetAt;
  bool _quotaLoaded = false;

  double _animatedQuotaValue = 0.0;
  int _displayedQuotaRemaining = 0;

  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _sendBtnCtrl;

  late AnimationController _cardFloatCtrl;
  late Animation<double> _cardFloatAnim;

  late Animation<double> _entrance;
  late Animation<double> _sendPulse;
  late Animation<double> _sendGlow;

  bool get canAccessGlobalSender {
    final r = widget.role.toLowerCase();
    return r == 'owner' || r == 'admin' || r == 'moderator' || r == 'partner' || r == 'developer' || r == 'vip';
  }

  int get _globalQuotaRemaining {
    final rem = _QuotaConfig.maxPerDay - _globalQuotaUsed;
    return rem < 0 ? 0 : rem;
  }

  bool get _globalQuotaEmpty => _globalQuotaRemaining <= 0;

  Duration get _timeUntilReset {
    if (_globalQuotaResetAt == null) return Duration.zero;
    final diff = _globalQuotaResetAt!.difference(DateTime.now());
    return diff.isNegative ? Duration.zero : diff;
  }

  String _formatRemainingTime() {
    final d = _timeUntilReset;
    if (d == Duration.zero) return 'sebentar';
    final hours = d.inHours;
    final mins = d.inMinutes % 60;
    if (hours > 0) return '${hours}j ${mins}m';
    return '${mins}m ${d.inSeconds % 60}s';
  }

  @override
  void initState() {
    super.initState();
    _updateSelectedBug();
    _modeController = PageController();

    _bgCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 16))..repeat();

    _entranceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _entrance = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic);

    _sendBtnCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..repeat(reverse: true);
    _sendPulse = Tween<double>(begin: 1.0, end: 1.04).animate(CurvedAnimation(parent: _sendBtnCtrl, curve: Curves.easeInOut));
    _sendGlow = Tween<double>(begin: 0.3, end: 0.6).animate(CurvedAnimation(parent: _sendBtnCtrl, curve: Curves.easeInOut));

    _cardFloatCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat(reverse: true);
    _cardFloatAnim = Tween<double>(begin: -5.0, end: 5.0).animate(
      CurvedAnimation(parent: _cardFloatCtrl, curve: Curves.easeInOut),
    );

    _entranceCtrl.forward();
    _loadGlobalSenders();
    _loadQuota();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _sendBtnCtrl.dispose();
    _cardFloatCtrl.dispose();
    targetCtrl.dispose();
    loopCtrl.dispose();
    codeCtrl.dispose();
    _modeController.dispose();
    super.dispose();
  }

  String get _quotaKey => 'global_quota_${widget.username}';

  Future<void> _animateQuotaTo(int targetRemaining) async {
    if (!mounted) return;
    final max = _QuotaConfig.maxPerDay;
    final double startValue = _animatedQuotaValue;
    final double endValue   = (max - targetRemaining) / max;
    final int startRemaining = _displayedQuotaRemaining;
    final int endRemaining   = targetRemaining;

    const totalSteps  = 30;
    const stepDuration = Duration(milliseconds: 35);

    for (int i = 1; i <= totalSteps; i++) {
      if (!mounted) return;
      final t = i / totalSteps;
      final eased = Curves.easeInOutCubic.transform(t);
      final newVal = startValue + (endValue - startValue) * eased;
      final newRem = (startRemaining + (endRemaining - startRemaining) * eased).round();

      setState(() {
        _animatedQuotaValue = newVal.clamp(0.0, 1.0);
        _displayedQuotaRemaining = newRem;
      });
      await Future.delayed(stepDuration);
    }
  }

  Future<void> _loadQuota() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_quotaKey);
      if (raw == null) {
        _globalQuotaUsed = 0; _globalQuotaResetAt = null; _quotaLoaded = true;
        if (mounted) setState(() {});
        _animateQuotaTo(_QuotaConfig.maxPerDay);
        return;
      }
      final data = jsonDecode(raw) as Map<String, dynamic>;
      final used = (data['used'] ?? 0) as int;
      final resetAtStr = data['resetAt'] as String?;
      final resetAt = resetAtStr != null ? DateTime.tryParse(resetAtStr) : null;

      if (resetAt != null && DateTime.now().isAfter(resetAt)) {
        _globalQuotaUsed = 0; _globalQuotaResetAt = null; await prefs.remove(_quotaKey);
      } else {
        _globalQuotaUsed = used; _globalQuotaResetAt = resetAt;
      }
      _quotaLoaded = true;
      if (mounted) setState(() {});
      _animateQuotaTo(_globalQuotaRemaining);
    } catch (e) {
      _globalQuotaUsed = 0; _globalQuotaResetAt = null; _quotaLoaded = true;
      if (mounted) setState(() {});
      _animateQuotaTo(_QuotaConfig.maxPerDay);
    }
  }

  Future<bool> _useQuota() async {
    if (_globalQuotaResetAt == null) _globalQuotaResetAt = DateTime.now().add(_QuotaConfig.resetWindow);
    if (DateTime.now().isAfter(_globalQuotaResetAt!)) {
      _globalQuotaUsed = 0; _globalQuotaResetAt = DateTime.now().add(_QuotaConfig.resetWindow);
    }
    if (_globalQuotaUsed >= _QuotaConfig.maxPerDay) return false;
    
    _globalQuotaUsed += 1;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_quotaKey, jsonEncode({'used': _globalQuotaUsed, 'resetAt': _globalQuotaResetAt!.toIso8601String()}));
    } catch (_) {}
    if (mounted) setState(() {});
    _animateQuotaTo(_globalQuotaRemaining);
    return true;
  }

  Future<void> _loadGlobalSenders() async {
    setState(() => _isLoadingSenders = true);
    try {
      final res = await http.get(Uri.parse('$_baseUrl/getActiveSenders?key=${widget.sessionKey}')).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['senders'] != null) {
        if (mounted) setState(() => _globalSenders = List<String>.from(data['senders']));
      } else {
        if (mounted) setState(() => _globalSenders = []);
      }
    } catch (_) {
      if (mounted) setState(() => _globalSenders = []);
    } finally {
      if (mounted) setState(() => _isLoadingSenders = false);
    }
  }

  Future<void> _sendBug() async {
    final rawInput = targetCtrl.text.trim();
    final key = widget.sessionKey;

    if (rawInput.isEmpty) {
      _showAlert('Input Kosong', 'Target tidak boleh kosong.');
      return;
    }

    setState(() { _isSending = true; _responseMsg = null; });

    try {
      String finalTarget = rawInput;
      if (_bugMode == 'number' && !rawInput.startsWith('+')) {
        final cleanNum = rawInput.replaceAll(RegExp(r'\D'), '');
        finalTarget = '$_countryCode$cleanNum';
      }

      if (_bugMode == 'number') {
        if (formatPhone(finalTarget) == null) { _showAlert('Nomor Tidak Valid', 'Gunakan format internasional.'); return; }
      } else {
        if (!isValidGroupLink(finalTarget)) { _showAlert('Link Tidak Valid', 'Masukkan link grup WhatsApp yang valid.'); return; }
      }

      if (_senderType == 'global' && !canAccessGlobalSender) { _showAlert('Akses Ditolak', 'Sender Global hanya untuk VIP!'); return; }
      if (selectedBugId.isEmpty) { _showAlert('Pilih Bug', 'Silakan pilih bug terlebih dahulu.'); return; }

      final bool isGlobalSender = _senderType == 'global';
      if (isGlobalSender) {
        if (_globalQuotaEmpty) { _showAlert('Jatah Global Habis', 'Reset dalam: ${_formatRemainingTime()}'); return; }
        final ok = await _useQuota();
        if (!ok) { _showAlert('Jatah Global Habis', 'Reset dalam: ${_formatRemainingTime()}'); return; }
      }

      final encodedTarget = Uri.encodeComponent(finalTarget);
      final url = Uri.parse('$_baseUrl/sendBug?key=$key&target=$encodedTarget&bug=$selectedBugId${isGlobalSender ? '&senderMode=global' : ''}');

      final res = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      final bugs = _bugMode == 'group' ? widget.listBugGroup : widget.listBug;
      final selectedBug = bugs.firstWhere((b) => b['bug_id'] == selectedBugId, orElse: () => {'bug_name': 'Bug'});
      final bugName = selectedBug['bug_name'] ?? 'Bug';

      if (data['valid'] == false) {
        if (isGlobalSender) await _refundQuota();
        _setResponse('error', 'Session key tidak valid.');
      } else if (data['cooldown'] == true) {
        if (isGlobalSender) await _refundQuota();
        _setResponse('warning', 'Cooldown aktif! Tunggu ${data['wait']} detik lagi.');
      } else if (data['sended'] == true) {
        final label = _bugMode == 'group' ? 'grup target' : finalTarget;
        
        if (isGlobalSender) {
          _setResponse('success', 'Bug $bugName send to $label\n(Global Sisa: ${_globalQuotaRemaining}/${_QuotaConfig.maxPerDay})');
        } else {
          _setResponse('success', 'Bug $bugName send to $label');
        }
        targetCtrl.clear();
      } else {
        if (isGlobalSender) await _refundQuota();
        _setResponse('error', 'Gagal mengirim. Server maintenance.');
      }
    } on Exception catch (e) {
      if (_senderType == 'global') await _refundQuota();
      _setResponse('error', 'Koneksi error. Periksa jaringan.');
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  Future<void> _refundQuota() async {
    if (_globalQuotaUsed > 0) {
      _globalQuotaUsed -= 1;
      try {
        final prefs = await SharedPreferences.getInstance();
        if (_globalQuotaResetAt != null) {
          await prefs.setString(_quotaKey, jsonEncode({'used': _globalQuotaUsed, 'resetAt': _globalQuotaResetAt!.toIso8601String()}));
        }
      } catch (_) {}
      if (mounted) setState(() {});
      _animateQuotaTo(_globalQuotaRemaining);
    }
  }

  void _updateSelectedBug() {
    final bugs = _bugMode == 'group' ? widget.listBugGroup : widget.listBug;
    if (bugs.isNotEmpty) {
      selectedBugId = bugs.first['bug_id'];
    } else {
      selectedBugId = '';
    }
  }

  void _setResponse(String type, String msg) {
    if (!mounted) return;
    setState(() => _responseMsg = '$type|$msg');
  }

  String? formatPhone(String s) {
    final c = s.replaceAll(RegExp(r'[^\d+]'), '');
    return (c.startsWith('+') && c.length >= 8) ? c : null;
  }

  bool isValidGroupLink(String s) => s.startsWith('https://') && s.contains('chat.whatsapp.com');

  void _showAlert(String title, String msg) {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black.withOpacity(0.4),
      transitionDuration: const Duration(milliseconds: 350),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: Tween<double>(begin: 0.85, end: 1.0).animate(
          CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        ),
        child: FadeTransition(
          opacity: Tween<double>(begin: 0, end: 1.0).animate(
            CurvedAnimation(parent: anim, curve: Curves.easeOut),
          ),
          child: child,
        ),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.rose.withOpacity(0.5), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: _C.rose.withOpacity(0.15),
                blurRadius: 30,
                spreadRadius: 4,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: _C.cardAlt,
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(19)),
                  border: Border(
                    bottom: BorderSide(color: _C.rose.withOpacity(0.3), width: 1),
                  ),
                ),
                child: Row(
                  children: [
                    _dot(const Color(0xFFFF5F57)),
                    const SizedBox(width: 6),
                    _dot(const Color(0xFFFFBD2E)),
                    const SizedBox(width: 6),
                    _dot(const Color(0xFF28C840)),
                    const Spacer(),
                    Icon(Icons.warning_amber_rounded, color: _C.rose, size: 16),
                    const SizedBox(width: 6),
                    Text(
                      'ALERT',
                      style: TextStyle(
                        color: _C.rose,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 60, height: 60,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _C.card,
                        border: Border.all(color: _C.rose.withOpacity(0.8), width: 1.5),
                        boxShadow: [
                          BoxShadow(
                            color: _C.rose.withOpacity(0.2), 
                            blurRadius: 20,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: const Icon(Icons.warning_amber_rounded, color: _C.rose, size: 30),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      title,
                      style: const TextStyle(color: _C.text, fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: -0.5),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      msg, 
                      textAlign: TextAlign.center, 
                      style: const TextStyle(color: _C.textSub, fontSize: 13.5, height: 1.5),
                    ),
                    const SizedBox(height: 24),
                    _GradBtn(
                      label: 'OK', 
                      fullWidth: true, 
                      is3DNeo: _is3DNeo,
                      onTap: () => Navigator.pop(ctx),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _dot(Color c) {
    return Container(
      width: 8, height: 8,
      decoration: BoxDecoration(shape: BoxShape.circle, color: c, boxShadow: [BoxShadow(color: c.withOpacity(0.5), blurRadius: 4)]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFFF5F9FF), Color(0xFFEAF2FF)],
                ),
              ),
            ),
          ),
          SafeArea(
            child: FadeTransition(
              opacity: _entrance,
              child: Column(
                children: [
                  _buildAppBar(),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: EdgeInsets.fromLTRB(_modeSelected ? 14 : 0, 0, _modeSelected ? 14 : 0, _modeSelected ? 20 : 16),
                      child: Column(
                        children: [
                          AnimatedSwitcher(
                            duration: const Duration(milliseconds: 500),
                            child: !_modeSelected
                                ? Column(
                                    key: const ValueKey("sliders_view"),
                                    children: [
                                      _buildImageBanner(),
                                      const SizedBox(height: 10),
                                      Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: _buildImageSliderMenu()),
                                      const SizedBox(height: 10),
                                      Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: _buildInfoCard()),
                                    ],
                                  )
                                : Column(
                                    key: const ValueKey("menu_form"),
                                    children: [
                                      _buildHeroCard(),
                                      const SizedBox(height: 16),
                                      Align(
                                        alignment: Alignment.centerLeft,
                                        child: TextButton.icon(
                                          onPressed: () => setState(() => _modeSelected = false),
                                          style: TextButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4)),
                                          icon: const Icon(Icons.arrow_back_ios_new, color: _C.accent1, size: 14),
                                          label: const Text("Kembali", style: TextStyle(color: _C.accent1, fontWeight: FontWeight.w800, fontSize: 12)),
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      _buildTargetInput(),
                                      const SizedBox(height: 12),
                                      if (_bugMode == 'testfunc') ...[
                                        _buildLoopInput(),
                                        const SizedBox(height: 12),
                                        _buildCodeInput(),
                                      ] else ...[
                                        _buildBugSelector(),
                                        const SizedBox(height: 12),
                                        _buildSenderCard(),
                                      ],
                                      const SizedBox(height: 20),
                                      _buildSendButton(),
                                      if (_responseMsg != null) ...[
                                        const SizedBox(height: 12),
                                        _buildResultBanner(),
                                      ],
                                    ],
                                  ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(4, 6, 8, 6),
      child: Row(
        children: [
          IconButton(icon: const Icon(Icons.menu_rounded, color: _C.text, size: 24), onPressed: () {}),
          const Spacer(),
          IconButton(icon: const Icon(Icons.headset_mic_outlined, color: _C.text, size: 22), onPressed: () {}),
          IconButton(icon: const Icon(Icons.music_note_outlined, color: _C.text, size: 22), onPressed: () {}),
          IconButton(icon: const Icon(Icons.notifications_none_rounded, color: _C.text, size: 22), onPressed: () {}),
          IconButton(icon: const Icon(Icons.logout_rounded, color: _C.text, size: 22), onPressed: () {}),
        ],
      ),
    );
  }

  Widget _buildImageBanner() {
    return Container(
      width: double.infinity,
      height: 170,
      child: ClipRRect(
        borderRadius: BorderRadius.zero,
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset('assets/images/banner.jpg', fit: BoxFit.cover, alignment: Alignment.topCenter),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.transparent, Colors.white.withOpacity(0.1), Colors.white.withOpacity(0.85)],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  stops: const [0.0, 0.55, 1.0],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(color: _C.emerald, shape: BoxShape.circle),
                        child: const Icon(FontAwesomeIcons.whatsapp, color: Colors.white, size: 16),
                      ),
                      const SizedBox(width: 8),
                      const Text(
                        'X-FAR 𝑴𝑬𝑵𝑼',
                        style: TextStyle(
                          color: _C.text, fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 1.5,
                          shadows: [Shadow(color: Colors.white, blurRadius: 10)],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Pilih menu yang tersedia bosque!',
                    style: TextStyle(color: _C.textSub, fontSize: 12, shadows: [Shadow(color: Colors.white, blurRadius: 8)]),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImageSliderMenu() {
    return Column(
      children: [
        SizedBox(
          height: MediaQuery.of(context).size.height * 0.36,
          child: PageView(
            controller: _modeController,
            onPageChanged: (index) => setState(() => _currentPage = index),
            children: [
              _buildFeaturedCard(
                title: "X-FAR 𝑩𝑼𝑮", subtitle: "Bug Tanpa Custom", buttonText: "𝑩𝑼𝑲𝑨 X-FAR 𝑩𝑼𝑮",
                icon: Icons.bug_report_rounded, color: _C.cardPurple,
                onPressed: () => setState(() { _bugMode = "number"; targetCtrl.clear(); _updateSelectedBug(); _modeSelected = true; }),
              ),
              _buildFeaturedCard(
                title: "BUG GROUP", subtitle: "Kirim Bug ke Grup WhatsApp", buttonText: "BUKA BUG GROUP",
                icon: Icons.groups_rounded, color: _C.cardGreen,
                onPressed: () => setState(() { _bugMode = "group"; _senderType = 'private'; targetCtrl.clear(); _updateSelectedBug(); _modeSelected = true; }),
              ),
              _buildFeaturedCard(
                title: "TEST FUNCTION", subtitle: "Eksekusi Custom JS Code", buttonText: "BUKA TEST FUNC",
                icon: Icons.code_rounded, color: _C.cardPink,
                onPressed: () => setState(() { _bugMode = "testfunc"; targetCtrl.clear(); loopCtrl.clear(); codeCtrl.clear(); _modeSelected = true; }),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        SmoothPageIndicator(
          controller: _modeController,
          count: 3,
          effect: WormEffect(
            activeDotColor: _currentPage == 0 ? _C.cardPurple : _currentPage == 1 ? _C.cardGreen : _C.cardPink,
            dotColor: _C.borderLit, dotHeight: 7, dotWidth: 7,
          ),
        ),
      ],
    );
  }

  Widget _buildFeaturedCard({
    required String title, required String subtitle, required String buttonText,
    required IconData icon, required Color color, required VoidCallback onPressed,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 24),
        border: Border.all(color: color.withOpacity(0.3), width: 1.5),
        boxShadow: [BoxShadow(color: color.withOpacity(0.12), blurRadius: 22, spreadRadius: 1)],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: color.withOpacity(0.5), width: 1),
            ),
            child: Text("RECOMMENDED", style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
          ),
          const SizedBox(height: 12),
          
          AnimatedBuilder(
            animation: _cardFloatAnim,
            builder: (context, child) {
              return Transform.translate(
                offset: Offset(0, _cardFloatAnim.value),
                child: child,
              );
            },
            child: Container(
              width: 64, height: 64,
              decoration: BoxDecoration(
                shape: BoxShape.circle, color: color.withOpacity(0.12),
                border: Border.all(color: color.withOpacity(0.4), width: 1.5),
                boxShadow: [BoxShadow(color: color.withOpacity(0.3), blurRadius: 20)],
              ),
              child: Icon(icon, color: color, size: 30),
            ),
          ),

          const SizedBox(height: 14),
          Text(title, style: const TextStyle(color: _C.text, fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 1)),
          const SizedBox(height: 4),
          Text(subtitle, style: const TextStyle(color: _C.textSub, fontSize: 12)),
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: onPressed,
            style: OutlinedButton.styleFrom(
              side: BorderSide(color: color.withOpacity(0.5), width: 1.5),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              backgroundColor: color.withOpacity(0.06),
            ),
            icon: Text(buttonText, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 13)),
            label: Icon(Icons.arrow_forward_rounded, color: color, size: 16),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _C.borderLit, width: 1.2),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: _C.accent1.withOpacity(0.1), shape: BoxShape.circle),
            child: const Icon(Icons.verified_rounded, color: _C.accent1, size: 18),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Semua Bug 100% real work, no gimmick!", style: TextStyle(color: _C.text, fontSize: 12, fontWeight: FontWeight.bold)),
                SizedBox(height: 2),
                Text("• X-FAR N.T.E", style: TextStyle(color: _C.textSub, fontSize: 10)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroCard() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: _C.cardGrad,
        border: Border.all(color: _C.accent1.withOpacity(0.3), width: 1.2),
        boxShadow: [BoxShadow(color: _C.accent1.withOpacity(0.08), blurRadius: 20, spreadRadius: 1)],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(
              color: _C.cardAlt,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
              border: Border(bottom: BorderSide(color: _C.accent1.withOpacity(0.25), width: 1)),
            ),
            child: Row(
              children: [
                _dot(const Color(0xFFFF5F57)),
                const SizedBox(width: 5),
                _dot(const Color(0xFFFFBD2E)),
                const SizedBox(width: 5),
                _dot(const Color(0xFF28C840)),
                const SizedBox(width: 10),
                const Icon(Icons.shield_moon_outlined, color: _C.accent1, size: 11),
                const SizedBox(width: 5),
                const Text('SECURE_SESSION', style: TextStyle(color: _C.textSub, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.2, fontFamily: 'monospace')),
                const Spacer(),
                Container(width: 6, height: 6, decoration: BoxDecoration(shape: BoxShape.circle, color: _C.emerald, boxShadow: [BoxShadow(color: _C.emerald, blurRadius: 5)])),
                const SizedBox(width: 5),
                Text('ONLINE', style: TextStyle(color: _C.emerald, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1, fontFamily: 'monospace')),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox(width: 64, height: 64, child: CustomPaint(painter: _CyberFramePainter(color: _C.accent1))),
                    Container(
                      width: 48, height: 48,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle, color: _C.cardAlt,
                        border: Border.all(color: _C.accent1.withOpacity(0.5), width: 1.5),
                        boxShadow: [BoxShadow(color: _C.accent1.withOpacity(0.25), blurRadius: 12)],
                      ),
                      child: const Icon(Icons.person_rounded, color: _C.accent1, size: 24),
                    ),
                  ],
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('// OPERATOR', style: TextStyle(color: _C.textDim, fontSize: 8.5, fontWeight: FontWeight.w700, letterSpacing: 1.5, fontFamily: 'monospace')),
                      const SizedBox(height: 2),
                      Text(widget.username, style: const TextStyle(color: _C.text, fontWeight: FontWeight.w900, fontSize: 18, letterSpacing: 0.3)),
                      const SizedBox(height: 5),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: _C.accent1.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(4),
                          border: Border.all(color: _C.accent1.withOpacity(0.5), width: 1),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.verified_user_rounded, color: _C.accent1, size: 9),
                            const SizedBox(width: 4),
                            Text(widget.role.toUpperCase(), style: const TextStyle(color: _C.accent1, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  decoration: BoxDecoration(color: _C.cardAlt, borderRadius: BorderRadius.circular(8), border: Border.all(color: _C.borderLit, width: 1)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text('EXPIRES', style: TextStyle(color: _C.textDim, fontSize: 8, fontWeight: FontWeight.w700, letterSpacing: 1, fontFamily: 'monospace')),
                      const SizedBox(height: 2),
                      Row(
                        children: [
                          Icon(Icons.schedule_rounded, color: _C.accent1, size: 10),
                          const SizedBox(width: 4),
                          Text(widget.expiredDate, style: const TextStyle(color: _C.text, fontWeight: FontWeight.w900, fontSize: 10, fontFamily: 'monospace')),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTargetInput() {
    if (_bugMode == 'number' || _bugMode == 'testfunc') {
      return _InputSection(
        icon: Icons.phone_android_rounded,
        label: _bugMode == 'testfunc' ? 'TARGET_NODE' : 'TARGET_NUMBER',
        is3DNeo: _is3DNeo,
        child: _CountryPhoneInput(
          controller: targetCtrl,
          countryCode: _countryCode,
          countryFlag: _countryFlag,
          onCountryTap: _showCountryPicker,
          is3DNeo: _is3DNeo,
        ),
      );
    }
    return _InputSection(
      icon: Icons.link_rounded,
      label: 'GROUP_URL',
      is3DNeo: _is3DNeo,
      child: _BugInput(
        controller: targetCtrl,
        hint: OmhcSilenceProtect.decode(["nW4Opsj","2DSWASu","U3beqV3","CSR2Sr5","BHnu+A1","ywk8="]),
        keyboardType: TextInputType.url,
        icon: Icons.link_rounded,
        is3DNeo: _is3DNeo,
      ),
    );
  }

  void _showCountryPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.vertical(top: Radius.circular(_is3DNeo ? 0 : 24)),
          border: Border.all(color: _C.accent1.withOpacity(0.3), width: 1.5),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 40, height: 4, decoration: BoxDecoration(color: _C.accent1, borderRadius: BorderRadius.circular(2))),
            const SizedBox(height: 16),
            _countryOption('🇮🇩', '+62', 'Indonesia'),
            _countryOption('🇲🇾', '+60', 'Malaysia'),
            _countryOption('🇸🇬', '+65', 'Singapore'),
            _countryOption('🇹🇭', '+66', 'Thailand'),
          ],
        ),
      ),
    );
  }

  Widget _countryOption(String flag, String code, String name) {
    final active = _countryCode == code;
    return GestureDetector(
      onTap: () {
        Navigator.pop(context);
        setState(() { _countryFlag = flag; _countryCode = code; });
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: active ? _C.accent1.withOpacity(0.08) : _C.cardAlt,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: active ? _C.accent1 : _C.border, width: 1.2),
        ),
        child: Row(
          children: [
            Text(flag, style: const TextStyle(fontSize: 22)),
            const SizedBox(width: 12),
            Expanded(child: Text(name, style: const TextStyle(color: _C.text, fontSize: 14, fontWeight: FontWeight.w700))),
            Text(code, style: const TextStyle(color: _C.accent1, fontSize: 14, fontWeight: FontWeight.w900, fontFamily: 'monospace')),
          ],
        ),
      ),
    );
  }

  Widget _buildLoopInput() {
    return _InputSection(
      icon: Icons.repeat_rounded,
      label: 'LOOP_COUNT',
      is3DNeo: _is3DNeo,
      child: _BugInput(
        controller: loopCtrl,
        hint: '10',
        keyboardType: TextInputType.number,
        icon: Icons.repeat_rounded,
        is3DNeo: _is3DNeo,
      ),
    );
  }

  Widget _buildCodeInput() {
    return _InputSection(
      icon: Icons.code_rounded,
      label: 'FUNCTION_CODE',
      is3DNeo: _is3DNeo,
      child: Container(
        decoration: BoxDecoration(color: _C.cardAlt, borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.accent1.withOpacity(0.3), width: 1.2)),
        padding: const EdgeInsets.all(12),
        child: TextField(
          controller: codeCtrl,
          maxLines: 6,
          style: const TextStyle(color: _C.text, fontSize: 11.5, fontFamily: 'monospace'),
          decoration: const InputDecoration(
            hintText: 'async function myFunc(sock, target) {}',
            hintStyle: TextStyle(color: _C.textDim, fontSize: 11.5), // ✅ SUDAH DIPERBAIKI
            border: InputBorder.none,
          ),
        ),
      ),
    );
  }

  // =========================================================================
  // 🟢 BUG SELECTOR (3D ZIG-ZAG) - FIXED TANPA PAGEVIEW (ANTI BLANK)
  // =========================================================================
  Widget _buildBugSelector() {
    final allBugs = _bugMode == "group" ? widget.listBugGroup : widget.listBug;
    final bool isGlobalSender = _senderType == 'global';
    
    // ✅ PENGAMAN: Pastikan data tidak null
    final List<Map<String, dynamic>> safeBugs = List<Map<String, dynamic>>.from(allBugs ?? []);

    final List<Map<String, dynamic>> bugs = isGlobalSender
        ? safeBugs.where((bug) {
            final name = (bug["bug_name"] ?? '').toString().toLowerCase().replaceAll(' ', '');
            final id = (bug["bug_id"] ?? '').toString().toLowerCase();
            return name.contains('delayultimate') || (name.contains('delay') && name.contains('ultimate')) || id.contains('delayultimate') || (id.contains('delay') && id.contains('ultimate'));
          }).toList()
        : safeBugs;

    final Color modeColor = _bugMode == "group" ? _C.cardGreen : _C.cardPurple;
    final List<Map<String, dynamic>> displayBugs = bugs.isEmpty ? safeBugs : bugs;

    if (isGlobalSender && bugs.isNotEmpty) {
      final firstGlobal = bugs.first["bug_id"];
      if (selectedBugId != firstGlobal) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) setState(() => selectedBugId = firstGlobal);
        });
      }
    }

    return Container(
      decoration: BoxDecoration(
        gradient: _C.cardGrad,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: modeColor.withOpacity(0.35), width: 1.2),
        boxShadow: [BoxShadow(color: modeColor.withOpacity(0.08), blurRadius: 18)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: _C.cardAlt,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
              border: Border(bottom: BorderSide(color: modeColor.withOpacity(0.25), width: 1)),
            ),
            child: Row(
              children: [
                _dot(const Color(0xFFFF5F57)),
                const SizedBox(width: 5),
                _dot(const Color(0xFFFFBD2E)),
                const SizedBox(width: 5),
                _dot(const Color(0xFF28C840)),
                const SizedBox(width: 10),
                Icon(Icons.bug_report_rounded, color: modeColor, size: 12),
                const SizedBox(width: 6),
                Text(
                  isGlobalSender ? 'BUG_SELECTOR // GLOBAL' : 'BUG_SELECTOR',
                  style: TextStyle(color: modeColor, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.5, fontFamily: 'monospace'),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: modeColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(3),
                    border: Border.all(color: modeColor.withOpacity(0.4), width: 1),
                  ),
                  child: Text(
                    '${displayBugs.length} BUGS',
                    style: TextStyle(color: modeColor, fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: 1, fontFamily: 'monospace'),
                  ),
                ),
              ],
            ),
          ),

          if (isGlobalSender)
            Container(
              margin: const EdgeInsets.fromLTRB(12, 12, 12, 0),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: _C.amber.withOpacity(0.08),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: _C.amber.withOpacity(0.3), width: 1),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.lock_rounded, color: _C.amber, size: 11),
                  const SizedBox(width: 6),
                  Text(
                    'GLOBAL: cuma Delayultimate yang tersedia',
                    style: TextStyle(color: _C.amber, fontSize: 10, fontWeight: FontWeight.w800, fontFamily: 'monospace'),
                  ),
                ],
              ),
            ),

          // ✅ MENGGUNAKAN LISTVIEW AGAR ANTI BLANK & BISA DIGESER
          Padding(
            padding: const EdgeInsets.only(top: 15, bottom: 25),
            child: SizedBox(
              height: 150,
              child: displayBugs.isEmpty
                  ? Center(child: Text('// no bugs available', style: TextStyle(color: _C.textDim, fontSize: 11, fontFamily: 'monospace')))
                  : ListView.builder(
                      scrollDirection: Axis.horizontal,
                      physics: const BouncingScrollPhysics(),
                      itemCount: displayBugs.length,
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      itemBuilder: (context, index) {
                        final bug = displayBugs[index];
                        final selected = selectedBugId == bug["bug_id"];

                        // ✅ Logika Zig-Zag: index genap miring kanan, ganjil miring kiri
                        final isEven = index % 2 == 0;
                        final double baseRotateY = isEven ? 0.08 : -0.08;
                        final double selectedRotateY = isEven ? 0.15 : -0.15;

                        return GestureDetector(
                          onTap: () => setState(() => selectedBugId = bug["bug_id"]),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 350),
                            curve: Curves.easeOutBack,
                            width: selected ? 160 : 135,
                            margin: EdgeInsets.only(
                              left: 6, 
                              right: 6,
                              top: selected ? 0 : 10,
                              bottom: selected ? 0 : 10,
                            ),
                            transform: Matrix4.identity()
                              ..setEntry(3, 2, 0.001)
                              ..scale(selected ? 1.05 : 0.95)
                              ..rotateY(selected ? selectedRotateY : baseRotateY),
                            transformAlignment: Alignment.center,
                            child: Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: selected ? modeColor.withOpacity(0.1) : Colors.white,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(
                                  color: selected ? modeColor : _C.borderLit, 
                                  width: selected ? 2.5 : 1.2
                                ),
                                boxShadow: selected 
                                  ? [BoxShadow(color: modeColor.withOpacity(0.4), blurRadius: 20, spreadRadius: 2)]
                                  : [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 6)],
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Icon(Icons.security_rounded, color: selected ? modeColor : _C.accent1, size: selected ? 24 : 18),
                                      const Spacer(),
                                      if (selected) Icon(Icons.check_circle_rounded, color: modeColor, size: 18),
                                    ],
                                  ),
                                  const Spacer(),
                                  Text(
                                    '${(index + 1).toString().padLeft(2, '0')}',
                                    style: TextStyle(
                                      color: selected ? modeColor : _C.textDim, 
                                      fontSize: selected ? 12 : 9,
                                      fontWeight: FontWeight.w900, fontFamily: 'monospace'
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    bug["bug_name"] ?? "Unknown",
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      color: selected ? modeColor : _C.text, 
                                      fontSize: selected ? 15 : 12,
                                      fontWeight: FontWeight.w900, height: 1.15
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ),
        ],
      ),
    );
  }
  // =========================================================================

  Widget _buildSenderCard() {
    final isGroupMode = _bugMode == 'group';
    return Container(
      decoration: BoxDecoration(
        gradient: _C.cardGrad,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _C.accent1.withOpacity(0.3), width: 1.2),
        boxShadow: [BoxShadow(color: _C.accent1.withOpacity(0.06), blurRadius: 18)],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: _C.cardAlt,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
              border: Border(bottom: BorderSide(color: _C.accent1.withOpacity(0.25), width: 1)),
            ),
            child: Row(
              children: [
                _dot(const Color(0xFFFF5F57)),
                const SizedBox(width: 5),
                _dot(const Color(0xFFFFBD2E)),
                const SizedBox(width: 5),
                _dot(const Color(0xFF28C840)),
                const SizedBox(width: 10),
                Icon(FontAwesomeIcons.server, color: _C.accent1, size: 11),
                const SizedBox(width: 6),
                Text('SENDER_CONFIG', style: TextStyle(color: _C.accent1, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.5, fontFamily: 'monospace')),
                const Spacer(),
                GestureDetector(
                  onTap: _loadGlobalSenders,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(color: _C.accent1.withOpacity(0.1), borderRadius: BorderRadius.circular(4)),
                    child: _isLoadingSenders
                        ? const SizedBox(width: 10, height: 10, child: CircularProgressIndicator(strokeWidth: 1.5, color: _C.accent1))
                        : const Icon(Icons.refresh_rounded, color: _C.accent1, size: 12),
                  ),
                ),
              ],
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: _SenderOption(
                    icon: FontAwesomeIcons.globe,
                    label: 'GLOBAL',
                    sublabel: isGroupMode ? 'LOCKED' : '${_globalSenders.length} ACTIVE',
                    selected: _senderType == 'global' && !isGroupMode,
                    locked: isGroupMode || !canAccessGlobalSender,
                    rotateY: -0.08, // ✅ Efek Miring Kiri
                    onTap: () {
                      if (!isGroupMode) {
                        setState(() { _senderType = 'global'; selectedBugId = ''; });
                      }
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _SenderOption(
                    icon: FontAwesomeIcons.userShield,
                    label: 'PRIVATE',
                    sublabel: 'OWN SESSION',
                    selected: _senderType == 'private',
                    locked: false,
                    rotateY: 0.08, // ✅ Efek Miring Kanan
                    onTap: () => setState(() { _senderType = 'private'; selectedBugId = ''; }),
                  ),
                ),
              ],
            ),
          ),

          if (_senderType == 'global' && !isGroupMode)
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              child: _buildQuotaBar(),
            ),
        ],
      ),
    );
  }
  
  Widget _buildQuotaBar() {
    if (!_quotaLoaded) return const SizedBox();
    final max = _QuotaConfig.maxPerDay;
    final isEmpty = _globalQuotaEmpty;
    final barColor = isEmpty ? _C.rose : _C.accent1;

    final double visualProgress = _animatedQuotaValue.clamp(0.0, 1.0);
    final int displayRemaining = _displayedQuotaRemaining.clamp(0, max);

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: _C.cardAlt,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: barColor.withOpacity(0.3), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(isEmpty ? Icons.block_rounded : Icons.bolt_rounded, color: barColor, size: 11),
              const SizedBox(width: 5),
              Text('GLOBAL_QUOTA', style: TextStyle(color: barColor, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1, fontFamily: 'monospace')),
              const Spacer(),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 150),
                transitionBuilder: (child, anim) => FadeTransition(
                  opacity: anim,
                  child: SlideTransition(
                    position: Tween<Offset>(begin: const Offset(0, 0.4), end: Offset.zero).animate(anim),
                    child: child,
                  ),
                ),
                child: Text(
                  '$displayRemaining/$max',
                  key: ValueKey(displayRemaining),
                  style: TextStyle(color: barColor, fontSize: 10, fontWeight: FontWeight.w900, fontFamily: 'monospace'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(3),
            child: LinearProgressIndicator(
              value: visualProgress,
              minHeight: 5,
              color: barColor,
              backgroundColor: _C.border.withOpacity(0.4),
            ),
          ),
          if (isEmpty) ...[
            const SizedBox(height: 5),
            Text('RESET: ${_formatRemainingTime()}', style: TextStyle(color: _C.rose, fontSize: 8.5, fontWeight: FontWeight.w800, fontFamily: 'monospace')),
          ],
        ],
      ),
    );
  }

  Widget _buildSendButton() {
    final isGlobalNumber = _bugMode == 'number' && _senderType == 'global';
    final quotaEmpty = isGlobalNumber && _globalQuotaEmpty;
    final disabled = _isSending || quotaEmpty;

    return AnimatedBuilder(
      animation: _sendBtnCtrl,
      builder: (_, __) => GestureDetector(
        onTap: disabled ? null : _sendBug,
        child: Transform.scale(
          scale: _isSending ? 1.0 : (quotaEmpty ? 1.0 : _sendPulse.value),
          child: Container(
            height: 58,
            width: double.infinity,
            decoration: BoxDecoration(
              gradient: quotaEmpty ? null : _C.btnGrad,
              color: quotaEmpty ? _C.rose.withOpacity(0.15) : null,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: quotaEmpty ? _C.rose : _C.accent1, width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: (quotaEmpty ? _C.rose : _C.accent1).withOpacity(_isSending ? 0.3 : _sendGlow.value * 0.6),
                  blurRadius: 28,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Center(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 300),
                child: _isSending
                    ? const Row(
                        key: ValueKey('sending'),
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)),
                          SizedBox(width: 12),
                          Text('TRANSMITTING...', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 1.5, fontFamily: 'monospace')),
                        ],
                      )
                    : Row(
                        key: ValueKey(quotaEmpty ? 'empty' : 'idle'),
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(quotaEmpty ? Icons.hourglass_empty_rounded : Icons.rocket_launch_rounded, color: Colors.white, size: 20),
                          const SizedBox(width: 10),
                          Text(quotaEmpty ? 'QUOTA_EXHAUSTED' : 'KIRIM BUG ATTACK', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 1.5, fontFamily: 'monospace')),
                        ],
                      ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildResultBanner() {
    if (_responseMsg == null) return const SizedBox();
    final parts = _responseMsg!.split('|');
    final type = parts[0];
    final msg = parts.length > 1 ? parts[1] : '';
    Color color = type == 'success' ? _C.emerald : _C.rose;
    IconData icon = type == 'success' ? Icons.check_circle_rounded : Icons.error_rounded;
    String label = type == 'success' ? 'SUCCESS' : 'ERROR';

    return Container(
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.4), width: 1.2),
        boxShadow: [BoxShadow(color: color.withOpacity(0.1), blurRadius: 14)],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: color.withOpacity(0.08),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(11)),
              border: Border(bottom: BorderSide(color: color.withOpacity(0.25), width: 1)),
            ),
            child: Row(
              children: [
                Icon(icon, color: color, size: 12),
                const SizedBox(width: 6),
                Text(label, style: TextStyle(color: color, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.5, fontFamily: 'monospace')),
                const Spacer(),
                GestureDetector(
                  onTap: () => setState(() => _responseMsg = null),
                  child: Icon(Icons.close_rounded, color: _C.textDim, size: 13),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Container(
                  width: 32, height: 32,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(0.1), border: Border.all(color: color.withOpacity(0.4), width: 1)),
                  child: Icon(icon, color: color, size: 16),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(msg, style: const TextStyle(color: _C.textSub, fontSize: 12, height: 1.4)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// SUPPORT WIDGETS
// ═══════════════════════════════════════════════════════════════════

class _CountryPhoneInput extends StatelessWidget {
  final TextEditingController controller;
  final String countryCode;
  final String countryFlag;
  final VoidCallback onCountryTap;
  final bool is3DNeo;

  const _CountryPhoneInput({
    required this.controller, required this.countryCode,
    required this.countryFlag, required this.onCountryTap, this.is3DNeo = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: _C.cardAlt,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _C.borderLit, width: 1.2),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: onCountryTap,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
              decoration: BoxDecoration(
                gradient: _C.primaryGrad,
                borderRadius: BorderRadius.horizontal(left: Radius.circular(is3DNeo ? 0 : 11)),
              ),
              child: Row(
                children: [
                  Text(countryFlag, style: const TextStyle(fontSize: 18)),
                  const SizedBox(width: 4),
                  Text(countryCode, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontFamily: 'monospace', fontSize: 13)),
                  const Icon(Icons.arrow_drop_down, color: Colors.white),
                ],
              ),
            ),
          ),
          Expanded(
            child: TextField(
              controller: controller,
              keyboardType: TextInputType.phone,
              style: const TextStyle(
                color: Color(0xFF0F172A), 
                fontWeight: FontWeight.w700, 
                fontFamily: 'monospace', 
                letterSpacing: 1.2, 
                fontSize: 14
              ),
              cursorColor: _C.accent1,
              decoration: const InputDecoration(
                hintText: '81234567890',
                hintStyle: TextStyle(color: Color(0xFF94A3B8), fontFamily: 'monospace'),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _InputSection extends StatelessWidget {
  final IconData icon;
  final String label;
  final Widget child;
  final bool is3DNeo;

  const _InputSection({required this.icon, required this.label, required this.child, this.is3DNeo = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: _C.cardGrad,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _C.accent1.withOpacity(0.3), width: 1.2),
        boxShadow: [BoxShadow(color: _C.accent1.withOpacity(0.05), blurRadius: 16)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: _C.cardAlt,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
              border: Border(bottom: BorderSide(color: _C.accent1.withOpacity(0.25), width: 1)),
            ),
            child: Row(
              children: [
                _smallDot(const Color(0xFFFF5F57)),
                const SizedBox(width: 4),
                _smallDot(const Color(0xFFFFBD2E)),
                const SizedBox(width: 4),
                _smallDot(const Color(0xFF28C840)),
                const SizedBox(width: 10),
                Icon(icon, color: _C.accent1, size: 11),
                const SizedBox(width: 6),
                Text(label, style: TextStyle(color: _C.accent1, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.5, fontFamily: 'monospace')),
              ],
            ),
          ),
          Padding(padding: const EdgeInsets.all(10), child: child),
        ],
      ),
    );
  }

  static Widget _smallDot(Color c) {
    return Container(width: 6, height: 6, decoration: BoxDecoration(shape: BoxShape.circle, color: c, boxShadow: [BoxShadow(color: c.withOpacity(0.5), blurRadius: 3)]));
  }
}

class _BugInput extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final TextInputType keyboardType;
  final IconData icon;
  final bool is3DNeo;

  const _BugInput({required this.controller, required this.hint, required this.keyboardType, required this.icon, this.is3DNeo = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: _C.cardAlt, borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.borderLit, width: 1.2)),
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        style: const TextStyle(
          color: Color(0xFF0F172A), 
          fontSize: 13.5, 
          fontFamily: 'monospace', 
          letterSpacing: 0.5
        ),
        cursorColor: _C.accent1,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(color: Color(0xFF94A3B8), fontSize: 13, fontFamily: 'monospace'),
          prefixIcon: Icon(icon, color: _C.accent1, size: 16),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        ),
      ),
    );
  }
}

// ✅ SENDER OPTION SUDAH DITAMBAH EFEK MIRING (rotateY)
class _SenderOption extends StatelessWidget {
  final IconData icon;
  final String label;
  final String sublabel;
  final bool selected;
  final bool locked;
  final double rotateY;
  final VoidCallback onTap;

  const _SenderOption({
    required this.icon, required this.label, required this.sublabel,
    required this.selected, required this.locked, required this.rotateY, required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = selected ? _C.accent1 : _C.textSub;
    final lockedColor = locked && !selected ? _C.textDim : color;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
        // ✅ EFEK 3D MIRING (Matrix4.rotateY)
        transform: Matrix4.identity()
          ..setEntry(3, 2, 0.001)
          ..rotateY(rotateY), 
        transformAlignment: Alignment.center,
        decoration: BoxDecoration(
          gradient: selected ? _C.primaryGrad : null,
          color: selected ? null : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: selected ? _C.accent1 : _C.borderLit, width: selected ? 1.8 : 1.2),
          boxShadow: selected ? [BoxShadow(color: _C.accent1.withOpacity(0.3), blurRadius: 14)] : [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 6)],
        ),
        child: Column(
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Icon(icon, color: selected ? Colors.white : lockedColor, size: 18),
                if (locked)
                  Positioned(
                    right: -4, top: -4,
                    child: Container(
                      width: 12, height: 12,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: _C.amber, border: Border.all(color: _C.card, width: 1.2)),
                      child: const Icon(Icons.lock_rounded, color: Colors.white, size: 7),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 6),
            Text(label, style: TextStyle(color: selected ? Colors.white : lockedColor, fontWeight: FontWeight.w900, fontSize: 11, letterSpacing: 1.2, fontFamily: 'monospace')),
            const SizedBox(height: 2),
            Text(sublabel, style: TextStyle(color: selected ? Colors.white70 : _C.textDim, fontSize: 8.5, letterSpacing: 0.8, fontFamily: 'monospace')),
          ],
        ),
      ),
    );
  }
}

class _CyberFramePainter extends CustomPainter {
  final Color color;
  _CyberFramePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(0.7)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    const len = 10.0;
    final w = size.width;
    final h = size.height;

    canvas.drawPath(Path()..moveTo(0, len)..lineTo(0, 0)..lineTo(len, 0), paint);
    canvas.drawPath(Path()..moveTo(w - len, 0)..lineTo(w, 0)..lineTo(w, len), paint);
    canvas.drawPath(Path()..moveTo(0, h - len)..lineTo(0, h)..lineTo(len, h), paint);
    canvas.drawPath(Path()..moveTo(w - len, h)..lineTo(w, h)..lineTo(w, h - len), paint);
  }

  @override
  bool shouldRepaint(_CyberFramePainter old) => old.color != color;
}

class _GradBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final bool fullWidth;
  final bool is3DNeo;

  const _GradBtn({required this.label, required this.onTap, this.fullWidth = false, this.is3DNeo = false});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 48,
        width: fullWidth ? double.infinity : null,
        decoration: BoxDecoration(
          gradient: _C.btnGrad,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [BoxShadow(color: _C.accent1.withOpacity(0.35), blurRadius: 16)],
        ),
        child: Center(
          child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: 1.2, fontFamily: 'monospace')),
        ),
      ),
    );
  }
}