import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// ═══════════════════════════════════════════════════════════════════
// PALETTE — RAINBOW LIGHT (biru • ungu • pink • hijau)
// ═══════════════════════════════════════════════════════════════════
class _FPC {
  // Backgrounds — putih dengan tint pastel
  static const bg        = Color(0xFFF9FBFF);
  static const surface   = Color(0xFFFFFFFF);
  static const card      = Color(0xFFFFFFFF);
  static const cardAlt   = Color(0xFFF1F5FF);

  static const border    = Color(0xFFE0E7FF);
  static const borderLit = Color(0xFFC7D2FE);

  // Warna-warni utama
  static const blue      = Color(0xFF3B82F6);
  static const blueDeep  = Color(0xFF2563EB);
  static const purple    = Color(0xFF8B5CF6);
  static const purpleDeep = Color(0xFF7C3AED);
  static const pink      = Color(0xFFEC4899);
  static const pinkBright = Color(0xFFF472B6);
  static const green     = Color(0xFF10B981);
  static const greenBright = Color(0xFF34D399);
  static const cyan      = Color(0xFF06B6D4);
  static const amber     = Color(0xFFF59E0B);

  // Text — gelap & kontras
  static const text      = Color(0xFF0F172A);
  static const textSub   = Color(0xFF475569);
  static const textDim   = Color(0xFF94A3B8);

  // Gradient utama — biru→ungu→pink
  static const LinearGradient rainbowGrad = LinearGradient(
    colors: [Color(0xFF60A5FA), Color(0xFFA78BFA), Color(0xFFF472B6)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // Gradient hijau→cyan (untuk verified state)
  static const LinearGradient emeraldGrad = LinearGradient(
    colors: [Color(0xFF34D399), Color(0xFF06B6D4)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // Gradient text multi-warna
  static const LinearGradient textGrad = LinearGradient(
    colors: [
      Color(0xFF3B82F6),
      Color(0xFF8B5CF6),
      Color(0xFFEC4899),
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    stops: [0.0, 0.5, 1.0],
  );

  // Background gradient pastel
  static const LinearGradient softGrad = LinearGradient(
    colors: [Color(0xFFF9FBFF), Color(0xFFF5F3FF), Color(0xFFFDF2F8)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );
}

// ═══════════════════════════════════════════════════════════════════
// HALAMAN VERIFIKASI SIDIK JARI — RAINBOW LIGHT EDITION
// ═══════════════════════════════════════════════════════════════════
class FingerprintVerifyPage extends StatefulWidget {
  final VoidCallback onVerified;
  final VoidCallback? onCancel;
  final Duration duration;
  final String title;
  final String subtitle;

  const FingerprintVerifyPage({
    super.key,
    required this.onVerified,
    this.onCancel,
    this.duration = const Duration(milliseconds: 1800),
    this.title = 'VERIFIKASI BIOMETRIK',
    this.subtitle = 'Sentuh & tahan untuk autentikasi',
  });

  @override
  State<FingerprintVerifyPage> createState() => _FingerprintVerifyPageState();
}

class _FingerprintVerifyPageState extends State<FingerprintVerifyPage>
    with TickerProviderStateMixin {
  double _progress = 0.0;
  bool _pressing = false;
  bool _verified = false;
  Timer? _timer;
  DateTime? _pressStartTime;
  int _lastPercent = 0;

  late AnimationController _glowController;
  late AnimationController _rotateController;
  late AnimationController _pulseController;
  late AnimationController _entranceController;
  late AnimationController _auroraController;
  late AnimationController _liquidController;

  late Animation<double> _fadeIn;
  late Animation<Offset> _slideIn;

  @override
  void initState() {
    super.initState();

    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    );
    _fadeIn = CurvedAnimation(parent: _entranceController, curve: Curves.easeOut);
    _slideIn = Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _entranceController, curve: Curves.easeOutCubic));

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2800),
    )..repeat(reverse: true);

    _rotateController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 8000),
    )..repeat();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    );

    _auroraController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 22),
    )..repeat();

    _liquidController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat();

    _entranceController.forward();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _glowController.dispose();
    _rotateController.dispose();
    _pulseController.dispose();
    _entranceController.dispose();
    _auroraController.dispose();
    _liquidController.dispose();
    super.dispose();
  }

  void _startPress() {
    if (_verified || _pressing) return;
    HapticFeedback.mediumImpact();
    _pressStartTime = DateTime.now();
    setState(() {
      _pressing = true;
      _progress = 0.0;
      _lastPercent = 0;
    });
    if (!_pulseController.isAnimating) _pulseController.repeat(reverse: true);
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(milliseconds: 16), (t) {
      if (!mounted || !_pressing || _verified) {
        t.cancel();
        return;
      }
      final elapsed = DateTime.now().difference(_pressStartTime!);
      final totalMs = widget.duration.inMilliseconds;
      final newProgress = (elapsed.inMilliseconds / totalMs).clamp(0.0, 1.0);
      final currentPercent = (newProgress * 100).toInt();
      if (currentPercent ~/ 10 > _lastPercent ~/ 10) {
        HapticFeedback.selectionClick();
      }
      _lastPercent = currentPercent;
      setState(() => _progress = newProgress);
      if (newProgress >= 1.0) {
        t.cancel();
        _onComplete();
      }
    });
  }

  void _endPress() {
    if (_verified) return;
    _timer?.cancel();
    _pressStartTime = null;
    if (_progress >= 1.0) return;
    if (_progress > 0.0) {
      HapticFeedback.lightImpact();
      _animateReset();
    }
    if (mounted) setState(() => _pressing = false);
    _pulseController.stop();
    _pulseController.reset();
  }

  void _animateReset() {
    final start = _progress;
    const resetDurationMs = 220;
    final startTime = DateTime.now();
    Timer.periodic(const Duration(milliseconds: 16), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      final elapsed = DateTime.now().difference(startTime).inMilliseconds;
      final factor = (1.0 - (elapsed / resetDurationMs)).clamp(0.0, 1.0);
      setState(() => _progress = start * factor);
      if (elapsed >= resetDurationMs) {
        t.cancel();
        if (mounted) setState(() => _progress = 0.0);
      }
    });
  }

  void _onComplete() {
    if (_verified) return;
    _verified = true;
    _pressing = false;
    HapticFeedback.heavyImpact();
    _pulseController.stop();
    setState(() => _progress = 1.0);
    Future.delayed(const Duration(milliseconds: 550), () {
      if (mounted) widget.onVerified();
    });
  }

  void _cancel() {
    _timer?.cancel();
    _pulseController.stop();
    if (widget.onCancel != null) {
      widget.onCancel!();
    } else {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _cancel();
      },
      child: Scaffold(
        backgroundColor: _FPC.bg,
        body: Stack(
          children: [
            Positioned.fill(
              child: Container(
                decoration: const BoxDecoration(gradient: _FPC.softGrad),
              ),
            ),
            Positioned.fill(
              child: IgnorePointer(
                child: AnimatedBuilder(
                  animation: Listenable.merge(
                      [_auroraController, _liquidController]),
                  builder: (_, __) => CustomPaint(
                    painter: _LiquidAuroraPainter(
                      _auroraController.value,
                      _liquidController.value,
                    ),
                  ),
                ),
              ),
            ),
            Positioned.fill(
              child: CustomPaint(painter: _HexGridPainter()),
            ),
            SafeArea(
              child: FadeTransition(
                opacity: _fadeIn,
                child: SlideTransition(
                  position: _slideIn,
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
                        child: Row(
                          children: [
                            _buildBackButton(),
                            const Spacer(),
                            _buildStatusChip(),
                          ],
                        ),
                      ),
                      const Spacer(flex: 2),
                      _buildTitleBlock(),
                      const SizedBox(height: 56),
                      _buildFingerprint(),
                      const SizedBox(height: 36),
                      _buildStatusPill(),
                      const SizedBox(height: 22),
                      _buildHintChips(),
                      const Spacer(flex: 2),
                      _buildCancelButton(),
                      const SizedBox(height: 36),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBackButton() {
    return GestureDetector(
      onTap: _cancel,
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: _FPC.card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _FPC.borderLit, width: 1.2),
          boxShadow: [
            BoxShadow(
              color: _FPC.blue.withOpacity(0.08),
              blurRadius: 16,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: const Icon(Icons.arrow_back_rounded,
            color: _FPC.blueDeep, size: 18),
      ),
    );
  }

  Widget _buildStatusChip() {
    return AnimatedBuilder(
      animation: _glowController,
      builder: (_, __) {
        final v = _glowController.value;
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          decoration: BoxDecoration(
            color: _FPC.card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _FPC.green.withOpacity(0.4), width: 1.2),
            boxShadow: [
              BoxShadow(
                color: _FPC.green.withOpacity(0.1),
                blurRadius: 12,
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 16,
                    height: 16,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _FPC.green.withOpacity(0.15 * v),
                    ),
                  ),
                  Container(
                    width: 7,
                    height: 7,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _FPC.greenBright.withOpacity(0.85 + v * 0.15),
                      boxShadow: [
                        BoxShadow(
                          color: _FPC.green.withOpacity(0.6 + v * 0.3),
                          blurRadius: 10,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 9),
              const Text(
                'BIOMETRIC',
                style: TextStyle(
                  color: _FPC.green,
                  fontSize: 9.5,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2.2,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTitleBlock() {
    return Column(
      children: [
        ShaderMask(
          shaderCallback: (b) => _FPC.textGrad.createShader(b),
          child: Text(
            widget.title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w900,
              fontFamily: 'Orbitron',
              letterSpacing: 4.5,
              height: 1.35,
            ),
          ),
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(width: 30, height: 1.2, color: _FPC.purple.withOpacity(0.4)),
            const SizedBox(width: 10),
            Container(
              width: 8,
              height: 8,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                gradient: _FPC.rainbowGrad,
              ),
            ),
            const SizedBox(width: 10),
            Container(width: 30, height: 1.2, color: _FPC.pink.withOpacity(0.4)),
          ],
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
          decoration: BoxDecoration(
            color: _FPC.card,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _FPC.borderLit, width: 1),
          ),
          child: Text(
            widget.subtitle,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: _FPC.textSub,
              fontSize: 11,
              fontFamily: 'Aktura',
              fontWeight: FontWeight.w600,
              letterSpacing: 0.6,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFingerprint() {
    const size = 240.0;
    return Listener(
      behavior: HitTestBehavior.opaque,
      onPointerDown: (_) => _startPress(),
      onPointerUp: (_) => _endPress(),
      onPointerCancel: (_) => _endPress(),
      child: AnimatedBuilder(
        animation: Listenable.merge(
            [_glowController, _rotateController, _pulseController]),
        builder: (context, _) {
          final glow = _glowController.value;
          final rotate = _rotateController.value;
          final pulse =
              _pressing ? (0.97 + _pulseController.value * 0.05) : 1.0;
          return Transform.scale(
            scale: pulse,
            child: SizedBox(
              width: size,
              height: size,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // Multi-color glow — biru, ungu, pink, hijau
                  Container(
                    width: size,
                    height: size,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: _FPC.blue.withOpacity(
                              0.08 + glow * 0.10 + _progress * 0.18),
                          blurRadius: 60 + glow * 30 + _progress * 40,
                        ),
                        BoxShadow(
                          color: _FPC.purple.withOpacity(
                              0.06 + glow * 0.08 + _progress * 0.12),
                          blurRadius: 80,
                        ),
                        BoxShadow(
                          color: _FPC.pink.withOpacity(
                              0.05 + glow * 0.06 + _progress * 0.10),
                          blurRadius: 90,
                        ),
                        if (_verified)
                          BoxShadow(
                            color: _FPC.green.withOpacity(0.2),
                            blurRadius: 100,
                          ),
                      ],
                    ),
                  ),
                  CustomPaint(
                    size: const Size(size, size),
                    painter: _AurumRingPainter(
                      rotation: rotate * 2 * math.pi,
                      progress: _progress,
                      liquidPhase: _liquidController.value,
                    ),
                  ),
                  _buildCornerBrackets(size),
                  Container(
                    width: size - 56,
                    height: size - 56,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: _verified
                          ? LinearGradient(
                              colors: [
                                _FPC.green.withOpacity(0.15),
                                _FPC.cyan.withOpacity(0.1),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            )
                          : LinearGradient(
                              colors: [
                                _FPC.cardAlt,
                                _FPC.card,
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                      border: Border.all(
                        color: (_verified ? _FPC.green : _FPC.purple)
                            .withOpacity(0.4 + glow * 0.3 + _progress * 0.5),
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: (_verified ? _FPC.green : _FPC.blue)
                              .withOpacity(0.15),
                          blurRadius: 24,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                  ),
                  if (_pressing && _progress < 1.0)
                    Positioned.fill(
                      child: IgnorePointer(
                        child: AnimatedBuilder(
                          animation: _liquidController,
                          builder: (_, __) => CustomPaint(
                            painter: _LiquidScanPainter(
                                _liquidController.value, size, _progress),
                          ),
                        ),
                      ),
                    ),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 400),
                    transitionBuilder: (child, anim) => ScaleTransition(
                      scale: anim,
                      child: FadeTransition(opacity: anim, child: child),
                    ),
                    child: Icon(
                      _verified
                          ? Icons.verified_rounded
                          : Icons.fingerprint_rounded,
                      key: ValueKey(_verified),
                      size: size * 0.30,
                      color: _verified
                          ? _FPC.green
                          : _FPC.purpleDeep.withOpacity(_pressing ? 1.0 : 0.85),
                      shadows: [
                        Shadow(
                          color: (_verified ? _FPC.green : _FPC.pink)
                              .withOpacity(_pressing ? 0.6 : 0.2),
                          blurRadius: _pressing ? 30 : 12,
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    bottom: size * 0.14,
                    child: AnimatedOpacity(
                      duration: const Duration(milliseconds: 200),
                      opacity: _progress > 0.02 ? 1.0 : 0.5,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 5),
                        decoration: BoxDecoration(
                          color: _FPC.card,
                          borderRadius: BorderRadius.circular(10),
                          border:
                              Border.all(color: _FPC.borderLit, width: 1),
                          boxShadow: [
                            BoxShadow(
                              color: _FPC.purple.withOpacity(0.1),
                              blurRadius: 10,
                            ),
                          ],
                        ),
                        child: Text(
                          '${(_progress * 100).toInt()}%',
                          style: TextStyle(
                            color: _verified ? _FPC.green : _FPC.purpleDeep,
                            fontSize: 13,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                            letterSpacing: 2,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildCornerBrackets(double size) {
    return AnimatedBuilder(
      animation: _glowController,
      builder: (_, __) {
        final v = 0.35 + _glowController.value * 0.25 + _progress * 0.4;
        const len = 20.0;
        const thick = 2.0;
        final color = _FPC.purple.withOpacity(v.clamp(0.0, 1.0));
        final s = size + 20;
        return SizedBox(
          width: s,
          height: s,
          child: Stack(
            children: [
              Positioned(
                top: 0,
                left: 0,
                child: CustomPaint(
                  size: const Size(len, len),
                  painter: _BracketPainter(
                      color: color, thick: thick, position: 'tl'),
                ),
              ),
              Positioned(
                top: 0,
                right: 0,
                child: CustomPaint(
                  size: const Size(len, len),
                  painter: _BracketPainter(
                      color: color, thick: thick, position: 'tr'),
                ),
              ),
              Positioned(
                bottom: 0,
                left: 0,
                child: CustomPaint(
                  size: const Size(len, len),
                  painter: _BracketPainter(
                      color: color, thick: thick, position: 'bl'),
                ),
              ),
              Positioned(
                bottom: 0,
                right: 0,
                child: CustomPaint(
                  size: const Size(len, len),
                  painter: _BracketPainter(
                      color: color, thick: thick, position: 'br'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildStatusPill() {
    String label;
    if (_verified) {
      label = 'AUTENTIKASI BERHASIL';
    } else if (_pressing && _progress < 1.0) {
      label = 'MEMPROSES ${(_progress * 100).toInt()}%';
    } else if (_progress > 0 && _progress < 1.0) {
      label = 'JANGAN DILEPAS';
    } else {
      label = 'SENTUH & TAHAN';
    }

    return AnimatedOpacity(
      opacity: _verified ? 0.0 : 1.0,
      duration: const Duration(milliseconds: 250),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 11),
        decoration: BoxDecoration(
          color: _FPC.card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: _pressing
                ? _FPC.purple.withOpacity(0.5)
                : _FPC.borderLit,
            width: 1.2,
          ),
          boxShadow: _pressing
              ? [
                  BoxShadow(
                    color: _FPC.purple.withOpacity(0.15),
                    blurRadius: 28,
                    spreadRadius: 1,
                  ),
                ]
              : [],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (_pressing && _progress < 1.0) ...[
              Container(
                width: 6,
                height: 6,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: _FPC.rainbowGrad,
                  boxShadow: [
                    BoxShadow(
                        color: _FPC.pink.withOpacity(0.7),
                        blurRadius: 8),
                  ],
                ),
              ),
              const SizedBox(width: 9),
            ],
            ShaderMask(
              shaderCallback: (b) => _pressing
                  ? _FPC.rainbowGrad.createShader(b)
                  : LinearGradient(
                      colors: [_FPC.textSub, _FPC.textSub],
                    ).createShader(b),
              child: Text(
                label,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 10.5,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Orbitron',
                  letterSpacing: 2.5,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHintChips() {
    return AnimatedOpacity(
      opacity: _verified ? 0.0 : 1.0,
      duration: const Duration(milliseconds: 250),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _hintChip(Icons.shield_outlined, 'AES-256', _FPC.blue),
          const SizedBox(width: 10),
          _hintChip(Icons.verified_user_outlined, 'TRUSTED', _FPC.purple),
        ],
      ),
    );
  }

  Widget _hintChip(IconData icon, String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
      decoration: BoxDecoration(
        color: _FPC.card,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.35), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 11),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(
              color: _FPC.textSub,
              fontSize: 9,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.4,
              fontFamily: 'Orbitron',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCancelButton() {
    return _PressableScale(
      onTap: _cancel,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
        decoration: BoxDecoration(
          color: _FPC.card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _FPC.borderLit, width: 1.2),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Icon(Icons.close_rounded, color: _FPC.textSub, size: 14),
            SizedBox(width: 8),
            Text(
              'BATAL',
              style: TextStyle(
                color: _FPC.textSub,
                fontSize: 10.5,
                fontWeight: FontWeight.w800,
                fontFamily: 'Orbitron',
                letterSpacing: 2.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// WIDGET BANTU — Pressable Scale
// ═══════════════════════════════════════════════════════════════════
class _PressableScale extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const _PressableScale({required this.child, required this.onTap});

  @override
  State<_PressableScale> createState() => _PressableScaleState();
}

class _PressableScaleState extends State<_PressableScale> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.94 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: widget.child,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// PAINTER — RAINBOW RING + LIQUID PROGRESS
// ═══════════════════════════════════════════════════════════════════
class _AurumRingPainter extends CustomPainter {
  final double rotation;
  final double progress;
  final double liquidPhase;

  _AurumRingPainter({
    required this.rotation,
    required this.progress,
    required this.liquidPhase,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 6;

    // Outer ring
    final outerPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9
      ..color = _FPC.border.withOpacity(0.7);
    canvas.drawCircle(center, radius + 8, outerPaint);

    // Dashed rainbow ring
    const dashCount = 72;
    for (int i = 0; i < dashCount; i++) {
      final a1 = (i / dashCount) * 2 * math.pi;
      final a2 = a1 + (1 / dashCount) * math.pi * 0.55;
      final hue = (i / dashCount) * 360;

      final dashPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2
        ..strokeCap = StrokeCap.square
        ..color = HSVColor.fromAHSV(1.0, hue, 0.5, 0.9).toColor().withOpacity(0.6);

      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius + 4),
        a1,
        a2 - a1,
        false,
        dashPaint,
      );
    }

    // Rainbow sweeping ring
    final sweepPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.4
      ..strokeCap = StrokeCap.round
      ..shader = SweepGradient(
        transform: GradientRotation(rotation),
        colors: [
          _FPC.blue.withOpacity(0.0),
          _FPC.blue.withOpacity(0.9),
          _FPC.purple.withOpacity(0.9),
          _FPC.pink.withOpacity(0.9),
          _FPC.amber.withOpacity(0.9),
          _FPC.green.withOpacity(0.9),
          _FPC.blue.withOpacity(0.0),
        ],
        stops: const [0.0, 0.15, 0.3, 0.45, 0.6, 0.8, 1.0],
      ).createShader(Rect.fromCircle(center: center, radius: radius));

    canvas.drawCircle(center, radius, sweepPaint);

    // Inner secondary ring (opposite rotation, softer)
    final innerSweep = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..strokeCap = StrokeCap.round
      ..shader = SweepGradient(
        transform: GradientRotation(-rotation * 0.7),
        colors: [
          _FPC.cyan.withOpacity(0.0),
          _FPC.cyan.withOpacity(0.7),
          _FPC.pinkBright.withOpacity(0.7),
          _FPC.purple.withOpacity(0.0),
        ],
        stops: const [0.0, 0.3, 0.6, 1.0],
      ).createShader(Rect.fromCircle(center: center, radius: radius - 4));

    canvas.drawCircle(center, radius - 4, innerSweep);

    // Progress track
    final trackPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..color = _FPC.border.withOpacity(0.8);
    canvas.drawCircle(center, radius - 20, trackPaint);

    if (progress > 0) {
      final rect = Rect.fromCircle(center: center, radius: radius - 20);

      // Glow progress
      final glowProgress = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 8
        ..strokeCap = StrokeCap.round
        ..color = _FPC.purple.withOpacity(0.18 + progress * 0.25)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);

      canvas.drawArc(
          rect, -math.pi / 2, progress * 2 * math.pi, false, glowProgress);

      // Rainbow progress
      final progressPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..strokeCap = StrokeCap.round
        ..shader = const SweepGradient(
          transform: GradientRotation(-math.pi / 2),
          colors: [
            Color(0xFF3B82F6),
            Color(0xFF8B5CF6),
            Color(0xFFEC4899),
            Color(0xFFF59E0B),
            Color(0xFF10B981),
          ],
          stops: [0.0, 0.25, 0.5, 0.75, 1.0],
        ).createShader(rect);

      canvas.drawArc(
          rect, -math.pi / 2, progress * 2 * math.pi, false, progressPaint);

      // Progress head dot
      final endAngle = -math.pi / 2 + progress * 2 * math.pi;
      final dotX = center.dx + (radius - 20) * math.cos(endAngle);
      final dotY = center.dy + (radius - 20) * math.sin(endAngle);

      canvas.drawCircle(
        Offset(dotX, dotY),
        11,
        Paint()
          ..color = _FPC.pink.withOpacity(0.35)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10),
      );
      canvas.drawCircle(
          Offset(dotX, dotY), 4, Paint()..color = _FPC.pink);
      canvas.drawCircle(
          Offset(dotX, dotY), 1.8, Paint()..color = _FPC.card);
    }

    // Liquid dots
    if (progress > 0.05) {
      final dots = (progress * 16).round();
      for (int i = 0; i < dots; i++) {
        final angle = (i / dots) * 2 * math.pi +
            rotation * 0.5 +
            liquidPhase * 2 * math.pi;
        final wave =
            math.sin(angle * 3 + liquidPhase * math.pi * 4) * 6;
        final pos = Offset(
          center.dx + (radius + 14 + wave) * math.cos(angle),
          center.dy + (radius + 14 + wave) * math.sin(angle),
        );
        final hue = (i / dots) * 360 + liquidPhase * 360;
        final dotPaint = Paint()
          ..color =
              HSVColor.fromAHSV(1.0, hue % 360, 0.6, 1.0).toColor().withOpacity(0.6);
        canvas.drawCircle(pos, 1.6, dotPaint);
      }
    }
  }

  @override
  bool shouldRepaint(_AurumRingPainter old) =>
      old.rotation != rotation ||
      old.progress != progress ||
      old.liquidPhase != liquidPhase;
}

// ═══════════════════════════════════════════════════════════════════
// PAINTER — CORNER BRACKETS
// ═══════════════════════════════════════════════════════════════════
class _BracketPainter extends CustomPainter {
  final Color color;
  final double thick;
  final String position;
  _BracketPainter({
    required this.color,
    required this.thick,
    required this.position,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = thick
      ..strokeCap = StrokeCap.square
      ..style = PaintingStyle.stroke;

    final path = Path();
    switch (position) {
      case 'tl':
        path.moveTo(0, size.height);
        path.lineTo(0, 0);
        path.lineTo(size.width, 0);
        break;
      case 'tr':
        path.moveTo(0, 0);
        path.lineTo(size.width, 0);
        path.lineTo(size.width, size.height);
        break;
      case 'bl':
        path.moveTo(0, 0);
        path.lineTo(0, size.height);
        path.lineTo(size.width, size.height);
        break;
      case 'br':
        path.moveTo(0, size.height);
        path.lineTo(size.width, size.height);
        path.lineTo(size.width, 0);
        break;
    }
    canvas.drawPath(path, p);
  }

  @override
  bool shouldRepaint(_BracketPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════════════
// PAINTER — LIQUID SCAN
// ═══════════════════════════════════════════════════════════════════
class _LiquidScanPainter extends CustomPainter {
  final double t;
  final double size;
  final double progress;
  _LiquidScanPainter(this.t, this.size, this.progress);

  @override
  void paint(Canvas canvas, Size canvasSize) {
    final center = Offset(canvasSize.width / 2, canvasSize.height / 2);
    final radius = size / 2 - 28;

    for (int i = 0; i < 3; i++) {
      final phase = (t + i / 3) % 1.0;
      final angle = phase * 2 * math.pi;
      final inner = Offset(
        center.dx + 12 * math.cos(angle),
        center.dy + 12 * math.sin(angle),
      );
      final outer = Offset(
        center.dx + radius * math.cos(angle),
        center.dy + radius * math.sin(angle),
      );

      final hue = (i / 3) * 360 + 200;
      final scanColor = HSVColor.fromAHSV(1.0, hue % 360, 0.6, 1.0).toColor();

      final p = Paint()
        ..shader = LinearGradient(
          colors: [
            Colors.transparent,
            scanColor.withOpacity(0.5 * (1 - progress * 0.5)),
            Colors.transparent,
          ],
          stops: const [0.0, 0.5, 1.0],
        ).createShader(Rect.fromPoints(inner, outer))
        ..strokeWidth = 2
        ..strokeCap = StrokeCap.round;

      canvas.drawLine(inner, outer, p);
    }
  }

  @override
  bool shouldRepaint(_LiquidScanPainter old) =>
      old.t != t || old.progress != progress;
}

// ═══════════════════════════════════════════════════════════════════
// PAINTER — HEX GRID
// ═══════════════════════════════════════════════════════════════════
class _HexGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = _FPC.purple.withOpacity(0.05)
      ..strokeWidth = 0.5
      ..style = PaintingStyle.stroke;

    const hexSize = 32.0;
    final dx = hexSize * 1.5;
    final dy = hexSize * math.sqrt(3);

    for (double x = 0; x < size.width + hexSize; x += dx) {
      for (double y = 0; y < size.height + dy; y += dy) {
        final offsetY = ((x / dx).round() % 2) * dy / 2;
        _drawHex(canvas, Offset(x, y + offsetY), hexSize, paint);
      }
    }
  }

  void _drawHex(Canvas canvas, Offset center, double size, Paint paint) {
    final path = Path();
    for (int i = 0; i < 6; i++) {
      final angle = (i * 60 - 30) * math.pi / 180;
      final point = Offset(
        center.dx + size * math.cos(angle),
        center.dy + size * math.sin(angle),
      );
      if (i == 0) {
        path.moveTo(point.dx, point.dy);
      } else {
        path.lineTo(point.dx, point.dy);
      }
    }
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

// ═══════════════════════════════════════════════════════════════════
// PAINTER — RAINBOW LIQUID AURORA
// ═══════════════════════════════════════════════════════════════════
class _LiquidAuroraPainter extends CustomPainter {
  final double t;
  final double liquid;
  _LiquidAuroraPainter(this.t, this.liquid);

  @override
  void paint(Canvas canvas, Size size) {
    // Blob biru
    final g1Center = Offset(
      size.width * (0.25 + 0.15 * math.sin(t * 2 * math.pi)),
      size.height * 0.30 + 40 * math.cos(t * math.pi * 2),
    );
    canvas.drawCircle(
      g1Center,
      size.width * 0.75,
      Paint()
        ..shader = RadialGradient(
          colors: [_FPC.blue.withOpacity(0.10), Colors.transparent],
        ).createShader(
            Rect.fromCircle(center: g1Center, radius: size.width * 0.75)),
    );

    // Blob ungu
    final g2Center = Offset(
      size.width * (0.75 + 0.10 * math.cos(t * 2 * math.pi)),
      size.height * 0.45 + 30 * math.sin(t * math.pi * 2),
    );
    canvas.drawCircle(
      g2Center,
      size.width * 0.65,
      Paint()
        ..shader = RadialGradient(
          colors: [_FPC.purple.withOpacity(0.08), Colors.transparent],
        ).createShader(
            Rect.fromCircle(center: g2Center, radius: size.width * 0.65)),
    );

    // Blob pink
    final g3Center = Offset(
      size.width * (0.55 + 0.12 * math.sin(t * 3 * math.pi)),
      size.height * 0.72 + 25 * math.cos(t * 2.5 * math.pi),
    );
    canvas.drawCircle(
      g3Center,
      size.width * 0.55,
      Paint()
        ..shader = RadialGradient(
          colors: [_FPC.pink.withOpacity(0.07), Colors.transparent],
        ).createShader(
            Rect.fromCircle(center: g3Center, radius: size.width * 0.55)),
    );

    // Blob hijau
    final g4Center = Offset(
      size.width * (0.18 + 0.08 * math.cos(t * 3 * math.pi)),
      size.height * 0.80 + 20 * math.sin(t * 2 * math.pi),
    );
    canvas.drawCircle(
      g4Center,
      size.width * 0.45,
      Paint()
        ..shader = RadialGradient(
          colors: [_FPC.green.withOpacity(0.06), Colors.transparent],
        ).createShader(
            Rect.fromCircle(center: g4Center, radius: size.width * 0.45)),
    );

    // Streak
    final streak = Paint()
      ..shader = LinearGradient(
        colors: [
          Colors.transparent,
          _FPC.purple.withOpacity(0.05),
          Colors.transparent,
        ],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));

    final streakY = size.height * (liquid % 1.0);
    canvas.drawRect(Rect.fromLTWH(0, streakY, size.width, 2), streak);
  }

  @override
  bool shouldRepaint(_LiquidAuroraPainter old) =>
      old.t != t || old.liquid != liquid;
}

// ═══════════════════════════════════════════════════════════════════
// WIDGET — FINGERPRINT VERIFY WIDGET (reusable)
// ═══════════════════════════════════════════════════════════════════
class FingerprintVerifyWidget extends StatefulWidget {
  final VoidCallback onVerified;
  final double size;
  final Duration duration;

  const FingerprintVerifyWidget({
    super.key,
    required this.onVerified,
    this.size = 200,
    this.duration = const Duration(milliseconds: 1800),
  });

  @override
  State<FingerprintVerifyWidget> createState() =>
      _FingerprintVerifyWidgetState();
}

class _FingerprintVerifyWidgetState extends State<FingerprintVerifyWidget>
    with TickerProviderStateMixin {
  double _progress = 0.0;
  bool _pressing = false;
  bool _verified = false;
  Timer? _timer;
  DateTime? _pressStartTime;
  int _lastPercent = 0;

  late AnimationController _glowController;
  late AnimationController _rotateController;
  late AnimationController _pulseController;
  late AnimationController _liquidController;

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2800))
      ..repeat(reverse: true);
    _rotateController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 8000))
      ..repeat();
    _pulseController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1600));
    _liquidController = AnimationController(
        vsync: this, duration: const Duration(seconds: 6))
      ..repeat();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _glowController.dispose();
    _rotateController.dispose();
    _pulseController.dispose();
    _liquidController.dispose();
    super.dispose();
  }

  void _startPress() {
    if (_verified || _pressing) return;
    HapticFeedback.mediumImpact();
    _pressStartTime = DateTime.now();
    setState(() {
      _pressing = true;
      _progress = 0.0;
      _lastPercent = 0;
    });
    if (!_pulseController.isAnimating) _pulseController.repeat(reverse: true);
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(milliseconds: 16), (t) {
      if (!mounted || !_pressing || _verified) {
        t.cancel();
        return;
      }
      final elapsed = DateTime.now().difference(_pressStartTime!);
      final totalMs = widget.duration.inMilliseconds;
      final newProgress = (elapsed.inMilliseconds / totalMs).clamp(0.0, 1.0);
      final currentPercent = (newProgress * 100).toInt();
      if (currentPercent ~/ 10 > _lastPercent ~/ 10) {
        HapticFeedback.selectionClick();
      }
      _lastPercent = currentPercent;
      setState(() => _progress = newProgress);
      if (newProgress >= 1.0) {
        t.cancel();
        _onComplete();
      }
    });
  }

  void _endPress() {
    if (_verified) return;
    _timer?.cancel();
    _pressStartTime = null;
    if (_progress >= 1.0) return;
    if (_progress > 0.0) {
      HapticFeedback.lightImpact();
      final start = _progress;
      const resetDurationMs = 220;
      final startTime = DateTime.now();
      Timer.periodic(const Duration(milliseconds: 16), (t) {
        if (!mounted) {
          t.cancel();
          return;
        }
        final elapsed = DateTime.now().difference(startTime).inMilliseconds;
        final factor = (1.0 - (elapsed / resetDurationMs)).clamp(0.0, 1.0);
        setState(() => _progress = start * factor);
        if (elapsed >= resetDurationMs) {
          t.cancel();
          if (mounted) setState(() => _progress = 0.0);
        }
      });
    }
    if (mounted) setState(() => _pressing = false);
    _pulseController.stop();
    _pulseController.reset();
  }

  void _onComplete() {
    if (_verified) return;
    _verified = true;
    _pressing = false;
    HapticFeedback.heavyImpact();
    _pulseController.stop();
    setState(() => _progress = 1.0);
    Future.delayed(const Duration(milliseconds: 550), () {
      if (mounted) widget.onVerified();
    });
  }

  @override
  Widget build(BuildContext context) {
    final size = widget.size;
    return Listener(
      behavior: HitTestBehavior.opaque,
      onPointerDown: (_) => _startPress(),
      onPointerUp: (_) => _endPress(),
      onPointerCancel: (_) => _endPress(),
      child: AnimatedBuilder(
        animation: Listenable.merge([
          _glowController,
          _rotateController,
          _pulseController,
          _liquidController,
        ]),
        builder: (context, _) {
          final glow = _glowController.value;
          final rotate = _rotateController.value;
          final pulse =
              _pressing ? (0.97 + _pulseController.value * 0.05) : 1.0;
          return Transform.scale(
            scale: pulse,
            child: SizedBox(
              width: size,
              height: size,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: size,
                    height: size,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: _FPC.blue.withOpacity(
                              0.08 + glow * 0.10 + _progress * 0.18),
                          blurRadius: 60 + glow * 30 + _progress * 40,
                        ),
                        BoxShadow(
                          color: _FPC.pink.withOpacity(0.06 + glow * 0.08),
                          blurRadius: 80,
                        ),
                      ],
                    ),
                  ),
                  CustomPaint(
                    size: Size(size, size),
                    painter: _AurumRingPainter(
                      rotation: rotate * 2 * math.pi,
                      progress: _progress,
                      liquidPhase: _liquidController.value,
                    ),
                  ),
                  Container(
                    width: size - 56,
                    height: size - 56,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [_FPC.cardAlt, _FPC.card],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      border: Border.all(
                        color: _FPC.purple.withOpacity(
                            0.4 + glow * 0.3 + _progress * 0.5),
                        width: 1.5,
                      ),
                    ),
                  ),
                  Icon(
                    _verified
                        ? Icons.verified_rounded
                        : Icons.fingerprint_rounded,
                    size: size * 0.30,
                    color: _verified
                        ? _FPC.green
                        : _FPC.purpleDeep.withOpacity(_pressing ? 1.0 : 0.85),
                    shadows: [
                      Shadow(
                        color: _FPC.pink
                            .withOpacity(_pressing ? 0.6 : 0.2),
                        blurRadius: _pressing ? 30 : 12,
                      ),
                    ],
                  ),
                  Positioned(
                    bottom: size * 0.14,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 5),
                      decoration: BoxDecoration(
                        color: _FPC.card,
                        borderRadius: BorderRadius.circular(10),
                        border:
                            Border.all(color: _FPC.borderLit, width: 1),
                      ),
                      child: Text(
                        '${(_progress * 100).toInt()}%',
                        style: TextStyle(
                          color: _verified ? _FPC.green : _FPC.purpleDeep,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}