import 'package:flutter/material.dart';
import 'dart:math' as math;
import 'dart:ui'; // 👈 WAJIB buat ImageFilter
import 'package:audioplayers/audioplayers.dart'; // ✅ IMPORT AUDIO
import 'dashboard_page.dart';
import 'audio_manager.dart';

class AudioDashboardScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGroup;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;
  final List<dynamic> jjVideos;
  final List<dynamic> thanksTo;

  const AudioDashboardScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listBugGroup,
    required this.listDoos,
    required this.news,
    required this.jjVideos,
    required this.thanksTo,
  });

  @override
  State<AudioDashboardScreen> createState() => _AudioDashboardScreenState();
}

class _AudioDashboardScreenState extends State<AudioDashboardScreen>
    with TickerProviderStateMixin {
  late AnimationController _rotationController;
  late AnimationController _eqController;
  late AnimationController _logoController;
  late AnimationController _glowController;

  final AudioManager _audioManager = AudioManager();
  final List<double> _barHeights = List.generate(21, (index) => 8.0);

  // LIGHT THEME
  static const bg        = Color(0xFFF5F9FF);
  static const surface   = Color(0xFFFFFFFF);
  static const card      = Color(0xFFFFFFFF);
  static const cardAlt   = Color(0xFFEFF6FF);
  static const border    = Color(0xFFD6E4F5);
  static const borderLit = Color(0xFFB6CDE8);
  static const text      = Color(0xFF0F172A);
  static const textSub   = Color(0xFF475569);
  static const textDim   = Color(0xFF94A3B8);
  
  static const primary   = Color(0xFF2563EB);
  static const accent    = Color(0xFF3B82F6);
  static const cyan      = Color(0xFF06B6D4);
  static const purple    = Color(0xFF8B5CF6);
  static const gold      = Color(0xFFF59E0B);
  static const success   = Color(0xFF10B981);

  @override
  void initState() {
    super.initState();

    _rotationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    );

    _logoController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    );
    
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _eqController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    )..addListener(() {
        if (_audioManager.isPlaying) {
          setState(() {
            for (int i = 0; i < _barHeights.length; i++) {
              _barHeights[i] = 8.0 + (math.Random().nextDouble() * 35.0);
            }
          });
        }
      });

    _eqController.repeat();

    _audioManager.init().then((_) {
      if (_audioManager.isPlaying) {
        _rotationController.repeat();
        _logoController.repeat();
      }
    });

    _audioManager.addListener(_onAudioChanged);
  }

  void _onAudioChanged() {
    if (!mounted) return;
    setState(() {
      if (_audioManager.isPlaying) {
        _rotationController.repeat();
        _logoController.repeat();
        _eqController.repeat();
      } else {
        _rotationController.stop();
        _logoController.stop();
        _eqController.stop();
      }
    });
  }

  @override
  void dispose() {
    _audioManager.removeListener(_onAudioChanged);
    _rotationController.dispose();
    _logoController.dispose();
    _glowController.dispose();
    _eqController.dispose();
    super.dispose();
  }

  void _goToDashboard() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listBugGroup: widget.listBugGroup,
          listDoos: widget.listDoos,
          news: widget.news,
          jjVideos: widget.jjVideos,
          thanksTo: widget.thanksTo,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: Stack(
        children: [
          // Background Gradient & Orbs
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFFF5F9FF), Color(0xFFE0E7FF)],
                ),
              ),
            ),
          ),
          
          Positioned(
            top: -100, right: -100,
            child: ImageFiltered(
              imageFilter: ImageFilter.blur(sigmaX: 80, sigmaY: 80),
              child: Container(
                width: 300, height: 300,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: accent.withOpacity(0.15),
                ),
              ),
            ),
          ),
          
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 16.0),
              child: Column(
                children: [
                  _buildHeader(),
                  const SizedBox(height: 32),
                  _buildTitleSection(),
                  const SizedBox(height: 32),
                  _buildVinylPlayer(),
                  const SizedBox(height: 24),
                  _buildTrackInfo(),
                  const SizedBox(height: 32),
                  _buildEnterButton(),
                  const SizedBox(height: 16),
                  _buildFooter(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== HEADER ====================
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.7),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: Colors.white, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: primary.withOpacity(0.05),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [primary, cyan],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: const Icon(Icons.graphic_eq_rounded, size: 20, color: Colors.white),
          ),
          const SizedBox(width: 12),
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("X-FAR AUDIO",
                  style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 12,
                      fontStyle: FontStyle.italic,
                      color: text,
                      letterSpacing: 0.5)),
              Text("PREMIUM ENGINE",
                  style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 9,
                      color: textSub,
                      letterSpacing: 1)),
            ],
          ),
          const Spacer(),
          Flexible(
            child: Text(
              "ID: ${widget.username.toUpperCase()}",
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  color: textSub),
            ),
          ),
          const SizedBox(width: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: success.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: success.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                const Icon(Icons.circle, size: 6, color: success),
                const SizedBox(width: 5),
                const Text("LIVE",
                    style: TextStyle(
                        fontSize: 9,
                        color: success,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1)),
              ],
            ),
          )
        ],
      ),
    );
  }

  // ==================== TITLE SECTION ====================
  Widget _buildTitleSection() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
          decoration: BoxDecoration(
            color: gold.withOpacity(0.1),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: gold.withOpacity(0.4)),
          ),
          child: const Text("PREMIUM SOUNDTRACK",
              style: TextStyle(
                  color: gold,
                  fontWeight: FontWeight.w900,
                  fontSize: 10,
                  letterSpacing: 2)),
        ),
        const SizedBox(height: 16),
        const Text(
          "DENGARKAN MUSIK",
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.w900,
            fontStyle: FontStyle.italic,
            letterSpacing: 1.2,
            color: text,
            height: 1.1,
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          "Nikmati pengalaman audio sebelum masuk\nke dashboard utama.",
          textAlign: TextAlign.center,
          style: TextStyle(color: textSub, fontSize: 12, height: 1.5),
        ),
      ],
    );
  }

  // ==================== VINYL PLAYER ====================
  Widget _buildVinylPlayer() {
    return AnimatedBuilder(
      animation: _glowController,
      builder: (context, child) {
        final glowVal = _glowController.value;
        return Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(32),
            border: Border.all(color: Colors.white, width: 2),
            boxShadow: [
              BoxShadow(
                color: primary.withOpacity(0.05 + glowVal * 0.05),
                blurRadius: 40,
                spreadRadius: 5,
                offset: const Offset(0, 15),
              ),
            ],
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Container(
                width: 250,
                height: 250,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: primary.withOpacity(0.15 + glowVal * 0.1),
                      blurRadius: 60,
                      spreadRadius: 10,
                    ),
                    BoxShadow(
                      color: cyan.withOpacity(0.1),
                      blurRadius: 80,
                      spreadRadius: 0,
                    ),
                  ],
                ),
              ),

              RotationTransition(
                turns: _rotationController,
                child: Container(
                  width: 250,
                  height: 250,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const RadialGradient(
                      colors: [
                        Color(0xFF2A2A2A),
                        Color(0xFF151515),
                        Color(0xFF000000),
                      ],
                      stops: [0.4, 0.8, 1.0],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.4),
                        blurRadius: 20,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      for (int i = 0; i < 8; i++)
                        Container(
                          width: 210.0 - (i * 20),
                          height: 210.0 - (i * 20),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white.withOpacity(0.05), width: 1),
                          ),
                        ),

                      ClipOval(
                        child: RotationTransition(
                          turns: _logoController,
                          child: Container(
                            width: 90,
                            height: 90,
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.grey,
                            ),
                            child: Image.asset(
                              'assets/images/Neverness.png',
                              fit: BoxFit.cover,
                              width: 90,
                              height: 90,
                              errorBuilder: (context, error, stackTrace) {
                                return const Center(
                                  child: Text(
                                    "N",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w900,
                                      fontSize: 32,
                                      fontStyle: FontStyle.italic,
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        ),
                      ),
                      
                      Container(
                        width: 12,
                        height: 12,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              Positioned(
                top: 10,
                right: 20,
                child: Transform.rotate(
                  angle: _audioManager.isPlaying ? -math.pi / 4.5 : -math.pi / 6,
                  alignment: Alignment.topCenter,
                  child: Column(
                    children: [
                      Container(
                        width: 16,
                        height: 16,
                        decoration: const BoxDecoration(
                          color: Colors.grey,
                          shape: BoxShape.circle,
                        ),
                      ),
                      Container(
                        width: 6,
                        height: 110,
                        decoration: BoxDecoration(
                          color: Colors.grey[400],
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ),
                      Container(
                        width: 18,
                        height: 18,
                        decoration: BoxDecoration(
                          color: primary,
                          borderRadius: BorderRadius.circular(4),
                          boxShadow: [
                            BoxShadow(color: primary.withOpacity(0.5), blurRadius: 8),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              Positioned(
                bottom: 0,
                left: 10,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: success.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    children: const [
                      Icon(Icons.circle, size: 6, color: success),
                      SizedBox(width: 5),
                      Text("33 1/3 RPM • SYNC",
                          style: TextStyle(
                              color: success,
                              fontSize: 9,
                              fontWeight: FontWeight.w800)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ==================== TRACK INFO + EQUALIZER ====================
  Widget _buildTrackInfo() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: primary.withOpacity(0.03),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              Icon(Icons.graphic_eq_rounded, size: 14, color: success),
              SizedBox(width: 6),
              Text("SEDANG DIPUTAR",
                  style: TextStyle(
                      color: textSub,
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 2)),
            ],
          ),
          const SizedBox(height: 12),
          const Text(
            "BREAKBEAT DREAM",
            style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w900,
                fontStyle: FontStyle.italic,
                letterSpacing: 1.5,
                color: text),
          ),
          const SizedBox(height: 24),
          
          Container(
            height: 60,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: cardAlt,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: borderLit),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: List.generate(21, (index) {
                Color barColor;
                if (index % 4 == 0) {
                  barColor = purple;
                } else if (index % 4 == 1) {
                  barColor = primary;
                } else if (index % 4 == 2) {
                  barColor = cyan;
                } else {
                  barColor = accent;
                }

                return AnimatedContainer(
                  duration: const Duration(milliseconds: 120),
                  width: 6,
                  height: _audioManager.isPlaying ? _barHeights[index] : 4.0,
                  decoration: BoxDecoration(
                    color: _audioManager.isPlaying ? barColor : textDim.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(3),
                    boxShadow: _audioManager.isPlaying ? [
                      BoxShadow(
                        color: barColor.withOpacity(0.4),
                        blurRadius: 4,
                        spreadRadius: 1,
                      )
                    ] : [],
                  ),
                );
              }),
            ),
          ),
          
          const SizedBox(height: 24),
          
          GestureDetector(
            onTap: () => _audioManager.togglePlay(),
            child: Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: [primary, cyan],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: primary.withOpacity(0.4),
                    blurRadius: 20,
                    spreadRadius: 2,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Icon(
                _audioManager.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                color: Colors.white,
                size: 32,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== TOMBOL MASUK ====================
  Widget _buildEnterButton() {
    return Container(
      width: double.infinity,
      height: 76,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          colors: [primary, accent],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        boxShadow: [
          BoxShadow(
            color: primary.withOpacity(0.3),
            blurRadius: 25,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(24),
          onTap: _goToDashboard,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 24),
                ),
                const SizedBox(width: 16),
                const Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("MASUK DASHBOARD",
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                              fontSize: 16,
                              letterSpacing: 0.5)),
                      SizedBox(height: 2),
                      Text("Lanjut ke Menu X-FAR",
                          style: TextStyle(
                              color: Colors.white70,
                              fontSize: 11,
                              fontStyle: FontStyle.italic)),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 8,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Row(
                    children: const [
                      Text("ENTER",
                          style: TextStyle(
                              color: primary,
                              fontWeight: FontWeight.w900,
                              fontSize: 13)),
                      SizedBox(width: 4),
                      Icon(Icons.arrow_forward_rounded, size: 16, color: primary),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ==================== FOOTER ====================
  Widget _buildFooter() {
    return const Text(
      "© 2026 X-FAR N.T.E • PREMIUM AUDIO",
      textAlign: TextAlign.center,
      style: TextStyle(
        color: textDim,
        fontSize: 10,
        fontWeight: FontWeight.w800,
        letterSpacing: 1.5,
      ),
    );
  }
}