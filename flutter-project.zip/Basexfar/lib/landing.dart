import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'fingerprint_verify.dart';
import 'buy_account.dart';
import 'free_trial.dart';

// ─── LIGHT CYBER LUXE PALETTE ───────────────────────────────
class _C {
  static const bg        = Color(0xFFF5F9FF);
  static const bgAlt     = Color(0xFFEAF2FF);
  static const surface   = Color(0xFFFFFFFF);
  static const card      = Color(0xFFFFFFFF);
  static const cardAlt   = Color(0xFFEFF6FF);

  static const border    = Color(0xFFD6E4F5);
  static const borderLit = Color(0xFFB6CDE8);
  static const glass     = Color(0x1A3B82F6);
  static const glassHi   = Color(0x2A3B82F6);

  // Accent palette — electric cyber
  static const cyan      = Color(0xFF0EA5E9);
  static const violet    = Color(0xFF8B5CF6);
  static const magenta   = Color(0xFFEC4899);
  static const emerald   = Color(0xFF10B981);
  static const gold      = Color(0xFFF59E0B);
  static const rose      = Color(0xFFEF4444);

  static const accent1   = Color(0xFF2563EB);
  static const accent2   = Color(0xFF3B82F6);
  static const accent3   = Color(0xFF1D4ED8);

  static const text      = Color(0xFF0F172A);
  static const textSub   = Color(0xFF475569);
  static const textDim   = Color(0xFF94A3B8);

  static const primary      = cyan;
  static const primaryMid   = Color(0xFF0284C7);
  static const primaryLight = Color(0xFF38BDF8);
  static const primaryFrost = Color(0xFF7DD3FC);
  static const accent       = violet;
  static const silver       = accent2;

  // Gradients — soft & vivid
  static const LinearGradient luxeGrad = LinearGradient(
    colors: [Color(0xFF60A5FA), Color(0xFF3B82F6), Color(0xFF2563EB)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    stops: [0.0, 0.5, 1.0],
  );

  static const LinearGradient auroraGrad = LinearGradient(
    colors: [Color(0xFF38BDF8), Color(0xFF8B5CF6), Color(0xFFEC4899)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    stops: [0.0, 0.5, 1.0],
  );

  static const LinearGradient softGrad = LinearGradient(
    colors: [Color(0xFFF5F9FF), Color(0xFFEAF2FF), Color(0xFFF5F9FF)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static const LinearGradient textGrad = LinearGradient(
    colors: [Color(0xFF0F172A), Color(0xFF2563EB), Color(0xFF8B5CF6)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    stops: [0.0, 0.6, 1.0],
  );

  static const LinearGradient cardGrad = LinearGradient(
    colors: [Color(0xFFFFFFFF), Color(0xFFF1F6FF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient goldGrad = LinearGradient(
    colors: [Color(0xFFFCD34D), Color(0xFFF59E0B), Color(0xFFD97706)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient emeraldGrad = LinearGradient(
    colors: [Color(0xFF6EE7B7), Color(0xFF10B981), Color(0xFF059669)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  bool _fingerprintVerified = false;

  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _logoCtrl;
  late AnimationController _btnCtrl;
  late AnimationController _orbCtrl;
  late AnimationController _particleCtrl;
  late AnimationController _pulseCtrl;

  late Animation<double> _fade;
  late Animation<Offset>  _slide;
  late Animation<double>  _logoPulse;
  late Animation<double>  _logoGlow;
  late Animation<double>  _btnGlow;
  late Animation<double>  _particleFade;

  final ScrollController _scrollCtrl = ScrollController();

  final GlobalKey _keyWelcome1 = GlobalKey();
  final GlobalKey _keyWelcome2 = GlobalKey();
  final GlobalKey _keyWelcome3 = GlobalKey();

  int _currentPage = 0;

  @override
  void initState() {
    super.initState();

    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 30))
      ..repeat();

    _entranceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1400));
    _fade  = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutQuad);
    _slide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _entranceCtrl, curve: Curves.easeOutCubic));

    _logoCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2800))
      ..repeat(reverse: true);
    _logoPulse = Tween<double>(begin: 0.92, end: 1.02)
        .animate(CurvedAnimation(parent: _logoCtrl, curve: Curves.easeInOutSine));
    _logoGlow = Tween<double>(begin: 0.4, end: 1.0)
        .animate(CurvedAnimation(parent: _logoCtrl, curve: Curves.easeInOutSine));

    _btnCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2000))
      ..repeat(reverse: true);
    _btnGlow = Tween<double>(begin: 0.3, end: 0.7)
        .animate(CurvedAnimation(parent: _btnCtrl, curve: Curves.easeInOutSine));

    _orbCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 16))
      ..repeat();

    _particleCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 6))
      ..repeat(reverse: true);
    _particleFade = Tween<double>(begin: 0.0, end: 0.6)
        .animate(CurvedAnimation(parent: _particleCtrl, curve: Curves.easeInOutQuad));

    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2200))
      ..repeat(reverse: true);

    _entranceCtrl.forward();
    _scrollCtrl.addListener(_onScroll);
  }

  void _onScroll() {
    if (!_scrollCtrl.hasClients) return;
    final screenH = MediaQuery.of(context).size.height;
    final offset = _scrollCtrl.offset;
    int page = 0;
    if (offset > screenH * 0.5 && offset <= screenH * 1.5) {
      page = 1;
    } else if (offset > screenH * 1.5) {
      page = 2;
    }
    if (page != _currentPage) {
      setState(() => _currentPage = page);
    }
  }

  void _scrollToPage(int index) {
    final keys = [_keyWelcome1, _keyWelcome2, _keyWelcome3];
    final ctx = keys[index].currentContext;
    if (ctx != null) {
      Scrollable.ensureVisible(
        ctx,
        duration: const Duration(milliseconds: 600),
        curve: Curves.easeOutCubic,
      );
    }
  }

  @override
  void dispose() {
    _scrollCtrl.removeListener(_onScroll);
    _scrollCtrl.dispose();
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _logoCtrl.dispose();
    _btnCtrl.dispose();
    _orbCtrl.dispose();
    _particleCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    try {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  void _goToBuyAccount() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const BuyAccountPage()),
    );
  }

  void _goToFreeTrial() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const FreeTrialPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!_fingerprintVerified) {
      return FingerprintVerifyPage(
        title: 'VERIFIKASI SIDIK JARI',
        subtitle: 'Tekan & tahan sampai 100% untuk lanjut',
        onVerified: () {
          if (mounted) {
            setState(() => _fingerprintVerified = true);
          }
        },
        onCancel: () {},
      );
    }

    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          Positioned.fill(
            child: _AnimatedBg(
              bgCtrl: _bgCtrl,
              orbCtrl: _orbCtrl,
              particleFade: _particleFade,
            ),
          ),
          SafeArea(
            child: FadeTransition(
              opacity: _fade,
              child: SlideTransition(
                position: _slide,
                child: Scrollbar(
                  controller: _scrollCtrl,
                  thickness: 3,
                  radius: const Radius.circular(3),
                  thumbVisibility: true,
                  child: SingleChildScrollView(
                    controller: _scrollCtrl,
                    physics: const BouncingScrollPhysics(
                      parent: AlwaysScrollableScrollPhysics(),
                    ),
                    child: Column(
                      children: [
                        Container(
                          key: _keyWelcome1,
                          constraints: BoxConstraints(
                            minHeight: MediaQuery.of(context).size.height,
                          ),
                          padding: const EdgeInsets.symmetric(horizontal: 28),
                          child: _buildWelcome1(),
                        ),
                        Container(
                          key: _keyWelcome2,
                          constraints: BoxConstraints(
                            minHeight: MediaQuery.of(context).size.height,
                          ),
                          padding: const EdgeInsets.symmetric(horizontal: 24),
                          child: _buildWelcome2(),
                        ),
                        Container(
                          key: _keyWelcome3,
                          child: _buildLandingContent(),
                        ),
                        const SizedBox(height: 30),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          _buildPageIndicator(),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // WELCOME 1 — SELAMAT DATANG
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildWelcome1() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const SizedBox(height: 60),

        // Icon dengan multi-ring aurora
        AnimatedBuilder(
          animation: _pulseCtrl,
          builder: (_, __) {
            return SizedBox(
              width: 200, height: 200,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // Outer ring
                  Container(
                    width: 190, height: 190,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: _C.cyan.withOpacity(0.15 + _pulseCtrl.value * 0.15),
                        width: 1,
                      ),
                    ),
                  ),
                  // Middle rotating arc
                  Transform.rotate(
                    angle: _orbCtrl.value * math.pi * 2,
                    child: Container(
                      width: 160, height: 160,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: SweepGradient(
                          colors: [
                            _C.cyan.withOpacity(0.4),
                            Colors.transparent,
                            _C.violet.withOpacity(0.4),
                            Colors.transparent,
                            _C.cyan.withOpacity(0.4),
                          ],
                          stops: const [0.0, 0.25, 0.5, 0.75, 1.0],
                        ),
                      ),
                    ),
                  ),
                  // Glow halo
                  Container(
                    width: 140, height: 140,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: _C.cyan.withOpacity(0.15 + _pulseCtrl.value * 0.15),
                          blurRadius: 60 + _pulseCtrl.value * 30,
                          spreadRadius: 8,
                        ),
                        BoxShadow(
                          color: _C.violet.withOpacity(0.1),
                          blurRadius: 100,
                          spreadRadius: 0,
                        ),
                      ],
                    ),
                  ),
                  // Inner icon bubble
                  Container(
                    width: 110, height: 110,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: _C.cardGrad,
                      border: Border.all(
                        color: _C.cyan.withOpacity(0.5),
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 20,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.waving_hand_rounded,
                      color: _C.cyan,
                      size: 52,
                    ),
                  ),
                ],
              ),
            );
          },
        ),

        const SizedBox(height: 36),

        // Title dengan gradient text
        ShaderMask(
          shaderCallback: (b) => _C.textGrad.createShader(b),
          child: const Text(
            'SELAMAT DATANG',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: 34,
              fontWeight: FontWeight.w900,
              letterSpacing: 4,
              height: 1.1,
              fontFamily: 'Qaxer',
            ),
          ),
        ),

        const SizedBox(height: 20),

        // Divider aurora
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 50, height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.transparent, _C.cyan.withOpacity(0.6)],
                ),
              ),
            ),
            const SizedBox(width: 12),
            Container(
              width: 8, height: 8,
              decoration: BoxDecoration(
                color: _C.cyan,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(color: _C.cyan.withOpacity(0.5), blurRadius: 16, spreadRadius: 2),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Container(
              width: 50, height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [_C.violet.withOpacity(0.6), Colors.transparent],
                ),
              ),
            ),
          ],
        ),

        const SizedBox(height: 24),

        // Subtitle
        ShaderMask(
          shaderCallback: (b) => _C.auroraGrad.createShader(b),
          child: const Text(
            'Di X-FAR N.T.E',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.w300,
              letterSpacing: 3,
              fontStyle: FontStyle.italic,
            ),
          ),
        ),

        const SizedBox(height: 16),

        // Deskripsi dalam glass card
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 8),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.borderLit),
            boxShadow: [
              BoxShadow(
                color: _C.cyan.withOpacity(0.08),
                blurRadius: 30,
                spreadRadius: 0,
              ),
            ],
          ),
          child: const Text(
            'Platform premium dengan tools canggih,\n'
            'keamanan tingkat tinggi, dan performa\n'
            'super cepat untuk kebutuhan kamu.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _C.textSub,
              fontSize: 13.5,
              height: 1.8,
              letterSpacing: 0.4,
            ),
          ),
        ),

        const SizedBox(height: 48),
        _buildScrollHint(),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // WELCOME 2 — TENTANG KAMI
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildWelcome2() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 60),

        // Header
        Center(
          child: Column(
            children: [
              // Badge
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      _C.cyan.withOpacity(0.1),
                      _C.violet.withOpacity(0.1),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(
                    color: _C.cyan.withOpacity(0.4),
                    width: 1,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: _C.cyan.withOpacity(0.15),
                      blurRadius: 20,
                    ),
                  ],
                ),
                child: const Text(
                  '✦  TENTANG KAMI  ✦',
                  style: TextStyle(
                    color: _C.cyan,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 3,
                  ),
                ),
              ),
              const SizedBox(height: 18),
              ShaderMask(
                shaderCallback: (b) => _C.textGrad.createShader(b),
                child: const Text(
                  'X-FAR N.T.E',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 44,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Qaxer',
                    letterSpacing: 6,
                    height: 1,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: _C.card,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _C.borderLit),
                ),
                child: const Text(
                  'PROJECT PREMIUM',
                  style: TextStyle(
                    color: _C.textSub,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 4,
                  ),
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 40),

        _buildParagraph(
          icon: Icons.auto_awesome_rounded,
          title: 'Apa itu X-FAR N.T.E?',
          text:
              'X-FAR N.T.E adalah platform cyberpunk marketplace '
              'generasi baru yang dirancang untuk memenuhi kebutuhan '
              'digital kamu. Kami menggabungkan teknologi terkini '
              'dengan desain premium untuk memberikan pengalaman '
              'terbaik bagi setiap pengguna.',
          accent: _C.cyan,
        ),
        const SizedBox(height: 16),
        _buildParagraph(
          icon: Icons.security_rounded,
          title: 'Keamanan Terjamin',
          text:
              'Setiap akun dilindungi dengan enkripsi end-to-end, '
              'verifikasi sidik jari, dan sistem anti-tamper APK. '
              'Kami memastikan data kamu aman dan tidak bisa diakses '
              'oleh pihak yang tidak bertanggung jawab.',
          accent: _C.violet,
        ),
        const SizedBox(height: 16),
        _buildParagraph(
          icon: Icons.bolt_rounded,
          title: 'Performa Tinggi',
          text:
              'Dengan infrastruktur server modern dan optimasi '
              'maksimal, X-FAR memberikan respon cepat, latensi '
              'rendah, dan stabilitas tinggi. Cocok untuk penggunaan '
              'harian maupun profesional.',
          accent: _C.emerald,
        ),
        const SizedBox(height: 16),
        _buildParagraph(
          icon: Icons.card_giftcard_rounded,
          title: 'Free Trial 3 hari',
          text:
              'Belum yakin? Kami menyediakan akun gratis selama 3 hari '
              'untuk mencoba semua fitur premium. Tanpa kartu kredit, '
              'tanpa komitmen. Cukup daftar dan langsung pakai.',
          accent: _C.gold,
        ),

        const SizedBox(height: 40),

        Center(
          child: Column(
            children: [
              ShaderMask(
                shaderCallback: (b) => _C.textGrad.createShader(b),
                child: const Text(
                  'Siap memulai?',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 2,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'Scroll ke bawah untuk lanjut',
                style: TextStyle(
                  color: _C.textDim,
                  fontSize: 12,
                  letterSpacing: 1.5,
                ),
              ),
              const SizedBox(height: 20),
              _buildScrollHint(),
            ],
          ),
        ),

        const SizedBox(height: 40),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // PARAGRAPH WIDGET (glassmorphism)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildParagraph({
    required IconData icon,
    required String title,
    required String text,
    required Color accent,
  }) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: accent.withOpacity(0.3),
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: accent.withOpacity(0.06),
            blurRadius: 24,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42, height: 42,
                decoration: BoxDecoration(
                  color: accent.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: accent.withOpacity(0.3),
                    width: 1,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: accent.withOpacity(0.15),
                      blurRadius: 12,
                    ),
                  ],
                ),
                child: Icon(icon, color: accent, size: 20),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    color: _C.text,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Aktura',
                    letterSpacing: 0.8,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            text,
            style: const TextStyle(
              color: _C.textSub,
              fontSize: 13,
              height: 1.7,
              letterSpacing: 0.2,
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // SCROLL HINT
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildScrollHint() {
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (_, __) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(
            'SCROLL DOWN',
            style: TextStyle(
              color: _C.textDim,
              fontSize: 9,
              letterSpacing: 3,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.card,
              border: Border.all(
                color: _C.cyan.withOpacity(0.4 + _pulseCtrl.value * 0.3),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: _C.cyan.withOpacity(0.1 + _pulseCtrl.value * 0.15),
                  blurRadius: 20,
                ),
              ],
            ),
            child: Transform.translate(
              offset: Offset(0, _pulseCtrl.value * 3),
              child: const Icon(
                Icons.keyboard_arrow_down_rounded,
                color: _C.cyan,
                size: 22,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // PAGE INDICATOR (kanan layar)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildPageIndicator() {
    return Positioned(
      right: 12,
      top: 0,
      bottom: 0,
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.borderLit),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 10,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: List.generate(3, (i) {
              final active = _currentPage == i;
              return GestureDetector(
                onTap: () => _scrollToPage(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeOutCubic,
                  margin: const EdgeInsets.symmetric(vertical: 6),
                  width: active ? 8 : 6,
                  height: active ? 32 : 6,
                  decoration: BoxDecoration(
                    gradient: active ? _C.auroraGrad : null,
                    color: active ? null : _C.textDim.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(active ? 8 : 3),
                    boxShadow: active
                        ? [
                            BoxShadow(
                              color: _C.cyan.withOpacity(0.5),
                              blurRadius: 12,
                              spreadRadius: 1,
                            ),
                          ]
                        : null,
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // LANDING CONTENT
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildLandingContent() {
    return Column(
      children: [
        const SizedBox(height: 32),
        _buildHeroSection(),
        const SizedBox(height: 28),
        _buildBanner(),
        const SizedBox(height: 28),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              _buildFeatureList(),
              const SizedBox(height: 28),
              _buildSignInButton(),
              const SizedBox(height: 12),
              _buildBuyButton(),
              const SizedBox(height: 12),
              _buildFreeTrialButton(),
              const SizedBox(height: 30),
              _buildDivider(),
              const SizedBox(height: 22),
              Row(children: [
                Expanded(child: _ContactBtn(
                  icon: FontAwesomeIcons.telegram,
                  label: 'Telegram',
                  color: _C.cyan,
                  colorDim: _C.cyan.withOpacity(0.1),
                  onTap: () => _openUrl(OmhcSilenceProtect.decode(["nW4Opsj","2DSWXDO","kmbOWF2","zGMwg=="])),
                )),
                const SizedBox(width: 12),
                Expanded(child: _ContactBtn(
                  icon: FontAwesomeIcons.whatsapp,
                  label: 'WhatsApp',
                  color: _C.emerald,
                  colorDim: _C.emerald.withOpacity(0.1),
                  onTap: () => _openUrl(OmhcSilenceProtect.decode(["nW4O","psj2","DSWU","Q6ou","JrI="])),
                )),
              ]),
              const SizedBox(height: 36),
              _buildFooter(),
              const SizedBox(height: 28),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildHeroSection() {
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (_, __) => Column(children: [
        AnimatedBuilder(
          animation: _logoCtrl,
          builder: (_, __) => Transform.scale(
            scale: _logoPulse.value,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Outer glow ring
                Container(
                  width: 180, height: 180,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _C.cyan.withOpacity(_logoGlow.value * 0.3),
                      width: 1,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _C.cyan.withOpacity(_logoGlow.value * 0.15),
                        blurRadius: 80,
                        spreadRadius: 20,
                      ),
                      BoxShadow(
                        color: _C.violet.withOpacity(_logoGlow.value * 0.1),
                        blurRadius: 120,
                        spreadRadius: 10,
                      ),
                    ],
                  ),
                ),
                // Middle ring
                Container(
                  width: 145, height: 145,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _C.violet.withOpacity(_logoGlow.value * 0.35),
                      width: 1.5,
                    ),
                  ),
                ),
                // Rotating aurora ring
                Transform.rotate(
                  angle: _orbCtrl.value * math.pi * 2,
                  child: Container(
                    width: 120, height: 120,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: SweepGradient(
                        colors: [
                          _C.cyan.withOpacity(_logoGlow.value * 0.5),
                          Colors.transparent,
                          _C.violet.withOpacity(_logoGlow.value * 0.4),
                          Colors.transparent,
                          _C.cyan.withOpacity(_logoGlow.value * 0.5),
                        ],
                        stops: const [0.0, 0.25, 0.5, 0.75, 1.0],
                      ),
                    ),
                  ),
                ),
                // Inner logo
                Container(
                  width: 100, height: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(28),
                    gradient: _C.cardGrad,
                    border: Border.all(
                      color: _C.cyan.withOpacity(_logoGlow.value * 0.6),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _C.cyan.withOpacity(_logoGlow.value * 0.3),
                        blurRadius: 40,
                        spreadRadius: 2,
                      ),
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 20,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(26),
                    child: Image.asset(
                      'assets/images/reze.png',
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        decoration: BoxDecoration(
                          gradient: _C.luxeGrad,
                          borderRadius: BorderRadius.circular(26),
                        ),
                        child: const Icon(
                          Icons.auto_awesome_rounded,
                          color: Colors.white, size: 42,
                        ),
                      ),
                    ),
                  ),
                ),
                // Glass overlay highlight
                Container(
                  width: 100, height: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(28),
                    gradient: LinearGradient(
                      colors: [
                        Colors.white.withOpacity(0.3),
                        Colors.transparent,
                        Colors.white.withOpacity(0.1),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 22),
        // Title gradient
        ShaderMask(
          shaderCallback: (b) => _C.textGrad.createShader(b),
          child: const Text(
            'X-FAR N.T.E',
            style: TextStyle(
              fontSize: 34,
              fontFamily: "Qaxer",
              fontWeight: FontWeight.w900,
              color: Colors.white,
              letterSpacing: 5,
              height: 1,
            ),
          ),
        ),
        const SizedBox(height: 12),
        // Version badge
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _C.cyan.withOpacity(0.3)),
            boxShadow: [
              BoxShadow(
                color: _C.cyan.withOpacity(0.08),
                blurRadius: 20,
                spreadRadius: 0,
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 6, height: 6,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _C.emerald,
                  boxShadow: [
                    BoxShadow(
                      color: _C.emerald.withOpacity(0.8),
                      blurRadius: 8,
                      spreadRadius: 1,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              const Text(
                'Version 1.0.0',
                style: TextStyle(
                  color: _C.textSub,
                  fontSize: 11,
                  letterSpacing: 1.2,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'Ready',
                ),
              ),
            ],
          ),
        ),
      ]),
    );
  }

  Widget _buildBanner() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        height: 200,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: _C.cardGrad,
          border: Border.all(color: _C.borderLit, width: 1),
          boxShadow: [
            BoxShadow(
              color: _C.cyan.withOpacity(0.15),
              blurRadius: 40,
              offset: const Offset(0, 12),
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 20,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.asset(
                'assets/images/landing.jpg',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  color: _C.surface,
                  child: const Icon(Icons.broken_image,
                      color: _C.textDim, size: 50),
                ),
              ),
              // Dark gradient overlay (ditipisin biar tetep kelihatan gambar)
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      _C.bg.withOpacity(0.6),
                      _C.bg.withOpacity(0.1),
                      _C.bg.withOpacity(0.8),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    stops: const [0.0, 0.5, 1.0],
                  ),
                ),
              ),
              // Aurora tint
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      _C.cyan.withOpacity(0.1),
                      Colors.transparent,
                      _C.violet.withOpacity(0.1),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),
              // Content
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(5),
                          decoration: BoxDecoration(
                            color: _C.cyan.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: _C.cyan.withOpacity(0.5),
                              width: 1,
                            ),
                          ),
                          child: const Icon(Icons.bolt_rounded,
                              color: _C.cyan, size: 14),
                        ),
                        const SizedBox(width: 8),
                        const Text(
                          'Version 18',
                          style: TextStyle(
                            color: _C.text,
                            fontWeight: FontWeight.w900,
                            fontSize: 13,
                            fontFamily: 'Ready',
                            letterSpacing: 1.5,
                          ),
                        ),
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            gradient: _C.emeraldGrad,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: _C.emerald.withOpacity(0.3),
                                blurRadius: 12,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                          child: const Text(
                            '● LIVE',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 9,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.5,
                              fontFamily: 'Aktura',
                            ),
                          ),
                        ),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ShaderMask(
                          shaderCallback: (b) => _C.auroraGrad.createShader(b),
                          child: const Text(
                            'X-FAR N.T.E',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 26,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Qaxer',
                              height: 1,
                            ),
                          ),
                        ),
                        const Text(
                          'Powered By SWIGHT ',
                          style: TextStyle(
                            color: _C.text,
                            fontSize: 24,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Qaxer',
                            height: 1.1,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFeatureList() {
    return Column(
      children: [
        _FeatureItem(
          icon: Icons.flash_on_rounded,
          title: 'ULTRA FAST',
          desc: 'Lightning speed performance & low latency execution.',
          color: _C.cyan,
        ),
        const SizedBox(height: 12),
        _FeatureItem(
          icon: Icons.shield_rounded,
          title: 'SECURE',
          desc: 'End-to-end encryption & anti-tamper APK security.',
          color: _C.violet,
        ),
        const SizedBox(height: 12),
        _FeatureItem(
          icon: Icons.track_changes_rounded,
          title: 'POWERFUL',
          desc: 'Advanced tools & remote access features built-in.',
          color: _C.gold,
        ),
      ],
    );
  }

  Widget _buildSignInButton() {
    return AnimatedBuilder(
      animation: _btnCtrl,
      builder: (_, __) => _PressableBtn(
        onTap: () => Navigator.pushNamed(context, '/login'),
        child: Container(
          width: double.infinity,
          height: 60,
          decoration: BoxDecoration(
            gradient: _C.luxeGrad,
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(
                color: _C.cyan.withOpacity(_btnGlow.value * 0.4),
                blurRadius: 30,
                offset: const Offset(0, 10),
              ),
              BoxShadow(
                color: _C.violet.withOpacity(_btnGlow.value * 0.2),
                blurRadius: 40,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Stack(
            children: [
              // Shine overlay
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    gradient: LinearGradient(
                      colors: [
                        Colors.white.withOpacity(0.3),
                        Colors.transparent,
                        Colors.white.withOpacity(0.1),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      stops: const [0.0, 0.4, 1.0],
                    ),
                  ),
                ),
              ),
              Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 34, height: 34,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white.withOpacity(0.2),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.5),
                          width: 1,
                        ),
                      ),
                      child: const Icon(Icons.login_rounded,
                          color: Colors.white, size: 18),
                    ),
                    const SizedBox(width: 14),
                    const Text(
                      'ENTER LOGIN',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontFamily: "Aktura",
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Icon(Icons.arrow_forward_rounded,
                        color: Colors.white.withOpacity(0.9), size: 16),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBuyButton() {
    return _PressableBtn(
      onTap: _goToBuyAccount,
      child: Container(
        width: double.infinity,
        height: 60,
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: _C.gold.withOpacity(0.5),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: _C.gold.withOpacity(0.15),
              blurRadius: 25,
              spreadRadius: 0,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 34, height: 34,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.gold.withOpacity(0.15),
                border: Border.all(
                  color: _C.gold.withOpacity(0.5),
                  width: 1,
                ),
              ),
              child: const Icon(Icons.shopping_bag_outlined,
                  color: _C.gold, size: 17),
            ),
            const SizedBox(width: 14),
            const Text(
              'BUY ACCESS',
              style: TextStyle(
                color: _C.text,
                fontSize: 17,
                fontFamily: "Aktura",
                fontWeight: FontWeight.w800,
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(width: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: _C.gold.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _C.gold.withOpacity(0.4), width: 1),
              ),
              child: const Text(
                'LIHAT HARGA',
                style: TextStyle(
                  color: _C.gold,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.8,
                  fontFamily: 'Aktura',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFreeTrialButton() {
    return AnimatedBuilder(
      animation: _btnCtrl,
      builder: (_, __) => _PressableBtn(
        onTap: _goToFreeTrial,
        child: Container(
          width: double.infinity,
          height: 60,
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: _C.emerald.withOpacity(0.5),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: _C.emerald.withOpacity(_btnGlow.value * 0.2),
                blurRadius: 28,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 34, height: 34,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _C.emerald.withOpacity(0.15),
                  border: Border.all(
                    color: _C.emerald.withOpacity(0.5),
                    width: 1,
                  ),
                ),
                child: const Icon(Icons.card_giftcard_rounded,
                    color: _C.emerald, size: 17),
              ),
              const SizedBox(width: 14),
              const Text(
                'FREE TRIAL 3H',
                style: TextStyle(
                  color: _C.text,
                  fontSize: 17,
                  fontFamily: "Aktura",
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.5,
                ),
              ),
              const SizedBox(width: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _C.emerald.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: _C.emerald.withOpacity(0.4),
                    width: 1,
                  ),
                ),
                child: const Text(
                  'GRATIS',
                  style: TextStyle(
                    color: _C.emerald,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.8,
                    fontFamily: 'Aktura',
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDivider() {
    return Row(children: [
      Expanded(
        child: Container(
          height: 1,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.transparent, _C.cyan.withOpacity(0.3), Colors.transparent],
              stops: const [0.0, 0.5, 1.0],
            ),
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _C.cyan.withOpacity(0.3), width: 1),
            boxShadow: [
              BoxShadow(
                color: _C.cyan.withOpacity(0.08),
                blurRadius: 12,
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.people_rounded, color: _C.cyan, size: 12),
              const SizedBox(width: 6),
              const Text(
                'JOIN X-FAR COMMUNITY',
                style: TextStyle(
                  color: _C.textSub,
                  fontSize: 10,
                  fontFamily: "Qaxer",
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
        ),
      ),
      Expanded(
        child: Container(
          height: 1,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.transparent, _C.violet.withOpacity(0.3), Colors.transparent],
              stops: const [0.0, 0.5, 1.0],
            ),
          ),
        ),
      ),
    ]);
  }

  Widget _buildFooter() {
    return Column(children: [
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(
          width: 40, height: 2,
          decoration: BoxDecoration(
            gradient: _C.auroraGrad,
            borderRadius: BorderRadius.circular(2),
            boxShadow: [
              BoxShadow(
                color: _C.cyan.withOpacity(0.3),
                blurRadius: 8,
              ),
            ],
          ),
        ),
        const SizedBox(width: 14),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: _C.borderLit,
              width: 1,
            ),
          ),
          child: RichText(
            text: const TextSpan(
              style: TextStyle(
                color: _C.textDim,
                fontSize: 11,
                letterSpacing: 0.8,
                fontWeight: FontWeight.w700,
              ),
              children: [
                TextSpan(text: '© ', style: TextStyle(fontFamily: 'Qaxer')),
                TextSpan(text: '2026', style: TextStyle(fontFamily: 'Ready')),
                TextSpan(
                  text: 'X-FAR N.T.E',
                  style: TextStyle(fontFamily: 'Qaxer'),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 14),
        Container(
          width: 40, height: 2,
          decoration: BoxDecoration(
            gradient: _C.auroraGrad,
            borderRadius: BorderRadius.circular(2),
            boxShadow: [
              BoxShadow(
                color: _C.violet.withOpacity(0.3),
                blurRadius: 8,
              ),
            ],
          ),
        ),
      ]),
    ]);
  }
}

// ─── Feature Item (glass card) ────────────────────────────────────────────────
class _FeatureItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String desc;
  final Color color;

  const _FeatureItem({
    required this.icon,
    required this.title,
    required this.desc,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: color.withOpacity(0.3),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.08),
            blurRadius: 24,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: color.withOpacity(0.4), width: 1),
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.15),
                  blurRadius: 14,
                ),
              ],
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: _C.text,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Aktura',
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  desc,
                  style: const TextStyle(
                    color: _C.textSub,
                    fontSize: 12,
                    height: 1.4,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          Container(
            width: 6, height: 6,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color,
              boxShadow: [
                BoxShadow(color: color.withOpacity(0.5), blurRadius: 10),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Contact Button ───────────────────────────────────────────────────────────
class _ContactBtn extends StatefulWidget {
  final IconData icon;
  final String label;
  final Color color;
  final Color colorDim;
  final VoidCallback onTap;

  const _ContactBtn({
    required this.icon, required this.label,
    required this.color, required this.colorDim,
    required this.onTap,
  });

  @override
  State<_ContactBtn> createState() => _ContactBtnState();
}

class _ContactBtnState extends State<_ContactBtn> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) { setState(() => _pressed = false); widget.onTap(); },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.95 : 1.0,
        duration: const Duration(milliseconds: 150),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          height: 56,
          decoration: BoxDecoration(
            color: _pressed ? _C.cardAlt : _C.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: widget.color.withOpacity(0.4),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: widget.color.withOpacity(_pressed ? 0.2 : 0.1),
                blurRadius: _pressed ? 20 : 14,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Container(
              width: 30, height: 30,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: widget.colorDim,
                border: Border.all(
                  color: widget.color.withOpacity(0.5),
                  width: 1,
                ),
              ),
              child: Center(
                child: FaIcon(widget.icon, color: widget.color, size: 14),
              ),
            ),
            const SizedBox(width: 10),
            Text(
              widget.label,
              style: const TextStyle(
                color: _C.text,
                fontSize: 14,
                fontWeight: FontWeight.w800,
                fontFamily: 'Aktura',
                letterSpacing: 0.5,
              ),
            ),
          ]),
        ),
      ),
    );
  }
}

// ─── Pressable Button ─────────────────────────────────────────────────────────
class _PressableBtn extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const _PressableBtn({required this.child, required this.onTap});

  @override
  State<_PressableBtn> createState() => _PressableBtnState();
}

class _PressableBtnState extends State<_PressableBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) { setState(() => _down = false); widget.onTap(); },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 140),
        child: AnimatedOpacity(
          opacity: _down ? 0.9 : 1.0,
          duration: const Duration(milliseconds: 140),
          child: widget.child,
        ),
      ),
    );
  }
}

// ─── Animated Background ──────────────────────────────────────────────────────
class _AnimatedBg extends StatelessWidget {
  final AnimationController bgCtrl;
  final AnimationController orbCtrl;
  final Animation<double> particleFade;
  const _AnimatedBg({
    required this.bgCtrl,
    required this.orbCtrl,
    required this.particleFade,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([bgCtrl, orbCtrl, particleFade]),
      builder: (_, __) => CustomPaint(
        painter: _BgPainter(bgCtrl.value, orbCtrl.value, particleFade.value),
      ),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  final double o;
  final double p;

  _BgPainter(this.t, this.o, this.p);

  @override
  void paint(Canvas canvas, Size size) {
    // Base gradient (Light)
    final bgPaint = Paint()
      ..shader = _C.softGrad.createShader(
          Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), bgPaint);

    // Grid subtle
    final grid = Paint()
      ..color = _C.border.withOpacity(0.3)
      ..strokeWidth = 0.5;
    const step = 45.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    // Aurora glow 1 — cyan
    final glow1 = Paint()
      ..shader = RadialGradient(
        colors: [
          _C.cyan.withOpacity(0.06 + math.sin(t * math.pi * 2) * 0.02),
          _C.violet.withOpacity(0.03),
          Colors.transparent,
        ],
        stops: const [0.0, 0.4, 0.8],
        radius: 0.85,
      ).createShader(Rect.fromCircle(
        center: Offset(size.width / 2, size.height * 0.25),
        radius: size.width * 0.85,
      ));
    canvas.drawCircle(
      Offset(size.width / 2, size.height * 0.25),
      size.width * 0.85,
      glow1,
    );

    // Aurora glow 2 — violet
    final glow2 = Paint()
      ..shader = RadialGradient(
        colors: [
          _C.violet.withOpacity(0.05 + math.sin(t * math.pi * 2 + 1) * 0.02),
          Colors.transparent,
        ],
        radius: 0.6,
      ).createShader(Rect.fromCircle(
        center: Offset(size.width * 0.2, size.height * 0.65),
        radius: size.width * 0.55,
      ));
    canvas.drawCircle(
      Offset(size.width * 0.2, size.height * 0.65),
      size.width * 0.55,
      glow2,
    );

    // Aurora glow 3 — magenta
    final glow3 = Paint()
      ..shader = RadialGradient(
        colors: [
          _C.magenta.withOpacity(0.04 + math.sin(t * math.pi * 2 + 2) * 0.02),
          Colors.transparent,
        ],
        radius: 0.6,
      ).createShader(Rect.fromCircle(
        center: Offset(size.width * 0.85, size.height * 0.75),
        radius: size.width * 0.55,
      ));
    canvas.drawCircle(
      Offset(size.width * 0.85, size.height * 0.75),
      size.width * 0.55,
      glow3,
    );

    // Moving orb
    final angle = o * math.pi * 2;
    final orbX = size.width / 2 + math.cos(angle) * size.width * 0.32;
    final orbY = size.height * 0.25 + math.sin(angle * 0.7) * 80;

    final orbGlow = Paint()
      ..shader = RadialGradient(
        colors: [
          _C.cyan.withOpacity(0.08 * p),
          _C.cyan.withOpacity(0.03 * p),
          Colors.transparent,
        ],
        radius: 0.5,
      ).createShader(Rect.fromCircle(center: Offset(orbX, orbY), radius: 120));
    canvas.drawCircle(Offset(orbX, orbY), 120, orbGlow);

    // Particle dots
    for (int i = 0; i < 5; i++) {
      final a = angle + (i * 1.256);
      final dx = size.width / 2 + math.cos(a) * size.width * 0.28;
      final dy = size.height * 0.35 + math.sin(a * 0.9) * 140;
      final dot = Paint()
        ..color = _C.cyan.withOpacity(0.15 * p)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(dx, dy), 3 + math.sin(t * 4 + i) * 2, dot);
    }
  }

  @override
  bool shouldRepaint(_BgPainter old) =>
      old.t != t || old.o != o || old.p != p;
}