// ═══════════════════════════════════════════════════════════════════════
// FILE: setoran_verifikasi_page.dart
// Panel owner/developer: lihat daftar setoran + ACC/Tolak
// ═══════════════════════════════════════════════════════════════════════

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:Fiona/Qaxer/.dart';

final _verifBaseUrl = Api.api;

class SetoranVerifikasiPage extends StatefulWidget {
  final String sessionKey;
  final String ownerUsername;

  const SetoranVerifikasiPage({
    super.key,
    required this.sessionKey,
    required this.ownerUsername,
  });

  @override
  State<SetoranVerifikasiPage> createState() => _SetoranVerifikasiPageState();
}

class _SetoranVerifikasiPageState extends State<SetoranVerifikasiPage> {
  List<dynamic> _pendingList = [];
  bool _isLoading = true;

  // LIGHT THEME
  static const bg = Color(0xFFF5F9FF);
  static const surface = Color(0xFFFFFFFF);
  static const card = Color(0xFFFFFFFF);
  static const border = Color(0xFFD6E4F5);
  static const primary = Color(0xFF2563EB);
  static const accent = Color(0xFF3B82F6);
  static const text = Color(0xFF0F172A);
  static const textSub = Color(0xFF475569);
  static const danger = Color(0xFFEF4444);
  static const warning = Color(0xFFF59E0B);
  static const success = Color(0xFF10B981);

  @override
  void initState() {
    super.initState();
    _fetchPending();
  }

  Future<void> _fetchPending() async {
    setState(() => _isLoading = true);
    try {
      final res = await http.get(Uri.parse(
        "$_verifBaseUrl/listSetoran?key=${widget.sessionKey}&status=pending",
      ));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        setState(() => _pendingList = data['setoran'] ?? []);
      } else {
        debugPrint("Invalid response: ${data['message']}");
      }
    } catch (e) {
      debugPrint("Error: $e");
    }
    if (mounted) setState(() => _isLoading = false);
  }

  Future<void> _accSetoran(Map item) async {
    final reqId = item['requestId'];
    final confirm = await _confirmDialog(
      "ACC Setoran",
      "Setujui setoran $reqId?\nAkun '${item['newUsername']}' akan dibuat otomatis.",
    );
    if (confirm != true) return;

    setState(() => _isLoading = true);
    try {
      final res = await http.get(Uri.parse(
        "$_verifBaseUrl/accSetoran?key=${widget.sessionKey}"
        "&requestId=$reqId"
        "&username=${item['newUsername']}"
        "&password=${item['newPassword']}"
        "&day=${item['durasiHari']}"
        "&role=${item['newUserRole']}",
      ));
      final data = jsonDecode(res.body);
      if (data['approved'] == true) {
        _alert("✅ Sukses", "Setoran di-ACC & akun dibuat.");
        _fetchPending();
      } else {
        _alert("❌ Gagal", data['message'] ?? "Gagal ACC setoran.");
      }
    } catch (e) {
      _alert("Error", "Koneksi gagal: $e");
    }
    if (mounted) setState(() => _isLoading = false);
  }

  Future<void> _rejectSetoran(Map item) async {
    final reqId = item['requestId'];
    final confirm =
        await _confirmDialog("Tolak Setoran", "Tolak setoran $reqId?");
    if (confirm != true) return;

    setState(() => _isLoading = true);
    try {
      final res = await http.get(Uri.parse(
        "$_verifBaseUrl/rejectSetoran?key=${widget.sessionKey}&requestId=$reqId",
      ));
      final data = jsonDecode(res.body);
      if (data['rejected'] == true) {
        _alert("❌ Ditolak", "Setoran telah ditolak.");
        _fetchPending();
      } else {
        _alert("Gagal", data['message'] ?? "Gagal menolak setoran.");
      }
    } catch (e) {
      _alert("Error", "Koneksi gagal: $e");
    }
    if (mounted) setState(() => _isLoading = false);
  }

  Future<bool?> _confirmDialog(String title, String msg) {
    return showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: accent.withOpacity(0.3)),
        ),
        title: Text(title, style: const TextStyle(color: text)),
        content: Text(msg, style: const TextStyle(color: textSub)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text("Batal", style: TextStyle(color: textSub)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text("Ya", style: TextStyle(color: primary)),
          ),
        ],
      ),
    );
  }

  void _alert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: accent.withOpacity(0.3)),
        ),
        title: Text(title, style: const TextStyle(color: text)),
        content: Text(msg, style: const TextStyle(color: textSub)),
        actions: [
          Center(
            child: TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("OK", style: TextStyle(color: primary)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildItem(Map item) {
    final status = item['status'] ?? 'pending';
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: status == 'pending' ? warning.withOpacity(0.4) : border,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: warning.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child:
                    const Icon(Icons.receipt_long, color: warning, size: 16),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item['requestId'] ?? '-',
                        style: const TextStyle(
                          color: text,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Ready',
                        )),
                    Text(
                        "Dari: ${item['creatorUsername']} (${item['creatorRole']})",
                        style: const TextStyle(
                            color: textSub, fontSize: 11)),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: status == 'pending'
                      ? warning.withOpacity(0.1)
                      : success.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: status == 'pending'
                        ? warning.withOpacity(0.3)
                        : success.withOpacity(0.3),
                  ),
                ),
                child: Text(
                  status.toUpperCase(),
                  style: TextStyle(
                    color: status == 'pending' ? warning : success,
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ],
          ),
          const Divider(color: border, height: 20),
          _row("Username", item['newUsername'] ?? '-'),
          _row("Role",
              (item['newUserRole'] ?? '-').toString().toUpperCase()),
          _row("Durasi", "${item['durasiHari']} hari"),
          _row("Harga", "Rp ${item['harga']}"),
          const SizedBox(height: 6),
          const Divider(color: border, height: 20),
          _row("Pengirim", item['namaPengirim'] ?? '-'),
          _row("Jumlah Transfer", "Rp ${item['jumlahTransfer']}"),
          _row("Waktu", _fmtDate(item['createdAt'])),

          if (status == 'pending') ...[
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: danger,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    onPressed: () => _rejectSetoran(item),
                    icon: const Icon(Icons.close,
                        color: Colors.white, size: 16),
                    label: const Text("TOLAK",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        )),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: primary,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    onPressed: () => _accSetoran(item),
                    icon: const Icon(Icons.check,
                        color: Colors.white, size: 16),
                    label: const Text("ACC & BUAT",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        )),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          SizedBox(
            width: 110,
            child: Text(label,
                style: const TextStyle(color: textSub, fontSize: 11)),
          ),
          Expanded(
            child: Text(value,
                style: const TextStyle(
                    color: text,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'Ready')),
          ),
        ],
      ),
    );
  }

  String _fmtDate(dynamic iso) {
    if (iso == null) return '-';
    try {
      final dt = DateTime.parse(iso.toString()).toLocal();
      return "${dt.day}/${dt.month}/${dt.year} "
          "${dt.hour.toString().padLeft(2, '0')}:"
          "${dt.minute.toString().padLeft(2, '0')}";
    } catch (_) {
      return iso.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: surface,
        elevation: 0,
        iconTheme: const IconThemeData(color: text),
        title: const Text("VERIFIKASI SETORAN",
            style: TextStyle(
              color: text,
              fontWeight: FontWeight.bold,
              fontSize: 14,
              letterSpacing: 2,
            )),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: primary),
            onPressed: _fetchPending,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: primary))
          : _pendingList.isEmpty
              ? const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(FontAwesomeIcons.inbox, color: textSub, size: 60),
                      SizedBox(height: 14),
                      Text("Belum ada setoran masuk",
                          style: TextStyle(color: textSub)),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _fetchPending,
                  color: primary,
                  backgroundColor: card,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: _pendingList.length,
                    itemBuilder: (_, i) => _buildItem(_pendingList[i]),
                  ),
                ),
    );
  }
}