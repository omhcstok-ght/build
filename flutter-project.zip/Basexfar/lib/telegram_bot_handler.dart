// ═══════════════════════════════════════════════════════════════════════
// FILE: telegram_bot_handler.dart
// Listener bot Telegram: handle klik tombol ACC / Tolak
// ═══════════════════════════════════════════════════════════════════════

import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'setoran_config.dart';

class TelegramBotHandler {
  static int _lastUpdateId = 0;
  static Timer? _timer;
  static bool _isRunning = false;

  /// Callback saat ACC berhasil
  static Function(String requestId)? onAccept;

  /// Callback saat Tolak berhasil
  static Function(String requestId)? onReject;

  /// Callback untuk log / debug
  static Function(String message)? onLog;

  static void _log(String msg) {
    debugPrint("[TelegramBot] $msg");
    onLog?.call(msg);
  }

  // ═════════════════════════════════════════════════════════════════
  // START / STOP
  // ═════════════════════════════════════════════════════════════════
  static void start() {
    if (_isRunning) return;
    _isRunning = true;
    _log("Bot handler started");
    _poll();
  }

  static void stop() {
    _isRunning = false;
    _timer?.cancel();
    _log("Bot handler stopped");
  }

  // ═════════════════════════════════════════════════════════════════
  // POLLING
  // ═════════════════════════════════════════════════════════════════
  static void _poll() {
    if (!_isRunning) return;
    _timer = Timer(
      Duration(seconds: SetoranConfig.pollingIntervalSeconds),
      () async {
        await _checkUpdates();
        _poll();
      },
    );
  }

  static Future<void> _checkUpdates() async {
    try {
      final res = await http.get(Uri.parse(
        "${SetoranConfig.telegramApi}/getUpdates?offset=${_lastUpdateId + 1}&timeout=2",
      )).timeout(const Duration(seconds: 10));

      final data = jsonDecode(res.body);
      if (data['ok'] != true) return;

      final updates = data['result'] as List;
      for (final u in updates) {
        _lastUpdateId = u['update_id'];

        // Handle callback_query (klik tombol inline)
        final cb = u['callback_query'];
        if (cb != null) {
          await _handleCallback(cb);
        }
      }
    } catch (e) {
      _log("Poll error: $e");
    }
  }

  // ═════════════════════════════════════════════════════════════════
  // HANDLE CALLBACK
  // ═════════════════════════════════════════════════════════════════
  static Future<void> _handleCallback(dynamic cb) async {
    try {
      final callbackData = cb['data'] as String;
      final callbackId = cb['id'];
      final msgId = cb['message']['message_id'];
      final chatId = cb['message']['chat']['id'];
      final originalCaption = cb['message']['caption'] ??
          cb['message']['text'] ??
          '';

      _log("Callback: $callbackData");

      if (callbackData.startsWith("acc:")) {
        final requestId = callbackData.substring(4);
        await _handleAccept(
          requestId, callbackId, msgId, chatId, originalCaption,
        );
      } else if (callbackData.startsWith("reject:")) {
        final requestId = callbackData.substring(7);
        await _handleReject(
          requestId, callbackId, msgId, chatId, originalCaption,
        );
      } else if (callbackData.startsWith("detail:")) {
        final requestId = callbackData.substring(7);
        await _answerCallback(callbackId, "Request ID: $requestId");
      }
    } catch (e) {
      _log("Handle callback error: $e");
    }
  }

  // ═════════════════════════════════════════════════════════════════
  // HANDLE ACCEPT
  // ═════════════════════════════════════════════════════════════════
  static Future<void> _handleAccept(
    String requestId,
    String callbackId,
    int msgId,
    int chatId,
    String originalCaption,
  ) async {
    await _answerCallback(callbackId, "⏳ Memproses ACC...");

    bool success = false;
    String message = "";

    try {
      final res = await http.get(Uri.parse(
        "${SetoranConfig.backendUrl}/accSetoran"
        "?key=${SetoranConfig.botSystemKey}"
        "&requestId=$requestId",
      )).timeout(const Duration(seconds: 15));

      final data = jsonDecode(res.body);
      success = data['approved'] == true;
      message = data['message'] ?? (success ? "Akun berhasil dibuat" : "Gagal");
    } catch (e) {
      message = "Error koneksi: $e";
      _log("ACC error: $e");
    }

    final newCaption = "$originalCaption\n\n"
        "${success ? '✅ *DITERIMA*' : '❌ *GAGAL*'}\n"
        "_$message_";

    await _editMessageCaption(
      chatId: chatId,
      messageId: msgId,
      caption: newCaption,
      removeButtons: true,
    );

    if (success) {
      _log("Request $requestId berhasil di-ACC");
      onAccept?.call(requestId);
    } else {
      _log("Request $requestId gagal di-ACC: $message");
    }
  }

  // ═════════════════════════════════════════════════════════════════
  // HANDLE REJECT
  // ═════════════════════════════════════════════════════════════════
  static Future<void> _handleReject(
    String requestId,
    String callbackId,
    int msgId,
    int chatId,
    String originalCaption,
  ) async {
    await _answerCallback(callbackId, "⏳ Menolak setoran...");

    bool success = false;
    String message = "";

    try {
      final res = await http.get(Uri.parse(
        "${SetoranConfig.backendUrl}/rejectSetoran"
        "?key=${SetoranConfig.botSystemKey}"
        "&requestId=$requestId",
      )).timeout(const Duration(seconds: 15));

      final data = jsonDecode(res.body);
      success = data['rejected'] == true;
      message = data['message'] ?? (success ? "Setoran ditolak" : "Gagal menolak");
    } catch (e) {
      message = "Error koneksi: $e";
      _log("Reject error: $e");
    }

    final newCaption = "$originalCaption\n\n"
        "❌ *DITOLAK*\n"
        "_$message_";

    await _editMessageCaption(
      chatId: chatId,
      messageId: msgId,
      caption: newCaption,
      removeButtons: true,
    );

    if (success) {
      _log("Request $requestId ditolak");
      onReject?.call(requestId);
    }
  }

  // ═════════════════════════════════════════════════════════════════
  // TELEGRAM API HELPERS
  // ═════════════════════════════════════════════════════════════════
  static Future<void> _answerCallback(String callbackId, String text) async {
    try {
      await http.post(
        Uri.parse("${SetoranConfig.telegramApi}/answerCallbackQuery"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "callback_query_id": callbackId,
          "text": text,
          "show_alert": false,
        }),
      ).timeout(const Duration(seconds: 10));
    } catch (e) {
      _log("Answer callback error: $e");
    }
  }

  static Future<void> _editMessageCaption({
    required int chatId,
    required int messageId,
    required String caption,
    bool removeButtons = false,
  }) async {
    try {
      final body = {
        "chat_id": chatId,
        "message_id": messageId,
        "caption": caption,
        "parse_mode": "Markdown",
      };
      if (removeButtons) {
        body["reply_markup"] = jsonEncode({"inline_keyboard": []});
      }

      await http.post(
        Uri.parse("${SetoranConfig.telegramApi}/editMessageCaption"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(body),
      ).timeout(const Duration(seconds: 10));
    } catch (e) {
      _log("Edit caption error: $e");
    }
  }

  // ═════════════════════════════════════════════════════════════════
  // RESET (untuk debugging)
  // ═════════════════════════════════════════════════════════════════
  static void resetOffset() {
    _lastUpdateId = 0;
    _log("Offset direset");
  }
}