import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';

class AudioManager extends ChangeNotifier {
  static final AudioManager _instance = AudioManager._internal();
  factory AudioManager() => _instance;
  AudioManager._internal();

  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isPlaying = false;
  bool _initialized = false;
  bool _isSourceLoaded = false; // ✅ TAMBAHAN: Cek apakah file mp3 sudah di-load

  bool get isPlaying => _isPlaying;
  bool get isInitialized => _initialized;

  Future<void> init() async {
    // Jika sudah di-load dan sedang main, langsung keluar
    if (_initialized && _isPlaying) return; 
    
    try {
      // ✅ 1. ATUR AUDIO CONTEXT (Hanya perlu di-set sekali)
      if (!_initialized) {
        await _audioPlayer.setAudioContext(
          AudioContext(
            android: const AudioContextAndroid(
              isSpeakerphoneOn: true,
              audioMode: AndroidAudioMode.normal,
              stayAwake: true,
              contentType: AndroidContentType.music,
              usageType: AndroidUsageType.media,
              audioFocus: AndroidAudioFocus.none, // 👈 Kunci utama anti-bentrok
            ),
            iOS: AudioContextIOS(
              category: AVAudioSessionCategory.playback,
              options: {
                AVAudioSessionOptions.mixWithOthers,
                AVAudioSessionOptions.duckOthers,
              },
            ),
          ),
        );
      }

      // ✅ 2. LOAD FILE HANYA SEKALI SAJA (Sangat menghemat RAM & CPU)
      if (!_isSourceLoaded) {
        await _audioPlayer.setSource(AssetSource('audio/breakbeat_dream.mp3'));
        await _audioPlayer.setVolume(0.3); 
        await _audioPlayer.setReleaseMode(ReleaseMode.loop);
        _isSourceLoaded = true;
      }
      
      // ✅ 3. Mainkan / Lanjutkan
      await _audioPlayer.resume();
      _isPlaying = true;
      _initialized = true;
      notifyListeners();
      
    } catch (e) {
      debugPrint('Gagal memuat audio: $e');
      _isPlaying = false;
      _initialized = true;
      notifyListeners();
    }
  }

  Future<void> togglePlay() async {
    if (_isPlaying) {
      await _audioPlayer.pause();
      _isPlaying = false;
    } else {
      // Jika belum pernah init, panggil init(). 
      // Jika sudah init, cukup resume tanpa memuat ulang file.
      if (!_initialized) {
        await init();
        return;
      }
      await _audioPlayer.resume();
      _isPlaying = true;
    }
    notifyListeners();
  }

  Future<void> stop() async {
    try {
      await _audioPlayer.stop();
      // Jika di-stop, kita harus reset status load-nya 
      // agar saat init() dipanggil lagi, dia mau nge-load ulang
      _isSourceLoaded = false; 
    } catch (_) {}
    _isPlaying = false;
    notifyListeners();
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }
}