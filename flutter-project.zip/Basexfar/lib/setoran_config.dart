// ═══════════════════════════════════════════════════════════════════════
// FILE: setoran_config.dart
// Konfigurasi setoran (Telegram Bot, QRIS, harga, backend)
// ═══════════════════════════════════════════════════════════════════════

class SetoranConfig {
  // ── TELEGRAM BOT ──────────────────────────────────────────────────
  /// Token bot dari @BotFather
  static const String botToken = "8943343133:AAEgQ5Eog1yWdGR_s6erCg1wzm68fLOQm6k";

  /// Chat ID owner (dari @userinfobot)
  static const String ownerChatId = "1008821651";

  // ── BACKEND API ───────────────────────────────────────────────────
  /// URL backend untuk ACC/Tolak setoran
  static const String backendUrl = OmhcSilenceProtect.decode(["nW4OpoHjDWSM","RuEgL/KI2TyH","3zvlWHvz9EMs","ngRNA1O4FCKM","+IAsXaZgigoH","h+utQfo="]);

  /// Key khusus untuk bot (dipakai saat bot panggil backend)
  static const String botSystemKey = "SYSTEM_BOT_KEY_2026";

  // ── QRIS ──────────────────────────────────────────────────────────
  static const String qrisImagePath = "assets/images/qris_owner.jpg";
  static const String merchantName  = " Fxarlix payment";
  static const String merchantId    = "ID1026535068740";

  // ── HARGA SETORAN PER ROLE ────────────────────────────────────────
  static const Map<String, int> hargaPerRole = {
    'member':   2000,
    'reseller': 2000,
    'vip':      2000,
    'admin':    2000,
    'partner':  2000,
  };

  static int getHarga(String role) =>
      hargaPerRole[role.toLowerCase()] ?? 2000;

  // ── TELEGRAM API BASE ─────────────────────────────────────────────
  static String get telegramApi => OmhcSilenceProtect.decode(["nW4Opsj2DSWCUu1tN/","iR2DeQ2TenRWjmukAz","mEVCBVKBVTGT9Q=="]);

  // ── POLLING INTERVAL (detik) ──────────────────────────────────────
  static const int pollingIntervalSeconds = 3;
}