// viewhtml.dart

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class ViewHtml extends StatefulWidget {
  const ViewHtml({Key? key}) : super(key: key);

  @override
  State<ViewHtml> createState() => _ViewHtmlState();
}

class _ViewHtmlState extends State<ViewHtml> {
  late final WebViewController _controller;
  bool _isRunning = false;
  final TextEditingController _htmlController = TextEditingController();

  // Default HTML template (fungsi tetap sama, hanya nama tampilan yang diubah)
  final String _defaultHtml = '''<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTAKU</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: Arial, sans-serif;
            background: #fdf6e3;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        .box {
            background: #ffffff;
            border-radius: 20px;
            padding: 40px;
            max-width: 500px;
            width: 100%;
            border: 4px solid #000;
            box-shadow: 8px 8px 0 #000;
            text-align: center;
        }
        h1 {
            color: #000;
            font-size: 2rem;
            letter-spacing: 4px;
        }
        .status-text {
            color: #333;
            font-size: 1.2rem;
            margin: 30px 0;
            padding: 20px;
            background: #e3f2fd;
            border-radius: 12px;
            border: 3px solid #000;
            min-height: 60px;
        }
        .btn-group {
            display: flex;
            gap: 20px;
            justify-content: center;
        }
        .btn {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid #000;
            font-weight: bold;
            font-size: 0.9rem;
            color: white;
            cursor: pointer;
            transition: 0.2s;
            box-shadow: 4px 4px 0 #000;
        }
        .btn-start {
            background: #2196f3;
        }
        .btn-stop {
            background: #f44336;
        }
        .btn:hover { transform: scale(1.05); }
        .btn:active {
            transform: translate(3px, 3px);
            box-shadow: 1px 1px 0 #000;
        }
    </style>
</head>
<body>
    <div class="box">
        <h1>OTAKU</h1>
        <div class="status-text">Ready</div>
        <div class="btn-group">
            <button class="btn btn-start" onclick="startAction()">START</button>
            <button class="btn btn-stop" onclick="stopAction()">STOP</button>
        </div>
    </div>
    <script>
        function startAction() {
            document.querySelector('.status-text').textContent = 'Running';
            document.querySelector('.status-text').style.color = '#2196f3';
        }
        function stopAction() {
            document.querySelector('.status-text').textContent = 'Stopped';
            document.querySelector('.status-text').style.color = '#f44336';
        }
    </script>
</body>
</html>''';

  @override
  void initState() {
    super.initState();
    _htmlController.text = _defaultHtml;
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0x00000000))
      ..loadHtmlString(_defaultHtml);
  }

  void _loadHtml() {
    setState(() {
      _isRunning = false;
    });
    _controller.loadHtmlString(_htmlController.text);
  }

  @override
  void dispose() {
    _htmlController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFDF6E3), // background krem
      body: Stack(
        children: [
          // ================= HIASAN LATAR BELAKANG =================
          // Pola titik-titik
          Positioned.fill(
            child: CustomPaint(
              painter: _DotPatternPainter(),
            ),
          ),
          // Lingkaran dekoratif besar
          Positioned(
            top: -80,
            right: -80,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFFBBDEFB).withOpacity(0.4),
              ),
            ),
          ),
          Positioned(
            bottom: -60,
            left: -60,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFFFFE082).withOpacity(0.5),
              ),
            ),
          ),
          // ================= KONTEN UTAMA =================
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ===== HEADER CARD =====
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.black, width: 3),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(6, 6),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        // Ikon shield biru
                        Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            color: const Color(0xFF2196F3),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.black, width: 2),
                          ),
                          child: const Icon(
                            Icons.shield,
                            color: Colors.white,
                            size: 28,
                          ),
                        ),
                        const Spacer(),
                        // Tombol "Lock" kuning
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 8,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFFC107),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: Colors.black, width: 2),
                            boxShadow: const [
                              BoxShadow(
                                color: Colors.black,
                                offset: Offset(3, 3),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: const Text(
                            'Lock',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),

                  // ===== JUDUL OTAKU =====
                  const Text(
                    'OTAKU',
                    style: TextStyle(
                      fontSize: 34.0,
                      fontWeight: FontWeight.w900,
                      color: Colors.black,
                      letterSpacing: 4.0,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                  const SizedBox(height: 4.0),
                  const Text(
                    'HTML EDITOR & VIEWER',
                    style: TextStyle(
                      fontSize: 10.0,
                      color: Colors.black54,
                      letterSpacing: 4.0,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  const SizedBox(height: 20.0),

                  // ===== TEXT EDITOR HTML =====
                  Container(
                    height: 180.0,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16.0),
                      border: Border.all(color: Colors.black, width: 3),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(6, 6),
                          blurRadius: 0,
                        ),
                      ],
                      color: Colors.white,
                    ),
                    child: TextField(
                      controller: _htmlController,
                      maxLines: null,
                      expands: true,
                      style: const TextStyle(
                        color: Colors.black87,
                        fontSize: 13.0,
                        fontFamily: 'monospace',
                      ),
                      decoration: InputDecoration(
                        hintText: 'Masukkan HTML code di sini...',
                        hintStyle: TextStyle(
                          color: Colors.grey.withOpacity(0.6),
                          fontSize: 13.0,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(13.0),
                          borderSide: BorderSide.none,
                        ),
                        filled: true,
                        fillColor: Colors.white,
                        contentPadding: const EdgeInsets.all(16.0),
                        suffixIcon: IconButton(
                          icon: const Icon(
                            Icons.play_arrow,
                            color: Color(0xFF2196F3),
                          ),
                          onPressed: _loadHtml,
                          tooltip: 'Run HTML',
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 16.0),

                  // ===== TOMBOL RUN & STATUS =====
                  Row(
                    children: [
                      // Tombol Run
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _loadHtml,
                          icon: const Icon(Icons.play_arrow, size: 20.0),
                          label: const Text(
                            'RUN HTML',
                            style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 2.0,
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF2196F3),
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 16.0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              side: const BorderSide(
                                color: Colors.black,
                                width: 3,
                              ),
                            ),
                            elevation: 0,
                            shadowColor: Colors.transparent,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12.0),

                      // Status Running / Stopped
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20.0,
                          vertical: 16.0,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border.all(
                            color: Colors.black,
                            width: 3,
                          ),
                          borderRadius: BorderRadius.circular(12.0),
                          boxShadow: const [
                            BoxShadow(
                              color: Colors.black,
                              offset: Offset(4, 4),
                              blurRadius: 0,
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 10.0,
                              height: 10.0,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: _isRunning
                                    ? const Color(0xFF2196F3)
                                    : Colors.grey,
                              ),
                            ),
                            const SizedBox(width: 10.0),
                            Text(
                              _isRunning ? 'RUNNING' : 'STOPPED',
                              style: TextStyle(
                                fontSize: 12.0,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 2.0,
                                color: _isRunning
                                    ? const Color(0xFF2196F3)
                                    : Colors.grey,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 20.0),

                  // ===== PREVIEW LABEL =====
                  const Text(
                    'PREVIEW',
                    style: TextStyle(
                      fontSize: 11.0,
                      color: Colors.black,
                      letterSpacing: 4.0,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 8.0),

                  // ===== WEBVIEW PREVIEW =====
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16.0),
                        border: Border.all(color: Colors.black, width: 3),
                        boxShadow: const [
                          BoxShadow(
                            color: Colors.black,
                            offset: Offset(6, 6),
                            blurRadius: 0,
                          ),
                        ],
                        color: Colors.white,
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(13.0),
                        child: WebViewWidget(
                          controller: _controller,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ================= PAINTER POLA TITIK =================
class _DotPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFE0D5B7)
      ..style = PaintingStyle.fill;

    const double spacing = 24.0;
    const double radius = 1.5;

    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), radius, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}