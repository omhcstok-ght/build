import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:ui';
import 'dart:math' as math;

// ========== THEME: HITAM-BIRU KEREN ==========
class WaColors {
  static const Color bgDeep = Color(0xFFDFF7E8);
  static const Color bgCard = Color(0xFFF1FFF6);
  static const Color bgSurface = Color(0xFFF1FFF6);
  static const Color accent = Color(0xFF168A4A);
  static const Color accentDeep = Color(0xFF126B3A);
  static const Color accentGlow = Color(0xFF168A4A);
  static const Color accentSoft = Color(0xFFDFF7E8);
  static const Color textMuted = Colors.black54;
  static const Color textSubtle = Colors.black54;
  static const Color border = Color(0xFFB7DEC6);
  static const Color textPrimary = Colors.black87;
  static const Color successGreen = Color(0xFF168A4A);
  static const Color errorRed = Color(0xFFD32F2F);
}

class SmtpSender {
  final String id;
  final String email;
  final String server;
  final String port;
  final bool useSSL;
  final int successCount;
  final int failCount;

  SmtpSender({
    required this.id,
    required this.email,
    required this.server,
    required this.port,
    required this.useSSL,
    required this.successCount,
    required this.failCount,
  });

  factory SmtpSender.fromJson(Map<String, dynamic> json) {
    return SmtpSender(
      id: json['id'],
      email: json['email'],
      server: json['server'] ?? 'smtp.gmail.com',
      port: json['port'] ?? '587',
      useSSL: json['useSSL'] ?? false,
      successCount: json['successCount'] ?? 0,
      failCount: json['failCount'] ?? 0,
    );
  }
}

class ReportWaPage extends StatefulWidget {
  final String username;

  const ReportWaPage({
    super.key,
    required this.username,
    required String sessionKey,
    required String role,
  });

  @override
  State<ReportWaPage> createState() => _ReportWaPageState();
}

class _ReportWaPageState extends State<ReportWaPage> with TickerProviderStateMixin {
  static const String baseUrl = "http://root.cloudnesia.my.id:3002/api";

  // Animation controllers
  late AnimationController _pulseController;
  late AnimationController _glowController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _glowAnimation;

  // Controllers
  final TextEditingController _targetController = TextEditingController();
  final TextEditingController _amountController = TextEditingController(text: '50');
  final ScrollController _logScrollController = ScrollController();

  // State variables
  bool _isAttacking = false;
  bool _isLoading = false;
  bool _stealthMode = true;
  List<String> _logs = [];
  Timer? _attackTimer;
  
  // Senders
  List<SmtpSender> _availableSenders = [];
  Set<String> _selectedSenderIds = {};
  
  // Stats
  int _totalReportsSent = 0;
  int _totalReportsFailed = 0;
  int _activeSenders = 0;
  
  // Active report
  String? _activeReportId;
  int _progressCurrent = 0;
  int _progressTotal = 0;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _loadSenders();
    _loadStats();
    _startPolling();
  }

  void _initializeAnimations() {
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _pulseAnimation = Tween<double>(begin: 0.95, end: 1.05).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _glowAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _glowController.dispose();
    _targetController.dispose();
    _amountController.dispose();
    _logScrollController.dispose();
    _attackTimer?.cancel();
    super.dispose();
  }

  // ==================== API CALLS ====================
  Future<void> _loadSenders() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/wa/senders/${widget.username}'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          setState(() {
            _availableSenders = (data['senders'] as List)
                .map((s) => SmtpSender.fromJson(s))
                .toList();
          });
        }
      }
    } catch (e) {
      debugPrint('Error loading senders: $e');
    }
  }

  Future<void> _loadStats() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/wa/report/stats/${widget.username}'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          setState(() {
            _activeSenders = data['stats']['senders']['active'] ?? 0;
            _totalReportsSent = data['stats']['reports']['sent'] ?? 0;
            _totalReportsFailed = data['stats']['reports']['failed'] ?? 0;
            
            if (data['stats']['activeReport'] != null) {
              _isAttacking = true;
              _activeReportId = data['stats']['activeReport']['id'];
              _progressCurrent = data['stats']['activeReport']['progress'];
              _progressTotal = data['stats']['activeReport']['total'];
            }
          });
        }
      }
    } catch (e) {
      debugPrint('Error loading stats: $e');
    }
  }

  void _startPolling() {
    Timer.periodic(const Duration(seconds: 2), (timer) {
      if (_isAttacking) {
        _loadStats();
      }
    });
  }

  // ==================== ATTACK LOGIC ====================
  Future<void> _toggleAttack() async {
    if (_isAttacking) {
      await _stopAttack();
    } else {
      await _startAttack();
    }
  }

  Future<void> _startAttack() async {
    if (_targetController.text.isEmpty) {
      _showAlert("⚠️ INPUT ERROR", "Target number cannot be empty!");
      return;
    }

    if (_selectedSenderIds.isEmpty) {
      _showAlert("⚠️ SENDER ERROR", "Please select at least one SMTP sender!");
      return;
    }

    final amount = int.tryParse(_amountController.text) ?? 50;
    if (amount < 1 || amount > 500) {
      _showAlert("⚠️ AMOUNT ERROR", "Report amount must be 1-500!");
      return;
    }

    setState(() {
      _isLoading = true;
      _logs.clear();
      _logs.add("[SYSTEM] ⚡ Initializing WhatsApp Report Protocol...");
      _logs.add("[SYSTEM] 🎯 Target: ${_targetController.text}");
      _logs.add("[SYSTEM] 📡 Using ${_selectedSenderIds.length} SMTP senders...");
      _logs.add("[SYSTEM] 🔗 Connecting to WhatsApp servers...");
    });

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/wa/report/send'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': widget.username,
          'targetNumber': _targetController.text.trim(),
          'amount': amount,
          'selectedSenderIds': _selectedSenderIds.toList(),
          'stealthMode': _stealthMode,
        }),
      );

      final data = jsonDecode(response.body);

      if (data['success'] == true) {
        setState(() {
          _isAttacking = true;
          _progressTotal = amount;
          _activeReportId = data['reportId'];
          _logs.add("[SYSTEM] ✅ Report bomb started with ${data['stats']['totalSenders']} senders");
        });
      } else {
        _logs.add("[SYSTEM] ❌ Failed: ${data['message']}");
        _showAlert("❌ ERROR", data['message'] ?? 'Failed to start');
      }
    } catch (e) {
      _logs.add("[SYSTEM] ❌ Connection error: $e");
      _showAlert("❌ ERROR", "Failed to connect to server");
    }

    setState(() => _isLoading = false);
  }

  Future<void> _stopAttack() async {
    if (_activeReportId == null) {
      setState(() => _isAttacking = false);
      _logs.add("[SYSTEM] 🛑 Process terminated");
      return;
    }

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/wa/report/stop/$_activeReportId'),
      );

      final data = jsonDecode(response.body);

      if (data['success'] == true) {
        setState(() {
          _isAttacking = false;
          _activeReportId = null;
          _progressCurrent = 0;
          _logs.add("[SYSTEM] 🛑 Report stopped by user");
          _logs.add("[SYSTEM] 🔌 Disconnected");
        });
      }
    } catch (e) {
      debugPrint('Error stopping report: $e');
    }
  }

  void _showAlert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: WaColors.bgDeep,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: WaColors.border.withOpacity(0.3), width: 1),
        ),
        title: Text(title, style: TextStyle(color: WaColors.accent, fontFamily: 'Orbitron')),
        content: Text(message, style: const TextStyle(color: WaColors.textMuted, fontFamily: 'ShareTechMono')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: WaColors.accent)),
          ),
        ],
      ),
    );
  }

  // ==================== UI BUILDERS ====================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WaColors.bgDeep,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: WaColors.bgDeep,
        elevation: 0,
        automaticallyImplyLeading: false,
        flexibleSpace: ClipRRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(color: WaColors.accent.withOpacity(0.5)),
          ),
        ),
        leading: Container(
          margin: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [WaColors.bgCard, WaColors.bgCard],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: WaColors.border.withOpacity(0.3)),
          ),
          child: IconButton(
            icon: const Icon(Icons.arrow_back, color: WaColors.textPrimary),
            onPressed: () => Navigator.pop(context),
          ),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [WaColors.bgCard, WaColors.bgCard],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                FontAwesomeIcons.whatsapp,
                color: WaColors.textPrimary,
                size: 18,
              ),
            ),
            const SizedBox(width: 12),
            const Text(
              'WHATSAPP REPORT',
              style: TextStyle(
                color: WaColors.textPrimary,
                fontSize: 18,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
                letterSpacing: 1,
              ),
            ),
          ],
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: WaColors.accent.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: WaColors.border.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Icon(Icons.check_circle, color: WaColors.accent, size: 12),
                const SizedBox(width: 4),
                Text(
                  '$_activeSenders Active',
                  style: const TextStyle(color: WaColors.textPrimary, fontSize: 11),
                ),
              ],
            ),
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topRight,
            radius: 1.5,
            colors: [WaColors.bgCard.withOpacity(0.1), WaColors.bgCard],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Column(
              children: [
                _buildStatsBar(),

                const SizedBox(height: 16),

                _buildInputCard(),

                const SizedBox(height: 16),

                _buildSenderSection(),

                const SizedBox(height: 20),

                _buildActionButton(),

                const SizedBox(height: 20),

                Expanded(child: _buildTerminalLogs()),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatsBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: WaColors.accent.withOpacity(0.5),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: WaColors.border.withOpacity(0.2)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildStatItem(
            icon: Icons.send,
            label: 'SENT',
            value: '$_totalReportsSent',
            color: WaColors.accent,
          ),
          Container(width: 1, height: 20, color: WaColors.accent.withOpacity(0.3)),
          _buildStatItem(
            icon: Icons.error,
            label: 'FAILED',
            value: '$_totalReportsFailed',
            color: WaColors.accent,
          ),
          Container(width: 1, height: 20, color: WaColors.accent.withOpacity(0.3)),
          _buildStatItem(
            icon: Icons.speed,
            label: 'RATE',
            value: _totalReportsSent + _totalReportsFailed > 0
                ? '${((_totalReportsSent / (_totalReportsSent + _totalReportsFailed)) * 100).toStringAsFixed(0)}%'
                : '0%',
            color: WaColors.accent,
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Row(
      children: [
        Icon(icon, color: color, size: 14),
        const SizedBox(width: 4),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(color: WaColors.accent, fontSize: 9),
            ),
            Text(
              value,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.bold,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildInputCard() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: LinearGradient(
          colors: [WaColors.bgCard, WaColors.bgCard],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(
          color: WaColors.accent.withOpacity(0.25),
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: WaColors.accent.withOpacity(0.15),
            blurRadius: 40,
            spreadRadius: 1,
            offset: const Offset(0, 15),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    AnimatedBuilder(
                      animation: _glowAnimation,
                      builder: (context, child) {
                        return Container(
                          height: 40,
                          width: 40,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              colors: [WaColors.bgCard, WaColors.bgCard],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: WaColors.accent.withOpacity(0.4 * _glowAnimation.value),
                                blurRadius: 15,
                              ),
                            ],
                          ),
                          child: const Icon(
                            FontAwesomeIcons.whatsapp,
                            color: WaColors.textPrimary,
                            size: 18,
                          ),
                        );
                      },
                    ),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Target Configuration",
                          style: TextStyle(
                            color: WaColors.accent,
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                        Container(
                          height: 2,
                          width: 40,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [WaColors.bgCard, WaColors.bgCard],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                _buildTextField(
                  controller: _targetController,
                  label: "TARGET NUMBER",
                  hint: "628123456789",
                  icon: Icons.phone_iphone,
                ),
                const SizedBox(height: 16),
                _buildTextField(
                  controller: _amountController,
                  label: "REPORT AMOUNT (1-500)",
                  hint: "50",
                  icon: Icons.confirmation_number,
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => setState(() => _stealthMode = !_stealthMode),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                          decoration: BoxDecoration(
                            color: _stealthMode
                                ? WaColors.accent.withOpacity(0.2)
                                : WaColors.accent.withOpacity(0.5),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: _stealthMode ? WaColors.accent : WaColors.accent.withOpacity(0.3),
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.shield,
                                color: _stealthMode ? WaColors.accent : WaColors.accent,
                                size: 14,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                'STEALTH MODE',
                                style: TextStyle(
                                  color: _stealthMode ? WaColors.accent : WaColors.accent,
                                  fontSize: 10,
                                  fontWeight: _stealthMode ? FontWeight.bold : FontWeight.normal,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: WaColors.accent,
            fontSize: 10,
            fontWeight: FontWeight.w600,
            fontFamily: 'Orbitron',
          ),
        ),
        const SizedBox(height: 4),
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: WaColors.accent.withOpacity(0.5),
            border: Border.all(color: WaColors.border.withOpacity(0.2)),
          ),
          child: TextField(
            controller: controller,
            keyboardType: keyboardType,
            style: const TextStyle(color: WaColors.textPrimary, fontSize: 13),
            cursorColor: WaColors.accent,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(color: WaColors.accent.withOpacity(0.3), fontSize: 12),
              prefixIcon: Icon(icon, color: WaColors.accent, size: 16),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSenderSection() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: WaColors.accent.withOpacity(0.3),
        border: Border.all(color: WaColors.border.withOpacity(0.2)),
      ),
      child: ExpansionTile(
        leading: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: WaColors.accent.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(Icons.email, color: WaColors.accent, size: 16),
        ),
        title: Text(
          'SELECT SENDERS (${_selectedSenderIds.length}/${_availableSenders.length})',
          style: const TextStyle(color: WaColors.textPrimary, fontSize: 12, fontWeight: FontWeight.bold),
        ),
        children: [
          if (_availableSenders.isEmpty)
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Icon(Icons.email, color: WaColors.accent.withOpacity(0.3), size: 32),
                  const SizedBox(height: 8),
                  Text(
                    'No SMTP senders found',
                    style: TextStyle(color: WaColors.accent, fontSize: 11),
                  ),
                ],
              ),
            )
          else
            ..._availableSenders.map((sender) {
              final isSelected = _selectedSenderIds.contains(sender.id);
              return GestureDetector(
                onTap: () {
                  setState(() {
                    if (isSelected) {
                      _selectedSenderIds.remove(sender.id);
                    } else {
                      _selectedSenderIds.add(sender.id);
                    }
                  });
                },
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: isSelected ? WaColors.accent.withOpacity(0.1) : WaColors.textPrimary,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isSelected ? WaColors.accent : WaColors.accent.withOpacity(0.2),
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        isSelected ? Icons.check_circle : Icons.radio_button_unchecked,
                        color: isSelected ? WaColors.accent : WaColors.accent,
                        size: 16,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              sender.email,
                              style: TextStyle(
                                color: isSelected ? WaColors.textPrimary : WaColors.accent,
                                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                                fontSize: 12,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Row(
                              children: [
                                Icon(Icons.check_circle, color: WaColors.accent, size: 10),
                                const SizedBox(width: 2),
                                Text('${sender.successCount}',
                                  style: TextStyle(color: WaColors.accent, fontSize: 9),
                                ),
                                const SizedBox(width: 6),
                                Icon(Icons.error, color: WaColors.accent, size: 10),
                                const SizedBox(width: 2),
                                Text('${sender.failCount}',
                                  style: TextStyle(color: WaColors.accent, fontSize: 9),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: WaColors.accent.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          sender.server.split('.').first,
                          style: TextStyle(color: WaColors.accent, fontSize: 8),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
        ],
      ),
    );
  }

  Widget _buildActionButton() {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return GestureDetector(
          onTap: _isLoading ? null : _toggleAttack,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: _isAttacking
                    ? [WaColors.accent, WaColors.accent]
                    : _isLoading
                        ? [WaColors.accent, WaColors.accent]
                        : [WaColors.accent, WaColors.accent],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: _isAttacking
                      ? WaColors.accent.withOpacity(0.3)
                      : WaColors.accent.withOpacity(0.3),
                  blurRadius: 20,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Center(
              child: _isLoading
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(color: WaColors.textPrimary, strokeWidth: 2),
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          _isAttacking ? Icons.stop_circle : Icons.play_arrow,
                          color: WaColors.textPrimary,
                          size: 18,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          _isAttacking ? "STOP REPORT" : "START REPORT BOMB",
                          style: const TextStyle(
                            color: WaColors.textPrimary,
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildDot(Color color) {
    return Container(
      width: 8,
      height: 8,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.5),
            blurRadius: 5,
          ),
        ],
      ),
    );
  }

  Widget _buildTerminalLogs() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(
          colors: [WaColors.bgCard, WaColors.bgCard],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(color: WaColors.border.withOpacity(0.2)),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Row(
                          children: [
                            _buildDot(WaColors.accent),
                            const SizedBox(width: 4),
                            _buildDot(WaColors.accent),
                            const SizedBox(width: 4),
                            _buildDot(WaColors.accent),
                          ],
                        ),
                        const SizedBox(width: 10),
                        Text(
                          "ACTIVITY LOGS",
                          style: TextStyle(
                            color: WaColors.accent,
                            fontWeight: FontWeight.w600,
                            fontSize: 12,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ],
                    ),
                    if (_isAttacking)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: WaColors.accent.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 6,
                              height: 6,
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: WaColors.textPrimary,
                              ),
                            ),
                            const SizedBox(width: 4),
                            Text(
                              '$_progressCurrent/$_progressTotal',
                              style: const TextStyle(color: WaColors.textPrimary, fontSize: 10),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      color: WaColors.accent.withOpacity(0.7),
                    ),
                    child: _logs.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.terminal,
                                  color: WaColors.accent.withOpacity(0.3),
                                  size: 32,
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  "System ready...",
                                  style: TextStyle(
                                    color: WaColors.accent.withOpacity(0.5),
                                    fontSize: 11,
                                    fontFamily: 'ShareTechMono',
                                  ),
                                ),
                              ],
                            ),
                          )
                        : ListView.builder(
                            controller: _logScrollController,
                            itemCount: _logs.length,
                            itemBuilder: (context, index) {
                              final isSuccess = _logs[index].contains("SUCCESS") || _logs[index].contains("✅");
                              final isError = _logs[index].contains("❌") || _logs[index].contains("ERROR");
                              return Padding(
                                padding: const EdgeInsets.symmetric(vertical: 2),
                                child: Text(
                                  _logs[index],
                                  style: TextStyle(
                                    color: isError
                                        ? WaColors.accent
                                        : isSuccess
                                            ? WaColors.accent
                                            : WaColors.accent.withOpacity(0.8),
                                    fontSize: 10,
                                    fontFamily: 'ShareTechMono',
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
