import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:Fiona/Qaxer/.dart';   // ← path Api.api kamu

import '../models/benefit_model.dart';

final _baseUrl = Api.api;

class BenefitService {
  // ─── Upload benefit ─────────────────────────────────
  Future<Map<String, dynamic>> uploadBenefit({
    required String sessionKey,
    required String link,
    required String deskripsi,
  }) async {
    try {
      final res = await http.post(
        Uri.parse('$_baseUrl/uploadBenefit'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': sessionKey,
          'link': link,
          'deskripsi': deskripsi,
        }),
      ).timeout(const Duration(seconds: 15));

      final data = jsonDecode(res.body);
      return {
        'valid': data['valid'] == true,
        'message': data['message'] ?? data['error'] ?? 'Terjadi kesalahan',
      };
    } catch (e) {
      return { 'valid': false, 'message': 'Koneksi error: $e' };
    }
  }

  // ─── Get all benefits ────────────────────────────────
  Future<List<BenefitModel>> getBenefits({
    required String sessionKey,
    int limit = 50,
  }) async {
    try {
      final res = await http.get(
        Uri.parse('$_baseUrl/getBenefits?key=$sessionKey&limit=$limit'),
      ).timeout(const Duration(seconds: 15));

      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['benefits'] is List) {
        return (data['benefits'] as List)
            .map((e) => BenefitModel.fromMap(
                  Map<String, dynamic>.from(e),
                  e['id'].toString(),
                ))
            .toList();
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  // ─── Delete benefit ──────────────────────────────────
  Future<Map<String, dynamic>> deleteBenefit({
    required String sessionKey,
    required String benefitId,
  }) async {
    try {
      final res = await http.post(
        Uri.parse('$_baseUrl/deleteBenefit'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': sessionKey,
          'benefitId': benefitId,
        }),
      ).timeout(const Duration(seconds: 15));

      final data = jsonDecode(res.body);
      return {
        'valid': data['valid'] == true,
        'message': data['message'] ?? data['error'] ?? 'Terjadi kesalahan',
      };
    } catch (e) {
      return { 'valid': false, 'message': 'Koneksi error: $e' };
    }
  }
}