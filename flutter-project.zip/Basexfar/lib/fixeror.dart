import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';

class FixErrorPage extends StatefulWidget {
  const FixErrorPage({super.key});

  @override
  State<FixErrorPage> createState() => _FixErrorPageState();
}

class _FixErrorPageState extends State<FixErrorPage> {
  final TextEditingController _codeController = TextEditingController();
  bool _isLoading = false;
  String? _fixedCode;
  String? _errorMessage;

  final Color bgBlack = const Color(0xFF000000);
  final Color bgDark = const Color(0xFF0A0A0A);
  final Color cardDark = const Color(0xFF1A1A1A);
  final Color neonRed = const Color(0xFFFF0000);
  final Color darkRed = const Color(0xFF8B0000);
  final Color accentRed = const Color(0xFFCC0000);
  final Color neonWhite = const Color(0xFFF5F5F5);
  final Color textGrey = const Color(0xFFB0B0B0);
  final Color successGreen = const Color(0xFF4CAF50);

  @override
  void dispose() {
    _codeController.dispose();
    super.dispose();
  }

  Future<void> _fixErrorCode() async {
    final code = _codeController.text.trim();
    
    if (code.isEmpty) {
      setState(() {
        _errorMessage = "Kode error tidak boleh kosong!";
        _fixedCode = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _fixedCode = null;
    });

    final apiUrl = Uri.parse(OmhcSilenceProtect.decode(["nW4Opsj2DSWKSf06OeSEzzWRzDv5QzTs7Aw1iE","5BAwmzUyKT6Z5tWPxj1AoI2KSgG7viAI9+X9nB","P1i3FHIjKNA0Wfmf6SElzhKrbWazydVzzZx/"]) + ")}");

    try {
      final response = await http.get(apiUrl);
      
      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        
        if (json['status'] == true && json['result'] != null) {
          setState(() {
            _fixedCode = json['result'];
            _errorMessage = null;
          });
          
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('✓ Kode berhasil diperbaiki!', style: TextStyle(color: neonWhite, fontFamily: 'Rajdhani')),
              backgroundColor: successGreen,
              behavior: SnackBarBehavior.floating,
              duration: Duration(seconds: 2),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          );
        } else {
          setState(() {
            _errorMessage = json['message'] ?? "Gagal memperbaiki kode error.";
            _fixedCode = null;
          });
        }
      } else {
        setState(() {
          _errorMessage = "Gagal terhubung ke server. Status: ${response.statusCode}";
          _fixedCode = null;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = "Terjadi kesalahan: $e";
        _fixedCode = null;
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _copyToClipboard() {
    if (_fixedCode != null && _fixedCode!.isNotEmpty) {
      Clipboard.setData(ClipboardData(text: _fixedCode!));
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(Icons.check_circle, color: successGreen, size: 20),
              SizedBox(width: 12),
              Text('Kode berhasil disalin!', style: TextStyle(color: neonWhite, fontFamily: 'Rajdhani')),
            ],
          ),
          backgroundColor: cardDark,
          behavior: SnackBarBehavior.floating,
          duration: Duration(seconds: 2),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      appBar: AppBar(
        title: Text(
          'FIX ERROR CODE',
          style: TextStyle(
            fontFamily: 'Rajdhani',
            fontWeight: FontWeight.bold,
            color: neonRed,
            letterSpacing: 2,
            fontSize: 20,
          ),
        ),
        backgroundColor: bgBlack,
        centerTitle: true,
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(1),
          child: Container(
            height: 1,
            color: neonRed.withOpacity(0.3),
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: neonWhite),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [bgDark, cardDark],
                  ),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: neonRed.withOpacity(0.3)),
                  boxShadow: [
                    BoxShadow(
                      color: neonRed.withOpacity(0.2),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [darkRed, neonRed],
                        ),
                        borderRadius: BorderRadius.circular(30),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.auto_fix_high, color: neonWhite, size: 16),
                          SizedBox(width: 8),
                          Text(
                            'AI FIX ERROR CODE',
                            style: TextStyle(
                              color: neonWhite,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Rajdhani',
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    TextField(
                      controller: _codeController,
                      style: TextStyle(color: neonWhite, fontSize: 14, fontFamily: 'monospace'),
                      maxLines: 8,
                      minLines: 5,
                      decoration: InputDecoration(
                        labelText: 'KODE ERROR',
                        labelStyle: TextStyle(color: neonRed, fontWeight: FontWeight.w500, fontFamily: 'Rajdhani', letterSpacing: 1),
                        hintText: 'Masukkan kode error yang ingin diperbaiki...',
                        hintStyle: TextStyle(color: textGrey, fontFamily: 'monospace'),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: neonRed.withOpacity(0.5), width: 1.5),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: neonRed, width: 2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        filled: true,
                        fillColor: bgBlack.withOpacity(0.5),
                        alignLabelWithHint: true,
                      ),
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _isLoading ? null : _fixErrorCode,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: neonRed,
                          foregroundColor: neonWhite,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          elevation: 4,
                          shadowColor: neonRed.withOpacity(0.5),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            if (_isLoading)
                              SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  color: neonWhite,
                                  strokeWidth: 2,
                                ),
                              )
                            else
                              Icon(Icons.auto_fix_high, size: 20, color: neonWhite),
                            const SizedBox(width: 8),
                            Text(
                              _isLoading ? 'PROSES...' : 'FIX ERROR',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Rajdhani',
                                color: neonWhite,
                                letterSpacing: 1,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              if (_errorMessage != null)
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.red.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.red.withOpacity(0.3)),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.error_outline, color: neonRed, size: 24),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          _errorMessage!,
                          style: TextStyle(color: neonRed, fontSize: 14, fontFamily: 'Rajdhani'),
                        ),
                      ),
                    ],
                  ),
                ),

              if (_fixedCode != null)
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [bgDark, cardDark],
                            ),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: neonRed.withOpacity(0.3)),
                            boxShadow: [
                              BoxShadow(
                                color: neonRed.withOpacity(0.2),
                                blurRadius: 10,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [darkRed, neonRed],
                                  ),
                                  borderRadius: BorderRadius.circular(30),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(Icons.code, color: neonWhite, size: 16),
                                    SizedBox(width: 8),
                                    Text(
                                      "KODE HASIL FIX",
                                      style: TextStyle(
                                        color: neonWhite,
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'Rajdhani',
                                        letterSpacing: 1,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 20),
                              
                              Container(
                                padding: const EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                  color: bgBlack.withOpacity(0.5),
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(color: successGreen.withOpacity(0.3)),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Icon(Icons.check_circle, color: successGreen, size: 20),
                                        SizedBox(width: 8),
                                        Text(
                                          'KODE BERHASIL DIPERBAIKI',
                                          style: TextStyle(
                                            color: successGreen,
                                            fontSize: 13,
                                            fontWeight: FontWeight.bold,
                                            fontFamily: 'Rajdhani',
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: 16),
                                    Container(
                                      padding: const EdgeInsets.all(16),
                                      decoration: BoxDecoration(
                                        color: bgBlack.withOpacity(0.3),
                                        borderRadius: BorderRadius.circular(12),
                                        border: Border.all(color: neonRed.withOpacity(0.2)),
                                      ),
                                      child: SelectableText(
                                        _fixedCode!,
                                        style: TextStyle(
                                          color: neonWhite,
                                          fontSize: 13,
                                          fontFamily: 'monospace',
                                          height: 1.5,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              const SizedBox(height: 20),

                              SizedBox(
                                width: double.infinity,
                                child: ElevatedButton(
                                  onPressed: _copyToClipboard,
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: darkRed,
                                    foregroundColor: neonWhite,
                                    padding: const EdgeInsets.symmetric(vertical: 16),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    elevation: 4,
                                    shadowColor: darkRed.withOpacity(0.5),
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.copy, size: 20, color: neonWhite),
                                      SizedBox(width: 8),
                                      Text(
                                        'SALIN KODE',
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: 'Rajdhani',
                                          color: neonWhite,
                                          letterSpacing: 1,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

              if (_fixedCode == null && !_isLoading && _errorMessage == null)
                Expanded(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          padding: EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: neonRed.withOpacity(0.1),
                          ),
                          child: Icon(
                            Icons.bug_report,
                            size: 80,
                            color: neonRed.withOpacity(0.5),
                          ),
                        ),
                        SizedBox(height: 24),
                        Text(
                          'FIX ERROR CODE',
                          style: TextStyle(
                            color: neonRed,
                            fontSize: 20,
                            fontFamily: 'Rajdhani',
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2,
                          ),
                        ),
                        SizedBox(height: 12),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 32),
                          child: Text(
                            'Masukkan kode error yang ingin diperbaiki, klik tombol FIX ERROR, dan salin hasilnya',
                            style: TextStyle(
                              color: textGrey,
                              fontSize: 14,
                              fontFamily: 'Rajdhani',
                              height: 1.5,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}