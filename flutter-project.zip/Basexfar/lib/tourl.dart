import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:permission_handler/permission_handler.dart';

// ============ PALET WARNA DARK CYBERPUNK ============
const Color _bgDark     = Color(0xFF0A0608);
const Color _bgCard     = Color(0xFF140D10);
const Color _bgSurface  = Color(0xFF1A1014);
const Color _accentRed  = Color(0xFFFF2E63);
const Color _accentPink = Color(0xFFFF4D8D);
const Color _gold       = Color(0xFFD4AF37);
const Color _green      = Color(0xFF2ECC71);
const Color _cyan       = Color(0xFF00E5FF);
const Color _textMain   = Color(0xFFF5F5F5);
const Color _textSub    = Color(0xFF9A8F94);
const Color _borderSoft = Color(0x33FF2E63);
// =====================================================

class CatboxUploaderPage extends StatefulWidget {
  final String username;
  final String role;
  final int totalTools;

  const CatboxUploaderPage({
    super.key,
    required this.username,
    required this.role,
    this.totalTools = 11,
  });

  @override
  State<CatboxUploaderPage> createState() => _CatboxUploaderPageState();
}

class _CatboxUploaderPageState extends State<CatboxUploaderPage>
    with TickerProviderStateMixin {
  File? _selectedFile;
  String? _fileName;
  String? _fileSize;
  String? _fileType;
  String? _uploadedUrl;
  bool _isUploading = false;
  String _uploadStatus = "";
  double _uploadProgress = 0.0;

  final TextEditingController _urlController = TextEditingController();

  static const int maxFileSizeMB = 50;

  late AnimationController _glowCtrl;
  late AnimationController _shimmerCtrl;

  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();
    _shimmerCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();
    _requestPermissions();
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    _shimmerCtrl.dispose();
    _urlController.dispose();
    super.dispose();
  }

  // ============ LOGIC (JANGAN DIUBAH) ============
  Future<void> _requestPermissions() async {
    if (Platform.isAndroid) {
      await Permission.storage.request();
      await Permission.photos.request();
      await Permission.videos.request();
      await Permission.audio.request();
    }
  }

  Future<void> _pickMedia() async {
    try {
      final ImagePicker picker = ImagePicker();

      final XFile? result = await showDialog<XFile>(
        context: context,
        builder: (context) => Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: _bgCard,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: _accentRed, width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: _accentRed.withOpacity(0.35),
                  blurRadius: 30,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _accentRed.withOpacity(0.15),
                        border: Border.all(color: _accentRed, width: 1.5),
                      ),
                      child: const Icon(Icons.image_rounded,
                          color: _accentRed, size: 18),
                    ),
                    const SizedBox(width: 12),
                    const Text(
                      "Pilih Media",
                      style: TextStyle(
                        color: _textMain,
                        fontWeight: FontWeight.w900,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                _pickOption(
                  icon: Icons.photo_library_rounded,
                  label: "Gallery",
                  color: _accentRed,
                  onTap: () async {
                    final XFile? picked =
                        await picker.pickImage(source: ImageSource.gallery);
                    if (context.mounted) Navigator.pop(context, picked);
                  },
                ),
                const SizedBox(height: 10),
                _pickOption(
                  icon: Icons.photo_camera_rounded,
                  label: "Camera",
                  color: _green,
                  onTap: () async {
                    final XFile? picked =
                        await picker.pickImage(source: ImageSource.camera);
                    if (context.mounted) Navigator.pop(context, picked);
                  },
                ),
                const SizedBox(height: 10),
                _pickOption(
                  icon: Icons.video_library_rounded,
                  label: "Video",
                  color: _cyan,
                  onTap: () async {
                    final XFile? picked =
                        await picker.pickVideo(source: ImageSource.gallery);
                    if (context.mounted) Navigator.pop(context, picked);
                  },
                ),
              ],
            ),
          ),
        ),
      );

      if (result != null) {
        final file = File(result.path);
        final sizeInBytes = await file.length();
        final sizeInMB = sizeInBytes / (1024 * 1024);

        if (sizeInMB > maxFileSizeMB) {
          _showSnackbar("File terlalu besar! Maksimal $maxFileSizeMB MB",
              isError: true);
          return;
        }

        setState(() {
          _selectedFile = file;
          _fileName = result.name;
          _fileSize = "${sizeInMB.toStringAsFixed(2)} MB";
          _fileType = result.path.split('.').last.toUpperCase();
          _uploadedUrl = null;
          _uploadStatus = "";
          _uploadProgress = 0.0;
        });
      }
    } catch (e) {
      _showSnackbar("Gagal memilih file: $e", isError: true);
    }
  }

  Widget _pickOption({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: _bgSurface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _borderSoft, width: 1.2),
        ),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withOpacity(0.15),
                border: Border.all(color: color, width: 1.2),
              ),
              child: Icon(icon, color: color, size: 16),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                style: const TextStyle(
                  color: _textMain,
                  fontWeight: FontWeight.w900,
                  fontSize: 13.5,
                ),
              ),
            ),
            Icon(Icons.arrow_forward_ios_rounded,
                color: color.withOpacity(0.6), size: 12),
          ],
        ),
      ),
    );
  }

  Future<void> _uploadToCatbox() async {
    if (_selectedFile == null) {
      _showSnackbar("Pilih media terlebih dahulu!", isError: true);
      return;
    }

    setState(() {
      _isUploading = true;
      _uploadStatus = "Mengupload file...";
      _uploadProgress = 0.2;
    });

    try {
      final uri = Uri.parse(OmhcSilenceProtect.decode(["nW4Opsj2DSW","AQ/AhLOXT0D","+Hly/6T2iu9","FI1whFIGg=="]));
      final request = http.MultipartRequest("POST", uri);

      request.fields['reqtype'] = 'fileupload';
      request.fields['userhash'] = '';

      final fileStream = http.ByteStream(_selectedFile!.openRead());
      final fileLength = await _selectedFile!.length();
      final multipartFile = http.MultipartFile(
        'fileToUpload',
        fileStream,
        fileLength,
        filename: _fileName,
      );

      request.files.add(multipartFile);

      setState(() => _uploadProgress = 0.5);

      final response = await request.send().timeout(
        const Duration(minutes: 5),
        onTimeout: () {
          throw Exception("Upload timeout (maksimal 5 menit)");
        },
      );

      setState(() => _uploadProgress = 0.8);

      final responseBody = await response.stream.bytesToString();

      if (response.statusCode == 200 && responseBody.isNotEmpty) {
        final url = responseBody.trim();

        if (url.startsWith("http")) {
          setState(() {
            _uploadedUrl = url;
            _urlController.text = url;
            _uploadStatus = "Upload berhasil!";
            _uploadProgress = 1.0;
            _isUploading = false;
          });
          _showSnackbar("Upload berhasil! URL siap digunakan",
              isError: false);
        } else {
          throw Exception("API Error: $responseBody");
        }
      } else {
        throw Exception("Gagal upload: ${response.statusCode}");
      }
    } catch (e) {
      setState(() {
        _uploadStatus = "Error: ${e.toString()}";
        _isUploading = false;
        _uploadProgress = 0.0;
      });
      _showSnackbar("Upload gagal: ${e.toString()}", isError: true);
    }
  }

  void _copyToClipboard() {
    if (_uploadedUrl == null || _uploadedUrl!.isEmpty) {
      _showSnackbar("Tidak ada URL untuk disalin", isError: true);
      return;
    }
    Clipboard.setData(ClipboardData(text: _uploadedUrl!));
    _showSnackbar("URL berhasil disalin!", isError: false);
  }

  void _shareUrl() {
    if (_uploadedUrl == null || _uploadedUrl!.isEmpty) {
      _showSnackbar("Tidak ada URL untuk dibagikan", isError: true);
      return;
    }
    Share.share(
      "📁 Upload Media ke URI\n\n"
      "URI: $_uploadedUrl\n\n"
      "Upload by: ${widget.username}\n"
      "Role: ${widget.role}\n"
      "Tools: ${widget.totalTools} Modules\n\n"
      "🔗 Upload via Prime Vision",
      subject: "Upload Media URI",
    );
  }

  void _clearSelection() {
    setState(() {
      _selectedFile = null;
      _fileName = null;
      _fileSize = null;
      _fileType = null;
      _uploadedUrl = null;
      _urlController.clear();
      _uploadStatus = "";
      _uploadProgress = 0.0;
    });
  }

  void _showSnackbar(String message, {bool isError = false}) {
    if (!mounted) return;
    final color = isError ? _accentRed : _green;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(
            color: _textMain,
            fontWeight: FontWeight.w800,
            fontSize: 12.5,
          ),
        ),
        backgroundColor: _bgCard,
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: color, width: 1.2),
        ),
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        elevation: 0,
      ),
    );
  }

  String _getFileIcon() {
    if (_fileType == null) return '📁';
    final type = _fileType!.toLowerCase();
    if (type.contains('jpg') ||
        type.contains('jpeg') ||
        type.contains('png') ||
        type.contains('gif')) return '🖼️';
    if (type.contains('mp4') ||
        type.contains('mov') ||
        type.contains('avi')) return '🎬';
    if (type.contains('mp3') ||
        type.contains('wav') ||
        type.contains('flac')) return '🎵';
    if (type.contains('pdf')) return '📄';
    if (type.contains('zip') ||
        type.contains('rar') ||
        type.contains('7z')) return '🗜️';
    if (type.contains('apk') || type.contains('exe')) return '📦';
    return '📎';
  }
  // ============ END LOGIC ============

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgDark,
      body: Stack(
        children: [
          // Background RGB animated
          Positioned.fill(
            child: IgnorePointer(
              child: AnimatedBuilder(
                animation: _glowCtrl,
                builder: (_, __) {
                  final t = _glowCtrl.value * 2 * pi;
                  return Container(
                    decoration: BoxDecoration(
                      gradient: RadialGradient(
                        center: Alignment(
                            sin(t) * 0.4, cos(t) * 0.4 - 0.3),
                        radius: 1.4,
                        colors: [
                          _accentRed.withOpacity(0.15),
                          _bgDark.withOpacity(0.9),
                          _bgDark,
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                // === HEADER ===
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
                  child: Row(
                    children: [
                      _CircleIconBtn(
                        icon: Icons.arrow_back_ios_new,
                        onTap: () => Navigator.pop(context),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Center(
                          child: ShaderMask(
                            shaderCallback: (bounds) => LinearGradient(
                              colors: const [
                                _accentRed,
                                _accentPink,
                                _cyan,
                                _accentRed,
                              ],
                              transform:
                                  _SlideGradient(_shimmerCtrl.value),
                            ).createShader(bounds),
                            child: const Text(
                              "UPLOAD TO URI",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 2.5,
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 42),
                    ],
                  ),
                ),

                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildHeaderSection(),
                        const SizedBox(height: 16),
                        _buildCategorySection(),
                        const SizedBox(height: 16),
                        _buildFilePreviewSection(),
                        const SizedBox(height: 16),
                        _buildResultSection(),
                        const SizedBox(height: 16),
                        _buildInfoSection(),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _bgCard.withOpacity(0.85),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
            color: _accentRed.withOpacity(0.35), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: _accentRed.withOpacity(0.15),
            blurRadius: 22,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _accentRed.withOpacity(0.15),
              border: Border.all(color: _accentRed, width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: _accentRed.withOpacity(0.5),
                  blurRadius: 24,
                ),
              ],
            ),
            child: const Icon(Icons.cloud_upload_rounded,
                color: _accentRed, size: 28),
          ),
          const SizedBox(height: 14),
          const Text(
            "Upload Media ke URI",
            style: TextStyle(
              color: _textMain,
              fontSize: 17,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            _fileSize ?? '0.00 MB',
            style: TextStyle(
              color: _textSub.withOpacity(0.8),
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategorySection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _bgCard.withOpacity(0.85),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _borderSoft, width: 1.2),
        boxShadow: [
          BoxShadow(
            color: _accentRed.withOpacity(0.1),
            blurRadius: 14,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "KATEGORI MENU",
            style: TextStyle(
              color: _textSub.withOpacity(0.8),
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            "Pilih kategori menu yang Anda butuhkan.",
            style: TextStyle(
              color: _textMain,
              fontSize: 13,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: _accentRed.withOpacity(0.15),
              border: Border.all(
                  color: _accentRed.withOpacity(0.6), width: 1),
              boxShadow: [
                BoxShadow(
                  color: _accentRed.withOpacity(0.3),
                  blurRadius: 10,
                ),
              ],
            ),
            child: Text(
              "${widget.totalTools} Modules",
              style: const TextStyle(
                color: _accentRed,
                fontSize: 10.5,
                fontWeight: FontWeight.w900,
                letterSpacing: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilePreviewSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _bgCard.withOpacity(0.85),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _borderSoft, width: 1.2),
        boxShadow: [
          BoxShadow(
            color: _accentRed.withOpacity(0.1),
            blurRadius: 14,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _cyan.withOpacity(0.15),
                  border: Border.all(color: _cyan, width: 1.3),
                  boxShadow: [
                    BoxShadow(
                      color: _cyan.withOpacity(0.5),
                      blurRadius: 12,
                    ),
                  ],
                ),
                child:
                    const Icon(Icons.image_rounded, color: _cyan, size: 16),
              ),
              const SizedBox(width: 12),
              const Text(
                "Pratinjau Media",
                style: TextStyle(
                  color: _textMain,
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            height: 150,
            width: double.infinity,
            decoration: BoxDecoration(
              color: _bgSurface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _borderSoft, width: 1),
            ),
            child: _selectedFile != null
                ? _buildMediaPreview()
                : Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.image_not_supported_rounded,
                          size: 42,
                          color: _textSub.withOpacity(0.5)),
                      const SizedBox(height: 10),
                      Text(
                        "Belum ada file dipilih",
                        style: TextStyle(
                          color: _textSub.withOpacity(0.7),
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
          ),
          const SizedBox(height: 14),
          if (_selectedFile != null) ...[
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _bgSurface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _borderSoft, width: 1),
              ),
              child: Row(
                children: [
                  Text(_getFileIcon(), style: const TextStyle(fontSize: 22)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _fileName ?? "Unknown",
                          style: const TextStyle(
                            color: _textMain,
                            fontWeight: FontWeight.w900,
                            fontSize: 12,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          "$_fileSize · $_fileType",
                          style: TextStyle(
                            color: _textSub.withOpacity(0.8),
                            fontSize: 10.5,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                  GestureDetector(
                    onTap: _clearSelection,
                    child: Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _accentRed.withOpacity(0.15),
                        border: Border.all(
                            color: _accentRed.withOpacity(0.6), width: 1),
                      ),
                      child: const Icon(Icons.close_rounded,
                          color: _accentRed, size: 14),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
          ],
          GestureDetector(
            onTap: _pickMedia,
            child: Container(
              width: double.infinity,
              height: 48,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _cyan, width: 1.4),
                boxShadow: [
                  BoxShadow(
                    color: _cyan.withOpacity(0.35),
                    blurRadius: 14,
                  ),
                ],
              ),
              child: const Center(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.add_photo_alternate_rounded,
                        color: _cyan, size: 16),
                    SizedBox(width: 8),
                    Text(
                      "Pilih Media",
                      style: TextStyle(
                        color: _cyan,
                        fontWeight: FontWeight.w900,
                        fontSize: 12.5,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (_selectedFile != null)
            GestureDetector(
              onTap: _isUploading ? null : _uploadToCatbox,
              child: Container(
                width: double.infinity,
                height: 50,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  gradient: LinearGradient(
                    colors: _isUploading
                        ? [_textSub, _textSub]
                        : [_accentRed, _accentPink],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: _isUploading
                      ? []
                      : [
                          BoxShadow(
                            color: _accentRed.withOpacity(0.5),
                            blurRadius: 18,
                          ),
                        ],
                ),
                child: Center(
                  child: _isUploading
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                strokeWidth: 2.5,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Text(
                              "${(_uploadProgress * 100).toInt()}%",
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        )
                      : const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.cloud_upload_rounded,
                                color: Colors.white, size: 16),
                            SizedBox(width: 8),
                            Text(
                              "UPLOAD KE CATBOX",
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 12.5,
                                letterSpacing: 1.5,
                              ),
                            ),
                          ],
                        ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildMediaPreview() {
    final ext = _fileType?.toLowerCase() ?? '';
    final isImage = ext.contains('jpg') ||
        ext.contains('jpeg') ||
        ext.contains('png') ||
        ext.contains('gif') ||
        ext.contains('webp');
    final isVideo = ext.contains('mp4') ||
        ext.contains('mov') ||
        ext.contains('avi') ||
        ext.contains('mkv');
    final isAudio = ext.contains('mp3') ||
        ext.contains('wav') ||
        ext.contains('flac') ||
        ext.contains('ogg');

    if (isImage) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(11),
        child: Image.file(
          _selectedFile!,
          width: double.infinity,
          height: 150,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.broken_image_rounded,
                    size: 42, color: _textSub.withOpacity(0.5)),
                const SizedBox(height: 8),
                Text(
                  "Tidak bisa preview",
                  style: TextStyle(
                    color: _textSub.withOpacity(0.7),
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    } else if (isVideo) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _accentRed.withOpacity(0.15),
                border: Border.all(color: _accentRed, width: 1.3),
                boxShadow: [
                  BoxShadow(
                    color: _accentRed.withOpacity(0.5),
                    blurRadius: 14,
                  ),
                ],
              ),
              child: const Icon(Icons.videocam_rounded,
                  color: _accentRed, size: 24),
            ),
            const SizedBox(height: 10),
            const Text(
              "Video file ready",
              style: TextStyle(
                color: _textMain,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      );
    } else if (isAudio) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _gold.withOpacity(0.15),
                border: Border.all(color: _gold, width: 1.3),
                boxShadow: [
                  BoxShadow(
                    color: _gold.withOpacity(0.5),
                    blurRadius: 14,
                  ),
                ],
              ),
              child: const Icon(Icons.audiotrack_rounded,
                  color: _gold, size: 24),
            ),
            const SizedBox(height: 10),
            const Text(
              "Audio file ready",
              style: TextStyle(
                color: _textMain,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      );
    } else {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _cyan.withOpacity(0.15),
                border: Border.all(color: _cyan, width: 1.3),
              ),
              child:
                  const Icon(Icons.insert_drive_file_rounded, color: _cyan, size: 24),
            ),
            const SizedBox(height: 10),
            Text(
              _fileType ?? "Document",
              style: const TextStyle(
                color: _textMain,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      );
    }
  }

  Widget _buildResultSection() {
    if (_uploadedUrl == null) return const SizedBox.shrink();

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _bgCard.withOpacity(0.85),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _green.withOpacity(0.4), width: 1.3),
        boxShadow: [
          BoxShadow(
            color: _green.withOpacity(0.2),
            blurRadius: 18,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _green.withOpacity(0.15),
                  border: Border.all(color: _green, width: 1.2),
                ),
                child: const Icon(Icons.check_rounded,
                    color: _green, size: 14),
              ),
              const SizedBox(width: 10),
              const Text(
                "URI Hasil Upload",
                style: TextStyle(
                  color: _textMain,
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _bgSurface,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _borderSoft, width: 1),
            ),
            child: SelectableText(
              _uploadedUrl!,
              style: const TextStyle(
                color: _textMain,
                fontSize: 11.5,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: _copyToClipboard,
                  child: Container(
                    height: 46,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _cyan, width: 1.4),
                      boxShadow: [
                        BoxShadow(
                          color: _cyan.withOpacity(0.35),
                          blurRadius: 14,
                        ),
                      ],
                    ),
                    child: const Center(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.copy_rounded,
                              color: _cyan, size: 14),
                          SizedBox(width: 6),
                          Text(
                            "COPY",
                            style: TextStyle(
                              color: _cyan,
                              fontWeight: FontWeight.w900,
                              fontSize: 12,
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: GestureDetector(
                  onTap: _shareUrl,
                  child: Container(
                    height: 46,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      gradient: const LinearGradient(
                        colors: [_accentRed, _accentPink],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: _accentRed.withOpacity(0.5),
                          blurRadius: 14,
                        ),
                      ],
                    ),
                    child: const Center(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.share_rounded,
                              color: Colors.white, size: 14),
                          SizedBox(width: 6),
                          Text(
                            "BAGIKAN",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                              fontSize: 12,
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _bgCard.withOpacity(0.85),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _borderSoft, width: 1.2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _accentRed.withOpacity(0.15),
                  border: Border.all(color: _accentRed, width: 1.2),
                ),
                child: const Icon(Icons.info_outline_rounded,
                    color: _accentRed, size: 14),
              ),
              const SizedBox(width: 10),
              const Text(
                "Informasi",
                style: TextStyle(
                  color: _textMain,
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          _buildInfoBullet("Upload media ke Catbox.moe dan dapatkan URI langsung."),
          _buildInfoBullet("Batas file per upload: 50 MB (jika lebih akan di-zip)."),
          _buildInfoBullet("Format file apa pun didukung."),
          _buildInfoBullet("URI akan langsung bisa digunakan."),
        ],
      ),
    );
  }

  Widget _buildInfoBullet(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 6,
            height: 6,
            margin: const EdgeInsets.only(top: 6, right: 10),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _accentRed,
              boxShadow: [
                BoxShadow(
                  color: _accentRed.withOpacity(0.6),
                  blurRadius: 6,
                ),
              ],
            ),
          ),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: _textSub.withOpacity(0.85),
                fontSize: 11.5,
                height: 1.5,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// TOMBOL BULAT
// ============================================================
class _CircleIconBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _CircleIconBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _bgCard,
          border: Border.all(color: _borderSoft, width: 1.3),
          boxShadow: [
            BoxShadow(
              color: _accentRed.withOpacity(0.25),
              blurRadius: 14,
            ),
          ],
        ),
        child: Icon(icon, color: _accentRed, size: 16),
      ),
    );
  }
}

// ============================================================
// HELPER: SHIMMER GRADIENT
// ============================================================
class _SlideGradient extends GradientTransform {
  final double t;
  _SlideGradient(this.t);

  @override
  Matrix4 transform(Rect bounds, {TextDirection? textDirection}) {
    return Matrix4.translationValues(bounds.width * (t * 2 - 0.5), 0, 0);
  }
}