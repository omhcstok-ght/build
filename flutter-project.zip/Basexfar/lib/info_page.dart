import 'dart:math' as math;
import 'package:flutter/material.dart';

// ─── Palette — Light Mode ───────────────────────────────────────────────────
class _C {
  // Background terang
  static const bg        = Color(0xFFF5F9FF);
  static const surface   = Color(0xFFFFFFFF);
  static const card      = Color(0xFFFFFFFF);

  // Border soft
  static const border    = Color(0xFFD6E4F5);
  static const borderLit = Color(0xFFB6CDE8);

  // Inti tema: Biru Aksen
  static const blue      = Color(0xFF2563EB);
  static const blueMid   = Color(0xFF3B82F6);
  static const blueLight = Color(0xFF60A5FA);

  // Accent colors
  static const green     = Color(0xFF10B981);
  static const amber     = Color(0xFFF59E0B);
  static const red       = Color(0xFFEF4444);
  static const purple    = Color(0xFF8B5CF6);

  // Teks gelap
  static const text      = Color(0xFF0F172A);
  static const textSub   = Color(0xFF475569);
  static const textDim   = Color(0xFF94A3B8);

  // Gradient tombol
  static const LinearGradient btnGrad = LinearGradient(
    colors: [Color(0xFF3B82F6), Color(0xFF2563EB)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

// ─── Rules data ───────────────────────────────────────────────────────────────
const _rules = [
  _Rule(
    title: 'Larangan Barter Akun',
    desc:  'Akun tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun.',
    icon:  Icons.swap_horiz_rounded,
    color: Color(0xFF8B5CF6), // Purple
  ),
  _Rule(
    title: 'Larangan Membagikan Akun',
    desc:  'Setiap akun bersifat pribadi dan hanya boleh digunakan oleh pemilik akun yang terdaftar.',
    icon:  Icons.share_rounded,
    color: Color(0xFF0EA5E9), // Cyan
  ),
  _Rule(
    title: 'Larangan Menjual Akun',
    desc:  'Member TIDAK diperbolehkan menjual akun. Penjualan hanya boleh dilakukan oleh role yang diizinkan secara resmi.',
    icon:  Icons.sell_rounded,
    color: Color(0xFFEF4444), // Rose
  ),
  _Rule(
    title: 'Larangan Jual Durasi Ilegal',
    desc:  'Dilarang menjual akses harian, mingguan, trial, atau sejenisnya di luar ketentuan yang telah ditetapkan.',
    icon:  Icons.timer_off_rounded,
    color: Color(0xFF8B5CF6), // Purple
  ),
  _Rule(
    title: 'Larangan Banting Harga',
    desc:  'Dilarang merusak atau menurunkan harga yang telah ditentukan di bawah ketentuan X-FAR project.',
    icon:  Icons.trending_down_rounded,
    color: Color(0xFF10B981), // Emerald
  ),
];

class _Rule {
  final String title;
  final String desc;
  final IconData icon;
  final Color color;
  const _Rule({required this.title, required this.desc,
      required this.icon, required this.color});
}

// ─── Page ─────────────────────────────────────────────────────────────────────
class InfoPage extends StatefulWidget {
  final String sessionKey;
  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> with TickerProviderStateMixin {
  bool isLoading = true;

  // Animations
  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _sanctionCtrl;

  late Animation<double> _entrance;
  late Animation<double> _sanctionGlow;

  @override
  void initState() {
    super.initState();

    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 18))
      ..repeat();

    _entranceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));
    _entrance = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic);

    _sanctionCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2000))
      ..repeat(reverse: true);
    _sanctionGlow = Tween<double>(begin: 0.2, end: 0.6)
        .animate(CurvedAnimation(parent: _sanctionCtrl, curve: Curves.easeInOut));

    // Loading lokal
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) {
        setState(() => isLoading = false);
        _entranceCtrl.forward();
      }
    });
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _sanctionCtrl.dispose();
    super.dispose();
  }

  // ─── Build ────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        backgroundColor: _C.bg,
        body: Stack(children: [
          Positioned.fill(child: _AnimatedBg(controller: _bgCtrl)),
          const Center(child: _DotsLoader()),
        ]),
      );
    }

    return Scaffold(
      backgroundColor: _C.bg,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          Positioned.fill(child: _AnimatedBg(controller: _bgCtrl)),
          SafeArea(
            child: FadeTransition(
              opacity: _entrance,
              child: ListView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 48),
                children: [
                  // Rules header
                  _buildSectionHeader(
                    icon: Icons.gavel_rounded,
                    title: 'Peraturan Pengguna',
                    subtitle: '${_rules.length} aturan berlaku',
                  ),
                  const SizedBox(height: 14),

                  // Rules list
                  ..._rules.asMap().entries.map((e) =>
                    _StaggerItem(
                      index: e.key,
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: _RuleCard(rule: e.value, number: e.key + 1),
                      ),
                    )),

                  const SizedBox(height: 20),

                  // Sanction card
                  _buildSanctionCard(),
                  const SizedBox(height: 24),

                  // Footer note
                  _buildFooter(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      automaticallyImplyLeading: false,
      centerTitle: true,
      title: Row(mainAxisSize: MainAxisSize.min, children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: _C.blue.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
            boxShadow: [
              BoxShadow(
                color: _C.blue.withOpacity(0.15),
                blurRadius: 10,
              ),
            ],
          ),
          child: const Icon(Icons.info_outline_rounded,
              color: _C.blue, size: 15),
        ),
        const SizedBox(width: 9),
        const Text('Peraturan and Info',
            style: TextStyle(color: _C.text, fontSize: 17, fontFamily: "Aktura",
                fontWeight: FontWeight.w700, letterSpacing: -0.3)),
      ]),
    );
  }

  Widget _buildSectionHeader({
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    return Row(children: [
      Container(
        width: 4, height: 20,
        decoration: BoxDecoration(
          gradient: _C.btnGrad,
          borderRadius: BorderRadius.circular(2),
          boxShadow: [
            BoxShadow(
              color: _C.blue.withOpacity(0.4),
              blurRadius: 8,
            ),
          ],
        ),
      ),
      const SizedBox(width: 12),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(color: _C.text, fontSize: 15,
            fontWeight: FontWeight.w700)),
        Text(subtitle, style: const TextStyle(color: _C.textSub, fontSize: 11)),
      ]),
      const Spacer(),
      Icon(icon, color: _C.textSub, size: 18),
    ]);
  }

  // ─── Sanction Card ────────────────────────────────────────────────────────
  Widget _buildSanctionCard() {
    return AnimatedBuilder(
      animation: _sanctionCtrl,
      builder: (_, __) => Container(
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: _C.red.withOpacity(0.3 + _sanctionGlow.value * 0.2),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: _C.red.withOpacity(_sanctionGlow.value * 0.1),
              blurRadius: 30,
              spreadRadius: 0,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Column(children: [
            // Header stripe
            Container(
              height: 3,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    Color(0xFFEF4444),
                    Colors.transparent,
                  ],
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(22),
              child: Column(children: [
                // Icon
                Container(
                  width: 60, height: 60,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _C.red.withOpacity(0.1),
                    border: Border.all(
                      color: _C.red.withOpacity(0.3 + _sanctionGlow.value * 0.2),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _C.red.withOpacity(_sanctionGlow.value * 0.15),
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: Icon(Icons.gavel_rounded,
                      color: _C.red.withOpacity(0.8 + _sanctionGlow.value * 0.2),
                      size: 28),
                ),
                const SizedBox(height: 14),
                const Text('SANKSI',
                    style: TextStyle(color: _C.red, fontSize: 20,
                        fontWeight: FontWeight.w900, letterSpacing: 2,
                        shadows: [
                          Shadow(color: _C.red, blurRadius: 12),
                        ])),
                const SizedBox(height: 10),

                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: _C.surface,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _C.border),
                  ),
                  child: Column(children: [
                    const Text(
                      'Jika pengguna terbukti melanggar salah satu peraturan di atas:',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: _C.textSub, fontSize: 12, height: 1.5),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 10),
                      decoration: BoxDecoration(
                        color: _C.red.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: _C.red.withOpacity(0.25)),
                        boxShadow: [
                          BoxShadow(
                            color: _C.red.withOpacity(0.1),
                            blurRadius: 12,
                          ),
                        ],
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.block_rounded, color: _C.red, size: 16),
                          SizedBox(width: 8),
                          Text('Akun DIHAPUS secara permanen',
                              style: TextStyle(color: _C.text, fontSize: 13,
                                  fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'Tanpa pengembalian akun, saldo, atau kompensasi apa pun.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: _C.textSub, fontSize: 12,
                          height: 1.4),
                    ),
                  ]),
                ),
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _buildFooter() {
    return Column(children: [
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.borderLit.withOpacity(0.6)),
          boxShadow: [
            BoxShadow(
              color: _C.blueMid.withOpacity(0.08),
              blurRadius: 16,
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.shield_moon_rounded,
                color: _C.blue, size: 18),
            const SizedBox(width: 12),
            const Expanded(
              child: Text(
                'Peraturan ini dibuat untuk menjaga keamanan, kenyamanan, dan '
                'kestabilan ekosistem X-FAR App. Dengan menggunakan '
                'aplikasi ini, pengguna dianggap telah menyetujui seluruh '
                'peraturan di atas.',
                style: TextStyle(color: _C.textSub, fontSize: 12, height: 1.6,
                    fontStyle: FontStyle.italic),
              ),
            ),
          ],
        ),
      ),
      const SizedBox(height: 16),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(
          height: 3, width: 40,
          decoration: BoxDecoration(
            gradient: _C.btnGrad,
            borderRadius: BorderRadius.circular(2),
            boxShadow: [
              BoxShadow(color: _C.blue.withOpacity(0.5), blurRadius: 8),
            ],
          ),
        ),
        const SizedBox(width: 10),
        const Text('X-FAR project Team',
            style: TextStyle(color: _C.textDim, fontSize: 11,
                fontWeight: FontWeight.w600, letterSpacing: 0.5)),
        const SizedBox(width: 10),
        Container(
          height: 3, width: 40,
          decoration: BoxDecoration(
            gradient: _C.btnGrad,
            borderRadius: BorderRadius.circular(2),
            boxShadow: [
              BoxShadow(color: _C.blue.withOpacity(0.5), blurRadius: 8),
            ],
          ),
        ),
      ]),
    ]);
  }
}

// ─── Rule Card ────────────────────────────────────────────────────────────────
class _RuleCard extends StatefulWidget {
  final _Rule rule;
  final int number;
  const _RuleCard({required this.rule, required this.number});

  @override
  State<_RuleCard> createState() => _RuleCardState();
}

class _RuleCardState extends State<_RuleCard> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final color = widget.rule.color;

    return GestureDetector(
      onTap: () => setState(() => _expanded = !_expanded),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOutCubic,
        decoration: BoxDecoration(
          color: _expanded ? color.withOpacity(0.05) : _C.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: _expanded ? color.withOpacity(0.4) : _C.border,
            width: _expanded ? 1.5 : 1.0,
          ),
          boxShadow: _expanded
              ? [
                  BoxShadow(color: color.withOpacity(0.1), blurRadius: 20,
                      offset: const Offset(0, 4)),
                ]
              : [
                  BoxShadow(color: _C.blueMid.withOpacity(0.04), blurRadius: 8),
                ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(14),
              child: Row(children: [
                // Icon container
                AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    color: color.withOpacity(_expanded ? 0.15 : 0.08),
                    borderRadius: BorderRadius.circular(11),
                    border: Border.all(
                        color: color.withOpacity(_expanded ? 0.5 : 0.2)),
                    boxShadow: _expanded
                        ? [BoxShadow(color: color.withOpacity(0.2), blurRadius: 12)]
                        : [],
                  ),
                  child: Icon(widget.rule.icon, color: color, size: 18),
                ),
                const SizedBox(width: 12),
                // Title + badge
                Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(color: color.withOpacity(0.3)),
                        ),
                        child: Text('Rule ${widget.number}',
                            style: TextStyle(color: color, fontSize: 9,
                                fontWeight: FontWeight.w800, letterSpacing: 0.5)),
                      ),
                    ]),
                    const SizedBox(height: 4),
                    Text(widget.rule.title,
                        style: const TextStyle(color: _C.text, fontSize: 13,
                            fontWeight: FontWeight.w700, height: 1.2)),
                  ],
                )),
                // Chevron
                AnimatedRotation(
                  turns: _expanded ? 0.5 : 0,
                  duration: const Duration(milliseconds: 220),
                  child: const Icon(Icons.keyboard_arrow_down_rounded,
                      color: _C.textDim, size: 20),
                ),
              ]),
            ),

            // Expanded desc
            AnimatedCrossFade(
              firstChild: const SizedBox(width: double.infinity),
              secondChild: Padding(
                padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _C.surface,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _C.borderLit.withOpacity(0.5)),
                  ),
                  child: Text(widget.rule.desc,
                      style: const TextStyle(color: _C.textSub, fontSize: 13,
                          height: 1.6)),
                ),
              ),
              crossFadeState: _expanded
                  ? CrossFadeState.showSecond
                  : CrossFadeState.showFirst,
              duration: const Duration(milliseconds: 250),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Stagger Item ─────────────────────────────────────────────────────────────
class _StaggerItem extends StatelessWidget {
  final int index;
  final Widget child;
  const _StaggerItem({required this.index, required this.child});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 400 + (index * 80).clamp(0, 500)),
      curve: Curves.easeOutCubic,
      builder: (_, v, ch) => Opacity(
        opacity: v,
        child: Transform.translate(offset: Offset(0, 16 * (1 - v)), child: ch),
      ),
      child: child,
    );
  }
}

// ─── Dots Loader ──────────────────────────────────────────────────────────────
class _DotsLoader extends StatefulWidget {
  const _DotsLoader();

  @override
  State<_DotsLoader> createState() => _DotsLoaderState();
}

class _DotsLoaderState extends State<_DotsLoader>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat();
  }

  @override
  void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) => Row(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(3, (i) {
          final t = ((_c.value - i / 3) % 1.0).clamp(0.0, 1.0);
          final s = math.sin(t * math.pi);
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Transform.scale(
              scale: 0.4 + s * 0.6,
              child: Container(
                width: 9, height: 9,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _C.blueLight.withOpacity(0.4 + s * 0.6),
                  boxShadow: [
                    BoxShadow(
                      color: _C.blueLight.withOpacity(s * 0.6),
                      blurRadius: 10,
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

// ─── Animated Background ──────────────────────────────────────────────────────
class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) =>
          CustomPaint(painter: _BgPainter(controller.value)),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    // Base gradient terang
    final bgPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Color(0xFFF5F9FF),
          Color(0xFFEAF2FF),
          Color(0xFFF5F9FF),
        ],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), bgPaint);

    // Grid halus
    final grid = Paint()
      ..color = _C.border.withOpacity(0.3)
      ..strokeWidth = 0.5;
    const step = 38.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    // Glow biru soft di atas
    final glow = Paint()
      ..shader = RadialGradient(colors: [
        _C.blueLight.withOpacity(0.08 + math.sin(t * math.pi * 2) * 0.02),
        _C.blueMid.withOpacity(0.03),
        Colors.transparent,
      ], radius: 0.85).createShader(Rect.fromCircle(
          center: Offset(size.width / 2, size.height * 0.18),
          radius: size.width * 0.65));
    canvas.drawCircle(
        Offset(size.width / 2, size.height * 0.18), size.width * 0.65, glow);

    // Glow tambahan di bawah
    final glowBottom = Paint()
      ..shader = RadialGradient(colors: [
        _C.blueMid.withOpacity(0.05),
        Colors.transparent,
      ], radius: 0.6).createShader(Rect.fromCircle(
          center: Offset(size.width * 0.5, size.height * 0.9),
          radius: size.width * 0.55));
    canvas.drawCircle(
        Offset(size.width * 0.5, size.height * 0.9),
        size.width * 0.55, glowBottom);
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}