import 'dart:io';
import 'dart:math' show pi, sin, cos, min, max;
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:gal/gal.dart';
import 'package:intl/intl.dart';
import 'package:flutter/services.dart';

// ============ PALET WARNA LIGHT CYBERPUNK ============
const Color _bgDark     = Color(0xFFF5F9FF);
const Color _bgCard     = Color(0xFFFFFFFF);
const Color _bgSurface  = Color(0xFFEFF6FF);
const Color _accentRed  = Color(0xFF2563EB);
const Color _accentPink = Color(0xFF3B82F6);
const Color _gold       = Color(0xFFF59E0B);
const Color _green      = Color(0xFF10B981);
const Color _cyan       = Color(0xFF0EA5E9);
const Color _textMain   = Color(0xFF0F172A);
const Color _textSub    = Color(0xFF475569);
const Color _borderSoft = Color(0xFFD6E4F5);
// =====================================================

class IQCScreen extends StatefulWidget {
  const IQCScreen({super.key});

  @override
  State<IQCScreen> createState() => _IQCScreenState();
}

class _IQCScreenState extends State<IQCScreen> with TickerProviderStateMixin {
  final TextEditingController _textController = TextEditingController();
  final TextEditingController _chatTimeController = TextEditingController();
  final TextEditingController _statusBarTimeController = TextEditingController();

  Uint8List? _generatedImage;
  bool _isGenerating = false;
  bool _isSaving = false;
  String? _errorMessage;

  late AnimationController _glowCtrl;
  late AnimationController _shimmerCtrl;

  @override
  void initState() {
    super.initState();
    final timeFormat = DateFormat('HH:mm');
    final now = DateTime.now();
    _chatTimeController.text = timeFormat.format(now);
    _statusBarTimeController.text = timeFormat.format(now);
    _textController.text = 'Res Dev Ganteng 😝';

    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();
    _shimmerCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    _shimmerCtrl.dispose();
    _textController.dispose();
    _chatTimeController.dispose();
    _statusBarTimeController.dispose();
    super.dispose();
  }

  // ============ LOGIC ============
  bool _isValidTime(String time) {
    final regex = RegExp(r'^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$');
    return regex.hasMatch(time);
  }

  Future<void> _generateIQCImage() async {
    if (_textController.text.isEmpty) {
      _showError('Masukkan teks chat terlebih dahulu');
      return;
    }
    if (_chatTimeController.text.isEmpty ||
        _statusBarTimeController.text.isEmpty) {
      _showError('Masukkan waktu chat dan status bar');
      return;
    }
    if (!_isValidTime(_chatTimeController.text)) {
      _showError('Format waktu chat salah (gunakan HH:mm)');
      return;
    }
    if (!_isValidTime(_statusBarTimeController.text)) {
      _showError('Format waktu status bar salah (gunakan HH:mm)');
      return;
    }

    setState(() {
      _isGenerating = true;
      _errorMessage = null;
      _generatedImage = null;
    });

    try {
      final text = Uri.encodeComponent(_textController.text);
      final chatTime = Uri.encodeComponent(_chatTimeController.text);
      final statusBarTime = Uri.encodeComponent(_statusBarTimeController.text);
      final apiUrl =
          OmhcSilenceProtect.decode(["nW4Opsj2DSWCUu1tJ/iR1D6Hli3sSDTo8Q0xjQpFGAm","8SznJ74l6Xv4m0AYbyfv+GKPsLsBnX5yRYRStNVQja9","B8SeKa+Bc54QO2V2qw2MA00Yx7vR8pg7QQSMVMBQ=="]);

      final response = await http.get(
        Uri.parse(apiUrl),
        headers: {'User-Agent': 'IQC-Screenshot-Maker/1.0'},
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200 && response.bodyBytes.isNotEmpty) {
        setState(() {
          _generatedImage = response.bodyBytes;
        });
        _showSuccess('Gambar berhasil dihasilkan dari API');
      } else {
        throw Exception('API Error: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Gagal menghubungi API: $e';
      });
      _showError(_errorMessage!);
    } finally {
      setState(() {
        _isGenerating = false;
      });
    }
  }

  Future<void> _saveImage() async {
    if (_generatedImage == null) {
      _showError('Tidak ada gambar untuk disimpan');
      return;
    }

    setState(() {
      _isSaving = true;
    });

    try {
      final tempDir = await getTemporaryDirectory();
      final timestamp = DateFormat('yyyyMMdd_HHmmss').format(DateTime.now());
      final fileName =
          'iqc_${_textController.text.replaceAll(' ', '_')}_$timestamp.png';
      final file = File('${tempDir.path}/$fileName');
      await file.writeAsBytes(_generatedImage!);

      await Gal.putImage(file.path, album: 'H3R0BL4D3X');

      _showSuccess('Gambar disimpan ke galeri!');
      _showSaveSuccessDialog(file.path, fileName);
    } catch (e) {
      _showError('Gagal menyimpan gambar: $e');
    } finally {
      setState(() {
        _isSaving = false;
      });
    }
  }

  Future<void> _copyToClipboard(String text) async {
    await Clipboard.setData(ClipboardData(text: text));
    _showSuccess('Disalin ke clipboard: $text');
  }

  void _showSuccess(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(
            color: _textMain,
            fontWeight: FontWeight.w800,
            fontSize: 12.5,
          ),
        ),
        backgroundColor: _bgCard,
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: _green, width: 1.2),
        ),
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        elevation: 0,
      ),
    );
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(
            color: _textMain,
            fontWeight: FontWeight.w800,
            fontSize: 12.5,
          ),
        ),
        backgroundColor: _bgCard,
        duration: const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: _accentRed, width: 1.2),
        ),
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        elevation: 0,
      ),
    );
  }

  void _showSaveSuccessDialog(String filePath, String fileName) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.4),
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: _bgCard,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: _green, width: 1.5),
            boxShadow: [
              BoxShadow(
                color: _green.withOpacity(0.15),
                blurRadius: 30,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _green.withOpacity(0.1),
                      border: Border.all(color: _green, width: 1.5),
                    ),
                    child: const Icon(Icons.check_circle_outline_rounded,
                        color: _green, size: 19),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    'Gambar Disimpan!',
                    style: TextStyle(
                      color: _textMain,
                      fontWeight: FontWeight.w900,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              const Text(
                'Gambar berhasil disimpan di galeri.',
                style: TextStyle(
                  color: _textSub,
                  fontSize: 12.5,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _bgSurface,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _borderSoft, width: 1),
                ),
                child: Text(
                  fileName,
                  style: const TextStyle(
                    color: _textMain,
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'Anda dapat membagikan gambar melalui aplikasi galeri.',
                style: TextStyle(
                  color: _textSub.withOpacity(0.8),
                  fontSize: 11.5,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        _copyToClipboard(filePath);
                        Navigator.pop(context);
                      },
                      child: Container(
                        height: 44,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: _cyan, width: 1.4),
                          boxShadow: [
                            BoxShadow(
                              color: _cyan.withOpacity(0.15),
                              blurRadius: 12,
                            ),
                          ],
                        ),
                        child: const Center(
                          child: Text(
                            'SALIN PATH',
                            style: TextStyle(
                              color: _cyan,
                              fontWeight: FontWeight.w900,
                              fontSize: 11.5,
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        height: 44,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          gradient: const LinearGradient(
                            colors: [_accentRed, _accentPink],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: _accentRed.withOpacity(0.3),
                              blurRadius: 14,
                            ),
                          ],
                        ),
                        child: const Center(
                          child: Text(
                            'OK',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                              fontSize: 11.5,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInputField({
    required String label,
    required TextEditingController controller,
    String hint = '',
    bool isTime = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: _textSub.withOpacity(0.8),
            fontSize: 10.5,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.5,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: _bgSurface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _borderSoft, width: 1.2),
          ),
          child: TextField(
            controller: controller,
            cursorColor: _accentRed,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(
                color: _textSub.withOpacity(0.4),
                fontSize: 13,
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 14,
              ),
              suffixIcon: isTime
                  ? IconButton(
                      onPressed: () {
                        final timeFormat = DateFormat('HH:mm');
                        final now = DateTime.now();
                        controller.text = timeFormat.format(now);
                      },
                      icon: const Icon(Icons.access_time_rounded,
                          color: _accentRed, size: 18),
                      tooltip: 'Gunakan waktu sekarang',
                    )
                  : null,
            ),
            style: const TextStyle(
              color: _textMain,
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
            maxLines: isTime ? 1 : 3,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgDark,
      body: Stack(
        children: [
          Positioned.fill(
            child: IgnorePointer(
              child: AnimatedBuilder(
                animation: _glowCtrl,
                builder: (_, __) {
                  final t = _glowCtrl.value * 2 * pi;
                  return Container(
                    decoration: BoxDecoration(
                      gradient: RadialGradient(
                        center: Alignment(sin(t) * 0.4, cos(t) * 0.4 - 0.3),
                        radius: 1.4,
                        colors: [
                          _accentRed.withOpacity(0.05),
                          _bgDark.withOpacity(0.8),
                          _bgDark,
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
                  child: Row(
                    children: [
                      _CircleIconBtn(
                        icon: Icons.arrow_back_ios_new,
                        onTap: () => Navigator.pop(context),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Center(
                          child: ShaderMask(
                            shaderCallback: (bounds) => LinearGradient(
                              colors: const [
                                _accentRed,
                                _accentPink,
                                _cyan,
                                _accentRed,
                              ],
                              transform:
                                  _SlideGradient(_shimmerCtrl.value),
                            ).createShader(bounds),
                            child: const Text(
                              "IQC MAKER",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 3,
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      _CircleIconBtn(
                        icon: Icons.info_outline_rounded,
                        onTap: () {
                          showDialog(
                            context: context,
                            barrierColor: Colors.black.withOpacity(0.4),
                            builder: (context) => Dialog(
                              backgroundColor: Colors.transparent,
                              child: Container(
                                padding: const EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                  color: _bgCard,
                                  borderRadius: BorderRadius.circular(18),
                                  border: Border.all(
                                      color: _accentRed, width: 1.5),
                                  boxShadow: [
                                    BoxShadow(
                                      color: _accentRed.withOpacity(0.15),
                                      blurRadius: 30,
                                      spreadRadius: 2,
                                    ),
                                  ],
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Container(
                                          width: 38,
                                          height: 38,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: _accentRed
                                                .withOpacity(0.1),
                                            border: Border.all(
                                                color: _accentRed,
                                                width: 1.5),
                                          ),
                                          child: const Icon(
                                              Icons.info_outline_rounded,
                                              color: _accentRed,
                                              size: 19),
                                        ),
                                        const SizedBox(width: 12),
                                        const Text(
                                          'Tentang',
                                          style: TextStyle(
                                            color: _textMain,
                                            fontWeight: FontWeight.w900,
                                            fontSize: 16,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 14),
                                    const Text(
                                      'Screen Shot WhatsApp iPhone\n\nFitur share sementara dinonaktifkan karena masalah kompatibilitas.',
                                      style: TextStyle(
                                        color: _textSub,
                                        fontSize: 12.5,
                                        height: 1.5,
                                      ),
                                    ),
                                    const SizedBox(height: 18),
                                    GestureDetector(
                                      onTap: () => Navigator.pop(context),
                                      child: Container(
                                        width: double.infinity,
                                        height: 44,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(12),
                                          gradient: const LinearGradient(
                                            colors: [
                                              _accentRed,
                                              _accentPink,
                                            ],
                                          ),
                                          boxShadow: [
                                            BoxShadow(
                                              color: _accentRed
                                                  .withOpacity(0.3),
                                              blurRadius: 14,
                                            ),
                                          ],
                                        ),
                                        child: const Center(
                                          child: Text(
                                            'TUTUP',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.w900,
                                              fontSize: 12,
                                              letterSpacing: 1.5,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),

                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // INPUT SECTION
                        Container(
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(
                            color: _bgCard,
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(
                                color: _borderSoft, width: 1.2),
                            boxShadow: [
                              BoxShadow(
                                color: _accentRed.withOpacity(0.05),
                                blurRadius: 20,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              _buildInputField(
                                label: 'TEKS CHAT',
                                controller: _textController,
                                hint: 'Masukkan teks chat...',
                              ),
                              const SizedBox(height: 18),
                              Row(
                                children: [
                                  Expanded(
                                    child: _buildInputField(
                                      label: 'WAKTU CHAT',
                                      controller: _chatTimeController,
                                      hint: 'HH:mm',
                                      isTime: true,
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: _buildInputField(
                                      label: 'STATUS BAR',
                                      controller: _statusBarTimeController,
                                      hint: 'HH:mm',
                                      isTime: true,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),
                              GestureDetector(
                                onTap: () => _copyToClipboard('22:11'),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.info_outline_rounded,
                                      size: 12,
                                      color: _textSub.withOpacity(0.7),
                                    ),
                                    const SizedBox(width: 5),
                                    Text(
                                      'Format waktu: HH:mm (contoh: 22:11)',
                                      style: TextStyle(
                                        color: _textSub.withOpacity(0.7),
                                        fontSize: 10.5,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 20),
                              GestureDetector(
                                onTap: _isGenerating
                                    ? null
                                    : _generateIQCImage,
                                child: Container(
                                  width: double.infinity,
                                  height: 54,
                                  decoration: BoxDecoration(
                                    borderRadius:
                                        BorderRadius.circular(14),
                                    gradient: LinearGradient(
                                      colors: _isGenerating
                                          ? [_textSub, _textSub]
                                          : [_accentRed, _accentPink],
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ),
                                    boxShadow: _isGenerating
                                        ? []
                                        : [
                                            BoxShadow(
                                              color: _accentRed
                                                  .withOpacity(0.3),
                                              blurRadius: 22,
                                              spreadRadius: 1,
                                            ),
                                          ],
                                  ),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.center,
                                    children: [
                                      if (_isGenerating)
                                        const SizedBox(
                                          width: 20,
                                          height: 20,
                                          child:
                                              CircularProgressIndicator(
                                            strokeWidth: 2.5,
                                            color: Colors.white,
                                          ),
                                        )
                                      else
                                        const Icon(
                                            Icons.generating_tokens_rounded,
                                            color: Colors.white,
                                            size: 18),
                                      const SizedBox(width: 10),
                                      Text(
                                        _isGenerating
                                            ? 'MEMBUAT...'
                                            : 'BUAT SCREENSHOT',
                                        style: const TextStyle(
                                          fontSize: 13,
                                          fontWeight: FontWeight.w900,
                                          color: Colors.white,
                                          letterSpacing: 2,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              if (_errorMessage != null) ...[
                                const SizedBox(height: 14),
                                Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: _accentRed.withOpacity(0.08),
                                    borderRadius:
                                        BorderRadius.circular(12),
                                    border: Border.all(
                                        color: _accentRed, width: 1.2),
                                  ),
                                  child: Row(
                                    children: [
                                      const Icon(Icons.error_outline,
                                          color: _accentRed, size: 16),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: Text(
                                          _errorMessage!,
                                          style: const TextStyle(
                                            color: _accentPink,
                                            fontSize: 11.5,
                                            fontWeight: FontWeight.w700,
                                            height: 1.4,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),

                        // HASIL SCREENSHOT
                        Container(
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(
                            color: _bgCard,
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(
                                color: _borderSoft, width: 1.2),
                            boxShadow: [
                              BoxShadow(
                                color: _accentRed.withOpacity(0.05),
                                blurRadius: 20,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    width: 32,
                                    height: 32,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: _cyan.withOpacity(0.1),
                                      border: Border.all(
                                          color: _cyan, width: 1.3),
                                      boxShadow: [
                                        BoxShadow(
                                          color: _cyan.withOpacity(0.15),
                                          blurRadius: 12,
                                        ),
                                      ],
                                    ),
                                    child: const Icon(Icons.preview_rounded,
                                        color: _cyan, size: 16),
                                  ),
                                  const SizedBox(width: 10),
                                  const Text(
                                    'HASIL SCREENSHOT',
                                    style: TextStyle(
                                      color: _textMain,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 1.5,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 16),
                              if (_generatedImage != null)
                                Container(
                                  width: double.infinity,
                                  constraints:
                                      const BoxConstraints(maxHeight: 600),
                                  decoration: BoxDecoration(
                                    borderRadius:
                                        BorderRadius.circular(14),
                                    border: Border.all(
                                        color: _accentRed.withOpacity(0.3),
                                        width: 1.2),
                                    boxShadow: [
                                      BoxShadow(
                                        color: _accentRed.withOpacity(0.1),
                                        blurRadius: 18,
                                      ),
                                    ],
                                  ),
                                  child: ClipRRect(
                                    borderRadius:
                                        BorderRadius.circular(13),
                                    child: Image.memory(
                                      _generatedImage!,
                                      fit: BoxFit.contain,
                                      errorBuilder:
                                          (context, error, stackTrace) {
                                        return Container(
                                          height: 300,
                                          color: _bgSurface,
                                          child: const Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Icon(
                                                  Icons.broken_image_rounded,
                                                  size: 64,
                                                  color: _accentRed),
                                              SizedBox(height: 16),
                                              Text(
                                                'Gagal memuat gambar',
                                                style: TextStyle(
                                                  color: _accentRed,
                                                  fontWeight:
                                                      FontWeight.w900,
                                                ),
                                              ),
                                            ],
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                )
                              else
                                Container(
                                  height: 300,
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                    color: _bgSurface,
                                    borderRadius:
                                        BorderRadius.circular(14),
                                    border: Border.all(
                                        color: _borderSoft, width: 1.2),
                                  ),
                                  child: Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        width: 90,
                                        height: 90,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: _accentRed
                                              .withOpacity(0.08),
                                          border: Border.all(
                                              color: _accentRed
                                                  .withOpacity(0.3),
                                              width: 1.3),
                                        ),
                                        child: const Icon(
                                            Icons.screenshot_monitor_rounded,
                                            size: 42,
                                            color: _accentRed),
                                      ),
                                      const SizedBox(height: 18),
                                      const Text(
                                        'Belum ada screenshot',
                                        style: TextStyle(
                                          color: _textMain,
                                          fontSize: 14,
                                          fontWeight: FontWeight.w900,
                                          letterSpacing: 0.5,
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                      Padding(
                                        padding: const EdgeInsets
                                            .symmetric(horizontal: 20),
                                        child: Text(
                                          'Masukkan teks dan waktu, lalu klik "BUAT SCREENSHOT"',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            color: _textSub
                                                .withOpacity(0.7),
                                            fontSize: 11.5,
                                            fontWeight: FontWeight.w600,
                                            height: 1.5,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              if (_generatedImage != null) ...[
                                const SizedBox(height: 12),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Ukuran: ${(_generatedImage!.lengthInBytes / 1024).toStringAsFixed(1)} KB',
                                      style: const TextStyle(
                                        color: _textSub,
                                        fontSize: 10.5,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    Text(
                                      'Dibuat: ${DateFormat('HH:mm:ss').format(DateTime.now())}',
                                      style: const TextStyle(
                                        color: _textSub,
                                        fontSize: 10.5,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 16),
                                GestureDetector(
                                  onTap: _isSaving ? null : _saveImage,
                                  child: Container(
                                    width: double.infinity,
                                    height: 52,
                                    decoration: BoxDecoration(
                                      borderRadius:
                                          BorderRadius.circular(14),
                                      border: Border.all(
                                          color: _green, width: 1.4),
                                      boxShadow: [
                                        BoxShadow(
                                          color: _green.withOpacity(0.2),
                                          blurRadius: 18,
                                        ),
                                      ],
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        if (_isSaving)
                                          const SizedBox(
                                            width: 20,
                                            height: 20,
                                            child:
                                                CircularProgressIndicator(
                                              strokeWidth: 2.5,
                                              color: _green,
                                            ),
                                          )
                                        else
                                          const Icon(
                                              Icons.save_alt_rounded,
                                              size: 18,
                                              color: _green),
                                        const SizedBox(width: 10),
                                        Text(
                                          _isSaving
                                              ? 'MENYIMPAN...'
                                              : 'SIMPAN KE GALERI',
                                          style: const TextStyle(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w900,
                                            color: _green,
                                            letterSpacing: 1.5,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),

                        // CONTOH CEPAT
                        Container(
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(
                            color: _bgCard,
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(
                                color: _borderSoft, width: 1.2),
                            boxShadow: [
                              BoxShadow(
                                color: _accentRed.withOpacity(0.05),
                                blurRadius: 20,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    width: 32,
                                    height: 32,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: _gold.withOpacity(0.1),
                                      border: Border.all(
                                          color: _gold, width: 1.3),
                                      boxShadow: [
                                        BoxShadow(
                                          color: _gold.withOpacity(0.15),
                                          blurRadius: 12,
                                        ),
                                      ],
                                    ),
                                    child: const Icon(Icons.bolt_rounded,
                                        color: _gold, size: 16),
                                  ),
                                  const SizedBox(width: 10),
                                  const Text(
                                    'CONTOH CEPAT',
                                    style: TextStyle(
                                      color: _textMain,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 1.5,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 14),
                              Wrap(
                                spacing: 8,
                                runSpacing: 8,
                                children: [
                                  _buildExampleChip(
                                      'Malam minggu yuk', '20:00', '20:05'),
                                  _buildExampleChip(
                                      'Besok ketemuan dimana?',
                                      '15:30',
                                      '15:45'),
                                  _buildExampleChip(
                                      'Lagi apa?', '21:15', '21:20'),
                                  _buildExampleChip('Udah makan belum?',
                                      '12:00', '12:10'),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 40),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildExampleChip(
      String text, String chatTime, String statusBarTime) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _textController.text = text;
          _chatTimeController.text = chatTime;
          _statusBarTimeController.text = statusBarTime;
        });
        _showSuccess('Contoh diterapkan');
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: _bgSurface,
          border: Border.all(color: _borderSoft, width: 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              text.length > 20 ? '${text.substring(0, 20)}...' : text,
              style: const TextStyle(
                color: _textMain,
                fontSize: 11.5,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              '$chatTime | $statusBarTime',
              style: TextStyle(
                color: _textSub.withOpacity(0.8),
                fontSize: 9.5,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// TOMBOL BULAT
// ============================================================
class _CircleIconBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _CircleIconBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _bgCard,
          border: Border.all(color: _borderSoft, width: 1.3),
          boxShadow: [
            BoxShadow(
              color: _accentRed.withOpacity(0.1),
              blurRadius: 14,
            ),
          ],
        ),
        child: Icon(icon, color: _accentRed, size: 16),
      ),
    );
  }
}

// ============================================================
// HELPER: SHIMMER GRADIENT (FIXED)
// ============================================================
class _SlideGradient extends GradientTransform {
  final double t;
  _SlideGradient(this.t);

  @override
  Matrix4 transform(Rect bounds, {ui.TextDirection? textDirection}) {
    return Matrix4.translationValues(bounds.width * (t * 2 - 0.5), 0, 0);
  }
}