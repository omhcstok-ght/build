import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

// ============ PALET WARNA DARK CYBERPUNK ============
const Color _bgDark     = Color(0xFF0A0608);
const Color _bgCard     = Color(0xFF140D10);
const Color _bgSurface  = Color(0xFF1A1014);
const Color _accentRed  = Color(0xFFFF2E63);
const Color _accentPink = Color(0xFFFF4D8D);
const Color _gold       = Color(0xFFD4AF37);
const Color _green      = Color(0xFF2ECC71);
const Color _cyan       = Color(0xFF00E5FF);
const Color _textMain   = Color(0xFFF5F5F5);
const Color _textSub    = Color(0xFF9A8F94);
const Color _borderSoft = Color(0x33FF2E63);
// =====================================================

class EncryptionRavenClawx extends StatefulWidget {
  const EncryptionRavenClawx({super.key});

  @override
  State<EncryptionRavenClawx> createState() => _EncryptionRavenClawxState();
}

class _EncryptionRavenClawxState extends State<EncryptionRavenClawx>
    with TickerProviderStateMixin {
  String fileType = 'js';
  String inputText = '';
  String outputText = '';

  final TextEditingController _inputCtrl = TextEditingController();
  final TextEditingController _outputCtrl = TextEditingController();

  late AnimationController _glowCtrl;
  late AnimationController _shimmerCtrl;

  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();
    _shimmerCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    _shimmerCtrl.dispose();
    _inputCtrl.dispose();
    _outputCtrl.dispose();
    super.dispose();
  }

  // ============ LOGIC (JANGAN DIUBAH) ============
  String encrypt(String text) => base64Encode(utf8.encode(text));
  String decrypt(String text) => utf8.decode(base64Decode(text));

  Future<void> autoDownload(String data) async {
    try {
      final dir = await getExternalStorageDirectory();
      final fileName =
          "RavenClawx_${DateTime.now().millisecondsSinceEpoch}.$fileType";
      final file = File("${dir!.path}/$fileName");
      await file.writeAsString(data);

      _snack("Saved: $fileName", success: true);
    } catch (e) {
      _snack("Gagal simpan: $e");
    }
  }
  // ============ END LOGIC ============

  void _snack(String msg, {bool success = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: const TextStyle(
            color: _textMain,
            fontWeight: FontWeight.w800,
            fontSize: 12.5,
          ),
        ),
        backgroundColor: _bgCard,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(
            color: success ? _green : _accentRed,
            width: 1.2,
          ),
        ),
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        elevation: 0,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgDark,
      body: Stack(
        children: [
          // Background RGB animated
          Positioned.fill(
            child: IgnorePointer(
              child: AnimatedBuilder(
                animation: _glowCtrl,
                builder: (_, __) {
                  final t = _glowCtrl.value * 2 * pi;
                  return Container(
                    decoration: BoxDecoration(
                      gradient: RadialGradient(
                        center: Alignment(sin(t) * 0.4, cos(t) * 0.4 - 0.3),
                        radius: 1.4,
                        colors: [
                          _accentRed.withOpacity(0.15),
                          _bgDark.withOpacity(0.9),
                          _bgDark,
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),

          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  // === HEADER ===
                  Row(
                    children: [
                      _CircleIconBtn(
                        icon: Icons.arrow_back_ios_new,
                        onTap: () => Navigator.pop(context),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Center(
                          child: ShaderMask(
                            shaderCallback: (bounds) => LinearGradient(
                              colors: const [
                                _accentRed,
                                _accentPink,
                                _cyan,
                                _accentRed,
                              ],
                              transform:
                                  _SlideGradient(_shimmerCtrl.value),
                            ).createShader(bounds),
                            child: const Text(
                              "ENCRYPTION",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 3,
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 42),
                    ],
                  ),
                  const SizedBox(height: 14),

                  // === DROPDOWN FILE TYPE ===
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    decoration: BoxDecoration(
                      color: _bgSurface,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: _borderSoft, width: 1.2),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        dropdownColor: _bgCard,
                        value: fileType,
                        icon: const Icon(Icons.keyboard_arrow_down_rounded,
                            color: _accentRed, size: 20),
                        style: const TextStyle(
                          color: _textMain,
                          fontWeight: FontWeight.w900,
                          fontSize: 13,
                        ),
                        isExpanded: true,
                        items: const [
                          DropdownMenuItem(
                            value: 'js',
                            child: Text("JavaScript (.js)"),
                          ),
                          DropdownMenuItem(
                            value: 'html',
                            child: Text("HTML (.html)"),
                          ),
                        ],
                        onChanged: (v) => setState(() => fileType = v!),
                      ),
                    ),
                  ),

                  const SizedBox(height: 12),

                  // === INPUT ===
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: _bgSurface,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: _borderSoft, width: 1.2),
                        boxShadow: [
                          BoxShadow(
                            color: _accentRed.withOpacity(0.08),
                            blurRadius: 14,
                          ),
                        ],
                      ),
                      child: TextField(
                        controller: _inputCtrl,
                        maxLines: null,
                        expands: true,
                        style: const TextStyle(
                          color: _textMain,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          height: 1.5,
                        ),
                        cursorColor: _accentRed,
                        decoration: InputDecoration(
                          labelText: "Input Source",
                          labelStyle: TextStyle(
                            color: _textSub.withOpacity(0.8),
                            fontSize: 11.5,
                            fontWeight: FontWeight.w700,
                          ),
                          hintText: "Tempel kode / teks di sini...",
                          hintStyle: TextStyle(
                            color: _textSub.withOpacity(0.4),
                            fontSize: 12.5,
                          ),
                          prefixIcon: const Padding(
                            padding: EdgeInsets.only(left: 12, top: 16),
                            child: Icon(Icons.code_rounded,
                                color: _accentRed, size: 18),
                          ),
                          border: InputBorder.none,
                          contentPadding:
                              const EdgeInsets.fromLTRB(48, 18, 14, 18),
                        ),
                        onChanged: (v) => inputText = v,
                      ),
                    ),
                  ),

                  const SizedBox(height: 12),

                  // === TOMBOL AKSI ===
                  Row(
                    children: [
                      Expanded(
                        child: GestureDetector(
                          onTap: () {
                            if (inputText.isEmpty) {
                              _snack("Input masih kosong bro");
                              return;
                            }
                            outputText = encrypt(inputText);
                            _outputCtrl.text = outputText;
                            autoDownload(outputText);
                            setState(() {});
                          },
                          child: Container(
                            padding:
                                const EdgeInsets.symmetric(vertical: 14),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(14),
                              gradient: const LinearGradient(
                                colors: [_accentRed, _accentPink],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: _accentRed.withOpacity(0.5),
                                  blurRadius: 18,
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisAlignment:
                                  MainAxisAlignment.center,
                              children: const [
                                Icon(Icons.enhanced_encryption_rounded,
                                    color: Colors.white, size: 16),
                                SizedBox(width: 6),
                                Flexible(
                                  child: Text(
                                    "Encrypt + Save",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w900,
                                      fontSize: 11.5,
                                      letterSpacing: 0.5,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: GestureDetector(
                          onTap: () {
                            if (inputText.isEmpty) {
                              _snack("Input masih kosong bro");
                              return;
                            }
                            try {
                              outputText = decrypt(inputText);
                              _outputCtrl.text = outputText;
                              setState(() {});
                            } catch (e) {
                              _snack(
                                  "Gagal decrypt — pastikan Base64 valid");
                            }
                          },
                          child: Container(
                            padding:
                                const EdgeInsets.symmetric(vertical: 14),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(14),
                              border:
                                  Border.all(color: _green, width: 1.5),
                              boxShadow: [
                                BoxShadow(
                                  color: _green.withOpacity(0.4),
                                  blurRadius: 18,
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisAlignment:
                                  MainAxisAlignment.center,
                              children: const [
                                Icon(Icons.lock_open_rounded,
                                    color: _green, size: 16),
                                SizedBox(width: 6),
                                Flexible(
                                  child: Text(
                                    "Decrypt",
                                    style: TextStyle(
                                      color: _green,
                                      fontWeight: FontWeight.w900,
                                      fontSize: 11.5,
                                      letterSpacing: 0.5,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),

                  // === OUTPUT ===
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: _bgCard.withOpacity(0.85),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: outputText.isNotEmpty
                              ? _green.withOpacity(0.5)
                              : _borderSoft,
                          width: 1.2,
                        ),
                        boxShadow: outputText.isNotEmpty
                            ? [
                                BoxShadow(
                                  color: _green.withOpacity(0.2),
                                  blurRadius: 16,
                                ),
                              ]
                            : [
                                BoxShadow(
                                  color: _accentRed.withOpacity(0.08),
                                  blurRadius: 14,
                                ),
                              ],
                      ),
                      child: TextField(
                        controller: _outputCtrl,
                        readOnly: true,
                        maxLines: null,
                        expands: true,
                        style: const TextStyle(
                          color: _textMain,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          height: 1.5,
                        ),
                        cursorColor: _green,
                        decoration: InputDecoration(
                          labelText: "Output Result",
                          labelStyle: TextStyle(
                            color: _textSub.withOpacity(0.8),
                            fontSize: 11.5,
                            fontWeight: FontWeight.w700,
                          ),
                          hintText: "Hasil muncul di sini...",
                          hintStyle: TextStyle(
                            color: _textSub.withOpacity(0.4),
                            fontSize: 12.5,
                          ),
                          prefixIcon: const Padding(
                            padding: EdgeInsets.only(left: 12, top: 16),
                            child: Icon(Icons.output_rounded,
                                color: _green, size: 18),
                          ),
                          border: InputBorder.none,
                          contentPadding:
                              const EdgeInsets.fromLTRB(48, 18, 14, 18),
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 10),

                  // === FOOTER INFO ===
                  Text(
                    "BASE64  ·  RAVENCLAWX ENGINE",
                    style: TextStyle(
                      color: _textSub.withOpacity(0.5),
                      fontSize: 9.5,
                      letterSpacing: 2.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// TOMBOL BULAT
// ============================================================
class _CircleIconBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _CircleIconBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _bgCard,
          border: Border.all(color: _borderSoft, width: 1.3),
          boxShadow: [
            BoxShadow(
              color: _accentRed.withOpacity(0.25),
              blurRadius: 14,
            ),
          ],
        ),
        child: Icon(icon, color: _accentRed, size: 16),
      ),
    );
  }
}

// ============================================================
// HELPER: SHIMMER GRADIENT
// ============================================================
class _SlideGradient extends GradientTransform {
  final double t;
  _SlideGradient(this.t);

  @override
  Matrix4 transform(Rect bounds, {TextDirection? textDirection}) {
    return Matrix4.translationValues(bounds.width * (t * 2 - 0.5), 0, 0);
  }
}