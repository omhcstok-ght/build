class Api {
  static const String api = "http://nodecloudlegalraraapremium.xzcl.web.id:6018";
}