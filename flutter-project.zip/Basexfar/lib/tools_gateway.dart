import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:audioplayers/audioplayers.dart'; // ✅ Import Audio

// ═══════════════════════════════════════════════════════════════════════
//  EXISTING IMPORTS
// ═══════════════════════════════════════════════════════════════════════
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'cek_ban_wa.dart';
import 'amprem_page.dart';
import 'anime_home.dart';
import 'spamotp.dart';
import 'youtube_tools.dart';
import 'dracin_page.dart';
import 'ddos_cloudflare.dart';
import 'create_vps_page.dart';
import 'comic.dart';
import 'breach_checker.dart';
import 'enc.dart';
import 'screens/list_benefit_screen.dart';
import 'wa_report.dart';
import 'tourl.dart';
import 'telegram_report_system.dart';
import 'iqc_page.dart';
import 'hentai_page.dart';
import 'fakestory.dart';
import 'encryption_base64.dart';
import 'donghua.dart';
import 'country_negara.dart';
import 'animek2.dart';
import 'viewhtml.dart';
import 'fixeror.dart';

// ═══════════════════════════════════════════════════════════════════════
//  LIGHT MODE THEME
// ═══════════════════════════════════════════════════════════════════════
class _C {
  static const bg        = Color(0xFFF5F9FF);
  static const surface   = Color(0xFFFFFFFF);
  static const card      = Color(0xFFFFFFFF);
  static const cardInner = Color(0xFFEFF6FF);
  static const border    = Color(0xFFD6E4F5);
  static const borderLit = Color(0xFFB6CDE8);

  static const neonBlue   = Color(0xFF2563EB);
  static const neonRed    = Color(0xFFEF4444);
  static const neonPurple = Color(0xFF8B5CF6);
  static const neonViolet = Color(0xFFEC4899);
  static const neonGreen  = Color(0xFF10B981);
  static const neonGold   = Color(0xFFF59E0B);

  static const text      = Color(0xFF0F172A);
  static const textSub   = Color(0xFF475569);
  static const textDim   = Color(0xFF94A3B8);

  static const LinearGradient neonGradient = LinearGradient(
    colors: [Color(0xFF60A5FA), Color(0xFF3B82F6), Color(0xFF2563EB)],
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );
}

// ═══════════════════════════════════════════════════════════════════════
//  ROLE COLOR HELPER
// ═══════════════════════════════════════════════════════════════════════
Color _getRoleColor(String role) {
  switch (role.toLowerCase()) {
    case 'developer': return _C.neonBlue;
    case 'owner':     return _C.neonRed;
    case 'tk':        return _C.neonBlue;
    case 'admin':     return _C.neonPurple;
    case 'reseller':  return _C.neonGreen;
    case 'vip':       return _C.neonGold;
    case 'member':    return _C.textSub;
    default:          return _C.neonBlue;
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  TOOL CATEGORY DATA
// ═══════════════════════════════════════════════════════════════════════
class _ToolCategory {
  final String id;
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;

  const _ToolCategory({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
  });
}

const _categories = [
  _ToolCategory(
    id: 'ddos',
    title: 'Panel',
    subtitle: 'Attack & Server',
    icon: Icons.flash_on_rounded,
    accent: _C.neonBlue,
  ),
  _ToolCategory(
    id: 'network',
    title: 'Network',
    subtitle: 'WiFi & Spam',
    icon: Icons.wifi_rounded,
    accent: _C.neonPurple,
  ),
  _ToolCategory(
    id: 'osint',
    title: 'OSINT',
    subtitle: 'Investigation',
    icon: Icons.search_rounded,
    accent: _C.neonRed,
  ),
  _ToolCategory(
    id: 'downloader',
    title: 'Downloader',
    subtitle: 'Social Media',
    icon: Icons.download_rounded,
    accent: _C.neonBlue,
  ),
  _ToolCategory(
    id: 'generator',
    title: 'Generator',
    subtitle: 'Buat & Edit',
    icon: Icons.build_rounded,
    accent: _C.neonRed,
  ),
  _ToolCategory(
    id: 'anime',
    title: 'Anime',
    subtitle: 'Stream & Watch',
    icon: Icons.movie_filter_rounded,
    accent: _C.neonViolet,
  ),
  _ToolCategory(
    id: 'premium',
    title: 'Premium',
    subtitle: 'Amprem & More',
    icon: Icons.workspace_premium_rounded,
    accent: _C.neonBlue,
  ),
  _ToolCategory(
    id: 'benefit',
    title: 'Benefit',
    subtitle: 'Gratis & Tools',
    icon: Icons.card_giftcard_rounded,
    accent: _C.neonGold,
  ),
  _ToolCategory(
    id: 'vps',
    title: 'VPS',
    subtitle: 'Cloud Server',
    icon: Icons.cloud_rounded,
    accent: _C.neonBlue,
  ),
  _ToolCategory(
    id: 'security',
    title: 'Security',
    subtitle: 'Breach & Encrypt',
    icon: Icons.security_rounded,
    accent: _C.neonRed,
  ),
  _ToolCategory(
    id: 'entertainment',
    title: 'Entertainment',
    subtitle: 'Comic & Drama',
    icon: Icons.theater_comedy_rounded,
    accent: _C.neonViolet,
  ),
  _ToolCategory(
    id: 'report',
    title: 'Report',
    subtitle: 'WA & Telegram',
    icon: Icons.report_problem_rounded,
    accent: _C.neonRed,
  ),
  _ToolCategory(
    id: 'upload',
    title: 'Upload',
    subtitle: 'File to URI',
    icon: Icons.cloud_upload_rounded,
    accent: _C.neonBlue,
  ),
  _ToolCategory(
    id: 'iqc',
    title: 'IQC',
    subtitle: 'Chat Generator',
    icon: Icons.chat_bubble_rounded,
    accent: _C.neonBlue,
  ),
];

// ═══════════════════════════════════════════════════════════════════════
//  PAGE UTAMA — TOOLS GATEWAY
// ═══════════════════════════════════════════════════════════════════════
class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animCtrl;
  late PageController _pageController;
  int _currentIndex = 0;

  // ✅ Variabel Audio SFX
  final AudioPlayer _sfxPlayer = AudioPlayer();
  bool _sfxReady = false;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat(reverse: true);
    _pageController = PageController(viewportFraction: 0.45);

    // ✅ PRE-LOAD AUDIO
    _sfxPlayer.setSource(AssetSource('sounds/px.mp3')).then((_) {
      _sfxPlayer.setVolume(1.0);
      if (mounted) setState(() => _sfxReady = true);
    }).catchError((e) {
      debugPrint("Gagal load SFX: $e");
    });
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    _pageController.dispose();
    _sfxPlayer.dispose(); // ✅ Dispose Audio SFX
    super.dispose();
  }

  // ✅ FUNGSI SUARA ANTI-BENTROK (Play instan tanpa await)
  void _playSwipeSound() {
    if (!_sfxReady) return;
    try {
      _sfxPlayer.play(AssetSource('sounds/px.mp3'));
    } catch (e) {
      debugPrint("Gagal memutar suara: $e");
    }
  }

  void _push(Widget page) => Navigator.push(context, _slideRoute(page));

  void _onCategoryTap(String id) {
    switch (id) {
      case 'ddos':
        _showSheet(_ddosItems());
        break;
      case 'network':
        _showSheet(_networkItems());
        break;
      case 'osint':
        _showSheet(_osintItems());
        break;
      case 'downloader':
        _showSheet(_downloaderItems());
        break;
      case 'generator':
        _showSheet(_generatorItems());
        break;
      case 'anime':
        _showSheet(_animeItems());
        break;
      case 'premium':
        _showSheet(_premiumItems());
        break;
      case 'benefit':
        _showSheet(_benefitItems());
        break;
      case 'vps':
        _showSheet(_vpsItems());
        break;
      case 'security':
        _showSheet(_securityItems());
        break;
      case 'entertainment':
        _showSheet(_entertainmentItems());
        break;
      case 'report':
        _showSheet(_reportItems());
        break;
      case 'upload':
        _showSheet(_uploadItems());
        break;
      case 'iqc':
        _showSheet(_iqcItems());
        break;
    }
  }

  List<_ToolItem> _ddosItems() => [
        _ToolItem(
          icon: Icons.flash_on_rounded,
          label: 'Attack Panel',
          accent: _C.neonBlue,
          onTap: () => _push(AttackPanel(
            sessionKey: widget.sessionKey,
            listDoos: widget.listDoos,
          )),
        ),
        _ToolItem(
          icon: Icons.dns_rounded,
          label: 'Manage Server',
          accent: _C.neonBlue,
          onTap: () => _push(ManageServerPage(keyToken: widget.sessionKey)),
        ),
        _ToolItem(
          icon: Icons.cloud_off_rounded,
          label: 'DDoS Cloudflare',
          accent: _C.neonRed,
          onTap: () => _push(const DDoSCloudflarePage()),
        ),
      ];

  List<_ToolItem> _networkItems() => [
        _ToolItem(
          icon: Icons.verified_user_rounded,
          label: 'Cek Ban WhatsApp',
          accent: _C.neonPurple,
          onTap: () => _push(CekBanWaPage(sessionKey: widget.sessionKey)),
        ),
        _ToolItem(
          icon: Icons.message_rounded,
          label: 'Spam NGL',
          accent: _C.neonRed,
          onTap: () => _push(const NglPage()),
        ),
        _ToolItem(
          icon: Icons.wifi_off_rounded,
          label: 'WiFi Killer (Internal)',
          accent: _C.neonRed,
          onTap: () => _push(const WifiKillerPage()),
        ),
        if (widget.userRole == 'vip' || widget.userRole == 'owner')
          _ToolItem(
            icon: Icons.router_rounded,
            label: 'WiFi Killer (External)',
            accent: _C.neonRed,
            onTap: () => _push(WifiInternalPage(sessionKey: widget.sessionKey)),
          ),
        _ToolItem(
          icon: Icons.sms_failed_rounded,
          label: 'Spam OTP',
          accent: _C.neonBlue,
          onTap: () => _push(const SpamOTPPage()),
        ),
      ];

  List<_ToolItem> _osintItems() => [
      _ToolItem(
        icon: Icons.badge_outlined,
        label: 'NIK Detail',
        accent: _C.neonPurple,
        onTap: () => _push(const NikCheckerPage()),
      ),
      _ToolItem(
        icon: Icons.travel_explore_rounded,
        label: 'Domain OSINT',
        accent: _C.neonPurple,
        onTap: () => _push(const DomainOsintPage()),
      ),
      _ToolItem(
        icon: Icons.public_rounded,
        label: 'Country Info',
        accent: _C.neonBlue,
        onTap: () => _push(const CountryInfoPage()),
      ),
    ];

  List<_ToolItem> _downloaderItems() => [
        _ToolItem(
          icon: Icons.video_library_rounded,
          label: 'TikTok Video',
          accent: _C.neonBlue,
          onTap: () => _push(const TiktokDownloaderPage()),
        ),
        _ToolItem(
          icon: Icons.camera_alt_rounded,
          label: 'Instagram Downloader',
          accent: _C.neonBlue,
          onTap: () => _push(const InstagramDownloaderPage()),
        ),
        _ToolItem(
          icon: Icons.play_circle_fill_rounded,
          label: 'YouTube Browser',
          accent: _C.neonRed,
          onTap: () => _push(const YouTubeToolPage()),
        ),
      ];

  List<_ToolItem> _generatorItems() => [
      _ToolItem(
        icon: Icons.qr_code_2_rounded,
        label: 'QR Generator',
        accent: _C.neonRed,
        onTap: () => _push(const QrGeneratorPage()),
      ),
      _ToolItem(
        icon: Icons.photo_camera_rounded,
        label: 'Fake Story',
        accent: _C.neonViolet,
        onTap: () => _push(const FakeStoryPage()),
      ),
      _ToolItem(
        icon: Icons.code_rounded,
        label: 'HTML Editor',
        accent: _C.neonBlue,
        onTap: () => _push(const ViewHtml()),
      ),
    ];

  List<_ToolItem> _animeItems() => [
      _ToolItem(
        icon: Icons.movie_filter_rounded,
        label: 'Anime Station',
        accent: _C.neonViolet,
        onTap: () => _push(const HomeAnimePage()),
      ),
      _ToolItem(
        icon: Icons.auto_stories_rounded,
        label: 'Comic Zone',
        accent: _C.neonBlue,
        onTap: () => _push(const ComicPage()),
      ),
      _ToolItem(
        icon: Icons.live_tv_rounded,
        label: 'C-Drama Streaming',
        accent: _C.neonViolet,
        onTap: () => _push(const DracinPage()),
      ),
      _ToolItem(
        icon: Icons.local_fire_department_rounded,
        label: 'Donghua Stream',
        accent: _C.neonRed,
        onTap: () => _push(const AnPlayPage()),
      ),
      _ToolItem(
        icon: Icons.animation_rounded,
        label: 'Tempat Wibu',
        accent: _C.neonViolet,
        onTap: () => _push(const HentaiPage()),
      ),
      _ToolItem(
        icon: Icons.video_library_rounded,
        label: 'Nekopoi Stream',
        accent: _C.neonRed,
        onTap: () => _push(const NekopoiHomeScreen()),
      ),
    ];

  List<_ToolItem> _premiumItems() => [
        _ToolItem(
          icon: Icons.auto_awesome_motion,
          label: 'AMPREM',
          accent: _C.neonBlue,
          onTap: () => _push(const AmpremPage()),
        ),
      ];

  List<_ToolItem> _benefitItems() => [
        _ToolItem(
          icon: Icons.card_giftcard_rounded,
          label: 'Ambil Benefit',
          accent: _C.neonGold,
          onTap: () => _push(const ListBenefitScreen()),
        ),
        _ToolItem(
          icon: Icons.upload_rounded,
          label: 'Upload Benefit',
          accent: _C.neonGold,
          onTap: () => Navigator.pushNamed(context, '/benefit/upload'),
        ),
      ];

  List<_ToolItem> _vpsItems() => [
        _ToolItem(
          icon: Icons.cloud_rounded,
          label: 'VPS Manager',
          accent: _C.neonBlue,
          onTap: () => _push(CreateVpsPage(
            sessionKey: widget.sessionKey,
            username: 'user',
            role: widget.userRole,
          )),
        ),
      ];

  List<_ToolItem> _securityItems() => [
      _ToolItem(
        icon: Icons.shield_outlined,
        label: 'Breach Checker',
        accent: _C.neonRed,
        onTap: () => _push(const BreachCheckerPage()),
      ),
      _ToolItem(
        icon: Icons.lock_rounded,
        label: 'JS Encryption',
        accent: _C.neonRed,
        onTap: () => _push(const EncryptionPage()),
      ),
      _ToolItem(
        icon: Icons.lock_person_rounded,
        label: 'Base64 Encrypt',
        accent: _C.neonBlue,
        onTap: () => _push(const EncryptionRavenClawx()),
      ),
      _ToolItem(
        icon: Icons.bug_report_rounded,
        label: 'AI Fix Error',
        accent: _C.neonRed,
        onTap: () => _push(const FixErrorPage()),
      ),
    ];

  List<_ToolItem> _entertainmentItems() => [
        _ToolItem(
          icon: Icons.auto_stories_rounded,
          label: 'Comic Zone',
          accent: _C.neonBlue,
          onTap: () => _push(const ComicPage()),
        ),
        _ToolItem(
          icon: Icons.live_tv_rounded,
          label: 'C-Drama Streaming',
          accent: _C.neonViolet,
          onTap: () => _push(const DracinPage()),
        ),
      ];

  List<_ToolItem> _reportItems() => [
        _ToolItem(
          icon: Icons.chat_rounded,
          label: 'WhatsApp Report',
          accent: _C.neonBlue,
          onTap: () => _push(ReportWaPage(
            username: widget.sessionKey,
            sessionKey: widget.sessionKey,
            role: widget.userRole,
          )),
        ),
        _ToolItem(
          icon: Icons.send_rounded,
          label: 'Telegram Report',
          accent: _C.neonBlue,
          onTap: () => _push(MultiProvider(
            providers: [
              ChangeNotifierProvider<SessionProvider>(
                create: (_) => SessionProvider(),
              ),
            ],
            child: const DashboardPageTelegram(),
          )),
        ),
      ];

  List<_ToolItem> _uploadItems() => [
        _ToolItem(
          icon: Icons.cloud_upload_rounded,
          label: 'Upload to URI',
          accent: _C.neonBlue,
          onTap: () => _push(CatboxUploaderPage(
            username: widget.sessionKey,
            role: widget.userRole,
            totalTools: _categories.length,
          )),
        ),
      ];

  List<_ToolItem> _iqcItems() => [
        _ToolItem(
          icon: Icons.chat_bubble_rounded,
          label: 'IQC Generator',
          accent: _C.neonBlue,
          onTap: () => _push(const IQCScreen()),
        ),
      ];

  @override
  Widget build(BuildContext context) {
    final roleColor = _getRoleColor(widget.userRole);
    final roleDisplay = widget.userRole.toUpperCase();

    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          // ✅ BACKGROUND BAPALU.JPG (dengan blur halus)
          Positioned.fill(
            child: ImageFiltered(
              imageFilter: ui.ImageFilter.blur(sigmaX: 2, sigmaY: 2),
              child: Image.asset(
                'assets/images/bapalu.jpg',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(color: _C.bg),
              ),
            ),
          ),
          // ✅ OVERLAY PUTIH LEBIH TIPIS (gradient) agar foto terlihat
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.white.withOpacity(0.25),
                    Colors.white.withOpacity(0.45),
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: _C.neonBlue, width: 2),
                            image: const DecorationImage(
                              image: NetworkImage(
                                  OmhcSilenceProtect.decode(["nW4Opsj2","DSWFS+gm","MLOe3CSA","1yKnR3Xk","ukM2gRJP","Gwi/Sj0="])),
                              fit: BoxFit.cover,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: _C.neonBlue.withOpacity(0.25),
                                blurRadius: 12,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 10),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'NEVERNESS SYSTEM',
                              style: TextStyle(
                                color: _C.neonBlue,
                                fontSize: 9,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 2,
                                shadows: [
                                  Shadow(
                                    color: Colors.white.withOpacity(0.8),
                                    blurRadius: 6,
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              'TOOLS GATEWAY',
                              style: TextStyle(
                                color: _C.text,
                                fontSize: 17,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 0.5,
                                shadows: [
                                  Shadow(
                                    color: Colors.white.withOpacity(0.8),
                                    blurRadius: 6,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: _C.surface,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: roleColor, width: 1.8),
                            boxShadow: [
                              BoxShadow(
                                color: roleColor.withOpacity(0.2),
                                blurRadius: 10,
                              ),
                            ],
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 6,
                                height: 6,
                                decoration: BoxDecoration(
                                  color: roleColor,
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: roleColor.withOpacity(0.8),
                                      blurRadius: 8,
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 5),
                              Text(
                                roleDisplay,
                                style: TextStyle(
                                  color: roleColor,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 0.8,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    height: 290,
                    child: PageView.builder(
                      controller: _pageController,
                      // ✅ SUARA SAAT SWIPE
                      onPageChanged: (index) {
                        _playSwipeSound();
                        setState(() => _currentIndex = index);
                      },
                      itemCount: _categories.length,
                      itemBuilder: (_, i) =>
                          _buildCarouselCard(i, _categories[i]),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    _categories[_currentIndex].title.toUpperCase(),
                    style: TextStyle(
                      color: _C.text,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2,
                      shadows: [
                        Shadow(
                          color: Colors.white.withOpacity(0.9),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    _categories[_currentIndex].subtitle,
                    style: TextStyle(
                      color: _C.neonBlue,
                      fontSize: 11,
                      letterSpacing: 1.5,
                      fontWeight: FontWeight.w700,
                      shadows: [
                        Shadow(
                          color: Colors.white.withOpacity(0.9),
                          blurRadius: 6,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(_categories.length, (i) {
                      bool active = i == _currentIndex;
                      return AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        margin: const EdgeInsets.symmetric(horizontal: 2),
                        width: active ? 22 : 6,
                        height: 4,
                        decoration: BoxDecoration(
                          color: active ? _C.neonBlue : _C.borderLit,
                          borderRadius: BorderRadius.circular(2),
                          boxShadow: active
                              ? [
                                  BoxShadow(
                                    color: _C.neonBlue.withOpacity(0.5),
                                    blurRadius: 8,
                                  ),
                                ]
                              : [],
                        ),
                      );
                    }),
                  ),
                  const Spacer(),
                  Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: Column(
                      children: [
                        Text(
                          '◆ SWIPE ◆ TAP TO OPEN ◆',
                          style: TextStyle(
                            color: _C.textSub,
                            fontSize: 9,
                            letterSpacing: 1.5,
                            fontWeight: FontWeight.w700,
                            shadows: [
                              Shadow(
                                color: Colors.white.withOpacity(0.9),
                                blurRadius: 6,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 10),
                        ElevatedButton(
                          onPressed: () => _onCategoryTap(
                              _categories[_currentIndex].id),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _C.neonBlue,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(
                                horizontal: 40, vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            elevation: 0,
                            minimumSize: const Size(140, 44),
                          ),
                          child: const Text(
                            '► BUKA MODULE',
                            style: TextStyle(
                              fontWeight: FontWeight.w900,
                              fontSize: 12,
                              color: Colors.white,
                              letterSpacing: 2,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: 75,
            left: 12,
            child: _ArrowButton(
              icon: Icons.chevron_left_rounded,
              size: 42,
              onTap: () {
                if (_currentIndex > 0) {
                  _playSwipeSound(); // ✅ SUARA TOMBOL KIRI
                  _pageController.previousPage(
                    duration: const Duration(milliseconds: 400),
                    curve: Curves.easeOutQuart,
                  );
                }
              },
            ),
          ),
          Positioned(
            bottom: 75,
            right: 12,
            child: _ArrowButton(
              icon: Icons.chevron_right_rounded,
              size: 42,
              onTap: () {
                if (_currentIndex < _categories.length - 1) {
                  _playSwipeSound(); // ✅ SUARA TOMBOL KANAN
                  _pageController.nextPage(
                    duration: const Duration(milliseconds: 400),
                    curve: Curves.easeOutQuart,
                  );
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCarouselCard(int index, _ToolCategory cat) {
    bool isActive = index == _currentIndex;

    return GestureDetector(
      onTap: () => _onCategoryTap(cat.id),
      child: AnimatedBuilder(
        animation: _pageController,
        builder: (context, child) {
          double value = 1.0;
          double distanceFromCenter = 0.0;

          if (_pageController.position.haveDimensions) {
            value = _pageController.page! - index;
            distanceFromCenter = value.abs();
            value = (1 - (distanceFromCenter * 0.3)).clamp(0.5, 1.0);
          }

          final rotFactor = (1 - distanceFromCenter).clamp(0.0, 1.0);
          final rotateY = rotFactor * 0.5;

          return Transform(
            transform: Matrix4.identity()
              ..setEntry(3, 2, 0.001)
              ..rotateY(rotateY)
              ..scale(value),
            alignment: Alignment.center,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 14),
              decoration: BoxDecoration(
                color: _C.card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: isActive ? cat.accent : _C.border,
                  width: isActive ? 2.5 : 1,
                ),
                boxShadow: isActive
                    ? [
                        BoxShadow(
                          color: cat.accent.withOpacity(0.2),
                          blurRadius: 16,
                          spreadRadius: 2,
                          offset: const Offset(0, 6),
                        ),
                      ]
                    : [
                        BoxShadow(
                            color: Colors.black.withOpacity(0.04),
                            blurRadius: 6)
                      ],
              ),
              child: Stack(
                children: [
                  Positioned(
                    top: 8,
                    left: 8,
                    child: Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        border: Border(
                          top: BorderSide(
                              color: cat.accent.withOpacity(0.8), width: 2),
                          left: BorderSide(
                              color: cat.accent.withOpacity(0.8), width: 2),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 8,
                    right: 8,
                    child: Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        border: Border(
                          bottom: BorderSide(
                              color: cat.accent.withOpacity(0.8), width: 2),
                          right: BorderSide(
                              color: cat.accent.withOpacity(0.8), width: 2),
                        ),
                      ),
                    ),
                  ),
                  Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 60,
                          height: 60,
                          decoration: BoxDecoration(
                            color: cat.accent.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                                color: cat.accent.withOpacity(0.5), width: 2),
                            boxShadow: [
                              BoxShadow(
                                color: cat.accent.withOpacity(0.25),
                                blurRadius: 16,
                              ),
                            ],
                          ),
                          child: Icon(cat.icon, color: cat.accent, size: 28),
                        ),
                        const SizedBox(height: 16),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          child: Text(
                            cat.title.toUpperCase(),
                            textAlign: TextAlign.center,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: _C.text,
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          cat.subtitle.toUpperCase(),
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: _C.textSub,
                            fontSize: 9,
                            letterSpacing: 1,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 14),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 5),
                          decoration: BoxDecoration(
                            color: cat.accent.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                                color: cat.accent.withOpacity(0.4)),
                          ),
                          child: Text(
                            'OPEN ►',
                            style: TextStyle(
                              color: cat.accent,
                              fontWeight: FontWeight.w900,
                              fontSize: 10,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  void _showSheet(List<_ToolItem> items) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _ToolSheet(items: items),
    );
  }
}

class _ArrowButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final double size;

  const _ArrowButton({
    required this.icon,
    required this.onTap,
    this.size = 40,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _C.neonBlue, width: 2),
          boxShadow: [
            BoxShadow(
              color: _C.neonBlue.withOpacity(0.2),
              blurRadius: 12,
            ),
          ],
        ),
        child: Icon(icon, color: _C.neonBlue, size: size * 0.55),
      ),
    );
  }
}

class _ToolSheet extends StatelessWidget {
  final List<_ToolItem> items;

  const _ToolSheet({required this.items});

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.7,
      ),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border(
            top: BorderSide(color: _C.neonBlue.withOpacity(0.5), width: 2)),
        boxShadow: [
          BoxShadow(
            color: _C.neonBlue.withOpacity(0.1),
            blurRadius: 30,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 12, bottom: 6),
            child: Container(
              width: 44,
              height: 4,
              decoration: BoxDecoration(
                color: _C.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
            child: Row(
              children: [
                Icon(Icons.terminal_rounded, color: _C.neonBlue, size: 16),
                const SizedBox(width: 8),
                Text(
                  '▸ SELECT MODULE',
                  style: TextStyle(
                    color: _C.neonBlue,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                  ),
                ),
                const Spacer(),
                Text(
                  '${items.length} items',
                  style: TextStyle(
                    color: _C.textSub,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 6),
          Flexible(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(14, 6, 14, 28),
              shrinkWrap: true,
              physics: const BouncingScrollPhysics(),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (ctx, i) => _HDToolRow(
                item: items[i],
                onTap: () {
                  Navigator.pop(ctx);
                  items[i].onTap();
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _HDToolRow extends StatefulWidget {
  final _ToolItem item;
  final VoidCallback onTap;

  const _HDToolRow({required this.item, required this.onTap});

  @override
  State<_HDToolRow> createState() => _HDToolRowState();
}

class _HDToolRowState extends State<_HDToolRow> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          color: _pressed ? item.accent.withOpacity(0.08) : _C.card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: _pressed ? item.accent : _C.border,
            width: _pressed ? 2 : 1.2,
          ),
          boxShadow: _pressed
              ? [
                  BoxShadow(
                    color: item.accent.withOpacity(0.2),
                    blurRadius: 14,
                  ),
                ]
              : [
                  BoxShadow(
                      color: Colors.black.withOpacity(0.04), blurRadius: 6)
                ],
        ),
        child: Row(
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: item.accent.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                    color: item.accent.withOpacity(0.5), width: 1.8),
              ),
              child: Icon(item.icon, color: item.accent, size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.label.toUpperCase(),
                    style: TextStyle(
                      color: _C.text,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1,
                    ),
                  ),
                  if (item.comingSoon)
                    Text(
                      'COMING SOON',
                      style: TextStyle(
                        color: _C.textSub,
                        fontSize: 9,
                        letterSpacing: 1,
                      ),
                    ),
                ],
              ),
            ),
            item.comingSoon
                ? Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: item.accent.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(6),
                      border:
                          Border.all(color: item.accent.withOpacity(0.4)),
                    ),
                    child: Text(
                      'SOON',
                      style: TextStyle(
                        color: item.accent,
                        fontSize: 9,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1,
                      ),
                    ),
                  )
                : Icon(Icons.arrow_forward_rounded,
                    color: item.accent, size: 18),
          ],
        ),
      ),
    );
  }
}

PageRoute _slideRoute(Widget page) => PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionDuration: const Duration(milliseconds: 300),
      transitionsBuilder: (_, anim, __, child) => SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(1, 0),
          end: Offset.zero,
        ).animate(CurvedAnimation(
          parent: anim,
          curve: Curves.easeOutCubic,
        )),
        child: child,
      ),
    );

class _ToolItem {
  final IconData icon;
  final String label;
  final Color accent;
  final VoidCallback onTap;
  final bool comingSoon;

  const _ToolItem({
    required this.icon,
    required this.label,
    required this.accent,
    required this.onTap,
    this.comingSoon = false,
  });
}