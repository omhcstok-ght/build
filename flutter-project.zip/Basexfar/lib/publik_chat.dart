import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:gallery_saver_plus/gallery_saver.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:Fiona/Qaxer/.dart';

final baseUrl = Api.api;

// ═══════════════════════════════════════════════════════════════════
// 🎨 PREMIUM PALETTE & THEME
// ═══════════════════════════════════════════════════════════════════
class _C {
  static const bg          = Color(0xFFF5F9FF);
  static const surface     = Color(0xFFFFFFFF);
  static const card        = Color(0xFFFFFFFF);
  static const cardAlt     = Color(0xFFEFF6FF);
  static const border      = Color(0xFFD6E4F5);
  static const borderLit   = Color(0xFFB6CDE8);
  
  static const accent      = Color(0xFF2563EB);
  static const accentLight = Color(0xFF60A5FA);
  static const accentGlow  = Color(0x332563EB);
  
  static const green       = Color(0xFF10B981);
  static const greenGlow   = Color(0x3310B981);
  
  static const danger      = Color(0xFFEF4444);
  static const text        = Color(0xFF0F172A);
  static const textSub     = Color(0xFF475569);
  static const textDim     = Color(0xFF94A3B8);

  static const LinearGradient primaryGrad = LinearGradient(
    colors: [Color(0xFF60A5FA), Color(0xFF2563EB)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );
  
  static const LinearGradient cardGrad = LinearGradient(
    colors: [Color(0xFFFFFFFF), Color(0xFFF1F6FF)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );
}

// ==========================================================
// ⚙️ HELPER FUNCTIONS
// ==========================================================
String _getWsUrl() {
  String url = Api.api;
  if (url.startsWith('https')) return 'wss://${url.substring(8)}';
  if (url.startsWith('http')) return 'ws://${url.substring(7)}';
  return 'ws://nodecloudlegalraraapremium.xzcl.web.id:6018';
}

bool _isImageUrl(String? url) {
  if (url == null || url.isEmpty) return false;
  final lower = url.toLowerCase();
  return lower.endsWith('.jpg') || lower.endsWith('.jpeg') || lower.endsWith('.png') || lower.endsWith('.gif') || lower.endsWith('.webp');
}

bool _isVideoUrl(String? url) {
  if (url == null || url.isEmpty) return false;
  final lower = url.toLowerCase();
  return lower.endsWith('.mp4') || lower.endsWith('.mov') || lower.endsWith('.avi') || lower.endsWith('.webm');
}

String _formatTime(String? timestamp) {
  if (timestamp == null || timestamp.isEmpty) return '';
  try {
    final dt = DateTime.parse(timestamp).toLocal();
    return '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
  } catch (_) {
    return '';
  }
}

// ==========================================================
// 📦 MODELS
// ==========================================================
class ChatMessage {
  final String id, userId, username, displayName, role, timestamp, avatarUrl;
  final String? message, imageUrl, voiceUrl, videoUrl, profileImageUrl;
  final bool isDeleted;

  ChatMessage({
    required this.id,
    required this.userId,
    required this.username,
    required this.displayName,
    required this.role,
    required this.timestamp,
    required this.avatarUrl,
    required this.isDeleted,
    this.message,
    this.imageUrl,
    this.voiceUrl,
    this.videoUrl,
    this.profileImageUrl,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> json) {
    return ChatMessage(
      id: json['id']?.toString() ?? '',
      userId: json['userId']?.toString() ?? '',
      username: json['username']?.toString() ?? '',
      displayName: json['displayName']?.toString() ?? json['username']?.toString() ?? 'Unknown',
      role: json['role']?.toString() ?? 'Member',
      message: json['message']?.toString(),
      imageUrl: json['imageUrl']?.toString(),
      voiceUrl: json['voiceUrl']?.toString(),
      videoUrl: json['videoUrl']?.toString(),
      timestamp: json['timestamp']?.toString() ?? DateTime.now().toIso8601String(),
      avatarUrl: json['avatarUrl']?.toString() ?? 'assets/images/logo.jpg',
      profileImageUrl: json['profileImageUrl']?.toString(),
      isDeleted: json['isDeleted'] ?? false,
    );
  }
}

class UserModel {
  final String username;
  final String displayName;
  final String role;
  final String? profileImageUrl;

  UserModel({
    required this.username,
    required this.displayName,
    required this.role,
    this.profileImageUrl,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      username: json['username']?.toString() ?? '',
      displayName: json['displayName']?.toString() ?? json['username']?.toString() ?? 'Unknown',
      role: json['role']?.toString() ?? 'Member',
      profileImageUrl: json['profileImageUrl']?.toString(),
    );
  }
}

// ==========================================================
// 🏠 MAIN COMMUNITY PAGE
// ==========================================================
class CommunityPage extends StatefulWidget {
  final String username, role, sessionKey;
  const CommunityPage({
    super.key,
    required this.username,
    required this.role,
    required this.sessionKey,
  });

  @override
  State<CommunityPage> createState() => _CommunityPageState();
}

class _CommunityPageState extends State<CommunityPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        backgroundColor: _C.surface,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: _C.accent, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "Community Chat",
          style: TextStyle(
            color: _C.text,
            fontWeight: FontWeight.w900,
            fontSize: 20,
            letterSpacing: 0.5,
          ),
        ),
        bottom: TabBar(
          controller: _tabController,
          indicator: UnderlineTabIndicator(
            borderSide: const BorderSide(width: 4.0, color: _C.accent),
            insets: const EdgeInsets.symmetric(horizontal: 40.0),
          ),
          labelColor: _C.accent,
          unselectedLabelColor: _C.textSub,
          labelStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 1),
          unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
          tabs: const [
            Tab(text: "GLOBAL"),
            Tab(text: "PRIVATE"),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          GlobalChatTab(username: widget.username, role: widget.role, sessionKey: widget.sessionKey),
          PrivateChatTab(username: widget.username, sessionKey: widget.sessionKey),
        ],
      ),
    );
  }
}

// ==========================================================
// 🌍 GLOBAL CHAT TAB (PREMIUM)
// ==========================================================
class GlobalChatTab extends StatefulWidget {
  final String username, role, sessionKey;
  const GlobalChatTab({super.key, required this.username, required this.role, required this.sessionKey});

  @override
  State<GlobalChatTab> createState() => _GlobalChatTabState();
}

class _GlobalChatTabState extends State<GlobalChatTab> {
  final TextEditingController _msgCtrl = TextEditingController();
  final ScrollController _scrollCtrl = ScrollController();
  final ImagePicker _picker = ImagePicker();

  List<ChatMessage> _messages = [];
  bool _isLoading = true;
  bool _isSending = false;
  bool _hasError = false;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _loadMessages();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) => _loadMessages(isBackground: true));
  }

  @override
  void dispose() {
    _timer?.cancel();
    _scrollCtrl.dispose();
    _msgCtrl.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    if (_scrollCtrl.hasClients) {
      Future.delayed(const Duration(milliseconds: 100), () {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      });
    }
  }

  Future<void> _loadMessages({bool isBackground = false}) async {
    if (!isBackground) {
      setState(() {
        _isLoading = true;
        _hasError = false;
      });
    }

    try {
      // 🔥 FIX: Mengirim sessionKey lewat query parameter (sesuaikan jika backend pakai Header)
      final url = Uri.parse('$baseUrl/chat/messages?key=${widget.sessionKey}');
      final res = await http.get(url).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200 && mounted) {
        dynamic decoded = json.decode(res.body);
        List<dynamic> data = [];

        if (decoded is List) {
          data = decoded;
        } else if (decoded is Map) {
          if (decoded.containsKey('messages') && decoded['messages'] is List) {
            data = decoded['messages'];
          } else if (decoded.containsKey('data') && decoded['data'] is List) {
            data = decoded['data'];
          }
        }

        setState(() {
          _messages = data.map((m) => ChatMessage.fromJson(m as Map<String, dynamic>)).toList();
          _isLoading = false;
          _hasError = false;
        });
        _scrollToBottom();
      } else {
        if (mounted && !isBackground) setState(() => _hasError = true);
      }
    } catch (e) {
      debugPrint("ERROR LOAD MESSAGES: $e");
      if (mounted && !isBackground) setState(() => _hasError = true);
    } finally {
      if (mounted && !isBackground) setState(() => _isLoading = false);
    }
  }

  void _showError(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
        backgroundColor: _C.danger,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  Future<void> _sendText() async {
    final text = _msgCtrl.text.trim();
    if (text.isEmpty || _isSending) return;

    _msgCtrl.clear();
    setState(() => _isSending = true);

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/chat/send'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'userId': widget.username,
          'username': widget.username,
          'role': widget.role,
          'message': text,
          'timestamp': DateTime.now().toIso8601String(),
          'key': widget.sessionKey, // FIX: Sisipkan key
        }),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        _loadMessages(isBackground: true);
      } else {
        _showError("Gagal mengirim pesan (${response.statusCode})");
      }
    } catch (e) {
      _showError("Error jaringan: $e");
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  Future<void> _sendMedia(bool isVideo) async {
    try {
      final XFile? file = isVideo
          ? await _picker.pickVideo(source: ImageSource.gallery)
          : await _picker.pickImage(source: ImageSource.gallery);

      if (file == null) return;

      setState(() => _isSending = true);

      var request = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl/chat/upload-${isVideo ? 'video' : 'image'}'),
      );

      request.files.add(await http.MultipartFile.fromPath(
        isVideo ? 'video' : 'image',
        file.path,
      ));

      request.fields['userId'] = widget.username;
      request.fields['username'] = widget.username;
      request.fields['role'] = widget.role;
      request.fields['key'] = widget.sessionKey; // FIX: Sisipkan key

      final response = await request.send().timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        _loadMessages(isBackground: true);
      } else {
        _showError("Gagal upload media (${response.statusCode})");
      }
    } catch (e) {
      _showError("Error upload: $e");
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  Future<void> _saveMedia(String url, bool isVideo) async {
    try {
      final res = await http.get(Uri.parse(url));
      if (res.statusCode == 200) {
        final dir = await getTemporaryDirectory();
        final file = File('${dir.path}/${DateTime.now().millisecondsSinceEpoch}.${isVideo ? 'mp4' : 'jpg'}');
        await file.writeAsBytes(res.bodyBytes);
        if (isVideo) {
          await GallerySaver.saveVideo(file.path);
        } else {
          await GallerySaver.saveImage(file.path);
        }
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('${isVideo ? 'Video' : 'Foto'} berhasil disimpan', style: const TextStyle(fontWeight: FontWeight.bold)),
              backgroundColor: _C.green,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
          );
        }
      }
    } catch (_) {
      if (mounted) _showError('Gagal menyimpan media');
    }
  }

  Widget _buildErrorState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.danger.withOpacity(0.1),
              boxShadow: [BoxShadow(color: _C.danger.withOpacity(0.2), blurRadius: 20)],
            ),
            child: const Icon(Icons.cloud_off_rounded, color: _C.danger, size: 60),
          ),
          const SizedBox(height: 24),
          const Text(
            "Gagal memuat pesan",
            style: TextStyle(color: _C.text, fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            "Periksa koneksi internet atau sesi Anda",
            style: TextStyle(color: _C.textSub, fontSize: 13),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: _C.accent,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              elevation: 4,
              shadowColor: _C.accentGlow,
            ),
            onPressed: () => _loadMessages(),
            icon: const Icon(Icons.refresh),
            label: const Text("Coba Lagi", style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.accent.withOpacity(0.1),
              boxShadow: [BoxShadow(color: _C.accentGlow, blurRadius: 20)],
            ),
            child: Icon(Icons.forum_rounded, color: _C.accent.withOpacity(0.8), size: 60),
          ),
          const SizedBox(height: 24),
          const Text(
            "Belum ada pesan",
            style: TextStyle(color: _C.text, fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            "Jadilah yang pertama memulai percakapan!",
            style: TextStyle(color: _C.textSub, fontSize: 13),
          ),
        ],
      ),
    );
  }

  Widget _buildRoleBadge(String role) {
    Color c = role.toLowerCase() == 'developer' || role.toLowerCase() == 'owner'
        ? const Color(0xFF8B5CF6) // Purple
        : role.toLowerCase() == 'admin'
            ? const Color(0xFFEF4444) // Red
            : const Color(0xFF0EA5E9); // Blue

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: c.withOpacity(0.12),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: c.withOpacity(0.5), width: 1),
        boxShadow: [BoxShadow(color: c.withOpacity(0.2), blurRadius: 4)],
      ),
      child: Text(
        role.toUpperCase(),
        style: TextStyle(color: c, fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: 0.5),
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessage msg) {
    final isMe = msg.userId == widget.username;
    bool hasImage = (msg.imageUrl != null && msg.imageUrl!.isNotEmpty) || _isImageUrl(msg.message);
    bool hasVideo = (msg.videoUrl != null && msg.videoUrl!.isNotEmpty) || _isVideoUrl(msg.message);
    String? mediaUrl = msg.imageUrl ?? msg.videoUrl ?? (hasImage || hasVideo ? msg.message : null);

    if (msg.isDeleted) {
      return Align(
        alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 16),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: _C.cardAlt,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _C.border),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.delete_outline, color: _C.textDim, size: 16),
              const SizedBox(width: 8),
              const Text(
                "Pesan ini dihapus",
                style: TextStyle(color: _C.textSub, fontStyle: FontStyle.italic, fontSize: 13),
              ),
            ],
          ),
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
      child: Row(
        mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isMe) ...[
            Container(
              width: 38,
              height: 38,
              margin: const EdgeInsets.only(right: 8, bottom: 4),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: _C.primaryGrad,
                border: Border.all(color: Colors.white, width: 2),
                boxShadow: [BoxShadow(color: _C.accentGlow, blurRadius: 8, offset: const Offset(0, 2))],
              ),
              child: ClipOval(
                child: msg.profileImageUrl != null && msg.profileImageUrl!.isNotEmpty
                    ? Image.network(
                        msg.profileImageUrl!,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => const Icon(Icons.person, color: Colors.white, size: 20),
                      )
                    : const Icon(Icons.person, color: Colors.white, size: 20),
              ),
            ),
          ],
          Flexible(
            child: Container(
              constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: isMe ? _C.accent : _C.card,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(20),
                  topRight: const Radius.circular(20),
                  bottomLeft: Radius.circular(isMe ? 20 : 4),
                  bottomRight: Radius.circular(isMe ? 4 : 20),
                ),
                border: isMe ? null : Border.all(color: _C.border),
                boxShadow: [
                  BoxShadow(
                    color: isMe ? _C.accentGlow : Colors.black.withOpacity(0.04),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (!isMe)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Flexible(
                            child: Text(
                              msg.displayName.isNotEmpty ? msg.displayName : msg.username,
                              style: const TextStyle(
                                color: _C.accent,
                                fontWeight: FontWeight.w900,
                                fontSize: 13,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          const SizedBox(width: 6),
                          _buildRoleBadge(msg.role),
                        ],
                      ),
                    ),
                  if (hasImage && mediaUrl != null) ...[
                    GestureDetector(
                      onTap: () => showDialog(
                        context: context,
                        builder: (_) => Dialog(
                          backgroundColor: Colors.transparent,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              InteractiveViewer(child: ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.network(mediaUrl, fit: BoxFit.contain))),
                              Positioned(
                                top: 40,
                                right: 20,
                                child: IconButton(
                                  icon: Container(
                                    padding: const EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                      color: Colors.black54,
                                      shape: BoxShape.circle,
                                      border: Border.all(color: Colors.white24),
                                    ),
                                    child: const Icon(Icons.download_rounded, color: Colors.white),
                                  ),
                                  onPressed: () => _saveMedia(mediaUrl, false),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.network(
                          mediaUrl,
                          width: 220,
                          height: 220,
                          fit: BoxFit.cover,
                          loadingBuilder: (_, child, p) => p == null
                              ? child
                              : Container(
                                  height: 220,
                                  width: 220,
                                  color: _C.cardAlt,
                                  child: const Center(child: CircularProgressIndicator(color: _C.accent)),
                                ),
                        ),
                      ),
                    ),
                  ] else if (hasVideo && mediaUrl != null) ...[
                    GestureDetector(
                      onTap: () => showDialog(
                        context: context,
                        builder: (_) => Dialog(
                          backgroundColor: Colors.transparent,
                          child: SizedBox(
                            width: MediaQuery.of(context).size.width * 0.9,
                            height: MediaQuery.of(context).size.height * 0.7,
                            child: VideoPlayerWidget(videoUrl: mediaUrl, onSave: () => _saveMedia(mediaUrl, true)),
                          ),
                        ),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Container(
                          width: 220,
                          height: 160,
                          color: Colors.black87,
                          child: const Center(
                            child: Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 50),
                          ),
                        ),
                      ),
                    ),
                  ] else if (msg.message != null && msg.message!.isNotEmpty) ...[
                    SelectableText(
                      msg.message!,
                      style: TextStyle(
                        color: isMe ? Colors.white : _C.text,
                        fontSize: 15,
                        height: 1.4,
                      ),
                    ),
                  ],
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          _formatTime(msg.timestamp),
                          style: TextStyle(
                            color: isMe ? Colors.white70 : _C.textDim,
                            fontSize: 10,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        if (isMe) ...[
                          const SizedBox(width: 4),
                          const Icon(Icons.done_all_rounded, color: Colors.white70, size: 14),
                        ]
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputBar() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: _C.border, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: _C.accentGlow,
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.image_rounded, color: _C.accent, size: 24),
            onPressed: _isSending ? null : () => _sendMedia(false),
          ),
          IconButton(
            icon: const Icon(Icons.videocam_rounded, color: _C.accent, size: 24),
            onPressed: _isSending ? null : () => _sendMedia(true),
          ),
          Expanded(
            child: TextField(
              controller: _msgCtrl,
              style: const TextStyle(color: _C.text, fontSize: 15),
              decoration: const InputDecoration(
                hintText: 'Ketik pesan...',
                hintStyle: TextStyle(color: _C.textDim, fontSize: 14),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(horizontal: 8),
              ),
              onSubmitted: (_) => _sendText(),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: _C.primaryGrad,
              boxShadow: [BoxShadow(color: _C.accentGlow, blurRadius: 8, offset: const Offset(0, 4))],
            ),
            child: IconButton(
              icon: _isSending
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.send_rounded, color: Colors.white, size: 22),
              onPressed: _isSending ? null : _sendText,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: RefreshIndicator(
            color: _C.accent,
            backgroundColor: _C.card,
            onRefresh: () => _loadMessages(),
            child: _isLoading
                ? ListView.builder(
                    itemCount: 10,
                    itemBuilder: (_, index) {
                      bool isMe = index % 2 == 0;
                      return Align(
                        alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 16),
                          width: MediaQuery.of(context).size.width * 0.6,
                          height: 60,
                          decoration: BoxDecoration(
                            color: _C.cardAlt,
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                      );
                    },
                  )
                : _hasError
                    ? _buildErrorState()
                    : _messages.isEmpty
                        ? _buildEmptyState()
                        : ListView.builder(
                            controller: _scrollCtrl,
                            padding: const EdgeInsets.only(bottom: 20, top: 10),
                            itemCount: _messages.length,
                            itemBuilder: (_, i) => _buildMessageBubble(_messages[i]),
                          ),
          ),
        ),
        _buildInputBar(),
      ],
    );
  }
}

// ==========================================================
// 🔒 PRIVATE CHAT TAB (PREMIUM)
// ==========================================================
class PrivateChatTab extends StatefulWidget {
  final String username, sessionKey;
  const PrivateChatTab({super.key, required this.username, required this.sessionKey});

  @override
  State<PrivateChatTab> createState() => _PrivateChatTabState();
}

class _PrivateChatTabState extends State<PrivateChatTab> {
  List<UserModel> _users = [];
  List<UserModel> _filtered = [];
  bool _isLoading = true;
  final TextEditingController _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _fetchUsers();
    _searchCtrl.addListener(() {
      setState(() {
        _filtered = _users
            .where((u) =>
                u.username.toLowerCase().contains(_searchCtrl.text.toLowerCase()) ||
                u.displayName.toLowerCase().contains(_searchCtrl.text.toLowerCase()))
            .toList();
      });
    });
  }

  Future<void> _fetchUsers() async {
    try {
      // FIX: Tambahkan sessionKey di URL jika backend memintanya
      final res = await http.get(Uri.parse('$baseUrl/api/chatUsers?key=${widget.sessionKey}')).timeout(const Duration(seconds: 10));
      final decoded = jsonDecode(res.body);

      if (decoded['success'] == true && mounted) {
        List<dynamic> usersJson = decoded['users'] ?? [];
        setState(() {
          _users = usersJson
              .map((u) => UserModel.fromJson(u as Map<String, dynamic>))
              .where((u) => u.username != widget.username)
              .toList();
          _filtered = _users;
          _isLoading = false;
        });
      } else {
        if (mounted) setState(() => _isLoading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator(color: _C.accent));
    }

    return Column(
      children: [
        Container(
          margin: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          decoration: BoxDecoration(
            color: _C.surface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.border, width: 1.5),
            boxShadow: [BoxShadow(color: _C.accentGlow, blurRadius: 12, offset: const Offset(0, 4))],
          ),
          child: TextField(
            controller: _searchCtrl,
            style: const TextStyle(color: _C.text),
            decoration: const InputDecoration(
              prefixIcon: Icon(Icons.search_rounded, color: _C.accent),
              hintText: 'Cari username...',
              hintStyle: TextStyle(color: _C.textDim),
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            ),
          ),
        ),
        Expanded(
          child: _filtered.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.person_off_rounded, size: 60, color: _C.textDim.withOpacity(0.5)),
                      const SizedBox(height: 16),
                      const Text(
                        "User tidak ditemukan",
                        style: TextStyle(color: _C.textSub, fontSize: 16),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  itemCount: _filtered.length,
                  itemBuilder: (_, i) {
                    final u = _filtered[i];
                    return Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      decoration: BoxDecoration(
                        color: _C.card,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: _C.border),
                        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 10, offset: const Offset(0, 4))],
                      ),
                      child: ListTile(
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        leading: Container(
                          width: 52,
                          height: 52,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: _C.primaryGrad,
                            boxShadow: [BoxShadow(color: _C.accentGlow, blurRadius: 10)],
                          ),
                          child: ClipOval(
                            child: u.profileImageUrl != null && u.profileImageUrl!.isNotEmpty
                                ? Image.network(
                                    u.profileImageUrl!,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => const Icon(Icons.person, color: Colors.white, size: 26),
                                  )
                                : const Icon(Icons.person, color: Colors.white, size: 26),
                          ),
                        ),
                        title: Text(
                          u.displayName,
                          style: const TextStyle(color: _C.text, fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                        subtitle: Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(
                            "@${u.username} • ${u.role.toUpperCase()}",
                            style: const TextStyle(color: _C.textSub, fontSize: 12, fontWeight: FontWeight.w600),
                          ),
                        ),
                        trailing: const Icon(Icons.chevron_right_rounded, color: _C.textDim),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => PrivateChatRoom(
                              myUsername: widget.username,
                              targetUsername: u.username,
                              targetDisplayName: u.displayName,
                              targetProfileUrl: u.profileImageUrl,
                              sessionKey: widget.sessionKey,
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}

// ==========================================================
// 💬 PRIVATE CHAT ROOM (PREMIUM)
// ==========================================================
class PrivateChatRoom extends StatefulWidget {
  final String myUsername, targetUsername, targetDisplayName, sessionKey;
  final String? targetProfileUrl;

  const PrivateChatRoom({
    super.key,
    required this.myUsername,
    required this.targetUsername,
    required this.targetDisplayName,
    required this.sessionKey,
    this.targetProfileUrl,
  });

  @override
  State<PrivateChatRoom> createState() => _PrivateChatRoomState();
}

class _PrivateChatRoomState extends State<PrivateChatRoom> {
  final TextEditingController _msgCtrl = TextEditingController();
  final ScrollController _scrollCtrl = ScrollController();
  final ImagePicker _picker = ImagePicker();
  late WebSocketChannel _channel;
  List<Map<String, dynamic>> _messages = [];
  bool _isConnected = false;
  bool _isSending = false;

  @override
  void initState() {
    super.initState();
    _connectWs();
  }

  void _connectWs() {
    try {
      _channel = WebSocketChannel.connect(Uri.parse(_getWsUrl()));
      _channel.sink.add(jsonEncode({'type': 'auth', 'key': widget.sessionKey}));
      _channel.sink.add(jsonEncode({'type': 'getMessages', 'with': widget.targetUsername}));

      _channel.stream.listen(
        (event) {
          final data = jsonDecode(event);
          if (data['type'] == 'messages') {
            setState(() {
              _messages = List<Map<String, dynamic>>.from(data['messages'] ?? []);
              _isConnected = true;
            });
            _scrollToBottom();
          } else if (data['type'] == 'chat') {
            final msg = data['message'] as Map<String, dynamic>;
            final isRelevant = (msg['from'] == widget.targetUsername && msg['to'] == widget.myUsername) ||
                (msg['from'] == widget.myUsername && msg['to'] == widget.targetUsername);
            if (isRelevant) {
              setState(() => _messages.add(msg));
              _scrollToBottom();
            }
          }
        },
        onError: (_) => setState(() => _isConnected = false),
        onDone: () => setState(() => _isConnected = false),
      );
    } catch (_) {
      setState(() => _isConnected = false);
    }
  }

  void _scrollToBottom() {
    if (_scrollCtrl.hasClients) {
      Future.delayed(const Duration(milliseconds: 100), () {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      });
    }
  }

  void _showError(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
        backgroundColor: _C.danger,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  Future<void> _sendMedia(bool isVideo) async {
    try {
      final XFile? file = isVideo
          ? await _picker.pickVideo(source: ImageSource.gallery)
          : await _picker.pickImage(source: ImageSource.gallery);

      if (file == null) return;
      setState(() => _isSending = true);

      var request = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl/background/upload-${isVideo ? 'video' : 'image'}'),
      );

      request.files.add(await http.MultipartFile.fromPath(
        isVideo ? 'video' : 'image',
        file.path,
      ));

      request.fields['userId'] = widget.myUsername;
      request.fields['username'] = widget.myUsername;
      request.fields['role'] = 'user';

      final response = await request.send().timeout(const Duration(seconds: 30));
      final responseData = await response.stream.toBytes();
      final jsonString = String.fromCharCodes(responseData);
      final json = jsonDecode(jsonString);

      if (json['success'] == true && _isConnected) {
        final String url = json['data']?['value']?.toString() ?? '';
        
        if (url.isNotEmpty) {
          _channel.sink.add(jsonEncode({
            'type': 'chat',
            'to': widget.targetUsername,
            'message': url,
            'mediaType': isVideo ? 'video' : 'image',
          }));
        } else {
          _showError("URL media tidak ditemukan dari server");
        }
      } else {
        _showError("Gagal upload media private");
      }
    } catch (e) {
      _showError("Error: $e");
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _sendText() {
    final text = _msgCtrl.text.trim();
    if (text.isEmpty || !_isConnected) return;

    _channel.sink.add(jsonEncode({
      'type': 'chat',
      'to': widget.targetUsername,
      'message': text,
      'mediaType': 'text',
    }));

    _msgCtrl.clear();
    _scrollToBottom();
  }

  @override
  void dispose() {
    _channel.sink.close();
    _msgCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  Widget _buildBubble(Map<String, dynamic> msg) {
    final isMe = msg['from'] == widget.myUsername;
    String content = msg['message']?.toString() ?? '';
    String mediaType = msg['mediaType']?.toString() ?? 'text';

    if (mediaType == 'text') {
      if (_isImageUrl(content)) mediaType = 'image';
      else if (_isVideoUrl(content)) mediaType = 'video';
    }

    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 16),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        decoration: BoxDecoration(
          color: isMe ? _C.accent : _C.card,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(20),
            topRight: const Radius.circular(20),
            bottomLeft: Radius.circular(isMe ? 20 : 4),
            bottomRight: Radius.circular(isMe ? 4 : 20),
          ),
          border: isMe ? null : Border.all(color: _C.border),
          boxShadow: [
            BoxShadow(
              color: isMe ? _C.accentGlow : Colors.black.withOpacity(0.04),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            if (mediaType == 'image') ...[
              GestureDetector(
                onTap: () => showDialog(
                  context: context,
                  builder: (_) => Dialog(
                    backgroundColor: Colors.transparent,
                    child: InteractiveViewer(child: ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.network(content, fit: BoxFit.contain))),
                  ),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.network(
                    content,
                    width: 200,
                    height: 200,
                    fit: BoxFit.cover,
                    loadingBuilder: (_, child, p) => p == null
                        ? child
                        : Container(
                            height: 200,
                            width: 200,
                            color: _C.cardAlt,
                            child: const Center(child: CircularProgressIndicator(color: _C.accent)),
                          ),
                  ),
                ),
              ),
            ] else if (mediaType == 'video') ...[
              GestureDetector(
                onTap: () => showDialog(
                  context: context,
                  builder: (_) => Dialog(
                    backgroundColor: Colors.transparent,
                    child: SizedBox(
                      width: MediaQuery.of(context).size.width * 0.9,
                      height: MediaQuery.of(context).size.height * 0.7,
                      child: VideoPlayerWidget(videoUrl: content, onSave: () {}),
                    ),
                  ),
                ),
                child: Container(
                  width: 200,
                  height: 150,
                  decoration: BoxDecoration(
                    color: Colors.black87,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Center(
                    child: Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 50),
                  ),
                ),
              ),
            ] else ...[
              Text(
                content,
                style: TextStyle(
                  color: isMe ? Colors.white : _C.text,
                  fontSize: 15,
                  height: 1.4,
                ),
              ),
            ],
            const SizedBox(height: 6),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  _formatTime(msg['time']?.toString()),
                  style: TextStyle(
                    color: isMe ? Colors.white70 : _C.textDim,
                    fontSize: 10,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                if (isMe) ...[
                  const SizedBox(width: 4),
                  const Icon(Icons.done_all_rounded, color: Colors.white70, size: 14),
                ]
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputBar() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: _C.border, width: 1.5),
        boxShadow: [
          BoxShadow(color: _C.accentGlow, blurRadius: 20, offset: const Offset(0, 8)),
        ],
      ),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.image_rounded, color: _C.accent, size: 24),
            onPressed: _isSending ? null : () => _sendMedia(false),
          ),
          IconButton(
            icon: const Icon(Icons.videocam_rounded, color: _C.accent, size: 24),
            onPressed: _isSending ? null : () => _sendMedia(true),
          ),
          Expanded(
            child: TextField(
              controller: _msgCtrl,
              style: const TextStyle(color: _C.text, fontSize: 15),
              decoration: const InputDecoration(
                hintText: 'Ketik pesan...',
                hintStyle: TextStyle(color: _C.textDim, fontSize: 14),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(horizontal: 8),
              ),
              onSubmitted: (_) => _sendText(),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: _C.primaryGrad,
              boxShadow: [BoxShadow(color: _C.accentGlow, blurRadius: 8, offset: const Offset(0, 4))],
            ),
            child: IconButton(
              icon: _isSending
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.send_rounded, color: Colors.white, size: 22),
              onPressed: _isSending ? null : _sendText,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        backgroundColor: _C.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: _C.text, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: _C.primaryGrad,
                boxShadow: [BoxShadow(color: _C.accentGlow, blurRadius: 10)],
              ),
              child: ClipOval(
                child: widget.targetProfileUrl != null && widget.targetProfileUrl!.isNotEmpty
                    ? Image.network(
                        widget.targetProfileUrl!,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => const Icon(Icons.person, color: Colors.white, size: 24),
                      )
                    : const Icon(Icons.person, color: Colors.white, size: 24),
              ),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.targetDisplayName,
                  style: const TextStyle(
                    color: _C.text,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _isConnected ? _C.green : _C.textDim,
                        boxShadow: _isConnected ? [BoxShadow(color: _C.greenGlow, blurRadius: 6)] : null,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      _isConnected ? 'Online' : 'Offline',
                      style: TextStyle(
                        color: _isConnected ? _C.green : _C.textSub,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: _messages.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.chat_bubble_outline_rounded, size: 60, color: _C.accent.withOpacity(0.3)),
                        const SizedBox(height: 16),
                        Text(
                          "Mulai chat dengan ${widget.targetDisplayName}",
                          style: const TextStyle(color: _C.textDim, fontSize: 14),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    controller: _scrollCtrl,
                    padding: const EdgeInsets.only(top: 16, bottom: 16),
                    itemCount: _messages.length,
                    itemBuilder: (_, i) => _buildBubble(_messages[i]),
                  ),
          ),
          _buildInputBar(),
        ],
      ),
    );
  }
}

// ==========================================================
// 📹 VIDEO PLAYER WIDGET (PREMIUM)
// ==========================================================
class VideoPlayerWidget extends StatefulWidget {
  final String videoUrl;
  final VoidCallback? onSave;

  const VideoPlayerWidget({
    super.key,
    required this.videoUrl,
    this.onSave,
  });

  @override
  State<VideoPlayerWidget> createState() => _VideoPlayerWidgetState();
}

class _VideoPlayerWidgetState extends State<VideoPlayerWidget> {
  late VideoPlayerController _ctrl;
  ChewieController? _chewie;
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _initVideo();
  }

  Future<void> _initVideo() async {
    try {
      _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.videoUrl));
      await _ctrl.initialize();
      _chewie = ChewieController(
        videoPlayerController: _ctrl,
        autoPlay: true,
        looping: false,
        aspectRatio: _ctrl.value.aspectRatio,
        materialProgressColors: ChewieProgressColors(
          playedColor: _C.accent,
          handleColor: _C.accentLight,
          bufferedColor: Colors.white.withOpacity(0.3),
          backgroundColor: Colors.white.withOpacity(0.1),
        ),
        placeholder: Container(
          color: Colors.black,
          child: const Center(child: CircularProgressIndicator(color: Colors.white)),
        ),
      );
      if (mounted) setState(() => _isLoading = false);
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = e.toString();
          _isLoading = false;
        });
      }
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _chewie?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Container(
        color: Colors.black,
        child: const Center(child: CircularProgressIndicator(color: Colors.white)),
      );
    }

    if (_error != null) {
      return Container(
        color: Colors.black,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline_rounded, color: _C.danger, size: 60),
              const SizedBox(height: 16),
              const Text(
                "Gagal memuat video",
                style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    _isLoading = true;
                    _error = null;
                  });
                  _initVideo();
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: _C.accent,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text("Coba Lagi"),
              ),
            ],
          ),
        ),
      );
    }

    return Stack(
      children: [
        if (_chewie != null) Chewie(controller: _chewie!),
        if (widget.onSave != null)
          Positioned(
            top: 16,
            right: 16,
            child: IconButton(
              icon: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white24),
                ),
                child: const Icon(Icons.download_rounded, color: Colors.white),
              ),
              onPressed: widget.onSave,
            ),
          ),
      ],
    );
  }
}