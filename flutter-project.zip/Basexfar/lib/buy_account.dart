import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:url_launcher/url_launcher.dart';

// ==================== LIGHT THEME COLORS ====================
const Color lightBg = Color(0xFFF5F9FF);
const Color lightSurface = Color(0xFFFFFFFF);
const Color lightCard = Color(0xFFFFFFFF);
const Color lightBorder = Color(0xFFD6E4F5);
const Color primaryBlue = Color(0xFF2563EB);
const Color accentBlue = Color(0xFF3B82F6);
const Color goldAccent = Color(0xFFF59E0B);
const Color textDark = Color(0xFF0F172A);
const Color textSub = Color(0xFF475569);
const Color textDim = Color(0xFF94A3B8);

class BuyAccountPage extends StatefulWidget {
  const BuyAccountPage({super.key});

  @override
  State<BuyAccountPage> createState() => _BuyAccountPageState();
}

class _BuyAccountPageState extends State<BuyAccountPage> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late List<Animation<double>> _fadeAnimations;
  late List<Animation<double>> _scaleAnimations;
  late List<Animation<Offset>> _slideAnimations;

  final List<Map<String, dynamic>> priceList = const [
    {
      "title": "Member Account",
      "icon": Icons.person,
      "color": Color(0xFF0EA5E9), // Cyan
      "tag": "BASIC ACCOUNT",
      "daily": "2K IDR / Perhari",
      "weekly": "5K IDR / Perminggu",
      "monthly": "10K IDR / Perbulan",
      "permanent": "15K IDR / Permanent",
      "featured": false,
    },
    {
      "title": "Role Reseller Account",
      "icon": Icons.people,
      "color": Color(0xFF3B82F6), // Blue
      "tag": "BUSINESS",
      "permanent": "20K IDR / Permanent",
      "featured": false,
    },
    {
      "title": "Role Admin Account",
      "icon": Icons.admin_panel_settings,
      "color": Color(0xFFF59E0B), // Amber
      "tag": "RECOMMENDED & BEST SELLER",
      "permanent": "30K IDR / Permanent",
      "featured": true,
    },
    {
      "title": "Role moderator Account",
      "icon": Icons.star,
      "color": Color(0xFFEF4444), // Red
      "tag": "VVIP & BUSSINESS ROLE",
      "permanent": "40K IDR / Permanent",
      "featured": false,
    },
    {
      "title": "Role owner Account",
      "icon": Icons.gavel,
      "color": Color(0xFF8B5CF6), // Purple
      "tag": "VVIP & THE BEST",
      "permanent": "55K IDR / Permanent",
      "featured": false,
    },
  ];

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );

    _fadeAnimations = List.generate(priceList.length, (index) {
      return Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(
          parent: _controller,
          curve: Interval(
            index * 0.12,
            0.3 + index * 0.12,
            curve: Curves.easeInOut,
          ),
        ),
      );
    });

    _scaleAnimations = List.generate(priceList.length, (index) {
      return Tween<double>(begin: 0.85, end: 1.0).animate(
        CurvedAnimation(
          parent: _controller,
          curve: Interval(
            index * 0.12,
            0.3 + index * 0.12,
            curve: Curves.easeOutBack,
          ),
        ),
      );
    });

    _slideAnimations = List.generate(priceList.length, (index) {
      return Tween<Offset>(
        begin: const Offset(0, 0.3),
        end: Offset.zero,
      ).animate(
        CurvedAnimation(
          parent: _controller,
          curve: Interval(
            index * 0.12,
            0.3 + index * 0.12,
            curve: Curves.easeOutCubic,
          ),
        ),
      );
    });

    _controller.forward();
  }

  Future<void> _openStore() async {
    final uri = Uri.parse("https://t.me/Orgggaja");

    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      await launchUrl(uri, mode: LaunchMode.platformDefault);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: lightBg,
      appBar: AppBar(
        backgroundColor: lightSurface,
        elevation: 0,
        leading: Container(
          margin: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: lightBg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: lightBorder),
          ),
          child: IconButton(
            icon: const Icon(Icons.arrow_back, color: textDark),
            onPressed: () => Navigator.pop(context),
          ),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: primaryBlue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: primaryBlue.withOpacity(0.3)),
              ),
              child: const Icon(
                Icons.shopping_cart,
                color: primaryBlue,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            const Text(
              "BUY ACCOUNT",
              style: TextStyle(
                fontFamily: 'Orbitron',
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: textDark,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [lightBg, Color(0xFFEAF2FF)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: priceList.length,
          itemBuilder: (context, index) {
            return AnimatedBuilder(
              animation: _controller,
              child: _buildAccountCard(priceList[index], index),
              builder: (context, child) {
                return Opacity(
                  opacity: _fadeAnimations[index].value,
                  child: Transform.scale(
                    scale: _scaleAnimations[index].value,
                    child: Transform.translate(
                      offset: _slideAnimations[index].value,
                      child: child,
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }

  Widget _buildAccountCard(Map<String, dynamic> item, int index) {
    final Color cardColor = item['color'] as Color;
    final bool isFeatured = item['featured'] as bool;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: lightCard,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: cardColor.withOpacity(isFeatured ? 0.6 : 0.3),
          width: isFeatured ? 2 : 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: cardColor.withOpacity(isFeatured ? 0.15 : 0.05),
            blurRadius: isFeatured ? 25 : 15,
            spreadRadius: isFeatured ? 4 : 2,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Stack(
          children: [
            // Background pattern
            Positioned(
              top: -20,
              right: -20,
              child: Icon(
                item['icon'] as IconData,
                color: cardColor.withOpacity(0.05),
                size: 120,
              ),
            ),

            // Featured Badge
            if (isFeatured)
              Positioned(
                top: 12,
                right: 12,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [goldAccent, goldAccent.withOpacity(0.7)],
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.star, color: Colors.white, size: 12),
                      SizedBox(width: 4),
                      Text(
                        'RECOMMENDED',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

            // Content
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: cardColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: cardColor.withOpacity(0.3),
                            width: 1,
                          ),
                        ),
                        child: Icon(
                          item['icon'] as IconData,
                          color: cardColor,
                          size: 24,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              item['title'] as String,
                              style: TextStyle(
                                color: textDark,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: cardColor.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                item['tag'] as String,
                                style: TextStyle(
                                  color: cardColor,
                                  fontSize: 11,
                                  fontFamily: 'ShareTechMono',
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),

                  // Harga
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: lightBg,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: lightBorder,
                        width: 1,
                      ),
                    ),
                    child: Column(
                      children: [
                        // Daily & Weekly (jika ada)
                        if (item.containsKey('daily') && item.containsKey('weekly'))
                          Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          const Icon(
                                            Icons.calendar_today,
                                            color: primaryBlue,
                                            size: 14,
                                          ),
                                          const SizedBox(width: 8),
                                          Text(
                                            "DAILY",
                                            style: TextStyle(
                                              color: textSub,
                                              fontSize: 11,
                                              fontFamily: 'ShareTechMono',
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        item['daily'] as String,
                                        style: const TextStyle(
                                          color: textDark,
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: 'Orbitron',
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  width: 1,
                                  height: 40,
                                  color: lightBorder,
                                ),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          const Icon(
                                            Icons.calendar_view_week,
                                            color: primaryBlue,
                                            size: 14,
                                          ),
                                          const SizedBox(width: 8),
                                          Text(
                                            "WEEKLY",
                                            style: TextStyle(
                                              color: textSub,
                                              fontSize: 11,
                                              fontFamily: 'ShareTechMono',
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        item['weekly'] as String,
                                        style: const TextStyle(
                                          color: textDark,
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: 'Orbitron',
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),

                        // Monthly & Permanent
                        Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      const Icon(
                                        Icons.calendar_month,
                                        color: primaryBlue,
                                        size: 14,
                                      ),
                                      const SizedBox(width: 8),
                                      Text(
                                        "MONTHLY",
                                        style: TextStyle(
                                          color: textSub,
                                          fontSize: 11,
                                          fontFamily: 'ShareTechMono',
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    item.containsKey('monthly') 
                                      ? item['monthly'] as String 
                                      : "Not available",
                                    style: const TextStyle(
                                      color: textDark,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Orbitron',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              width: 1,
                              height: 40,
                              color: lightBorder,
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.all_inclusive,
                                        color: cardColor,
                                        size: 14,
                                      ),
                                      const SizedBox(width: 8),
                                      Text(
                                        "PERMANENT",
                                        style: TextStyle(
                                          color: textSub,
                                          fontSize: 11,
                                          fontFamily: 'ShareTechMono',
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    item['permanent'] as String,
                                    style: TextStyle(
                                      color: cardColor,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Orbitron',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Tombol ke Store
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _openStore,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: cardColor,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        elevation: 0,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Icon(
                            Icons.storefront,
                            color: Colors.white,
                            size: 20,
                          ),
                          SizedBox(width: 8),
                          Text(
                            "Buy Now Via Store",
                            style: TextStyle(
                              fontFamily: 'Orbitron',
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // Info tambahan
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: lightBg,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: lightBorder),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          Icons.security_rounded,
                          color: textDim,
                          size: 14,
                        ),
                        const SizedBox(width: 6),
                        const Text(
                          '100% Trusted & Verified',
                          style: TextStyle(
                            color: textSub,
                            fontSize: 11,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                        const SizedBox(width: 12),
                        Container(
                          width: 3,
                          height: 3,
                          decoration: const BoxDecoration(
                            color: textDim,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 12),
                        const Icon(
                          Icons.verified_rounded,
                          color: Color(0xFF10B981),
                          size: 14,
                        ),
                        const SizedBox(width: 6),
                        const Text(
                          'Instant Delivery',
                          style: TextStyle(
                            color: textSub,
                            fontSize: 11,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}