import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:Fiona/Qaxer/.dart';

final baseUrl = Api.api;

// ═══════════════════════════════════════════════════════════════════
//  LIGHT PALETTE — Bersih, Terang, Kece
// ═══════════════════════════════════════════════════════════════════
class _C {
  static const bg        = Color(0xFFF5F9FF);
  static const surface   = Color(0xFFFFFFFF);
  static const card      = Color(0xFFFFFFFF);
  static const cardAlt   = Color(0xFFEFF6FF);
  static const cardHi    = Color(0xFFE0E7FF);

  static const border    = Color(0xFFD6E4F5);
  static const borderLit = Color(0xFFB6CDE8);
  static const glass     = Color(0x1A3B82F6);

  static const text      = Color(0xFF0F172A);
  static const textSub   = Color(0xFF475569);
  static const textDim   = Color(0xFF94A3B8);

  static const accent1   = Color(0xFF2563EB);
  static const accent2   = Color(0xFF3B82F6);
  static const accent3   = Color(0xFF1D4ED8);
  static const cyan      = Color(0xFF0EA5E9);
  static const emerald   = Color(0xFF10B981);
  static const amber     = Color(0xFFF59E0B);
  static const rose      = Color(0xFFEF4444);

  static const primary      = accent2;
  static const primaryLight = accent1;
  static const primaryMid   = accent3;
  static const primaryFrost = cyan;

  static const LinearGradient primaryGrad = LinearGradient(
    colors: [Color(0xFF60A5FA), Color(0xFF3B82F6), Color(0xFF2563EB)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    stops: [0.0, 0.5, 1.0],
  );

  static const LinearGradient luxuryGrad = LinearGradient(
    colors: [Color(0xFF3B82F6), Color(0xFF2563EB)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient cardGrad = LinearGradient(
    colors: [Color(0xFFFFFFFF), Color(0xFFF1F6FF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient glassGrad = LinearGradient(
    colors: [Color(0x1A3B82F6), Color(0x083B82F6)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient textGrad = LinearGradient(
    colors: [Color(0xFF0F172A), Color(0xFF2563EB)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient buttonGrad = LinearGradient(
    colors: [Color(0xFF3B82F6), Color(0xFF2563EB)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

// ═══════════════════════════════════════════════════════════════════════════
//  LOGIN PAGE
// ═══════════════════════════════════════════════════════════════════════════
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with TickerProviderStateMixin {
  final userCtrl = TextEditingController();
  final passCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  static const platform = MethodChannel('app_security');

  bool _isLoading   = false;
  bool _obscurePass = true;
  String? _androidId;

  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _logoCtrl;
  late AnimationController _btnCtrl;
  late AnimationController _shakeCtrl;
  late AnimationController _scanCtrl;

  late Animation<double> _fade;
  late Animation<Offset>  _slide;
  late Animation<double>  _logoGlow;
  late Animation<double>  _btnPulse;
  late Animation<double>  _shake;

  @override
  void initState() {
    super.initState();

    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 20))..repeat();

    _entranceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1000));
    _fade  = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _entranceCtrl, curve: Curves.easeOutCubic));

    _logoCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2400))
      ..repeat(reverse: true);
    _logoGlow = Tween<double>(begin: 0.3, end: 0.9)
        .animate(CurvedAnimation(parent: _logoCtrl, curve: Curves.easeInOut));

    _btnCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);
    _btnPulse = Tween<double>(begin: 1.0, end: 1.02)
        .animate(CurvedAnimation(parent: _btnCtrl, curve: Curves.easeInOut));

    _shakeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    _shake = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -10.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -10.0, end: 10.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 10.0, end: -7.0),  weight: 2),
      TweenSequenceItem(tween: Tween(begin: -7.0, end: 7.0),   weight: 2),
      TweenSequenceItem(tween: Tween(begin: 7.0, end: 0.0),    weight: 1),
    ]).animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.easeInOut));

    _scanCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 4))..repeat();

    _entranceCtrl.forward();
    _initLogin();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _logoCtrl.dispose();
    _btnCtrl.dispose();
    _shakeCtrl.dispose();
    _scanCtrl.dispose();
    userCtrl.dispose();
    passCtrl.dispose();
    super.dispose();
  }

  Future<void> _initLogin() async {
    try {
      final deviceInfo = await DeviceInfoPlugin().androidInfo;
      _androidId = deviceInfo.id;

      final packageInfo = await PackageInfo.fromPlatform();
      final appVersion = packageInfo.version;

      String appCertificate;
      try {
        appCertificate = await platform.invokeMethod<String>('getSignature') ?? '';
      } catch (_) {
        appCertificate = '';
      }

      if (appVersion.isEmpty || appCertificate.isEmpty) {
        if (!mounted) return;
        _showAlert(
          title: 'APK Tidak Valid',
          message: 'Informasi keamanan aplikasi tidak dapat diverifikasi.',
          type: _AlertType.error,
          showContact: true,
        );
        return;
      }

      final prefs = await SharedPreferences.getInstance();
      final savedUser = prefs.getString('username');
      final savedPass = prefs.getString('password');
      final savedKey = prefs.getString('key');

      if (savedUser == null || savedPass == null || savedKey == null) return;

      final uri = Uri.parse('$baseUrl/myInfo').replace(
        queryParameters: {
          'username': savedUser,
          'password': savedPass,
          'androidId': _androidId ?? '',
          'key': savedKey,
          'appVersion': appVersion,
          'appCertificate': appCertificate,
        },
      );

      final res = await http.get(uri);
      final data = jsonDecode(res.body);

      if (data['error'] == 'SECURITY_FAILED' ||
          data['error'] == 'SECURITY_REQUIRED') {
        if (!mounted) return;
        _showAlert(
          title: 'Akses Ditolak',
          message: data['message'] ?? 'APK tidak valid.',
          type: _AlertType.error,
          showContact: true,
        );
        return;
      }

      if (data['valid'] == true && mounted) {
        await _updateFCM(savedKey);
        Navigator.pushReplacementNamed(
          context,
          '/musik',
          arguments: {
            'username':     savedUser,
            'password':     savedPass,
            'role':         data['role'],
            'sessionKey':   data['key'],
            'expiredDate':  data['expiredDate'],
            'listBug':      _parseList(data['listBug']),
            'listBugGroup': _parseList(data['listBugGroup']),
            'listDoos':     _parseList(data['listDDoS']),
            'news':         _parseList(data['news']),
            'jjVideos':     _parseList(data['jjVideos']),
            'thanksTo':     _parseList(data['thanksTo']),
          },
        );
      }
    } catch (e) {
      if (!mounted) return;
      _showAlert(
        title: 'Koneksi Error',
        message: 'Gagal terhubung ke server. Periksa jaringan Anda.',
        type: _AlertType.error,
      );
    }
  }

  List<Map<String, dynamic>> _parseList(dynamic raw) =>
      (raw as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();

  Future<void> _updateFCM(String sessionKey) async {
    try {
      await FirebaseMessaging.instance.requestPermission();
      final token = await FirebaseMessaging.instance.getToken();
      if (token == null) return;
      await http.get(
        Uri.parse('$baseUrl/updateFCM?key=$sessionKey&token=${Uri.encodeComponent(token)}'),
      );
    } catch (_) {}
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;

    final username = userCtrl.text.trim();
    final password = passCtrl.text.trim();

    setState(() => _isLoading = true);

    try {
      String appVersion = "";
      String appCertificate = "";

      final info = await PackageInfo.fromPlatform();
      appVersion = info.version;

      try {
        appCertificate = await platform.invokeMethod<String>('getSignature') ?? '';
      } catch (_) {
        appCertificate = '';
      }

      if (appVersion.isEmpty || appCertificate.isEmpty) {
        _shakeCtrl.forward(from: 0);
        _showAlert(
          title: 'APK Tidak Valid',
          message: 'Informasi keamanan aplikasi tidak dapat diverifikasi.',
          type: _AlertType.error,
          showContact: true,
        );
        if (mounted) setState(() => _isLoading = false);
        return;
      }

      final res = await http.post(Uri.parse('$baseUrl/validate'), body: {
        'username': username,
        'password': password,
        'androidId': _androidId ?? 'unknown',
        'appVersion': appVersion,
        'appCertificate': appCertificate,
      });

      final data = jsonDecode(res.body);

      if (data['error'] == 'SECURITY_FAILED') {
        _shakeCtrl.forward(from: 0);
        _showAlert(
          title: 'Akses Ditolak',
          message: data['message'] ?? 'APK tidak valid.',
          type: _AlertType.error,
          showContact: true,
        );
        if (mounted) setState(() => _isLoading = false);
        return;
      }

      if (data['maintenance'] == true) {
        _shakeCtrl.forward(from: 0);
        _showAlert(
          title: 'Maintenance',
          message: data['message'] ?? 'Server sedang dalam pemeliharaan.',
          type: _AlertType.warning,
        );
      } else if (data['banned'] == true) {
        _shakeCtrl.forward(from: 0);
        _showAlert(
          title: 'Akun Dibanned',
          message: data['message'] ?? 'Akun Anda telah dibanned oleh Admin.',
          type: _AlertType.error,
        );
      } else if (data['expired'] == true) {
        _shakeCtrl.forward(from: 0);
        _showAlert(
          title: 'Akses Habis',
          message: 'Masa akses Anda telah berakhir. Silakan perpanjang.',
          type: _AlertType.warning,
          showContact: true,
        );
      } else if (data['valid'] != true) {
        _shakeCtrl.forward(from: 0);
        final msg = (data['message'] ?? '').toString().toLowerCase();
        if (msg.contains('perangkat') || msg.contains('device') ||
            msg.contains('another')) {
          _showAlert(
            title: 'Sesi Aktif',
            message: 'Akun ini sedang login di perangkat lain.',
            type: _AlertType.warning,
          );
        } else {
          _showAlert(
            title: 'Login Gagal',
            message: 'Username atau password salah.',
            type: _AlertType.error,
          );
        }
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString('username', username);
        prefs.setString('password', password);
        prefs.setString('key', data['key']);
        await _updateFCM(data['key']);

        if (mounted) {
          Navigator.pushReplacementNamed(
            context,
            '/musik',
            arguments: {
              'username':     username,
              'password':     password,
              'role':         data['role'],
              'sessionKey':   data['key'],
              'expiredDate':  data['expiredDate'],
              'listBug':      _parseList(data['listBug']),
              'listBugGroup': _parseList(data['listBugGroup']),
              'listDoos':     _parseList(data['listDDoS']),
              'news':         _parseList(data['news']),
              'jjVideos':     _parseList(data['jjVideos']),
              'thanksTo':     _parseList(data['thanksTo']),
            },
          );
        }
      }
    } catch (_) {
      _shakeCtrl.forward(from: 0);
      _showAlert(
        title: 'Koneksi Error',
        message: 'Gagal terhubung ke server. Periksa jaringan Anda.',
        type: _AlertType.error,
      );
    }

    if (mounted) setState(() => _isLoading = false);
  }

  void _showAlert({
    required String title,
    required String message,
    required _AlertType type,
    bool showContact = false,
  }) {
    final brightness = switch (type) {
      _AlertType.error   => 0.4,
      _AlertType.warning => 0.7,
      _AlertType.success => 1.0,
    };

    final iconBg = Color.lerp(_C.cardAlt, _C.accent1, brightness)!;
    final icon = switch (type) {
      _AlertType.error   => Icons.error_rounded,
      _AlertType.warning => Icons.warning_amber_rounded,
      _AlertType.success => Icons.check_circle_rounded,
    };

    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black.withOpacity(0.4),
      transitionDuration: const Duration(milliseconds: 350),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: _C.borderLit, width: 1.5),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 40,
                offset: const Offset(0, 15),
              ),
              BoxShadow(
                color: _C.accent2.withOpacity(brightness * 0.10),
                blurRadius: 40,
                spreadRadius: 2,
              ),
            ],
          ),
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 90, height: 90,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: _C.border.withOpacity(0.5), width: 1),
                  ),
                ),
                Container(
                  width: 64, height: 64,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [iconBg, _C.card],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    border: Border.all(
                      color: _C.accent2.withOpacity(brightness * 0.7),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _C.accent2.withOpacity(brightness * 0.2),
                        blurRadius: 25,
                      ),
                    ],
                  ),
                  child: Icon(
                    icon,
                    color: _C.text.withOpacity(0.7 + brightness * 0.3),
                    size: 30,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 22),
            Text(
              title,
              style: const TextStyle(
                color: _C.text,
                fontSize: 20,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.5,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: _C.textSub,
                fontSize: 13.5,
                height: 1.6,
              ),
            ),
            const SizedBox(height: 26),
            if (showContact) ...[
              _GradientBtn(
                label: 'Hubungi Admin',
                icon: Icons.telegram,
                fullWidth: true,
                onTap: () async {
                  Navigator.pop(ctx);
                  await launchUrl(Uri.parse('https://t.me/xxfanz'),
                      mode: LaunchMode.externalApplication);
                },
              ),
              const SizedBox(height: 10),
            ],
            _GhostBtn(
              label: showContact ? 'Tutup' : 'OK',
              fullWidth: true,
              onTap: () => Navigator.pop(ctx),
            ),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          Positioned.fill(
            child: _NeoBg(
              controller: _bgCtrl,
              scanCtrl: _scanCtrl,
            ),
          ),

          SafeArea(
            child: FadeTransition(
              opacity: _fade,
              child: SlideTransition(
                position: _slide,
                child: Center(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _buildLogo(),
                        const SizedBox(height: 36),
                        _buildHeading(),
                        const SizedBox(height: 32),
                        AnimatedBuilder(
                          animation: _shake,
                          builder: (_, child) => Transform.translate(
                            offset: Offset(_shake.value, 0),
                            child: child,
                          ),
                          child: _buildForm(),
                        ),
                        const SizedBox(height: 28),
                        _buildFooter(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),

          Positioned(
            top: 16, right: 20,
            child: _buildStatusIndicator(),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusIndicator() {
    return AnimatedBuilder(
      animation: _logoGlow,
      builder: (_, __) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: _C.card.withOpacity(0.9),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _C.accent2.withOpacity(0.4), width: 1),
          boxShadow: [
            BoxShadow(
              color: _C.accent2.withOpacity(0.1),
              blurRadius: 16,
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 7, height: 7,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.accent2,
                boxShadow: [
                  BoxShadow(
                    color: _C.accent2.withOpacity(0.6 + _logoGlow.value * 0.4),
                    blurRadius: 10 + (_logoGlow.value * 6),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            const Text(
              'DEEP SECURE',
              style: TextStyle(
                color: _C.textSub,
                fontSize: 9,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLogo() {
    return AnimatedBuilder(
      animation: _logoGlow,
      builder: (_, __) => SizedBox(
        width: 170,
        height: 170,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Container(
              width: 170, height: 170,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    _C.accent2.withOpacity(_logoGlow.value * 0.15),
                    Colors.transparent,
                  ],
                  stops: const [0.3, 1.0],
                ),
              ),
            ),

            Transform.rotate(
              angle: _bgCtrl.value * math.pi * 2,
              child: Container(
                width: 140, height: 140,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: SweepGradient(
                    colors: [
                      _C.accent1.withOpacity(_logoGlow.value * 0.6),
                      _C.accent3.withOpacity(_logoGlow.value * 0.3),
                      Colors.transparent,
                      _C.accent2.withOpacity(_logoGlow.value * 0.4),
                      _C.accent1.withOpacity(_logoGlow.value * 0.6),
                    ],
                    stops: const [0.0, 0.25, 0.5, 0.75, 1.0],
                  ),
                ),
              ),
            ),

            Container(
              width: 124, height: 124,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: _C.accent2.withOpacity(0.3),
                  width: 1,
                ),
              ),
            ),

            Container(
              width: 100, height: 100,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(28),
                gradient: _C.cardGrad,
                border: Border.all(
                  color: _C.accent2.withOpacity(_logoGlow.value * 0.6),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: _C.accent2.withOpacity(_logoGlow.value * 0.3),
                    blurRadius: 40,
                    spreadRadius: 4,
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 30,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(26),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.asset(
                      'assets/images/logo.png',
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => ShaderMask(
                        shaderCallback: (b) => _C.primaryGrad.createShader(b),
                        child: const Icon(
                          Icons.water_drop_rounded,
                          color: Colors.white,
                          size: 42,
                        ),
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.white.withOpacity(0.20),
                            Colors.transparent,
                            Colors.white.withOpacity(0.05),
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeading() {
    return Column(children: [
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: _C.card.withOpacity(0.8),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _C.borderLit, width: 1),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.water_drop_outlined,
              color: _C.accent2,
              size: 12,
            ),
            const SizedBox(width: 6),
            const Text(
              'X-FAR 𝑪𝑶𝑹𝑬 • V1.0.0',
              style: TextStyle(
                color: _C.textSub,
                fontSize: 10,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
              ),
            ),
          ],
        ),
      ),
      const SizedBox(height: 16),

      ShaderMask(
        shaderCallback: (b) => _C.textGrad.createShader(b),
        child: const Text(
          'Selamat Datang',
          style: TextStyle(
            fontSize: 36,
            fontWeight: FontWeight.w900,
            color: Colors.white,
            letterSpacing: -0.8,
            height: 1.1,
            shadows: [
              Shadow(color: Color(0xFF7DD3FC), blurRadius: 24),
            ],
          ),
        ),
      ),
      const SizedBox(height: 8),
      const Text(
        'Masukkan kredensial akun Anda',
        style: TextStyle(
          color: _C.textSub,
          fontSize: 13,
          fontWeight: FontWeight.w500,
          letterSpacing: 0.3,
        ),
      ),
    ]);
  }

  Widget _buildForm() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: _C.borderLit, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: _C.accent2.withOpacity(0.08),
            blurRadius: 55,
            offset: const Offset(0, 15),
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 40,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Form(
        key: _formKey,
        child: Column(children: [
          Row(children: [
            Container(
              width: 4, height: 22,
              decoration: BoxDecoration(
                gradient: _C.primaryGrad,
                borderRadius: BorderRadius.circular(2),
                boxShadow: [
                  BoxShadow(
                    color: _C.accent2.withOpacity(0.5),
                    blurRadius: 12,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            const Text(
              'Kredensial Akun',
              style: TextStyle(
                color: _C.text,
                fontSize: 14,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.5,
              ),
            ),
          ]),
          const SizedBox(height: 22),

          _NeoField(
            controller: userCtrl,
            label: 'Username',
            icon: Icons.person_outline_rounded,
            validator: (v) => (v == null || v.isEmpty) ? 'Username tidak boleh kosong' : null,
          ),
          const SizedBox(height: 14),
          _NeoField(
            controller: passCtrl,
            label: 'Password',
            icon: Icons.lock_outline_rounded,
            obscure: _obscurePass,
            onToggleObscure: () => setState(() => _obscurePass = !_obscurePass),
            validator: (v) => (v == null || v.isEmpty) ? 'Password tidak boleh kosong' : null,
          ),
          const SizedBox(height: 26),

          _NeoLoginButton(
            isLoading: _isLoading,
            pulseAnim: _btnPulse,
            onTap: _login,
          ),
        ]),
      ),
    );
  }

  Widget _buildFooter() {
    return Column(children: [
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Text(
          'Belum punya akses? ',
          style: TextStyle(
            color: _C.textSub,
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
        ),
        GestureDetector(
          onTap: () => launchUrl(Uri.parse('https://t.me/xxfanz'),
              mode: LaunchMode.externalApplication),
          child: ShaderMask(
            shaderCallback: (b) => _C.textGrad.createShader(b),
            child: const Text(
              'Beli Sekarang',
              style: TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.3,
              ),
            ),
          ),
        ),
      ]),
      const SizedBox(height: 22),
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(width: 30, height: 1, color: _C.borderLit),
          const SizedBox(width: 10),
          Text(
            '© 2026 X-FAR N.T.E',
            style: TextStyle(
              color: _C.textDim.withOpacity(0.7),
              fontSize: 10.5,
              letterSpacing: 0.8,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(width: 10),
          Container(width: 30, height: 1, color: _C.borderLit),
        ],
      ),
    ]);
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  NEO FIELD — TEKS INPUT HITAM GELAP BIAR KELIHATAN
// ═══════════════════════════════════════════════════════════════════════════
class _NeoField extends StatefulWidget {
  final TextEditingController controller;
  final String label;
  final IconData icon;
  final bool obscure;
  final VoidCallback? onToggleObscure;
  final String? Function(String?)? validator;

  const _NeoField({
    required this.controller,
    required this.label,
    required this.icon,
    this.obscure = false,
    this.onToggleObscure,
    this.validator,
  });

  @override
  State<_NeoField> createState() => _NeoFieldState();
}

class _NeoFieldState extends State<_NeoField> {
  bool _focused = false;
  final _focus = FocusNode();

  @override
  void initState() {
    super.initState();
    _focus.addListener(() => setState(() => _focused = _focus.hasFocus));
  }

  @override
  void dispose() {
    _focus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      decoration: BoxDecoration(
        color: _C.cardAlt,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _focused ? _C.accent2 : _C.borderLit,
          width: _focused ? 2 : 1.2,
        ),
        boxShadow: _focused
            ? [
                BoxShadow(
                  color: _C.accent2.withOpacity(0.15),
                  blurRadius: 28,
                  spreadRadius: 0,
                ),
              ]
            : [
                BoxShadow(
                  color: Colors.black.withOpacity(0.02),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
      ),
      child: TextFormField(
        controller: widget.controller,
        focusNode: _focus,
        obscureText: widget.obscure,
        validator: widget.validator,
        // 👇 TEKS INPUT JADI HITAM GELAP BIAR KELIHATAN 👇
        style: const TextStyle(
          color: Color(0xFF0F172A),
          fontSize: 14.5,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.3,
        ),
        cursorColor: const Color(0xFF3B82F6),
        cursorWidth: 2,
        decoration: InputDecoration(
          labelText: widget.label,
          labelStyle: const TextStyle(color: Color(0xFF475569), fontSize: 13.5),
          floatingLabelStyle: const TextStyle(
            color: Color(0xFF3B82F6),
            fontSize: 12,
            fontWeight: FontWeight.w700,
          ),
          prefixIcon: Icon(
            widget.icon,
            color: _focused ? const Color(0xFF3B82F6) : const Color(0xFF475569),
            size: 19,
          ),
          suffixIcon: widget.onToggleObscure != null
              ? IconButton(
                  icon: Icon(
                    widget.obscure
                        ? Icons.visibility_off_outlined
                        : Icons.visibility_outlined,
                    color: const Color(0xFF475569),
                    size: 19,
                  ),
                  onPressed: widget.onToggleObscure,
                )
              : null,
          errorStyle: const TextStyle(color: Color(0xFFEF4444), fontSize: 11),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  NEO LOGIN BUTTON
// ═══════════════════════════════════════════════════════════════════════════
class _NeoLoginButton extends StatefulWidget {
  final bool isLoading;
  final Animation<double> pulseAnim;
  final VoidCallback onTap;

  const _NeoLoginButton({
    required this.isLoading,
    required this.pulseAnim,
    required this.onTap,
  });

  @override
  State<_NeoLoginButton> createState() => _NeoLoginButtonState();
}

class _NeoLoginButtonState extends State<_NeoLoginButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        if (!widget.isLoading) widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedBuilder(
        animation: widget.pulseAnim,
        builder: (_, __) => Transform.scale(
          scale: widget.isLoading || _down ? 1.0 : widget.pulseAnim.value,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            height: 58,
            width: double.infinity,
            decoration: BoxDecoration(
              gradient: _C.buttonGrad,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: _C.accent2.withOpacity(0.6),
                width: 1,
              ),
              boxShadow: _down || widget.isLoading
                  ? []
                  : [
                      BoxShadow(
                        color: _C.accent2.withOpacity(widget.pulseAnim.value * 0.4),
                        blurRadius: 30,
                        offset: const Offset(0, 10),
                      ),
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 20,
                        offset: const Offset(0, 6),
                      ),
                    ],
            ),
            child: Center(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 220),
                child: widget.isLoading
                    ? const SizedBox(
                        key: ValueKey('loading'),
                        width: 22, height: 22,
                        child: CircularProgressIndicator(
                          strokeWidth: 2.5,
                          color: Colors.white,
                        ),
                      )
                    : const Row(
                        key: ValueKey('idle'),
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.login_rounded,
                              color: Colors.white, size: 20),
                          SizedBox(width: 10),
                          Text(
                            'MASUK',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 2.5,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  GRADIENT BUTTON
// ═══════════════════════════════════════════════════════════════════════════
class _GradientBtn extends StatefulWidget {
  final String label;
  final IconData? icon;
  final VoidCallback onTap;
  final bool fullWidth;
  const _GradientBtn({
    required this.label,
    required this.onTap,
    this.icon,
    this.fullWidth = false,
  });

  @override
  State<_GradientBtn> createState() => _GradientBtnState();
}

class _GradientBtnState extends State<_GradientBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 48,
          width: widget.fullWidth ? double.infinity : null,
          decoration: BoxDecoration(
            gradient: _C.buttonGrad,
            borderRadius: BorderRadius.circular(14),
            boxShadow: _down
                ? []
                : [
                    BoxShadow(
                      color: _C.accent2.withOpacity(0.3),
                      blurRadius: 20,
                      offset: const Offset(0, 6),
                    ),
                  ],
          ),
          child: Center(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (widget.icon != null) ...[
                  Icon(
                    widget.icon,
                    color: Colors.white,
                    size: 16,
                  ),
                  const SizedBox(width: 8),
                ],
                Text(
                  widget.label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 14,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _GhostBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final bool fullWidth;
  const _GhostBtn({
    required this.label,
    required this.onTap,
    this.fullWidth = false,
  });

  @override
  State<_GhostBtn> createState() => _GhostBtnState();
}

class _GhostBtnState extends State<_GhostBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        height: 48,
        width: widget.fullWidth ? double.infinity : null,
        decoration: BoxDecoration(
          color: _down ? _C.cardAlt : Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.borderLit, width: 1.2),
        ),
        child: Center(
          child: Text(
            widget.label,
            style: const TextStyle(
              color: _C.textSub,
              fontWeight: FontWeight.w700,
              fontSize: 14,
              letterSpacing: 0.5,
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  NEO BACKGROUND — Light Ocean
// ═══════════════════════════════════════════════════════════════════════════
class _NeoBg extends StatelessWidget {
  final AnimationController controller;
  final AnimationController scanCtrl;
  const _NeoBg({required this.controller, required this.scanCtrl});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([controller, scanCtrl]),
      builder: (_, __) => CustomPaint(
        painter: _NeoBgPainter(controller.value, scanCtrl.value),
      ),
    );
  }
}

class _NeoBgPainter extends CustomPainter {
  final double t;
  final double scan;
  _NeoBgPainter(this.t, this.scan);

  @override
  void paint(Canvas canvas, Size size) {
    // Base gradient terang
    final bgPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Color(0xFFF5F9FF),
          Color(0xFFEAF2FF),
          Color(0xFFF5F9FF),
        ],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), bgPaint);

    // Orbs dengan warna biru soft
    final orb1X = size.width * 0.2 + math.sin(t * math.pi * 2) * 30;
    final orb1Y = size.height * 0.2 + math.cos(t * math.pi * 2) * 30;
    canvas.drawCircle(
      Offset(orb1X, orb1Y),
      size.width * 0.7,
      Paint()
        ..shader = RadialGradient(colors: [
          _C.accent2.withOpacity(0.06 + math.sin(t * math.pi * 2) * 0.02),
          Colors.transparent,
        ]).createShader(Rect.fromCircle(
            center: Offset(orb1X, orb1Y), radius: size.width * 0.7)),
    );

    final orb2X = size.width * 0.8 + math.cos(t * math.pi * 2 + 1) * 40;
    final orb2Y = size.height * 0.75 + math.sin(t * math.pi * 2 + 1) * 40;
    canvas.drawCircle(
      Offset(orb2X, orb2Y),
      size.width * 0.6,
      Paint()
        ..shader = RadialGradient(colors: [
          _C.accent1.withOpacity(0.04 + math.cos(t * math.pi * 2) * 0.02),
          Colors.transparent,
        ]).createShader(Rect.fromCircle(
            center: Offset(orb2X, orb2Y), radius: size.width * 0.6)),
    );

    // Titik-titik halus
    final dotPaint = Paint()..color = _C.accent2.withOpacity(0.05);
    const spacing = 34.0;
    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), 0.8, dotPaint);
      }
    }

    // Efek scan line tipis
    final scanY = size.height * scan;
    final scanPaint = Paint()
      ..shader = LinearGradient(
        colors: [
          Colors.transparent,
          _C.accent2.withOpacity(0.06),
          Colors.transparent,
        ],
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
      ).createShader(Rect.fromLTWH(0, scanY - 1, size.width, 2));
    canvas.drawRect(Rect.fromLTWH(0, scanY - 1, size.width, 2), scanPaint);
  }

  @override
  bool shouldRepaint(_NeoBgPainter old) => old.t != t || old.scan != scan;
}

enum _AlertType { error, warning, success }