// hentai_page.dart — FIXED VERSION
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shimmer/shimmer.dart';
import 'package:url_launcher/url_launcher.dart' as ul;
import 'package:webview_flutter/webview_flutter.dart';

// ==================== MODELS ====================
class NekopoiAnimeModel {
  final String title;
  final String image;
  final String link;
  final String? upload;
  final String? duration;
  final List<String>? genres;

  NekopoiAnimeModel({
    required this.title,
    required this.image,
    required this.link,
    this.upload,
    this.duration,
    this.genres,
  });

  factory NekopoiAnimeModel.fromLatest(Map<String, dynamic> json) {
    return NekopoiAnimeModel(
      title: json['title'] ?? '',
      image: json['image'] ?? '',
      link: json['link'] ?? '',
      upload: json['upload'],
    );
  }

  factory NekopoiAnimeModel.fromRelease(Map<String, dynamic> json) {
    return NekopoiAnimeModel(
      title: json['title'] ?? '',
      image: json['img'] ?? '',
      link: json['url'] ?? '',
      duration: json['duration'],
      genres: (json['genre'] as List<dynamic>?)
          ?.map((e) => e.toString())
          .where((e) => e.isNotEmpty)
          .toList(),
    );
  }

  factory NekopoiAnimeModel.fromSearch(Map<String, dynamic> json) {
    return NekopoiAnimeModel(
      title: json['title'] ?? '',
      image: json['img'] ?? '',
      link: json['url'] ?? '',
      duration: json['duration'],
      genres: (json['genre'] as List<dynamic>?)
          ?.map((e) => e.toString())
          .where((e) => e.isNotEmpty)
          .toList(),
    );
  }
}

class NekopoiDetailModel {
  final String title;
  final String info;
  final String image;
  final String synopsis;
  final String genre;
  final String anime;
  final String producers;
  final String duration;
  final String size;
  final String stream;
  final List<NekopoiDownloadOption> downloads;

  NekopoiDetailModel({
    required this.title,
    required this.info,
    required this.image,
    required this.synopsis,
    required this.genre,
    required this.anime,
    required this.producers,
    required this.duration,
    required this.size,
    required this.stream,
    required this.downloads,
  });

  factory NekopoiDetailModel.fromJson(Map<String, dynamic> json) {
    return NekopoiDetailModel(
      title: json['title'] ?? '',
      info: json['info'] ?? '',
      image: json['img'] ?? '',
      synopsis: json['sinopsis'] ?? '',
      genre: json['genre'] ?? '',
      anime: json['anime'] ?? '',
      producers: json['producers'] ?? '',
      duration: json['duration'] ?? '',
      size: json['size'] ?? '',
      stream: json['stream'] ?? '',
      downloads: (json['download'] as List<dynamic>?)
              ?.map((e) => NekopoiDownloadOption.fromJson(e))
              .toList() ??
          [],
    );
  }
}

class NekopoiDownloadOption {
  final String type;
  final String title;
  final List<NekopoiDownloadLink> links;

  NekopoiDownloadOption({
    required this.type,
    required this.title,
    required this.links,
  });

  factory NekopoiDownloadOption.fromJson(Map<String, dynamic> json) {
    return NekopoiDownloadOption(
      type: json['type'] ?? '',
      title: json['title'] ?? '',
      links: (json['links'] as List<dynamic>?)
              ?.map((e) => NekopoiDownloadLink.fromJson(e))
              .toList() ??
          [],
    );
  }
}

class NekopoiDownloadLink {
  final String name;
  final String url;

  NekopoiDownloadLink({
    required this.name,
    required this.url,
  });

  factory NekopoiDownloadLink.fromJson(Map<String, dynamic> json) {
    return NekopoiDownloadLink(
      name: json['name'] ?? '',
      url: json['link'] ?? '',
    );
  }
}

// ==================== SERVICES ====================
class NekopoiApiService {
  static const String baseUrl = OmhcSilenceProtect.decode(["nW4Opsj2DSWUVf","NtMPyT1jGU1zbl","T2jk/Aw/gwwPC0","i8Vz/Z9YlpRQ=="]);

  static Future<List<NekopoiAnimeModel>> getLatestAnime() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/latest'));

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final results = jsonData['results'] as List<dynamic>;
        return results.map((e) => NekopoiAnimeModel.fromLatest(e)).toList();
      }
      throw Exception('Failed to load latest anime');
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  static Future<List<NekopoiAnimeModel>> getReleaseAnime(int page) async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/release/$page'));

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final data = jsonData['data'] as List<dynamic>;
        return data.map((e) => NekopoiAnimeModel.fromRelease(e)).toList();
      }
      throw Exception('Failed to load release anime');
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  static Future<List<NekopoiAnimeModel>> searchAnime(String query) async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/search/$query'));

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final data = jsonData['data'] as List<dynamic>;
        return data.map((e) => NekopoiAnimeModel.fromSearch(e)).toList();
      }
      throw Exception('Failed to search anime');
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  static Future<NekopoiDetailModel> getAnimeDetail(String url) async {
    try {
      final encodedUrl = Uri.encodeComponent(url);
      final response =
          await http.get(Uri.parse('$baseUrl/get?url=$encodedUrl'));

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        return NekopoiDetailModel.fromJson(jsonData['data']);
      }
      throw Exception('Failed to load anime detail');
    } catch (e) {
      throw Exception('Error: $e');
    }
  }
}

// ==================== URL LAUNCHER HELPER (FIXED) ====================
class NekopoiUrlHelper {
  static Future<void> launch(String url) async {
    final uri = Uri.parse(url);
    if (await ul.canLaunchUrl(uri)) {
      await ul.launchUrl(uri, mode: ul.LaunchMode.externalApplication);
    } else {
      throw Exception('Could not launch $url');
    }
  }
}

// ==================== WIDGETS ====================
class NekopoiVideoCard extends StatelessWidget {
  final NekopoiAnimeModel anime;
  final bool isLatest;

  const NekopoiVideoCard({
    super.key,
    required this.anime,
    this.isLatest = true,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => NekopoiDetailScreen(url: anime.link),
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF0A1118),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 3,
              child: Stack(
                children: [
                  ClipRRect(
                    borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(12)),
                    child: Image.network(
                      anime.image,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: const Color(0xFF102A43),
                        child: const Center(
                          child: Icon(
                            Icons.image_not_supported,
                            color: Colors.white54,
                          ),
                        ),
                      ),
                    ),
                  ),
                  if (anime.duration != null && anime.duration!.isNotEmpty)
                    Positioned(
                      bottom: 8,
                      right: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.7),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          anime.duration!,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                          ),
                        ),
                      ),
                    ),
                  Positioned.fill(
                    child: Center(
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.5),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.play_arrow,
                          color: Colors.white,
                          size: 30,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 2,
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      anime.title,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    if (isLatest && anime.upload != null)
                      Text(
                        anime.upload!,
                        style: const TextStyle(
                          color: Color(0xFF78909C),
                          fontSize: 10,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    if (!isLatest &&
                        anime.genres != null &&
                        anime.genres!.isNotEmpty)
                      Expanded(
                        child: Wrap(
                          spacing: 4,
                          runSpacing: 2,
                          children: anime.genres!.take(2).map((genre) {
                            return Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 4, vertical: 1),
                              decoration: BoxDecoration(
                                color: Colors.deepPurple.shade800,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                genre,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 8,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class NekopoiLoadingShimmer extends StatelessWidget {
  final int itemCount;
  final double childAspectRatio;

  const NekopoiLoadingShimmer({
    super.key,
    this.itemCount = 6,
    this.childAspectRatio = 0.7,
  });

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.all(12),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: childAspectRatio,
      ),
      itemCount: itemCount,
      itemBuilder: (_, __) => Shimmer.fromColors(
        baseColor: const Color(0xFF102A43),
        highlightColor: const Color(0xFF102A43),
        child: Container(
          decoration: BoxDecoration(
            color: const Color(0xFF0A1118),
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }
}

class NekopoiErrorWidget extends StatelessWidget {
  final VoidCallback onRetry;

  const NekopoiErrorWidget({super.key, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.error_outline,
            color: Colors.grey.shade600,
            size: 64,
          ),
          const SizedBox(height: 16),
          const Text(
            "Gagal memuat data",
            style: TextStyle(
              color: Color(0xFF78909C),
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: onRetry,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.deepPurple,
              padding:
                  const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
            child: const Text(
              "Coba Lagi",
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}

// ==================== SCREENS ====================
class NekopoiHomeScreen extends StatefulWidget {
  const NekopoiHomeScreen({super.key});

  @override
  State<NekopoiHomeScreen> createState() => _NekopoiHomeScreenState();
}

class _NekopoiHomeScreenState extends State<NekopoiHomeScreen> {
  List<NekopoiAnimeModel> latestAnimeList = [];
  List<NekopoiAnimeModel> releaseAnimeList = [];
  List<NekopoiAnimeModel> searchResults = [];
  bool isLoadingLatest = true;
  bool isLoadingRelease = true;
  bool isSearching = false;
  bool isSearchLoading = false;
  bool isLoadingMore = false;
  bool hasMore = true;
  int currentPage = 1;
  final ScrollController _scrollController = ScrollController();
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();

  Future<void> fetchLatestAnime() async {
    try {
      final data = await NekopoiApiService.getLatestAnime();
      setState(() {
        latestAnimeList = data;
        isLoadingLatest = false;
      });
    } catch (e) {
      debugPrint('Error: $e');
      setState(() => isLoadingLatest = false);
    }
  }

  Future<void> fetchReleaseAnime({bool isRefresh = false}) async {
    if (isLoadingMore) return;

    if (isRefresh) {
      setState(() {
        currentPage = 1;
        hasMore = true;
        releaseAnimeList.clear();
        isLoadingRelease = true;
      });
    } else {
      setState(() {
        isLoadingMore = true;
      });
    }

    try {
      final data = await NekopoiApiService.getReleaseAnime(currentPage);

      if (data.isEmpty) {
        setState(() {
          hasMore = false;
          isLoadingMore = false;
          isLoadingRelease = false;
        });
        return;
      }

      setState(() {
        if (isRefresh) {
          releaseAnimeList = data;
        } else {
          releaseAnimeList.addAll(data);
        }
        currentPage++;
        isLoadingMore = false;
        isLoadingRelease = false;
      });
    } catch (e) {
      debugPrint('Error: $e');
      setState(() {
        isLoadingMore = false;
        isLoadingRelease = false;
      });
    }
  }

  Future<void> searchAnime(String query) async {
    if (query.isEmpty) {
      setState(() {
        isSearching = false;
        searchResults.clear();
      });
      return;
    }

    setState(() {
      isSearching = true;
      isSearchLoading = true;
    });

    try {
      final data = await NekopoiApiService.searchAnime(query);
      setState(() {
        searchResults = data;
        isSearchLoading = false;
      });
    } catch (e) {
      debugPrint('Search Error: $e');
      setState(() {
        searchResults = [];
        isSearchLoading = false;
      });
    }
  }

  void _clearSearch() {
    _searchController.clear();
    setState(() {
      isSearching = false;
      searchResults.clear();
    });
    _searchFocusNode.unfocus();
  }

  void _setupScrollController() {
    _scrollController.addListener(() {
      if (_scrollController.position.pixels >=
          _scrollController.position.maxScrollExtent - 200) {
        if (!isLoadingMore && hasMore && !isSearching) {
          fetchReleaseAnime();
        }
      }
    });
  }

  @override
  void initState() {
    super.initState();
    fetchLatestAnime();
    fetchReleaseAnime();
    _setupScrollController();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.deepPurple,
        title: const Text(
          "Nekopoi",
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        centerTitle: true,
        elevation: 0,
      ),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            color: const Color(0xFF0A1118),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFF102A43),
                      borderRadius: BorderRadius.circular(25),
                    ),
                    child: TextField(
                      controller: _searchController,
                      focusNode: _searchFocusNode,
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        hintText: "Cari anime...",
                        hintStyle:
                            const TextStyle(color: Color(0xFF78909C)),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 15,
                        ),
                        prefixIcon: const Icon(
                          Icons.search,
                          color: Color(0xFF78909C),
                        ),
                        suffixIcon: _searchController.text.isNotEmpty
                            ? IconButton(
                                icon: const Icon(
                                  Icons.clear,
                                  color: Color(0xFF78909C),
                                ),
                                onPressed: _clearSearch,
                              )
                            : null,
                      ),
                      onChanged: (value) {
                        if (value.isNotEmpty) {
                          searchAnime(value);
                        } else {
                          setState(() {
                            isSearching = false;
                            searchResults.clear();
                          });
                        }
                      },
                      onSubmitted: (value) {
                        if (value.isNotEmpty) {
                          searchAnime(value);
                        }
                      },
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                if (isSearchLoading)
                  const SizedBox(
                    width: 40,
                    height: 40,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: Colors.deepPurpleAccent,
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            child:
                isSearching ? _buildSearchResults() : _buildHomeContent(),
          ),
        ],
      ),
    );
  }

  Widget _buildHomeContent() {
    return RefreshIndicator(
      onRefresh: () async {
        await fetchLatestAnime();
        await fetchReleaseAnime(isRefresh: true);
      },
      color: Colors.deepPurpleAccent,
      child: CustomScrollView(
        controller: _scrollController,
        slivers: [
          SliverToBoxAdapter(
            child: Column(
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.deepPurple.shade800,
                        Colors.deepPurple.shade900,
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Latest Releases",
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "Total ${latestAnimeList.length} video terbaru",
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.7),
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
                if (isLoadingLatest)
                  SizedBox(
                    height: 180,
                    child: ListView.builder(
                      padding: const EdgeInsets.all(12),
                      scrollDirection: Axis.horizontal,
                      itemCount: 5,
                      itemBuilder: (_, __) => Container(
                        width: 120,
                        margin: const EdgeInsets.only(right: 12),
                        child: Shimmer.fromColors(
                          baseColor: const Color(0xFF102A43),
                          highlightColor: const Color(0xFF102A43),
                          child: Container(
                            decoration: BoxDecoration(
                              color: const Color(0xFF0A1118),
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ),
                    ),
                  )
                else if (latestAnimeList.isNotEmpty)
                  SizedBox(
                    height: 180,
                    child: ListView.builder(
                      padding: const EdgeInsets.all(12),
                      scrollDirection: Axis.horizontal,
                      itemCount: latestAnimeList.length,
                      itemBuilder: (context, index) {
                        return Container(
                          width: 120,
                          margin: const EdgeInsets.only(right: 12),
                          child: NekopoiVideoCard(
                              anime: latestAnimeList[index], isLatest: true),
                        );
                      },
                    ),
                  ),
                const SizedBox(height: 16),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.deepPurple.shade800,
                        Colors.deepPurple.shade900,
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "All Releases",
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "Halaman $currentPage",
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.7),
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (isLoadingRelease)
            const SliverToBoxAdapter(
              child: NekopoiLoadingShimmer(),
            )
          else if (releaseAnimeList.isNotEmpty)
            SliverPadding(
              padding: const EdgeInsets.all(12),
              sliver: SliverGrid(
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 0.7,
                ),
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    return NekopoiVideoCard(
                        anime: releaseAnimeList[index], isLatest: false);
                  },
                  childCount: releaseAnimeList.length,
                ),
              ),
            ),
          if (isLoadingMore)
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Center(
                  child: CircularProgressIndicator(
                      color: Colors.deepPurpleAccent),
                ),
              ),
            ),
          if (!hasMore && releaseAnimeList.isNotEmpty)
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Center(
                  child: Text(
                    "Tidak ada lagi data",
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSearchResults() {
    if (isSearchLoading) {
      return const NekopoiLoadingShimmer();
    }

    if (searchResults.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.search_off,
              color: Colors.grey.shade600,
              size: 64,
            ),
            const SizedBox(height: 16),
            const Text(
              "Tidak ada hasil pencarian",
              style: TextStyle(
                color: Color(0xFF78909C),
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "Coba dengan kata kunci lain",
              style: TextStyle(
                color: Colors.grey.shade500,
                fontSize: 14,
              ),
            ),
          ],
        ),
      );
    }

    return Column(
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.deepPurple.shade800,
                Colors.deepPurple.shade900,
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Search Results",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                "Menampilkan ${searchResults.length} hasil untuk '${_searchController.text}'",
                style: TextStyle(
                  color: Colors.white.withOpacity(0.7),
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.all(12),
            gridDelegate:
                const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 0.7,
            ),
            itemCount: searchResults.length,
            itemBuilder: (context, index) {
              return NekopoiVideoCard(
                  anime: searchResults[index], isLatest: false);
            },
          ),
        ),
      ],
    );
  }
}

class NekopoiDetailScreen extends StatefulWidget {
  final String url;

  const NekopoiDetailScreen({super.key, required this.url});

  @override
  State<NekopoiDetailScreen> createState() => _NekopoiDetailScreenState();
}

class _NekopoiDetailScreenState extends State<NekopoiDetailScreen>
    with WidgetsBindingObserver {
  NekopoiDetailModel? animeDetail;
  bool isLoading = true;
  bool isError = false;
  bool isPlaying = false;
  bool isFullScreen = false;
  late WebViewController _webViewController;
  bool _isWebViewLoading = true;
  String? _streamUrl;

  Future<void> fetchAnimeDetail() async {
    try {
      final data = await NekopoiApiService.getAnimeDetail(widget.url);
      setState(() {
        animeDetail = data;
        _streamUrl = data.stream;
        isLoading = false;
      });
    } catch (e) {
      debugPrint('Error: $e');
      setState(() {
        isLoading = false;
        isError = true;
      });
    }
  }

  void _initializeWebView() {
    if (_streamUrl == null) return;

    _webViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..addJavaScriptChannel(
        'FullScreen',
        onMessageReceived: (JavaScriptMessage message) {
          if (message.message == 'enter') {
            _enterFullScreen();
          } else if (message.message == 'exit') {
            _exitFullScreen();
          }
        },
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            if (progress == 100) {
              setState(() {
                _isWebViewLoading = false;
              });
              _injectJavaScript();
            }
          },
          onPageStarted: (String url) {
            setState(() {
              _isWebViewLoading = true;
            });
          },
          onPageFinished: (String url) {
            setState(() {
              _isWebViewLoading = false;
            });
            _injectJavaScript();
          },
          onWebResourceError: (WebResourceError error) {
            setState(() {
              _isWebViewLoading = false;
            });
          },
          onNavigationRequest: (NavigationRequest request) {
            if (request.url != _streamUrl) {
              debugPrint('Blocked navigation to: ${request.url}');
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse(_streamUrl!));
  }

  void _injectJavaScript() {
    _webViewController.runJavaScript('''
      document.addEventListener('click', function(e) {
        const target = e.target.closest('a');
        if (target) {
          e.preventDefault();
          e.stopPropagation();
          return false;
        }
      }, true);
      
      document.addEventListener('submit', function(e) {
        e.preventDefault();
        e.stopPropagation();
        return false;
      }, true);
      
      function handleFullScreenChange() {
        if (document.fullscreenElement || document.webkitFullscreenElement || 
            document.mozFullScreenElement || document.msFullscreenElement) {
          FullScreen.postMessage('enter');
        } else {
          FullScreen.postMessage('exit');
        }
      }
      
      document.addEventListener('fullscreenchange', handleFullScreenChange);
      document.addEventListener('webkitfullscreenchange', handleFullScreenChange);
      document.addEventListener('mozfullscreenchange', handleFullScreenChange);
      document.addEventListener('MSFullscreenChange', handleFullScreenChange);
      
      document.addEventListener('click', function(e) {
        if (e.target.tagName === 'VIDEO' || e.target.closest('video')) {
          setTimeout(handleFullScreenChange, 100);
        }
      });
      
      document.addEventListener('touchend', function(e) {
        if (e.target.tagName === 'VIDEO' || e.target.closest('video')) {
          setTimeout(handleFullScreenChange, 100);
        }
      });
      
      document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
          setTimeout(handleFullScreenChange, 100);
        }
      });
    ''');
  }

  void _enterFullScreen() {
    if (!isFullScreen) {
      setState(() {
        isFullScreen = true;
      });

      SystemChrome.setPreferredOrientations([
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);

      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    }
  }

  void _exitFullScreen() {
    if (isFullScreen) {
      setState(() {
        isFullScreen = false;
      });

      SystemChrome.setPreferredOrientations([
        DeviceOrientation.portraitUp,
        DeviceOrientation.portraitDown,
      ]);

      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    }
  }

  void _showDownloadOptions() {
    if (animeDetail == null || animeDetail!.downloads.isEmpty) return;

    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF0A1118),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        return SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "📥 Download Options",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 16),
                ...animeDetail!.downloads.map((option) {
                  return Card(
                    color: Colors.deepPurple.shade900.withOpacity(0.3),
                    margin: const EdgeInsets.only(bottom: 12),
                    child: ExpansionTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.deepPurple.shade800,
                        child: Text(
                          option.type.toUpperCase(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      title: Text(
                        option.title,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      children: option.links.map((link) {
                        return ListTile(
                          leading: _getProviderIcon(link.name),
                          title: Text(
                            link.name,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                            ),
                          ),
                          trailing: const Icon(
                            Icons.download,
                            color: Colors.deepPurpleAccent,
                            size: 20,
                          ),
                          onTap: () async {
                            try {
                              await NekopoiUrlHelper.launch(link.url);
                            } catch (e) {
                              if (context.mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                      content: Text(
                                          'Tidak dapat membuka URL')),
                                );
                              }
                            }
                          },
                        );
                      }).toList(),
                    ),
                  );
                }).toList(),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _getProviderIcon(String provider) {
    switch (provider.toLowerCase()) {
      case 'mp4upload':
        return const Icon(Icons.video_file, color: Colors.blue, size: 20);
      case 'pixeldrain':
        return const Icon(Icons.cloud_download,
            color: Colors.white, size: 20);
      case 'krakenfiles':
        return const Icon(Icons.folder, color: Colors.orange, size: 20);
      case 'mirror':
        return const Icon(Icons.copy_all, color: Colors.purple, size: 20);
      default:
        return const Icon(Icons.download, color: Colors.white, size: 20);
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    fetchAnimeDetail();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  void didChangeMetrics() {
    final physicalSize = WidgetsBinding.instance.window.physicalSize;
    final pixelRatio = WidgetsBinding.instance.window.devicePixelRatio;
    final logicalSize = physicalSize / pixelRatio;

    final isNowFullScreen = logicalSize.width > logicalSize.height;

    if (isNowFullScreen != isFullScreen) {
      setState(() {
        isFullScreen = isNowFullScreen;
      });

      if (isFullScreen) {
        SystemChrome.setPreferredOrientations([
          DeviceOrientation.landscapeLeft,
          DeviceOrientation.landscapeRight,
        ]);
        SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
      } else {
        SystemChrome.setPreferredOrientations([
          DeviceOrientation.portraitUp,
          DeviceOrientation.portraitDown,
        ]);
        SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: isFullScreen
          ? null
          : AppBar(
              backgroundColor: Colors.deepPurple,
              title: Text(
                animeDetail?.title ?? "Detail Anime",
                style: const TextStyle(
                    fontWeight: FontWeight.bold, color: Colors.white),
              ),
              centerTitle: true,
            ),
      body: isLoading
          ? _buildLoadingShimmer()
          : isError || animeDetail == null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.error_outline,
                          color: Colors.white54, size: 64),
                      const SizedBox(height: 16),
                      const Text(
                        "Gagal memuat detail anime",
                        style: TextStyle(color: Colors.white),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: fetchAnimeDetail,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.deepPurple,
                        ),
                        child: const Text("Coba Lagi",
                            style: TextStyle(color: Colors.white)),
                      ),
                    ],
                  ),
                )
              : isPlaying
                  ? _buildVideoPlayer()
                  : _buildAnimeDetail(),
    );
  }

  Widget _buildVideoPlayer() {
    return Container(
      width: double.infinity,
      height: isFullScreen ? MediaQuery.of(context).size.height : null,
      color: Colors.black,
      child: Stack(
        children: [
          _isWebViewLoading
              ? Container(
                  color: Colors.black,
                  child: const Center(
                    child: CircularProgressIndicator(
                        color: Colors.deepPurpleAccent),
                  ),
                )
              : WebViewWidget(controller: _webViewController),
          if (isFullScreen)
            Positioned(
              top: 40,
              right: 20,
              child: IconButton(
                icon: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.black54,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Icon(Icons.fullscreen_exit,
                      color: Colors.white, size: 30),
                ),
                onPressed: _exitFullScreen,
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildAnimeDetail() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 200,
            width: double.infinity,
            color: Colors.black,
            child: Stack(
              children: [
                ClipRRect(
                  child: Image.network(
                    animeDetail!.image,
                    width: double.infinity,
                    height: 200,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      height: 200,
                      color: const Color(0xFF102A43),
                      alignment: Alignment.center,
                      child: const Icon(Icons.image_not_supported,
                          color: Colors.white54),
                    ),
                  ),
                ),
                Positioned.fill(
                  child: Center(
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          isPlaying = true;
                        });
                        _initializeWebView();
                      },
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.5),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.play_arrow,
                          color: Colors.white,
                          size: 50,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  animeDetail!.title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  animeDetail!.info,
                  style: const TextStyle(
                    color: Color(0xFF78909C),
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 16),
                _buildInfoItem("Anime", animeDetail!.anime),
                _buildInfoItem("Producers", animeDetail!.producers),
                _buildInfoItem("Duration", animeDetail!.duration),
                _buildInfoItem("Size", animeDetail!.size),
                const SizedBox(height: 16),
                const Text(
                  "Genre",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: animeDetail!.genre.split(',').map((g) {
                    return Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.deepPurple.shade800,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        g.trim(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),
                const Text(
                  "Synopsis",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  animeDetail!.synopsis,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                    height: 1.5,
                  ),
                  textAlign: TextAlign.justify,
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: isPlaying
                            ? null
                            : () {
                                setState(() {
                                  isPlaying = true;
                                });
                                _initializeWebView();
                              },
                        icon: const Icon(Icons.play_arrow),
                        label: const Text("Play"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.deepPurple,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _showDownloadOptions,
                        icon: const Icon(Icons.download),
                        label: const Text("Download"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.deepPurple.shade800,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 80,
            child: Text(
              "$label:",
              style: const TextStyle(
                color: Color(0xFF78909C),
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingShimmer() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Shimmer.fromColors(
            baseColor: const Color(0xFF102A43),
            highlightColor: const Color(0xFF102A43),
            child: Container(
              height: 200,
              width: double.infinity,
              color: const Color(0xFF0A1118),
            ),
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Shimmer.fromColors(
                  baseColor: const Color(0xFF102A43),
                  highlightColor: const Color(0xFF102A43),
                  child: Container(
                    height: 24,
                    width: double.infinity,
                    color: const Color(0xFF0A1118),
                  ),
                ),
                const SizedBox(height: 8),
                Shimmer.fromColors(
                  baseColor: const Color(0xFF102A43),
                  highlightColor: const Color(0xFF102A43),
                  child: Container(
                    height: 16,
                    width: double.infinity,
                    color: const Color(0xFF0A1118),
                  ),
                ),
                const SizedBox(height: 16),
                ...List.generate(
                  4,
                  (index) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Shimmer.fromColors(
                      baseColor: const Color(0xFF102A43),
                      highlightColor: const Color(0xFF102A43),
                      child: Container(
                        height: 16,
                        width: double.infinity,
                        color: const Color(0xFF0A1118),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}