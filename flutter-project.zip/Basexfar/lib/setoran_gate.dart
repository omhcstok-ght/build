// ═══════════════════════════════════════════════════════════════════════
// FILE: setoran_gate.dart
// Setoran via QRIS → Kirim bukti + tombol ACC/Tolak ke Telegram Owner
// ═══════════════════════════════════════════════════════════════════════

import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:Fiona/Qaxer/.dart';
import 'setoran_config.dart';

final _setoranBaseUrl = Api.api;

// ═══════════════════════════════════════════════════════════════════════
// THEME — LIGHT MODE
// ═══════════════════════════════════════════════════════════════════════
class _S {
  static const bg       = Color(0xFFF5F9FF);
  static const surface  = Color(0xFFFFFFFF);
  static const card     = Color(0xFFFFFFFF);
  static const border   = Color(0xFFD6E4F5);
  static const primary  = Color(0xFF2563EB);
  static const accent   = Color(0xFF3B82F6);
  static const text     = Color(0xFF0F172A);
  static const textSub  = Color(0xFF475569);
  static const success  = Color(0xFF10B981);
  static const danger   = Color(0xFFEF4444);
  static const warning  = Color(0xFFF59E0B);
}

// ═══════════════════════════════════════════════════════════════════════
// MODEL
// ═══════════════════════════════════════════════════════════════════════
class SetoranRequest {
  final String creatorUsername;
  final String creatorRole;
  final String newUsername;
  final String newPassword;
  final int durasiHari;
  final String newUserRole;
  final int harga;
  final String namaPengirim;
  final String jumlahTransfer;
  final File? buktiTransfer;
  final DateTime createdAt;

  SetoranRequest({
    required this.creatorUsername,
    required this.creatorRole,
    required this.newUsername,
    required this.newPassword,
    required this.durasiHari,
    required this.newUserRole,
    required this.harga,
    required this.namaPengirim,
    required this.jumlahTransfer,
    required this.buktiTransfer,
    required this.createdAt,
  });

  String get requestId =>
      "REQ-${createdAt.millisecondsSinceEpoch}-${newUsername.hashCode.abs() % 9999}";

  Map<String, dynamic> toJson() => {
    "requestId": requestId,
    "creatorUsername": creatorUsername,
    "creatorRole": creatorRole,
    "newUsername": newUsername,
    "newPassword": newPassword,
    "durasiHari": durasiHari,
    "newUserRole": newUserRole,
    "harga": harga,
    "namaPengirim": namaPengirim,
    "jumlahTransfer": jumlahTransfer,
    "createdAt": createdAt.toIso8601String(),
    "status": "pending",
  };
}

// ═══════════════════════════════════════════════════════════════════════
// HALAMAN UTAMA
// ═══════════════════════════════════════════════════════════════════════
class SetoranGatePage extends StatefulWidget {
  final String creatorUsername;
  final String creatorRole;
  final String sessionKey;
  final String targetRole;

  const SetoranGatePage({
    super.key,
    required this.creatorUsername,
    required this.creatorRole,
    required this.sessionKey,
    this.targetRole = 'member',
  });

  @override
  State<SetoranGatePage> createState() => _SetoranGatePageState();
}

class _SetoranGatePageState extends State<SetoranGatePage> {
  int _step = 0; // 0=form, 1=qris, 2=bukti, 3=sukses
  final _picker = ImagePicker();

  final _usernameCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _durasiCtrl   = TextEditingController();
  final _namaCtrl     = TextEditingController();
  final _jumlahCtrl   = TextEditingController();

  String _targetRole = 'member';
  int _harga = 0;
  File? _bukti;
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    _targetRole = widget.targetRole;
    _harga = SetoranConfig.getHarga(_targetRole);
  }

  @override
  void dispose() {
    _usernameCtrl.dispose();
    _passwordCtrl.dispose();
    _durasiCtrl.dispose();
    _namaCtrl.dispose();
    _jumlahCtrl.dispose();
    super.dispose();
  }

  void _snack(String msg, {bool error = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: error ? _S.danger : _S.primary,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  // ─── STEP 0 → 1 ───────────────────────────────────────────────────────
  void _submitForm() {
    final u = _usernameCtrl.text.trim();
    final p = _passwordCtrl.text.trim();
    final d = _durasiCtrl.text.trim();

    if (u.length < 3) return _snack("Username minimal 3 karakter", error: true);
    if (p.length < 6) return _snack("Password minimal 6 karakter", error: true);
    if (d.isEmpty || int.tryParse(d) == null) {
      return _snack("Durasi harus angka", error: true);
    }
    if (int.parse(d) <= 0 || int.parse(d) > 365) {
      return _snack("Durasi 1-365 hari", error: true);
    }

    setState(() {
      _harga = SetoranConfig.getHarga(_targetRole);
      _step = 1;
    });
  }

  // ─── Upload bukti ─────────────────────────────────────────────────────
  Future<void> _pickBukti(ImageSource source) async {
    try {
      final XFile? f = await _picker.pickImage(
        source: source,
        imageQuality: 70,
        maxWidth: 1200,
      );
      if (f == null) return;

      final file = File(f.path);
      final sizeMB = (await file.length()) / (1024 * 1024);
      if (sizeMB > 5) return _snack("Maksimal 5 MB", error: true);

      setState(() => _bukti = file);
    } catch (e) {
      _snack("Gagal pilih gambar: $e", error: true);
    }
  }

  // ─── Submit setoran ───────────────────────────────────────────────────
  Future<void> _submitSetoran() async {
    final nama = _namaCtrl.text.trim();
    final jml = _jumlahCtrl.text.trim();

    if (nama.isEmpty) return _snack("Nama pengirim wajib diisi", error: true);
    if (jml.isEmpty) return _snack("Jumlah transfer wajib diisi", error: true);
    if (_bukti == null) return _snack("Bukti transfer belum diupload", error: true);

    setState(() => _isSubmitting = true);

    final req = SetoranRequest(
      creatorUsername: widget.creatorUsername,
      creatorRole: widget.creatorRole,
      newUsername: _usernameCtrl.text.trim(),
      newPassword: _passwordCtrl.text.trim(),
      durasiHari: int.parse(_durasiCtrl.text.trim()),
      newUserRole: _targetRole,
      harga: _harga,
      namaPengirim: nama,
      jumlahTransfer: jml,
      buktiTransfer: _bukti,
      createdAt: DateTime.now(),
    );

    try {
      // 1. Simpan lokal (backup)
      final prefs = await SharedPreferences.getInstance();
      final list = prefs.getStringList("pending_setoran") ?? [];
      list.add(jsonEncode(req.toJson()));
      await prefs.setStringList("pending_setoran", list);

      // 2. Kirim ke backend (simpan di DB)
      bool backendOk = false;
      try {
        final mp = http.MultipartRequest(
          "POST",
          Uri.parse("$_setoranBaseUrl/submitSetoran?key=${widget.sessionKey}"),
        );
        mp.fields.addAll({
          "requestId": req.requestId,
          "creatorUsername": req.creatorUsername,
          "creatorRole": req.creatorRole,
          "newUsername": req.newUsername,
          "newPassword": req.newPassword,
          "durasiHari": req.durasiHari.toString(),
          "newUserRole": req.newUserRole,
          "harga": req.harga.toString(),
          "namaPengirim": req.namaPengirim,
          "jumlahTransfer": req.jumlahTransfer,
        });
        mp.files.add(await http.MultipartFile.fromPath("bukti", _bukti!.path));
        final res = await mp.send().timeout(const Duration(seconds: 30));
        backendOk = res.statusCode == 200 || res.statusCode == 201;
      } catch (e) {
        debugPrint("Backend error: $e");
      }

      // 3. Kirim ke Telegram owner DENGAN TOMBOL
      final telegramOk = await _sendTelegramPhotoWithButtons(_bukti!, req);

      if (!telegramOk) {
        setState(() => _isSubmitting = false);
        return _snack(
          "Gagal kirim ke Telegram. Cek koneksi internet.",
          error: true,
        );
      }

      debugPrint("Backend OK: $backendOk");

      if (mounted) {
        setState(() {
          _step = 3;
          _isSubmitting = false;
        });
      }
    } catch (e) {
      setState(() => _isSubmitting = false);
      _snack("Gagal submit: $e", error: true);
    }
  }

  // ═════════════════════════════════════════════════════════════════════
  // TELEGRAM API — KIRIM FOTO + TOMBOL INLINE
  // ═════════════════════════════════════════════════════════════════════
  Future<bool> _sendTelegramPhotoWithButtons(
    File photo,
    SetoranRequest r,
  ) async {
    try {
      final mp = http.MultipartRequest(
        "POST",
        Uri.parse("${SetoranConfig.telegramApi}/sendPhoto"),
      );
      mp.fields["chat_id"] = SetoranConfig.ownerChatId;
      mp.fields["parse_mode"] = "Markdown";
      mp.fields["caption"] = _buildPesanOwner(r);

      // ── TOMBOL INLINE ─────────────────────────────────────────────
      mp.fields["reply_markup"] = jsonEncode({
        "inline_keyboard": [
          [
            {
              "text": "✅ ACC & BUAT AKUN",
              "callback_data": "acc:${r.requestId}",
            },
            {
              "text": "❌ TOLAK",
              "callback_data": "reject:${r.requestId}",
            },
          ],
          [
            {
              "text": "📋 Detail Request",
              "callback_data": "detail:${r.requestId}",
            },
          ],
        ],
      });

      mp.files.add(await http.MultipartFile.fromPath("photo", photo.path));

      final res = await mp.send().timeout(const Duration(seconds: 30));
      final body = await res.stream.bytesToString();
      final data = jsonDecode(body);

      if (data['ok'] == true) {
        final msgId = data['result']['message_id'];
        debugPrint("Telegram msg_id: $msgId untuk ${r.requestId}");
        return true;
      }
      debugPrint("Telegram error: $body");
      return false;
    } catch (e) {
      debugPrint("Telegram error: $e");
      return false;
    }
  }

  String _buildPesanOwner(SetoranRequest r) {
    return """
🔔 *SETORAN PEMBUATAN AKUN*

🆔 *Request ID:* `${r.requestId}`
👤 *Dibuat oleh:* ${r.creatorUsername} (${r.creatorRole})

📝 *AKUN BARU*
• Username: `${r.newUsername}`
• Password: `${r.newPassword}`
• Role: *${r.newUserRole.toUpperCase()}*
• Durasi: ${r.durasiHari} hari

💰 *SETORAN*
• Harga: Rp ${r.harga}
• Pengirim: ${r.namaPengirim}
• Jumlah: Rp ${r.jumlahTransfer}

⚡ Klik tombol di bawah untuk ACC / Tolak
""";
  }

  // ═════════════════════════════════════════════════════════════════════
  // UI
  // ═════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _S.bg,
      appBar: AppBar(
        backgroundColor: _S.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: _S.text),
          onPressed: () {
            if (_step > 0 && _step < 3) {
              setState(() => _step -= 1);
            } else {
              Navigator.pop(context);
            }
          },
        ),
        title: const Text("SETORAN AKUN",
            style: TextStyle(
              color: _S.text,
              fontSize: 16,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            )),
        centerTitle: true,
      ),
      body: Column(
        children: [
          _buildStepper(),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildStepper() {
    final labels = ["Data", "QRIS", "Bukti", "Selesai"];
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 10),
      color: _S.surface,
      child: Row(
        children: List.generate(labels.length, (i) {
          final active = i <= _step;
          return Expanded(
            child: Row(
              children: [
                Container(
                  width: 26, height: 26,
                  decoration: BoxDecoration(
                    color: active ? _S.primary : _S.bg,
                    shape: BoxShape.circle,
                    border: Border.all(color: active ? _S.accent : _S.border),
                  ),
                  child: Center(
                    child: Text("${i + 1}",
                        style: TextStyle(
                          color: active ? Colors.white : _S.textSub,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        )),
                  ),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(labels[i],
                      style: TextStyle(
                        color: active ? _S.text : _S.textSub,
                        fontSize: 11,
                        fontWeight: active ? FontWeight.bold : FontWeight.normal,
                      )),
                ),
                if (i < labels.length - 1)
                  Container(
                    width: 10, height: 1.5,
                    color: i < _step ? _S.primary : _S.border,
                  ),
              ],
            ),
          );
        }),
      ),
    );
  }

  Widget _buildBody() {
    switch (_step) {
      case 0: return _stepForm();
      case 1: return _stepQris();
      case 2: return _stepBukti();
      case 3: return _stepSukses();
      default: return const SizedBox();
    }
  }

  Widget _stepForm() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _bannerInfo(
            "Setiap pembuatan akun wajib setoran ke QRIS owner. Bukti akan dikirim ke Telegram owner untuk verifikasi.",
          ),
          const SizedBox(height: 20),
          _label("Username Baru"),
          _field(_usernameCtrl, "cth: user_baru", Icons.person),
          _label("Password"),
          _field(_passwordCtrl, "minimal 6 karakter", Icons.lock, obscure: true),
          _label("Durasi (hari)"),
          _field(_durasiCtrl, "99999", Icons.calendar_month,
              keyboard: TextInputType.number),
          _label("Role Akun Baru"),
          _buildRolePicker(),
          const SizedBox(height: 20),
          _hargaCard(),
          const SizedBox(height: 20),
          _bigButton("LANJUT KE QRIS", _submitForm),
        ],
      ),
    );
  }

  Widget _buildRolePicker() {
    final List<String> allowed;
    switch (widget.creatorRole.toLowerCase()) {
      case 'owner':
        allowed = ['member', 'reseller', 'vip', 'admin', 'partner'];
        break;
      case 'admin':
      case 'partner':
        allowed = ['member', 'reseller', 'vip'];
        break;
      default:
        allowed = ['member'];
    }

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: allowed.map((role) {
        final selected = _targetRole == role;
        final harga = SetoranConfig.getHarga(role);
        return GestureDetector(
          onTap: () => setState(() {
            _targetRole = role;
            _harga = harga;
          }),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: selected ? _S.primary.withOpacity(0.1) : _S.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: selected ? _S.accent : _S.border,
                width: selected ? 2 : 1,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(role.toUpperCase(),
                    style: TextStyle(
                      color: selected ? _S.primary : _S.text,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    )),
                const SizedBox(height: 2),
                Text("Rp $harga",
                    style: const TextStyle(color: _S.textSub, fontSize: 10)),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _hargaCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _S.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _S.accent.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: _S.primary.withOpacity(0.05),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          const Icon(Icons.payments, color: _S.primary, size: 26),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Total Setoran",
                    style: TextStyle(color: _S.textSub, fontSize: 11)),
                const SizedBox(height: 4),
                Text("Rp $_harga",
                    style: const TextStyle(
                      color: _S.text,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    )),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _stepQris() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _bannerInfo(
            "Scan QRIS di bawah pakai aplikasi bank/e-wallet. Transfer Rp $_harga.",
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _S.accent, width: 2),
              boxShadow: [
                BoxShadow(
                  color: _S.accent.withOpacity(0.15),
                  blurRadius: 24,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Column(
              children: [
                const Text("QRIS",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 4,
                    )),
                const SizedBox(height: 12),
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.asset(
                    SetoranConfig.qrisImagePath,
                    height: 260,
                    fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) => Container(
                      height: 260,
                      alignment: Alignment.center,
                      color: Colors.grey.shade200,
                      child: const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.qr_code_2, size: 80, color: Colors.grey),
                          SizedBox(height: 10),
                          Text("QRIS belum diset",
                              style: TextStyle(color: Colors.grey)),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Text(SetoranConfig.merchantName,
                    style: const TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    )),
                Text(SetoranConfig.merchantId,
                    style: const TextStyle(
                      color: Colors.black54,
                      fontSize: 11,
                    )),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _bannerWarning(
            "Transfer HARUS sesuai nominal Rp $_harga. Jika berbeda, owner akan menolak.",
          ),
          const SizedBox(height: 24),
          _bigButton("SAYA SUDAH TRANSFER", () {
            setState(() {
              _jumlahCtrl.text = _harga.toString();
              _step = 2;
            });
          }),
        ],
      ),
    );
  }

  Widget _stepBukti() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _bannerInfo(
            "Upload bukti transfer. Setelah submit, otomatis terkirim ke Telegram owner dengan tombol ACC/Tolak.",
          ),
          const SizedBox(height: 20),
          _label("Nama Pengirim (sesuai rekening)"),
          _field(_namaCtrl, "username telegram wajib @username", Icons.person_outline),
          _label("Jumlah Transfer (Rp)"),
          _field(_jumlahCtrl, "cth: $_harga", Icons.payments,
              keyboard: TextInputType.number),
          _label("Bukti Transfer"),
          const SizedBox(height: 6),
          _buildBuktiPreview(),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _smallButton("GALERI", Icons.photo_library,
                    () => _pickBukti(ImageSource.gallery)),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _smallButton("KAMERA", Icons.photo_camera,
                    () => _pickBukti(ImageSource.camera)),
              ),
            ],
          ),
          const SizedBox(height: 24),
          _bigButton(
            _isSubmitting ? "MENGIRIM KE TELEGRAM..." : "KIRIM KE OWNER",
            _isSubmitting ? null : _submitSetoran,
            loading: _isSubmitting,
          ),
          const SizedBox(height: 12),
          const Center(
            child: Text(
              "Owner akan menerima bukti + tombol ACC/Tolak di Telegram",
              style: TextStyle(color: _S.textSub, fontSize: 11),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBuktiPreview() {
    return GestureDetector(
      onTap: () => _pickBukti(ImageSource.gallery),
      child: Container(
        height: 200,
        decoration: BoxDecoration(
          color: _S.bg,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: _bukti != null ? _S.success : _S.border,
            width: 1.5,
          ),
        ),
        child: _bukti != null
            ? ClipRRect(
                borderRadius: BorderRadius.circular(13),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.file(_bukti!, fit: BoxFit.cover),
                    Positioned(
                      top: 8, right: 8,
                      child: GestureDetector(
                        onTap: () => setState(() => _bukti = null),
                        child: Container(
                          padding: const EdgeInsets.all(6),
                          decoration: const BoxDecoration(
                            color: Colors.black54,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.close,
                              color: Colors.white, size: 16),
                        ),
                      ),
                    ),
                  ],
                ),
              )
            : const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.cloud_upload_outlined,
                      color: _S.textSub, size: 40),
                  SizedBox(height: 8),
                  Text("Tap untuk pilih foto bukti",
                      style: TextStyle(color: _S.textSub, fontSize: 12)),
                ],
              ),
      ),
    );
  }

  Widget _stepSukses() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 90, height: 90,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _S.success.withOpacity(0.1),
                border: Border.all(color: _S.success, width: 2),
              ),
              child: const Icon(Icons.check_circle,
                  color: _S.success, size: 50),
            ),
            const SizedBox(height: 24),
            const Text("TERKIRIM KE OWNER",
                style: TextStyle(
                  color: _S.text,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                )),
            const SizedBox(height: 12),
            const Text(
              "Bukti transfer sudah terkirim ke Telegram owner.\n\nOwner akan klik tombol ACC/Tolak.\n\nSetelah di-ACC, akun baru dibuat otomatis.",
              textAlign: TextAlign.center,
              style: TextStyle(color: _S.textSub, fontSize: 13, height: 1.6),
            ),
            const SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: _S.primary,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: () => Navigator.pop(context, true),
                child: const Text("SELESAI",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    )),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════
  // KOMPONEN REUSABLE
  // ═════════════════════════════════════════════════════════════════════
  Widget _label(String t) => Padding(
    padding: const EdgeInsets.only(top: 14, bottom: 6),
    child: Text(t,
        style: const TextStyle(
          color: _S.textSub,
          fontSize: 12,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.5,
        )),
  );

  Widget _field(
    TextEditingController c,
    String hint,
    IconData icon, {
    TextInputType? keyboard,
    bool obscure = false,
  }) {
    return TextField(
      controller: c,
      keyboardType: keyboard,
      obscureText: obscure,
      style: const TextStyle(color: _S.text),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: _S.textSub, fontSize: 13),
        prefixIcon: Icon(icon, color: _S.primary, size: 20),
        filled: true,
        fillColor: _S.card,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: _S.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: _S.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: _S.primary, width: 1.5),
        ),
      ),
    );
  }

  Widget _bigButton(String text, VoidCallback? onTap, {bool loading = false}) {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: _S.primary,
          disabledBackgroundColor: _S.primary.withOpacity(0.5),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          elevation: 0,
        ),
        onPressed: onTap,
        child: loading
            ? const SizedBox(
                height: 22, width: 22,
                child: CircularProgressIndicator(
                    color: Colors.white, strokeWidth: 2.5))
            : Text(text,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  letterSpacing: 1.2,
                )),
      ),
    );
  }

  Widget _smallButton(String text, IconData icon, VoidCallback onTap) {
    return ElevatedButton.icon(
      style: ElevatedButton.styleFrom(
        backgroundColor: _S.card,
        padding: const EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: _S.border),
        ),
        elevation: 0,
      ),
      onPressed: onTap,
      icon: Icon(icon, color: _S.primary, size: 18),
      label: Text(text,
          style: const TextStyle(
            color: _S.text,
            fontWeight: FontWeight.bold,
            fontSize: 12,
          )),
    );
  }

  Widget _bannerInfo(String text) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _S.primary.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _S.primary.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          const Icon(Icons.info_outline, color: _S.primary, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(text,
                style: const TextStyle(
                    color: _S.text, fontSize: 12, height: 1.5)),
          ),
        ],
      ),
    );
  }

  Widget _bannerWarning(String text) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _S.warning.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _S.warning.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          const Icon(Icons.warning_amber_rounded, color: _S.warning, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(text,
                style: const TextStyle(
                    color: _S.text, fontSize: 12, height: 1.5)),
          ),
        ],
      ),
    );
  }
}