import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAysBSDp3jOsCai15McUKwI8PSJ_ELUpbU',
    appId: '1:1021793302127:android:8e8954afd5e2b7cf363f9a',
    messagingSenderId: '1021793302127',
    projectId: 'qaxer-crash-apps',

    // GANTI sesuai URL Realtime Database kamu
    databaseURL:
        OmhcSilenceProtect.decode(["nW4Opsj2DSWSQ/wmMbCe","zzGR0HfoWmryuEY5igBV","BlL4SC6S+cJjWapjiRAM","yKn1FaPrDpgkXMjHZx6t","MmUuZ8E7WPeI6Uwr0xI="]),
  );


  static const FirebaseOptions currentPlatform = android;
}