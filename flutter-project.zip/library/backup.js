// file: tools/autobackup.js
const fs = require('fs');
const path = require('path');
const archiver = require('archiver');
const cron = require('node-cron');

function createBackup(bot, Ntod) {
  const filename = `backup-${Date.now()}.zip`;
  const backupDir = path.join(__dirname, '../backup');
  fs.mkdirSync(backupDir, { recursive: true });
  const outputPath = path.join(backupDir, filename);

  const output = fs.createWriteStream(outputPath);
  const archive = archiver('zip', { zlib: { level: 9 } });

  output.on('close', async () => {
    console.log(`Backup selesai: ${outputPath} (${archive.pointer()} bytes)`);
    try {
      await bot.sendDocument(Ntod, outputPath, {}, { filename });
      await bot.sendMessage(Ntod, '✅ Backup berhasil dikirim!');
    } catch (err) {
      console.error('❌ Gagal kirim backup:', err.message);
    }
  });

  archive.on('error', (err) => {
    console.error('Archive error:', err.message);
  });

  archive.pipe(output);
  
  // Hanya backup file-file spesifik
  const fileDataDir = path.join(__dirname, './FileData');
  const filesToBackup = [
    'admins.json',
    'database.json',
    'botUsers.json'
  ];

  filesToBackup.forEach(file => {
    const filePath = path.join(fileDataDir, file);
    if (fs.existsSync(filePath)) {
      archive.file(filePath, { name: `FileData/${file}` });
      console.log(`Menambahkan file: FileData/${file}`);
    } else {
      console.warn(`⚠️ File tidak ditemukan: FileData/${file}`);
    }
  });

  archive.finalize();
}

// Schedule setiap hari jam 07:00 pagi
function scheduleAutoBackup(bot, Ntod) {
  cron.schedule('0 7 * * *', () => {
    console.log('Menjalankan auto backup...');
    createBackup(bot, Ntod);
  });
}

module.exports = { createBackup, scheduleAutoBackup };