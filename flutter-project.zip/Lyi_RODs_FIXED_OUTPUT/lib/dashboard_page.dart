import 'dart:convert';
import 'dart:io';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:audio_service/audio_service.dart';
import 'package:audioplayers/audioplayers.dart';
import 'device_dashboard.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:xml/xml.dart' as xml;

import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'games.dart';
import 'ordernokos.dart';
import 'global_chat_page.dart';
import 'musik_page.dart';
import 'backsound_setting.dart';
import 'audio_service.dart' as bg;
import 'theme_provider.dart';

// =============================================
// Audio Handler untuk background playback
// =============================================
class MyAudioHandler extends BaseAudioHandler with SeekHandler {
  final AudioPlayer _player = AudioPlayer();

  MyAudioHandler() {
    _listenToPlayerState();
    _listenToPositionChanges();
    _listenToPlayerErrors();
  }

  void _listenToPlayerState() {
    _player.onPlayerStateChanged.listen((state) {
      if (state == PlayerState.playing) {
        playbackState.add(playbackState.value.copyWith(
          playing: true,
          processingState: AudioProcessingState.ready,
          controls: [
            MediaControl.skipToPrevious,
            MediaControl.pause,
            MediaControl.skipToNext,
            MediaControl.stop,
          ],
          androidCompactActionIndices: const [0, 1, 2],
        ));
      } else if (state == PlayerState.paused) {
        playbackState.add(playbackState.value.copyWith(
          playing: false,
          processingState: AudioProcessingState.ready,
          controls: [
            MediaControl.skipToPrevious,
            MediaControl.play,
            MediaControl.skipToNext,
            MediaControl.stop,
          ],
          androidCompactActionIndices: const [0, 1, 2],
        ));
      } else if (state == PlayerState.completed) {
        playbackState.add(playbackState.value.copyWith(
          playing: false,
          processingState: AudioProcessingState.completed,
        ));
      } else if (state == PlayerState.disposed) {
        playbackState.add(playbackState.value.copyWith(
          playing: false,
          processingState: AudioProcessingState.idle,
        ));
      }
    });
  }

  void _listenToPositionChanges() {
    _player.onPositionChanged.listen((position) {
      playbackState.add(playbackState.value.copyWith(
        updatePosition: position,
      ));
    });
  }

  void _listenToPlayerErrors() {
    _player.onLog.listen((msg) {
      if (msg.contains('error') || msg.contains('Error') || msg.contains('ERROR')) {
        debugPrint("AudioHandler Error: $msg");
      }
    });
  }

  @override
  Future<void> play() async {
    await _player.resume();
  }

  @override
  Future<void> pause() async {
    await _player.pause();
  }

  @override
  Future<void> stop() async {
    await _player.stop();
    await super.stop();
  }

  @override
  Future<void> seek(Duration position) async {
    await _player.seek(position);
  }

  Future<void> playFromUrl(
    String url, {
    String title = 'Unknown',
    String artist = 'Unknown',
    String album = '',
    String artUri = '',
  }) async {
    mediaItem.add(MediaItem(
      id: url,
      title: title,
      artist: artist,
      album: album,
      artUri: artUri.isNotEmpty ? Uri.parse(artUri) : null,
    ));
    await _player.stop();
    await _player.setSourceUrl(url);
    await _player.resume();
  }

  Future<void> pausePlayback() async {
    await _player.pause();
  }

  Future<void> resumePlayback() async {
    await _player.resume();
  }

  Future<void> seekToPosition(Duration position) async {
    await _player.seek(position);
  }

  Future<void> stopPlayback() async {
    await _player.stop();
  }

  bool get isPlaying => _player.state == PlayerState.playing;
}

// =============================================
// Dashboard Page
// =============================================
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  ThemeProvider get tp => ThemeProvider();

  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;
  VideoPlayerController? _bgVideoController;
  VideoPlayerController? _menuVideoController;
  VideoPlayerController? _bannerVideoController;
  late PageController _pageController;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = "unknown";
  String deviceModel = "Unknown";
  File? _profileImage;
  int _bottomNavIndex = 0;
  int onlineUsers = 0;
  int activeConnections = 0;

  Map<String, dynamic>? weatherData;
  bool isLoadingWeather = true;
  String weatherErrorMsg = "";

  int batteryLevel = 0;
  String batteryState = "Unknown";
  String osVersion = "Unknown";
  int sdkInt = 0;

  double _deviceUptime = 0.0;
  int _totalRamMb = 0;
  int _usedRamMb = 0;
  int _totalStorageGb = 0;
  int _freeStorageGb = 0;
  String _networkType = "Unknown";
  int _signalStrength = 0;

  int _accountDaysLeft = 0;
  double _accountProgress = 0.0;
  String _accountStatus = "ACTIVE";
  bool _isAccountExpired = false;

  int _selectedNewsTab = 0;
  final List<Map<String, String>> _newsTabs = [
    {"label": "ANTARA TERKINI", "url": "https://www.antaranews.com/rss/terkini.xml"},
    {"label": "DETIK NEWS", "url": "https://rss.detik.com/index.php"},
    {"label": "KOMPAS", "url": "https://www.kompas.com/rss"},
    {"label": "INTERNASIONAL", "url": "https://www.antaranews.com/rss/internasional.xml"},
    {"label": "HIBURAN", "url": "https://www.antaranews.com/rss/hiburan.xml"},
    {"label": "EKONOMI", "url": "https://www.antaranews.com/rss/ekonomi.xml"},
    {"label": "OLAHRAGA", "url": "https://www.antaranews.com/rss/olahraga.xml"},
    {"label": "TEKNOLOGI", "url": "https://www.antaranews.com/rss/teknologi.xml"},
  ];
  final Map<int, List<Map<String, dynamic>>> _newsTabData = {};
  final Map<int, bool> _newsTabLoading = {};
  final Map<int, String> _newsTabError = {};

  int _selectedWidgetIndex = 0;
  final List<Map<String, dynamic>> _widgetOptions = [
    {"icon": FontAwesomeIcons.newspaper, "label": "NEWS"},
    {"icon": FontAwesomeIcons.mosque, "label": "SHALAT"},
    {"icon": FontAwesomeIcons.cloudSun, "label": "CUACA"},
    {"icon": FontAwesomeIcons.spotify, "label": "MUSIC"},
    {"icon": FontAwesomeIcons.clock, "label": "JAM"},
  ];

  MyAudioHandler? _audioHandler;
  bool _audioServiceInitialized = false;
  bool _isBgMusicOn = true;

  bool _spotifyPlaying = false;
  bool _spotifyLoading = false;
  Duration _spotifyDuration = Duration.zero;
  Duration _spotifyPosition = Duration.zero;
  String _spotifyDurationStr = "0:00";
  String _spotifyPositionStr = "0:00";
  double _spotifyProgress = 0.0;

  final TextEditingController _spotifySearchController = TextEditingController();
  List<Map<String, dynamic>> _spotifySearchResults = [];
  bool _isSearching = false;
  String _searchError = "";

  Map<String, dynamic>? _currentPlayingSong;
  String _currentSongTitle = "No Song Playing";
  String _currentSongArtist = "-";
  String _currentSongImage = "";
  String _currentSongAlbum = "-";

  final List<Map<String, dynamic>> _spotifyQueue = [];
  int _spotifyCurrentIndex = -1;

  bool _showSearchResults = false;
  bool _showQueue = false;

  final List<Map<String, String>> thanksToList = [
    {"name": "Lyi", "role": "Owner"},
    {"name": "DEVELOPER LY", "role": "Backend"},
    {"name": "CH RODS", "role": "UI/UX Designer"},
    {"name": "ALL MEMBERS", "role": "Supporter"},
  ];
  int _currentThanksIndex = 0;

  // ========== BROADCAST RECEIVER ==========
  WebSocketChannel? _broadcastChannel;
  final List<Map<String, String>> _broadcastMessages = [];
  bool _isBroadcastConnected = false;
  final TextEditingController _broadcastUrlController = TextEditingController(
    text: 'ws://console.miunnst.site:5289', // default untuk emulator, ganti sesuai server
  );

  // Smooth HD Colors
  static const Color _neonCyan = Color(0xFF22D1EE);
  static const Color _bgCyan = Color(0xFF0A1518);
  static const Color _neonPurple = Color(0xFFA855F7);
  static const Color _bgPurple = Color(0xFF140E1F);
  static const Color _neonGreen = Color(0xFF34D399);
  static const Color _bgGreen = Color(0xFF0A1810);
  static const Color _neonPink = Color(0xFFF472B6);
  static const Color _bgPink = Color(0xFF1A0E17);
  static const Color _neonOrange = Color(0xFFFB923C);
  static const Color _bgOrange = Color(0xFF1A120A);
  static const Color _textPrimary = Color(0xFFEAEAF0);
  static const Color _textSecondary = Color(0xFF6B6B80);
  static const Color _neonBlue = Color(0xFF38BDF8);
  static const Color _neonWhite = Color(0xFFF0F4FF);
  static const Color _spotifyGreen = Color(0xFF34D399);
  static const Color _spotifyDarkGreen = Color(0xFF0A1F12);
  static const Color _spotifyBg = Color(0xFF080E0A);

  Timer? _clockTimer;
  String _clockTime = "00:00:00";
  String _clockDate = "";

  final TextEditingController _noteController = TextEditingController();
  String _quickNote = "";
  bool _noteExpanded = false;

  final List<String> _motivations = [
    "Konsistensi adalah kunci sukses.",
    "Mulai dari yang kecil, hasilkan yang besar.",
    "Setiap hari adalah kesempatan baru.",
    "Jangan pernah menyerah pada proses.",
    "Disiplin melebihi motivasi.",
    "Focus on progress, not perfection.",
    "Hari ini lebih baik dari kemarin.",
  ];
  String _dailyMotivation = "";

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _dailyMotivation = _motivations[DateTime.now().day % _motivations.length];

    _pageController = PageController(initialPage: 0);
    _controller = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _animation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutCubic,
    );
    _controller.forward();

    _initAudioService();
    _isBgMusicOn = bg.AudioService().isEnabled;
    _initAndroidIdAndConnect();
    _loadProfileImage();
    _loadQuickNote();
    _initBgVideo();
    _initMenuVideo();
    _initBannerVideo();
    _calculateAccountStats();
    _initClock();
    _initLocationBasedFeatures();
    _fetchDeviceStats();
    _startThanksToAutoSlider();
    _fetchRssNewsForTab(0);
  }

  Future<void> _loadQuickNote() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _quickNote = prefs.getString('quick_note_$username') ?? "";
      _noteController.text = _quickNote;
    });
  }

  Future<void> _saveQuickNote(String text) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('quick_note_$username', text);
    setState(() {
      _quickNote = text;
    });
  }

  void _initClock() {
    final now = DateTime.now();
    _clockTime = _formatClock(now);
    _clockDate = _formatDateFull(now);
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      final n = DateTime.now();
      setState(() {
        _clockTime = _formatClock(n);
        _clockDate = _formatDateFull(n);
      });
    });
  }

  String _formatClock(DateTime dt) {
    return "${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}:${dt.second.toString().padLeft(2, '0')}";
  }

  String _formatDateFull(DateTime dt) {
    final days = ['SEN', 'SEL', 'RAB', 'KAM', 'JUM', 'SAB', 'MIN'];
    final months = ['JAN', 'FEB', 'MAR', 'APR', 'MEI', 'JUN', 'JUL', 'AGU', 'SEP', 'OKT', 'NOV', 'DES'];
    return "${days[dt.weekday - 1]}, ${dt.day} ${months[dt.month - 1]} ${dt.year}";
  }

  // =============================================
  // INIT VIDEO BACKGROUND (background.mp4)
  // =============================================
  void _initBgVideo() {
    _bgVideoController =
        VideoPlayerController.asset('assets/videos/background.mp4')
          ..initialize().then((_) {
            if (mounted) {
              setState(() {});
              _bgVideoController?.setLooping(true);
              _bgVideoController?.setVolume(0.0);
              _bgVideoController?.play();
            }
          }).catchError((e) {
            debugPrint("BG Video error: $e");
          });
  }

  Future<void> _initAudioService() async {
    try {
      _audioHandler = await AudioService.init(
        builder: () => MyAudioHandler(),
        config: const AudioServiceConfig(
          androidNotificationChannelId: 'com.astavvip.dashboard.audio',
          androidNotificationChannelName: 'Music Player',
          androidNotificationOngoing: true,
          androidStopForegroundOnPause: true,
        ),
      );

      if (_audioHandler != null) {
        _audioHandler!.playbackState.listen((state) {
          if (mounted) {
            setState(() {
              _spotifyPlaying = state.playing;
              _spotifyPosition = state.position;
              _spotifyPositionStr = _formatDuration(_spotifyPosition);
              if (_spotifyDuration.inSeconds > 0) {
                _spotifyProgress = _spotifyPosition.inSeconds / _spotifyDuration.inSeconds;
              }
            });
          }
          if (state.processingState == AudioProcessingState.completed) {
            _playNextSong();
          }
        });

        _audioHandler!.mediaItem.listen((item) {
          if (item != null && mounted) {
            setState(() {
              _spotifyDuration = item.duration ?? Duration.zero;
              _spotifyDurationStr = _formatDuration(_spotifyDuration);
            });
          }
        });

        _audioServiceInitialized = true;
      }
    } catch (e) {
      debugPrint("AudioService init error: $e");
      _audioServiceInitialized = false;
    }
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final hours = duration.inHours;
    final minutes = duration.inMinutes.remainder(60);
    final seconds = duration.inSeconds.remainder(60);
    if (hours > 0) {
      return "$hours:${twoDigits(minutes)}:${twoDigits(seconds)}";
    }
    return "${twoDigits(minutes)}:${twoDigits(seconds)}";
  }

  Future<void> _searchSongs(String query) async {
    if (query.trim().isEmpty) {
      setState(() {
        _spotifySearchResults = [];
        _showSearchResults = false;
        _searchError = "";
      });
      return;
    }

    setState(() {
      _isSearching = true;
      _showSearchResults = true;
      _showQueue = false;
      _searchError = "";
      _spotifySearchResults = [];
    });

    try {
      final encodedQuery = Uri.encodeComponent(query.trim());
      final url = Uri.parse(
        "https://itunes.apple.com/search?term=$encodedQuery&media=music&limit=20",
      );
      final client = http.Client();
      final response = await client.get(url).timeout(const Duration(seconds: 15));
      client.close();

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data == null || data['results'] == null) {
          if (mounted) {
            setState(() {
              _isSearching = false;
              _searchError = "Format data tidak didukung";
            });
          }
          return;
        }

        final resultsRaw = data['results'] as List;
        List<Map<String, dynamic>> songs = [];

        for (var item in resultsRaw) {
          if (item is! Map<String, dynamic>) continue;
          String imageUrl = item['artworkUrl100'] ?? "";
          if (imageUrl.isNotEmpty) {
            imageUrl = imageUrl.replaceAll("100x100", "600x600");
          }
          String downloadUrl = item['previewUrl'] ?? "";
          if (downloadUrl.isEmpty) continue;
          songs.add({
            'id': item['trackId']?.toString() ?? "",
            'title': item['trackName'] ?? "Unknown",
            'artist': item['artistName'] ?? "Unknown",
            'album': item['collectionName'] ?? "",
            'image': imageUrl,
            'url': downloadUrl,
            'duration': item['trackTimeMillis']?.toString() ?? "0",
          });
        }

        if (mounted) {
          setState(() {
            _spotifySearchResults = songs;
            _isSearching = false;
            if (songs.isEmpty) {
              _searchError = "Tidak ada lagu ditemukan";
            }
          });
        }
      } else {
        if (mounted) {
          setState(() {
            _isSearching = false;
            _searchError = "Server API error (${response.statusCode})";
          });
        }
      }
    } on SocketException {
      if (mounted) {
        setState(() {
          _isSearching = false;
          _searchError = "Tidak ada koneksi internet";
        });
      }
    } on TimeoutException {
      if (mounted) {
        setState(() {
          _isSearching = false;
          _searchError = "Koneksi lambat, coba lagi";
        });
      }
    } catch (e) {
      debugPrint("Search Error Detail: $e");
      if (mounted) {
        setState(() {
          _isSearching = false;
          _searchError = "Terjadi kesalahan sistem";
        });
      }
    }
  }

  Future<void> _playSong(Map<String, dynamic> song) async {
    setState(() {
      _spotifyLoading = true;
      _currentPlayingSong = song;
      _currentSongTitle = song['title'] ?? "Unknown";
      _currentSongArtist = song['artist'] ?? "Unknown";
      _currentSongImage = song['image'] ?? "";
      _currentSongAlbum = song['album'] ?? "";
      _spotifyProgress = 0.0;
      _spotifyPosition = Duration.zero;
      _spotifyDuration = Duration.zero;
      _spotifyPositionStr = "0:00";
      _spotifyDurationStr = "0:00";
    });
    bg.AudioService().pause();

    try {
      String url = song['url']?.toString() ?? "";
      if (url.isEmpty) {
        if (mounted) {
          setState(() {
            _spotifyLoading = false;
          });
        }
        bg.AudioService().resume();
        return;
      }

      if (_audioServiceInitialized && _audioHandler != null) {
        await _audioHandler!.playFromUrl(
          url,
          title: song['title'] ?? 'Unknown',
          artist: song['artist'] ?? 'Unknown',
          album: song['album'] ?? '',
          artUri: song['image'] ?? '',
        );
      }

      if (mounted) {
        setState(() {
          _spotifyLoading = false;
        });
      }
    } catch (e) {
      debugPrint("Play Error: $e");
      if (mounted) {
        setState(() {
          _spotifyLoading = false;
          _spotifyPlaying = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Gagal memutar lagu"),
            backgroundColor: tp.accent,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    }
  }

  void _addToQueue(Map<String, dynamic> song) {
    setState(() {
      _spotifyQueue.add(song);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Ditambahkan ke queue: ${song['title']}"),
        backgroundColor: _spotifyGreen.withOpacity(0.8),
        duration: const Duration(seconds: 1),
      ),
    );
  }

  void _playNextSong() {
    if (_spotifyQueue.isNotEmpty) {
      final nextSong = _spotifyQueue.removeAt(0);
      _playSong(nextSong);
    } else {
      setState(() {
        _spotifyPlaying = false;
        _spotifyProgress = 0.0;
      });
    }
  }

  void _playPreviousSong() {
    if (_spotifyPosition.inSeconds > 3) {
      _audioHandler?.seekToPosition(Duration.zero);
    }
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  void _initMenuVideo() {
    _menuVideoController =
        VideoPlayerController.asset('assets/videos/banner.mp4')
          ..initialize().then((_) {
            if (mounted) {
              setState(() {});
              _menuVideoController?.setLooping(true);
              _menuVideoController?.setVolume(0.0);
              _menuVideoController?.play();
            }
          }).catchError((e) {
            debugPrint("Menu Video error: $e");
          });
  }

  void _initBannerVideo() {
    _bannerVideoController =
        VideoPlayerController.asset('assets/videos/banner.mp4')
          ..initialize().then((_) {
            if (mounted) {
              setState(() {});
              _bannerVideoController?.setLooping(true);
              _bannerVideoController?.setVolume(0.0);
              _bannerVideoController?.play();
            }
          }).catchError((e) {
            debugPrint("Banner Video error: $e");
          });
  }

  void _calculateAccountStats() {
    try {
      final now = DateTime.now();
      final expired = DateTime.parse(expiredDate);
      final difference = expired.difference(now);
      if (difference.inDays <= 0) {
        _isAccountExpired = true;
        _accountStatus = "EXPIRED";
        _accountDaysLeft = 0;
        _accountProgress = 0.0;
      } else {
        _isAccountExpired = false;
        _accountDaysLeft = difference.inDays;
        final totalDays = 30;
        _accountProgress = (_accountDaysLeft / totalDays).clamp(0.0, 1.0);
        if (_accountDaysLeft <= 3) {
          _accountStatus = "CRITICAL";
        } else if (_accountDaysLeft <= 7) {
          _accountStatus = "WARNING";
        } else {
          _accountStatus = "ACTIVE";
        }
      }
    } catch (e) {
      _accountStatus = "UNKNOWN";
      _accountDaysLeft = 0;
      _accountProgress = 0.0;
    }
  }

  Future<void> _fetchDeviceStats() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    final battery = Battery();
    final batLevel = await battery.batteryLevel;
    final batState = await battery.batteryState;
    String stateString = "Unknown";
    if (batState == BatteryState.charging) {
      stateString = "Charging";
    } else if (batState == BatteryState.discharging) {
      stateString = "Discharging";
    } else if (batState == BatteryState.full) {
      stateString = "Full";
    }
    setState(() {
      deviceModel = "${deviceInfo.brand} ${deviceInfo.model}";
      osVersion = "Android ${deviceInfo.version.release}";
      sdkInt = deviceInfo.version.sdkInt;
      batteryLevel = batLevel;
      batteryState = stateString;
      _networkType = "WiFi";
      _signalStrength = 85;
      _totalRamMb = 4096;
      _usedRamMb = 2340;
      _totalStorageGb = 128;
      _freeStorageGb = 42;
      _deviceUptime = DateTime.now().millisecondsSinceEpoch / 1000;
    });
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  Future<void> _initLocationBasedFeatures() async {
    bool serviceEnabled;
    LocationPermission permission;
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      setState(() {
        isLoadingWeather = false;
        weatherErrorMsg = "GPS tidak aktif";
        _isLoadingPrayer = false;
        _prayerError = "GPS tidak aktif";
      });
      return;
    }
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        setState(() {
          isLoadingWeather = false;
          weatherErrorMsg = "Izin lokasi ditolak";
          _isLoadingPrayer = false;
          _prayerError = "Izin lokasi ditolak";
        });
        return;
      }
    }
    if (permission == LocationPermission.deniedForever) {
      setState(() {
        isLoadingWeather = false;
        weatherErrorMsg = "Izin lokasi ditolak permanen";
        _isLoadingPrayer = false;
        _prayerError = "Izin lokasi ditolak permanen";
      });
      return;
    }
    try {
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
      );
      _fetchWeather(position.latitude, position.longitude);
      _fetchPrayerTimes(position.latitude, position.longitude);
    } catch (e) {
      setState(() {
        isLoadingWeather = false;
        weatherErrorMsg = "Gagal mendapatkan lokasi";
        _isLoadingPrayer = false;
        _prayerError = "Gagal mendapatkan lokasi";
      });
    }
  }

  Future<void> _fetchWeather(double lat, double lon) async {
    try {
      final String apiKey = "68296d0a3a5d6ee2b5cb993918d19ef9";
      final url = Uri.parse(
        "https://api.openweathermap.org/data/2.5/weather?lat=$lat&lon=$lon&appid=$apiKey&units=metric",
      );
      final response = await http.get(url);
      if (response.statusCode == 200) {
        setState(() {
          weatherData = jsonDecode(response.body);
          isLoadingWeather = false;
        });
      } else {
        setState(() {
          isLoadingWeather = false;
          weatherErrorMsg = "Gagal load data cuaca";
        });
      }
    } catch (e) {
      setState(() {
        isLoadingWeather = false;
        weatherErrorMsg = "Terjadi kesalahan";
      });
    }
  }

  bool _isLoadingPrayer = true;
  String _prayerError = "";
  String _prayerLocationName = "Mendeteksi...";
  Map<String, String> _prayerTimes = {};

  Timer? _prayerCountdownTimer;
  String _nextPrayerName = "-";
  String _nextPrayerTimeStr = "-";
  String _countdownText = "--:--:--";

  Future<void> _fetchPrayerTimes(double lat, double lon) async {
    try {
      final now = DateTime.now();
      final url = Uri.parse(
        "http://api.aladhan.com/v1/timings/${now.day}-${now.month}-${now.year}?latitude=$lat&longitude=$lon&method=20",
      );
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['code'] == 200) {
          final timings = data['data']['timings'];
          final meta = data['data']['meta'];
          setState(() {
            _prayerLocationName = "${meta['timezone']}";
            _prayerTimes = {
              "Imsak": timings['Imsak'] ?? '-',
              "Subuh": timings['Fajr'] ?? '-',
              "Terbit": timings['Sunrise'] ?? '-',
              "Dzuhur": timings['Dhuhr'] ?? '-',
              "Ashar": timings['Asr'] ?? '-',
              "Maghrib": timings['Maghrib'] ?? '-',
              "Isya": timings['Isha'] ?? '-',
            };
            _isLoadingPrayer = false;
          });
          _calculateAndStartPrayerCountdown();
        } else {
          setState(() {
            _isLoadingPrayer = false;
            _prayerError = "Gagal memuat jadwal";
          });
        }
      } else {
        setState(() {
          _isLoadingPrayer = false;
          _prayerError = "Gagal memuat jadwal";
        });
      }
    } catch (e) {
      setState(() {
        _isLoadingPrayer = false;
        _prayerError = "Terjadi kesalahan jaringan";
      });
    }
  }

  void _calculateAndStartPrayerCountdown() {
    _prayerCountdownTimer?.cancel();
    final now = DateTime.now();
    DateTime? nextPrayer;
    String foundName = "";
    String foundTimeStr = "";
    final order = ["Imsak", "Subuh", "Terbit", "Dzuhur", "Ashar", "Maghrib", "Isya"];
    for (String prayer in order) {
      final timeStr = _prayerTimes[prayer];
      if (timeStr == null || timeStr == '-') continue;
      final parts = timeStr.split(':');
      if (parts.length < 2) continue;
      final hour = int.tryParse(parts[0]);
      final minute = int.tryParse(parts[1]);
      if (hour == null || minute == null) continue;
      final prayerTime = DateTime(now.year, now.month, now.day, hour, minute);
      if (prayerTime.isAfter(now)) {
        nextPrayer = prayerTime;
        foundName = prayer;
        foundTimeStr = "${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}";
        break;
      }
    }
    if (nextPrayer == null) {
      final imsakStr = _prayerTimes["Imsak"];
      if (imsakStr != null && imsakStr != '-') {
        final parts = imsakStr.split(':');
        if (parts.length >= 2) {
          final hour = int.tryParse(parts[0]) ?? 0;
          final minute = int.tryParse(parts[1]) ?? 0;
          nextPrayer = DateTime(now.year, now.month, now.day + 1, hour, minute);
          foundName = "Imsak (Besok)";
          foundTimeStr = "${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}";
        }
      }
    }
    if (nextPrayer != null) {
      setState(() {
        _nextPrayerName = foundName;
        _nextPrayerTimeStr = foundTimeStr;
      });
      _prayerCountdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
        if (!mounted || nextPrayer == null) {
          timer.cancel();
          return;
        }
        final nowTimer = DateTime.now();
        final diff = nextPrayer!.difference(nowTimer);
        if (diff.isNegative) {
          timer.cancel();
          _calculateAndStartPrayerCountdown();
        } else {
          final hours = diff.inHours.toString().padLeft(2, '0');
          final minutes = (diff.inMinutes % 60).toString().padLeft(2, '0');
          final seconds = (diff.inSeconds % 60).toString().padLeft(2, '0');
          if (mounted) {
            setState(() {
              _countdownText = "$hours:$minutes:$seconds";
            });
          }
        }
      });
    }
  }

  Future<void> _fetchRssNewsForTab(int tabIndex) async {
    if (_newsTabData.containsKey(tabIndex)) return;
    setState(() {
      _newsTabLoading[tabIndex] = true;
      _newsTabError[tabIndex] = "";
    });
    try {
      final url = Uri.parse(_newsTabs[tabIndex]['url']!);
      final response = await http.get(url).timeout(
        const Duration(seconds: 15),
        onTimeout: () => http.Response('Timeout', 408),
      );
      if (response.statusCode == 200) {
        final document = xml.XmlDocument.parse(response.body);
        final items = document.findAllElements('item');
        List<Map<String, dynamic>> tempNews = [];
        for (var item in items) {
          if (tempNews.length >= 10) break;
          final title = item.findElements('title').singleOrNull?.innerText ?? '';
          final pubDate = item.findElements('pubDate').singleOrNull?.innerText ?? '';
          final description = item.findElements('description').singleOrNull?.innerText ?? '';
          final link = item.findElements('link').singleOrNull?.innerText ?? '';
          final enclosure = item.findElements('enclosure').singleOrNull;
          String imageUrl = '';
          if (enclosure != null) {
            imageUrl = enclosure.getAttribute('url') ?? '';
          }
          if (imageUrl.isEmpty && description.contains('src="')) {
            final match = RegExp(r'src="(.*?)"').firstMatch(description);
            if (match != null) imageUrl = match.group(1) ?? '';
          }
          final cleanDesc = description
              .replaceAll(RegExp(r'<[^>]*>'), '')
              .replaceAll('&nbsp;', ' ')
              .trim();
          tempNews.add({
            'title': title,
            'pubDate': pubDate,
            'description': cleanDesc,
            'imageUrl': imageUrl,
            'link': link,
          });
        }
        if (mounted) {
          setState(() {
            _newsTabData[tabIndex] = tempNews;
            _newsTabLoading[tabIndex] = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            _newsTabError[tabIndex] = "Server berita sedang down";
            _newsTabLoading[tabIndex] = false;
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _newsTabError[tabIndex] = "Gagal memuat berita";
          _newsTabLoading[tabIndex] = false;
        });
      }
    }
  }

  void _onNewsTabChanged(int newIndex) {
    setState(() {
      _selectedNewsTab = newIndex;
    });
    _fetchRssNewsForTab(newIndex);
  }

  void _startThanksToAutoSlider() {
    Future.delayed(const Duration(seconds: 4), () {
      if (mounted) {
        setState(() {
          _currentThanksIndex = (_currentThanksIndex + 1) % thanksToList.length;
        });
        _startThanksToAutoSlider();
      }
    });
  }

  IconData _getWeatherIcon(String condition) {
    final cond = condition.toLowerCase();
    if (cond.contains('clear')) return FontAwesomeIcons.sun;
    if (cond.contains('clouds')) return FontAwesomeIcons.cloud;
    if (cond.contains('rain') || cond.contains('drizzle')) return FontAwesomeIcons.cloudRain;
    if (cond.contains('thunderstorm')) return FontAwesomeIcons.cloudBolt;
    if (cond.contains('snow')) return FontAwesomeIcons.snowflake;
    if (cond.contains('mist') || cond.contains('fog') || cond.contains('haze')) return FontAwesomeIcons.smog;
    return FontAwesomeIcons.cloudSun;
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case "ACTIVE":
        return _neonGreen;
      case "WARNING":
        return _neonOrange;
      case "CRITICAL":
        return tp.accent;
      case "EXPIRED":
        return Colors.red.shade700;
      default:
        return _textSecondary;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status) {
      case "ACTIVE":
        return Icons.check_circle_rounded;
      case "WARNING":
        return Icons.warning_rounded;
      case "CRITICAL":
        return Icons.error_rounded;
      case "EXPIRED":
        return Icons.cancel_rounded;
      default:
        return Icons.help_rounded;
    }
  }

  void _connectToWebSocket() {
    try {
      channel = WebSocketChannel.connect(
        Uri.parse('wss://ws-host.astavvip-tech.xyz:2595'),
      );
      channel.sink.add(jsonEncode({
        "type": "validate",
        "key": sessionKey,
        "androidId": androidId,
      }));
      channel.sink.add(jsonEncode({"type": "stats"}));
      channel.stream.listen((event) {
        final data = jsonDecode(event);
        if (data['type'] == 'myInfo') {
          if (data['valid'] == false) {
            if (data['reason'] == 'androidIdMismatch') {
              _handleInvalidSession("Your account has logged on another device.");
            } else if (data['reason'] == 'keyInvalid') {
              _handleInvalidSession("Key is not valid. Please login again.");
            }
          }
        }
        if (data['type'] == 'stats') {
          setState(() {
            onlineUsers = data['onlineUsers'] ?? 0;
            activeConnections = data['activeConnections'] ?? 0;
          });
        }
      });
    } catch (e) {
      debugPrint("WS Connection Error: $e");
    }
  }

  // ========== BROADCAST RECEIVER METHODS ==========
  void _connectBroadcast() {
    final url = _broadcastUrlController.text.trim();
    if (url.isEmpty) return;
    _disconnectBroadcast();

    try {
      _broadcastChannel = WebSocketChannel.connect(Uri.parse(url));
      setState(() {
        _isBroadcastConnected = true;
        _broadcastMessages.clear();
      });

      _broadcastChannel!.stream.listen(
        (dynamic data) {
          try {
            final Map<String, dynamic> json =
                Map<String, dynamic>.from(data is String ? jsonDecode(data) : data);
            final msg = json['message'] ?? 'No message';
            final time = json['timestamp'] != null
                ? DateTime.parse(json['timestamp']).toLocal().toString()
                : DateTime.now().toLocal().toString();
            if (mounted) {
              setState(() {
                _broadcastMessages.insert(0, {'message': msg, 'time': time});
              });
            }
          } catch (e) {
            if (mounted) {
              setState(() {
                _broadcastMessages.insert(0, {
                  'message': data.toString(),
                  'time': DateTime.now().toLocal().toString(),
                });
              });
            }
          }
        },
        onDone: () {
          if (mounted) {
            setState(() {
              _isBroadcastConnected = false;
            });
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Koneksi Broadcast terputus')),
            );
          }
        },
        onError: (err) {
          if (mounted) {
            setState(() {
              _isBroadcastConnected = false;
            });
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Broadcast Error: $err')),
            );
          }
        },
      );
    } catch (e) {
      setState(() {
        _isBroadcastConnected = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal koneksi broadcast: $e')),
      );
    }
  }

  void _disconnectBroadcast() {
    if (_broadcastChannel != null) {
      _broadcastChannel!.sink.close();
      _broadcastChannel = null;
    }
    if (mounted && _isBroadcastConnected) {
      setState(() {
        _isBroadcastConnected = false;
      });
    }
  }

  void _showBroadcastDialog() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => StatefulBuilder(
        builder: (context, setSheetState) {
          return Container(
            height: MediaQuery.of(context).size.height * 0.7,
            margin: EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: tp.bg,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _neonCyan.withOpacity(0.3), width: 1),
            ),
            child: Column(
              children: [
                // Header
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(color: _neonCyan.withOpacity(0.1)),
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(FontAwesomeIcons.broadcastTower, color: _neonCyan, size: 18),
                      const SizedBox(width: 10),
                      const Text(
                        'BROADCAST RECEIVER',
                        style: TextStyle(
                          color: _neonCyan,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        icon: const Icon(Icons.close, color: _textSecondary, size: 20),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                ),
                // Input URL dan tombol connect
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _broadcastUrlController,
                          enabled: !_isBroadcastConnected,
                          style: const TextStyle(color: _textPrimary, fontSize: 11),
                          decoration: InputDecoration(
                            labelText: 'WebSocket URL',
                            labelStyle: const TextStyle(color: _textSecondary, fontSize: 9),
                            hintText: 'ws://ip:port',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(color: _neonCyan.withOpacity(0.2)),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(color: _neonCyan.withOpacity(0.2)),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(color: _neonCyan.withOpacity(0.6)),
                            ),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      if (!_isBroadcastConnected)
                        ElevatedButton.icon(
                          onPressed: () {
                            _connectBroadcast();
                            setSheetState(() {});
                          },
                          icon: const Icon(Icons.wifi, size: 12),
                          label: const Text('HUBUNG', style: TextStyle(fontSize: 9)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _neonCyan,
                            foregroundColor: Colors.black,
                            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          ),
                        )
                      else
                        ElevatedButton.icon(
                          onPressed: () {
                            _disconnectBroadcast();
                            setSheetState(() {});
                          },
                          icon: Icon(Icons.close, size: 12),
                          label: Text('PUTUS', style: TextStyle(fontSize: 9)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: tp.accent.withOpacity(0.2),
                            foregroundColor: tp.accent,
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          ),
                        ),
                    ],
                  ),
                ),
                // Status koneksi
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 12),
                  child: Row(
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _isBroadcastConnected ? _neonGreen : tp.accent,
                        ),
                      ),
                      SizedBox(width: 6),
                      Text(
                        _isBroadcastConnected ? 'TERHUBUNG' : 'TERPUTUS',
                        style: TextStyle(
                          color: _isBroadcastConnected ? _neonGreen : tp.accent,
                          fontSize: 8,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                      const Spacer(),
                      Text(
                        '${_broadcastMessages.length} pesan',
                        style: const TextStyle(color: _textSecondary, fontSize: 8),
                      ),
                    ],
                  ),
                ),
                const Divider(color: _textSecondary, height: 16),
                // Daftar pesan broadcast
                Expanded(
                  child: _broadcastMessages.isEmpty
                      ? const Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(FontAwesomeIcons.broadcastTower, color: _textSecondary, size: 32),
                              SizedBox(height: 12),
                              Text(
                                'Belum ada pesan broadcast',
                                style: TextStyle(color: _textSecondary, fontSize: 10),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          reverse: true,
                          padding: EdgeInsets.symmetric(horizontal: 12),
                          itemCount: _broadcastMessages.length,
                          itemBuilder: (ctx, i) {
                            final item = _broadcastMessages[i];
                            return Card(
                              margin: EdgeInsets.only(bottom: 8),
                              color: tp.card,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                                side: BorderSide(color: _neonCyan.withOpacity(0.1)),
                              ),
                              child: ListTile(
                                leading: const Icon(Icons.mic, color: _neonCyan, size: 16),
                                title: Text(
                                  item['message']!,
                                  style: const TextStyle(
                                    color: _textPrimary,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                subtitle: Text(
                                  item['time']!,
                                  style: const TextStyle(color: _textSecondary, fontSize: 8),
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: Color(0xFF180A0E),
        shape: RoundedRectangleBorder(
          side: BorderSide(color: tp.accent, width: 1),
          borderRadius: BorderRadius.circular(12),
        ),
        title: Text(
          "Session Expired",
          style: TextStyle(color: _textPrimary, fontFamily: 'Orbitron'),
        ),
        content: Text(
          message,
          style: TextStyle(color: _textSecondary, fontFamily: 'Orbitron'),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => LoginPage()),
                (route) => false,
              );
            },
            child: Text(
              "OK",
              style: TextStyle(
                color: tp.accent,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _onBottomNavTapped(int index) {
    setState(() {
      _bottomNavIndex = index;
    });
    _pageController.jumpToPage(index);
    final bgAudio = bg.AudioService();
    if (bgAudio.isEnabled) {
      if (index == 0 || index == 1 || index == 5) {
        bgAudio.resume();
      } else {
        bgAudio.pause();
      }
    }
  }

  void _onSidebarTabSelected(int index) {
    if (index == 1) {
      Navigator.pop(context);
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => SellerPage(keyToken: sessionKey)),
      );
    } else if (index == 2) {
      Navigator.pop(context);
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => AdminPage(sessionKey: sessionKey)),
      );
    } else if (index == 3) {
      Navigator.pop(context);
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => OwnerPage(sessionKey: sessionKey, username: username),
        ),
      );
    }
  }

  Color _getActiveNeon(int index) {
    switch (index) {
      case 0: return tp.accent;
      case 1: return _neonCyan;
      case 2: return _neonPurple;
      case 3: return _neonGreen;
      case 4: return _neonPink;
      case 5: return _neonOrange;
      default: return tp.accent;
    }
  }

  Color _getActiveBg(int index) {
    switch (index) {
      case 0: return tp.bg;
      case 1: return _bgCyan;
      case 2: return _bgPurple;
      case 3: return _bgGreen;
      case 4: return _bgPink;
      case 5: return _bgOrange;
      default: return tp.bg;
    }
  }

  void _showMusicOptionsSheet(BuildContext context, Color activeNeon) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) {
        return Container(
          margin: const EdgeInsets.fromLTRB(12, 0, 12, 16),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: const Color(0xFF0A0A0F),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: activeNeon.withOpacity(0.25), width: 1),
            boxShadow: [
              BoxShadow(
                color: activeNeon.withOpacity(0.15),
                blurRadius: 30,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(bottom: 20),
                decoration: BoxDecoration(
                  color: activeNeon.withOpacity(0.4),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: activeNeon.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: activeNeon.withOpacity(0.3)),
                    ),
                    child: Icon(FontAwesomeIcons.music, color: activeNeon, size: 16),
                  ),
                  const SizedBox(width: 14),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'MUSIC PLAYER',
                        style: TextStyle(
                          color: activeNeon,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.5,
                        ),
                      ),
                      Text(
                        _currentPlayingSong != null
                            ? (_spotifyPlaying ? '\u25B6 $_currentSongTitle' : '\u23F8 $_currentSongTitle')
                            : 'Tidak ada lagu yang diputar',
                        style: TextStyle(
                          color: _currentPlayingSong != null
                              ? (_spotifyPlaying ? _spotifyGreen : Colors.grey)
                              : Colors.grey,
                          fontSize: 11,
                          fontFamily: 'Orbitron',
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 20),
              _buildMusicOption(
                icon: FontAwesomeIcons.list,
                label: 'Buka Music Player',
                subtitle: 'Cari & putar lagu favorit kamu',
                color: activeNeon,
                onTap: () {
                  Navigator.pop(context);
                  setState(() {
                    _bottomNavIndex = 4;
                  });
                  _pageController.jumpToPage(4);
                },
              ),
              const SizedBox(height: 10),
              _buildMusicOption(
                icon: FontAwesomeIcons.compactDisc,
                label: 'Now Playing',
                subtitle: _currentPlayingSong != null ? _currentSongTitle : 'Belum ada lagu yang diputar',
                color: _spotifyGreen,
                onTap: () {
                  Navigator.pop(context);
                  setState(() {
                    _bottomNavIndex = 0;
                    _selectedWidgetIndex = 3;
                  });
                  _pageController.jumpToPage(0);
                },
              ),
              const SizedBox(height: 10),
              if (_currentPlayingSong != null) ...[
                _buildMusicOption(
                  icon: _spotifyPlaying ? FontAwesomeIcons.pause : FontAwesomeIcons.play,
                  label: _spotifyPlaying ? 'Pause' : 'Play',
                  subtitle: _spotifyPlaying ? 'Jeda lagu saat ini' : 'Lanjutkan lagu',
                  color: Colors.orangeAccent,
                  onTap: () {
                    Navigator.pop(context);
                    if (_spotifyPlaying) {
                      _audioHandler?.pausePlayback();
                      bg.AudioService().resume();
                    } else {
                      _audioHandler?.resumePlayback();
                      bg.AudioService().pause();
                    }
                  },
                ),
                const SizedBox(height: 10),
              ],
              const SizedBox(height: 4),
            ],
          ),
        );
      },
    );
  }

  Widget _buildMusicOption({
    required IconData icon,
    required String label,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.2), width: 1),
        ),
        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: color, size: 15),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      color: Colors.white54,
                      fontSize: 10,
                      fontFamily: 'Orbitron',
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right_rounded, color: color.withOpacity(0.5), size: 18),
          ],
        ),
      ),
    );
  }

  Widget _buildMiniNowPlaying(Color activeNeon) {
    if (_currentPlayingSong == null) {
      return const SizedBox.shrink();
    }

    return GestureDetector(
      onTap: () {
        setState(() {
          _bottomNavIndex = 0;
          _selectedWidgetIndex = 3;
        });
        _pageController.jumpToPage(0);
      },
      child: Container(
        margin: EdgeInsets.only(right: 4),
        padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: tp.bg.withOpacity(0.7),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: _spotifyGreen.withOpacity(0.4),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: _spotifyGreen.withOpacity(0.1),
              blurRadius: 8,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                border: Border.all(
                  color: _spotifyGreen.withOpacity(0.3),
                  width: 1,
                ),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(3),
                child: _currentSongImage.isNotEmpty
                    ? Image.network(
                        _currentSongImage,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: tp.bg,
                          child: Icon(
                            FontAwesomeIcons.music,
                            color: _spotifyGreen.withOpacity(0.5),
                            size: 10,
                          ),
                        ),
                      )
                    : Container(
                        color: tp.bg,
                        child: Icon(
                          FontAwesomeIcons.music,
                          color: _spotifyGreen.withOpacity(0.5),
                          size: 10,
                        ),
                      ),
              ),
            ),
            const SizedBox(width: 6),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  _currentSongTitle,
                  style: const TextStyle(
                    color: _neonWhite,
                    fontSize: 7,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 1),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (_spotifyPlaying)
                      Container(
                        width: 4,
                        height: 4,
                        margin: const EdgeInsets.only(right: 3),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _spotifyGreen,
                          boxShadow: [
                            BoxShadow(
                              color: _spotifyGreen.withOpacity(0.6),
                              blurRadius: 3,
                            ),
                          ],
                        ),
                      ),
                    Text(
                      _spotifyPlaying ? "Playing" : "Paused",
                      style: TextStyle(
                        color: _spotifyPlaying ? _spotifyGreen : _textSecondary,
                        fontSize: 5,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(width: 4),
            SizedBox(
              width: 20,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(1),
                    child: LinearProgressIndicator(
                      value: _spotifyProgress.clamp(0.0, 1.0),
                      minHeight: 2,
                      backgroundColor: _spotifyGreen.withOpacity(0.15),
                      valueColor: const AlwaysStoppedAnimation<Color>(_spotifyGreen),
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    _spotifyPositionStr,
                    style: TextStyle(
                      color: _textSecondary.withOpacity(0.6),
                      fontSize: 4,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final activeNeon = _getActiveNeon(_bottomNavIndex);

    return Theme(
      data: ThemeData(
        fontFamily: 'Orbitron',
        scaffoldBackgroundColor: tp.bg,
        textTheme: Theme.of(context).textTheme.apply(fontFamily: 'Orbitron'),
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.transparent,
          elevation: 0,
          iconTheme: IconThemeData(color: activeNeon),
          titleTextStyle: TextStyle(
            color: _textPrimary,
            fontSize: 14,
            fontWeight: FontWeight.w600,
            fontFamily: 'Orbitron',
          ),
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          title: Text(username),
          centerTitle: true,
          leading: Builder(
            builder: (context) => IconButton(
              icon: Icon(Icons.menu_rounded, color: activeNeon, size: 20),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
          actions: [
            _buildMiniNowPlaying(activeNeon),
            // ========== BROADCAST TOOL (ICON) ==========
            IconButton(
              icon: Icon(FontAwesomeIcons.broadcastTower, color: activeNeon, size: 16),
              onPressed: _showBroadcastDialog,
              tooltip: 'Broadcast Receiver',
            ),
            IconButton(
              icon: Icon(
                _isBgMusicOn ? FontAwesomeIcons.music : FontAwesomeIcons.volumeXmark,
                color: _isBgMusicOn ? activeNeon : Colors.grey,
                size: 16,
              ),
              onPressed: () async {
                final newVal = !_isBgMusicOn;
                setState(() {
                  _isBgMusicOn = newVal;
                });
                await bg.AudioService().setEnabled(newVal);
              },
            ),
            IconButton(
              icon: Icon(FontAwesomeIcons.headset, color: activeNeon, size: 16),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ContactPage()),
                );
              },
            ),
            IconButton(
              icon: Icon(FontAwesomeIcons.userCircle, color: activeNeon, size: 18),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ProfilePage(
                      username: username,
                      password: password,
                      role: role,
                      expiredDate: expiredDate,
                      sessionKey: sessionKey,
                    ),
                  ),
                );
              },
            ),
          ],
        ),
        drawer: _buildCustomDrawer(activeNeon),
        body: Stack(
          fit: StackFit.expand,
          children: [
            // =============================================
            // BACKGROUND VIDEO (background.mp4)
            // =============================================
            _buildVideoBackground(),
            // Dark overlay agar konten terbaca jelas
            Container(color: Colors.black.withOpacity(0.65)),
            // Konten utama
            FadeTransition(
              opacity: _animation,
              child: PageView.builder(
                controller: _pageController,
                physics: const BouncingScrollPhysics(),
                itemCount: 6,
                onPageChanged: (index) {
                  setState(() {
                    _bottomNavIndex = index;
                  });
                  final bgAudio = bg.AudioService();
                  if (bgAudio.isEnabled) {
                    if (index == 0 || index == 1 || index == 5) {
                      bgAudio.resume();
                    } else {
                      bgAudio.pause();
                    }
                  }
                },
                itemBuilder: (context, index) {
                  return _buildPageContent(index);
                },
              ),
            ),
          ],
        ),
        extendBody: true,
        bottomNavigationBar: _buildBottomNavBar(activeNeon),
      ),
    );
  }

  // =============================================
  // VIDEO BACKGROUND BUILDER
  // =============================================
  Widget _buildVideoBackground() {
    if (_bgVideoController != null && _bgVideoController!.value.isInitialized) {
      return SizedBox.expand(
        child: FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: _bgVideoController!.value.size.width,
            height: _bgVideoController!.value.size.height,
            child: VideoPlayer(_bgVideoController!),
          ),
        ),
      );
    } else {
      return Container(
        color: tp.bg,
        child: Center(
          child: SizedBox(
            width: 18,
            height: 18,
            child: CircularProgressIndicator(
              color: tp.accent,
              strokeWidth: 2,
            ),
          ),
        ),
      );
    }
  }

  Widget _buildPageContent(int index) {
    switch (index) {
      case 0: return _buildMainFeedPage();
      case 1:
        return HomePage(
          username: username,
          password: password,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
      case 2: return InfoPage(sessionKey: sessionKey);
      case 3:
        return DeviceDashboardPage(
          username: username,
          role: role,
          sessionKey: sessionKey,
        );
      case 4: return const MusikPage();
      case 5:
        return ToolsPage(
          sessionKey: sessionKey,
          userRole: role,
          listDoos: listDoos,
        );
      default: return _buildMainFeedPage();
    }
  }

  Widget _buildMainFeedPage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(10, 72, 10, 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildBannerVideoWidget(),
          const SizedBox(height: 10),
          _buildUnifiedStatsCard(),
          const SizedBox(height: 10),
          _buildMotivationCard(),
          const SizedBox(height: 10),
          _buildWidgetSelector(),
          SizedBox(height: 10),
          _buildSelectedWidgetContent(),
          SizedBox(height: 10),
          _buildQuickNoteCard(),
          SizedBox(height: 10),
          _buildActionGrid(),
          SizedBox(height: 10),
          _buildThanksToWidget(),
        ],
      ),
    );
  }

  Widget _buildBannerVideoWidget() {
    return Container(
      height: 110,
      width: double.infinity,
      decoration: BoxDecoration(
        color: tp.bg.withOpacity(0.6),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: tp.accent.withOpacity(0.2), width: 1),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_bannerVideoController != null && _bannerVideoController!.value.isInitialized)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bannerVideoController!.value.size.width,
                  height: _bannerVideoController!.value.size.height,
                  child: VideoPlayer(_bannerVideoController!),
                ),
              )
            else
              Container(
                color: tp.bg,
                child: Center(
                  child: SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      color: tp.accent,
                      strokeWidth: 2,
                    ),
                  ),
                ),
              ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.black.withOpacity(0.2),
                    Colors.black.withOpacity(0.8),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
            Positioned(
              bottom: 8,
              left: 10,
              right: 10,
              child: Row(
                children: [
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: tp.accent.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(color: tp.accent.withOpacity(0.5), width: 1),
                    ),
                    child: Text(
                      "LIVE",
                      style: TextStyle(
                        color: tp.accent,
                        fontSize: 7,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ),
                  SizedBox(width: 6),
                  Text(
                    "WELCOME BACK",
                    style: TextStyle(
                      color: _textPrimary,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                  Spacer(),
                  Text(
                    username,
                    style: TextStyle(
                      color: tp.accent.withOpacity(0.8),
                      fontSize: 8,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUnifiedStatsCard() {
    final statusColor = _getStatusColor(_accountStatus);
    final statusIcon = _getStatusIcon(_accountStatus);
    final ramPercent = _totalRamMb > 0 ? (_usedRamMb / _totalRamMb * 100).clamp(0.0, 100.0) : 0.0;
    final storagePercent = _totalStorageGb > 0 ? ((_totalStorageGb - _freeStorageGb) / _totalStorageGb * 100).clamp(0.0, 100.0) : 0.0;

    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: tp.card.withOpacity(0.7),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: statusColor.withOpacity(0.2), width: 1),
        boxShadow: [
          BoxShadow(
            color: statusColor.withOpacity(0.05),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.dashboard_rounded, color: statusColor, size: 14),
                  const SizedBox(width: 6),
                  const Text(
                    "DASHBOARD",
                    style: TextStyle(
                      color: _textPrimary,
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: statusColor.withOpacity(0.35), width: 1),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(statusIcon, color: statusColor, size: 9),
                    const SizedBox(width: 4),
                    Text(
                      _accountStatus,
                      style: TextStyle(
                        color: statusColor,
                        fontSize: 7,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Remaining Time",
                style: TextStyle(
                  color: _textSecondary.withOpacity(0.8),
                  fontSize: 7,
                  fontFamily: 'Orbitron',
                ),
              ),
              Text(
                "$_accountDaysLeft Days Left",
                style: TextStyle(
                  color: statusColor,
                  fontSize: 7,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          ),
          SizedBox(height: 5),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: _accountProgress,
              minHeight: 4,
              backgroundColor: tp.bg.withOpacity(0.5),
              valueColor: AlwaysStoppedAnimation<Color>(statusColor),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _unifiedStatChip(
                  icon: FontAwesomeIcons.crown,
                  label: "ROLE",
                  value: role.toUpperCase(),
                  color: _neonOrange,
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: _unifiedStatChip(
                  icon: FontAwesomeIcons.calendarAlt,
                  label: "EXPIRED",
                  value: _formatDate(expiredDate),
                  color: _neonCyan,
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: _unifiedStatChip(
                  icon: FontAwesomeIcons.users,
                  label: "ONLINE",
                  value: "$onlineUsers Users",
                  color: _neonGreen,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Expanded(
                child: _unifiedStatChip(
                  icon: Icons.devices_rounded,
                  label: "DEVICE",
                  value: deviceModel.length > 14 ? "${deviceModel.substring(0, 14)}..." : deviceModel,
                  color: _neonPurple,
                ),
              ),
              SizedBox(width: 6),
              Expanded(
                child: _unifiedStatChip(
                  icon: Icons.battery_full_rounded,
                  label: "BATTERY",
                  value: "$batteryLevel% $batteryState",
                  color: batteryLevel > 20 ? _neonGreen : tp.accent,
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: _unifiedStatChip(
                  icon: Icons.wifi_rounded,
                  label: "NETWORK",
                  value: "$_networkType $_signalStrength%",
                  color: _neonBlue,
                ),
              ),
            ],
          ),
          SizedBox(height: 6),
          Row(
            children: [
              Expanded(
                child: _unifiedStatChip(
                  icon: Icons.memory_rounded,
                  label: "RAM",
                  value: "${_usedRamMb}MB / ${_totalRamMb}MB",
                  color: ramPercent > 80 ? tp.accent : _neonPink,
                  showProgress: true,
                  progressValue: ramPercent / 100,
                  progressColor: ramPercent > 80 ? tp.accent : _neonPink,
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: _unifiedStatChip(
                  icon: Icons.storage_rounded,
                  label: "STORAGE",
                  value: "${_totalStorageGb - _freeStorageGb}GB / ${_totalStorageGb}GB",
                  color: storagePercent > 85 ? _neonOrange : _neonCyan,
                  showProgress: true,
                  progressValue: storagePercent / 100,
                  progressColor: storagePercent > 85 ? _neonOrange : _neonCyan,
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: _unifiedStatChip(
                  icon: Icons.android_rounded,
                  label: "SYSTEM",
                  value: "API $sdkInt",
                  color: _textSecondary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Expanded(
                child: _unifiedStatChip(
                  icon: FontAwesomeIcons.link,
                  label: "SESSION",
                  value: sessionKey.substring(0, 8).toUpperCase(),
                  color: _neonPurple,
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: _unifiedStatChip(
                  icon: FontAwesomeIcons.networkWired,
                  label: "CONN",
                  value: "$activeConnections Active",
                  color: _neonGreen,
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: _unifiedStatChip(
                  icon: FontAwesomeIcons.clock,
                  label: "TIME",
                  value: _clockTime.substring(0, 5),
                  color: _neonWhite,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _unifiedStatChip({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
    bool showProgress = false,
    double progressValue = 0.0,
    Color? progressColor,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 7),
      decoration: BoxDecoration(
        color: tp.bg.withOpacity(0.4),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.12), width: 0.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 8),
              const SizedBox(width: 4),
              Text(
                label,
                style: TextStyle(
                  color: _textSecondary.withOpacity(0.65),
                  fontSize: 5.5,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: TextStyle(
              color: _textPrimary.withOpacity(0.9),
              fontSize: 7,
              fontWeight: FontWeight.w600,
              fontFamily: 'Orbitron',
            ),
            overflow: TextOverflow.ellipsis,
          ),
          if (showProgress) ...[
            SizedBox(height: 3),
            ClipRRect(
              borderRadius: BorderRadius.circular(2),
              child: LinearProgressIndicator(
                value: progressValue.clamp(0.0, 1.0),
                minHeight: 2.5,
                backgroundColor: tp.bg.withOpacity(0.6),
                valueColor: AlwaysStoppedAnimation<Color>(progressColor ?? color),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildMotivationCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            _neonPurple.withOpacity(0.08),
            _neonPink.withOpacity(0.05),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _neonPurple.withOpacity(0.15), width: 1),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: _neonPurple.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _neonPurple.withOpacity(0.2)),
            ),
            child: const Icon(
              FontAwesomeIcons.quoteLeft,
              color: _neonPurple,
              size: 12,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "MOTIVASI HARIAN",
                  style: TextStyle(
                    color: _neonPurple,
                    fontSize: 6,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  _dailyMotivation,
                  style: const TextStyle(
                    color: _textPrimary,
                    fontSize: 9,
                    fontFamily: 'Orbitron',
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // =============================================
  // WIDGET SELECTOR (HORIZONTAL KE SAMPING)
  // =============================================
  Widget _buildWidgetSelector() {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 2),
        itemCount: _widgetOptions.length,
        separatorBuilder: (context, index) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final opt = _widgetOptions[index];
          final isActive = _selectedWidgetIndex == index;
          final Color activeColor = _getWidgetColor(index);

          return GestureDetector(
            onTap: () {
              setState(() {
                _selectedWidgetIndex = index;
              });
            },
            child: AnimatedContainer(
              duration: Duration(milliseconds: 250),
              padding: EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: isActive ? activeColor.withOpacity(0.12) : tp.card.withOpacity(0.5),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: isActive ? activeColor.withOpacity(0.6) : _textSecondary.withOpacity(0.1),
                  width: isActive ? 1.5 : 0.5,
                ),
                boxShadow: isActive
                    ? [
                        BoxShadow(
                          color: activeColor.withOpacity(0.15),
                          blurRadius: 12,
                          spreadRadius: 1,
                        ),
                      ]
                    : [],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    opt['icon'] as IconData,
                    color: isActive ? activeColor : _textSecondary,
                    size: 12,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    opt['label'] as String,
                    style: TextStyle(
                      color: isActive ? activeColor : _textSecondary,
                      fontSize: 8,
                      fontWeight: isActive ? FontWeight.bold : FontWeight.w500,
                      fontFamily: 'Orbitron',
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Color _getWidgetColor(int index) {
    switch (index) {
      case 0: return tp.accent;
      case 1: return _neonBlue;
      case 2: return _neonCyan;
      case 3: return _spotifyGreen;
      case 4: return _neonOrange;
      default: return tp.accent;
    }
  }

  Widget _buildSelectedWidgetContent() {
    switch (_selectedWidgetIndex) {
      case 0: return _buildRssNewsWidget();
      case 1: return _buildPrayerWidget();
      case 2: return _buildWeatherWidget();
      case 3: return _buildSpotifyWidget();
      case 4: return _buildDigitalClockWidget();
      default: return _buildRssNewsWidget();
    }
  }

  Widget _buildDigitalClockWidget() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(vertical: 24, horizontal: 16),
      decoration: BoxDecoration(
        color: tp.card.withOpacity(0.7),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _neonOrange.withOpacity(0.25), width: 1),
        boxShadow: [
          BoxShadow(
            color: _neonOrange.withOpacity(0.06),
            blurRadius: 16,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(FontAwesomeIcons.clock, color: _neonOrange, size: 10),
              const SizedBox(width: 6),
              Text(
                "DIGITAL CLOCK",
                style: TextStyle(
                  color: _neonOrange.withOpacity(0.7),
                  fontSize: 7,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            _clockTime,
            style: const TextStyle(
              color: _neonWhite,
              fontSize: 36,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
              letterSpacing: 4,
              shadows: [
                Shadow(blurRadius: 20, color: _neonOrange, offset: Offset(0, 0)),
                Shadow(blurRadius: 40, color: _neonOrange, offset: Offset(0, 0)),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: _neonOrange.withOpacity(0.08),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: _neonOrange.withOpacity(0.2)),
            ),
            child: Text(
              _clockDate,
              style: TextStyle(
                color: _neonOrange.withOpacity(0.9),
                fontSize: 10,
                fontWeight: FontWeight.w600,
                fontFamily: 'Orbitron',
                letterSpacing: 2,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _clockInfoChip(FontAwesomeIcons.sun, "Sunrise", "05:48", _neonOrange),
              const SizedBox(width: 10),
              _clockInfoChip(FontAwesomeIcons.moon, "Sunset", "17:52", _neonPurple),
              const SizedBox(width: 10),
              _clockInfoChip(FontAwesomeIcons.hourglassHalf, "Day Progress", "${_getDayProgress()}%", _neonCyan),
            ],
          ),
        ],
      ),
    );
  }

  int _getDayProgress() {
    final now = DateTime.now();
    final totalMinutes = now.hour * 60 + now.minute;
    return ((totalMinutes / 1440) * 100).round();
  }

  Widget _clockInfoChip(IconData icon, String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.06),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.15)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 10),
          const SizedBox(height: 3),
          Text(
            label,
            style: TextStyle(
              color: _textSecondary.withOpacity(0.7),
              fontSize: 5.5,
              fontFamily: 'Orbitron',
            ),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 8,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWeatherWidget() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: tp.card.withOpacity(0.7),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _neonBlue.withOpacity(0.3), width: 1),
        boxShadow: [
          BoxShadow(
            color: _neonBlue.withOpacity(0.06),
            blurRadius: 16,
            spreadRadius: 2,
          ),
        ],
      ),
      child: isLoadingWeather
          ? const SizedBox(
              height: 80,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(
                      color: _neonBlue,
                      strokeWidth: 2,
                    ),
                  ),
                  SizedBox(width: 8),
                  Text(
                    "Detecting Location...",
                    style: TextStyle(
                      color: _neonWhite,
                      fontSize: 8,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ],
              ),
            )
          : weatherData != null
              ? Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: _neonBlue.withOpacity(0.08),
                                border: Border.all(color: _neonBlue.withOpacity(0.3)),
                              ),
                              child: FaIcon(
                                _getWeatherIcon(weatherData!['weather'][0]['main']),
                                color: _neonBlue,
                                size: 22,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "${weatherData!['main']['temp'].round()}\u00B0C",
                                  style: const TextStyle(
                                    color: _neonWhite,
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Orbitron',
                                    shadows: [
                                      Shadow(blurRadius: 12, color: _neonBlue, offset: Offset(0, 0)),
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  "${weatherData!['name']}",
                                  style: const TextStyle(
                                    color: _neonBlue,
                                    fontSize: 7,
                                    fontFamily: 'Orbitron',
                                    letterSpacing: 1,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        Text(
                          "${weatherData!['weather'][0]['main']}",
                          style: TextStyle(
                            color: _neonWhite,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 12),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                      decoration: BoxDecoration(
                        color: tp.bg.withOpacity(0.4),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          _weatherDetail(
                            FontAwesomeIcons.droplet,
                            "Humidity",
                            "${weatherData!['main']['humidity']}%",
                            _neonBlue,
                          ),
                          Container(width: 1, height: 28, color: _neonBlue.withOpacity(0.15)),
                          _weatherDetail(
                            FontAwesomeIcons.wind,
                            "Wind",
                            "${(weatherData!['wind']['speed'] * 3.6).round()} km/h",
                            _neonCyan,
                          ),
                          Container(width: 1, height: 28, color: _neonBlue.withOpacity(0.15)),
                          _weatherDetail(
                            FontAwesomeIcons.eye,
                            "Visibility",
                            "${((weatherData!['visibility'] ?? 10000) / 1000).round()} km",
                            _neonGreen,
                          ),
                          Container(width: 1, height: 28, color: _neonBlue.withOpacity(0.15)),
                          _weatherDetail(
                            FontAwesomeIcons.temperatureHalf,
                            "Feels Like",
                            "${weatherData!['main']['feels_like'].round()}\u00B0C",
                            _neonOrange,
                          ),
                        ],
                      ),
                    ),
                  ],
                )
              : SizedBox(
                  height: 80,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.location_off, color: _neonWhite, size: 12),
                      const SizedBox(width: 6),
                      Text(
                        weatherErrorMsg,
                        style: const TextStyle(
                          color: _neonWhite,
                          fontSize: 8,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }

  Widget _weatherDetail(IconData icon, String label, String value, Color color) {
    return Column(
      children: [
        Icon(icon, color: color, size: 10),
        const SizedBox(height: 3),
        Text(
          label,
          style: TextStyle(
            color: _textSecondary.withOpacity(0.6),
            fontSize: 5.5,
            fontFamily: 'Orbitron',
          ),
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: TextStyle(
            color: color,
            fontSize: 8,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
          ),
        ),
      ],
    );
  }

  Widget _buildPrayerWidget() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: tp.card.withOpacity(0.7),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _neonBlue.withOpacity(0.3), width: 1),
        boxShadow: [
          BoxShadow(
            color: _neonBlue.withOpacity(0.06),
            blurRadius: 16,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(FontAwesomeIcons.mosque, color: _neonBlue, size: 12),
                  const SizedBox(width: 6),
                  const Text(
                    "WAKTU SHALAT",
                    style: TextStyle(
                      color: _neonBlue,
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
              Flexible(
                child: Text(
                  _prayerLocationName,
                  style: const TextStyle(
                    color: _textSecondary,
                    fontSize: 6,
                    fontFamily: 'Orbitron',
                  ),
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.end,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (_isLoadingPrayer)
            const SizedBox(
              height: 60,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(
                      color: _neonBlue,
                      strokeWidth: 2,
                    ),
                  ),
                  SizedBox(height: 6),
                  Text(
                    "Mencari jadwal...",
                    style: TextStyle(
                      color: _textSecondary,
                      fontSize: 7,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ],
              ),
            )
          else if (_prayerError.isNotEmpty)
            SizedBox(
              height: 50,
              child: Center(
                child: Text(
                  _prayerError,
                  style: const TextStyle(
                    color: Colors.redAccent,
                    fontSize: 8,
                    fontFamily: 'Orbitron',
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            )
          else
            Column(
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
                  margin: const EdgeInsets.only(bottom: 10),
                  decoration: BoxDecoration(
                    color: _neonBlue.withOpacity(0.06),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _neonBlue.withOpacity(0.2)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "MENUJU",
                            style: TextStyle(
                              color: _textSecondary,
                              fontSize: 6,
                              fontFamily: 'Orbitron',
                              letterSpacing: 1,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            _nextPrayerName,
                            style: const TextStyle(
                              color: _neonBlue,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            _nextPrayerTimeStr,
                            style: const TextStyle(
                              color: _textSecondary,
                              fontSize: 7,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            _countdownText,
                            style: const TextStyle(
                              color: _neonWhite,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                              letterSpacing: 2,
                              shadows: [
                                Shadow(blurRadius: 10, color: _neonBlue, offset: Offset(0, 0)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Wrap(
                  spacing: 5,
                  runSpacing: 5,
                  children: _prayerTimes.entries.map((entry) {
                    bool isNext = entry.key == _nextPrayerName ||
                        (entry.key.contains("Besok") && _nextPrayerName.contains("Besok"));
                    final itemWidth = (MediaQuery.of(context).size.width - 20 - 10 * 3 - 5 * 3) / 4;
                    return SizedBox(
                      width: itemWidth,
                      child: Container(
                        padding: EdgeInsets.symmetric(vertical: 8),
                        decoration: BoxDecoration(
                          color: isNext ? _neonBlue.withOpacity(0.12) : tp.bg.withOpacity(0.4),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: isNext ? _neonBlue.withOpacity(0.5) : _neonBlue.withOpacity(0.12),
                            width: isNext ? 1.5 : 0.5,
                          ),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              entry.key,
                              style: TextStyle(
                                color: isNext ? _neonBlue : _textSecondary,
                                fontSize: 6,
                                fontFamily: 'Orbitron',
                                fontWeight: isNext ? FontWeight.bold : FontWeight.normal,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              entry.value.replaceAll(":00", "").replaceAll(" (WIB)", ""),
                              style: TextStyle(
                                color: isNext ? _neonWhite : _neonBlue,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
        ],
      ),
    );
  }

  Widget _buildSpotifyWidget() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: tp.card.withOpacity(0.7),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _spotifyGreen.withOpacity(0.25), width: 1),
        boxShadow: [
          BoxShadow(
            color: _spotifyGreen.withOpacity(0.06),
            blurRadius: 16,
            spreadRadius: 2,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: Column(
          children: [
            _buildNowPlayingBar(),
            _buildSpotifySearchBar(),
            _buildSpotifyContentArea(),
            _buildSpotifyPlayerControls(),
          ],
        ),
      ),
    );
  }

  Widget _buildNowPlayingBar() {
    return GestureDetector(
      onTap: () {
        setState(() {
          _showSearchResults = false;
          _showQueue = false;
        });
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: tp.bg.withOpacity(0.3),
          border: Border(
            bottom: BorderSide(color: _spotifyGreen.withOpacity(0.1), width: 1),
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _spotifyGreen.withOpacity(0.3)),
                boxShadow: [
                  BoxShadow(color: _spotifyGreen.withOpacity(0.08), blurRadius: 8),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(7),
                child: _currentSongImage.isNotEmpty
                    ? Image.network(
                        _currentSongImage,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: tp.bg,
                          child: Icon(FontAwesomeIcons.music, color: _spotifyGreen.withOpacity(0.4), size: 16),
                        ),
                      )
                    : Container(
                        color: tp.bg,
                        child: Icon(FontAwesomeIcons.music, color: _spotifyGreen.withOpacity(0.4), size: 16),
                      ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _currentSongTitle,
                    style: const TextStyle(
                      color: _neonWhite,
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    _currentSongArtist,
                    style: TextStyle(
                      color: _spotifyGreen.withOpacity(0.7),
                      fontSize: 7,
                      fontFamily: 'Orbitron',
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            _spotifyLoading
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(color: _spotifyGreen, strokeWidth: 2),
                  )
                : Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (_spotifyPlaying)
                        Container(
                          width: 6,
                          height: 6,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _spotifyGreen,
                            boxShadow: [
                              BoxShadow(color: _spotifyGreen.withOpacity(0.6), blurRadius: 4),
                            ],
                          ),
                        ),
                      const SizedBox(width: 4),
                      Text(
                        _spotifyPlaying ? "PLAYING" : "PAUSED",
                        style: TextStyle(
                          color: _spotifyPlaying ? _spotifyGreen : _textSecondary,
                          fontSize: 6,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ],
                  ),
          ],
        ),
      ),
    );
  }

  Widget _buildSpotifySearchBar() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: Container(
              height: 34,
              decoration: BoxDecoration(
                color: tp.bg.withOpacity(0.4),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _spotifyGreen.withOpacity(0.2)),
              ),
              child: Row(
                children: [
                  const SizedBox(width: 8),
                  Icon(FontAwesomeIcons.magnifyingGlass, color: _spotifyGreen.withOpacity(0.6), size: 12),
                  const SizedBox(width: 6),
                  Expanded(
                    child: TextField(
                      controller: _spotifySearchController,
                      style: const TextStyle(
                        color: _neonWhite,
                        fontSize: 9,
                        fontFamily: 'Orbitron',
                      ),
                      decoration: const InputDecoration(
                        hintText: "Search songs...",
                        hintStyle: TextStyle(
                          color: _textSecondary,
                          fontSize: 8,
                          fontFamily: 'Orbitron',
                        ),
                        border: InputBorder.none,
                        isDense: true,
                        contentPadding: EdgeInsets.symmetric(vertical: 8),
                      ),
                      onSubmitted: (value) {
                        _searchSongs(value);
                      },
                      textInputAction: TextInputAction.search,
                    ),
                  ),
                  if (_spotifySearchController.text.isNotEmpty)
                    GestureDetector(
                      onTap: () {
                        _spotifySearchController.clear();
                        setState(() {
                          _spotifySearchResults = [];
                          _showSearchResults = false;
                          _searchError = "";
                        });
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(6),
                        child: Icon(Icons.close_rounded, color: _textSecondary.withOpacity(0.6), size: 12),
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 6),
          GestureDetector(
            onTap: () {
              _searchSongs(_spotifySearchController.text);
            },
            child: Container(
              height: 34,
              width: 34,
              decoration: BoxDecoration(
                color: _spotifyGreen,
                borderRadius: BorderRadius.circular(8),
                boxShadow: [
                  BoxShadow(color: _spotifyGreen.withOpacity(0.3), blurRadius: 8),
                ],
              ),
              child: _isSearching
                  ? const Padding(
                      padding: EdgeInsets.all(8),
                      child: CircularProgressIndicator(color: _spotifyBg, strokeWidth: 2),
                    )
                  : const Icon(FontAwesomeIcons.magnifyingGlass, color: _spotifyBg, size: 12),
            ),
          ),
          SizedBox(width: 6),
          GestureDetector(
            onTap: () {
              setState(() {
                _showQueue = !_showQueue;
                _showSearchResults = false;
              });
            },
            child: Container(
              height: 34,
              width: 34,
              decoration: BoxDecoration(
                color: _showQueue ? _spotifyGreen.withOpacity(0.2) : tp.bg.withOpacity(0.4),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: _showQueue ? _spotifyGreen.withOpacity(0.6) : _spotifyGreen.withOpacity(0.2),
                ),
              ),
              child: Stack(
                children: [
                  Center(
                    child: Icon(
                      FontAwesomeIcons.list,
                      color: _showQueue ? _spotifyGreen : _textSecondary,
                      size: 12,
                    ),
                  ),
                  if (_spotifyQueue.isNotEmpty)
                    Positioned(
                      top: 4,
                      right: 4,
                      child: Container(
                        width: 14,
                        height: 14,
                        decoration: BoxDecoration(
                          color: _spotifyGreen,
                          shape: BoxShape.circle,
                          border: Border.all(color: _spotifyBg),
                        ),
                        child: Center(
                          child: Text(
                            _spotifyQueue.length.toString(),
                            style: const TextStyle(
                              color: _spotifyBg,
                              fontSize: 6,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSpotifyContentArea() {
    if (_showQueue) {
      return _buildQueueList();
    }
    if (_showSearchResults) {
      return _buildSearchResultsList();
    }
    return Container(
      height: 100,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(FontAwesomeIcons.spotify, color: _spotifyGreen.withOpacity(0.12), size: 36),
          const SizedBox(height: 10),
          Text(
            "Search and play any song",
            style: TextStyle(
              color: _textSecondary.withOpacity(0.4),
              fontSize: 8,
              fontFamily: 'Orbitron',
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchResultsList() {
    if (_isSearching) {
      return Container(
        height: 120,
        child: const Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 18,
              height: 18,
              child: CircularProgressIndicator(color: _spotifyGreen, strokeWidth: 2),
            ),
            SizedBox(height: 8),
            Text(
              "Searching...",
              style: TextStyle(color: _textSecondary, fontSize: 8, fontFamily: 'Orbitron'),
            ),
          ],
        ),
      );
    }
    if (_searchError.isNotEmpty) {
      return Container(
        height: 80,
        padding: EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline_rounded, color: tp.accent.withOpacity(0.5), size: 20),
            SizedBox(height: 6),
            Text(
              _searchError,
              style: TextStyle(color: tp.accent, fontSize: 8, fontFamily: 'Orbitron'),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }
    if (_spotifySearchResults.isEmpty) {
      return const SizedBox.shrink();
    }
    return Container(
      height: 180,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: ListView.separated(
        physics: const BouncingScrollPhysics(),
        itemCount: _spotifySearchResults.length,
        separatorBuilder: (context, index) => Divider(color: _spotifyGreen.withOpacity(0.06), height: 1),
        itemBuilder: (context, index) {
          final song = _spotifySearchResults[index];
          bool isCurrentPlaying = _currentPlayingSong != null && _currentPlayingSong!['id'] == song['id'];
          return GestureDetector(
            onTap: () => _playSong(song),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Row(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      border: Border.all(
                        color: isCurrentPlaying ? _spotifyGreen : _spotifyGreen.withOpacity(0.15),
                        width: isCurrentPlaying ? 1.5 : 0.5,
                      ),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: song['image'].toString().isNotEmpty
                          ? Image.network(
                              song['image'],
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                color: tp.bg,
                                child: Icon(FontAwesomeIcons.music, color: _spotifyGreen.withOpacity(0.3), size: 12),
                              ),
                            )
                          : Container(
                              color: tp.bg,
                              child: Icon(FontAwesomeIcons.music, color: _spotifyGreen.withOpacity(0.3), size: 12),
                            ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          song['title'] ?? 'Unknown',
                          style: TextStyle(
                            color: isCurrentPlaying ? _spotifyGreen : _neonWhite,
                            fontSize: 8,
                            fontWeight: isCurrentPlaying ? FontWeight.bold : FontWeight.w600,
                            fontFamily: 'Orbitron',
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 2),
                        Text(
                          song['artist'] ?? 'Unknown',
                          style: TextStyle(
                            color: _textSecondary.withOpacity(0.7),
                            fontSize: 6,
                            fontFamily: 'Orbitron',
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  GestureDetector(
                    onTap: () => _addToQueue(song),
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      child: Icon(FontAwesomeIcons.plus, color: _spotifyGreen.withOpacity(0.5), size: 10),
                    ),
                  ),
                  const SizedBox(width: 4),
                  if (isCurrentPlaying && _spotifyPlaying)
                    Icon(FontAwesomeIcons.volumeHigh, color: _spotifyGreen, size: 10)
                  else
                    Icon(FontAwesomeIcons.play, color: _textSecondary.withOpacity(0.4), size: 10),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildQueueList() {
    if (_spotifyQueue.isEmpty) {
      return Container(
        height: 80,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(FontAwesomeIcons.list, color: _textSecondary.withOpacity(0.2), size: 24),
            const SizedBox(height: 8),
            Text(
              "Queue is empty",
              style: TextStyle(
                color: _textSecondary.withOpacity(0.4),
                fontSize: 8,
                fontFamily: 'Orbitron',
              ),
            ),
          ],
        ),
      );
    }
    return Container(
      height: 140,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              children: [
                Icon(FontAwesomeIcons.list, color: _spotifyGreen, size: 10),
                const SizedBox(width: 6),
                Text(
                  "PLAY QUEUE (${_spotifyQueue.length})",
                  style: const TextStyle(
                    color: _spotifyGreen,
                    fontSize: 7,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.5,
                  ),
                ),
                Spacer(),
                GestureDetector(
                  onTap: () {
                    setState(() {
                      _spotifyQueue.clear();
                    });
                  },
                  child: Text(
                    "CLEAR",
                    style: TextStyle(
                      color: tp.accent.withOpacity(0.7),
                      fontSize: 6,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.separated(
              physics: const BouncingScrollPhysics(),
              itemCount: _spotifyQueue.length,
              separatorBuilder: (context, index) => Divider(color: _spotifyGreen.withOpacity(0.04), height: 1),
              itemBuilder: (context, index) {
                final song = _spotifyQueue[index];
                return Dismissible(
                  key: Key(song['id'].toString()),
                  direction: DismissDirection.endToStart,
                  onDismissed: (direction) {
                    setState(() {
                      _spotifyQueue.removeAt(index);
                    });
                  },
                  background: Container(
                    alignment: Alignment.centerRight,
                    padding: EdgeInsets.only(right: 12),
                    child: Icon(Icons.delete_outline_rounded, color: tp.accent, size: 16),
                  ),
                  child: GestureDetector(
                    onTap: () => _playSong(song),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Row(
                        children: [
                          Text(
                            "${index + 1}",
                            style: TextStyle(
                              color: _textSecondary.withOpacity(0.5),
                              fontSize: 7,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            width: 28,
                            height: 28,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              border: Border.all(color: _spotifyGreen.withOpacity(0.12)),
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(3),
                              child: song['image'].toString().isNotEmpty
                                  ? Image.network(
                                      song['image'],
                                      fit: BoxFit.cover,
                                      errorBuilder: (_, __, ___) => Container(
                                        color: tp.bg,
                                        child: Icon(FontAwesomeIcons.music, color: _spotifyGreen.withOpacity(0.3), size: 10),
                                      ),
                                    )
                                  : Container(
                                      color: tp.bg,
                                      child: Icon(FontAwesomeIcons.music, color: _spotifyGreen.withOpacity(0.3), size: 10),
                                    ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  song['title'] ?? 'Unknown',
                                  style: const TextStyle(
                                    color: _neonWhite,
                                    fontSize: 7,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'Orbitron',
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                Text(
                                  song['artist'] ?? 'Unknown',
                                  style: TextStyle(
                                    color: _textSecondary.withOpacity(0.6),
                                    fontSize: 6,
                                    fontFamily: 'Orbitron',
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSpotifyPlayerControls() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        border: Border(top: BorderSide(color: _spotifyGreen.withOpacity(0.1))),
      ),
      child: Column(
        children: [
          SliderTheme(
            data: SliderThemeData(
              trackHeight: 3,
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 5),
              overlayShape: const RoundSliderOverlayShape(overlayRadius: 10),
              activeTrackColor: _spotifyGreen,
              inactiveTrackColor: _spotifyGreen.withOpacity(0.12),
              thumbColor: _neonWhite,
              overlayColor: _spotifyGreen.withOpacity(0.2),
            ),
            child: Slider(
              value: _spotifyDuration.inSeconds > 0 ? _spotifyProgress : 0.0,
              onChanged: (val) {
                final seekPosition = Duration(
                  seconds: (val * _spotifyDuration.inSeconds).round(),
                );
                _audioHandler?.seekToPosition(seekPosition);
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  _spotifyPositionStr,
                  style: TextStyle(color: _textSecondary.withOpacity(0.7), fontSize: 7, fontFamily: 'Orbitron'),
                ),
                Text(
                  _spotifyDurationStr,
                  style: TextStyle(color: _textSecondary.withOpacity(0.7), fontSize: 7, fontFamily: 'Orbitron'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _spotifyControlButton(icon: FontAwesomeIcons.shuffle, size: 12, color: _textSecondary.withOpacity(0.4), onTap: () {}),
              const SizedBox(width: 20),
              _spotifyControlButton(icon: FontAwesomeIcons.backwardStep, size: 18, color: _neonWhite, onTap: _playPreviousSong),
              const SizedBox(width: 16),
              GestureDetector(
                onTap: () {
                  if (_currentPlayingSong == null) return;
                  if (_spotifyPlaying) {
                    _audioHandler?.pausePlayback();
                    bg.AudioService().resume();
                  } else {
                    _audioHandler?.resumePlayback();
                    bg.AudioService().pause();
                  }
                },
                child: Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _spotifyGreen,
                    boxShadow: [
                      BoxShadow(color: _spotifyGreen.withOpacity(0.35), blurRadius: 16, spreadRadius: 1),
                    ],
                  ),
                  child: Center(
                    child: _spotifyLoading
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(color: _spotifyBg, strokeWidth: 2),
                          )
                        : Icon(
                            _spotifyPlaying ? FontAwesomeIcons.pause : FontAwesomeIcons.play,
                            color: _spotifyBg,
                            size: 16,
                          ),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              _spotifyControlButton(icon: FontAwesomeIcons.forwardStep, size: 18, color: _neonWhite, onTap: _playNextSong),
              const SizedBox(width: 20),
              _spotifyControlButton(icon: FontAwesomeIcons.repeat, size: 12, color: _textSecondary.withOpacity(0.4), onTap: () {
                if (_currentPlayingSong != null) {
                  _audioHandler?.seekToPosition(Duration.zero);
                  _audioHandler?.resumePlayback();
                  bg.AudioService().pause();
                }
              }),
            ],
          ),
        ],
      ),
    );
  }

  Widget _spotifyControlButton({
    required IconData icon,
    required double size,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Icon(icon, color: color, size: size),
    );
  }

  Widget _buildQuickNoteCard() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: tp.card.withOpacity(0.7),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _neonCyan.withOpacity(0.2), width: 1),
      ),
      child: Column(
        children: [
          GestureDetector(
            onTap: () {
              setState(() {
                _noteExpanded = !_noteExpanded;
              });
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              child: Row(
                children: [
                  Container(
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(
                      color: _neonCyan.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(7),
                      border: Border.all(color: _neonCyan.withOpacity(0.2)),
                    ),
                    child: Icon(
                      FontAwesomeIcons.stickyNote,
                      color: _neonCyan,
                      size: 11,
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Text(
                    "QUICK NOTE",
                    style: TextStyle(
                      color: _neonCyan,
                      fontSize: 8,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                  const Spacer(),
                  if (_quickNote.isNotEmpty && !_noteExpanded)
                    Expanded(
                      child: Text(
                        _quickNote,
                        style: TextStyle(
                          color: _textSecondary.withOpacity(0.6),
                          fontSize: 7,
                          fontFamily: 'Orbitron',
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.end,
                      ),
                    ),
                  const SizedBox(width: 4),
                  Icon(
                    _noteExpanded ? Icons.expand_less_rounded : Icons.expand_more_rounded,
                    color: _neonCyan.withOpacity(0.5),
                    size: 16,
                  ),
                ],
              ),
            ),
          ),
          if (_noteExpanded)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                border: Border(top: BorderSide(color: _neonCyan.withOpacity(0.1))),
              ),
              child: Column(
                children: [
                  Container(
                    constraints: const BoxConstraints(maxHeight: 80),
                    child: TextField(
                      controller: _noteController,
                      style: TextStyle(
                        color: _neonWhite,
                        fontSize: 8,
                        fontFamily: 'Orbitron',
                      ),
                      maxLines: 4,
                      decoration: InputDecoration(
                        hintText: "Tulis catatan cepat...",
                        hintStyle: TextStyle(
                          color: _textSecondary.withOpacity(0.4),
                          fontSize: 8,
                          fontFamily: 'Orbitron',
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: BorderSide(color: _neonCyan.withOpacity(0.15)),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: BorderSide(color: _neonCyan.withOpacity(0.15)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: BorderSide(color: _neonCyan.withOpacity(0.4)),
                        ),
                        contentPadding: EdgeInsets.all(10),
                        filled: true,
                        fillColor: tp.bg.withOpacity(0.4),
                      ),
                    ),
                  ),
                  SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      GestureDetector(
                        onTap: () {
                          _noteController.clear();
                          _saveQuickNote("");
                        },
                        child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: tp.accent.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: tp.accent.withOpacity(0.3)),
                          ),
                          child: Text(
                            "CLEAR",
                            style: TextStyle(
                              color: tp.accent,
                              fontSize: 7,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 8),
                      GestureDetector(
                        onTap: () {
                          _saveQuickNote(_noteController.text);
                          setState(() {
                            _noteExpanded = false;
                          });
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: const Text("Catatan disimpan"),
                              backgroundColor: _neonCyan.withOpacity(0.8),
                              duration: Duration(seconds: 1),
                            ),
                          );
                        },
                        child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: _neonCyan,
                            borderRadius: BorderRadius.circular(6),
                            boxShadow: [
                              BoxShadow(color: _neonCyan.withOpacity(0.3), blurRadius: 8),
                            ],
                          ),
                          child: Text(
                            "SAVE",
                            style: TextStyle(
                              color: tp.bg,
                              fontSize: 7,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  // =============================================
  // RSS NEWS WIDGET (Horizontal Selector & Horizontal News List)
  // =============================================
  Widget _buildRssNewsWidget() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: tp.card.withOpacity(0.7),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: tp.accent.withOpacity(0.2), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          // Header
          Center(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(FontAwesomeIcons.newspaper, color: tp.accent, size: 12),
                SizedBox(width: 6),
                Text(
                  "BERITA TERKINI",
                  style: TextStyle(
                    color: tp.accent,
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                  ),
                ),
              ],
            ),
          ),
          
          // Spasi Header ke Tab Selector
          const SizedBox(height: 10),
          
          // Tab Selector Horizontal
          SizedBox(
            height: 28,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              physics: BouncingScrollPhysics(),
              itemCount: _newsTabs.length,
              separatorBuilder: (context, index) => SizedBox(width: 6),
              itemBuilder: (context, index) {
                final isActive = _selectedNewsTab == index;
                return GestureDetector(
                  onTap: () => _onNewsTabChanged(index),
                  child: AnimatedContainer(
                    duration: Duration(milliseconds: 200),
                    padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: isActive ? tp.accent.withOpacity(0.15) : tp.bg.withOpacity(0.4),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                        color: isActive ? tp.accent.withOpacity(0.5) : _textSecondary.withOpacity(0.1),
                        width: isActive ? 1.2 : 0.5,
                      ),
                    ),
                    child: Center(
                      child: Text(
                        _newsTabs[index]['label'] ?? '',
                        style: TextStyle(
                          color: isActive ? tp.accent : _textSecondary,
                          fontSize: 6,
                          fontWeight: isActive ? FontWeight.bold : FontWeight.w500,
                          fontFamily: 'Orbitron',
                          letterSpacing: 0.3,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          
          // Spasi Tab ke Konten
          SizedBox(height: 12),
          
          // Konten Berita Horizontal
          _buildNewsTabContent(),
        ],
      ),
    );
  }

  Widget _buildNewsTabContent() {
    final isLoading = _newsTabLoading[_selectedNewsTab] ?? false;
    final error = _newsTabError[_selectedNewsTab] ?? '';
    final data = _newsTabData[_selectedNewsTab];

    if (isLoading) {
      return SizedBox(
        height: 150,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 16,
              height: 16,
              child: CircularProgressIndicator(color: tp.accent, strokeWidth: 2),
            ),
            SizedBox(height: 8),
            Text(
              "Mengambil berita...",
              style: TextStyle(color: _textSecondary, fontSize: 8, fontFamily: 'Orbitron'),
            ),
          ],
        ),
      );
    }

    if (error.isNotEmpty) {
      return SizedBox(
        height: 150,
        child: Center(
          child: Text(
            error,
            style: const TextStyle(color: Colors.redAccent, fontSize: 8, fontFamily: 'Orbitron'),
          ),
        ),
      );
    }

    if (data == null || data.isEmpty) {
      return const SizedBox(
        height: 150,
        child: Center(
          child: Text(
            "Tidak ada berita",
            style: TextStyle(color: _textSecondary, fontSize: 8, fontFamily: 'Orbitron'),
          ),
        ),
      );
    }

    // Menggunakan ListView horizontal agar bisa di-scroll ke samping
    return SizedBox(
      height: 160,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: data.length,
        separatorBuilder: (context, index) => SizedBox(width: 10),
        itemBuilder: (context, index) {
          return _buildHorizontalNewsItem(data[index]);
        },
      ),
    );
  }

  Widget _buildHorizontalNewsItem(Map<String, dynamic> news) {
    String formattedTime = "";
    try {
      if (news['pubDate'].toString().isNotEmpty) {
        final dateTime = DateTime.parse(news['pubDate'].toString());
        formattedTime = "${dateTime.day}/${dateTime.month} ${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}";
      }
    } catch (e) {
      final raw = news['pubDate'].toString();
      formattedTime = raw.length >= 16 ? raw.substring(0, 16) : raw;
    }

    // Menggunakan Fixed width agar tidak menumpuk
    return Container(
      width: 160,
      decoration: BoxDecoration(
        color: tp.bg.withOpacity(0.4),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: tp.accent.withOpacity(0.15), width: 1),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Gambar Berita
            Container(
              height: 90,
              width: double.infinity,
              decoration: BoxDecoration(
                color: tp.bg,
              ),
              child: news['imageUrl'].toString().isNotEmpty
                  ? Image.network(
                      news['imageUrl'],
                      fit: BoxFit.cover,
                      width: double.infinity,
                      errorBuilder: (_, __, ___) => const Center(
                        child: Icon(Icons.image_not_supported_outlined, color: _textSecondary, size: 20),
                      ),
                    )
                  : const Center(
                      child: Icon(Icons.article_outlined, color: _textSecondary, size: 24),
                    ),
            ),
            
            // Detail Berita
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Judul
                    Text(
                      news['title'] ?? 'Tidak ada judul',
                      style: TextStyle(
                        color: _textPrimary,
                        fontSize: 7,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Orbitron',
                        height: 1.3,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    
                    // Waktu
                    Row(
                      children: [
                        Icon(Icons.access_time_rounded, color: tp.accent, size: 8),
                        SizedBox(width: 4),
                        Text(
                          formattedTime,
                          style: TextStyle(color: tp.accent, fontSize: 6, fontFamily: 'Orbitron'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionGrid() {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      mainAxisSpacing: 6,
      crossAxisSpacing: 6,
      childAspectRatio: 2.8,
      children: [
        _buildGridMenuButton(
          icon: FontAwesomeIcons.telegram,
          label: "JOIN TELEGRAM",
          accentColor: _neonCyan,
          onTap: () => _openUrl("https://t.me/myselfiyi"),
        ),
        _buildGridMenuButton(
          icon: Icons.bug_report_outlined,
          label: "MANAGE BUG",
          accentColor: tp.accent,
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => BugSenderPage(
                  sessionKey: sessionKey,
                  username: username,
                  role: role,
                ),
              ),
            );
          },
        ),
        _buildGridMenuButton(
          icon: Icons.sports_esports_outlined,
          label: "GAMES",
          accentColor: _neonPurple,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => GamesPage()),
          ),
        ),
        _buildGridMenuButton(
          icon: Icons.shopping_cart_outlined,
          label: "ORDER",
          accentColor: _neonGreen,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => OrderNokosPage()),
          ),
        ),
      ],
    );
  }

  Widget _buildGridMenuButton({
    required IconData icon,
    required String label,
    required Color accentColor,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: tp.card.withOpacity(0.7),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: accentColor.withOpacity(0.15)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: accentColor, size: 14),
            const SizedBox(width: 7),
            Text(
              label,
              style: TextStyle(
                color: _textPrimary.withOpacity(0.9),
                fontSize: 9,
                fontWeight: FontWeight.w500,
                fontFamily: 'Orbitron',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildThanksToWidget() {
    final current = thanksToList[_currentThanksIndex];

    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(vertical: 14, horizontal: 10),
      decoration: BoxDecoration(
        color: tp.bg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: tp.accent.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(width: 2, height: 10, color: tp.accent.withOpacity(0.4)),
              SizedBox(width: 8),
              Text(
                "SPECIAL THANKS TO",
                style: TextStyle(
                  color: _textSecondary,
                  fontSize: 7,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                  fontFamily: 'Orbitron',
                ),
              ),
              SizedBox(width: 8),
              Container(width: 2, height: 10, color: tp.accent.withOpacity(0.4)),
            ],
          ),
          const SizedBox(height: 10),
          AnimatedSwitcher(
            duration: Duration(milliseconds: 400),
            transitionBuilder: (child, animation) {
              final offsetAnim = Tween<Offset>(
                begin: Offset(0, 0.3),
                end: Offset.zero,
              ).animate(CurvedAnimation(parent: animation, curve: Curves.easeOutBack));
              final scaleAnim = Tween<double>(begin: 0.8, end: 1.0)
                  .animate(CurvedAnimation(parent: animation, curve: Curves.easeOutBack));
              return ClipRect(
                child: SlideTransition(
                  position: offsetAnim,
                  child: ScaleTransition(scale: scaleAnim, child: child),
                ),
              );
            },
            child: Text(
              current['name'] ?? "",
              key: ValueKey<String>(current['name'] ?? ""),
              style: TextStyle(
                color: _textPrimary,
                fontSize: 18,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
                fontFamily: 'Orbitron',
                shadows: [
                  Shadow(blurRadius: 12, color: tp.accent, offset: Offset(0, 0)),
                ],
              ),
              textAlign: TextAlign.center,
            ),
          ),
          SizedBox(height: 8),
          AnimatedSwitcher(
            duration: Duration(milliseconds: 400),
            transitionBuilder: (child, animation) => FadeTransition(opacity: animation, child: child),
            child: Row(
              key: ValueKey<String>(current['role'] ?? ""),
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.terminal_rounded, color: tp.accent.withOpacity(0.7), size: 10),
                SizedBox(width: 6),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                  decoration: BoxDecoration(
                    color: tp.accent.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: tp.accent.withOpacity(0.25)),
                  ),
                  child: Text(
                    "> ${current['role'] ?? ""}",
                    style: TextStyle(
                      color: tp.accent,
                      fontSize: 8,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 1,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNavBar(Color activeNeon) {
    final icons = [
      Icons.home_rounded,
      FontAwesomeIcons.whatsapp,
      Icons.notifications_outlined,
      Icons.settings,
      Icons.music_note_rounded,
      Icons.build_outlined,
    ];

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Container(
        height: 64,
        decoration: BoxDecoration(
          color: tp.bg.withOpacity(0.9),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: activeNeon.withOpacity(0.15)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.5),
              blurRadius: 16,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: List.generate(6, (index) {
            bool isActive = _bottomNavIndex == index;
            Color itemColor = isActive ? activeNeon : _textSecondary;
            return GestureDetector(
              onTap: () => _onBottomNavTapped(index),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: isActive ? activeNeon.withOpacity(0.12) : Colors.transparent,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icons[index], color: itemColor, size: 22),
              ),
            );
          }),
        ),
      ),
    );
  }

  Widget _buildCustomDrawer(Color activeNeon) {
    return Drawer(
      backgroundColor: tp.bg,
      width: MediaQuery.of(context).size.width * 0.72,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildDrawerHeader(activeNeon),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.only(top: 6),
              children: [
                if (role == "reseller")
                  _buildDrawerItem(
                    icon: Icons.storefront_outlined,
                    label: "Seller Page",
                    color: activeNeon,
                    onTap: () => _onSidebarTabSelected(1),
                  ),
                if (role == "admin")
                  _buildDrawerItem(
                    icon: Icons.admin_panel_settings_outlined,
                    label: "Admin Page",
                    color: activeNeon,
                    onTap: () => _onSidebarTabSelected(2),
                  ),
                if (role == "owner")
                  _buildDrawerItem(
                    icon: Icons.workspace_premium_outlined,
                    label: "Owner Page",
                    color: activeNeon,
                    onTap: () => _onSidebarTabSelected(3),
                  ),
                _buildDrawerItem(
                  icon: Icons.history_rounded,
                  label: "Riwayat Aktivitas",
                  color: activeNeon,
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role),
                      ),
                    );
                  },
                ),
                _buildDrawerItem(
                  icon: FontAwesomeIcons.comments,
                  label: "Chat Global",
                  color: activeNeon,
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => GlobalChatPage(
                          sessionKey: sessionKey,
                          username: username,
                          role: role,
                        ),
                      ),
                    );
                  },
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  child: Divider(color: _textSecondary.withOpacity(0.15), height: 1),
                ),
                _buildDrawerItem(
                  icon: Icons.logout_rounded,
                  label: "Log Out",
                  color: tp.accent,
                  isLogout: true,
                  onTap: () async {
                    Navigator.pop(context);
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.clear();
                    if (!mounted) return;
                    Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(builder: (_) => const LoginPage()),
                      (route) => false,
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerHeader(Color activeNeon) {
    return Container(
      height: 180,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [tp.bg, activeNeon.withOpacity(0.08)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Stack(
        children: [
          if (_menuVideoController != null && _menuVideoController!.value.isInitialized)
            Opacity(
              opacity: 0.08,
              child: SizedBox.expand(
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _menuVideoController!.value.size.width,
                    height: _menuVideoController!.value.size.height,
                    child: VideoPlayer(_menuVideoController!),
                  ),
                ),
              ),
            ),
          SafeArea(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: activeNeon, width: 2),
                      boxShadow: [
                        BoxShadow(color: activeNeon.withOpacity(0.25), blurRadius: 12),
                      ],
                    ),
                    child: ClipOval(
                      child: _profileImage != null
                          ? Image.file(_profileImage!, fit: BoxFit.cover)
                          : Icon(
                              FontAwesomeIcons.userAstronaut,
                              size: 22,
                              color: activeNeon.withOpacity(0.7),
                            ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    username,
                    style: const TextStyle(
                      color: _textPrimary,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: activeNeon.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: activeNeon.withOpacity(0.25)),
                    ),
                    child: Text(
                      role.toUpperCase(),
                      style: TextStyle(
                        color: activeNeon,
                        fontSize: 8,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    return ListTile(
      leading: Icon(icon, color: isLogout ? tp.accent : color, size: 16),
      title: Text(
        label,
        style: TextStyle(
          color: isLogout ? tp.accent : _textPrimary,
          fontSize: 10,
          fontWeight: isLogout ? FontWeight.bold : FontWeight.w500,
          fontFamily: 'Orbitron',
        ),
      ),
      onTap: onTap,
    );
  }

  String _formatDate(String dateStr) {
    try {
      final date = DateTime.parse(dateStr);
      return "${date.day}/${date.month}/${date.year}";
    } catch (e) {
      return dateStr;
    }
  }

  @override
  void dispose() {
    _prayerCountdownTimer?.cancel();
    _clockTimer?.cancel();
    _spotifySearchController.dispose();
    _noteController.dispose();
    _broadcastUrlController.dispose();
    _disconnectBroadcast();
    _audioHandler?.stop();
    bg.AudioService().resume();
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _bgVideoController?.dispose();
    _menuVideoController?.dispose();
    _bannerVideoController?.dispose();
    _pageController.dispose();
    super.dispose();
  }
}

// =============================================
// News Media Widget
// =============================================
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) {
            setState(() {});
            _controller?.setLooping(true);
            _controller?.setVolume(0.0);
            _controller?.play();
          }
        });
    }
  }

  bool _isVideo(String url) {
    final Uri? uri = Uri.tryParse(url);
    if (uri == null || uri.pathSegments.isEmpty) return false;
    final path = uri.pathSegments.last.toLowerCase();
    return path.endsWith(".mp4") || path.endsWith(".webm") || path.endsWith(".mov") || path.endsWith(".mkv");
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return Center(
          child: AspectRatio(
            aspectRatio: _controller!.value.aspectRatio,
            child: VideoPlayer(_controller!),
          ),
        );
      } else {
        return const Center(
          child: CircularProgressIndicator(color: Color(0xFFE8364F)),
        );
      }
    } else {
      return Image.network(
        widget.url,
        fit: BoxFit.cover,
        width: double.infinity,
        height: double.infinity,
        errorBuilder: (_, __, ___) => Container(
          color: const Color(0xFF101018),
          child: const Icon(Icons.broken_image, color: Color(0xFF6B6B80)),
        ),
      );
    }
  }
}