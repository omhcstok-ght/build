import 'dart:ui';
import 'color_picker_page.dart';
import 'theme_provider.dart';
import 'package:flutter/material.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';

// --- VARIABEL WARNA GLOBAL (DAPAT DIAKSES OLEH SEMUA CLASS DI FILE INI) ---
const Color bgDeepBlack = Color(0xFF050505);
const Color cardBlack = Color(0xFF0F0F0F);
const Color neonRed = Color(0xFFFF003C);
const Color neonWhite = Color(0xFFF0F0F0);
const Color neonCyan = Color(0xFF00E5FF);
const Color neonPurple = Color(0xFFD500F9);
const Color neonGreen = Color(0xFF76FF03);
const Color neonYellow = Color(0xFFFFAB00);
const Color textGrey = Color(0xFF6B6B6B);
const Color borderSubtle = Color(0xFF1E1E1E);

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> {
  ThemeProvider get tp => ThemeProvider();
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: tp,
      builder: (context, _) => Scaffold(
      backgroundColor: tp.bg,
      body: SafeArea(
        child: Column(
          children: [
            _buildGlowHeader(),
            const SizedBox(height: 20),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: GridView.count(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 1.1,
                  children: [
                    _buildToolCard(
                      icon: Icons.bolt_outlined,
                      title: "DDoS",
                      subtitle: "Attack & Server",
                      gradient: const LinearGradient(colors: [neonRed, Color(0xFF950020)]),
                      glowColor: neonRed,
                      onTap: () => _navigateToCategory(context, 'DDoS Tools', neonRed, Icons.bolt_outlined, _getDDoSTools()),
                    ),
                    _buildToolCard(
                      icon: Icons.wifi_tethering_rounded,
                      title: "Network",
                      subtitle: "WiFi & Spam",
                      gradient: const LinearGradient(colors: [neonCyan, Color(0xFF006978)]),
                      glowColor: neonCyan,
                      onTap: () => _navigateToCategory(context, 'Network Tools', neonCyan, Icons.wifi_tethering_rounded, _getNetworkTools()),
                    ),
                    _buildToolCard(
                      icon: Icons.radar_outlined,
                      title: "OSINT",
                      subtitle: "Investigation",
                      gradient: const LinearGradient(colors: [neonPurple, Color(0xFF6A0080)]),
                      glowColor: neonPurple,
                      onTap: () => _navigateToCategory(context, 'OSINT Tools', neonPurple, Icons.radar_outlined, _getOSINTTools()),
                    ),
                    _buildToolCard(
                      icon: Icons.download_for_offline_outlined,
                      title: "Social",
                      subtitle: "Media Downloader",
                      gradient: const LinearGradient(colors: [neonGreen, Color(0xFF33691E)]),
                      glowColor: neonGreen,
                      onTap: () => _navigateToCategory(context, 'Media Downloader', neonGreen, Icons.download_for_offline_outlined, _getDownloaderTools()),
                    ),
                    _buildToolCard(
                      icon: Icons.build_outlined,
                      title: "Utilities",
                      subtitle: "Extra Tools",
                      gradient: const LinearGradient(colors: [neonYellow, Color(0xFF8D6E00)]),
                      glowColor: neonYellow,
                      onTap: () => _navigateToCategory(context, 'Utility Tools', neonYellow, Icons.build_outlined, _getUtilityTools()),
                    ),
                    _buildToolCard(
                      icon: Icons.palette_outlined,
                      title: "Theme",
                      subtitle: "Ganti Warna",
                      gradient: LinearGradient(colors: [tp.primary, tp.accent]),
                      glowColor: tp.accent,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ColorPickerPage())),
                    ),
                    _buildToolCard(
                      icon: Icons.star_outline_rounded,
                      title: "Favorites",
                      subtitle: "Quick Access",
                      gradient: const LinearGradient(colors: [neonWhite, textGrey]),
                      glowColor: neonWhite,
                      onTap: () => _showComingSoon(context),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    ),
    );
  }

  // --- WIDGET HEADER GLOW ---
  Widget _buildGlowHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            tp.card.withOpacity(0.8),
            tp.accent.withOpacity(0.1),
            tp.card.withOpacity(0.8),
          ],
        ),
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
        border: Border.all(color: neonRed.withOpacity(0.2), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  gradient: LinearGradient(
                    colors: [neonRed.withOpacity(0.2), Colors.transparent],
                  ),
                ),
                child: ShaderMask(
                  shaderCallback: (bounds) => const LinearGradient(
                    colors: [neonWhite, neonRed, neonWhite],
                    tileMode: TileMode.mirror,
                  ).createShader(bounds),
                  blendMode: BlendMode.srcIn,
                  child: const Text(
                    "TOOLS DASHBOARD",
                    style: TextStyle(
                      fontSize: 26,
                      fontFamily: 'Rajdhani',
                      fontWeight: FontWeight.w800,
                      letterSpacing: 4,
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            "Advanced Security & OSINT Suite",
            style: TextStyle(
              color: textGrey,
              fontSize: 14,
              fontFamily: 'Rajdhani',
              fontWeight: FontWeight.w600,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }

  // --- WIDGET CARD GLOW SMOOTH DENGAN ANIMASI ---
  Widget _buildToolCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required LinearGradient gradient,
    required Color glowColor,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) => setState(() => _isPressed = false),
      onTapCancel: () => setState(() => _isPressed = false),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        curve: Curves.easeInOut,
        transform: _isPressed ? (Matrix4.identity()..scale(0.95)) : Matrix4.identity(),
        transformAlignment: Alignment.center,
        decoration: BoxDecoration(
          color: cardBlack,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: glowColor.withOpacity(0.15), width: 1),
          boxShadow: [
            BoxShadow(
              color: glowColor.withOpacity(_isPressed ? 0.15 : 0.08),
              blurRadius: _isPressed ? 25 : 20,
              spreadRadius: _isPressed ? 4 : 2,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [glowColor.withOpacity(0.2), glowColor.withOpacity(0.05)],
                  ),
                  border: Border.all(color: glowColor.withOpacity(0.4), width: 1.5),
                  boxShadow: [
                    BoxShadow(
                      color: glowColor.withOpacity(0.3),
                      blurRadius: 12,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: Icon(icon, color: glowColor, size: 24, shadows: [
                  Shadow(color: glowColor, blurRadius: 10),
                ]),
              ),
              const Spacer(),
              Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: neonWhite,
                  fontSize: 17,
                  fontFamily: 'Rajdhani',
                  fontWeight: FontWeight.w800,
                  shadows: [Shadow(color: glowColor.withOpacity(0.5), blurRadius: 8)],
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: textGrey,
                  fontSize: 12,
                  fontFamily: 'Rajdhani',
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // --- LOGIKA MENU LIST ---
  List<Map<String, dynamic>> _getDDoSTools() {
    return [
      {'icon': Icons.flash_on, 'label': 'Attack Panel', 'page': AttackPanel(sessionKey: widget.sessionKey, listDoos: widget.listDoos)},
      {'icon': Icons.dns_outlined, 'label': 'Manage Server', 'page': ManageServerPage(keyToken: widget.sessionKey)},
    ];
  }

  List<Map<String, dynamic>> _getNetworkTools() {
    List<Map<String, dynamic>> tools = [
      {'icon': Icons.newspaper_outlined, 'label': 'Spam NGL', 'page': const NglPage()},
      {'icon': Icons.wifi_off_outlined, 'label': 'WiFi Killer (Internal)', 'page': const WifiKillerPage()},
    ];
    if (widget.userRole == "vip" || widget.userRole == "owner") {
      tools.add({'icon': Icons.router_outlined, 'label': 'WiFi Killer (External)', 'page': WifiInternalPage(sessionKey: widget.sessionKey)});
    }
    return tools;
  }

  List<Map<String, dynamic>> _getOSINTTools() {
    return [
      {'icon': Icons.badge_outlined, 'label': 'NIK Detail', 'page': const NikCheckerPage()},
      {'icon': Icons.domain_outlined, 'label': 'Domain OSINT', 'page': const DomainOsintPage()},
      {'icon': Icons.person_search_outlined, 'label': 'Phone Lookup', 'page': null},
      {'icon': Icons.email_outlined, 'label': 'Email OSINT', 'page': null},
    ];
  }

  List<Map<String, dynamic>> _getDownloaderTools() {
    return [
      {'icon': Icons.video_library_outlined, 'label': 'TikTok WATCH', 'page': const TiktokDownloaderPage()},
      {'icon': Icons.camera_alt_outlined, 'label': 'Instagram Downloader', 'page': const InstagramDownloaderPage()},
    ];
  }

  List<Map<String, dynamic>> _getUtilityTools() {
    return [
      {'icon': Icons.qr_code_2_outlined, 'label': 'QR Generator', 'page': const QrGeneratorPage()},
      {'icon': Icons.security_outlined, 'label': 'IP Scanner', 'page': null},
      {'icon': Icons.network_check_outlined, 'label': 'Port Scanner', 'page': null},
    ];
  }

  // --- NAVIGASI KE HALAMAN SUB-MENU ---
  void _navigateToCategory(BuildContext context, String title, Color accentColor, IconData headerIcon, List<Map<String, dynamic>> tools) {
    Navigator.of(context).push(
      PageRouteBuilder(
        opaque: false,
        transitionDuration: const Duration(milliseconds: 400),
        reverseTransitionDuration: const Duration(milliseconds: 300),
        pageBuilder: (context, animation, secondaryAnimation) => _CategoryDetailPage(
          title: title,
          accentColor: accentColor,
          headerIcon: headerIcon,
          tools: tools,
        ),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          const begin = Offset(0.0, 1.0);
          const end = Offset.zero;
          const curve = Curves.easeOutCubic;
          final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
          final offsetAnimation = animation.drive(tween);
          
          return FadeTransition(
            opacity: animation,
            child: SlideTransition(
              position: offsetAnimation,
              child: child,
            ),
          );
        },
      ),
    );
  }

  void _showComingSoon(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Row(
          children: [
            Icon(Icons.hourglass_top, color: neonWhite),
            SizedBox(width: 10),
            Text(
              'Feature Coming Soon!',
              style: TextStyle(
                fontFamily: 'Rajdhani',
                fontWeight: FontWeight.w700,
                color: neonWhite,
              ),
            ),
          ],
        ),
        backgroundColor: neonRed.withOpacity(0.9),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: neonRed.withOpacity(0.5), width: 1),
        ),
        elevation: 0,
        duration: const Duration(seconds: 2),
      ),
    );
  }
}

// --- HALAMAN DETAIL KATEGORI ---
class _CategoryDetailPage extends StatelessWidget {
  final String title;
  final Color accentColor;
  final IconData headerIcon;
  final List<Map<String, dynamic>> tools;

  const _CategoryDetailPage({
    required this.title,
    required this.accentColor,
    required this.headerIcon,
    required this.tools,
  });

  @override
  Widget build(BuildContext context) {
    // LANGSUNG MENGGUNAKAN VARIABEL GLOBAL, TANPA PREFIX "ToolsPage."
    return Scaffold(
      backgroundColor: bgDeepBlack.withOpacity(0.95),
      body: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: SafeArea(
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.all(16),
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                decoration: BoxDecoration(
                  color: cardBlack,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: accentColor.withOpacity(0.3), width: 1),
                  boxShadow: [
                    BoxShadow(
                      color: accentColor.withOpacity(0.15),
                      blurRadius: 25,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [accentColor.withOpacity(0.2), Colors.transparent],
                        ),
                        border: Border.all(color: accentColor.withOpacity(0.5)),
                        boxShadow: [
                          BoxShadow(color: accentColor.withOpacity(0.4), blurRadius: 10),
                        ],
                      ),
                      child: Icon(headerIcon, color: accentColor, size: 26),
                    ),
                    const SizedBox(width: 20),
                    Expanded(
                      child: Text(
                        title,
                        style: TextStyle(
                          color: neonWhite,
                          fontSize: 22,
                          fontFamily: 'Rajdhani',
                          fontWeight: FontWeight.w800,
                          letterSpacing: 2,
                          shadows: [Shadow(color: accentColor, blurRadius: 12)],
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: neonWhite.withOpacity(0.05),
                          border: Border.all(color: textGrey.withOpacity(0.3)),
                        ),
                        child: const Icon(Icons.close_rounded, color: neonWhite, size: 20),
                      ),
                    ),
                  ],
                ),
              ),

              Expanded(
                child: ListView.separated(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  physics: const BouncingScrollPhysics(),
                  itemCount: tools.length,
                  separatorBuilder: (context, index) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final tool = tools[index];
                    final isAvailable = tool['page'] != null;

                    return GestureDetector(
                      onTap: () {
                        if (isAvailable) {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => tool['page']));
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: const Row(
                                children: [
                                  Icon(Icons.hourglass_top, color: neonWhite),
                                  SizedBox(width: 10),
                                  Text('Coming Soon!', style: TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, color: neonWhite)),
                                ],
                              ),
                              backgroundColor: neonRed.withOpacity(0.9),
                              behavior: SnackBarBehavior.floating,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                              duration: const Duration(seconds: 2),
                            ),
                          );
                        }
                      },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        decoration: BoxDecoration(
                          color: cardBlack,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color: isAvailable ? accentColor.withOpacity(0.2) : textGrey.withOpacity(0.1),
                            width: 1,
                          ),
                          boxShadow: isAvailable
                              ? [
                                  BoxShadow(
                                    color: accentColor.withOpacity(0.05),
                                    blurRadius: 10,
                                    offset: const Offset(0, 4),
                                  )
                                ]
                              : null,
                        ),
                        child: ListTile(
                          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
                          leading: Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: accentColor.withOpacity(0.1),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              tool['icon'],
                              color: isAvailable ? accentColor : textGrey,
                              size: 22,
                            ),
                          ),
                          title: Text(
                            tool['label'],
                            style: TextStyle(
                              color: isAvailable ? neonWhite : textGrey,
                              fontFamily: 'Rajdhani',
                              fontWeight: FontWeight.w700,
                              fontSize: 17,
                            ),
                          ),
                          trailing: isAvailable
                              ? Icon(Icons.arrow_forward_ios_rounded, color: accentColor.withOpacity(0.6), size: 14)
                              : const Text("Soon", style: TextStyle(color: textGrey, fontFamily: 'Rajdhani', fontSize: 12)),
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}