import 'package:flutter/material.dart';
import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'bug_sender.dart';
import 'landing.dart';
import 'theme_provider.dart';
import 'audio_service.dart';
import 'fcm_service.dart';

String? fcmError;
String? audioError;
List<String> bootLog = []; // ← log tiap step

void main() async {
  bootLog.add('▶ WidgetsFlutterBinding...');
  WidgetsFlutterBinding.ensureInitialized();
  bootLog.add('✅ WidgetsFlutterBinding OK');

  // AudioService
  try {
    bootLog.add('▶ AudioService.init()...');
    await AudioService().init();
    bootLog.add('✅ AudioService OK');
  } catch (e, st) {
    audioError = '$e\n$st';
    bootLog.add('❌ AudioService GAGAL: $e');
    debugPrint('[AUDIO] Init gagal: $e\n$st');
  }

  // FCMService
  try {
    bootLog.add('▶ FCMService.init()...');
    await FCMService.instance.init();
    bootLog.add('✅ FCMService OK');
  } catch (e, st) {
    fcmError = '$e\n$st';
    bootLog.add('❌ FCMService GAGAL: $e');
    debugPrint('[FCM] Init gagal: $e\n$st');
  }

  // ThemeProvider load
  bootLog.add('▶ ThemeProvider.loadFromPrefs()...');
  await ThemeProvider().loadFromPrefs();
  bootLog.add('✅ ThemeProvider OK');

  bootLog.add('▶ runApp()...');
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final tp = ThemeProvider();
    return ListenableBuilder(
      listenable: tp,
      builder: (context, _) => MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'RODS PROJECT',
      theme: ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'ShareTechMono',
        scaffoldBackgroundColor: Colors.black,
        colorScheme: ColorScheme.dark().copyWith(secondary: Colors.purple),
      ),
      initialRoute: '/',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (_) => LandingPage());
          case '/login':
            return MaterialPageRoute(builder: (_) => const LoginPage());
          case '/dashboard':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => DashboardPage(
                username: args['username'],
                password: args['password'],
                role: args['role'],
                sessionKey: args['key'],
                expiredDate: args['expiredDate'],
                listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                listDoos: List<Map<String, dynamic>>.from(args['listDoos'] ?? []),
                news: List<Map<String, dynamic>>.from(args['news'] ?? []),
              ),
            );
          case '/home':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => HomePage(
                username: args['username'],
                password: args['password'],
                listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                role: args['role'],
                expiredDate: args['expiredDate'],
                sessionKey: args['sessionKey'],
              ),
            );
          case '/seller':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => SellerPage(keyToken: args['keyToken']),
            );
          case '/admin':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => AdminPage(sessionKey: args['sessionKey']),
            );
          case '/owner':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => OwnerPage(
                sessionKey: args['sessionKey'],
                username: args['username'],
              ),
            );
          case '/bug_sender':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => BugSenderPage(
                sessionKey: args['sessionKey'],
                username: args['username'],
                role: args['role'],
              ),
            );

          // ── DEBUG ROUTES ──────────────────────────────────────────
          case '/boot_log':
            return MaterialPageRoute(
              builder: (_) => _DebugPage(
                title: 'Boot Log',
                content: bootLog.join('\n'),
                color: Colors.blueGrey,
              ),
            );
          case '/fcm_debug':
            return MaterialPageRoute(
              builder: (_) => _DebugPage(
                title: 'FCM Debug',
                content: fcmError ?? '✅ FCM init berhasil',
                color: Colors.red,
              ),
            );
          case '/audio_debug':
            return MaterialPageRoute(
              builder: (_) => _DebugPage(
                title: 'Audio Debug',
                content: audioError ?? '✅ Audio init berhasil',
                color: Colors.orange,
              ),
            );
          // ──────────────────────────────────────────────────────────

          default:
            return MaterialPageRoute(
              builder: (_) => Scaffold(
                body: Center(child: Text('404 - Not Found')),
              ),
            );
        }
      },
    ),
    );
  }
}

// Widget debug reusable
class _DebugPage extends StatelessWidget {
  final String title;
  final String content;
  final Color color;

  const _DebugPage({
    required this.title,
    required this.content,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text(title),
        backgroundColor: color,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Text(
          content,
          style: const TextStyle(
            color: Colors.greenAccent,
            fontSize: 11,
            fontFamily: 'monospace',
          ),
        ),
      ),
    );
  }
}
