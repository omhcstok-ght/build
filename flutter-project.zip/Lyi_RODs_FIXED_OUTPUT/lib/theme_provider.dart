import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppTheme {
  final String name;
  final Color primary;
  final Color accent;
  final Color bg;
  final Color card;

  const AppTheme({
    required this.name,
    required this.primary,
    required this.accent,
    required this.bg,
    required this.card,
  });
}

class ThemeProvider extends ChangeNotifier {
  static final ThemeProvider _instance = ThemeProvider._();
  factory ThemeProvider() => _instance;
  ThemeProvider._();

  // Default: tema merah gelap original
  Color _primary = const Color(0xFF7A1419);
  Color _accent  = const Color(0xFFB71C2B);
  Color _bg      = const Color(0xFF050505);
  Color _card    = const Color(0xFF0F0F0F);

  Color get primary => _primary;
  Color get accent  => _accent;
  Color get bg      => _bg;
  Color get card    => _card;

  // Preset tema bawaan
  static const List<AppTheme> presets = [
    AppTheme(name: 'RODs Red',    primary: Color(0xFF7A1419), accent: Color(0xFFB71C2B), bg: Color(0xFF050505), card: Color(0xFF0F0F0F)),
    AppTheme(name: 'Neon Purple', primary: Color(0xFF6A0080), accent: Color(0xFFD500F9), bg: Color(0xFF080010), card: Color(0xFF120020)),
    AppTheme(name: 'Cyber Cyan',  primary: Color(0xFF006978), accent: Color(0xFF00E5FF), bg: Color(0xFF000D10), card: Color(0xFF001520)),
    AppTheme(name: 'Neon Green',  primary: Color(0xFF1B5E20), accent: Color(0xFF76FF03), bg: Color(0xFF020A02), card: Color(0xFF071007)),
    AppTheme(name: 'Gold Hacker', primary: Color(0xFF8D6E00), accent: Color(0xFFFFAB00), bg: Color(0xFF0A0800), card: Color(0xFF120F00)),
    AppTheme(name: 'Toxic Pink',  primary: Color(0xFF880E4F), accent: Color(0xFFFF4081), bg: Color(0xFF0A0005), card: Color(0xFF150010)),
    AppTheme(name: 'Ice Blue',    primary: Color(0xFF0D47A1), accent: Color(0xFF2979FF), bg: Color(0xFF00050F), card: Color(0xFF000C1E)),
    AppTheme(name: 'All Black',   primary: Color(0xFF222222), accent: Color(0xFF555555), bg: Color(0xFF000000), card: Color(0xFF0A0A0A)),
  ];

  Future<void> loadFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    _primary = Color(prefs.getInt('theme_primary') ?? 0xFF7A1419);
    _accent  = Color(prefs.getInt('theme_accent')  ?? 0xFFB71C2B);
    _bg      = Color(prefs.getInt('theme_bg')      ?? 0xFF050505);
    _card    = Color(prefs.getInt('theme_card')     ?? 0xFF0F0F0F);
    notifyListeners();
  }

  Future<void> applyPreset(AppTheme theme) async {
    _primary = theme.primary;
    _accent  = theme.accent;
    _bg      = theme.bg;
    _card    = theme.card;
    await _save();
    notifyListeners();
  }

  Future<void> applyCustom({
    required Color primary,
    required Color accent,
  }) async {
    _primary = primary;
    _accent  = accent;
    // bg & card derived dari primary (lebih gelap)
    _bg   = Color.fromARGB(255,
      (_primary.red   * 0.05).round(),
      (_primary.green * 0.05).round(),
      (_primary.blue  * 0.05).round(),
    );
    _card = Color.fromARGB(255,
      (_primary.red   * 0.12).round(),
      (_primary.green * 0.12).round(),
      (_primary.blue  * 0.12).round(),
    );
    await _save();
    notifyListeners();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('theme_primary', _primary.value);
    await prefs.setInt('theme_accent',  _accent.value);
    await prefs.setInt('theme_bg',      _bg.value);
    await prefs.setInt('theme_card',    _card.value);
  }
}
