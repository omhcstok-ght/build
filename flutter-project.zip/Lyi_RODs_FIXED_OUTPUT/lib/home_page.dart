import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'config.dart';
import 'theme_provider.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  ThemeProvider get tp => ThemeProvider();

  final targetController = TextEditingController();
  late AnimationController _fadeController;
  late AnimationController _pulseController;
  String selectedBugId = "";

  // --- State Baru: Mode Target dan Mode Sender ---
  String _selectedBugMode = "number";
  String _selectedSenderType = "private"; // "private" atau "global"

  // Data senders
  List<dynamic> _privateSenders = [];
  List<dynamic> _globalSenders = [];
  bool _isLoadingSenders = false;
  String? _sendersError;

  bool _isSending = false;
  String? _responseMessage;

  // --- Tema Baru: Elegant Black Glassmorphism ---
  static const Color glassBg = Color(0x12121212);
  static const Color glassBorder = Color(0x33FFFFFF);
  static const Color textWhite = Colors.white;
  static const Color textGrey = Color(0xFFB0B0B0);

  final LinearGradient accentGradient = const LinearGradient(
    colors: [Color(0xFFFF1744), Color(0xFFD50000)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // Video Player Variables
  late VideoPlayerController _videoController;
  late ChewieController _chewieController;
  bool _isVideoInitialized = false;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _pulseController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }

    _initializeVideoPlayer();
    _fetchSenders();
  }

  void _initializeVideoPlayer() {
    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4');

    _videoController
        .initialize()
        .then((_) {
          setState(() {
            _videoController.setVolume(0.1);
            _chewieController = ChewieController(
              videoPlayerController: _videoController,
              autoPlay: true,
              looping: true,
              showControls: false,
              autoInitialize: true,
            );
            _isVideoInitialized = true;
          });
        })
        .catchError((error) {
          print("Video initialization error: $error");
          setState(() {
            _isVideoInitialized = false;
          });
        });
  }

  Future<void> _fetchSenders() async {
    setState(() {
      _isLoadingSenders = true;
      _sendersError = null;
    });

    try {
      // Fetch private senders
      final privateResponse = await http.get(
        Uri.parse("${ApiConfig.baseUrl}/mySender?key=${widget.sessionKey}"),
        headers: {'Content-Type': 'application/json'},
      );

      // Fetch global senders
      final globalResponse = await http.get(
        Uri.parse(
          "${ApiConfig.baseUrl}/globalSenders?key=${widget.sessionKey}",
        ),
        headers: {'Content-Type': 'application/json'},
      );

      if (privateResponse.statusCode == 200) {
        final privateData = jsonDecode(privateResponse.body);
        if (privateData["valid"] == true) {
          setState(() {
            _privateSenders = privateData["connections"] ?? [];
          });
        }
      }

      if (globalResponse.statusCode == 200) {
        final globalData = jsonDecode(globalResponse.body);
        if (globalData["valid"] == true) {
          setState(() {
            _globalSenders = globalData["connections"] ?? [];
          });
        }
      }
    } catch (e) {
      setState(() {
        _sendersError = "Failed to load senders: $e";
      });
    } finally {
      setState(() {
        _isLoadingSenders = false;
      });
    }
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _pulseController.dispose();
    targetController.dispose();
    _videoController.dispose();
    _chewieController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  int getActiveSenderCount() {
    if (_selectedSenderType == "private") {
      return _privateSenders.length;
    } else {
      return _globalSenders.length;
    }
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    // Cek apakah ada sender aktif
    if (getActiveSenderCount() == 0) {
      _showAlert(
        "⚠️ Tidak Ada Sender",
        "${_selectedSenderType == "private" ? "Private" : "Global"} sender tidak tersedia.\n\nTambahkan sender terlebih dahulu di menu Manage Bug Sender.",
      );
      return;
    }

    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert(
          "⚠️ Peringatan",
          "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.",
        );
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert(
          "⚠️ Peringatan",
          "Masukkan link group WA yang valid (contoh: https://chat.whatsapp.com/...).",
        );
        return;
      }
    }

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });

    try {
      // Kirim dengan parameter senderType
      final res = await http.get(
        Uri.parse(
          "${ApiConfig.baseUrl}/sendBug?key=$key&target=$rawInput&bug=$selectedBugId&senderType=${_selectedSenderType}",
        ),
      );
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        setState(
          () => _responseMessage = "⏳ Cooldown: Tunggu ${data['wait']} detik.",
        );
      } else if (data["valid"] == false) {
        setState(
          () => _responseMessage = "❌ Key Invalid: Silakan login ulang.",
        );
      } else if (data["sended"] == false) {
        setState(
          () => _responseMessage = "⚠️ Gagal: Server sedang maintenance.",
        );
      } else {
        setState(
          () => _responseMessage =
              "✅ Berhasil mengirim bug menggunakan ${_selectedSenderType == "private" ? "Private" : "Global"} sender!",
        );
        targetController.clear();
      }
    } catch (_) {
      setState(
        () => _responseMessage = "❌ Error: Terjadi kesalahan. Coba lagi.",
      );
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Color(0xFF1A1A1A),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: tp.accent, width: 1),
        ),
        title: Text(
          title,
          style: TextStyle(
            color: tp.accent,
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Text(msg, style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: tp.accent)),
          ),
        ],
      ),
    );
  }

  void _navigateToBugSender() {
    Navigator.pushNamed(
      context,
      '/bug_sender',
      arguments: {
        'sessionKey': widget.sessionKey,
        'username': widget.username,
        'role': widget.role,
      },
    ).then((_) => _fetchSenders()); // Refresh senders when coming back
  }

  BoxDecoration _glassBoxDecoration({double borderRadius = 20}) {
    return BoxDecoration(
      color: glassBg,
      borderRadius: BorderRadius.circular(borderRadius),
      border: Border.all(color: glassBorder, width: 1),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.4),
          blurRadius: 20,
          offset: const Offset(0, 10),
        ),
      ],
    );
  }

  Widget _buildHeaderPanel() {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: _glassBoxDecoration(),
      child: Row(
        children: [
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: accentGradient,
              boxShadow: [
                BoxShadow(
                  color: tp.accent.withOpacity(0.4),
                  blurRadius: 15,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: CircleAvatar(
              radius: 28,
              backgroundColor: Colors.transparent,
              backgroundImage: const AssetImage('assets/images/logo.png'),
            ),
          ),
          SizedBox(width: 20),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.username,
                  style: TextStyle(
                    color: textWhite,
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5,
                  ),
                ),
                SizedBox(height: 6),
                Row(
                  children: [
                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: tp.accent.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: tp.accent.withOpacity(0.3)),
                      ),
                      child: Text(
                        widget.role.toUpperCase(),
                        style: TextStyle(
                          color: tp.accent,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      "Exp: ${widget.expiredDate}",
                      style: const TextStyle(
                        color: textGrey,
                        fontSize: 12,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoPlayer() {
    if (!_isVideoInitialized) {
      return Container(
        width: double.infinity,
        height: 180,
        margin: EdgeInsets.symmetric(vertical: 20),
        decoration: _glassBoxDecoration(),
        child: Center(
          child: CircularProgressIndicator(color: tp.accent, strokeWidth: 2),
        ),
      );
    }

    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(vertical: 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: tp.accent.withOpacity(0.2),
            blurRadius: 20,
            spreadRadius: 1,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: AspectRatio(
          aspectRatio: _videoController.value.aspectRatio,
          child: Stack(
            children: [
              Chewie(controller: _chewieController),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.transparent, Colors.black.withOpacity(0.3)],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildModeSelector() {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: glassBorder),
      ),
      child: Row(
        children: [
          _buildModeItem(
            label: "NOMOR",
            icon: Icons.phone_iphone_rounded,
            isSelected: _selectedBugMode == "number",
            onTap: () {
              setState(() {
                _selectedBugMode = "number";
                targetController.clear();
              });
            },
          ),
          _buildModeItem(
            label: "GROUP",
            icon: Icons.group_work_rounded,
            isSelected: _selectedBugMode == "group",
            onTap: () {
              setState(() {
                _selectedBugMode = "group";
                targetController.clear();
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _buildModeItem({
    required String label,
    required IconData icon,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: Duration(milliseconds: 300),
          padding: EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? tp.accent : Colors.transparent,
            borderRadius: BorderRadius.circular(10),
            boxShadow: isSelected
                ? [
                    BoxShadow(
                      color: tp.accent.withOpacity(0.4),
                      blurRadius: 10,
                    ),
                  ]
                : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: isSelected ? Colors.white : textGrey, size: 18),
              const SizedBox(width: 8),
              Text(
                label,
                style: TextStyle(
                  color: isSelected ? Colors.white : textGrey,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHorizontalBugSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 4, bottom: 12),
          child: Text(
            "SELECT BUG PAYLOAD",
            style: TextStyle(
              color: textGrey,
              fontSize: 12,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.5,
            ),
          ),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          child: Row(
            children: widget.listBug.map((bug) {
              final bool isSelected = selectedBugId == bug['bug_id'];
              return Padding(
                padding: const EdgeInsets.only(right: 10),
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      selectedBugId = bug['bug_id'];
                    });
                  },
                  child: AnimatedContainer(
                    duration: Duration(milliseconds: 200),
                    padding: EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 12,
                    ),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? tp.accent
                          : Colors.black.withOpacity(0.4),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isSelected ? tp.accent : glassBorder,
                        width: 1,
                      ),
                      boxShadow: isSelected
                          ? [
                              BoxShadow(
                                color: tp.accent.withOpacity(0.3),
                                blurRadius: 8,
                              ),
                            ]
                          : null,
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.bug_report_rounded,
                          color: isSelected ? Colors.white : textGrey,
                          size: 16,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          bug['bug_name'],
                          style: TextStyle(
                            color: isSelected ? Colors.white : textGrey,
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  // ==================== NEW: SENDER SELECTOR WIDGET ====================
  Widget _buildSenderSelector() {
    final int privateCount = _privateSenders.length;
    final int globalCount = _globalSenders.length;
    final bool isPrivateSelected = _selectedSenderType == "private";
    final bool isGlobalSelected = _selectedSenderType == "global";

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 4, bottom: 12),
          child: Text(
            "PILIH SENDER",
            style: TextStyle(
              color: textGrey,
              fontSize: 12,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.5,
            ),
          ),
        ),
        Row(
          children: [
            // Private Sender Button
            Expanded(
              child: GestureDetector(
                onTap: () {
                  setState(() {
                    _selectedSenderType = "private";
                  });
                },
                child: AnimatedContainer(
                  duration: Duration(milliseconds: 200),
                  padding: EdgeInsets.symmetric(vertical: 16),
                  decoration: BoxDecoration(
                    gradient: isPrivateSelected ? accentGradient : null,
                    color: isPrivateSelected
                        ? null
                        : Colors.black.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: isPrivateSelected ? tp.accent : glassBorder,
                      width: 1.5,
                    ),
                    boxShadow: isPrivateSelected
                        ? [
                            BoxShadow(
                              color: tp.accent.withOpacity(0.3),
                              blurRadius: 12,
                            ),
                          ]
                        : null,
                  ),
                  child: Column(
                    children: [
                      Icon(
                        Icons.person,
                        color: isPrivateSelected ? Colors.white : textGrey,
                        size: 28,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "PRIVATE",
                        style: TextStyle(
                          color: isPrivateSelected ? Colors.white : textGrey,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          letterSpacing: 1,
                        ),
                      ),
                      SizedBox(height: 4),
                      Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: isPrivateSelected
                              ? Colors.white.withOpacity(0.2)
                              : tp.accent.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          "$privateCount Aktif",
                          style: TextStyle(
                            color: isPrivateSelected
                                ? Colors.white
                                : tp.accent,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            // Global Sender Button
            Expanded(
              child: GestureDetector(
                onTap: () {
                  setState(() {
                    _selectedSenderType = "global";
                  });
                },
                child: AnimatedContainer(
                  duration: Duration(milliseconds: 200),
                  padding: EdgeInsets.symmetric(vertical: 16),
                  decoration: BoxDecoration(
                    gradient: isGlobalSelected ? accentGradient : null,
                    color: isGlobalSelected
                        ? null
                        : Colors.black.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: isGlobalSelected ? tp.accent : glassBorder,
                      width: 1.5,
                    ),
                    boxShadow: isGlobalSelected
                        ? [
                            BoxShadow(
                              color: tp.accent.withOpacity(0.3),
                              blurRadius: 12,
                            ),
                          ]
                        : null,
                  ),
                  child: Column(
                    children: [
                      Icon(
                        Icons.public,
                        color: isGlobalSelected ? Colors.white : textGrey,
                        size: 28,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "GLOBAL",
                        style: TextStyle(
                          color: isGlobalSelected ? Colors.white : textGrey,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          letterSpacing: 1,
                        ),
                      ),
                      SizedBox(height: 4),
                      Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: isGlobalSelected
                              ? Colors.white.withOpacity(0.2)
                              : tp.accent.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          globalCount == 0 ? "Tidak Ada" : "$globalCount Aktif",
                          style: TextStyle(
                            color: isGlobalSelected ? Colors.white : tp.accent,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
        // Manage Sender Button
        const SizedBox(height: 12),
        GestureDetector(
          onTap: _navigateToBugSender,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.3),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: glassBorder),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.settings, color: textGrey, size: 16),
                SizedBox(width: 8),
                Text(
                  "KELOLA SENDER",
                  style: TextStyle(
                    color: textGrey,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildInputPanel() {
    return Container(
      padding: EdgeInsets.all(24),
      decoration: _glassBoxDecoration(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // 1. MODE SELECTOR (Number/Group)
          _buildModeSelector(),
          SizedBox(height: 30),

          // 2. INPUT TARGET
          TextField(
            controller: targetController,
            style: TextStyle(color: Colors.white, fontSize: 16),
            cursorColor: tp.accent,
            keyboardType: _selectedBugMode == "number"
                ? TextInputType.phone
                : TextInputType.url,
            decoration: InputDecoration(
              hintText: _selectedBugMode == "number"
                  ? "Masukkan Nomor Target (+62...)"
                  : "Masukkan Link Group WhatsApp",
              hintStyle: TextStyle(color: textGrey.withOpacity(0.4)),
              filled: true,
              fillColor: Colors.black.withOpacity(0.2),
              contentPadding: EdgeInsets.symmetric(
                vertical: 20,
                horizontal: 20,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide(color: glassBorder),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide(color: tp.accent, width: 2),
              ),
              prefixIcon: Icon(
                _selectedBugMode == "number"
                    ? Icons.call_rounded
                    : Icons.link_rounded,
                color: tp.accent,
              ),
            ),
          ),
          SizedBox(height: 30),

          // 3. HORIZONTAL BUG SELECTOR
          _buildHorizontalBugSelector(),

          SizedBox(height: 30),

          // 4. SENDER SELECTOR (NEW)
          if (_isLoadingSenders)
            Padding(
              padding: EdgeInsets.symmetric(vertical: 20),
              child: Center(
                child: CircularProgressIndicator(
                  color: tp.accent,
                  strokeWidth: 2,
                ),
              ),
            )
          else
            _buildSenderSelector(),
        ],
      ),
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return GestureDetector(
          onTap: _isSending ? null : _sendBug,
          child: Container(
            height: 70,
            width: double.infinity,
            decoration: BoxDecoration(
              gradient: accentGradient,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: tp.accent.withOpacity(
                    0.4 + (_pulseController.value * 0.2),
                  ),
                  blurRadius: 25 + (_pulseController.value * 10),
                  spreadRadius: _pulseController.value * 2,
                ),
              ],
            ),
            child: Center(
              child: _isSending
                  ? const SizedBox(
                      height: 28,
                      width: 28,
                      child: CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 3,
                      ),
                    )
                  : const Text(
                      "EXECUTE",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2.5,
                      ),
                    ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();

    Color msgColor;
    IconData msgIcon;

    if (_responseMessage!.startsWith('✅')) {
      msgColor = Colors.greenAccent;
      msgIcon = Icons.check_circle_outline;
    } else if (_responseMessage!.startsWith('❌')) {
      msgColor = Colors.redAccent;
      msgIcon = Icons.error_outline;
    } else {
      msgColor = Colors.orangeAccent;
      msgIcon = Icons.info_outline;
    }

    return Container(
      margin: const EdgeInsets.only(top: 20),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.6),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: msgColor.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(msgIcon, color: msgColor, size: 24),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _responseMessage!,
              style: TextStyle(
                color: msgColor,
                fontWeight: FontWeight.w600,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: tp.bg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Column(
            children: [
              _buildHeaderPanel(),
              const SizedBox(height: 25),
              _buildVideoPlayer(),
              const SizedBox(height: 25),
              _buildInputPanel(),
              const SizedBox(height: 30),
              _buildSendButton(),
              _buildResponseMessage(),
            ],
          ),
        ),
      ),
    );
  }
}
