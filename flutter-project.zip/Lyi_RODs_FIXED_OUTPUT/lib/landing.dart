import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'audio_service.dart' as bg;
import 'main.dart' show fcmError, bootLog; // ← import debug vars
import 'theme_provider.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  ThemeProvider get tp => ThemeProvider();

  late AnimationController _fadeController;
  late AnimationController _floatController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _floatAnimation;

  int _tapCount = 0; // debug tap counter
  static const String _kFontFamily = 'Rajdhani';



  @override
  void initState() {
    super.initState();
    bg.AudioService().pause();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeOut),
    );

    _floatController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat(reverse: true);
    _floatAnimation = Tween<double>(begin: -5, end: 5).animate(
      CurvedAnimation(parent: _floatController, curve: Curves.easeInOut),
    );

    _fadeController.forward();

    // ← Tampilkan FCM error sebagai snackbar kalau ada
    if (fcmError != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('FCM Error (tap untuk detail): ${fcmError!.substring(0, fcmError!.length.clamp(0, 80))}...'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 10),
            action: SnackBarAction(
              label: 'Detail',
              textColor: Colors.white,
              onPressed: () => Navigator.pushNamed(context, '/fcm_debug'),
            ),
          ),
        );
      });
    }
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _floatController.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      debugPrint("Could not launch $uri");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: tp.bg,
        body: Stack(
          children: [
            _buildAmbientGlow(),
            Center(
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(height: 60),
                      GestureDetector(
                        onTap: () {
                          _tapCount++;
                          if (_tapCount >= 5) {
                            _tapCount = 0;
                            Navigator.pushNamed(context, '/boot_log');
                          }
                        },
                        child: _buildHeroImageFixed(),
                      ),
                      const SizedBox(height: 35),
                      Text(
                        "RODS PROJECT",
                        style: TextStyle(
                          fontFamily: _kFontFamily,
                          fontSize: 52,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 10,
                          color: Colors.white,
                          height: 1.0,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        "PREMIUM DIGITAL ACCESS",
                        style: TextStyle(
                          fontFamily: _kFontFamily,
                          fontSize: 13,
                          letterSpacing: 4,
                          color: tp.accent,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 45),
                      _buildGlassPanel(),
                      const SizedBox(height: 30),
                      Text(
                        "SECURE • PRIVATE • EXCLUSIVE",
                        style: TextStyle(
                          fontFamily: _kFontFamily,
                          fontSize: 10,
                          letterSpacing: 2,
                          color: Colors.white.withOpacity(0.4),
                        ),
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
    );
  }

  Widget _buildAmbientGlow() {
    return Stack(
      children: [
        Positioned(
          top: -50,
          left: -50,
          child: Container(
            width: 300,
            height: 300,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [tp.accent.withOpacity(0.25), Colors.transparent],
              ),
            ),
          ),
        ),
        Positioned(
          bottom: -50,
          right: -50,
          child: Container(
            width: 350,
            height: 350,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [const Color(0xFF1A0B2E).withOpacity(0.4), Colors.transparent],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildHeroImageFixed() {
    return AnimatedBuilder(
      animation: _floatAnimation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, _floatAnimation.value),
          child: Container(
            width: 240,
            height: 240,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.8),
                  spreadRadius: 5,
                  blurRadius: 20,
                ),
                BoxShadow(
                  color: tp.accent.withOpacity(0.3),
                  blurRadius: 40,
                  spreadRadius: 0,
                )
              ],
            ),
            child: ClipOval(
              child: Image.asset("assets/images/reze.png", fit: BoxFit.cover),
            ),
          ),
        );
      },
    );
  }

  Widget _buildGlassPanel() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 25, sigmaY: 25),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.04),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white.withOpacity(0.1), width: 1),
          ),
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: tp.accent,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    elevation: 0,
                  ).copyWith(overlayColor: MaterialStateProperty.all(Colors.white24)),
                  onPressed: () => Navigator.pushNamed(context, "/login"),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("LOGIN", style: TextStyle(fontFamily: _kFontFamily, fontSize: 16, fontWeight: FontWeight.w700, letterSpacing: 2)),
                      const SizedBox(width: 10),
                      const FaIcon(FontAwesomeIcons.arrowRight, size: 14)
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.white,
                    side: BorderSide(color: Colors.white.withOpacity(0.2)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () => _openUrl("https://t.me/xxfanz"),
                  child: Text("BUY ACCESS", style: TextStyle(fontFamily: _kFontFamily, fontSize: 15, fontWeight: FontWeight.w600, letterSpacing: 1.5, color: Colors.white70)),
                ),
              ),
              const SizedBox(height: 20),
              Container(
                height: 1,
                margin: const EdgeInsets.symmetric(horizontal: 10),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [Colors.transparent, Colors.white.withOpacity(0.2), Colors.transparent]),
                ),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(child: _socialBtn(FontAwesomeIcons.telegram, "Telegram", const Color(0xFF229ED9), "https://t.me/xxfanz")),
                  const SizedBox(width: 10),
                  Expanded(child: _socialBtn(FontAwesomeIcons.whatsapp, "WhatsApp", const Color(0xFF25D366), "https://wa.me/62882021831732")),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _socialBtn(IconData icon, String label, Color color, String url) {
    return InkWell(
      onTap: () => _openUrl(url),
      borderRadius: BorderRadius.circular(10),
      child: Container(
        height: 48,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.white.withOpacity(0.08)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(icon, color: color, size: 16),
            const SizedBox(width: 8),
            Text(label, style: TextStyle(fontFamily: _kFontFamily, color: Colors.white70, fontWeight: FontWeight.w600, fontSize: 13)),
          ],
        ),
      ),
    );
  }
}
