import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'theme_provider.dart';

// --- KONFIGURASI BACKEND ---
const String _baseUrl = "https://herganteng.ryuuuprv.my.id:3652/api";
// Catatan: Jika run di HP Asli (bukan emulator), ganti IP dengan IP Laptop Anda (misal: 192.168.1.5)

class OrderNokosPage extends StatefulWidget {
  const OrderNokosPage({super.key});

  @override
  State<OrderNokosPage> createState() => _OrderNokosPageState();
}

class _OrderNokosPageState extends State<OrderNokosPage>
    with TickerProviderStateMixin {
  ThemeProvider get tp => ThemeProvider();
  // --- FORM CONTROLLERS ---
  final _formKey = GlobalKey<FormState>();
  final _serviceController = TextEditingController(
    text: "wa",
  ); // Default WhatsApp
  final _countryController = TextEditingController(
    text: "6",
  ); // Default Indonesia

  // --- STATE VARIABLES ---
  bool _isLoading = false;
  bool _isWaitingOtp = false;

  String _currentOrderId = "";
  String _phoneNumberDisplay = "-";
  String _statusMessage = "Siap untuk memesan nomor";
  String _otpCode = "";

  // --- ANIMATION CONTROLLER (Untuk efek loading menarik) ---
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    // Setup animasi pulse untuk status "Menunggu OTP"
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    )..repeat(reverse: true);

    _pulseAnimation = Tween<double>(begin: 0.8, end: 1.2).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _serviceController.dispose();
    _countryController.dispose();
    super.dispose();
  }

  // --- FUNGSI: KIRIM ORDER KE BACKEND ---
  Future<void> _submitOrder() async {
    // Tutup keyboard
    FocusScope.of(context).unfocus();

    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
      _statusMessage = "Menghubungi Server...";
      _isWaitingOtp = false;
      _otpCode = "";
    });

    try {
      final response = await http
          .post(
            Uri.parse('$_baseUrl/order'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'service': _serviceController.text.trim().toLowerCase(),
              'country': _countryController.text.trim(),
              'operator': 'any', // Biarkan sistem memilih operator
            }),
          )
          .timeout(const Duration(seconds: 15)); // Timeout 15 detik

      final data = json.decode(response.body);

      if (response.statusCode == 200 && data['status'] == true) {
        // SUKSES ORDER
        String id = data['data']['id'] ?? data['data']['activation_id'];
        String phone = data['data']['phone_number'] ?? data['data']['number'];

        setState(() {
          _isLoading = false;
          _isWaitingOtp = true;
          _currentOrderId = id;
          _phoneNumberDisplay = phone;
          _statusMessage = "Menunggu SMS Masuk...";
        });

        setState(() {
          _isLoading = false;
          _isWaitingOtp = true;
          _currentOrderId = id;
          _phoneNumberDisplay = phone;
          _statusMessage = "Menunggu SMS Masuk...";
        });

        _showSuccessSnackBar("Order Berhasil! Nomor: $phone");
      } else {
        // GAGAL ORDER
        _handleError(data['message'] ?? "Gagal memesan nomor.");
      }
    } catch (e) {
      _handleError("Koneksi gagal. Cek internet Anda.");
    }
  }

  // --- FUNGSI: UPDATE STATUS DARI SOCKET (REAL-TIME) ---
  // Method ini akan dipanggil oleh Parent (MainScreen) saat ada event dari server
  void updateOtpStatus(Map<String, dynamic> data) {
    // Pastikan update ini untuk order yang SEDANG aktif di layar ini
    if (data['id'] == _currentOrderId) {
      setState(() {
        if (data['status'] == 'STATUS_OK' || data['status'] == 'SUCCESS') {
          // OTP MASUK
          _isWaitingOtp = false;
          _statusMessage = "OTP Diterima!";
          _otpCode = data['otp_code'] ?? data['sms'] ?? "Kode tidak terbaca";

          // Berhentikan animasi pulse
          _pulseController.stop();
          _pulseController.reset();

          // Efek suara atau getar bisa ditambahkan disini
        } else if (data['status'] == 'CANCEL') {
          _isWaitingOtp = false;
          _statusMessage = "Order Dibatalkan";
          _pulseController.stop();
        } else {
          // Status lain (Pending, Processing)
          _statusMessage = "Status: ${data['status']}";
        }
      });
    }
  }

  void _handleError(String message) {
    setState(() {
      _isLoading = false;
      _isWaitingOtp = false;
      _statusMessage = message;
    });
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: Colors.red, content: Text(message)),
      );
    }
  }

  void _showSuccessSnackBar(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: Colors.green, content: Text(message)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // --- TEMA WARNA ---
  final Color cardColor = const Color(0xFF1E1E1E);

    return Scaffold(
      backgroundColor: const Color(0xFF050505),
      appBar: AppBar(
        title: const Text(
          "ORDER NOKOS",
          style: TextStyle(
            fontFamily: 'Rajdhani',
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            onPressed: () {
              // TODO: Navigasi ke halaman riwayat
            },
          ),
        ],
      ),
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // --- 1. STATUS CARD (LIVE UPDATE) ---
                _buildStatusCard(cardColor, tp.primary),

                const SizedBox(height: 30),

                // --- 2. INPUT LAYANAN ---
                _buildInputField(
                  label: "KODE LAYANAN",
                  controller: _serviceController,
                  hint: "Contoh: wa (WhatsApp), tg (Telegram)",
                  icon: Icons.apps,
                ),

                const SizedBox(height: 20),

                // --- 3. INPUT NEGARA ---
                _buildInputField(
                  label: "KODE NEGARA",
                  controller: _countryController,
                  hint: "Contoh: 6 (Indonesia)",
                  icon: Icons.public,
                  keyboardType: TextInputType.number,
                ),

                const SizedBox(height: 40),

                // --- 4. TOMBOL AKSI ---
                SizedBox(
                  width: double.infinity,
                  height: 65,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _submitOrder,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: tp.primary,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      elevation: _isLoading ? 0 : 8,
                      shadowColor: tp.primary.withOpacity(0.4),
                    ),
                    child: _isLoading
                        ? const SizedBox(
                            width: 30,
                            height: 30,
                            child: CircularProgressIndicator(
                              color: Colors.black,
                              strokeWidth: 3,
                            ),
                          )
                        : Text(
                            "ORDER SEKARANG",
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Rajdhani',
                              letterSpacing: 1.2,
                            ),
                          ),
                  ),
                ),

                const SizedBox(height: 20),

                // Info Helper
                Center(
                  child: Text(
                    "Pastikan saldo mencukupi sebelum order.",
                    style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // --- WIDGET: STATUS CARD ---
  Widget _buildStatusCard(Color cardColor, Color primaryColor) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: _isWaitingOtp ? tp.primary : Colors.white10,
          width: 1.5,
        ),
        boxShadow: [
          if (_isWaitingOtp)
            BoxShadow(
              color: tp.primary.withOpacity(0.2),
              blurRadius: 15,
              spreadRadius: 2,
            ),
        ],
      ),
      child: Column(
        children: [
          // Header Status
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "STATUS AKTIVASI",
                style: TextStyle(
                  color: Colors.grey.shade400,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.0,
                ),
              ),
              if (_isWaitingOtp)
                ScaleTransition(
                  scale: _pulseAnimation,
                  child: Icon(Icons.sync, color: tp.primary, size: 20),
                )
              else
                Icon(
                  _otpCode.isNotEmpty ? Icons.check_circle : Icons.info_outline,
                  color: _otpCode.isNotEmpty
                      ? tp.primary
                      : Colors.grey.shade500,
                  size: 20,
                ),
            ],
          ),
          const Divider(height: 20, color: Colors.white10),

          // Isi Status
          if (_phoneNumberDisplay != "-" && _phoneNumberDisplay.isNotEmpty)
            Column(
              children: [
                Text(
                  "NOMOR TUJUAN",
                  style: TextStyle(color: Colors.grey.shade500, fontSize: 11),
                ),
                const SizedBox(height: 4),
                Text(
                  _phoneNumberDisplay,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Rajdhani',
                  ),
                ),
                const SizedBox(height: 15),
              ],
            ),

          Text(
            _statusMessage,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _isWaitingOtp ? tp.primary : Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
          ),

          const SizedBox(height: 15),

          // TAMPILAN KODE OTP (Jika SUDAH MASUK)
          if (_otpCode.isNotEmpty) ...[
            Container(
              padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
              decoration: BoxDecoration(
                color: tp.primary.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: tp.primary),
              ),
              child: Column(
                children: [
                  Text(
                    "KODE OTP ANDA",
                    style: TextStyle(
                      color: tp.primary,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _otpCode,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 36,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 5,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Text(
              "Salin kode di atas untuk verifikasi.",
              style: TextStyle(color: Colors.grey.shade500, fontSize: 11),
            ),
          ],
        ],
      ),
    );
  }

  // --- WIDGET: INPUT FIELD REUSABLE ---
  Widget _buildInputField({
    required String label,
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    TextInputType? keyboardType,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          keyboardType: keyboardType ?? TextInputType.text,
          style: const TextStyle(color: Colors.white, fontSize: 16),
          decoration: InputDecoration(
            filled: true,
            fillColor: const Color(0xFF121212),
            hintText: hint,
            hintStyle: TextStyle(color: Colors.grey.shade600),
            prefixIcon: Icon(icon, color: Colors.grey.shade400),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: const Color(0xFF00E676), width: 2),
            ),
            contentPadding: const EdgeInsets.symmetric(
              vertical: 18,
              horizontal: 20,
            ),
          ),
          validator: (value) {
            if (value == null || value.trim().isEmpty) {
              return "Field ini wajib diisi";
            }
            return null;
          },
        ),
      ],
    );
  }
}
