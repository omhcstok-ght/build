import 'dart:math';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class _C {
  // Pure Deep Black Background (Mirip Spotify OLED Mode)
  static const bg       = Color(0xFF000000);
  static const surface  = Color(0xFF121212);
  static const elevated = Color(0xFF1E1E1E);
  static const border   = Color(0xFF282828);
  
  // Aesthetic Neon Accents
  static const accent   = Color(0xFF1DB954); // Spotify Green
  
  // Text Hierarchy (High Contrast)
  static const textP    = Color(0xFFFFFFFF); // Primary Text
  static const textS    = Color(0xFFB3B3B3); // Secondary Text
  static const textM    = Color(0xFF6E6E6E); // Muted Text
}

class MusikPage extends StatefulWidget {
  final AudioPlayer? sharedPlayer;
  final int? initialTrack;
  const MusikPage({super.key, this.sharedPlayer, this.initialTrack});

  @override
  State<MusikPage> createState() => _MusikPageState();
}

class _MusikPageState extends State<MusikPage> {
  late AudioPlayer _player;
  final _searchCtrl = TextEditingController();

  bool _playing    = false;
  bool _shuffle    = false;
  bool _repeat     = false;
  Duration _pos    = Duration.zero;
  Duration _dur    = Duration.zero;

  List<Map<String, dynamic>> _results = [];
  bool _searching  = false;
  String _errMsg   = '';

  Map<String, dynamic>? _nowPlaying;

  @override
  void initState() {
    super.initState();
    _player = widget.sharedPlayer ?? AudioPlayer();
    
    // SETUP BACKGROUND PLAYING (Fix 100% untuk audioplayers versi 6.1.0)
    // Pada versi terbaru, parameter iOS sudah dihapus total dari sini.
    // Konfigurasi iOS cukup dari Info.plist (UIBackgroundModes: audio).
    _player.setAudioContext(AudioContext(
      android: AudioContextAndroid(
        isSpeakerphoneOn: false,
        stayAwake: true, // Wajib agar tidak mati saat layar locked (Android)
      ),
    ));

    _player.onPlayerStateChanged.listen((s) {
      if (mounted) setState(() => _playing = s == PlayerState.playing);
    });
    _player.onPositionChanged.listen((d) {
      if (mounted) setState(() => _pos = d);
    });
    _player.onDurationChanged.listen((d) {
      if (mounted) setState(() => _dur = d);
    });
    _player.onPlayerComplete.listen((_) => _nextTrack());

    _search('Top Hits 2024');
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    if (widget.sharedPlayer == null) _player.dispose();
    super.dispose();
  }

  Future<void> _search(String query) async {
    if (query.trim().isEmpty) return;
    setState(() {
      _searching = true;
      _errMsg = '';
    });
    try {
      final url = Uri.parse(
        'https://itunes.apple.com/search?term=${Uri.encodeComponent(query)}&media=music&limit=30&entity=song'
      );
      final res = await http.get(url).timeout(Duration(seconds: 10));
      final data = jsonDecode(res.body);
      final list = (data['results'] as List).map((t) => {
        'title':    t['trackName'] ?? '',
        'artist':   t['artistName'] ?? '',
        'album':    t['collectionName'] ?? '',
        'img':      t['artworkUrl100']?.toString().replaceAll('100x100', '300x300') ?? '',
        'preview':  t['previewUrl'] ?? '',
        'itunesUrl': t['trackViewUrl'] ?? '',
      }).where((t) => (t['preview'] as String).isNotEmpty).toList();
      
      setState(() {
        _results = list;
        _searching = false;
      });
    } catch (e) {
      setState(() {
        _errMsg = 'Gagal memuat data. Periksa koneksi internet.';
        _searching = false;
      });
    }
  }

  Future<void> _play(Map<String, dynamic> track) async {
    final url = track['preview'] as String;
    if (url.isEmpty) return;
    
    setState(() {
      _nowPlaying = track;
      _pos = Duration.zero;
    });
    
    await _player.stop();
    await _player.setReleaseMode(ReleaseMode.stop);
    await _player.play(UrlSource(url));
  }

  void _togglePlay() {
    if (_playing) {
      _player.pause();
    } else if (_nowPlaying != null) {
      _player.resume();
    }
  }

  void _nextTrack() {
    if (_results.isEmpty || _nowPlaying == null) return;
    final idx = _results.indexWhere((t) => t['title'] == _nowPlaying!['title']);
    if (idx < 0) return;
    
    int next;
    if (_shuffle) {
      do { next = Random().nextInt(_results.length); } while (next == idx && _results.length > 1);
    } else if (_repeat) {
      next = idx;
    } else {
      next = (idx + 1) % _results.length;
    }
    _play(_results[next]);
  }

  void _prevTrack() {
    if (_results.isEmpty || _nowPlaying == null) return;
    final idx = _results.indexWhere((t) => t['title'] == _nowPlaying!['title']);
    if (idx < 0) return;
    _play(_results[(idx - 1 + _results.length) % _results.length]);
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            _buildSearchBar(),
            _buildGenreChips(),
            if (_nowPlaying != null) _buildNowPlaying(),
            Expanded(child: _buildResults()),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
      child: Row(
        children: [
          Container(
            decoration: const BoxDecoration(
              color: _C.elevated,
              shape: BoxShape.circle,
            ),
            child: const IconButton(
              icon: Icon(Icons.chevron_left, color: _C.textP, size: 28),
              onPressed: null,
            ),
          ),
          const Spacer(),
          const Text(
            'Smoty Play',
            style: TextStyle(
              color: _C.textP,
              fontWeight: FontWeight.bold,
              fontSize: 20,
              letterSpacing: 0.5,
            ),
          ),
          const Spacer(),
          Container(
            decoration: const BoxDecoration(
              color: _C.elevated,
              shape: BoxShape.circle,
            ),
            child: const IconButton(
              icon: Icon(Icons.more_horiz_rounded, color: _C.textP, size: 22),
              onPressed: null,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        height: 48,
        decoration: BoxDecoration(
          color: _C.elevated,
          borderRadius: BorderRadius.circular(8),
        ),
        child: TextField(
          controller: _searchCtrl,
          onSubmitted: (v) => _search(v),
          style: const TextStyle(
            color: _C.textP,
            fontSize: 15,
            fontWeight: FontWeight.w500,
          ),
          decoration: InputDecoration(
            hintText: 'Cari lagu atau artis...',
            hintStyle: TextStyle(
              color: _C.textM.withOpacity(0.8),
              fontSize: 15,
              fontWeight: FontWeight.w400,
            ),
            prefixIcon: const Icon(Icons.search_rounded, color: _C.textM, size: 22),
            suffixIcon: _searchCtrl.text.isNotEmpty
                ? GestureDetector(
                    onTap: () {
                      _searchCtrl.clear();
                      setState(() {});
                    },
                    child: const Icon(Icons.close_rounded, color: _C.textS, size: 20),
                  )
                : null,
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(vertical: 14),
          ),
          onChanged: (value) => setState(() {}),
        ),
      ),
    );
  }

  Widget _buildGenreChips() {
    final genres = ['Semua', 'Pop', 'Hip-Hop', 'R&B', 'Electronic', 'Lo-Fi', 'K-Pop', 'Indonesia'];
    return Padding(
      padding: const EdgeInsets.only(top: 16, bottom: 8, left: 24),
      child: SizedBox(
        height: 32,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          itemCount: genres.length,
          separatorBuilder: (_, __) => const SizedBox(width: 10),
          itemBuilder: (_, i) {
            final g = genres[i];
            return GestureDetector(
              onTap: () {
                _searchCtrl.text = g == 'Semua' ? 'Top Hits' : g;
                _search(_searchCtrl.text);
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                decoration: BoxDecoration(
                  color: i == 0 ? _C.textP : _C.elevated,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  g,
                  style: TextStyle(
                    color: i == 0 ? _C.bg : _C.textS,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildResults() {
    if (_searching) {
      return const Center(child: CircularProgressIndicator(color: _C.accent));
    }
    if (_errMsg.isNotEmpty) {
      return Center(child: Text(_errMsg, style: const TextStyle(color: _C.textS)));
    }
    if (_results.isEmpty) {
      return const Center(child: Text('Cari lagu favoritmu', style: TextStyle(color: _C.textM)));
    }

    return ListView.builder(
      padding: const EdgeInsets.only(top: 16, bottom: 20),
      itemCount: _results.length,
      itemBuilder: (_, i) {
        final t = _results[i];
        final isPlaying = _nowPlaying != null && _nowPlaying!['title'] == t['title'] && _playing;
        
        return GestureDetector(
          onTap: () => _play(t),
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 4),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: isPlaying ? _C.accent.withOpacity(0.1) : Colors.transparent,
              borderRadius: BorderRadius.circular(6),
            ),
            child: Row(
              children: [
                SizedBox(
                  width: 24,
                  child: isPlaying
                      ? const Icon(Icons.graphic_eq_rounded, color: _C.accent, size: 18)
                      : Text(
                          '${i + 1}',
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: _C.textM, fontSize: 14, fontWeight: FontWeight.w400),
                        ),
                ),
                const SizedBox(width: 12),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: t['img'] != ''
                      ? Image.network(
                          t['img'] as String,
                          width: 44,
                          height: 44,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => _buildPlaceholderArt(),
                        )
                      : _buildPlaceholderArt(),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        t['title'] as String,
                        style: TextStyle(
                          color: isPlaying ? _C.accent : _C.textP,
                          fontSize: 15,
                          fontWeight: isPlaying ? FontWeight.bold : FontWeight.w500,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        t['artist'] as String,
                        style: const TextStyle(
                          color: _C.textM,
                          fontSize: 13,
                          fontWeight: FontWeight.w400,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.more_vert_rounded, color: _C.textM, size: 20),
                  onPressed: () {},
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildPlaceholderArt() {
    return Container(
      width: 44,
      height: 44,
      color: _C.elevated,
      child: const Icon(Icons.music_note_rounded, color: _C.textM, size: 20),
    );
  }

  Widget _buildNowPlaying() {
    final t = _nowPlaying!;
    final progress = _dur.inSeconds > 0 ? (_pos.inSeconds / _dur.inSeconds).clamp(0.0, 1.0) : 0.0;

    return Container(
      margin: const EdgeInsets.fromLTRB(24, 12, 24, 0),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: _C.border,
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 20,
            spreadRadius: 2,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: t['img'] != ''
                    ? Image.network(
                        t['img'] as String,
                        width: 56,
                        height: 56,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => _buildPlaceholderArt(),
                      )
                    : _buildPlaceholderArt(),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      t['title'] as String,
                      style: const TextStyle(
                        color: _C.textP,
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      t['artist'] as String,
                      style: const TextStyle(
                        color: _C.textS,
                        fontSize: 13,
                        fontWeight: FontWeight.w400,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          Column(
            children: [
              LayoutBuilder(
                builder: (context, constraints) {
                  return GestureDetector(
                    onTapDown: (details) {
                      if (_dur.inSeconds <= 0) return;
                      final localDx = details.localPosition.dx;
                      final seekProgress = (localDx / constraints.maxWidth).clamp(0.0, 1.0);
                      _player.seek(Duration(seconds: (seekProgress * _dur.inSeconds).toInt()));
                    },
                    child: Container(
                      height: 4,
                      decoration: BoxDecoration(
                        color: _C.border,
                        borderRadius: BorderRadius.circular(2),
                      ),
                      child: Stack(
                        children: [
                          FractionallySizedBox(
                            widthFactor: progress,
                            alignment: Alignment.centerLeft,
                            child: Container(
                              decoration: BoxDecoration(
                                color: _C.accent,
                                borderRadius: BorderRadius.circular(2),
                                boxShadow: const [
                                  BoxShadow(
                                    color: _C.accent,
                                    blurRadius: 6,
                                    spreadRadius: 0.5,
                                  )
                                ],
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment(progress, 0),
                            child: Container(
                              width: 12,
                              height: 12,
                              decoration: const BoxDecoration(
                                color: _C.textP,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black54,
                                    blurRadius: 4,
                                    offset: Offset(0, 1),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    _fmt(_pos),
                    style: const TextStyle(
                      color: _C.textM,
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(
                    _fmt(_dur),
                    style: const TextStyle(
                      color: _C.textM,
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ],
          ),
          
          const SizedBox(height: 12),
          
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: () => setState(() => _shuffle = !_shuffle),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Icon(
                    Icons.shuffle_rounded,
                    color: _shuffle ? _C.accent : _C.textM,
                    size: 20,
                  ),
                ),
              ),
              const SizedBox(width: 16),
              GestureDetector(
                onTap: _prevTrack,
                child: const Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Icon(
                    Icons.skip_previous_rounded,
                    color: _C.textP,
                    size: 30,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: _togglePlay,
                child: Container(
                  width: 56,
                  height: 56,
                  decoration: const BoxDecoration(
                    color: _C.textP,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    _playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                    color: _C.bg,
                    size: 32,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: _nextTrack,
                child: const Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Icon(
                    Icons.skip_next_rounded,
                    color: _C.textP,
                    size: 30,
                  ),
                ),
              ),
              const SizedBox(width: 16),
              GestureDetector(
                onTap: () => setState(() => _repeat = !_repeat),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Icon(
                    Icons.repeat_rounded,
                    color: _repeat ? _C.accent : _C.textM,
                    size: 20,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}