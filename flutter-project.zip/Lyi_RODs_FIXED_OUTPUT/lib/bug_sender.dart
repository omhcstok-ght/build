import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'config.dart';
import 'theme_provider.dart';

class BugSenderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const BugSenderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage>
    with SingleTickerProviderStateMixin {
  ThemeProvider get tp => ThemeProvider();

  List<dynamic> privateSenders = [];
  List<dynamic> globalSenders = [];
  bool isLoading = false;
  bool isRefreshing = false;
  String? errorMessage;
  int _selectedTabIndex = 0;
  late TabController _tabController;

  // Check if user can see global tab (owner or admin only)
  bool get _canAccessGlobalTab =>
      widget.role == "owner" || widget.role == "admin";

  // --- TEMA NEON BLUE & PUTIH ALAMI ---
  final Color primaryWhite = const Color(0xFFE6F1FF);
  final Color secondaryGrey = const Color(0xFF8892B0);
  final Color neonBlue = const Color(0xFF00D4FF);
  final Color neonCyan = const Color(0xFF64FFDA);
  final Color neonPurple = const Color(0xFFBD34FE);
  final Color cardGlass = Colors.white.withOpacity(0.03);
  final Color borderGlass = Colors.white.withOpacity(0.08);
  final String fontFamily = 'Rajdhani';

  @override
  void initState() {
    super.initState();
    // Only show Global tab for owner and admin
    _tabController = TabController(
      length: _canAccessGlobalTab ? 2 : 1,
      vsync: this,
    );
    _tabController.addListener(() {
      if (!_tabController.indexIsChanging) {
        setState(() {
          _selectedTabIndex = _tabController.index;
        });
      }
    });
    _fetchAllSenders();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _fetchAllSenders() async {
    if (mounted) {
      setState(() {
        if (privateSenders.isEmpty && globalSenders.isEmpty) isLoading = true;
        errorMessage = null;
      });
    }

    try {
      // Fetch private senders for all users
      final privateResponse = await http.get(
        Uri.parse("${ApiConfig.baseUrl}/mySender?key=${widget.sessionKey}"),
      );

      // Fetch global senders only for owner and admin
      http.Response? globalResponse;
      if (_canAccessGlobalTab) {
        globalResponse = await http.get(
          Uri.parse(
            "${ApiConfig.baseUrl}/globalSenders?key=${widget.sessionKey}",
          ),
        );
      }

      // Process private response (always available)
      if (privateResponse.statusCode == 200) {
        final data = jsonDecode(privateResponse.body);
        if (data["valid"] == true && mounted) {
          setState(() {
            privateSenders = data["connections"] ?? [];
          });
        }
      }

      // Only process global response for owner/admin
      if (_canAccessGlobalTab &&
          globalResponse != null &&
          globalResponse.statusCode == 200) {
        final data = jsonDecode(globalResponse.body);
        if (data["valid"] == true && mounted) {
          setState(() {
            globalSenders = data["connections"] ?? [];
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          errorMessage = "Connection failed: $e";
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
          isRefreshing = false;
        });
      }
    }
  }

  // --- FIX BUG: SMART POLLING AGAR NOMOR LANGSUNG MASUK LIST ---
  Future<void> _waitForSenderToAppear(
    String targetNumber, {
    required bool isGlobal,
  }) async {
    _showSnackBar("Waiting for device to connect to server...", isError: false);

    // Beri jeda 3 detik awal untuk WhatsApp memproses pairing di background
    await Future.delayed(const Duration(seconds: 3));

    int attempts = 0;
    bool isFound = false;

    // Looping pengecekan sebanyak 5 kali (total 15 detik)
    while (attempts < 5 && !isFound) {
      await Future.delayed(const Duration(seconds: 3));
      await _fetchAllSenders(); // Refresh data dari server

      final list = isGlobal ? globalSenders : privateSenders;
      for (var sender in list) {
        final sessionName =
            sender['sessionName']?.toString().toLowerCase() ?? '';
        final number = sender['number']?.toString().toLowerCase() ?? '';
        final target = targetNumber.toLowerCase();

        if (sessionName.contains(target) || number.contains(target)) {
          isFound = true;
          break;
        }
      }
      attempts++;
    }

    if (mounted) {
      if (isFound) {
        _showSnackBar(
          "Device successfully connected and added!",
          isError: false,
        );
      } else {
        _showSnackBar(
          "Pairing success. Pull down to refresh if not visible.",
          isError: false,
        );
      }
    }
  }

  Future<void> _refreshSenders() async {
    setState(() => isRefreshing = true);
    await _fetchAllSenders();
  }

  void _showAddSenderDialog() {
    final phoneController = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: tp.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: borderGlass, width: 1),
        ),
        title: Row(
          children: [
            Icon(Icons.add_circle, color: neonBlue),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                _selectedTabIndex == 0
                    ? "Add Private Sender"
                    : "Add Global Sender",
                style: TextStyle(
                  color: primaryWhite,
                  fontWeight: FontWeight.bold,
                  fontFamily: fontFamily,
                ),
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: phoneController,
              keyboardType: TextInputType.phone,
              style: TextStyle(color: primaryWhite, fontFamily: fontFamily),
              decoration: InputDecoration(
                labelText: "Phone Number",
                labelStyle: TextStyle(color: neonCyan, fontFamily: fontFamily),
                hintText: "62xxx",
                hintStyle: TextStyle(
                  color: secondaryGrey,
                  fontFamily: fontFamily,
                ),
                prefixIcon: Icon(Icons.phone, color: neonCyan),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: secondaryGrey.withOpacity(0.3)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: neonBlue),
                ),
              ),
            ),
            const SizedBox(height: 16),
            if (_selectedTabIndex == 1 && widget.role != "owner")
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.red.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.warning_amber,
                      color: Colors.redAccent,
                      size: 20,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        "Only Owner can add global senders",
                        style: TextStyle(
                          color: Colors.redAccent,
                          fontSize: 12,
                          fontFamily: fontFamily,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "CANCEL",
              style: TextStyle(color: secondaryGrey, fontFamily: fontFamily),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor:
                  (_selectedTabIndex == 1 && widget.role != "owner")
                  ? secondaryGrey
                  : neonBlue,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: (_selectedTabIndex == 1 && widget.role != "owner")
                ? null
                : () async {
                    final number = phoneController.text.trim();

                    if (number.isEmpty) {
                      _showSnackBar("Please enter phone number", isError: true);
                      return;
                    }

                    Navigator.pop(context);

                    if (_selectedTabIndex == 0) {
                      await _addPrivateSender(number);
                    } else {
                      await _addGlobalSender(number);
                    }
                  },
            child: Text(
              _selectedTabIndex == 0 ? "ADD PRIVATE" : "ADD GLOBAL",
              style: TextStyle(
                color: tp.bg,
                fontFamily: fontFamily,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _addPrivateSender(String number) async {
    setState(() => isLoading = true);

    try {
      final response = await http.get(
        Uri.parse(
          "${ApiConfig.baseUrl}/getPairing?key=${widget.sessionKey}&number=$number",
        ),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          _showPairingCodeDialog(number, data['pairingCode'], isGlobal: false);
        } else {
          _showSnackBar(
            data['message'] ?? "Failed to generate pairing code",
            isError: true,
          );
        }
      } else {
        _showSnackBar("Server error: ${response.statusCode}", isError: true);
      }
    } catch (e) {
      _showSnackBar("Connection failed: $e", isError: true);
    } finally {
      setState(() => isLoading = false);
    }
  }

  Future<void> _addGlobalSender(String number) async {
    if (widget.role != "owner") {
      _showSnackBar("Only owner can add global senders", isError: true);
      return;
    }

    setState(() => isLoading = true);

    try {
      final response = await http.post(
        Uri.parse(ApiConfig.addGlobalSenderEndpoint),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey, 'number': number}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          _showPairingCodeDialog(
            number,
            data['pairingCode'],
            isGlobal: true,
            sessionName: data['sessionName'],
          );
        } else {
          _showSnackBar(
            data['message'] ?? "Failed to generate global sender",
            isError: true,
          );
        }
      } else {
        _showSnackBar("Server error: ${response.statusCode}", isError: true);
      }
    } catch (e) {
      _showSnackBar("Connection failed: $e", isError: true);
    } finally {
      setState(() => isLoading = false);
    }
  }

  // --- FIX: Confirm global sender after pairing ---
  Future<void> _confirmGlobalSender(String sessionName, String number) async {
    try {
      final response = await http.post(
        Uri.parse(ApiConfig.confirmGlobalSenderEndpoint),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'sessionName': sessionName,
          'number': number,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          _showSnackBar(
            "Global sender confirmed and added to list!",
            isError: false,
          );
          _fetchAllSenders(); // Refresh list
        } else {
          // Might already exist, just refresh
          _fetchAllSenders();
        }
      }
    } catch (e) {
      // Silent fail - sender might already be confirmed
      _fetchAllSenders();
    }
  }

  void _showPairingCodeDialog(
    String number,
    String code, {
    required bool isGlobal,
    String? sessionName,
  }) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: tp.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: borderGlass),
        ),
        title: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: neonBlue.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.qr_code_2, color: neonBlue, size: 40),
            ),
            const SizedBox(height: 15),
            Text(
              isGlobal ? "Global Sender Pairing" : "Private Sender Pairing",
              style: TextStyle(
                color: primaryWhite,
                fontWeight: FontWeight.bold,
                fontSize: 18,
                fontFamily: fontFamily,
              ),
            ),
          ],
        ),
        content: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: cardGlass,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: borderGlass),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "Number: $number",
                style: TextStyle(color: primaryWhite, fontFamily: fontFamily),
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: neonBlue, width: 1),
                  boxShadow: [
                    BoxShadow(
                      color: neonBlue.withOpacity(0.2),
                      blurRadius: 15,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: Text(
                  code,
                  style: TextStyle(
                    color: neonCyan,
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 4,
                    fontFamily: 'Courier',
                  ),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  icon: Icon(Icons.copy, color: neonBlue, size: 18),
                  label: Text(
                    "COPY CODE",
                    style: TextStyle(
                      color: neonBlue,
                      fontWeight: FontWeight.bold,
                      fontFamily: fontFamily,
                    ),
                  ),
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: neonBlue.withOpacity(0.3)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: () async {
                    await Clipboard.setData(ClipboardData(text: code));
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          "Code copied to clipboard!",
                          style: TextStyle(
                            color: tp.bg,
                            fontFamily: fontFamily,
                          ),
                        ),
                        backgroundColor: neonCyan,
                        behavior: SnackBarBehavior.floating,
                        duration: Duration(seconds: 2),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "CLOSE",
              style: TextStyle(color: secondaryGrey, fontFamily: fontFamily),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: neonBlue,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: () {
              Navigator.pop(context);
              // For global sender, confirm it first then wait for appearance
              if (isGlobal && sessionName != null) {
                _confirmGlobalSender(sessionName, number).then((_) {
                  _waitForSenderToAppear(number, isGlobal: isGlobal);
                });
              } else {
                _waitForSenderToAppear(number, isGlobal: isGlobal);
              }
            },
            child: Text(
              "CHECK STATUS",
              style: TextStyle(
                color: tp.bg,
                fontFamily: fontFamily,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteSender(String senderId, bool isGlobal) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: tp.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: borderGlass),
        ),
        title: Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: Colors.orangeAccent),
            const SizedBox(width: 12),
            Text(
              "Confirm Delete",
              style: TextStyle(color: primaryWhite, fontFamily: fontFamily),
            ),
          ],
        ),
        content: Text(
          "Are you sure you want to delete this ${isGlobal ? 'global' : 'private'} sender? This action cannot be undone.",
          style: TextStyle(color: secondaryGrey, fontFamily: fontFamily),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(
              "CANCEL",
              style: TextStyle(color: secondaryGrey, fontFamily: fontFamily),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.redAccent.withOpacity(0.1),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: () => Navigator.pop(context, true),
            child: Text(
              "DELETE",
              style: TextStyle(
                color: Colors.redAccent,
                fontFamily: fontFamily,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() => isLoading = true);

      try {
        http.Response response;

        if (isGlobal) {
          response = await http.delete(
            Uri.parse(ApiConfig.deleteGlobalSenderEndpoint),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'sessionName': senderId,
            }),
          );
        } else {
          response = await http.delete(
            Uri.parse(
              "${ApiConfig.baseUrl}/deleteSender?key=${widget.sessionKey}&id=$senderId",
            ),
          );
        }

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data["valid"] == true) {
            _showSnackBar("Sender deleted successfully!", isError: false);
            _fetchAllSenders();
          } else {
            _showSnackBar(
              data["message"] ?? "Failed to delete sender",
              isError: true,
            );
          }
        } else {
          _showSnackBar("Server error: ${response.statusCode}", isError: true);
        }
      } catch (e) {
        _showSnackBar("Connection failed: $e", isError: true);
      } finally {
        setState(() => isLoading = false);
      }
    }
  }

  void _showSnackBar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: TextStyle(
            color: isError ? Colors.white : tp.bg,
            fontWeight: FontWeight.w600,
            fontFamily: fontFamily,
          ),
        ),
        backgroundColor: isError ? Colors.redAccent : neonCyan,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  Widget _buildSenderCard(
    Map<String, dynamic> sender,
    int index, {
    required bool isGlobal,
  }) {
    final name = sender['sessionName'] ?? 'WhatsApp Sender';

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: tp.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isGlobal ? neonPurple.withOpacity(0.5) : borderGlass,
        ),
        boxShadow: [
          BoxShadow(
            color: isGlobal
                ? neonPurple.withOpacity(0.1)
                : Colors.black.withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: isGlobal
                        ? neonPurple.withOpacity(0.15)
                        : neonBlue.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    isGlobal ? Icons.public : Icons.phone_android,
                    color: isGlobal ? neonPurple : neonBlue,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: TextStyle(
                          color: primaryWhite,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          fontFamily: fontFamily,
                        ),
                      ),
                      if (isGlobal && sender['addedBy'] != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(
                            "Added by: ${sender['addedBy']}",
                            style: TextStyle(
                              color: secondaryGrey,
                              fontSize: 12,
                              fontFamily: fontFamily,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: isGlobal
                        ? neonPurple.withOpacity(0.15)
                        : neonCyan.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: isGlobal
                          ? neonPurple.withOpacity(0.3)
                          : neonCyan.withOpacity(0.3),
                    ),
                  ),
                  child: Text(
                    isGlobal ? "GLOBAL" : "CONNECTED",
                    style: TextStyle(
                      color: isGlobal ? neonPurple : neonCyan,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.2,
                      fontFamily: fontFamily,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(
                      Icons.refresh,
                      size: 16,
                      color: Colors.white,
                    ),
                    label: Text(
                      "REFRESH",
                      style: TextStyle(
                        fontFamily: fontFamily,
                        color: primaryWhite,
                      ),
                    ),
                    style: OutlinedButton.styleFrom(
                      backgroundColor: cardGlass,
                      side: BorderSide(color: borderGlass),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onPressed: () => _refreshSenders(),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    icon: const Icon(
                      Icons.delete_outline,
                      size: 16,
                      color: Colors.redAccent,
                    ),
                    label: Text(
                      "DELETE",
                      style: TextStyle(
                        fontFamily: fontFamily,
                        color: Colors.redAccent,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.redAccent.withOpacity(0.1),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onPressed: () => _deleteSender(
                      sender['sessionName'] ?? sender['id'],
                      isGlobal,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(bool isGlobal) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(30),
              decoration: BoxDecoration(
                color: cardGlass,
                shape: BoxShape.circle,
                border: Border.all(color: borderGlass),
              ),
              child: Icon(
                isGlobal ? Icons.public : Icons.phone_iphone,
                color: neonBlue,
                size: 80,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              isGlobal ? "No Global Senders" : "No Private Senders",
              style: TextStyle(
                color: primaryWhite,
                fontSize: 22,
                fontWeight: FontWeight.bold,
                fontFamily: fontFamily,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              isGlobal
                  ? "Add your first global sender (Owner only)"
                  : "Add your first WhatsApp sender to get started",
              style: TextStyle(
                color: secondaryGrey,
                fontSize: 14,
                fontFamily: fontFamily,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 40),
            if (!isGlobal || widget.role == "owner")
              ElevatedButton.icon(
                icon: Icon(Icons.add, color: tp.bg),
                label: Text(
                  isGlobal
                      ? "ADD FIRST GLOBAL SENDER"
                      : "ADD FIRST PRIVATE SENDER",
                  style: TextStyle(
                    color: tp.bg,
                    fontFamily: fontFamily,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: neonBlue,
                  shadowColor: neonBlue.withOpacity(0.4),
                  elevation: 10,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 32,
                    vertical: 16,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                onPressed: _showAddSenderDialog,
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, color: Colors.redAccent, size: 80),
            const SizedBox(height: 24),
            Text(
              "Failed to Load",
              style: TextStyle(
                color: primaryWhite,
                fontSize: 22,
                fontWeight: FontWeight.bold,
                fontFamily: fontFamily,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              errorMessage ?? "Unknown error occurred",
              style: TextStyle(
                color: secondaryGrey,
                fontSize: 14,
                fontFamily: fontFamily,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 40),
            ElevatedButton.icon(
              icon: const Icon(Icons.refresh, color: Colors.black),
              label: Text(
                "TRY AGAIN",
                style: TextStyle(
                  color: Colors.black,
                  fontFamily: fontFamily,
                  fontWeight: FontWeight.bold,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: neonBlue,
                padding: const EdgeInsets.symmetric(
                  horizontal: 32,
                  vertical: 16,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              onPressed: _fetchAllSenders,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSenderList() {
    final List<dynamic> currentSenders = _selectedTabIndex == 0
        ? privateSenders
        : globalSenders;
    final bool isGlobal = _selectedTabIndex == 1;

    if (currentSenders.isEmpty) {
      return _buildEmptyState(isGlobal);
    }

    return RefreshIndicator(
      color: neonBlue,
      backgroundColor: tp.card,
      onRefresh: _refreshSenders,
      child: ListView.builder(
        physics: const AlwaysScrollableScrollPhysics(),
        itemCount: currentSenders.length,
        itemBuilder: (context, index) => _buildSenderCard(
          Map<String, dynamic>.from(currentSenders[index]),
          index,
          isGlobal: isGlobal,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: tp.bg,
      appBar: AppBar(
        title: Text(
          "Manage Bug Sender",
          style: TextStyle(
            color: primaryWhite,
            fontFamily: fontFamily,
            fontWeight: FontWeight.bold,
            fontSize: 20,
            letterSpacing: 1.0,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Color(0xFF00D4FF)),
          onPressed: () => Navigator.pop(context),
        ),
        bottom: _canAccessGlobalTab
            ? TabBar(
                controller: _tabController,
                indicatorColor: neonBlue,
                indicatorSize: TabBarIndicatorSize.label,
                labelColor: neonBlue,
                unselectedLabelColor: secondaryGrey,
                tabs: const [
                  Tab(text: "PRIVATE", icon: Icon(Icons.person)),
                  Tab(text: "GLOBAL", icon: Icon(Icons.public)),
                ],
              )
            : null,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Color(0xFF00D4FF)),
            onPressed: isLoading ? null : _refreshSenders,
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF020917), Color(0xFF0A192F), Color(0xFF020917)],
          ),
        ),
        child: isLoading && privateSenders.isEmpty && globalSenders.isEmpty
            ? Center(
                child: CircularProgressIndicator(
                  color: neonBlue,
                  strokeWidth: 2,
                ),
              )
            : errorMessage != null
            ? _buildErrorState()
            : _buildSenderList(),
      ),
      floatingActionButton: Container(
        decoration: BoxDecoration(
          color: neonBlue,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: neonBlue.withOpacity(0.4),
              blurRadius: 20,
              spreadRadius: 2,
            ),
          ],
        ),
        child: FloatingActionButton(
          onPressed: _showAddSenderDialog,
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: const Icon(Icons.add, color: Colors.black, size: 28),
        ),
      ),
    );
  }
}
