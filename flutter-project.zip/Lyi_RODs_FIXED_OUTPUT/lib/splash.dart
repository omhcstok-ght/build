import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_page.dart';
import 'audio_service.dart' as bg;
import 'theme_provider.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  ThemeProvider get tp => ThemeProvider();

  late VideoPlayerController _videoController;
  late AnimationController _fadeController;
  late AnimationController _loadingController;
  late AnimationController _glowController;
  late AnimationController _particleController;

  bool _fadeOutStarted = false;
  bool _navigated = false;

  // Warna Neon Theme
  final Color neonBlue = const Color(0xFF00F0FF);
  final Color neonWhite = const Color(0xFFE0F7FF);

  @override
  void initState() {
    super.initState();

    // Pause background music selama splash screen
    bg.AudioService().pause();

    // Controller untuk transisi fade out akhir
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    // Controller untuk animasi loading bar (bounce smooth)
    _loadingController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);

    // Controller untuk efek berkedip (glow/pulse) pada elemen utama
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    // Controller untuk partikel melayang di background
    _particleController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();

    _videoController = VideoPlayerController.asset("assets/videos/splash.mp4")
      ..initialize().then((_) {
        setState(() {});
        _videoController.setLooping(false);
        _videoController.play();

        _videoController.addListener(() {
          final position = _videoController.value.position;
          final duration = _videoController.value.duration;

          if (duration != null &&
              position >= duration - const Duration(seconds: 1) &&
              !_fadeOutStarted) {
            _fadeOutStarted = true;
            _fadeController.forward();
          }

          if (position >= duration && !_navigated) {
            _navigateToDashboard();
          }
        });
      });
  }

  void _navigateToDashboard() {
    if (_navigated) return;
    _navigated = true;

    _videoController.pause();
    _loadingController.stop();
    _glowController.stop();
    _particleController.stop();

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 800),
        pageBuilder: (context, animation, secondaryAnimation) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return FadeTransition(
            opacity: CurvedAnimation(parent: animation, curve: Curves.easeInOut),
            child: ScaleTransition(
              scale: CurvedAnimation(parent: animation, curve: Curves.easeOutBack),
              child: child,
            ),
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    _videoController.dispose();
    _fadeController.dispose();
    _loadingController.dispose();
    _glowController.dispose();
    _particleController.dispose();
    super.dispose();
  }

  // Widget untuk efek partikel cyberpunk
  Widget _buildNeonParticle(double left, double top, double size) {
    return AnimatedBuilder(
      animation: _particleController,
      builder: (context, child) {
        final dy = math.sin(_particleController.value * 2 * math.pi + top) * 20;
        final dx = math.cos(_particleController.value * 2 * math.pi + left) * 10;
        return Positioned(
          left: left + dx,
          top: top + dy,
          child: Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: left % 2 == 0 ? neonBlue.withOpacity(0.6) : tp.accent.withOpacity(0.6),
              boxShadow: [
                BoxShadow(
                  color: left % 2 == 0 ? neonBlue : tp.accent,
                  blurRadius: 10,
                  spreadRadius: 2,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: Theme.of(context).copyWith(
        textTheme: Theme.of(context).textTheme.apply(fontFamily: 'Rajdhani'),
      ),
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(
          children: [
            // 1. VIDEO BACKGROUND + DARKEN OVERLAY
            if (_videoController.value.isInitialized)
              Positioned.fill(
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _videoController.value.size.width,
                    height: _videoController.value.size.height,
                    child: VideoPlayer(_videoController),
                  ),
                ),
              )
            else
              const Center(
                child: CircularProgressIndicator(color: Color(0xFF00F0FF)),
              ),

            // Gelapkan video agar elemen neon terlihat jelas
            Positioned.fill(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 1.0, sigmaY: 1.0),
                child: Container(
                  color: Colors.black.withOpacity(0.5),
                ),
              ),
            ),

            // 2. PARTIKEL NEON BACKGROUND
            _buildNeonParticle(MediaQuery.of(context).size.width * 0.1, 100, 4),
            _buildNeonParticle(MediaQuery.of(context).size.width * 0.8, 150, 6),
            _buildNeonParticle(MediaQuery.of(context).size.width * 0.3, 300, 3),
            _buildNeonParticle(MediaQuery.of(context).size.width * 0.7, 400, 5),
            _buildNeonParticle(MediaQuery.of(context).size.width * 0.5, 200, 4),
            _buildNeonParticle(MediaQuery.of(context).size.width * 0.9, 500, 3),

            // 3. SKIP BUTTON (Gaya Cyberpunk Borders)
            Positioned(
              top: 50,
              right: 20,
              child: GestureDetector(
                onTap: _navigateToDashboard,
                child: AnimatedBuilder(
                  animation: _glowController,
                  builder: (context, child) {
                    return Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(2),
                        border: Border.all(
                          color: neonBlue.withOpacity(0.5 + _glowController.value * 0.5),
                          width: 1.5,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: neonBlue.withOpacity(0.2 * _glowController.value),
                            blurRadius: 15,
                            spreadRadius: 1,
                          )
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.skip_next,
                            color: neonBlue,
                            size: 16,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            "SKIP",
                            style: TextStyle(
                              fontFamily: 'Rajdhani',
                              color: neonBlue,
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                              letterSpacing: 3,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ),

            // 4. AREA JUDUL & LOADING (BAGIAN BAWAH)
            Positioned(
              bottom: 80,
              left: 0,
              right: 0,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Garis Dekorasi Atas Judul
                  AnimatedBuilder(
                    animation: _loadingController,
                    builder: (context, _) {
                      return FractionallySizedBox(
                        widthFactor: 0.6,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(1),
                          child: LinearProgressIndicator(
                            value: _loadingController.value * 0.5,
                            backgroundColor: Colors.transparent,
                            valueColor: AlwaysStoppedAnimation<Color>(
                              tp.accent.withOpacity(0.8),
                            ),
                            minHeight: 1,
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 20),

                  // JUDUL UTAMA
                  AnimatedBuilder(
                    animation: _glowController,
                    builder: (context, child) {
                      final glowIntensity = 10 + (_glowController.value * 20);
                      return Text(
                        "RODS PROJECT",
                        style: TextStyle(
                          fontFamily: 'Rajdhani',
                          fontSize: 56,
                          fontWeight: FontWeight.bold,
                          color: neonWhite,
                          letterSpacing: 6,
                          shadows: [
                            Shadow(
                              color: neonBlue.withOpacity(0.8),
                              blurRadius: glowIntensity,
                              offset: const Offset(0, 0),
                            ),
                            Shadow(
                              color: tp.accent.withOpacity(0.6),
                              blurRadius: glowIntensity * 0.5,
                              offset: const Offset(2, 4),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 24),

                  // LOADING BAR (Dual Color Neon)
                  SizedBox(
                    width: 220,
                    height: 4,
                    child: AnimatedBuilder(
                      animation: _loadingController,
                      builder: (context, child) {
                        return Stack(
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(2),
                              ),
                            ),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(2),
                              child: Align(
                                alignment: Alignment.centerLeft,
                                child: AnimatedContainer(
                                  duration: const Duration(milliseconds: 100),
                                  width: 220 * (_loadingController.value * 0.8),
                                  height: 4,
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [neonBlue, tp.accent],
                                      begin: Alignment.centerLeft,
                                      end: Alignment.centerRight,
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: neonBlue.withOpacity(0.6),
                                        blurRadius: 8,
                                        spreadRadius: 1,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 14),

                  // TEKS STATUS
                  Text(
                    "LOADING...",
                    style: TextStyle(
                      fontFamily: 'Rajdhani',
                      fontSize: 14,
                      color: neonWhite.withOpacity(0.5),
                      letterSpacing: 4,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  
                  const SizedBox(height: 16),
                  
                  // Garis Dekorasi Bawah Judul
                  AnimatedBuilder(
                    animation: _loadingController,
                    builder: (context, _) {
                      return FractionallySizedBox(
                        widthFactor: 0.6,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(1),
                          child: LinearProgressIndicator(
                            value: _loadingController.value * 0.5,
                            backgroundColor: Colors.transparent,
                            valueColor: AlwaysStoppedAnimation<Color>(
                              tp.accent.withOpacity(0.8),
                            ),
                            minHeight: 1,
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),

            // 5. VIGNETTE OVERLAY
            Positioned.fill(
              child: IgnorePointer(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      center: Alignment.center,
                      radius: 1.2,
                      colors: [
                        Colors.transparent,
                        Colors.black.withOpacity(0.6),
                      ],
                    ),
                  ),
                ),
              ),
            ),

            // 6. FADE OUT EFFECT AKHIR
            if (_fadeOutStarted)
              FadeTransition(
                opacity: _fadeController.drive(Tween(begin: 1.0, end: 0.0)),
                child: Container(color: Colors.black),
              ),
          ],
        ),
      ),
    );
  }
}