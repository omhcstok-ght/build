import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:intl/intl.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:path_provider/path_provider.dart';
import 'config.dart';
import 'models/chat_model.dart';
import 'theme_provider.dart';

class GlobalChatPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const GlobalChatPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<GlobalChatPage> createState() => _GlobalChatPageState();
}

class _GlobalChatPageState extends State<GlobalChatPage>
    with TickerProviderStateMixin {
  ThemeProvider get tp => ThemeProvider();

  // --- TEMA WARNA TELEGRAM AESTHETIC ---
  static const Color secondaryBg = Color(0xFF0E1621);
  static const Color bubbleOutBg = Color(0xFF2B5278);
  static const Color bubbleInBg = Color(0xFF182533);
  static const Color accentCyan = Color(0xFF5EB5F7);
  static const Color accentGreen = Color(0xFF4DCD5E);
  static const Color textWhite = Color(0xFFFFFFFF);
  static const Color textGrey = Color(0xFF8B9BAB);
  static const Color subtleBorder = Color(0xFF1F2936);

  // --- CONTROLLERS & STATE ---
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final FocusNode _focusNode = FocusNode();
  final AudioPlayer _audioPlayer = AudioPlayer();
  final FlutterSoundRecorder _audioRecorder = FlutterSoundRecorder();

  List<ChatMessage> _messages = [];
  List<ChatUser> _onlineUsers = [];
  bool _isLoading = true;
  bool _isSending = false;
  bool _isPlayingVoice = false;
  bool _isUploadingImage = false;
  bool _isRecording = false;
  String? _currentPlayingId;
  String? _recordingPath;
  int _recordingDuration = 0;
  WebSocketChannel? _channel;
  bool _wsConnected = false;

  @override
  void initState() {
    super.initState();
    _initializeChat();
    _connectWebSocket();
    _messageController.addListener(_onTextChanged);
  }

  @override
  void dispose() {
    _messageController.removeListener(_onTextChanged);
    _messageController.dispose();
    _focusNode.dispose();
    _scrollController.dispose();
    _audioPlayer.dispose();
    _audioRecorder.closeRecorder();
    _channel?.sink.close();
    super.dispose();
  }

  void _onTextChanged() {
    setState(() {});
  }

  void _initializeChat() async {
    await _loadMessages();
    await _loadOnlineUsers();
    _scrollToBottom();
  }

  // =====================================================
  // FIX: WebSocket menggunakan ApiConfig.wsUrl langsung
  // dan registrasi username agar broadcast diterima
  // =====================================================
  void _connectWebSocket() {
    try {
      _channel = WebSocketChannel.connect(Uri.parse(ApiConfig.wsUrl));

      // FIX: Kirim registrasi username ke server agar masuk wsClients
      _channel!.sink.add(jsonEncode({
        'type': 'register',
        'key': widget.sessionKey,
        'username': widget.username,
      }));

      _channel!.stream.listen(
        (message) {
          try {
            final data = jsonDecode(message);
            // Terima broadcast chat_message dari server
            if (data['type'] == 'chat_message') {
              final chatMessage = ChatMessage.fromJson(data['data']);
              if (mounted) {
                setState(() {
                  // Hindari duplikasi pesan
                  final exists = _messages.any((m) => m.id == chatMessage.id);
                  if (!exists) {
                    _messages.add(chatMessage);
                  }
                });
                _scrollToBottom();
              }
            }
            // Terima history dari server setelah register
            if (data['type'] == 'chat_history') {
              final msgs = (data['messages'] as List?)
                  ?.map((e) => ChatMessage.fromJson(e))
                  .toList() ?? [];
              if (mounted && msgs.isNotEmpty) {
                setState(() {
                  _messages = msgs;
                  _isLoading = false;
                });
                _scrollToBottom();
              }
            }
          } catch (_) {}
        },
        onError: (error) {
          _wsConnected = false;
          _channel = null;
          _scheduleReconnect();
        },
        onDone: () {
          _wsConnected = false;
          _channel = null;
          _scheduleReconnect();
        },
      );

      _wsConnected = true;
    } catch (e) {
      _wsConnected = false;
      _scheduleReconnect();
    }
  }

  // FIX: Polling juga dijalankan bersamaan sebagai fallback
  // agar pesan dari user lain tetap muncul jika WS tidak stabil
  void _scheduleReconnect() {
    Future.delayed(const Duration(seconds: 5), () {
      if (mounted) {
        _connectWebSocket();
        _loadMessages();
      }
    });
  }

  Future<void> _loadMessages() async {
    try {
      final response = await http.get(
        Uri.parse(
          '${ApiConfig.getChatMessagesEndpoint}?key=${widget.sessionKey}&roomId=global&limit=50',
        ),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          if (mounted) {
            setState(() {
              _messages = (data['messages'] as List)
                  .map((e) => ChatMessage.fromJson(e))
                  .toList();
              _isLoading = false;
            });
            _scrollToBottom();
          }
        } else {
          if (mounted) setState(() => _isLoading = false);
        }
      } else {
        if (mounted) setState(() => _isLoading = false);
      }
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _loadOnlineUsers() async {
    try {
      final response = await http.get(
        Uri.parse(
          '${ApiConfig.getChatUsersEndpoint}?key=${widget.sessionKey}&roomId=global',
        ),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && mounted) {
          setState(() {
            _onlineUsers = (data['users'] as List)
                .map((e) => ChatUser.fromJson(e))
                .toList();
          });
        }
      }
    } catch (e) {
      // Silent error
    }
  }

  // =====================================================
  // FIX: Setelah send, langsung tambahkan ke list lokal
  // (optimistic update) agar pesan tampil LANGSUNG 100%
  // =====================================================
  Future<void> _sendMessage() async {
    final text = _messageController.text.trim();
    if (text.isEmpty || _isSending) return;

    setState(() => _isSending = true);
    _messageController.clear();
    _focusNode.unfocus();

    // Optimistic: tambahkan pesan dulu di UI
    final tempId = 'temp_${DateTime.now().millisecondsSinceEpoch}';
    final tempMsg = ChatMessage(
      id: tempId,
      senderId: widget.username,
      senderName: widget.username,
      senderRole: widget.role,
      content: text,
      type: MessageType.text,
      timestamp: DateTime.now(),
    );

    if (mounted) {
      setState(() => _messages.add(tempMsg));
      _scrollToBottom();
    }

    try {
      final response = await http.post(
        Uri.parse(ApiConfig.sendChatMessageEndpoint),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'roomId': 'global',
          'content': text,
          'type': 'text',
        }),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          // Ganti pesan temp dengan data asli dari server
          final realMsg = ChatMessage.fromJson(data['data']);
          if (mounted) {
            setState(() {
              final idx = _messages.indexWhere((m) => m.id == tempId);
              if (idx != -1) {
                _messages[idx] = realMsg;
              }
            });
          }
        } else {
          // Gagal: hapus pesan temp
          if (mounted) {
            setState(() => _messages.removeWhere((m) => m.id == tempId));
            _showError('Gagal mengirim: ${data['message'] ?? 'Error'}');
          }
        }
      } else {
        if (mounted) {
          setState(() => _messages.removeWhere((m) => m.id == tempId));
          _showError('Gagal mengirim pesan');
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() => _messages.removeWhere((m) => m.id == tempId));
        _showError('Gagal mengirim pesan: timeout/jaringan');
      }
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  Future<void> _sendImage() async {
    final picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);
    if (image == null) return;

    final caption = _messageController.text.trim();
    setState(() => _isUploadingImage = true);

    try {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse(ApiConfig.uploadChatMediaEndpoint),
      );

      request.fields['key'] = widget.sessionKey;
      request.fields['roomId'] = 'global';
      request.fields['type'] = 'image';
      request.fields['caption'] = caption;

      final imageFile = await http.MultipartFile.fromPath('media', image.path);
      request.files.add(imageFile);

      final streamedResponse = await request.send().timeout(const Duration(seconds: 30));
      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          _messageController.clear();
          _showSuccess('Foto berhasil dikirim');
          await _loadMessages();
          _scrollToBottom();
        } else {
          _showError('Gagal mengupload gambar: ${data['message'] ?? ''}');
        }
      }
    } catch (e) {
      _showError('Gagal mengirim gambar');
    } finally {
      if (mounted) setState(() => _isUploadingImage = false);
    }
  }

  Future<void> _initRecorder() async {
    final status = await Permission.microphone.request();
    if (status != PermissionStatus.granted) {
      _showError('Izin mikrofon diperlukan');
      return;
    }
    await _audioRecorder.openRecorder();
  }

  Future<void> _startRecording() async {
    try {
      await _initRecorder();
      final directory = await getTemporaryDirectory();
      final path = '${directory.path}/voice_${DateTime.now().millisecondsSinceEpoch}.aac';
      await _audioRecorder.startRecorder(toFile: path, codec: Codec.aacADTS);

      setState(() {
        _isRecording = true;
        _recordingPath = path;
        _recordingDuration = 0;
      });
      _startRecordingTimer();
    } catch (e) {
      _showError('Gagal memulai rekaman');
    }
  }

  void _startRecordingTimer() {
    Future.delayed(const Duration(seconds: 1), () {
      if (_isRecording && mounted) {
        setState(() => _recordingDuration++);
        _startRecordingTimer();
      }
    });
  }

  Future<void> _stopRecording() async {
    try {
      await _audioRecorder.stopRecorder();
      setState(() => _isRecording = false);

      if (_recordingPath != null) {
        await _uploadVoiceNote(_recordingPath!);
      }
    } catch (e) {
      _showError('Gagal menghentikan rekaman');
      setState(() => _isRecording = false);
    }
  }

  Future<void> _uploadVoiceNote(String path) async {
    try {
      setState(() => _isSending = true);
      final request = http.MultipartRequest(
        'POST',
        Uri.parse(ApiConfig.uploadChatMediaEndpoint),
      );

      request.fields['key'] = widget.sessionKey;
      request.fields['roomId'] = 'global';
      request.fields['type'] = 'voice';
      request.fields['duration'] = _recordingDuration.toString();

      final voiceFile = await http.MultipartFile.fromPath('media', path);
      request.files.add(voiceFile);

      final streamedResponse = await request.send().timeout(const Duration(seconds: 30));
      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          _showSuccess('Voice note berhasil dikirim');
          await _loadMessages();
          _scrollToBottom();
        }
      }
    } catch (e) {
      _showError('Gagal mengirim voice note');
    } finally {
      if (mounted) {
        setState(() {
          _isSending = false;
          _recordingDuration = 0;
          _recordingPath = null;
        });
      }
    }
  }

  Future<void> _playVoiceNote(String url, String messageId) async {
    try {
      if (_currentPlayingId == messageId && _isPlayingVoice) {
        await _audioPlayer.stop();
        setState(() {
          _isPlayingVoice = false;
          _currentPlayingId = null;
        });
      } else {
        await _audioPlayer.play(UrlSource(url));
        setState(() {
          _isPlayingVoice = true;
          _currentPlayingId = messageId;
        });

        _audioPlayer.onPlayerComplete.listen((_) {
          if (mounted) {
            setState(() {
              _isPlayingVoice = false;
              _currentPlayingId = null;
            });
          }
        });
      }
    } catch (e) {
      _showError('Gagal memutar voice note');
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.error_outline, color: Colors.white),
            const SizedBox(width: 12),
            Flexible(child: Text(message, style: const TextStyle(fontSize: 14))),
          ],
        ),
        backgroundColor: const Color(0xFFE53935),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  void _showSuccess(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.check_circle_outline, color: Colors.white),
            const SizedBox(width: 12),
            Text(message, style: const TextStyle(fontSize: 14)),
          ],
        ),
        backgroundColor: const Color(0xFF43A047),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  void _showImageViewer(String imageUrl) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: EdgeInsets.zero,
          child: Stack(
            children: [
              GestureDetector(
                onTap: () => Navigator.of(context).pop(),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  color: Colors.black.withOpacity(0.95),
                ),
              ),
              Center(
                child: InteractiveViewer(
                  panEnabled: true,
                  boundaryMargin: const EdgeInsets.all(20),
                  minScale: 0.5,
                  maxScale: 4,
                  child: Hero(
                    tag: imageUrl,
                    child: Image.network(
                      imageUrl,
                      fit: BoxFit.contain,
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          width: 300,
                          height: 300,
                          color: secondaryBg,
                          child: const Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.broken_image, color: textGrey, size: 50),
                                SizedBox(height: 12),
                                Text('Gagal memuat gambar', style: TextStyle(color: textGrey)),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 50,
                right: 20,
                child: GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.6),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.close, color: Colors.white, size: 24),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: tp.bg,
        appBarTheme: const AppBarTheme(
          backgroundColor: secondaryBg,
          elevation: 0,
          iconTheme: IconThemeData(color: textWhite),
          titleTextStyle: TextStyle(color: textWhite, fontSize: 18, fontWeight: FontWeight.w600),
        ),
      ),
      child: Scaffold(
        appBar: _buildAppBar(),
        body: Column(
          children: [
            _buildOnlineUsersHeader(),
            const Divider(height: 1, color: subtleBorder),
            Expanded(
              child: Container(
                color: tp.bg,
                child: _isLoading
                    ? _buildLoadingIndicator()
                    : _buildMessagesList(),
              ),
            ),
            if (_isRecording) _buildRecordingIndicator(),
            _buildMessageInput(),
          ],
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      titleSpacing: 8,
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: const BoxDecoration(
              color: accentCyan,
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.people_alt_rounded, color: secondaryBg, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Global Chat',
                  style: TextStyle(
                    color: textWhite,
                    fontSize: 17,
                    fontWeight: FontWeight.w600,
                    letterSpacing: -0.2,
                  ),
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: _wsConnected ? accentGreen : Colors.orange,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      '${_onlineUsers.where((u) => u.isOnline).length} Online',
                      style: const TextStyle(
                        color: textGrey,
                        fontSize: 12,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.refresh_rounded),
          onPressed: _loadMessages,
          tooltip: 'Refresh',
        ),
      ],
    );
  }

  Widget _buildOnlineUsersHeader() {
    final onlineUsers = _onlineUsers.where((u) => u.isOnline).take(8).toList();

    return Container(
      color: secondaryBg,
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: onlineUsers.isEmpty
                    ? [
                        Text(
                          'Semua user terhubung',
                          style: TextStyle(color: textGrey.withOpacity(0.6), fontSize: 12),
                        )
                      ]
                    : onlineUsers
                        .map((user) => Padding(
                              padding: const EdgeInsets.only(right: 16),
                              child: _buildUserAvatar(user),
                            ))
                        .toList(),
              ),
            ),
          ),
          if (_onlineUsers.length > 8)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: accentCyan.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                '+${_onlineUsers.length - 8}',
                style: const TextStyle(
                  color: accentCyan,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildUserAvatar(ChatUser user) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Stack(
          children: [
            CircleAvatar(
              radius: 18,
              backgroundColor: _getRoleColor(user.role),
              child: Text(
                user.name.isNotEmpty ? user.name[0].toUpperCase() : '?',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Positioned(
              right: 0,
              bottom: 0,
              child: Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  color: accentGreen,
                  shape: BoxShape.circle,
                  border: Border.all(color: secondaryBg, width: 2),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        SizedBox(
          width: 48,
          child: Text(
            user.name.length > 6 ? '${user.name.substring(0, 6)}..' : user.name,
            textAlign: TextAlign.center,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: textGrey,
              fontSize: 10,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLoadingIndicator() {
    return const Center(
      child: CircularProgressIndicator(color: accentCyan),
    );
  }

  Widget _buildMessagesList() {
    if (_messages.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.chat_bubble_outline, color: textGrey.withOpacity(0.3), size: 60),
            const SizedBox(height: 16),
            Text(
              'Belum ada pesan.\nJadi yang pertama ngobrol! 👋',
              textAlign: TextAlign.center,
              style: TextStyle(color: textGrey.withOpacity(0.5), fontSize: 14),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
      itemCount: _messages.length,
      itemBuilder: (context, index) {
        final message = _messages[index];
        final isMe = message.senderId == widget.username;
        final isPrevSameSender = index > 0 && _messages[index - 1].senderId == message.senderId;

        return _buildMessageBubble(message, isMe, isPrevSameSender);
      },
    );
  }

  Widget _buildMessageBubble(ChatMessage message, bool isMe, bool isPrevSameSender) {
    final topMargin = isPrevSameSender ? 2.0 : 8.0;
    final isTempMsg = message.id.startsWith('temp_');

    return Container(
      margin: EdgeInsets.only(
        top: topMargin,
        bottom: 2,
        left: isMe ? 60 : 8,
        right: isMe ? 8 : 60,
      ),
      child: Row(
        mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isMe && !isPrevSameSender) ...[
            CircleAvatar(
              radius: 16,
              backgroundColor: _getRoleColor(message.senderRole),
              child: Text(
                message.senderName.isNotEmpty ? message.senderName[0].toUpperCase() : '?',
                style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(width: 8),
          ] else if (!isMe) ...[
            const SizedBox(width: 40),
          ],

          Flexible(
            child: Opacity(
              opacity: isTempMsg ? 0.7 : 1.0,
              child: Container(
                decoration: BoxDecoration(
                  color: isMe ? bubbleOutBg : bubbleInBg,
                  borderRadius: BorderRadius.only(
                    topLeft: const Radius.circular(14),
                    topRight: const Radius.circular(14),
                    bottomLeft: Radius.circular(isMe ? 14 : (isPrevSameSender ? 4 : 14)),
                    bottomRight: Radius.circular(isMe ? (isPrevSameSender ? 4 : 14) : 14),
                  ),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (!isMe && !isPrevSameSender) ...[
                      Row(
                        children: [
                          Text(
                            message.senderName,
                            style: TextStyle(
                              color: _getRoleColor(message.senderRole),
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                            decoration: BoxDecoration(
                              color: _getRoleColor(message.senderRole).withOpacity(0.2),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              message.senderRole.toUpperCase(),
                              style: TextStyle(
                                color: _getRoleColor(message.senderRole),
                                fontSize: 8,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                    ],

                    _buildMessageContent(message, isMe),

                    const SizedBox(height: 4),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          _formatTime(message.timestamp),
                          style: TextStyle(
                            color: isMe ? Colors.white60 : textGrey,
                            fontSize: 11,
                          ),
                        ),
                        if (isMe) ...[
                          const SizedBox(width: 4),
                          isTempMsg
                              ? const SizedBox(
                                  width: 12,
                                  height: 12,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 1.5,
                                    color: Colors.white60,
                                  ),
                                )
                              : const Icon(Icons.done_all, color: accentCyan, size: 16),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageContent(ChatMessage message, bool isMe) {
    switch (message.type) {
      case MessageType.text:
        return Text(
          message.content,
          style: const TextStyle(
            color: textWhite,
            fontSize: 15,
            height: 1.35,
            letterSpacing: -0.1,
          ),
        );
      case MessageType.image:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (message.mediaUrl != null)
              GestureDetector(
                onTap: () => _showImageViewer(message.mediaUrl!),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.network(
                    message.mediaUrl!,
                    width: 220,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        height: 150,
                        width: 220,
                        color: secondaryBg,
                        child: const Center(child: Icon(Icons.broken_image, color: textGrey)),
                      );
                    },
                    loadingBuilder: (context, child, loadingProgress) {
                      if (loadingProgress == null) return child;
                      return Container(
                        height: 150,
                        width: 220,
                        color: secondaryBg,
                        child: Center(
                          child: CircularProgressIndicator(
                            color: accentCyan,
                            strokeWidth: 2,
                            value: loadingProgress.expectedTotalBytes != null
                                ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                                : null,
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            if (message.content.isNotEmpty && message.content != '📷 Photo')
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  message.content,
                  style: const TextStyle(color: textWhite, fontSize: 14, height: 1.3),
                ),
              ),
          ],
        );
      case MessageType.voice:
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            GestureDetector(
              onTap: () => message.mediaUrl != null
                  ? _playVoiceNote(message.mediaUrl!, message.id)
                  : null,
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _currentPlayingId == message.id && _isPlayingVoice
                      ? accentCyan.withOpacity(0.2)
                      : Colors.transparent,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  _currentPlayingId == message.id && _isPlayingVoice
                      ? Icons.pause
                      : Icons.play_arrow,
                  color: accentCyan,
                  size: 24,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: List.generate(
                    20,
                    (index) => Container(
                      width: 2,
                      height: _currentPlayingId == message.id && _isPlayingVoice
                          ? (index % 3 == 0 ? 12 : (index % 3 == 1 ? 18 : 8))
                          : (index % 4 == 0 ? 8 : 14),
                      margin: const EdgeInsets.symmetric(horizontal: 1),
                      decoration: BoxDecoration(
                        color: _currentPlayingId == message.id && _isPlayingVoice
                            ? accentCyan
                            : (isMe ? Colors.white38 : textGrey.withOpacity(0.5)),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    if (message.duration != null)
                      Text(
                        '${message.duration}s',
                        style: TextStyle(
                          color: isMe ? Colors.white70 : textGrey,
                          fontSize: 11,
                        ),
                      ),
                    if (_currentPlayingId == message.id && _isPlayingVoice) ...[
                      const SizedBox(width: 8),
                      const Text(
                        'Playing',
                        style: TextStyle(color: accentCyan, fontSize: 11, fontWeight: FontWeight.w500),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ],
        );
    }
  }

  Widget _buildRecordingIndicator() {
    return Container(
      color: secondaryBg,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          const Icon(Icons.cancel, color: Colors.redAccent),
          const SizedBox(width: 24),
          Row(
            children: List.generate(
              15,
              (index) => Container(
                width: 3,
                height: 8 + (index % 4) * 4.0,
                margin: const EdgeInsets.symmetric(horizontal: 1.5),
                decoration: BoxDecoration(
                  color: Colors.redAccent,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
          ),
          const SizedBox(width: 24),
          Text(
            '${_recordingDuration ~/ 60}:${(_recordingDuration % 60).toString().padLeft(2, '0')}',
            style: const TextStyle(color: textWhite, fontSize: 16, fontWeight: FontWeight.w500, letterSpacing: 1),
          ),
          const Spacer(),
          GestureDetector(
            onTap: _stopRecording,
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: const BoxDecoration(
                color: accentCyan,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.send, color: secondaryBg, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageInput() {
    return Container(
      padding: const EdgeInsets.only(left: 12, right: 8, top: 10, bottom: 10),
      decoration: const BoxDecoration(
        color: secondaryBg,
        border: Border(top: BorderSide(color: subtleBorder, width: 1)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          _buildCircleButton(
            icon: Icons.attach_file_rounded,
            color: textGrey,
            onTap: _isUploadingImage ? null : _sendImage,
            isLoading: _isUploadingImage,
          ),
          const SizedBox(width: 8),
          Flexible(
            child: Container(
              decoration: BoxDecoration(
                color: tp.bg,
                borderRadius: BorderRadius.circular(22),
              ),
              child: TextField(
                controller: _messageController,
                focusNode: _focusNode,
                style: const TextStyle(color: textWhite, fontSize: 15, height: 1.3),
                decoration: InputDecoration(
                  hintText: 'Pesan',
                  hintStyle: TextStyle(color: textGrey.withOpacity(0.7), fontSize: 15),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                  isDense: true,
                ),
                maxLines: 5,
                minLines: 1,
                textInputAction: TextInputAction.newline,
                keyboardType: TextInputType.multiline,
              ),
            ),
          ),
          const SizedBox(width: 8),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 200),
            child: _messageController.text.trim().isNotEmpty || _isSending
                ? _buildCircleButton(
                    key: const ValueKey('send'),
                    icon: Icons.send_rounded,
                    color: accentCyan,
                    bgColor: accentCyan,
                    iconColor: secondaryBg,
                    onTap: _isSending ? null : _sendMessage,
                    isLoading: false,
                  )
                : _buildCircleButton(
                    key: const ValueKey('mic'),
                    icon: Icons.mic_rounded,
                    color: textGrey,
                    onTap: _isRecording ? _stopRecording : _startRecording,
                    isActive: _isRecording,
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildCircleButton({
    required IconData icon,
    required Color color,
    Color? bgColor,
    Color? iconColor,
    VoidCallback? onTap,
    bool isLoading = false,
    bool isActive = false,
    Key? key,
  }) {
    return SizedBox(
      key: key,
      height: 44,
      width: 44,
      child: IconButton(
        onPressed: onTap,
        padding: EdgeInsets.zero,
        icon: isLoading
            ? SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  color: iconColor ?? color,
                  strokeWidth: 2,
                ),
              )
            : Container(
                decoration: BoxDecoration(
                  color: isActive ? Colors.redAccent.withOpacity(0.2) : (bgColor ?? Colors.transparent),
                  shape: BoxShape.circle,
                ),
                padding: const EdgeInsets.all(2),
                child: Icon(
                  icon,
                  color: iconColor ?? (isActive ? Colors.redAccent : color),
                  size: 22,
                ),
              ),
      ),
    );
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case 'owner':
        return const Color(0xFFE040FB);
      case 'admin':
        return const Color(0xFFFFAB40);
      case 'reseller':
        return accentCyan;
      default:
        return textGrey;
    }
  }

  String _formatTime(DateTime timestamp) {
    return DateFormat('HH:mm').format(timestamp);
  }
}
