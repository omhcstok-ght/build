import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      default:
        return android;
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyCdbBCB8qWcOYm1tWyrRuNWlB0AR0a0t2s',
    appId: '1:1048647550598:android:f191793822f063fa72b307',
    messagingSenderId: '1048647550598',
    projectId: 'hanz-2b797',
    storageBucket: 'hanz-2b797.firebasestorage.app',
  );
}
