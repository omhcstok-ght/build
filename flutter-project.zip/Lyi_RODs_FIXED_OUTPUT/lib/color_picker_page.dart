import 'package:flutter/material.dart';
import 'theme_provider.dart';

class ColorPickerPage extends StatefulWidget {
  const ColorPickerPage({super.key});

  @override
  State<ColorPickerPage> createState() => _ColorPickerPageState();
}

class _ColorPickerPageState extends State<ColorPickerPage>
    with SingleTickerProviderStateMixin {
  ThemeProvider get tp => ThemeProvider();
  late TabController _tab;

  // Custom picker state
  double _primaryH = 0, _primaryS = 0.7, _primaryV = 0.4;
  double _accentH  = 0, _accentS  = 0.8, _accentV  = 0.7;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
    // init slider dari tema aktif
    final hsv1 = HSVColor.fromColor(tp.primary);
    _primaryH = hsv1.hue; _primaryS = hsv1.saturation; _primaryV = hsv1.value;
    final hsv2 = HSVColor.fromColor(tp.accent);
    _accentH = hsv2.hue; _accentS = hsv2.saturation; _accentV = hsv2.value;
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  Color get _previewPrimary =>
      HSVColor.fromAHSV(1, _primaryH, _primaryS, _primaryV).toColor();
  Color get _previewAccent =>
      HSVColor.fromAHSV(1, _accentH, _accentS, _accentV).toColor();

  @override
  Widget build(BuildContext context) {
    final accent = tp.accent;
    final bg     = tp.bg;
    final card   = tp.card;

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: card,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_rounded, color: accent),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'THEME COLOR',
          style: TextStyle(
            color: accent,
            fontFamily: 'Rajdhani',
            fontWeight: FontWeight.w800,
            letterSpacing: 3,
            shadows: [Shadow(color: accent, blurRadius: 10)],
          ),
        ),
        bottom: TabBar(
          controller: _tab,
          indicatorColor: accent,
          labelColor: accent,
          unselectedLabelColor: Colors.grey,
          labelStyle: const TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.w700),
          tabs: const [Tab(text: 'PRESET'), Tab(text: 'CUSTOM')],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [_buildPresetTab(bg, card, accent), _buildCustomTab(bg, card, accent)],
      ),
    );
  }

  // ── TAB PRESET ──────────────────────────────────────────────────────────────
  Widget _buildPresetTab(Color bg, Color card, Color accent) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Pilih Tema', style: _labelStyle(accent)),
        const SizedBox(height: 12),
        ...ThemeProvider.presets.map((preset) {
          final isActive = tp.primary.value == preset.primary.value &&
              tp.accent.value == preset.accent.value;
          return GestureDetector(
            onTap: () async {
              await tp.applyPreset(preset);
              setState(() {});
              _showSnack('Tema "${preset.name}" diterapkan!');
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: isActive ? preset.accent : preset.accent.withOpacity(0.2),
                  width: isActive ? 2 : 1,
                ),
                boxShadow: isActive
                    ? [BoxShadow(color: preset.accent.withOpacity(0.3), blurRadius: 20)]
                    : null,
              ),
              child: Row(
                children: [
                  // Preview swatch
                  Container(
                    width: 48, height: 48,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      gradient: LinearGradient(
                        colors: [preset.primary, preset.accent],
                      ),
                      boxShadow: [BoxShadow(color: preset.accent.withOpacity(0.5), blurRadius: 10)],
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(preset.name,
                          style: TextStyle(
                            color: Colors.white,
                            fontFamily: 'Rajdhani',
                            fontWeight: FontWeight.w700,
                            fontSize: 16,
                            shadows: [Shadow(color: preset.accent, blurRadius: 6)],
                          )),
                        const SizedBox(height: 4),
                        Row(children: [
                          _colorDot(preset.primary),
                          const SizedBox(width: 6),
                          _colorDot(preset.accent),
                          const SizedBox(width: 6),
                          _colorDot(preset.bg),
                        ]),
                      ],
                    ),
                  ),
                  if (isActive)
                    Icon(Icons.check_circle_rounded, color: preset.accent, size: 22),
                ],
              ),
            ),
          );
        }),
      ],
    );
  }

  // ── TAB CUSTOM ───────────────────────────────────────────────────────────────
  Widget _buildCustomTab(Color bg, Color card, Color accent) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Preview
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: card,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _previewAccent.withOpacity(0.4)),
              boxShadow: [BoxShadow(color: _previewAccent.withOpacity(0.2), blurRadius: 20)],
            ),
            child: Column(children: [
              Text('PREVIEW', style: TextStyle(
                color: _previewAccent, fontFamily: 'Rajdhani',
                fontWeight: FontWeight.w800, letterSpacing: 3,
                shadows: [Shadow(color: _previewAccent, blurRadius: 8)],
              )),
              const SizedBox(height: 12),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                _previewSwatch('Primary', _previewPrimary),
                const SizedBox(width: 16),
                _previewSwatch('Accent', _previewAccent),
              ]),
            ]),
          ),
          const SizedBox(height: 24),

          // Primary sliders
          Text('PRIMARY COLOR', style: _labelStyle(accent)),
          const SizedBox(height: 8),
          _hsvSlider('Hue', _primaryH, 0, 360, accent, (v) => setState(() => _primaryH = v)),
          _hsvSlider('Saturation', _primaryS, 0, 1, accent, (v) => setState(() => _primaryS = v)),
          _hsvSlider('Value/Bright', _primaryV, 0, 1, accent, (v) => setState(() => _primaryV = v)),

          const SizedBox(height: 20),

          // Accent sliders
          Text('ACCENT COLOR', style: _labelStyle(accent)),
          const SizedBox(height: 8),
          _hsvSlider('Hue', _accentH, 0, 360, accent, (v) => setState(() => _accentH = v)),
          _hsvSlider('Saturation', _accentS, 0, 1, accent, (v) => setState(() => _accentS = v)),
          _hsvSlider('Value/Bright', _accentV, 0, 1, accent, (v) => setState(() => _accentV = v)),

          const SizedBox(height: 28),

          // Apply button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: _previewAccent,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                shadowColor: _previewAccent.withOpacity(0.6),
                elevation: 8,
              ),
              icon: const Icon(Icons.check_rounded, color: Colors.black),
              label: const Text('TERAPKAN', style: TextStyle(
                color: Colors.black,
                fontFamily: 'Rajdhani',
                fontWeight: FontWeight.w800,
                fontSize: 16,
                letterSpacing: 2,
              )),
              onPressed: () async {
                await tp.applyCustom(
                  primary: _previewPrimary,
                  accent: _previewAccent,
                );
                setState(() {});
                _showSnack('Warna custom diterapkan!');
              },
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  // ── HELPERS ──────────────────────────────────────────────────────────────────
  Widget _hsvSlider(String label, double value, double min, double max,
      Color accent, ValueChanged<double> onChanged) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(children: [
        SizedBox(width: 90,
          child: Text(label, style: const TextStyle(
            color: Colors.grey, fontFamily: 'Rajdhani', fontSize: 13))),
        Expanded(child: SliderTheme(
          data: SliderThemeData(
            activeTrackColor: accent,
            thumbColor: accent,
            overlayColor: accent.withOpacity(0.2),
            inactiveTrackColor: Colors.grey.shade800,
          ),
          child: Slider(value: value, min: min, max: max, onChanged: onChanged),
        )),
      ]),
    );
  }

  Widget _colorDot(Color c) => Container(
    width: 14, height: 14,
    decoration: BoxDecoration(color: c, shape: BoxShape.circle,
      border: Border.all(color: Colors.white12)),
  );

  Widget _previewSwatch(String label, Color c) => Column(children: [
    Container(width: 60, height: 60,
      decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(12),
        boxShadow: [BoxShadow(color: c.withOpacity(0.5), blurRadius: 12)])),
    const SizedBox(height: 6),
    Text(label, style: const TextStyle(color: Colors.grey, fontFamily: 'Rajdhani', fontSize: 12)),
  ]);

  TextStyle _labelStyle(Color c) => TextStyle(
    color: c, fontFamily: 'Rajdhani', fontWeight: FontWeight.w700,
    fontSize: 13, letterSpacing: 2,
  );

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.w700)),
      backgroundColor: tp.accent.withOpacity(0.9),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      duration: const Duration(seconds: 2),
    ));
  }
}
