import 'dart:io';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'firebase_options.dart'; // ← TAMBAH INI

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  debugPrint('[FCM] BG message: ${message.notification?.title}');
}

class FCMService {
  FCMService._();
  static final FCMService instance = FCMService._();

  late final FirebaseMessaging _messaging;
  final FlutterLocalNotificationsPlugin _localNotif =
      FlutterLocalNotificationsPlugin();

  static const String _channelId = 'broadcast_channel';
  static const String _channelName = 'Broadcast Notifikasi';
  static const String _topic = 'broadcast_notif';

  Future<void> init() async {
    // 1. Init Firebase dengan options eksplisit
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform, // ← TAMBAH INI
    );

    // 1b. Assign messaging setelah Firebase init
    _messaging = FirebaseMessaging.instance;

    // 2. Set background handler
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

    // 3. Setup local notifications
    await _initLocalNotifications();

    // 4. Minta permission
    await _requestPermission();

    // 5. Subscribe ke topic
    await _messaging.subscribeToTopic(_topic);
    debugPrint('[FCM] Subscribed to topic: $_topic');

    // 6. Log token
    final token = await _messaging.getToken();
    debugPrint('[FCM] Token: $token');

    // 7. Foreground handler
    FirebaseMessaging.onMessage.listen(_onForegroundMessage);

    // 8. Background tap handler
    FirebaseMessaging.onMessageOpenedApp.listen(_onNotifTapped);

    // 9. Terminated state
    final initialMessage = await _messaging.getInitialMessage();
    if (initialMessage != null) {
      _onNotifTapped(initialMessage);
    }
  }

  Future<void> _initLocalNotifications() async {
    const androidChannel = AndroidNotificationChannel(
      _channelId,
      _channelName,
      description: 'Notifikasi broadcast dari RODS PROJECT',
      importance: Importance.high,
      playSound: true,
    );

    await _localNotif
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(androidChannel);

    const initSettings = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(
        requestAlertPermission: true,
        requestBadgePermission: true,
        requestSoundPermission: true,
      ),
    );

    await _localNotif.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (details) {
        debugPrint('[FCM] Notif tapped (foreground): ${details.payload}');
      },
    );

    await _messaging.setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );
  }

  Future<void> _requestPermission() async {
    if (Platform.isAndroid || Platform.isIOS) {
      final settings = await _messaging.requestPermission(
        alert: true,
        badge: true,
        sound: true,
        provisional: false,
      );
      debugPrint('[FCM] Permission: ${settings.authorizationStatus}');
    }
  }

  Future<void> _onForegroundMessage(RemoteMessage message) async {
    debugPrint('[FCM] Foreground: ${message.notification?.title}');

    final notification = message.notification;
    final android = message.notification?.android;

    if (notification != null) {
      await _localNotif.show(
        notification.hashCode,
        notification.title,
        notification.body,
        NotificationDetails(
          android: AndroidNotificationDetails(
            _channelId,
            _channelName,
            channelDescription: 'Notifikasi broadcast dari RODS PROJECT',
            importance: Importance.high,
            priority: Priority.high,
            icon: android?.smallIcon ?? '@mipmap/ic_launcher',
            color: const Color(0xFFE63946),
            playSound: true,
            enableVibration: true,
          ),
          iOS: const DarwinNotificationDetails(
            presentAlert: true,
            presentBadge: true,
            presentSound: true,
          ),
        ),
        payload: message.data.toString(),
      );
    }
  }

  void _onNotifTapped(RemoteMessage message) {
    debugPrint('[FCM] Notif tapped: ${message.data}');
  }

  Future<void> unsubscribe() async {
    await _messaging.unsubscribeFromTopic(_topic);
  }

  Future<String?> getToken() => _messaging.getToken();
}
