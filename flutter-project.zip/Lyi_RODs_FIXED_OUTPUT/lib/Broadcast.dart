import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'dart:convert';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Broadcast Receiver',
      theme: ThemeData.dark(),
      home: const BroadcastPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class BroadcastPage extends StatefulWidget {
  const BroadcastPage({super.key});

  @override
  State<BroadcastPage> createState() => _BroadcastPageState();
}

class _BroadcastPageState extends State<BroadcastPage> {
  late WebSocketChannel _channel;
  final List<Map<String, String>> _messages = [];
  bool _isConnected = false;

  final TextEditingController _serverUrlController = TextEditingController(
    text: 'ws://console.miunnst.site:5289', // untuk emulator Android, localhost host machine
    // Gunakan 'ws://192.168.x.x:3000' untuk device fisik (ganti dengan IP komputer server)
  );

  @override
  void dispose() {
    _disconnect();
    _serverUrlController.dispose();
    super.dispose();
  }

  void _connect() {
    final url = _serverUrlController.text.trim();
    if (url.isEmpty) return;

    _channel = WebSocketChannel.connect(Uri.parse(url));
    setState(() {
      _isConnected = true;
      _messages.clear();
    });

    _channel.stream.listen(
      (data) {
        // data dari server sudah berupa string JSON { message, timestamp }
        try {
          final json = Map<String, dynamic>.from(await _parseJson(data));
          final msg = json['message'] ?? data.toString();
          final time = json['timestamp'] != null
              ? DateTime.parse(json['timestamp']).toLocal().toString()
              : DateTime.now().toLocal().toString();
          setState(() {
            _messages.insert(0, {'message': msg, 'time': time});
          });
        } catch (e) {
          // fallback jika bukan JSON
          setState(() {
            _messages.insert(0, {'message': data.toString(), 'time': DateTime.now().toLocal().toString()});
          });
        }
      },
      onDone: () {
        setState(() {
          _isConnected = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Koneksi WebSocket terputus')),
        );
      },
      onError: (error) {
        setState(() {
          _isConnected = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $error')),
        );
      },
    );
  }

  // Helper untuk parsing JSON dari stream (karena stream tidak async)
  Future<dynamic> _parseJson(String data) async {
    return await Future.value(Map<String, dynamic>.from(
        (() {return data;})() as Map)); // sederhana
  }
  // Perbaiki parsing JSON di atas dengan method yang benar:
  // Pada praktiknya, gunakan jsonDecode(data) lalu konversi ke Map.
  // Tapi untuk singkat, saya tulis ulang bagian listen agar benar:

  // Seharusnya:
  /*
    _channel.stream.listen((data) {
      final decoded = jsonDecode(data as String);
      final msg = decoded['message'];
      final time = DateTime.parse(decoded['timestamp']).toLocal().toString();
      setState(() => _messages.insert(0, {'message': msg, 'time': time}));
    });
  */
  // Namun karena kode di atas kurang rapi, saya akan tulis ulang dengan benar di bawah.
}

// === VERSI LEBIH BERSIH (ganti seluruh class di atas dengan ini) ===
// Saya tulis ulang secara lengkap dan benar agar tidak error.

class BroadcastPage extends StatefulWidget {
  const BroadcastPage({super.key});

  @override
  State<BroadcastPage> createState() => _BroadcastPageState();
}

class _BroadcastPageState extends State<BroadcastPage> {
  late WebSocketChannel _channel;
  final List<Map<String, String>> _messages = [];
  bool _isConnected = false;
  final TextEditingController _serverUrlController = TextEditingController(
    text: 'ws://10.0.2.2:3000',
  );

  @override
  void dispose() {
    _disconnect();
    _serverUrlController.dispose();
    super.dispose();
  }

  void _connect() {
    final url = _serverUrlController.text.trim();
    if (url.isEmpty) return;
    _disconnect(); // pastikan yang lama ditutup

    _channel = WebSocketChannel.connect(Uri.parse(url));
    setState(() {
      _isConnected = true;
      _messages.clear();
    });

    _channel.stream.listen(
      (dynamic data) {
        try {
          final Map<String, dynamic> json = 
              Map<String, dynamic>.from(data is String ? jsonDecode(data) : data);
          final msg = json['message'] ?? 'No message';
          final time = json['timestamp'] != null
              ? DateTime.parse(json['timestamp']).toLocal().toString()
              : DateTime.now().toLocal().toString();
          setState(() {
            _messages.insert(0, {'message': msg, 'time': time});
          });
        } catch (e) {
          setState(() {
            _messages.insert(0, {
              'message': data.toString(),
              'time': DateTime.now().toLocal().toString()
            });
          });
        }
      },
      onDone: () {
        setState(() => _isConnected = false);
        _showSnack('Koneksi ditutup server');
      },
      onError: (err) {
        setState(() => _isConnected = false);
        _showSnack('Error: $err');
      },
    );
  }

  void _disconnect() {
    if (_channel != null) {
      _channel.sink.close();
    }
    if (_isConnected) {
      setState(() => _isConnected = false);
    }
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Broadcast Receiver (WebSocket)'),
        backgroundColor: Colors.deepPurple,
        actions: [
          if (_isConnected)
            IconButton(
              icon: const Icon(Icons.close),
              onPressed: _disconnect,
              tooltip: 'Putus',
            ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _serverUrlController,
                    decoration: InputDecoration(
                      labelText: 'WebSocket URL',
                      hintText: 'ws://ip:port',
                      border: OutlineInputBorder(),
                      suffixIcon: _isConnected
                          ? const Icon(Icons.check_circle, color: Colors.green)
                          : null,
                    ),
                    enabled: !_isConnected,
                  ),
                ),
                const SizedBox(width: 12),
                if (!_isConnected)
                  ElevatedButton.icon(
                    onPressed: _connect,
                    icon: const Icon(Icons.wifi),
                    label: const Text('Hubung'),
                  ),
              ],
            ),
          ),
          Expanded(
            child: _messages.isEmpty
                ? const Center(child: Text('Belum ada pesan masuk'))
                : ListView.builder(
                    reverse: true,
                    itemCount: _messages.length,
                    itemBuilder: (ctx, i) {
                      final item = _messages[i];
                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        child: ListTile(
                          title: Text(item['message']!),
                          subtitle: Text(item['time']!),
                          leading: const Icon(Icons.message, color: Colors.amber),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
