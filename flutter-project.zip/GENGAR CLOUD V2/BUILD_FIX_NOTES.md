Xyro V4 — build error fixes

Changes applied from the supplied Flutter 3.38.0 build log:
- Font Awesome contact entries now store FaIconData and no longer access `.data` inside a const list.
- Added the missing `theme.dart` import in riwayat_page.dart for AppColors.
- Removed const from widgets/gradients that referenced runtime theme getters in check_banned_page.dart, wifi_internal.dart, wifi_external.dart, ddos_panel.dart, tiktok_page.dart, device_dashboard.dart, and control_panel.dart.
- Changed _GradBtn's gradient default to nullable and resolves the runtime theme gradient in build.
- Changed _toast color parameter to nullable and resolves the dynamic theme accent inside the method.

Validation: ZIP integrity checked. Flutter analyze/build was not run in this environment because Flutter SDK is unavailable here; run `flutter pub get`, `flutter analyze`, and `flutter build apk --release` in the build worker.
