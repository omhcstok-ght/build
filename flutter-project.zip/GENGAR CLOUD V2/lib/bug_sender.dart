// bug_sender.dart
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'theme.dart'; // WAJIB IMPORT THEME

const String kFont = 'Pek';

class BugSenderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const BugSenderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage> with SingleTickerProviderStateMixin {
  List<dynamic> senderList = [];
  bool isLoading = false;
  String? errorMessage;
  late PageController _pageController;
  int _currentPage = 0;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: 0.88, initialPage: 0);
    _fetchSenders();
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _fetchSenders() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final response = await http.get(
        Uri.parse("http://hetters-xloww.ryuuuprvt.my.id:2947/mySender?key=${widget.sessionKey}"),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          setState(() {
            senderList = data["connections"] ?? [];
          });
        } else {
          setState(() => errorMessage = data["message"] ?? "Failed to fetch senders");
        }
      } else {
        setState(() => errorMessage = "Server error: ${response.statusCode}");
      }
    } catch (e) {
      setState(() => errorMessage = "Connection failed: $e");
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    final bg = AppColors.bg;
    final primary = AppColors.accent;
    final text = AppColors.text;
    final textSub = AppColors.textSub;
    final border = AppColors.border;
    final card = AppColors.card;

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded, color: text, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          "SENDER MANAGEMENT",
          style: TextStyle(
            color: text,
            fontSize: 16,
            fontWeight: FontWeight.w800,
            fontFamily: kFont,
            letterSpacing: 1.5,
          ),
        ),
        centerTitle: true,
      ),
      body: AppBackground(
        imagePath: 'assets/images/mmk.jpg',
        child: SafeArea(
          child: Column(
            children: [
              if (isLoading && senderList.isEmpty)
                Expanded(
                  child: Center(
                    child: CircularProgressIndicator(color: primary, strokeWidth: 3),
                  ),
                )
              else if (errorMessage != null && senderList.isEmpty)
                Expanded(
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.error_outline_rounded, color: AppColors.red, size: 60),
                        const SizedBox(height: 16),
                        Text(
                          errorMessage!,
                          style: TextStyle(color: textSub, fontFamily: kFont),
                        ),
                        const SizedBox(height: 16),
                        ElevatedButton(
                          onPressed: _fetchSenders,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: primary,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                            ),
                          ),
                          child: Text("RETRY", style: TextStyle(color: text)),
                        )
                      ],
                    ),
                  ),
                )
              else if (senderList.isEmpty)
                Expanded(
                  child: _buildEmptyState(isComic, primary, textSub),
                )
              else
                Expanded(
                  child: Column(
                    children: [
                      const SizedBox(height: 20),
                      SizedBox(
                        height: 350,
                        child: PageView.builder(
                          controller: _pageController,
                          onPageChanged: (index) {
                            setState(() => _currentPage = index);
                          },
                          itemCount: senderList.length,
                          itemBuilder: (context, index) {
                            final sender = Map<String, dynamic>.from(senderList[index]);
                            return _buildSenderCard(sender, index, isComic, card, border, primary, text, textSub);
                          },
                        ),
                      ),
                      const SizedBox(height: 20),
                      // Page Indicator
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(senderList.length, (index) {
                          final isActive = index == _currentPage;
                          return AnimatedContainer(
                            duration: const Duration(milliseconds: 300),
                            margin: const EdgeInsets.symmetric(horizontal: 4),
                            width: isActive ? 24 : 8,
                            height: 8,
                            decoration: BoxDecoration(
                              color: isActive ? primary : border,
                              borderRadius: BorderRadius.circular(4),
                              boxShadow: isActive && !isComic
                                  ? [BoxShadow(color: primary.withOpacity(0.5), blurRadius: 8)]
                                  : null,
                            ),
                          );
                        }),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddSenderDialog(),
        backgroundColor: primary,
        child: Icon(Icons.add_rounded, color: isComic ? const Color(0xFF1A1A1A) : Colors.white, size: 28),
      ),
    );
  }

  Widget _buildEmptyState(bool isComic, Color primary, Color textSub) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.phone_iphone_rounded, color: textSub.withOpacity(0.5), size: 80),
          const SizedBox(height: 20),
          Text(
            "BELUM ADA SENDER",
            style: TextStyle(
              color: textSub,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: kFont,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            "Klik tombol + di bawah untuk\nmenambahkan sender baru",
            textAlign: TextAlign.center,
            style: TextStyle(color: textSub, fontFamily: kFont, fontSize: 13),
          ),
        ],
      ),
    );
  }

  Widget _buildSenderCard(Map<String, dynamic> sender, int index, bool isComic, Color card, Color border, Color primary, Color text, Color textSub) {
    final name = sender['sessionName'] ?? 'Unnamed Sender';
    final phone = sender['id']?.split(':')[0]?.split('@')[0] ?? 'Unknown';
    
    return AnimatedBuilder(
      animation: _pageController,
      builder: (context, child) {
        double scale = 1.0;
        if (_pageController.position.haveDimensions) {
          final value = (_pageController.page ?? 0) - index;
          scale = (1 - (value.abs() * 0.1)).clamp(0.9, 1.0);
        }

        return Transform.scale(
          scale: scale,
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: card,
              borderRadius: BorderRadius.circular(AppColors.cardRadius),
              border: Border.all(color: border, width: AppColors.borderWidth),
              boxShadow: AppColors.glassShadow,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 80, height: 80,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: AppColors.btnGrad,
                    border: isComic ? Border.all(color: border, width: 3) : null,
                    boxShadow: isComic ? null : [BoxShadow(color: primary.withOpacity(0.4), blurRadius: 20)],
                  ),
                  child: Icon(Icons.phone_android_rounded, color: isComic ? const Color(0xFF1A1A1A) : Colors.white, size: 36),
                ),
                const SizedBox(height: 24),
                Text(
                  name.toUpperCase(),
                  style: TextStyle(color: text, fontSize: 20, fontWeight: FontWeight.w900, fontFamily: kFont, letterSpacing: 1),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                Text(
                  phone,
                  style: TextStyle(color: textSub, fontSize: 14, fontFamily: kFont),
                ),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppColors.green.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(isComic ? 4 : 20),
                    border: Border.all(color: AppColors.green.withOpacity(0.5), width: 1),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(width: 8, height: 8, decoration: BoxDecoration(color: AppColors.green, shape: BoxShape.circle)),
                      const SizedBox(width: 8),
                      Text("TERHUBUNG", style: TextStyle(color: AppColors.green, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: kFont)),
                    ],
                  ),
                ),
                const SizedBox(height: 30),
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => _fetchSenders(),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          decoration: BoxDecoration(
                            color: primary.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                            border: Border.all(color: primary.withOpacity(0.3)),
                          ),
                          child: Center(
                            child: Icon(Icons.refresh_rounded, color: primary, size: 22),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: GestureDetector(
                        onTap: () => _deleteSender(sender['id']),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          decoration: BoxDecoration(
                            color: AppColors.red.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                            border: Border.all(color: AppColors.red.withOpacity(0.3)),
                          ),
                          child: Center(
                            child: Icon(Icons.delete_outline_rounded, color: AppColors.red, size: 22),
                          ),
                        ),
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
        );
      },
    );
  }

  void _showAddSenderDialog() {
    final phoneController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) {
        final isComic = ThemeModeManager.isComic3d;
        return AlertDialog(
          backgroundColor: AppColors.card,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppColors.cardRadius),
            side: BorderSide(color: AppColors.border, width: AppColors.borderWidth),
          ),
          title: Text("TAMBAH SENDER", style: TextStyle(color: AppColors.text, fontFamily: kFont, fontWeight: FontWeight.bold)),
          content: TextField(
            controller: phoneController,
            keyboardType: TextInputType.phone,
            style: TextStyle(color: AppColors.text, fontFamily: kFont),
            decoration: InputDecoration(
              hintText: "628xxxxxxxxxx",
              hintStyle: TextStyle(color: AppColors.textHint, fontFamily: kFont),
              filled: true,
              fillColor: AppColors.dark,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                borderSide: BorderSide(color: AppColors.border),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("BATAL", style: TextStyle(color: AppColors.textSub, fontFamily: kFont)),
            ),
            ElevatedButton(
              onPressed: () {
                if (phoneController.text.isNotEmpty) {
                  Navigator.pop(context);
                  _addSender(phoneController.text.trim());
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.accent,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(isComic ? 4 : 12)),
              ),
              child: Text("LANJUT", style: TextStyle(color: isComic ? const Color(0xFF1A1A1A) : Colors.white, fontFamily: kFont, fontWeight: FontWeight.bold)),
            ),
          ],
        );
      },
    );
  }

  Future<void> _addSender(String number) async {
    showDialog(context: context, barrierDismissible: false, builder: (_) => Center(child: CircularProgressIndicator(color: AppColors.accent)));
    try {
      final res = await http.get(Uri.parse("http://hetters-xloww.ryuuuprvt.my.id:2947/getPairing?key=${widget.sessionKey}&number=$number"));
      Navigator.pop(context); // Close loading
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _showPairingDialog(number, data['pairingCode']);
      } else {
        _showSnackbar(data['message'] ?? "Gagal generate kode");
      }
    } catch (e) {
      Navigator.pop(context);
      _showSnackbar("Koneksi error: $e");
    }
  }

  void _showPairingDialog(String number, String code) {
    final isComic = ThemeModeManager.isComic3d;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppColors.cardRadius),
          side: BorderSide(color: AppColors.border, width: AppColors.borderWidth),
        ),
        title: Row(
          children: [
            Icon(Icons.qr_code_scanner_rounded, color: AppColors.accent),
            const SizedBox(width: 10),
            Text("PAIRING CODE", style: TextStyle(color: AppColors.text, fontFamily: kFont, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text("Masukkan kode ini di WhatsApp > Linked Devices:", style: TextStyle(color: AppColors.textSub, fontFamily: kFont, fontSize: 12)),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.dark,
                borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                border: Border.all(color: AppColors.accent.withOpacity(0.5)),
              ),
              child: Text(
                code,
                style: TextStyle(color: AppColors.accent, fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: 5, fontFamily: kFont),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _fetchSenders();
            },
            child: Text("TUTUP & REFRESH", style: TextStyle(color: AppColors.accent, fontFamily: kFont, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteSender(String id) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppColors.cardRadius)),
        title: Text("Hapus Sender?", style: TextStyle(color: AppColors.text, fontFamily: kFont)),
        content: Text("Yakin ingin menghapus sender ini?", style: TextStyle(color: AppColors.textSub, fontFamily: kFont)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text("BATAL", style: TextStyle(color: AppColors.textSub))),
          TextButton(onPressed: () => Navigator.pop(context, true), child: Text("HAPUS", style: TextStyle(color: AppColors.red))),
        ],
      ),
    );
    if (confirm == true) {
      try {
        await http.delete(Uri.parse("http://hetters-xloww.ryuuuprvt.my.id:2947/deleteSender?key=${widget.sessionKey}&id=$id"));
        _fetchSenders();
      } catch (_) {}
    }
  }

  void _showSnackbar(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg, style: TextStyle(fontFamily: kFont)), backgroundColor: AppColors.red));
  }
}