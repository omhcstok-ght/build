// main.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'theme.dart';   
import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'landing.dart';
import 'fingerprint_gengar.dart'; 

class _AppTheme {
  static const _font = 'ShareTechMono';

  static ThemeData build() {
    final bg          = AppColors.bg;
    final surface     = AppColors.dark;
    final card        = AppColors.card;
    final border      = AppColors.border;
    final borderLit   = AppColors.borderLit;
    final primary     = AppColors.accent;
    final primaryMid  = AppColors.accentMid;
    final primaryLight= AppColors.accentLight;
    final primaryDark = AppColors.accentDark;
    final text        = AppColors.text;
    final textSub     = AppColors.textSub;
    final textDim     = AppColors.textHint;
    final green       = AppColors.green;
    final amber       = AppColors.amber;
    final red         = AppColors.red;

    final isComic = ThemeModeManager.isComic3d;
    final radiusCard = AppColors.cardRadius;
    final radiusSmall = isComic ? 4.0 : 8.0;
    final bw = AppColors.borderWidth;

    return ThemeData(
      useMaterial3: true,
      brightness: isComic ? Brightness.light : Brightness.dark,
      fontFamily: _font,
      scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme(
        brightness: isComic ? Brightness.light : Brightness.dark,
        primary: primaryLight, onPrimary: bg, primaryContainer: primaryDark, onPrimaryContainer: text,
        secondary: primaryMid, onSecondary: bg, secondaryContainer: borderLit, onSecondaryContainer: text,
        tertiary: green, onTertiary: bg, error: red, onError: text,
        surface: surface, onSurface: text, outline: border, outlineVariant: borderLit,
        shadow: Colors.black, scrim: Colors.black87, inverseSurface: text, onInverseSurface: bg, inversePrimary: primaryDark,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent, foregroundColor: text, elevation: 0,
        titleTextStyle: TextStyle(fontFamily: _font, fontSize: 18, fontWeight: FontWeight.w600, color: text),
        iconTheme: IconThemeData(color: primaryMid, size: 22), actionsIconTheme: IconThemeData(color: textSub, size: 20),
      ),
      cardTheme: CardThemeData(color: card, elevation: 0, margin: EdgeInsets.zero, clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radiusCard), side: BorderSide(color: border, width: bw))),
      dialogTheme: DialogThemeData(backgroundColor: AppColors.dark, elevation: 0, surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radiusCard + 4), side: BorderSide(color: borderLit, width: bw))),
      snackBarTheme: SnackBarThemeData(backgroundColor: card, contentTextStyle: TextStyle(color: text, fontFamily: _font, fontSize: 13), behavior: SnackBarBehavior.floating),
      textTheme: TextTheme(
        bodyLarge: TextStyle(fontFamily: _font, color: text), bodyMedium: TextStyle(fontFamily: _font, color: text), bodySmall: TextStyle(fontFamily: _font, color: textSub),
      ),
    );
  }
}

Route<dynamic>? _generateRoute(RouteSettings settings) {
  final args = settings.arguments as Map<String, dynamic>?;
  Widget page;

  switch (settings.name) {
    case '/':
      page = const SplashVideoPage(nextPage: LandingPage(), username: 'Guest');
      break;
    case '/login': page = const LoginPage(); break;
    case '/dashboard':
      page = DashboardPage(
        username: args!['username'] as String, password: args['password'] as String, role: args['role'] as String,
        sessionKey: args['key'] as String, expiredDate: args['expiredDate'] as String,
        listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []), listDoos: List<Map<String, dynamic>>.from(args['listDoos'] ?? []), news: List<Map<String, dynamic>>.from(args['news'] ?? []),
      );
      break;
    case '/home':
      page = HomePage(username: args!['username'] as String, password: args['password'] as String, role: args['role'] as String, expiredDate: args['expiredDate'] as String, sessionKey: args['sessionKey'] as String, listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []));
      break;
    case '/seller': page = SellerPage(keyToken: args!['keyToken'] as String); break;
    case '/admin': page = AdminPage(sessionKey: args!['sessionKey'] as String); break;
    case '/owner': page = OwnerPage(sessionKey: args!['sessionKey'] as String, username: args['username'] as String); break;
    default: page = _NotFoundPage(routeName: settings.name ?? 'unknown');
  }

  return PageRouteBuilder<dynamic>(
    settings: settings, transitionDuration: const Duration(milliseconds: 320), reverseTransitionDuration: const Duration(milliseconds: 260),
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, animation, secondaryAnimation, child) {
      return FadeTransition(
        opacity: CurvedAnimation(parent: animation, curve: Curves.easeOutCubic),
        child: SlideTransition(
          position: Tween<Offset>(begin: const Offset(0, 0.035), end: Offset.zero).animate(CurvedAnimation(parent: animation, curve: Curves.easeOutCubic)),
          child: child,
        ),
      );
    },
  );
}

class _NotFoundPage extends StatefulWidget {
  const _NotFoundPage({required this.routeName});
  final String routeName;
  @override State<_NotFoundPage> createState() => _NotFoundPageState();
}
class _NotFoundPageState extends State<_NotFoundPage> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _fade;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))..forward();
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
  }
  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Center(
        child: FadeTransition(
          opacity: _fade,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('404', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 72, fontWeight: FontWeight.w800, color: Colors.white)),
              const SizedBox(height: 10),
              Text('Route not found', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 16, color: AppColors.textSub)),
              const SizedBox(height: 30),
              OutlinedButton.icon(onPressed: () => Navigator.of(context).pushNamedAndRemoveUntil('/login', (_) => false), icon: const Icon(Icons.arrow_back_rounded, size: 16), label: const Text('Back to Login')),
            ],
          ),
        ),
      ),
    );
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ThemeModeManager.load();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
  runApp(const _OrcaApp());
}

class _OrcaApp extends StatelessWidget {
  const _OrcaApp();
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge(<Listenable>[
        ThemeModeManager.current, ThemeModeManager.accentArgb, ThemeModeManager.backgroundArgb, ThemeModeManager.backgroundPath, ThemeModeManager.backgroundType,
      ]),
      builder: (context, _) => MaterialApp(
        debugShowCheckedModeBanner: false, title: 'TramsFlox', theme: _AppTheme.build(), initialRoute: '/', onGenerateRoute: _generateRoute,
        builder: (context, child) {
          final mq = MediaQuery.of(context);
          return MediaQuery(data: mq.copyWith(textScaler: TextScaler.linear(mq.textScaleFactor.clamp(0.85, 1.2))), child: child ?? const SizedBox.shrink());
        },
      ),
    );
  }
}