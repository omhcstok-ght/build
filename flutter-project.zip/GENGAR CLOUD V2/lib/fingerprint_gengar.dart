import 'dart:async';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'theme.dart'; 

const String kFont = 'Pek';

class SplashVideoPage extends StatefulWidget {
  final Widget nextPage;
  final String username;

  const SplashVideoPage({
    super.key,
    required this.nextPage,
    required this.username,
  });

  @override
  State<SplashVideoPage> createState() => _SplashVideoPageState();
}

class _SplashVideoPageState extends State<SplashVideoPage>
    with TickerProviderStateMixin {
  static const Duration _holdDuration = Duration(milliseconds: 1500);
  static const Duration _loadDuration = Duration(milliseconds: 1500);

  Color get bgMain => AppColors.bg;
  Color get accentMain => AppColors.accent;
  Color get textMain => AppColors.text;
  Color get textSubMain => AppColors.textSub;

  bool _showLoading = false;
  bool _navigated = false;
  bool _holding = false;

  late final AnimationController _holdCtrl;
  late final AnimationController _progressCtrl;
  late final AnimationController _radarCtrl; 
  late final AnimationController _pulseCtrl;

  late Timer _clockTimer;
  DateTime _now = DateTime.now();

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });

    _holdCtrl = AnimationController(vsync: this, duration: _holdDuration)
      ..addStatusListener((status) { if (status == AnimationStatus.completed) _goToLoading(); });
    _progressCtrl = AnimationController(vsync: this, duration: _loadDuration)
      ..addStatusListener((status) { if (status == AnimationStatus.completed) _goNext(); });
    _radarCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _clockTimer.cancel(); _holdCtrl.dispose(); _progressCtrl.dispose(); _radarCtrl.dispose(); _pulseCtrl.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  void _onHoldStart() {
    if (_showLoading || _navigated) return;
    setState(() => _holding = true); HapticFeedback.selectionClick(); _holdCtrl.forward(from: 0);
  }

  void _onHoldEnd() {
    if (_showLoading || _navigated) return;
    if (_holdCtrl.status != AnimationStatus.completed) {
      _holdCtrl.stop(); _holdCtrl.value = 0; setState(() => _holding = false);
    }
  }

  void _goToLoading() {
    if (_showLoading || _navigated) return;
    HapticFeedback.heavyImpact();
    setState(() { _showLoading = true; _holding = false; });
    WidgetsBinding.instance.addPostFrameCallback((_) { if (mounted && _showLoading) _progressCtrl.forward(from: 0); });
  }

  void _goNext() {
    if (_navigated) return;
    _navigated = true; HapticFeedback.lightImpact();
    Navigator.of(context).pushReplacement(PageRouteBuilder(
      transitionDuration: const Duration(milliseconds: 400),
      pageBuilder: (_, __, ___) => widget.nextPage,
      transitionsBuilder: (_, animation, __, child) => FadeTransition(opacity: animation, child: child),
    ));
  }

  String get _formattedTime => '${_now.hour.toString().padLeft(2, '0')}:${_now.minute.toString().padLeft(2, '0')}:${_now.second.toString().padLeft(2, '0')}';
  String get _formattedDate {
    const months = ['JANUARI','FEBRUARI','MARET','APRIL','MEI','JUNI','JULI','AGUSTUS','SEPTEMBER','OKTOBER','NOVEMBER','DESEMBER'];
    const days = ['SENIN','SELASA','RABU','KAMIS','JUMAT','SABTU','MINGGU'];
    return '${_now.day.toString().padLeft(2, '0')} ${months[_now.month - 1]} ${_now.year} • ${days[_now.weekday - 1]}';
  }

  @override
  Widget build(BuildContext context) {
    return ThemeRebuilder(
      builder: (context) {
        final isComic = ThemeModeManager.isComic3d;
        return Scaffold(
          backgroundColor: bgMain,
          body: AppBackground(
            imagePath: 'assets/images/mmk.jpg',
            child: Stack(
              fit: StackFit.expand,
              children: [
                if (isComic) Container(color: const Color(0xFFFDF5E6)),
                if (isComic) CustomPaint(painter: _ComicGridPainter(), size: Size.infinite),
                if (!isComic) Container(decoration: BoxDecoration(gradient: RadialGradient(center: const Alignment(0, -0.8), radius: 1.2, colors: [accentMain.withOpacity(0.15), bgMain.withOpacity(0.0)]))),
                AnimatedSwitcher(duration: const Duration(milliseconds: 400), child: _showLoading ? _buildLoadingPhase() : _buildFingerprintPhase()),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildFingerprintPhase() => ThemeModeManager.isComic3d ? _buildComicFingerprintPhase() : _buildNeonFingerprintPhase();

  Widget _buildNeonFingerprintPhase() {
    return SafeArea(
      key: const ValueKey('fp_neon'),
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        // ✅ PADDING BAWAH DIPERBANYAK BIAR GA KEPOTONG
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 60),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              decoration: BoxDecoration(color: Colors.black.withOpacity(0.6), borderRadius: BorderRadius.circular(20), border: Border.all(color: accentMain.withOpacity(0.5), width: 1), boxShadow: [BoxShadow(color: accentMain.withOpacity(0.2), blurRadius: 10, spreadRadius: 1)]),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.security, color: accentMain, size: 14),
                  const SizedBox(width: 6),
                  Text('BIOMETRIC AUTH SYSTEM', style: TextStyle(color: textMain, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Text(_formattedTime, style: TextStyle(color: accentMain, fontSize: 52, fontWeight: FontWeight.w900, letterSpacing: 4, shadows: [Shadow(color: accentMain.withOpacity(0.8), blurRadius: 20)])),
            const SizedBox(height: 4),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.calendar_today, color: textSubMain, size: 10),
                const SizedBox(width: 6),
                Text(_formattedDate, style: TextStyle(color: textSubMain, fontSize: 11, fontWeight: FontWeight.w600)),
              ],
            ),
            const SizedBox(height: 24),
            
            // Card About
            _glassBox(
              colorIndex: 0,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('ABOUT THE NOMERCY', style: TextStyle(color: textMain, fontSize: 13, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 10),
                  Text('The NoMercy adalah platform keamanan biometrik generasi terbaru. Menggabungkan teknologi sidik jari dengan enkripsi AES-256 tingkat militer.', style: TextStyle(color: textMain, fontSize: 12, height: 1.5)),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      _buildNeonStatBox(Icons.bolt, '99.9%', 'ACCURACY'),
                      const SizedBox(width: 8),
                      _buildNeonStatBox(Icons.speed, '<0.3s', 'LATENCY'),
                      const SizedBox(width: 8),
                      _buildNeonStatBox(Icons.security, 'AES-256', 'ENCRYPT'),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            
            // Title
            Text('— BIOMETRIC SCAN —', style: TextStyle(color: textMain, fontSize: 13, fontWeight: FontWeight.bold, letterSpacing: 2)),
            const SizedBox(height: 4),
            Text('Letakkan jari Anda pada sensor', style: TextStyle(color: textSubMain, fontSize: 11)),
            const SizedBox(height: 24),
            
            // Scanner
            _buildNeonScannerArea(),
            
            const SizedBox(height: 40),
            Text('END-TO-END ENCRYPTED', style: TextStyle(color: accentMain, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget _buildComicFingerprintPhase() {
    return SafeArea(
      key: const ValueKey('fp_comic'),
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        // ✅ PADDING BAWAH DIPERBANYAK BIAR GA KEPOTONG
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 60),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              decoration: BoxDecoration(color: const Color(0xFFFF4081), borderRadius: BorderRadius.circular(30), border: Border.all(color: Colors.black, width: 3), boxShadow: const [BoxShadow(color: Colors.black, offset: Offset(4, 4), blurRadius: 0)]),
              child: Text('BIOMETRIC AUTH SYSTEM', style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: 1.5, fontFamily: kFont)),
            ),
            const SizedBox(height: 16),
            Text(_formattedTime, style: TextStyle(color: Colors.black, fontSize: 64, fontWeight: FontWeight.w900, letterSpacing: 2, fontFamily: kFont)),
            const SizedBox(height: 4),
            Text(_formattedDate, style: TextStyle(color: Colors.black, fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 2, fontFamily: kFont)),
            const SizedBox(height: 24),
            
            // Card About
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(color: const Color(0xFFFDF5E6), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.black, width: 3.5), boxShadow: const [BoxShadow(color: Colors.black, offset: Offset(6, 6), blurRadius: 0)]),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('ABOUT GenGar Cloud', style: TextStyle(color: Colors.black, fontSize: 15, fontWeight: FontWeight.w900, fontFamily: kFont)),
                  const SizedBox(height: 10),
                  Text('Sonic Crash adalah platform keamanan biometrik generasi terbaru. Menggabungkan teknologi sidik jari dengan enkripsi AES-256 tingkat militer.', style: TextStyle(color: Colors.black, fontSize: 12, height: 1.5, fontFamily: kFont)),
                ],
              ),
            ),
            const SizedBox(height: 32),
            
            // Scanner
            _buildComicScannerArea(),
            
            const SizedBox(height: 40),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.lock, color: Colors.black, size: 14),
                const SizedBox(width: 6),
                Text('END-TO-END ENCRYPTED', style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: 1, fontFamily: kFont)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ── NEON SCANNER ──
  Widget _buildNeonScannerArea() {
    const double size = 180; 
    
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Labels atas
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _buildTinyLabelNeon('CPU: 12.4%'),
            _buildTinyLabelNeon('SIGNAL: 94.6%'),
            _buildTinyLabelNeon('PACKETS: 1000'),
          ],
        ),
        const SizedBox(height: 20),

        // Area Lingkaran Scan
        GestureDetector(
          onTapDown: (_) => _onHoldStart(), 
          onTapUp: (_) => _onHoldEnd(), 
          onTapCancel: _onHoldEnd,
          child: SizedBox(
            width: size, height: size,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Garis luar tipis
                Container(
                  width: size, height: size,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle, 
                    border: Border.all(color: Colors.white.withOpacity(0.1), width: 1),
                    boxShadow: [BoxShadow(color: accentMain.withOpacity(0.05), blurRadius: 20, spreadRadius: 3)]
                  )
                ),
                
                // ✅ RADAR SWEEP (Animasi Muter)
                if (_holding)
                  AnimatedBuilder(
                    animation: _radarCtrl,
                    builder: (context, child) {
                      return Transform.rotate(
                        angle: _radarCtrl.value * 2 * math.pi,
                        child: Container(
                          width: size, height: size,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: SweepGradient(
                              colors: [
                                accentMain.withOpacity(0.0),
                                accentMain.withOpacity(0.0),
                                accentMain.withOpacity(0.4),
                                accentMain.withOpacity(0.8),
                              ],
                              stops: const [0.0, 0.7, 0.9, 1.0],
                            ),
                          ),
                        ),
                      );
                    },
                  ),

                // Bracket
                Positioned(top: 15, left: 15, child: _buildCornerNeon(top: true, left: true)),
                Positioned(top: 15, right: 15, child: _buildCornerNeon(top: true, right: true)),
                Positioned(bottom: 15, left: 15, child: _buildCornerNeon(bottom: true, left: true)),
                Positioned(bottom: 15, right: 15, child: _buildCornerNeon(bottom: true, right: true)),

                // Icon Sidik Jari
                AnimatedBuilder(
                  animation: _holdCtrl, 
                  builder: (c, _) => Icon(
                    Icons.fingerprint_rounded, 
                    size: 65, 
                    color: _holding ? accentMain : Colors.white.withOpacity(0.2)
                  )
                ),

                // Progress Ring
                SizedBox(
                  width: size, height: size, 
                  child: CircularProgressIndicator(
                    value: _holdCtrl.value, 
                    strokeWidth: 4, 
                    backgroundColor: Colors.transparent, 
                    color: accentMain
                  )
                ),
              ]
            )
          ),
        ),
        const SizedBox(height: 20),

        // Labels bawah
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _buildTinyLabelNeon('HASH: 0x0000'),
            _buildTinyLabelNeon('MODE: ${_holding ? "SCAN" : "IDLE"}'),
          ],
        ),
        const SizedBox(height: 24),

        // Tombol Hold
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.8), 
            borderRadius: BorderRadius.circular(30), 
            border: Border.all(color: _holding ? accentMain : Colors.white.withOpacity(0.3), width: _holding ? 2 : 1)
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min, 
            children: [
              Icon(Icons.touch_app, color: _holding ? accentMain : textMain, size: 16), 
              const SizedBox(width: 8), 
              Text(_holding ? 'SCANNING...' : 'TOUCH & HOLD', style: TextStyle(color: _holding ? accentMain : textMain, fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1))
            ]
          ),
        ),
      ],
    );
  }

  // ── COMIC SCANNER ──
  Widget _buildComicScannerArea() {
    const double size = 180;
    
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Labels atas
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _comicSmallLabel('CPU 12.4%'),
            _comicSmallLabel('SIGNAL 98.6%'),
            _comicSmallLabel('PACKETS 1000'),
          ],
        ),
        const SizedBox(height: 20),

        // Area Lingkaran Scan
        GestureDetector(
          onTapDown: (_) => _onHoldStart(), 
          onTapUp: (_) => _onHoldEnd(), 
          onTapCancel: _onHoldEnd,
          child: SizedBox(
            width: size, height: size, 
            child: Stack(
              alignment: Alignment.center, 
              children: [
                // Pulsing ring belakang
                AnimatedBuilder(
                  animation: _pulseCtrl, 
                  builder: (_, __) => Container(
                    width: size, height: size, 
                    decoration: BoxDecoration(
                      shape: BoxShape.circle, 
                      border: Border.all(color: const Color(0xFFFF4081).withOpacity(0.5), width: 4 + (_pulseCtrl.value * 4))
                    )
                  )
                ),

                // ✅ ANIMASI MUTER (Garis berputar)
                if (_holding)
                  AnimatedBuilder(
                    animation: _radarCtrl,
                    builder: (context, child) {
                      return Transform.rotate(
                        angle: _radarCtrl.value * 2 * math.pi,
                        child: Container(
                          width: size * 0.95, height: size * 0.95,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: const Color(0xFFFF4081).withOpacity(0.8),
                              width: 4,
                              strokeAlign: BorderSide.strokeAlignOutside,
                            ),
                            // Efek putus-putus
                            gradient: SweepGradient(
                              colors: [
                                Colors.transparent,
                                const Color(0xFFFF4081).withOpacity(0.8),
                                Colors.transparent,
                              ],
                              stops: const [0.0, 0.5, 1.0],
                            ),
                          ),
                        ),
                      );
                    },
                  ),

                // Lingkaran putih tengah
                Container(
                  width: size * 0.75, height: size * 0.75, 
                  decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white, border: Border.all(color: Colors.black, width: 6))
                ),
                
                // Icon Sidik Jari
                AnimatedBuilder(
                  animation: _holdCtrl, 
                  builder: (c, _) => Icon(Icons.fingerprint_rounded, size: 65, color: _holding ? const Color(0xFFFF4081) : Colors.black)
                ),

                // Progress Ring
                SizedBox(
                  width: size * 0.75, height: size * 0.75, 
                  child: CircularProgressIndicator(
                    value: _holdCtrl.value, strokeWidth: 6, backgroundColor: Colors.transparent, color: const Color(0xFFFF4081)
                  )
                ),

                // Bracket
                Positioned(top: 10, left: 10, child: _buildComicCorner(top: true, left: true)),
                Positioned(top: 10, right: 10, child: _buildComicCorner(top: true, right: true)),
                Positioned(bottom: 10, left: 10, child: _buildComicCorner(bottom: true, left: true)),
                Positioned(bottom: 10, right: 10, child: _buildComicCorner(bottom: true, right: true)),
              ]
            )
          ),
        ),
        const SizedBox(height: 20),

        // Labels bawah
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _comicSmallLabel('HASH: 0x00'),
            _comicSmallLabel('MODE: ${_holding ? "SCAN" : "IDLE"}'),
          ],
        ),
        const SizedBox(height: 24),

        // Tombol Hold
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          decoration: BoxDecoration(
            color: const Color(0xFFFFEA00), 
            borderRadius: BorderRadius.circular(12), 
            border: Border.all(color: Colors.black, width: 3.5), 
            boxShadow: const [BoxShadow(color: Colors.black, offset: Offset(4, 4), blurRadius: 0)]
          ),
          child: Text('TOUCH & HOLD', style: TextStyle(color: Colors.black, fontSize: 13, fontWeight: FontWeight.w900, fontFamily: kFont)),
        ),
      ],
    );
  }

  Widget _buildLoadingPhase() => ThemeModeManager.isComic3d ? _buildComicLoadingPhase() : _buildNeonLoadingPhase();

  Widget _buildNeonLoadingPhase() {
    return SafeArea(
      key: const ValueKey('load_neon'), 
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32), 
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center, 
          children: [
            _glassBox(
              colorIndex: 2, 
              padding: const EdgeInsets.all(32), 
              child: Column(
                children: [
                  SizedBox(
                    width: 100, height: 100, 
                    child: Stack(
                      alignment: Alignment.center, 
                      children: [
                        CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(accentMain), strokeWidth: 2), 
                        Icon(Icons.fingerprint, color: accentMain, size: 48)
                      ]
                    )
                  ),
                  const SizedBox(height: 24),
                  Text('VERIFYING IDENTITY', style: TextStyle(color: textMain, fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 3)),
                  const SizedBox(height: 24),
                  AnimatedBuilder(
                    animation: _progressCtrl, 
                    builder: (c, _) {
                      final p = _progressCtrl.value.clamp(0.0, 1.0);
                      return Column(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(4), 
                            child: SizedBox(
                              width: 180, height: 4, 
                              child: LinearProgressIndicator(value: p, backgroundColor: Colors.white.withOpacity(0.1), valueColor: AlwaysStoppedAnimation<Color>(accentMain))
                            )
                          ),
                          const SizedBox(height: 12),
                          Text('${(p * 100).round()}%', style: TextStyle(color: accentMain, fontSize: 14, fontWeight: FontWeight.bold)),
                        ]
                      );
                    }
                  ),
                ]
              )
            ),
          ]
        )
      )
    );
  }

  Widget _buildComicLoadingPhase() {
    return SafeArea(
      key: const ValueKey('load_comic'), 
      child: Center(
        child: Container(
          padding: const EdgeInsets.all(32), 
          decoration: BoxDecoration(
            color: const Color(0xFFFDF5E6), borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.black, width: 4), boxShadow: const [BoxShadow(color: Colors.black, offset: Offset(8, 8), blurRadius: 0)]
          ), 
          child: Column(
            mainAxisSize: MainAxisSize.min, 
            children: [
              Container(
                width: 80, height: 80, 
                decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white, border: Border.all(color: Colors.black, width: 4)), 
                child: const Center(child: CircularProgressIndicator(color: Color(0xFFFF4081), strokeWidth: 6))
              ),
              const SizedBox(height: 20),
              Text('VERIFYING IDENTITY', style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.w900, fontFamily: kFont)),
              const SizedBox(height: 20),
              AnimatedBuilder(
                animation: _progressCtrl, 
                builder: (c, _) {
                  final p = _progressCtrl.value.clamp(0.0, 1.0);
                  return Container(
                    width: 180, height: 20, 
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.black, width: 3)), 
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8), 
                      child: LinearProgressIndicator(value: p, backgroundColor: Colors.transparent, valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFFF4081)))
                    )
                  );
                }
              ),
            ]
          )
        )
      )
    );
  }

  Widget _buildTinyLabelNeon(String text) => Text(text, style: TextStyle(color: textSubMain.withOpacity(0.6), fontSize: 8, fontWeight: FontWeight.w600, letterSpacing: 1));

  Widget _buildCornerNeon({bool top = false, bool bottom = false, bool left = false, bool right = false}) {
    return Container(
      width: 14, height: 14, 
      decoration: BoxDecoration(
        border: Border(
          top: top ? BorderSide(color: accentMain, width: 2) : BorderSide.none,
          bottom: bottom ? BorderSide(color: accentMain, width: 2) : BorderSide.none,
          left: left ? BorderSide(color: accentMain, width: 2) : BorderSide.none,
          right: right ? BorderSide(color: accentMain, width: 2) : BorderSide.none,
        )
      )
    );
  }

  Widget _buildNeonStatBox(IconData icon, String value, String label) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4), 
        decoration: BoxDecoration(color: Colors.white.withOpacity(0.05), borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.white.withOpacity(0.15), width: 1)), 
        child: Column(
          children: [
            Icon(icon, color: textMain, size: 14), 
            const SizedBox(height: 4),
            Text(value, style: TextStyle(color: textMain, fontSize: 12, fontWeight: FontWeight.bold)),
            const SizedBox(height: 2),
            Text(label, style: TextStyle(color: textSubMain, fontSize: 8, fontWeight: FontWeight.w600, letterSpacing: 0.5)),
          ]
        )
      )
    );
  }

  Widget _glassBox({required Widget child, EdgeInsetsGeometry? padding, int colorIndex = 0}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16), 
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12), 
        child: Container(
          padding: padding ?? const EdgeInsets.all(16), 
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white.withOpacity(0.15), width: 1), gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [accentMain.withOpacity(0.05), Colors.black.withOpacity(0.2)])
          ), 
          child: child
        )
      )
    );
  }

  Widget _comicSmallLabel(String text) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3), 
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(6), border: Border.all(color: Colors.black, width: 2), boxShadow: const [BoxShadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0)]), 
    child: Text(text, style: TextStyle(color: Colors.black, fontSize: 8, fontWeight: FontWeight.bold, fontFamily: kFont))
  );

  Widget _buildComicCorner({bool top = false, bool bottom = false, bool left = false, bool right = false}) {
    return Container(
      width: 20, height: 20, 
      decoration: BoxDecoration(
        border: Border(
          top: top ? const BorderSide(color: Colors.black, width: 4) : BorderSide.none,
          bottom: bottom ? const BorderSide(color: Colors.black, width: 4) : BorderSide.none,
          left: left ? const BorderSide(color: Colors.black, width: 4) : BorderSide.none,
          right: right ? const BorderSide(color: Colors.black, width: 4) : BorderSide.none,
        )
      )
    );
  }
}

class _ComicGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.black.withOpacity(0.05)..strokeWidth = 1;
    const step = 30.0;
    for (double x = 0; x < size.width; x += step) canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    for (double y = 0; y < size.height; y += step) canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}