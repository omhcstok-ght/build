// theme.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

enum AppThemeMode { neonGlass, comic3d }

class AppThemeModeInfo {
  final AppThemeMode mode;
  final String name;
  final String subtitle;
  final IconData icon;

  const AppThemeModeInfo({
    required this.mode,
    required this.name,
    required this.subtitle,
    required this.icon,
  });
}

const List<AppThemeModeInfo> kThemeModes = [
  AppThemeModeInfo(
    mode: AppThemeMode.neonGlass,
    name: 'Neon Glass',
    subtitle: 'Tema bawaan base (Premium Glass)',
    icon: Icons.blur_on_rounded,
  ),
  AppThemeModeInfo(
    mode: AppThemeMode.comic3d,
    name: '3D Comic',
    subtitle: 'Border tebal & warna pop-art',
    icon: Icons.auto_stories_rounded,
  ),
];

class ThemeModeManager {
  static const _prefsKey = 'app_theme_mode';
  static const _accentKey = 'custom_accent_color';
  static const _bgColorKey = 'custom_background_color';
  static const _bgPathKey = 'custom_background_path';
  static const _bgTypeKey = 'custom_background_type';
  static const _bgSoundKey = 'background_video_sound';
  static const defaultVideoAsset = 'assets/videos/custom_background.mp4';
  
  static final ValueNotifier<bool> backgroundSoundEnabled = ValueNotifier<bool>(false);
  static final ValueNotifier<VideoPlayerController?> backgroundVideo = ValueNotifier<VideoPlayerController?>(null);
  static VideoPlayerController? _videoController;
  static String? _videoIdentity;
  static int _videoGeneration = 0;

  static Future<void> _syncGlobalVideo({bool useDefaultWhenUnset = true}) async {
    final type = backgroundType.value;
    final path = backgroundPath.value;
    final identity = type == 'video' && path != null ? 'file:$path'
        : (type == 'none' && useDefaultWhenUnset ? 'asset:$defaultVideoAsset' : null);
    if (identity == _videoIdentity && _videoController != null) return;
    _videoIdentity = identity;
    final generation = ++_videoGeneration;
    final old = _videoController;
    _videoController = null;
    backgroundVideo.value = null;
    if (old != null) await old.dispose();
    if (identity == null) return;
    final controller = identity.startsWith('file:')
        ? VideoPlayerController.file(File(identity.substring(5)))
        : VideoPlayerController.asset(defaultVideoAsset);
    _videoController = controller;
    try {
      await controller.initialize();
      if (generation != _videoGeneration || _videoController != controller) {
        await controller.dispose();
        return;
      }
      await controller.setLooping(true);
      await controller.setVolume(backgroundSoundEnabled.value ? 1.0 : 0.0);
      await controller.play();
      backgroundVideo.value = controller;
    } catch (_) {
      if (_videoController == controller) { _videoController = null; backgroundVideo.value = null; }
      await controller.dispose();
    }
  }

  static Future<void> resumeBackgroundVideo() async {
    final controller = _videoController;
    if (controller != null && controller.value.isInitialized) {
      if (!controller.value.isPlaying) {
        try { await controller.play(); } catch (_) {}
      }
      return;
    }
    await _syncGlobalVideo();
  }

  static Future<void> setBackgroundSound(bool enabled) async {
    backgroundSoundEnabled.value = enabled;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_bgSoundKey, enabled);
    final controller = _videoController;
    if (controller != null && controller.value.isInitialized) {
      await controller.setVolume(enabled ? 1.0 : 0.0);
    }
  }

  static final ValueNotifier<int?> accentArgb = ValueNotifier<int?>(null);
  static final ValueNotifier<int?> backgroundArgb = ValueNotifier<int?>(null);
  static final ValueNotifier<String?> backgroundPath = ValueNotifier<String?>(null);
  static final ValueNotifier<String> backgroundType = ValueNotifier<String>('none');

  static final ValueNotifier<AppThemeMode> current = ValueNotifier<AppThemeMode>(AppThemeMode.neonGlass);

  static AppThemeMode get mode => current.value;

  static Future<void> setMode(AppThemeMode m) async {
    current.value = m;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefsKey, m.name);
  }

  static Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    accentArgb.value = prefs.getInt(_accentKey);
    backgroundArgb.value = prefs.getInt(_bgColorKey);
    backgroundPath.value = prefs.getString(_bgPathKey);
    backgroundType.value = prefs.getString(_bgTypeKey) ?? 'none';
    backgroundSoundEnabled.value = prefs.getBool(_bgSoundKey) ?? false;
    await _syncGlobalVideo();
    final saved = prefs.getString(_prefsKey);
    if (saved != null) {
      final found = AppThemeMode.values.firstWhere(
        (e) => e.name == saved,
        orElse: () => AppThemeMode.neonGlass,
      );
      current.value = found;
    }
  }

  static Future<void> setAccentColor(Color color) async {
    accentArgb.value = color.value;
    final p = await SharedPreferences.getInstance();
    await p.setInt(_accentKey, color.value);
  }

  static Future<void> resetAccentColor() async {
    accentArgb.value = null;
    final p = await SharedPreferences.getInstance();
    await p.remove(_accentKey);
  }
  
  static Future<void> setBackgroundColor(Color color) async {
    backgroundArgb.value = color.value;
    backgroundPath.value = null;
    backgroundType.value = 'color';
    await _syncGlobalVideo();
    final p = await SharedPreferences.getInstance();
    await p.setInt(_bgColorKey, color.value);
    await p.remove(_bgPathKey);
    await p.setString(_bgTypeKey, 'color');
  }

  static Future<void> setBackgroundFile(String path, String type) async {
    backgroundPath.value = path;
    backgroundType.value = type;
    await _syncGlobalVideo();
    final p = await SharedPreferences.getInstance();
    await p.setString(_bgPathKey, path);
    await p.setString(_bgTypeKey, type);
    await p.remove(_bgColorKey);
    backgroundArgb.value = null;
  }

  static Future<void> resetAppearanceBackground() async {
    backgroundPath.value = null;
    backgroundArgb.value = null;
    backgroundType.value = 'none';
    await _syncGlobalVideo();
    final p = await SharedPreferences.getInstance();
    await p.remove(_bgPathKey); 
    await p.remove(_bgColorKey); 
    await p.remove(_bgTypeKey);
  }

  static bool get isNeonGlass => mode == AppThemeMode.neonGlass;
  static bool get isComic3d   => mode == AppThemeMode.comic3d;
  static bool get isNormal    => mode == AppThemeMode.neonGlass;
}

class AppColors {
  static const List<Color> comicPalette = [
    Color(0xFF00E5FF), Color(0xFFFF4081), Color(0xFFFFEA00), Color(0xFF76FF03), Color(0xFFD500F9), Color(0xFFFF6D00),
  ];

  static Color getComicColor(int index) => comicPalette[index % comicPalette.length];

  static Color get bg {
    if (ThemeModeManager.isComic3d) return const Color(0xFFFDF5E6); 
    return const Color(0xFF080A10); 
  }

  static Color get card {
    if (ThemeModeManager.isComic3d) return const Color(0xFF00E5FF); 
    return Colors.white.withOpacity(0.05); 
  }

  static Color get card2 {
    if (ThemeModeManager.isComic3d) return const Color(0xFFFF4081);
    return Colors.white.withOpacity(0.02); 
  }

  static Color get border {
    if (ThemeModeManager.isComic3d) return const Color(0xFF000000); 
    return Colors.white.withOpacity(0.1); 
  }

  static Color get borderLit {
    if (ThemeModeManager.isComic3d) return const Color(0xFF000000);
    return Colors.white.withOpacity(0.25);
  }

  static Color get text {
    if (ThemeModeManager.isComic3d) return const Color(0xFF000000); 
    return Colors.white;
  }

  static Color get textSub {
    if (ThemeModeManager.isComic3d) return const Color(0xFF222222);
    return Colors.white.withOpacity(0.65);
  }

  static Color get textHint {
    if (ThemeModeManager.isComic3d) return const Color(0xFF555555);
    return Colors.white.withOpacity(0.4);
  }

  static Color get accent {
    final custom = ThemeModeManager.accentArgb.value;
    if (custom != null) return Color(custom);
    if (ThemeModeManager.isComic3d) return const Color(0xFFFFEA00);
    return const Color(0xFF9D5CFF); 
  }

  static Color get accentMid {
    if (ThemeModeManager.accentArgb.value != null) {
      return HSLColor.fromColor(Color(ThemeModeManager.accentArgb.value!)).withLightness((HSLColor.fromColor(Color(ThemeModeManager.accentArgb.value!)).lightness * 0.82).clamp(0.0, 1.0).toDouble()).toColor();
    }
    if (ThemeModeManager.isComic3d) return const Color(0xFF76FF03);
    return const Color(0xFFB388FF);
  }

  static Color get accentLight {
    if (ThemeModeManager.accentArgb.value != null) {
      final hsl = HSLColor.fromColor(Color(ThemeModeManager.accentArgb.value!));
      return hsl.withLightness((hsl.lightness + (1.0 - hsl.lightness) * 0.28).clamp(0.0, 1.0).toDouble()).toColor();
    }
    if (ThemeModeManager.isComic3d) return const Color(0xFF00E5FF);
    return const Color(0xFFD0BFFF);
  }

  static Color get accentDark {
    if (ThemeModeManager.accentArgb.value != null) {
      final hsl = HSLColor.fromColor(Color(ThemeModeManager.accentArgb.value!));
      return hsl.withLightness((hsl.lightness * 0.62).clamp(0.0, 1.0).toDouble()).toColor();
    }
    if (ThemeModeManager.isComic3d) return const Color(0xFFD500F9);
    return const Color(0xFF6C3BFF);
  }

  static Color get dark {
    if (ThemeModeManager.isComic3d) return const Color(0xFFFFFFFF);
    return Colors.black.withOpacity(0.5); 
  }

  static Color get green => ThemeModeManager.isComic3d ? const Color(0xFF76FF03) : const Color(0xFF00E676);
  static Color get amber => const Color(0xFFFFB300);
  static Color get red   => ThemeModeManager.isComic3d ? const Color(0xFFFF1744) : const Color(0xFFFF4D67);
  static Color get gold  => const Color(0xFFFFD700);
  static Color get pink  => const Color(0xFFFF4081);
  static Color get purple=> const Color(0xFFD500F9);
  static Color get teal  => const Color(0xFF00E5FF);

  static LinearGradient get btnGrad {
    if (ThemeModeManager.accentArgb.value != null) {
      return LinearGradient(colors: [accentLight, accentDark], begin: Alignment.topLeft, end: Alignment.bottomRight);
    }
    if (ThemeModeManager.isComic3d) {
      return const LinearGradient(colors: [Color(0xFFFFEA00), Color(0xFFFF6D00)], begin: Alignment.topLeft, end: Alignment.bottomRight);
    }
    return LinearGradient(
      colors: [const Color(0xFF9D5CFF).withOpacity(0.8), const Color(0xFF6C3BFF).withOpacity(0.8)],
      begin: Alignment.topLeft, end: Alignment.bottomRight,
    );
  }

  static LinearGradient get glassGrad {
    if (ThemeModeManager.isComic3d) {
      return const LinearGradient(colors: [Color(0xFFFFFFFF), Color(0xFFFFFFFF)], begin: Alignment.topLeft, end: Alignment.bottomRight);
    }
    return LinearGradient(
      colors: [Colors.white.withOpacity(0.08), Colors.white.withOpacity(0.01)],
      begin: Alignment.topLeft, end: Alignment.bottomRight,
    );
  }

  static Color get glassBorder {
    if (ThemeModeManager.isComic3d) return const Color(0xFF000000);
    return Colors.white.withOpacity(0.15);
  }

  static List<BoxShadow> get glassShadow {
    if (ThemeModeManager.isComic3d) {
      return const [BoxShadow(color: Color(0xFF000000), offset: Offset(4, 4), blurRadius: 0)];
    }
    return [
      BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 30, offset: const Offset(0, 10)),
      BoxShadow(color: Colors.white.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, -2)),
    ];
  }

  static List<BoxShadow> get softShadow {
    if (ThemeModeManager.isComic3d) {
      return const [BoxShadow(color: Color(0xFF000000), offset: Offset(2, 2), blurRadius: 0)];
    }
    return [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 15, offset: const Offset(0, 4))];
  }

  static double get cardRadius {
    if (ThemeModeManager.isComic3d) return 16;
    return 20;
  }

  static double get sheetRadius {
    if (ThemeModeManager.isComic3d) return 16;
    return 28;
  }

  static double get borderWidth {
    if (ThemeModeManager.isComic3d) return 3.5;
    return 1.0;
  }
}

class AppBackground extends StatefulWidget {
  final AnimationController? controller;
  final String? imagePath;
  final Widget child;
  const AppBackground({super.key, this.controller, this.imagePath, required this.child});
  @override
  State<AppBackground> createState() => _AppBackgroundState();
}

class _AppBackgroundState extends State<AppBackground> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    ThemeModeManager.resumeBackgroundVideo();
    ThemeModeManager.backgroundVideo.addListener(_refreshBackground);
    ThemeModeManager.backgroundPath.addListener(_refreshBackground);
    ThemeModeManager.backgroundType.addListener(_refreshBackground);
    ThemeModeManager.backgroundArgb.addListener(_refreshBackground);
  }

  void _refreshBackground() { if (mounted) setState(() {}); }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      ThemeModeManager.resumeBackgroundVideo();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    ThemeModeManager.backgroundVideo.removeListener(_refreshBackground);
    ThemeModeManager.backgroundPath.removeListener(_refreshBackground);
    ThemeModeManager.backgroundType.removeListener(_refreshBackground);
    ThemeModeManager.backgroundArgb.removeListener(_refreshBackground);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Stack(children: [
    Positioned.fill(child: _buildBaseBg()),
    Positioned.fill(child: Container(decoration: BoxDecoration(gradient: LinearGradient(
      begin: Alignment.topCenter, end: Alignment.bottomCenter,
      colors: ThemeModeManager.isComic3d
          ? [Colors.transparent, Colors.transparent] 
          : [Colors.black.withOpacity(0.3), Colors.black.withOpacity(0.7)], 
    )))),
    Positioned.fill(child: widget.child),
  ]);

  Widget _buildBaseBg() {
    if (ThemeModeManager.isComic3d) return ColoredBox(color: AppColors.bg);
    
    final picked = ThemeModeManager.backgroundPath.value;
    final type = ThemeModeManager.backgroundType.value;
    if (type == 'video' || type == 'none') {
      final controller = ThemeModeManager.backgroundVideo.value;
      if (controller != null && controller.value.isInitialized) {
        return SizedBox.expand(child: FittedBox(fit: BoxFit.cover,
          child: SizedBox(width: controller.value.size.width, height: controller.value.size.height,
            child: VideoPlayer(controller))));
      }
      return ColoredBox(color: AppColors.bg);
    }
    if (type == 'image' && picked != null) {
      return Image.file(File(picked), fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => ColoredBox(color: AppColors.bg));
    }
    if (ThemeModeManager.backgroundArgb.value != null) {
      return ColoredBox(color: Color(ThemeModeManager.backgroundArgb.value!));
    }
    if (widget.imagePath != null) {
      return Image.asset(widget.imagePath!, fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => ColoredBox(color: AppColors.bg));
    }
    return ColoredBox(color: AppColors.bg);
  }
}

// ═════════════════════════════════════════════════════════════════════
//  THEME REBUILDER (Auto refresh halaman saat warna diganti)
// ═════════════════════════════════════════════════════════════════════
class ThemeRebuilder extends StatefulWidget {
  final Widget Function(BuildContext) builder;
  const ThemeRebuilder({super.key, required this.builder});

  @override
  State<ThemeRebuilder> createState() => _ThemeRebuilderState();
}

class _ThemeRebuilderState extends State<ThemeRebuilder> {
  @override
  void initState() {
    super.initState();
    ThemeModeManager.current.addListener(_refresh);
    ThemeModeManager.accentArgb.addListener(_refresh);
    ThemeModeManager.backgroundArgb.addListener(_refresh);
    ThemeModeManager.backgroundPath.addListener(_refresh);
    ThemeModeManager.backgroundType.addListener(_refresh);
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    ThemeModeManager.current.removeListener(_refresh);
    ThemeModeManager.accentArgb.removeListener(_refresh);
    ThemeModeManager.backgroundArgb.removeListener(_refresh);
    ThemeModeManager.backgroundPath.removeListener(_refresh);
    ThemeModeManager.backgroundType.removeListener(_refresh);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.builder(context);
}