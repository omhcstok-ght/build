// appearance_settings_page.dart
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:ui';
import 'theme.dart';

const String _appearanceFont = 'ShareTechMono'; 

class AppearanceSettingsPage extends StatefulWidget {
  const AppearanceSettingsPage({super.key});

  @override
  State<AppearanceSettingsPage> createState() => _AppearanceSettingsPageState();
}

class _AppearanceSettingsPageState extends State<AppearanceSettingsPage> {
  static const List<Color> _palette = [
    Color(0xFFFF1744), Color(0xFFFF5252), Color(0xFFFF9800), Color(0xFFFFC107),
    Color(0xFFFFFF00), Color(0xFF8BC34A), Color(0xFF00C853), Color(0xFF1DE9B6),
    Color(0xFF00BCD4), Color(0xFF03A9F4), Color(0xFF2962FF), Color(0xFF3F51B5),
    Color(0xFF673AB7), Color(0xFF9C27B0), Color(0xFFE91E63), Color(0xFFFF80AB),
    Color(0xFF795548), Color(0xFF9E9E9E), Color(0xFFEEEEEE), Color(0xFF607D8B),
    Color(0xFF000000), Color(0xFFFFFFFF), Color(0xFF64FFDA), Color(0xFFB2FF59),
    Color(0xFFFF6E40), Color(0xFF7C4DFF), Color(0xFF536DFE), Color(0xFF00E5FF),
  ];

  final ImagePicker _picker = ImagePicker();

  TextStyle _text(double size, {Color? color, FontWeight weight = FontWeight.w500, double spacing = 0}) =>
      TextStyle(fontFamily: _appearanceFont, fontSize: size, color: color ?? AppColors.text, fontWeight: weight, letterSpacing: spacing);

  Future<void> _pickBackground(bool video) async {
    try {
      final XFile? file = video ? await _picker.pickVideo(source: ImageSource.gallery) : await _picker.pickImage(source: ImageSource.gallery, imageQuality: 95);
      if (file == null) return;
      await ThemeModeManager.setBackgroundFile(file.path, video ? 'video' : 'image');
      if (mounted) { setState(() {}); }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Galeri error: $e', style: _text(12)), backgroundColor: Colors.red));
    }
  }

  Future<Color?> _customColor(Color initial) async {
    double hue = HSVColor.fromColor(initial).hue, sat = HSVColor.fromColor(initial).saturation, val = HSVColor.fromColor(initial).value;
    return showDialog<Color>(context: context, builder: (ctx) => StatefulBuilder(
      builder: (ctx, setDialog) {
        final color = HSVColor.fromAHSV(1, hue, sat, val).toColor();
        return AlertDialog(
          backgroundColor: AppColors.bg, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24), side: BorderSide(color: AppColors.borderLit)),
          title: Text('WARNA KUSTOM', style: _text(16, weight: FontWeight.w800)),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(height: 58, decoration: BoxDecoration(gradient: LinearGradient(colors: [color.withOpacity(.65), color]), borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white.withOpacity(.16)))),
            const SizedBox(height: 16),
            _slider('Hue', hue, 0, 360, (v) => setDialog(() => hue = v)),
            _slider('Sat', sat, 0, 1, (v) => setDialog(() => sat = v)),
            _slider('Val', val, 0, 1, (v) => setDialog(() => val = v)),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: Text('BATAL', style: _text(11, color: AppColors.textSub))),
            FilledButton(onPressed: () => Navigator.pop(ctx, color), style: FilledButton.styleFrom(backgroundColor: color),
              child: Text('PAKAI', style: _text(11, color: color.computeLuminance() > .5 ? Colors.black : Colors.white, weight: FontWeight.w800))),
          ],
        );
      },
    ));
  }

  Widget _slider(String label, double value, double min, double max, ValueChanged<double> change) => Column(
    crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Text(label, style: _text(11, color: AppColors.textSub)), const Spacer(), Text(value.toStringAsFixed(label == 'Hue' ? 0 : 2), style: _text(10, color: AppColors.accent, weight: FontWeight.w700))]),
      Slider(value: value, min: min, max: max, activeColor: AppColors.accent, onChanged: change),
    ],
  );

  Widget _panel({required Widget child, EdgeInsets padding = const EdgeInsets.all(16)}) {
    return ClipRRect(borderRadius: BorderRadius.circular(AppColors.cardRadius), child: BackdropFilter(filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10), child: Container(padding: padding, decoration: BoxDecoration(color: ThemeModeManager.isComic3d ? AppColors.card : Colors.white.withOpacity(0.05), borderRadius: BorderRadius.circular(AppColors.cardRadius), border: Border.all(color: AppColors.border, width: AppColors.borderWidth), boxShadow: AppColors.glassShadow, gradient: ThemeModeManager.isComic3d ? null : AppColors.glassGrad), child: child)));
  }

  Widget _sectionHeading(String eyebrow, String title, String subtitle, IconData icon) => Padding(
    padding: const EdgeInsets.only(bottom: 12), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(width: 42, height: 42, decoration: BoxDecoration(borderRadius: BorderRadius.circular(13), gradient: LinearGradient(colors: [AppColors.accent.withOpacity(.3), AppColors.accent.withOpacity(.05)]), border: Border.all(color: AppColors.accent.withOpacity(.4))), child: Icon(icon, color: AppColors.accent, size: 21)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(eyebrow, style: _text(10, color: AppColors.accent, weight: FontWeight.w800, spacing: 1.5)),
        const SizedBox(height: 3), Text(title, style: _text(15, weight: FontWeight.w800)),
        const SizedBox(height: 4), Text(subtitle, style: _text(10, color: AppColors.textSub)),
      ])),
    ]),
  );

  Widget _colorGrid({required bool background, required VoidCallback changed}) {
    final selected = background ? ThemeModeManager.backgroundArgb.value : ThemeModeManager.accentArgb.value;
    return Wrap(spacing: 10, runSpacing: 12, children: [
      for (final color in _palette)
        InkWell(onTap: () async {
          if (background) await ThemeModeManager.setBackgroundColor(color);
          else await ThemeModeManager.setAccentColor(color);
          if (mounted) setState(() {});
        }, borderRadius: BorderRadius.circular(18), child: AnimatedContainer(duration: const Duration(milliseconds: 160), width: 36, height: 36, decoration: BoxDecoration(color: color, shape: BoxShape.circle, border: Border.all(color: selected == color.value ? Colors.white : AppColors.borderLit, width: selected == color.value ? 2.6 : 1), boxShadow: selected == color.value ? [BoxShadow(color: color.withOpacity(.5), blurRadius: 12, spreadRadius: 1)] : null), child: selected == color.value ? Icon(Icons.check_rounded, size: 18, color: color.computeLuminance() > .55 ? Colors.black : Colors.white) : null)),
      InkWell(onTap: () async {
        final c = await _customColor(selected == null ? AppColors.accent : Color(selected));
        if (c == null) return;
        if (background) await ThemeModeManager.setBackgroundColor(c); else await ThemeModeManager.setAccentColor(c);
        if (mounted) setState(() {});
      }, borderRadius: BorderRadius.circular(18), child: Container(width: 36, height: 36, decoration: BoxDecoration(shape: BoxShape.circle, gradient: const SweepGradient(colors: [Colors.red, Colors.orange, Colors.yellow, Colors.green, Colors.cyan, Colors.blue, Colors.purple, Colors.red]), border: Border.all(color: AppColors.borderLit, width: 1.5)), child: const Icon(Icons.add_rounded, size: 20, color: Colors.white))),
    ]);
  }

  Widget _themeChoices() => Column(children: [
    for (final info in kThemeModes) ...[
      InkWell(onTap: () async { await ThemeModeManager.setMode(info.mode); if (mounted) setState(() {}); }, borderRadius: BorderRadius.circular(15), child: AnimatedContainer(duration: const Duration(milliseconds: 180), margin: const EdgeInsets.only(bottom: 9), padding: const EdgeInsets.all(14), decoration: BoxDecoration(borderRadius: BorderRadius.circular(15), color: ThemeModeManager.current.value == info.mode ? AppColors.accent.withOpacity(.15) : AppColors.card2, border: Border.all(color: ThemeModeManager.current.value == info.mode ? AppColors.accent : AppColors.border, width: ThemeModeManager.current.value == info.mode ? 2 : 1), boxShadow: ThemeModeManager.current.value == info.mode ? [BoxShadow(color: AppColors.accent.withOpacity(.2), blurRadius: 16, offset: const Offset(0, 5))] : null),
        child: Row(children: [
          Container(width: 40, height: 40, decoration: BoxDecoration(color: ThemeModeManager.current.value == info.mode ? AppColors.accent.withOpacity(.2) : AppColors.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: ThemeModeManager.current.value == info.mode ? AppColors.accent.withOpacity(.5) : AppColors.border)), child: Icon(info.icon, color: ThemeModeManager.current.value == info.mode ? AppColors.accent : AppColors.textSub, size: 20)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(info.name.toUpperCase(), style: _text(13, weight: FontWeight.w800)), const SizedBox(height: 3), Text(info.subtitle, style: _text(10, color: AppColors.textSub))])),
          Icon(ThemeModeManager.current.value == info.mode ? Icons.check_circle_rounded : Icons.circle_outlined, color: ThemeModeManager.current.value == info.mode ? AppColors.accent : AppColors.textSub, size: 22),
        ]),
      )),
    ],
  ]);

  @override
  Widget build(BuildContext context) {
    return ThemeRebuilder(
      builder: (context) => Scaffold(
        backgroundColor: AppColors.bg,
        body: AppBackground(
          imagePath: 'assets/images/mmk.jpg',
          child: SafeArea(
            child: Column(children: [
              AppBar(backgroundColor: Colors.transparent, elevation: 0, title: Text('PERSONALISASI', style: _text(16, weight: FontWeight.w900, spacing: 1.5)), iconTheme: IconThemeData(color: AppColors.text), centerTitle: true),
              Expanded(child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 28), children: [
                _panel(child: Row(children: [
                  Container(width: 48, height: 48, decoration: BoxDecoration(borderRadius: BorderRadius.circular(15), gradient: AppColors.btnGrad, boxShadow: [BoxShadow(color: AppColors.accent.withOpacity(.3), blurRadius: 15)]), child: const Icon(Icons.tune_rounded, color: Colors.white, size: 24)),
                  const SizedBox(width: 14),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('PREMIUM UI', style: _text(16, weight: FontWeight.w900, spacing: 1)), const SizedBox(height: 4), Text('Atur tampilan sesuai gaya kamu', style: _text(11, color: AppColors.textSub))])),
                ])),
                const SizedBox(height: 16),
                _panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  _sectionHeading('01 / STYLE PRESET', 'Pilih tema', 'Pilih gaya tampilan dengan pilihan aktif yang jelas.', Icons.palette_outlined),
                  _themeChoices(),
                ])),
                const SizedBox(height: 16),
                _panel(child: ValueListenableBuilder<bool>(
                  valueListenable: ThemeModeManager.backgroundSoundEnabled,
                  builder: (context, enabled, _) => Row(children: [
                    Container(width: 42, height: 42, decoration: BoxDecoration(color: AppColors.accent.withOpacity(.12), borderRadius: BorderRadius.circular(13)), child: Icon(enabled ? Icons.volume_up_rounded : Icons.volume_off_rounded, color: AppColors.accent)),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('SUARA BACKGROUND', style: _text(11, weight: FontWeight.w800)),
                      const SizedBox(height: 3),
                      Text(enabled ? 'Suara aktif' : 'Suara dimatikan', style: _text(9, color: AppColors.textSub)),
                    ])),
                    Switch.adaptive(value: enabled, activeColor: AppColors.accent, onChanged: (value) async { await ThemeModeManager.setBackgroundSound(value); }),
                  ]),
                )),
                const SizedBox(height: 16),
                _panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  _sectionHeading('02 / ACCENT CONTROL', 'Ubah warna aksen', 'Warna aksen mengubah elemen utama aplikasi.', Icons.color_lens_outlined),
                  _colorGrid(background: false, changed: () {}),
                  const SizedBox(height: 16),
                  SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: () async { await ThemeModeManager.resetAccentColor(); if (mounted) setState(() {}); }, style: OutlinedButton.styleFrom(foregroundColor: AppColors.text, side: BorderSide(color: AppColors.borderLit), padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13))), icon: const Icon(Icons.restart_alt_rounded, size: 18), label: Text('RESET WARNA', style: _text(11, weight: FontWeight.w800, color: AppColors.text)))),
                ])),
                const SizedBox(height: 16),
                _panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  _sectionHeading('03 / WALLPAPER', 'Ganti background', 'Gunakan gambar atau video dari galeri.', Icons.wallpaper_rounded),
                  Row(children: [
                    Expanded(child: _mediaButton(icon: Icons.image_outlined, label: 'PILIH FOTO', onTap: () => _pickBackground(false))),
                    const SizedBox(width: 10),
                    Expanded(child: _mediaButton(icon: Icons.movie_outlined, label: 'PILIH VIDEO', onTap: () => _pickBackground(true))),
                  ]),
                ])),
                const SizedBox(height: 16),
                _panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  _sectionHeading('04 / BACKDROP TONE', 'Warna background', 'Atur warna latar polos tanpa media.', Icons.format_paint_outlined),
                  _colorGrid(background: true, changed: () {}),
                  const SizedBox(height: 16),
                  SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: () async { await ThemeModeManager.resetAppearanceBackground(); if (mounted) setState(() {}); }, style: OutlinedButton.styleFrom(foregroundColor: AppColors.text, side: BorderSide(color: AppColors.borderLit), padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13))), icon: const Icon(Icons.restart_alt_rounded, size: 18), label: Text('RESET BACKGROUND', style: _text(11, weight: FontWeight.w800, color: AppColors.text)))),
                ])),
              ])),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _mediaButton({required IconData icon, required String label, required VoidCallback onTap}) =>
      InkWell(onTap: onTap, borderRadius: BorderRadius.circular(14), child: Container(padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 10), decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [AppColors.accent.withOpacity(.15), AppColors.card]), borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.accent.withOpacity(.3))), child: Column(children: [Icon(icon, color: AppColors.accent, size: 24), const SizedBox(height: 8), Text(label, textAlign: TextAlign.center, style: _text(10, weight: FontWeight.w800, spacing: .5))])));
}