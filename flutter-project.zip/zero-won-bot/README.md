# ZERO WON WhatsApp Bot

Starter bot Node.js untuk **WhatsApp Business Cloud API resmi**. Termasuk auto-reply sederhana, command `/menu`, `/ping`, `/help`, `/about`, webhook, deduplikasi pesan, log aktivitas, dan dashboard bertema ZERO WON dengan gambar yang disediakan.

## Kebutuhan
- Node.js 20+
- Akun Meta Developer dan aplikasi dengan produk WhatsApp
- WhatsApp Business Account, nomor telepon Cloud API, access token, dan webhook publik HTTPS

## Menjalankan lokal
1. Salin `.env.example` menjadi `.env`.
2. Isi `WHATSAPP_TOKEN`, `PHONE_NUMBER_ID`, `VERIFY_TOKEN`, `APP_SECRET`, dan `GRAPH_API_VERSION` dengan nilai dari konfigurasi Meta. Gunakan versi Graph API yang masih didukung Meta; jangan biarkan `vXX.X`.
3. Jalankan:
   ```bash
   npm install
   npm start
   ```
4. Buka `http://localhost:3000` untuk dashboard. Endpoint pemeriksaan: `/health`.
5. Untuk menerima webhook dari Meta, expose server melalui HTTPS dan set callback URL ke `https://DOMAIN/webhook`, dengan verify token yang sama seperti `VERIFY_TOKEN`.
6. Subscribe aplikasi ke webhook field `messages` pada konfigurasi WhatsApp.

## Catatan fitur
- Bot hanya membalas pesan masuk berbentuk teks dan tombol sederhana.
- `replyFor()` adalah tempat mengembangkan command dan integrasi AI.
- Moderasi grup, pengelolaan anggota grup, serta fitur broadcast massal tidak disediakan oleh starter ini. Kemampuan Cloud API bergantung pada fitur resmi yang tersedia untuk akun dan versi API Meta.
- Untuk percakapan bisnis yang dimulai oleh bisnis, ikuti aturan template dan jendela layanan WhatsApp yang berlaku.

## Keamanan sebelum produksi
- Simpan `.env` di server; jangan commit atau membagikan token.
- Aktifkan `APP_SECRET` agar signature webhook diverifikasi.
- Gunakan HTTPS, secret yang kuat, pembatasan akses dashboard/log, dan penyimpanan log yang sesuai.
- Tambahkan antrean/retry dan penyimpanan deduplikasi persisten sebelum trafik produksi.
