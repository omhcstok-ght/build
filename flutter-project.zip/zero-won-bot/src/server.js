require('dotenv').config();
const express = require('express');
const crypto = require('crypto');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const GRAPH_VERSION = process.env.GRAPH_API_VERSION || 'vXX.X';
const logs = [];
const seenMessageIds = new Set();

app.use(express.json({
  verify: (req, res, buf) => { req.rawBody = buf; }
}));
app.use(express.static(path.join(__dirname, '..', 'public')));

function addLog(type, message) {
  logs.unshift({ time: new Date().toISOString(), type, message });
  if (logs.length > 60) logs.pop();
}
function maskPhone(value = '') {
  return value.length > 4 ? `${value.slice(0, 2)}••••${value.slice(-2)}` : 'unknown';
}
function validSignature(req) {
  if (!process.env.APP_SECRET) return true; // Optional during local setup; configure before production.
  const signature = req.get('x-hub-signature-256') || '';
  const expected = 'sha256=' + crypto.createHmac('sha256', process.env.APP_SECRET)
    .update(req.rawBody || Buffer.from('')).digest('hex');
  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

async function sendText(to, body) {
  const token = process.env.WHATSAPP_TOKEN;
  const phoneNumberId = process.env.PHONE_NUMBER_ID;
  if (!token || !phoneNumberId || GRAPH_VERSION === 'vXX.X') {
    addLog('setup', 'Message not sent: configure WhatsApp credentials and Graph API version.');
    return;
  }
  const response = await fetch(`https://graph.facebook.com/${GRAPH_VERSION}/${phoneNumberId}/messages`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      messaging_product: 'whatsapp', recipient_type: 'individual', to,
      type: 'text', text: { preview_url: false, body }
    })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error?.message || `WhatsApp API returned ${response.status}`);
  addLog('sent', `Reply sent to ${maskPhone(to)}.`);
}

function replyFor(message) {
  const text = (message || '').trim();
  const command = text.toLowerCase();
  if (['/menu', 'menu', 'hai', 'halo', 'hi'].includes(command)) {
    return '✦ ZERO WON BOT ✦\n\n/menu — tampilkan menu\n/ping — cek bot\n/help — bantuan\n/about — info bot\n\nKirim pesan untuk auto-reply.';
  }
  if (command === '/ping') return 'PONG! ZERO WON BOT aktif.';
  if (command === '/help') return 'Bantuan ZERO WON: ketik /menu untuk melihat perintah yang tersedia.';
  if (command === '/about') return 'ZERO WON WhatsApp Bot — berjalan melalui WhatsApp Business Cloud API.';
  return `ZERO WON menerima pesanmu: “${text.slice(0, 500)}”\n\nKetik /menu untuk melihat perintah.`;
}

app.get('/webhook', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];
  if (mode === 'subscribe' && token && token === process.env.VERIFY_TOKEN) return res.status(200).send(challenge);
  return res.sendStatus(403);
});

app.post('/webhook', async (req, res) => {
  if (!validSignature(req)) return res.sendStatus(401);
  // Acknowledge quickly; process messages after returning 200.
  res.sendStatus(200);
  try {
    const entries = req.body.entry || [];
    for (const entry of entries) {
      for (const change of entry.changes || []) {
        const value = change.value || {};
        for (const item of value.messages || []) {
          if (!item.id || seenMessageIds.has(item.id)) continue;
          seenMessageIds.add(item.id);
          if (seenMessageIds.size > 2000) seenMessageIds.clear();
          const from = item.from;
          const incoming = item.text?.body || (item.type === 'button' ? item.button?.text : '') || '';
          if (!from || !incoming) continue;
          addLog('received', `Message from ${maskPhone(from)}.`);
          await sendText(from, replyFor(incoming));
        }
      }
    }
  } catch (error) {
    addLog('error', error.message);
    console.error(error);
  }
});

app.get('/health', (req, res) => res.json({
  status: 'online',
  configured: Boolean(process.env.WHATSAPP_TOKEN && process.env.PHONE_NUMBER_ID && GRAPH_VERSION !== 'vXX.X'),
  uptimeSeconds: Math.floor(process.uptime())
}));
app.get('/api/logs', (req, res) => res.json(logs.slice(0, 30)));
app.get('/api/config-status', (req, res) => res.json({
  token: Boolean(process.env.WHATSAPP_TOKEN),
  phoneNumberId: Boolean(process.env.PHONE_NUMBER_ID),
  verifyToken: Boolean(process.env.VERIFY_TOKEN),
  appSecret: Boolean(process.env.APP_SECRET),
  graphVersionSet: GRAPH_VERSION !== 'vXX.X'
}));

app.listen(PORT, () => {
  addLog('system', `ZERO WON server started on port ${PORT}.`);
  console.log(`ZERO WON bot listening on http://localhost:${PORT}`);
});
