# K Game Space

Starter Flutter project for an Android game-space dashboard with a dark navy/cyan visual style and a custom K emblem.

## Included
- Home dashboard
- Game library sample list
- Tools page (UI placeholders)
- Profile page
- Custom K logo drawn in Flutter

## Build an APK
1. Install Flutter SDK and Android Studio on a computer.
2. Extract this project.
3. Open a terminal in the `KGameSpace` folder.
4. Run:
   ```bash
   flutter pub get
   flutter doctor
   flutter build apk --release
   ```
5. APK output:
   `build/app/outputs/flutter-apk/app-release.apk`

## Important
This is a starter UI project, not a complete system-level game booster. Real installed-app detection, game launching, FPS overlays, temperature sensors and performance controls require Android native permissions/APIs and device-specific testing. It does not secretly change game memory or bypass game protections.
