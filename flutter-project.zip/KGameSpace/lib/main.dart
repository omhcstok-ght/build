import 'package:flutter/material.dart';

void main() => runApp(const KGameSpaceApp());

const bg = Color(0xFF07111F);
const panel = Color(0xFF101F31);
const cyan = Color(0xFF55DDF5);
const muted = Color(0xFF91A6BA);

class KGameSpaceApp extends StatelessWidget {
  const KGameSpaceApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'K Game Space',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: cyan,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class Game {
  final String name;
  final String subtitle;
  final IconData icon;
  final Color color;
  const Game(this.name, this.subtitle, this.icon, this.color);
}

const games = [
  Game('Free Fire', 'Battle Royale', Icons.local_fire_department, Color(0xFFFFA34D)),
  Game('Roblox', 'Play your world', Icons.extension, Color(0xFFE85B69)),
  Game('Minecraft', 'Build & explore', Icons.grass, Color(0xFF68C889)),
  Game('Mobile Legends', 'MOBA', Icons.shield, Color(0xFF6EAAFF)),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  int selectedGame = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: IndexedStack(
          index: tab,
          children: [
            _home(),
            _library(),
            _tools(),
            _profile(),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF0D1A2A),
        indicatorColor: cyan.withOpacity(.16),
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.sports_esports_outlined), selectedIcon: Icon(Icons.sports_esports), label: 'Games'),
          NavigationDestination(icon: Icon(Icons.tune), label: 'Tools'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _home() => ListView(
    padding: const EdgeInsets.fromLTRB(20, 18, 20, 24),
    children: [
      Row(children: [
        const KLogo(size: 48),
        const SizedBox(width: 12),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('K GAME SPACE', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
          SizedBox(height: 3),
          Text('Your games. One space.', style: TextStyle(color: muted, fontSize: 12)),
        ])),
        IconButton(onPressed: () => _message('Settings coming soon'), icon: const Icon(Icons.settings_outlined, color: muted)),
      ]),
      const SizedBox(height: 25),
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(25),
          gradient: const LinearGradient(colors: [Color(0xFF123B56), Color(0xFF14243C)], begin: Alignment.topLeft, end: Alignment.bottomRight),
          border: Border.all(color: cyan.withOpacity(.22)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('GAME MODE', style: TextStyle(color: cyan, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 2)),
          const SizedBox(height: 9),
          const Text('Ready to play?', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800)),
          const SizedBox(height: 5),
          const Text('Keep your favorite games together.', style: TextStyle(color: Color(0xFFB6C9D8))),
          const SizedBox(height: 18),
          Row(children: [
            _stat('GAMES', '04'),
            const SizedBox(width: 25),
            _stat('MODE', 'READY'),
            const Spacer(),
            const Icon(Icons.bolt, color: cyan, size: 34),
          ]),
        ]),
      ),
      const SizedBox(height: 25),
      _sectionTitle('Quick overview', 'DEVICE'),
      Row(children: [
        Expanded(child: _metric(Icons.speed, 'Performance', 'Monitor support')),
        const SizedBox(width: 12),
        Expanded(child: _metric(Icons.thermostat_outlined, 'Temperature', 'Device dependent')),
      ]),
      const SizedBox(height: 25),
      _sectionTitle('Your games', 'SEE ALL', onTap: () => setState(() => tab = 1)),
      ...games.take(3).map((g) => _gameTile(g)),
      const SizedBox(height: 12),
      const Text('Note: this starter project is a game launcher interface. Real FPS, temperature and installed-app detection need Android-specific integrations.', style: TextStyle(color: muted, fontSize: 11, height: 1.5)),
    ],
  );

  Widget _library() => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('My Games', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800)),
      const SizedBox(height: 6),
      const Text('Your gaming collection', style: TextStyle(color: muted)),
      const SizedBox(height: 20),
      ...games.map(_gameTile),
      const SizedBox(height: 12),
      OutlinedButton.icon(onPressed: () => _message('Add game integration can be connected next.'), icon: const Icon(Icons.add), label: const Text('Add a game')),
    ],
  );

  Widget _tools() => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('Game Tools', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800)),
      const SizedBox(height: 6),
      const Text('Shortcuts for your gaming setup', style: TextStyle(color: muted)),
      const SizedBox(height: 20),
      _toolTile(Icons.speed, 'Performance monitor', 'FPS overlay requires Android integration'),
      _toolTile(Icons.thermostat, 'Device temperature', 'Sensor availability depends on device'),
      _toolTile(Icons.touch_app, 'Touch test', 'Check basic touch response'),
      _toolTile(Icons.settings_suggest, 'Game settings', 'Open device settings manually'),
    ],
  );

  Widget _profile() => Center(child: Column(mainAxisSize: MainAxisSize.min, children: const [
    KLogo(size: 76),
    SizedBox(height: 16),
    Text('K Game Space', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    SizedBox(height: 5),
    Text('Version 1.0.0 • Starter project', style: TextStyle(color: muted)),
  ]));

  Widget _sectionTitle(String title, String action, {VoidCallback? onTap}) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Row(children: [
      Expanded(child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
      GestureDetector(onTap: onTap, child: Text(action, style: const TextStyle(color: cyan, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1))),
    ]),
  );

  Widget _stat(String label, String value) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(label, style: const TextStyle(color: muted, fontSize: 9, letterSpacing: 1.2)),
    const SizedBox(height: 3),
    Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
  ]);

  Widget _metric(IconData icon, String title, String sub) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white.withOpacity(.05))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: cyan),
      const SizedBox(height: 12),
      Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 4),
      Text(sub, style: const TextStyle(color: muted, fontSize: 10)),
    ]),
  );

  Widget _gameTile(Game game) => Container(
    margin: const EdgeInsets.only(bottom: 10),
    padding: const EdgeInsets.all(13),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(17)),
    child: Row(children: [
      Container(width: 48, height: 48, decoration: BoxDecoration(color: game.color.withOpacity(.16), borderRadius: BorderRadius.circular(14)), child: Icon(game.icon, color: game.color, size: 27)),
      const SizedBox(width: 13),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(game.name, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text(game.subtitle, style: const TextStyle(color: muted, fontSize: 11)),
      ])),
      IconButton(onPressed: () => _message('${game.name}: connect Android launch support to open this game.'), icon: const Icon(Icons.play_circle_fill, color: cyan, size: 30)),
    ]),
  );

  Widget _toolTile(IconData icon, String title, String subtitle) => Container(
    margin: const EdgeInsets.only(bottom: 12),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)),
    child: Row(children: [
      Icon(icon, color: cyan, size: 27),
      const SizedBox(width: 14),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text(subtitle, style: const TextStyle(color: muted, fontSize: 11)),
      ])),
      const Icon(Icons.chevron_right, color: muted),
    ]),
  );

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text), behavior: SnackBarBehavior.floating));
  }
}

class KLogo extends StatelessWidget {
  final double size;
  const KLogo({super.key, required this.size});
  @override
  Widget build(BuildContext context) => Container(
    width: size, height: size,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(size * .27),
      gradient: const LinearGradient(colors: [Color(0xFF123B5C), Color(0xFF071522)], begin: Alignment.topLeft, end: Alignment.bottomRight),
      border: Border.all(color: cyan.withOpacity(.35)),
      boxShadow: [BoxShadow(color: cyan.withOpacity(.12), blurRadius: 16)],
    ),
    child: CustomPaint(painter: KMarkPainter()),
  );
}

class KMarkPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = cyan..style = PaintingStyle.fill;
    final w = size.width, h = size.height;
    final path = Path()
      ..moveTo(w*.25, h*.27)..lineTo(w*.72, h*.27)..lineTo(w*.63, h*.39)..lineTo(w*.35, h*.39)
      ..lineTo(w*.35, h*.48)..lineTo(w*.62, h*.48)..lineTo(w*.75, h*.59)..lineTo(w*.35, h*.59)
      ..lineTo(w*.25, h*.70)..lineTo(w*.25, h*.57)..lineTo(w*.43, h*.50)..lineTo(w*.25, h*.43)..close();
    canvas.drawPath(path, p);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
