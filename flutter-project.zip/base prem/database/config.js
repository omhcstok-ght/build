module.exports = {
  tokens: "8492430132:AAFzqOiIYvb4QqnEjyV5GokgsZxpze9mh34",  // Ubah Jadi Token Bot Mu !!!
  owner: "1320437076", // Ubah Jadi Id Mu !!!
  port: "3005", // Ubah Jadi Port Panel Mu !!!
  ipvps: "152.42.162.115" // Ubah Jadi Ip Vps Mu !!!
};