XSCTEAMZ — PAKET PROJECT ANDROID

CARA BUILD APK MELALUI GITHUB

1. Ekstrak ZIP ini.
2. Upload ISI folder ini ke repository GitHub (bukan folder pembungkusnya).
3. Pastikan pubspec.yaml, lib/, assets/, dan .github/ terlihat langsung di halaman utama repository.
4. Buka tab Actions.
5. Pilih workflow "Build XSCTEAMZ APK", lalu tekan Run workflow.
6. Jika proses selesai, buka hasil run dan unduh artifact "XSCTEAMZ-APK".

CATATAN
- Paket ini membungkus aplikasi HTML XSCTEAMZ ke dalam aplikasi Android menggunakan Flutter WebView.
- Data yang tersimpan hanya di perangkat/browser tetap bersifat lokal; paket ini tidak menambahkan server atau sinkronisasi akun/riwayat antarperangkat.
- Build bergantung pada layanan GitHub Actions, Flutter, Android SDK, dan koneksi internet.
- Tidak ada jaminan bebas dari semua error di setiap layanan build. Jika gagal, kirim log error lengkap agar penyebabnya bisa diperbaiki.
