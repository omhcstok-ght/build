XSCTEAMZ Flutter project

1. Extract this ZIP.
2. Upload the CONTENTS of this folder to the root of a GitHub repository.
3. Make sure pubspec.yaml is at the repository root (not inside another folder).
4. Open GitHub > Actions > Build XSCTEAMZ APK > Run workflow.
5. When complete, download the XSCTEAMZ-APK artifact.

This is a Flutter WebView wrapper around the supplied XSCTEAMZ HTML file.
The web app itself retains its existing browser/local-storage behavior. It does not
add a backend or make local account/history data sync between devices.
