import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() => runApp(const XSCTEAMZApp());

class XSCTEAMZApp extends StatelessWidget {
  const XSCTEAMZApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'XSCTEAMZ',
      themeMode: ThemeMode.dark,
      home: XSCTEAMZHome(),
    );
  }
}

class XSCTEAMZHome extends StatefulWidget {
  const XSCTEAMZHome({super.key});

  @override
  State<XSCTEAMZHome> createState() => _XSCTEAMZHomeState();
}

class _XSCTEAMZHomeState extends State<XSCTEAMZHome> {
  late final WebViewController controller;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF0D0F18))
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (_) => setState(() => loading = false),
      ))
      ..loadFlutterAsset('assets/index.html');
  }

  Future<bool> _back() async {
    if (await controller.canGoBack()) {
      await controller.goBack();
      return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (!didPop && await controller.canGoBack()) {
          await controller.goBack();
        } else if (!didPop && mounted) {
          // Keep the app open on the home screen; Android handles the next back press.
        }
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF0D0F18),
        body: SafeArea(
          child: Stack(children: [
            WebViewWidget(controller: controller),
            if (loading)
              const ColoredBox(
                color: Color(0xFF0D0F18),
                child: Center(
                  child: CircularProgressIndicator(color: Color(0xFFE94C9A)),
                ),
              ),
          ]),
        ),
      ),
    );
  }
}
