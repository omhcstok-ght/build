# MetodeUnbandByForge

**Developer:** FORGE
**Version:** V1.0.0
**Platform:** Android + Flutter Web

> MetodeUnbandByForge adalah aplikasi Flutter yang membantu pengguna menyusun surat permohonan peninjauan (appeal/review-request) yang santun dan multibahasa untuk akun WhatsApp yang dibatasi (restricted), lalu mengirimkannya sendiri melalui aplikasi email milik pengguna. Aplikasi ini TIDAK melakukan otomasi, TIDAK mengirim email secara otomatis, dan TIDAK menjamin pemulihan akun. Aplikasi ini tidak berafiliasi dengan WhatsApp atau Meta.

---

## Daftar Isi

- [Fitur](#fitur)
- [Struktur Proyek](#struktur-proyek)
- [Persyaratan](#persyaratan)
- [Menjalankan dengan Cepat](#menjalankan-dengan-cepat)
- [Build APK](#build-apk)
- [Build Flutter Web](#build-flutter-web)
- [Tabel Penggantian Media](#tabel-penggantian-media)
- [Admin Panel](#admin-panel)
- [Firebase (Opsional)](#firebase-opsional)
- [Mode Lokal vs Firebase](#mode-lokal-vs-firebase)
- [Keamanan](#keamanan)
- [Disclaimer Lengkap](#disclaimer-lengkap)
- [Lisensi](#lisensi)
- [Troubleshooting](#troubleshooting)

---

## Fitur

- Video intro (layar pembuka dengan video `assets/videos/intro.mp4`).
- Loading screen dengan progres pra-muat aset yang NYATA (real asset-preloading progress), tombol lewati (LEWATI), dan musik latar (BGM) berloop.
- Carousel 3 foto (sumber: `assets/images/1000023802.png`, `1000014144.webp`, `1000014143.webp`).
- 5 template permohonan multibahasa (seri V1 — MULTILINGUAL APPEAL, masing-masing sekitar 50 bahasa).
- Form pengguna dengan validasi (nama, nomor WhatsApp internasional dengan pola `^\+?[1-9]\d{6,14}$`, jenis masalah, detail masalah).
- Preview teks akhir yang dapat diedit langsung oleh pengguna.
- Tombol Salin (copy) dan Buka Email (membuka aplikasi email pengguna via `mailto:`).
- Pelacakan status draft: `Belum dikirim`, `Draft tersimpan`, `Siap dikirim`, `Email dibuka`.
- Admin Panel:
  - Login dengan password yang di-hash SHA-256 (tersimpan lokal).
  - Perubahan password WAJIB pada login pertama.
  - Kunci akun otomatis setelah 5 percobaan login gagal.
  - Modul: Dashboard (statistik + log), Template (CRUD), Media Manager, App Settings, Users/Drafts.
- Mode Firebase OPSIONAL (Firebase Auth + Cloud Firestore + Storage) dengan fallback otomatis ke mode lokal (SharedPreferences) jika Firebase belum dikonfigurasi.
- Draft SELALU disimpan secara lokal di perangkat pengguna (privasi).
- Tema gelap yang dibangun dari AppSettings (warna primer dapat diubah lewat Admin Panel).

## Struktur Proyek

```
MetodeUnbandByForge/
├── README.md
├── analysis_options.yaml
├── .gitignore
├── docs/
│   ├── FIREBASE_SETUP.md
│   ├── BUILD_GUIDE.md
│   └── ASSET_GUIDE.md
├── admin/
│   ├── README.md
│   ├── firestore.rules
│   └── storage.rules
├── android/                  (dibuat ulang dengan flutter create, lihat di bawah)
├── web/                      (dibuat ulang dengan flutter create, lihat di bawah)
├── assets/
│   ├── audio/
│   │   └── bgm.mp3
│   ├── images/
│   │   ├── 1000023802.png
│   │   ├── 1000014144.webp
│   │   ├── 1000014143.webp
│   │   └── forge_logo.png
│   └── videos/
│       ├── intro.mp4
│       └── loading.mp4
└── lib/
    ├── main.dart                          (entry point, Provider AppState, tema gelap)
    ├── models/
    │   └── models.dart                    (AppealTemplate, AppealDraft + DraftStatus, AppSettings, ActivityLog, AdminAccount)
    ├── theme/
    │   └── app_theme.dart                 (buildForgeTheme(AppSettings))
    ├── data/
    │   └── default_templates.dart         (kDefaultTemplates: seed 5 template)
    ├── services/
    │   ├── database_service.dart          (abstract DatabaseService + factory createDatabaseService: coba Firebase, fallback lokal)
    │   ├── local_database_service.dart    (implementasi SharedPreferences)
    │   ├── firebase_database_service.dart (Firestore: forge_settings, forge_templates, forge_logs, forge_users)
    │   ├── firebase_options.dart          (STUB; timpa dengan flutterfire configure)
    │   ├── auth_service.dart              (autentikasi admin lokal SHA-256 + Firebase Auth opsional)
    │   ├── audio_service.dart             (BGM loop via audioplayers)
    │   ├── media_service.dart             (file_picker + path_provider)
    │   └── template_text.dart             (buildFinalText: penggantian variabel)
    ├── providers/
    │   └── app_state.dart                 (AppState ChangeNotifier)
    ├── widgets/
    │   ├── common.dart                    (ForgeLogo, GlowingButton, ForgeCard, SectionHeader, skeleton, toast)
    │   └── media_widgets.dart             (VideoBackground + fallback, MediaResolverImage, AutoCarousel)
    ├── screens/
    │   ├── splash_screen.dart
    │   ├── intro_screen.dart              (video intro)
    │   ├── loading_screen.dart            (progres real + LEWATI + bgm)
    │   ├── home_shell.dart                (header + bottom nav BERANDA/TEMPLATE/PANDUAN/TENTANG)
    │   ├── beranda_screen.dart            (carousel, judul, kartu status)
    │   ├── template_screen.dart           (V1 — MULTILINGUAL APPEAL, 5 kartu: PILIH/LIHAT TEKS/SALIN)
    │   ├── form_screen.dart               (validasi nomor internasional)
    │   ├── preview_screen.dart            (teks editable, salin, buka email, disclaimer)
    │   ├── panduan_screen.dart
    │   └── tentang_screen.dart
    └── admin/
        ├── admin_login_screen.dart
        ├── admin_shell.dart               (TabBar: Dashboard/Template/Media/Pengaturan/Pengguna)
        ├── admin_dashboard_screen.dart
        ├── admin_templates_screen.dart
        ├── admin_media_screen.dart
        ├── admin_settings_screen.dart
        └── admin_users_screen.dart
```

## Persyaratan

- Flutter SDK 3.22 atau lebih baru (Dart 3.4 atau lebih baru).
- Untuk build Android: Android Studio / Android SDK, JDK 17.
- Untuk build Web: browser modern (Chrome disarankan).
- Cek instalasi:

```bash
flutter doctor
```

## Menjalankan dengan Cepat

Folder platform `android/` dan `web/` TIDAK disertakan dalam paket proyek (ZIP). Ini disengaja agar paket tetap ringkas dan tidak ada konfigurasi platform yang bentrok antar mesin. Kedua folder itu aman dibuat ulang oleh Flutter, dan proses ini TIDAK akan menimpa kode maupun aset Anda: file yang sudah ada seperti `lib/` dan `assets/` dipertahankan oleh `flutter create`.

Langkah (jalankan di dalam folder proyek):

```bash
cd MetodeUnbandByForge

# 1. Buat ulang folder platform android/ dan web/
flutter create --platforms=android,web .

# 2. Unduh dependensi
flutter pub get

# 3. Jalankan aplikasi
flutter run
```

Catatan penting untuk langkah `flutter create --platforms=android,web .`:

- Perintah ini harus dijalankan DI DALAM folder proyek (titik `.` di akhir berarti folder saat ini).
- Perintah ini hanya membuat folder/file platform yang belum ada (`android/`, `web/`, dan file pendukung).
- File yang sudah ada, termasuk `lib/` dan `assets/`, tidak akan ditimpa.
- Setelah perintah ini, `flutter run` bisa dipakai untuk Android (perangkat/emulator) maupun Chrome (web).

## Build APK

```bash
flutter build apk --release
```

Hasil build berada di:

```
build/app/outputs/flutter-apk/app-release.apk
```

Untuk opsi lanjutan (split per ABI, penandatanganan release, build appbundle), lihat [docs/BUILD_GUIDE.md](docs/BUILD_GUIDE.md).

## Build Flutter Web

```bash
flutter build web
```

Hasil build berada di folder `build/web/` dan dapat diunggah ke hosting statis apa pun (Firebase Hosting, Netlify, GitHub Pages, atau server web biasa). Panduan deploy ada di [docs/BUILD_GUIDE.md](docs/BUILD_GUIDE.md).

## Tabel Penggantian Media

PERINGATAN: semua file media di bawah ini SAAT INI adalah PLACEHOLDER buatan otomatis (bertema hitam-kuning FORGE), BUKAN file asli milik pengguna. Ganti dengan file asli Anda dengan NAMA FILE YANG SAMA agar tidak perlu mengubah kode.

| File | Tujuan | Cara mengganti |
| --- | --- | --- |
| `assets/videos/intro.mp4` | Video pembuka (intro screen) | Timpa file dengan video Anda, pertahankan nama `intro.mp4`. Rekomendasi: H.264 + AAC, piksel format yuv420p, 720p-1080p. |
| `assets/videos/loading.mp4` | Background layar loading | Timpa file dengan video Anda, pertahankan nama `loading.mp4`. Usahakan durasi pendek dan mudah di-loop. |
| `assets/audio/bgm.mp3` | Musik latar (BGM) berloop di loading screen | Jika Anda hanya punya video MP3 yang ingin dijadikan musik, ekstrak audionya: `ffmpeg -i video_ketiga.mp4 -vn -c:a aac bgm.m4a`. Kemudian simpan hasilnya sebagai `assets/audio/bgm.mp3` (pakai nama `bgm.mp3` agar tidak perlu mengubah kode; format AAC/mp3 keduanya didukung audioplayers). |
| `assets/images/1000023802.png` | Foto carousel slide 1 | Timpa file, pertahankan nama. Disarankan 1280x720 (landscape) atau 1080x1350 (portrait), PNG/WebP/JPEG. |
| `assets/images/1000014144.webp` | Foto carousel slide 2 | Timpa file, pertahankan nama. Format webp aman untuk Android dan Web; jika ragu, konversi ke PNG dengan nama sama tidak disarankan (ekstensi harus tetap sesuai) — gunakan ekstensi asli sesuai daftar. |
| `assets/images/1000014143.webp` | Foto carousel slide 3 | Timpa file, pertahankan nama. |
| `assets/images/forge_logo.png` | Logo aplikasi (header, splash, tentang) | Timpa file, pertahankan nama. PNG dengan latar transparan disarankan. |

Rekomendasi teknis video:

- Codec video: H.264 (AVC). Codec audio: AAC.
- Piksel format: yuv420p (wajib agar kompatibel dengan kebanyakan perangkat Android dan decode web).
- Resolusi: 720p-1080p. Jaga ukuran file tetap kecil (lihat [docs/ASSET_GUIDE.md](docs/ASSET_GUIDE.md)).

Anda juga dapat mengganti path media tanpa menyentuh file aset melalui Admin Panel > Pengaturan (field intro video, loading video, bgm, carousel), atau mengunggah media melalui Admin Panel > Media.

## Admin Panel

Cara masuk:

1. Buka tab TENTANG di aplikasi.
2. Tekan tombol Admin Panel.

Kredensial default:

- Username: `admin`
- Password: `ForgeAdmin#2024`

Aturan keamanan:

- SAAT LOGIN PERTAMA, aplikasi MEMAKSA penggantian password (forced password change). Anda tidak bisa melanjutkan sebelum mengganti password default.
- Password disimpan sebagai hash SHA-256, bukan teks biasa. Password default tidak ditulis di dalam kode publik sebagai kredensial aktif; hash awalnya hanya benih lokal di perangkat Anda.
- Setelah 5 percobaan login gagal, akun dikunci sementara (lockout).

Modul Admin Panel:

- Dashboard: statistik ringkas + log aktivitas.
- Template: CRUD 5 template permohonan.
- Media: kelola/unggah media (via file_picker).
- Pengaturan: App settings (nama aplikasi, warna primer, path media, dan lainnya).
- Pengguna: data pengguna dan draft (mode lokal dibaca dari penyimpanan perangkat).

## Firebase (Opsional)

Firebase SIFATNYA OPSIONAL. Aplikasi berjalan penuh tanpa Firebase (mode lokal default, semua data di SharedPreferences perangkat). Jika Anda ingin sinkronisasi antar perangkat, aktifkan Firebase Auth + Cloud Firestore + Storage, lalu jalankan `flutterfire configure` untuk mengganti stub `lib/firebase_options.dart`.

Panduan lengkap: [docs/FIREBASE_SETUP.md](docs/FIREBASE_SETUP.md)

## Mode Lokal vs Firebase

| Aspek | Mode Lokal (default) | Mode Firebase |
| --- | --- | --- |
| Penyimpanan draft | Selalu lokal (SharedPreferences) | Cloud Firestore (draft tetap tersimpan lokal untuk privasi) |
| Login admin | SHA-256 lokal | Firebase Auth (Email/Password) + custom claim admin |
| Template | Seed lokal + CRUD lokal | Koleksi `forge_templates` |
| Pengaturan | SharedPreferences | Dokumen `forge_settings/app` |
| Log aktivitas | SharedPreferences | Koleksi `forge_logs` |
| Fallback | Otomatis dipakai jika Firebase gagal diinisialisasi | Otomatis turun ke lokal jika `initializeApp` gagal |

## Keamanan

- Password admin disimpan sebagai hash SHA-256; tidak ada password plain text di kode maupun di penyimpanan.
- Kredensial default hanya berlaku di perangkat Anda dan WAJIB diganti pada login pertama.
- Tidak ada password atau kredensial yang di-commit di kode publik. File seperti `google-services.json` dikecualikan dari git (lihat `.gitignore`).
- Draft pengguna SELALU disimpan lokal di perangkat (privasi), apa pun mode database yang aktif.
- Ketika mode Firebase aktif, akses tulis dikontrol security rules + custom claim admin (lihat `admin/firestore.rules` dan `admin/storage.rules`).

## Disclaimer Lengkap

- Aplikasi ini TIDAK berafiliasi, tidak didukung, dan tidak terkait dengan WhatsApp, Meta Platforms, Inc., maupun anak perusahaannya.
- Aplikasi ini TIDAK menjamin pemulihan, pembukaan, atau peninjauan akun apa pun. Hasil akhir sepenuhnya merupakan keputusan WhatsApp.
- Aplikasi ini hanya membantu MENYUSUN teks permohonan. Pengiriman dilakukan OLEH PENGGUNA SENDIRI melalui aplikasi email milik pengguna (tombol buka email hanya membuka draft email; tidak ada pengiriman otomatis).
- Kanal resmi yang dapat digunakan pengguna: FAQ WhatsApp (`https://faq.whatsapp.com`), formulir kontak/resmi di `https://www.whatsapp.com/contact`, atau alamat email dukungan resmi yang ditampilkan di dalam aplikasi WhatsApp milik pengguna sendiri (placeholder `{SUPPORT_EMAIL}` pada template diisi oleh pengguna dengan alamat resmi yang ia terima dari aplikasi WhatsApp-nya). Aplikasi ini tidak menyediakan dan tidak mengklaim alamat email resmi WhatsApp.
- JANGAN gunakan aplikasi ini untuk mengirim email massal, berulang, atau spam. Kirim satu permohonan yang santun dan tunggu jawaban resmi. Penyalahgunaan dapat melanggar ketentuan layanan WhatsApp.
- Pengguna bertanggung jawab penuh atas isi surat, kebenaran data yang dimasukkan, dan kepatuhan terhadap hukum serta ketentuan layanan yang berlaku.

## Lisensi

Perangkat lunak ini disediakan untuk PENGGUNAAN INTERNAL FORGE. Tanpa izin tertulis dari FORGE, Anda tidak diperbolehkan menjual, mensublisensikan, atau mendistribusikan ulang kode ini sebagai produk Anda. Aset media yang Anda unggahkan sendiri tetap milik Anda.

## Troubleshooting

- Konflik versi dependensi saat `flutter pub get`:
  Jalankan `flutter pub upgrade`, lalu ulangi `flutter pub get`. Pastikan Flutter SDK minimal 3.22.
- Video tidak jalan / layar hitam:
  Pastikan codec H.264 + AAC dengan piksel format yuv420p. Perintah normalisasi ada di [docs/ASSET_GUIDE.md](docs/ASSET_GUIDE.md).
- Audio BGM tidak bunyi di Web:
  Browser membatasi autoplay audio tanpa interaksi pengguna. BGM pada aplikasi ini dimulai pada layar loading setelah ada interaksi (tombol LEWATI atau interaksi pertama); perilaku ini normal dan dibatasi oleh browser, bukan bug aplikasi.
- Folder `android/` atau `web/` hilang:
  Jalankan `flutter create --platforms=android,web .` di dalam folder proyek (lihat bagian Menjalankan dengan Cepat).
- Masalah build lanjutan (signing, gradle, minSdk):
  Lihat tabel troubleshooting di [docs/BUILD_GUIDE.md](docs/BUILD_GUIDE.md).
