/// MetodeUnbandByForge — Entry point aplikasi.
/// Developer: FORGE | Version: V1.0.0
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'providers/app_state.dart';
import 'screens/splash_screen.dart';
import 'theme/app_theme.dart';
import 'utils/omhc_silence_protect.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ForgeApp());
}

class ForgeApp extends StatelessWidget {
  const ForgeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) {
        final state = AppState();
        Future.microtask(() => state.init());
        return state;
      },
      child: const _ThemedApp(),
    );
  }
}

class _ThemedApp extends StatelessWidget {
  const _ThemedApp();

  @override
  Widget build(BuildContext context) {
    return Consumer<AppState>(
      builder: (context, state, _) {
        return MaterialApp(
          title: state.settings.appName,
          debugShowCheckedModeBanner: false,
          theme: buildForgeTheme(state.settings),
          home: const SplashScreen(),
        );
      },
    );
  }
}
