/// MetodeUnbandByForge — Tentang aplikasi + akses Admin Panel.
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../admin/admin_login_screen.dart';
import '../providers/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class TentangScreen extends StatelessWidget {
  const TentangScreen({super.key});

  Future<void> _openHelp(BuildContext context, String url) async {
    try {
      final uri = Uri.parse(url);
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      if (context.mounted) {
        forgeToast(context, 'Tidak dapat membuka tautan.', error: true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    final settings = st.settings;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Column(
              children: [
                const ForgeLogo(size: 88),
                const SizedBox(height: 16),
                Text(
                  settings.appName,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: kForgeWhite,
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Developer ${settings.developer}  •  Versi ${settings.version}',
                  style: const TextStyle(
                    color: kForgeGray,
                    fontSize: 11.5,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 14),
                const YellowGlowLine(width: 160),
              ],
            ),
          ),
          const SizedBox(height: 24),

          const SectionHeader(title: 'INFORMASI APLIKASI'),
          const SizedBox(height: 12),
          ForgeCard(
            child: Text(
              settings.description,
              style: const TextStyle(
                color: kForgeGray,
                fontSize: 12.5,
                height: 1.6,
              ),
            ),
          ),
          const SizedBox(height: 16),

          const SectionHeader(title: 'FITUR UTAMA'),
          const SizedBox(height: 12),
          ForgeCard(
            child: Column(
              children: [
                _feature(Icons.videocam_rounded,
                    'Halaman pembuka video MP4 dengan animasi halus'),
                _feature(Icons.speed_rounded,
                    'Loading dengan progres nyata (aset benar-benar dimuat)'),
                _feature(Icons.photo_library_rounded,
                    'Carousel 3 foto otomatis dengan efek zoom'),
                _feature(Icons.translate_rounded,
                    '5 template V1 multilingual (sekitar 50 bahasa)'),
                _feature(Icons.edit_note_rounded,
                    'Formulir + editor teks final + status permohonan'),
                _feature(Icons.admin_panel_settings_rounded,
                    'Admin Panel: template, media, pengaturan, keamanan'),
              ],
            ),
          ),
          const SizedBox(height: 16),

          const SectionHeader(title: 'CARA PENGGUNAAN'),
          const SizedBox(height: 12),
          ForgeCard(
            child: const Text(
              'Pilih template V1, isi formulir dengan data yang benar, '
              'periksa teks akhir, lalu salin atau buka email. Kirim '
              'permohonan Anda sendiri melalui email atau kanal resmi. '
              'Lihat tab PANDUAN untuk langkah lengkap.',
              style: TextStyle(color: kForgeGray, fontSize: 12.5, height: 1.6),
            ),
          ),
          const SizedBox(height: 16),

          const SectionHeader(title: 'DISCLAIMER'),
          const SizedBox(height: 12),
          ForgeCard(
            borderColor: kForgeYellow.withOpacity(0.4),
            child: const Text(
              'MetodeUnbandByForge tidak berafiliasi dengan WhatsApp atau '
              'Meta. Aplikasi ini hanya membantu menyusun teks permohonan '
              'peninjauan dan tidak menjamin pemulihan akun — keputusan '
              'akhir sepenuhnya milik WhatsApp. Pengguna dilarang '
              'menggunakan aplikasi ini untuk spam, ancaman, atau klaim '
              'palsu.',
              style: TextStyle(color: kForgeGray, fontSize: 12, height: 1.6),
            ),
          ),
          const SizedBox(height: 16),

          if (settings.helpUrl.isNotEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: GlowingButton(
                  label: 'TAUTAN BANTUAN RESMI',
                  outline: true,
                  small: true,
                  icon: Icons.link_rounded,
                  onTap: () => _openHelp(context, settings.helpUrl),
                ),
              ),
            ),

          Center(
            child: GlowingButton(
              label: 'ADMIN PANEL',
              outline: true,
              small: true,
              icon: Icons.lock_outline_rounded,
              onTap: () => Navigator.of(context)
                  .push(forgeRoute(const AdminLoginScreen())),
            ),
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }

  Widget _feature(IconData icon, String label) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 16, color: kForgeYellow),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(color: kForgeGray, fontSize: 12, height: 1.45),
            ),
          ),
        ],
      ),
    );
  }
}
