/// MetodeUnbandByForge — Beranda: carousel, judul, aksi, status permohonan.
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../providers/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import '../widgets/media_widgets.dart';

class BerandaScreen extends StatelessWidget {
  final VoidCallback onGoTemplate;
  final VoidCallback onGoPanduan;

  const BerandaScreen({
    super.key,
    required this.onGoTemplate,
    required this.onGoPanduan,
  });

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    final draft = st.latestDraft;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ---------------- Carousel ----------------
          AutoCarousel(images: st.settings.carouselImages),
          const SizedBox(height: 26),

          // ---------------- Judul utama ----------------
          Text(
            st.settings.appName,
            style: const TextStyle(
              color: kForgeWhite,
              fontSize: 22,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            st.settings.description,
            style: const TextStyle(
              color: kForgeGray,
              fontSize: 13,
              height: 1.55,
            ),
          ),
          const SizedBox(height: 16),
          const YellowGlowLine(),
          const SizedBox(height: 20),

          // ---------------- Aksi cepat ----------------
          Row(
            children: [
              Expanded(
                child: GlowingButton(
                  label: 'MULAI SEKARANG',
                  icon: Icons.bolt_rounded,
                  onTap: onGoTemplate,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: GlowingButton(
                  label: 'PANDUAN',
                  icon: Icons.menu_book_rounded,
                  outline: true,
                  onTap: onGoPanduan,
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),

          // ---------------- Status permohonan terakhir ----------------
          SectionHeader(title: 'STATUS PERMOHONAN'),
          const SizedBox(height: 12),
          ForgeCard(
            glow: draft != null,
            borderColor: draft != null ? kForgeYellow.withOpacity(0.5) : null,
            child: draft == null
                ? Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.inbox_rounded,
                              size: 20, color: kForgeGray),
                          const SizedBox(width: 10),
                          const Expanded(
                            child: Text(
                              'Belum ada permohonan',
                              style: TextStyle(
                                color: kForgeWhite,
                                fontWeight: FontWeight.w700,
                                fontSize: 13.5,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Pilih template V1, isi formulir, dan susun teks '
                        'permohonan peninjauan Anda.',
                        style: TextStyle(color: kForgeGray, fontSize: 12, height: 1.5),
                      ),
                      const SizedBox(height: 14),
                      GlowingButton(
                        label: 'BUAT PERMOHONAN',
                        small: true,
                        onTap: onGoTemplate,
                      ),
                    ],
                  )
                : Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              _templateName(st, draft),
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: kForgeWhite,
                                fontWeight: FontWeight.w800,
                                fontSize: 13.5,
                              ),
                            ),
                          ),
                          StatusChip(
                            label: draft.status.label.toUpperCase(),
                            color: _statusColor(draft.status),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Nomor: ${draft.waNumber}',
                        style: const TextStyle(color: kForgeGray, fontSize: 11.5),
                      ),
                      Text(
                        'Diperbarui: ${_formatTime(draft.updatedAt)}',
                        style: const TextStyle(color: kForgeGray, fontSize: 11),
                      ),
                      const SizedBox(height: 16),
                      StatusTimeline(status: draft.status),
                    ],
                  ),
          ),
          const SizedBox(height: 24),

          // ---------------- Disclaimer mini ----------------
          ForgeCard(
            borderColor: kForgeBorder,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.shield_outlined, size: 18, color: kForgeGray),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Aplikasi ini hanya membantu menyusun teks permohonan. '
                    'Tidak ada jaminan pemulihan akun — keputusan akhir '
                    'sepenuhnya milik WhatsApp. Anda mengirim pesan sendiri '
                    'melalui email atau kanal resmi.',
                    style: TextStyle(
                      color: kForgeGray.withOpacity(0.95),
                      fontSize: 11,
                      height: 1.55,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }

  String _templateName(AppState st, AppealDraft d) {
    final t = st.templateById(d.templateId);
    return t?.name ?? 'Template V1';
  }

  Color _statusColor(DraftStatus status) {
    switch (status) {
      case DraftStatus.notSent:
        return kForgeGray;
      case DraftStatus.draftSaved:
        return kForgeYellow;
      case DraftStatus.readyToSend:
        return kForgeYellow;
      case DraftStatus.emailOpened:
        return const Color(0xFF4ADE80);
    }
  }

  String _formatTime(DateTime t) {
    final hh = t.hour.toString().padLeft(2, '0');
    final mm = t.minute.toString().padLeft(2, '0');
    return '${t.day}/${t.month}/${t.year} $hh:$mm';
  }
}
