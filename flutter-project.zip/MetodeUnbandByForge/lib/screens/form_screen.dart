/// MetodeUnbandByForge — Formulir permohonan pengguna.
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../providers/app_state.dart';
import '../services/template_text.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import 'preview_screen.dart';

class FormScreen extends StatefulWidget {
  const FormScreen({super.key});

  @override
  State<FormScreen> createState() => _FormScreenState();
}

class _FormScreenState extends State<FormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _detailCtrl = TextEditingController();
  String _issueType = 'Pemblokiran akun';

  static const _issueTypes = [
    'Pemblokiran akun',
    'Pembatasan fitur',
    'Verifikasi ulang diminta',
    'Akun dicuri / diretas',
    'Kesalahan pelanggaran',
    'Lainnya',
  ];

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _detailCtrl.dispose();
    super.dispose();
  }

  String? _validateName(String? v) {
    if (v == null || v.trim().length < 2) {
      return 'Nama pemilik akun wajib diisi (min. 2 karakter).';
    }
    return null;
  }

  String? _validatePhone(String? v) {
    final raw = (v ?? '').replaceAll(RegExp(r'[\s\-()]'), '');
    if (raw.isEmpty) return 'Nomor WhatsApp wajib diisi.';
    final re = RegExp(r'^\+?[1-9]\d{6,14}$');
    if (!re.hasMatch(raw)) {
      return 'Gunakan format internasional, contoh: +6281234567890';
    }
    return null;
  }

  String? _validateDetails(String? v) {
    if (v == null || v.trim().length < 5) {
      return 'Jelaskan masalah secara singkat (min. 5 karakter).';
    }
    return null;
  }

  Future<void> _submit() async {
    final st = context.read<AppState>();
    if (!( _formKey.currentState?.validate() ?? false)) {
      forgeToast(context, 'Periksa kembali formulir — ada bagian yang belum benar.',
          error: true);
      return;
    }
    final template = st.selectedTemplate;
    if (template == null) {
      forgeToast(context, 'Pilih salah satu template banding terlebih dahulu.',
          error: true);
      return;
    }

    final phone = _phoneCtrl.text.trim().replaceAll(RegExp(r'[\s\-()]'), '');
    final finalText = buildFinalText(
      body: template.body,
      ownerName: _nameCtrl.text,
      waNumber: phone,
      issueType: _issueType,
      issueDetails: _detailCtrl.text,
      supportEmail: st.settings.supportEmail,
      appName: st.settings.appName,
    );

    final draft = await st.createDraft(
      ownerName: _nameCtrl.text.trim(),
      waNumber: phone,
      issueType: _issueType,
      issueDetails: _detailCtrl.text.trim(),
      templateId: template.id,
      finalText: finalText,
    );

    if (!mounted) return;
    Navigator.of(context)
        .push(forgeRoute(PreviewScreen(draft: draft)));
  }

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    final selectedId = st.selectedTemplateId;

    return Scaffold(
      backgroundColor: kForgeBg,
      appBar: AppBar(
        title: const Text(
          'FORMULIR PERMOHONAN',
          style: TextStyle(
            color: kForgeYellow,
            fontWeight: FontWeight.w800,
            fontSize: 14,
            letterSpacing: 1.5,
          ),
        ),
        backgroundColor: kForgeSurface,
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SectionHeader(
                title: 'DATA PEMOHON',
                subtitle: 'Data ini hanya tersimpan di perangkat Anda dan '
                    'digunakan untuk mengisi variabel template.',
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _nameCtrl,
                validator: _validateName,
                textInputAction: TextInputAction.next,
                decoration: const InputDecoration(
                  labelText: 'Nama pemilik akun',
                  hintText: 'Contoh: Budi Santoso',
                  prefixIcon: Icon(Icons.person_outline_rounded,
                      size: 18, color: kForgeGray),
                ),
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _phoneCtrl,
                validator: _validatePhone,
                keyboardType: TextInputType.phone,
                textInputAction: TextInputAction.next,
                decoration: const InputDecoration(
                  labelText: 'Nomor WhatsApp (internasional)',
                  hintText: '+6281234567890',
                  prefixIcon: Icon(Icons.phone_outlined,
                      size: 18, color: kForgeGray),
                ),
              ),
              const SizedBox(height: 14),
              DropdownButtonFormField<String>(
                value: _issueType,
                items: _issueTypes
                    .map((e) => DropdownMenuItem<String>(
                          value: e,
                          child: Text(e,
                              style: const TextStyle(
                                  color: kForgeWhite, fontSize: 13)),
                        ))
                    .toList(),
                onChanged: (v) {
                  if (v != null) setState(() => _issueType = v);
                },
                dropdownColor: kForgeSurface,
                decoration: const InputDecoration(
                  labelText: 'Jenis masalah akun',
                  prefixIcon: Icon(Icons.report_problem_outlined,
                      size: 18, color: kForgeGray),
                ),
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _detailCtrl,
                validator: _validateDetails,
                maxLines: 4,
                minLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Penjelasan singkat masalah',
                  hintText:
                      'Jelaskan secara jujur, singkat, dan profesional apa '
                      'yang terjadi pada akun Anda.',
                  alignLabelWithHint: true,
                ),
              ),
              const SizedBox(height: 20),

              SectionHeader(title: 'TEMPLATE BANDING DIPILIH'),
              const SizedBox(height: 12),
              if (st.activeTemplates.isEmpty)
                ForgeCard(
                  child: const Text(
                    'Tidak ada template aktif. Minta admin mengaktifkan '
                    'template di Admin Panel.',
                    style: TextStyle(color: kForgeGray, fontSize: 12),
                  ),
                )
              else
                DropdownButtonFormField<String>(
                  value: st.templateById(selectedId ?? '')?.id ??
                      st.activeTemplates.first.id,
                  items: st.activeTemplates
                      .map((t) => DropdownMenuItem<String>(
                            value: t.id,
                            child: Text(
                              t.name,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  color: kForgeWhite, fontSize: 13),
                            ),
                          ))
                      .toList(),
                  onChanged: (v) =>
                      context.read<AppState>().selectTemplate(v),
                  dropdownColor: kForgeSurface,
                  decoration: InputDecoration(
                    labelText: 'Template V1',
                    prefixIcon: const Icon(Icons.translate_rounded,
                        size: 18, color: kForgeGray),
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.visibility_outlined,
                          size: 18, color: kForgeGray),
                      tooltip: 'Lihat teks template',
                      onPressed: () {
                        final t = st.templateById(selectedId ?? '') ??
                            st.activeTemplates.first;
                        showBodyDialog(context, title: t.name, body: t.body);
                      },
                    ),
                  ),
                ),
              const SizedBox(height: 26),

              GlowingButton(
                label: 'KIRIM PERMOHONAN',
                icon: Icons.send_rounded,
                expand: true,
                onTap: _submit,
              ),
              const SizedBox(height: 14),
              Text(
                'Catatan: tombol ini menyusun teks akhir dan membuka halaman '
                'preview. Tidak ada pesan yang dikirim otomatis — Anda yang '
                'mengirim melalui email/kanal resmi.',
                style: TextStyle(
                  color: kForgeGray.withOpacity(0.9),
                  fontSize: 10.5,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }
}
