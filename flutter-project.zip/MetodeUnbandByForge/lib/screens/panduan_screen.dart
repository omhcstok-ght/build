/// MetodeUnbandByForge — Panduan penggunaan.
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../theme/app_theme.dart';
import '../widgets/common.dart';

class PanduanScreen extends StatelessWidget {
  const PanduanScreen({super.key});

  static const _steps = [
    (
      'Pilih Template V1',
      'Buka tab TEMPLATE dan pilih salah satu dari lima pilihan V1 — '
          'MULTILINGUAL APPEAL. Tekan LIHAT TEKS untuk membaca isi teks '
          'sebelum memutuskan, lalu tekan PILIH.'
    ),
    (
      'Lengkapi Formulir',
      'Isi nama pemilik akun, nomor WhatsApp dalam format internasional '
          '(contoh +6281234567890), jenis masalah, dan penjelasan singkat '
          'yang jujur. Data ini mengisi variabel pada template.'
    ),
    (
      'Periksa Preview Teks',
      'Teks final akan tersusun otomatis dan tetap dapat Anda edit. '
          'Baca ulang agar pesan sopan, benar, dan tidak berlebihan.'
    ),
    (
      'Salin atau Buka Email',
      'Gunakan SALIN TEKS untuk menempel manual, atau BUKA EMAIL bila '
          'admin sudah mengatur email dukungan. Kirim dari aplikasi email '
          'Anda sendiri — tidak ada pengiriman otomatis.'
    ),
    (
      'Kirim Sekali, Tunggu Resmi',
      'Kirim permohonan Anda satu kali. Hindari mengirim berulang-ulang '
          'karena dapat dianggap spam. Waktu respons bervariasi dan tidak '
          'dapat dijamin.'
    ),
    (
      'Pantau Status',
      'Status permohonan (Belum dikirim, Draft tersimpan, Siap dikirim, '
          'Email dibuka) terlihat di Beranda. Status hanya mencerminkan '
          'perangkat Anda, bukan tanggapan WhatsApp.'
    ),
  ];

  static const _tips = [
    'Gunakan nomor WhatsApp yang benar dengan kode negara.',
    'Jelaskan masalah dengan jujur dan singkat — tanpa klaim palsu.',
    'Bahasa sopan meningkatkan keterbacaan permohonan Anda.',
    'Teks multibahasa membantu tim dukungan yang beragam membaca maksud Anda.',
    'Simpan draft sebelum menutup aplikasi agar tidak hilang.',
    'Kanal resmi WhatsApp: faq.whatsapp.com dan www.whatsapp.com/contact.',
  ];

  Future<void> _openHelp(BuildContext context) async {
    try {
      final uri = Uri.parse(OmhcSilenceProtect.decode(["NV490A","fsyBOS","2l7ZHR","lihEeA","OY3oQ1","fo"]));
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      if (context.mounted) {
        forgeToast(context, 'Tidak dapat membuka tautan.', error: true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionHeader(
            title: 'CARA MENGGUNAKAN',
            subtitle:
                'Enam langkah menyusun permohonan peninjauan akun WhatsApp '
                'yang sopan dan profesional.',
          ),
          const SizedBox(height: 16),
          for (var i = 0; i < _steps.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: ForgeCard(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(
                        color: kForgeYellow.withOpacity(0.12),
                        shape: BoxShape.circle,
                        border:
                            Border.all(color: kForgeYellow.withOpacity(0.5)),
                      ),
                      child: Center(
                        child: Text(
                          '${i + 1}',
                          style: const TextStyle(
                            color: kForgeYellow,
                            fontWeight: FontWeight.w900,
                            fontSize: 14,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _steps[i].$1,
                            style: const TextStyle(
                              color: kForgeWhite,
                              fontWeight: FontWeight.w800,
                              fontSize: 13.5,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            _steps[i].$2,
                            style: const TextStyle(
                              color: kForgeGray,
                              fontSize: 12,
                              height: 1.55,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

          const SizedBox(height: 12),
          const SectionHeader(title: 'TIPS PENTING'),
          const SizedBox(height: 12),
          ForgeCard(
            child: Column(
              children: [
                for (final tip in _tips)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(Icons.check_circle_outline_rounded,
                            size: 15, color: kForgeYellow),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            tip,
                            style: const TextStyle(
                              color: kForgeGray,
                              fontSize: 12,
                              height: 1.5,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // ---------------- Peringatan ----------------
          ForgeCard(
            borderColor: kForgeYellow.withOpacity(0.6),
            glow: true,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.warning_amber_rounded,
                        size: 18, color: kForgeYellow),
                    const SizedBox(width: 8),
                    const Text(
                      'PERINGATAN',
                      style: TextStyle(
                        color: kForgeYellow,
                        fontWeight: FontWeight.w800,
                        fontSize: 12,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                const Text(
                  'Tidak ada sistem atau aplikasi yang dapat menjamin akun '
                  'Anda dibuka kembali. Keputusan pemulihan hanya dapat '
                  'dilakukan oleh WhatsApp. Aplikasi ini tidak berafiliasi '
                  'dengan WhatsApp atau Meta dan tidak mengirim permohonan '
                  'secara otomatis.',
                  style: TextStyle(
                    color: kForgeGray,
                    fontSize: 12,
                    height: 1.6,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          const SectionHeader(title: 'PERTANYAAN UMUM'),
          const SizedBox(height: 12),
          _faq(
            'Apakah akun pasti kembali normal?',
            'Tidak. Tidak ada jaminan. Permohonan hanya membantu menyampaikan '
                'kejadian secara jelas kepada tim resmi WhatsApp yang menilai '
                'setiap kasus.',
          ),
          _faq(
            'Apakah aplikasi mengirim email otomatis?',
            'Tidak. Aplikasi hanya menyusun teks dan membuka aplikasi email '
                'Anda. Anda menekan tombol kirim sendiri dan tidak ada '
                'pengiriman berulang.',
          ),
          _faq(
            'Berapa lama proses peninjauan?',
            'Waktu bervariasi untuk setiap kasus dan tidak dapat dijamin '
                'oleh siapa pun. Hindari mengirim permohonan berkali-kali.',
          ),
          _faq(
            'Mengapa teksnya campur banyak bahasa?',
            'Teks V1 menggabungkan sekitar 50 bahasa sebagai satu permohonan '
                'berlapis, namun inti permohonan tetap jelas dan terstruktur.',
          ),

          const SizedBox(height: 16),
          Center(
            child: GlowingButton(
              label: 'BUKA FAQ RESMI WHATSAPP',
              outline: true,
              small: true,
              icon: Icons.open_in_new_rounded,
              onTap: () => _openHelp(context),
            ),
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }

  Widget _faq(String question, String answer) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Theme(
        data: ThemeData.dark().copyWith(dividerColor: kForgeBorder),
        child: ExpansionTile(
          tilePadding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
          childrenPadding:
              const EdgeInsets.fromLTRB(14, 0, 14, 12),
          collapsedShape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: const BorderSide(color: kForgeBorder),
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: const BorderSide(color: kForgeBorder),
          ),
          backgroundColor: kForgeSurface,
          title: Text(
            question,
            style: const TextStyle(
              color: kForgeWhite,
              fontSize: 12.5,
              fontWeight: FontWeight.w700,
            ),
          ),
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                answer,
                style: const TextStyle(
                  color: kForgeGray,
                  fontSize: 12,
                  height: 1.55,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
