/// MetodeUnbandByForge — Shell utama: header + bottom navigation 4 tab.
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../admin/admin_login_screen.dart';
import '../providers/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import 'beranda_screen.dart';
import 'panduan_screen.dart';
import 'template_screen.dart';
import 'tentang_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  void _goTab(int i) => setState(() => _index = i);

  void _showInfoDialog() {
    final st = context.read<AppState>();
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Row(
          children: [
            const ForgeLogo(size: 34, glow: false),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                st.settings.appName,
                style: const TextStyle(
                  color: kForgeYellow,
                  fontWeight: FontWeight.w800,
                  fontSize: 15,
                ),
              ),
            ),
          ],
        ),
        content: Text(
          '${st.settings.description}\n\n'
          'Developer: ${st.settings.developer}\n'
          'Versi: ${st.settings.version}\n'
          'Mode database: ${st.dbMode.toUpperCase()}',
          style: const TextStyle(color: kForgeGray, fontSize: 12.5, height: 1.5),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('TUTUP',
                style: TextStyle(color: kForgeYellow, fontSize: 12)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();

    return Scaffold(
      backgroundColor: kForgeBg,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            // ---------------- Header ----------------
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: const BoxDecoration(
                color: kForgeSurface,
                border: Border(bottom: BorderSide(color: kForgeBorder)),
              ),
              child: Row(
                children: [
                  const ForgeLogo(size: 42),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          st.settings.appName,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: kForgeWhite,
                            fontWeight: FontWeight.w800,
                            fontSize: 14.5,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Text(
                              '${st.settings.developer} • ${st.settings.version}',
                              style: const TextStyle(
                                color: kForgeGray,
                                fontSize: 10.5,
                                letterSpacing: 1,
                              ),
                            ),
                            const SizedBox(width: 8),
                            const StatusChip(label: 'AKTIF'),
                          ],
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    tooltip: st.soundOn ? 'Matikan suara' : 'Nyalakan suara',
                    onPressed: () => context.read<AppState>().setSound(!st.soundOn),
                    icon: Icon(
                      st.soundOn
                          ? Icons.volume_up_rounded
                          : Icons.volume_off_rounded,
                      size: 20,
                      color: st.soundOn ? kForgeYellow : kForgeGray,
                    ),
                  ),
                  IconButton(
                    tooltip: 'Informasi',
                    onPressed: _showInfoDialog,
                    icon: const Icon(Icons.info_outline_rounded,
                        size: 20, color: kForgeGray),
                  ),
                  IconButton(
                    tooltip: 'Admin Panel',
                    onPressed: () =>
                        Navigator.of(context).push(forgeRoute(const AdminLoginScreen())),
                    icon: const Icon(Icons.lock_outline_rounded,
                        size: 20, color: kForgeGray),
                  ),
                ],
              ),
            ),
            // ---------------- Body ----------------
            Expanded(
              child: IndexedStack(
                index: _index,
                children: [
                  BerandaScreen(
                    onGoTemplate: () => _goTab(1),
                    onGoPanduan: () => _goTab(2),
                  ),
                  const TemplateScreen(),
                  const PanduanScreen(),
                  const TentangScreen(),
                ],
              ),
            ),
          ],
        ),
      ),
      // ---------------- Bottom Navigation ----------------
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: kForgeSurface,
          border: Border(top: BorderSide(color: kForgeBorder)),
        ),
        child: SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(
              children: [
                _NavItem(
                  icon: Icons.home_rounded,
                  label: 'BERANDA',
                  active: _index == 0,
                  onTap: () => _goTab(0),
                ),
                _NavItem(
                  icon: Icons.description_rounded,
                  label: 'TEMPLATE',
                  active: _index == 1,
                  onTap: () => _goTab(1),
                ),
                _NavItem(
                  icon: Icons.menu_book_rounded,
                  label: 'PANDUAN',
                  active: _index == 2,
                  onTap: () => _goTab(2),
                ),
                _NavItem(
                  icon: Icons.info_rounded,
                  label: 'TENTANG',
                  active: _index == 3,
                  onTap: () => _goTab(3),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;

  const _NavItem({
    required this.icon,
    required this.label,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = active ? kForgeYellow : kForgeGray;
    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 22, color: color),
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  fontSize: 9.5,
                  fontWeight: active ? FontWeight.w800 : FontWeight.w600,
                  letterSpacing: 1,
                  color: color,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
