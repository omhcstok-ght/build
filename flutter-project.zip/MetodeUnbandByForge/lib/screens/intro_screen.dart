/// MetodeUnbandByForge — Halaman pembuka fullscreen dengan video MP4 intro.
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';

import '../providers/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import '../widgets/media_widgets.dart';
import 'loading_screen.dart';

class IntroScreen extends StatefulWidget {
  const IntroScreen({super.key});

  @override
  State<IntroScreen> createState() => _IntroScreenState();
}

class _IntroScreenState extends State<IntroScreen> {
  VideoPlayerController? _own;

  @override
  void initState() {
    super.initState();
    // Jika tidak ada controller pra-inisialisasi, buat sendiri.
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final st = context.read<AppState>();
      if (st.introController == null) {
        try {
          final c = VideoPlayerController.asset(st.settings.introVideo);
          await c.initialize();
          if (mounted) {
            setState(() => _own = c);
          } else {
            await c.dispose();
          }
        } catch (_) {}
      }
    });
  }

  @override
  void dispose() {
    try {
      _own?.dispose();
    } catch (_) {}
    // Controller pra-inisialisasi milik AppState — dibiarkan hidup agar
    // dapat dipakai lagi, tidak ada duplikasi.
    super.dispose();
  }

  void _enter() {
    Navigator.of(context).pushReplacement(forgeRoute(const LoadingScreen()));
  }

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    final controller = st.introController ?? _own;

    return Scaffold(
      backgroundColor: kForgeBg,
      body: VideoBackground(
        controller: controller,
        assetPath: controller == null ? st.settings.introVideo : null,
        overlayChild: Container(
          color: Colors.black.withOpacity(0.55),
          child: SafeArea(
            child: TweenAnimationBuilder<double>(
              tween: Tween(begin: 0.0, end: 1.0),
              duration: const Duration(milliseconds: 1100),
              curve: Curves.easeOutCubic,
              builder: (context, t, child) {
                return Opacity(opacity: t, child: child);
              },
              child: Column(
                children: [
                  const Spacer(flex: 3),
                  Hero(
                    tag: 'forge_logo',
                    child: ForgeLogo(size: 104),
                  ),
                  const SizedBox(height: 22),
                  Text(
                    st.settings.appName,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: kForgeWhite,
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.2,
                      height: 1.25,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    st.settings.tagline,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: kForgeGray,
                      fontSize: 13,
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 22),
                  const YellowGlowLine(width: 170),
                  const Spacer(flex: 4),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 28),
                    child: SizedBox(
                      width: double.infinity,
                      child: GlowingButton(
                        label: 'MASUK KE APLIKASI',
                        icon: Icons.arrow_forward_rounded,
                        onTap: _enter,
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),
                  Text(
                    '${st.settings.developer}  •  ${st.settings.version}',
                    style: const TextStyle(
                      color: kForgeGray,
                      fontSize: 11,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 22),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
