/// MetodeUnbandByForge — Menu V1: pilihan teks banding multilingual.
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../providers/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import 'form_screen.dart';

class TemplateScreen extends StatelessWidget {
  const TemplateScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    final templates = List<AppealTemplate>.from(st.templates)
      ..sort((a, b) => a.name.compareTo(b.name));

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ---------------- Header kartu utama ----------------
          ForgeCard(
            borderColor: kForgeYellow.withOpacity(0.6),
            glow: true,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: kForgeYellow.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: kForgeYellow.withOpacity(0.5)),
                      ),
                      child: const Icon(Icons.translate_rounded,
                          size: 20, color: kForgeYellow),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Text(
                        'V1 — MULTILINGUAL APPEAL',
                        style: TextStyle(
                          color: kForgeYellow,
                          fontWeight: FontWeight.w900,
                          fontSize: 15,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                const Text(
                  'Lima pilihan teks permohonan peninjauan akun. Setiap '
                  'template menggabungkan sekitar 50 bahasa secara berlapis '
                  'namun tetap menyampaikan permohonan yang jelas, sopan, '
                  'dan profesional.',
                  style: TextStyle(color: kForgeGray, fontSize: 12, height: 1.55),
                ),
                const SizedBox(height: 10),
                StatusChip(
                  label: '${templates.length} TEMPLATE',
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),

          // ---------------- Daftar template ----------------
          for (final t in templates)
            Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: _TemplateCard(template: t),
            ),

          Text(
            'Template dikelola melalui Admin Panel (tambah, edit, '
            'aktifkan/nonaktifkan).',
            style: TextStyle(
              color: kForgeGray.withOpacity(0.8),
              fontSize: 10.5,
              fontStyle: FontStyle.italic,
            ),
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Kartu satu template
// ---------------------------------------------------------------------------
class _TemplateCard extends StatelessWidget {
  final AppealTemplate template;

  const _TemplateCard({required this.template});

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    final t = template;
    final selected = st.selectedTemplateId == t.id;

    return ForgeCard(
      borderColor: selected
          ? kForgeYellow.withOpacity(0.85)
          : (t.isActive ? kForgeBorder : kForgeBorder.withOpacity(0.5)),
      glow: selected,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: selected
                      ? kForgeYellow.withOpacity(0.15)
                      : kForgeBg,
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: selected ? kForgeYellow : kForgeBorder,
                  ),
                ),
                child: Center(
                  child: selected
                      ? const Icon(Icons.check_rounded,
                          size: 16, color: kForgeYellow)
                      : Text(
                          'V1',
                          style: TextStyle(
                            color: t.isActive ? kForgeGray : kForgeBorder,
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      t.name,
                      style: TextStyle(
                        color: t.isActive ? kForgeWhite : kForgeGray,
                        fontWeight: FontWeight.w800,
                        fontSize: 13.5,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(99),
                            border: Border.all(
                              color: kForgeYellow.withOpacity(0.5),
                            ),
                          ),
                          child: Text(
                            '${t.languageCount} BAHASA',
                            style: const TextStyle(
                              color: kForgeYellow,
                              fontSize: 9.5,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        if (selected)
                          const StatusChip(label: 'DIPILIH')
                        else if (!t.isActive)
                          const StatusChip(label: 'NONAKTIF', color: kForgeGray),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            t.description,
            style: const TextStyle(color: kForgeGray, fontSize: 12, height: 1.5),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: GlowingButton(
                  label: 'PILIH',
                  small: true,
                  icon: Icons.check_circle_outline_rounded,
                  onTap: t.isActive
                      ? () {
                          st.selectTemplate(t.id);
                          forgeToast(context,
                              '${t.name} dipilih. Lengkapi formulir berikutnya.');
                          Navigator.of(context)
                              .push(forgeRoute(const FormScreen()));
                        }
                      : null,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: GlowingButton(
                  label: 'LIHAT TEKS',
                  small: true,
                  outline: true,
                  icon: Icons.visibility_outlined,
                  onTap: () => showBodyDialog(
                    context,
                    title: t.name,
                    body: t.body,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: GlowingButton(
                  label: 'SALIN',
                  small: true,
                  outline: true,
                  icon: Icons.copy_rounded,
                  onTap: () async {
                    await Clipboard.setData(ClipboardData(text: t.body));
                    if (context.mounted) {
                      forgeToast(context,
                          'Template disalin. Variabel belum diisi — gunakan formulir.');
                    }
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
