/// MetodeUnbandByForge — Halaman loading dengan progres NYATA.
///
/// Persentase mengikuti proses pemuatan aset & inisialisasi aplikasi:
/// database, template, precache gambar, audio latar, pra-init video intro.
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/app_state.dart';
import '../services/audio_service.dart';
import '../services/platform_media.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import '../widgets/media_widgets.dart';
import 'home_shell.dart';

class _LoadTask {
  final double weight;
  final String label;
  final Future<void> Function() run;

  const _LoadTask(this.weight, this.label, this.run);
}

class LoadingScreen extends StatefulWidget {
  const LoadingScreen({super.key});

  @override
  State<LoadingScreen> createState() => _LoadingScreenState();
}

class _LoadingScreenState extends State<LoadingScreen> {
  double _progress = 0;
  String _status = 'MENYIAPKAN...';
  bool _skipped = false;
  bool _navigated = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _runTasks());
  }

  Future<void> _runTasks() async {
    final st = context.read<AppState>();

    Future<void> precacheRef(String ref) async {
      final provider = imageProviderFor(ref);
      if (provider == null) return;
      try {
        await precacheImage(provider, context, onError: (_, __) {});
      } catch (_) {}
    }

    final tasks = <_LoadTask>[
      _LoadTask(0.15, 'MENGHUBUNGKAN DATABASE & PENGATURAN', () async {
        if (!st.loaded) await st.init();
      }),
      _LoadTask(0.10, 'MEMUAT TEMPLATE BANDING V1', () async {
        // Pastikan template ter-seed dan terbaca.
        if (st.templates.isEmpty) await st.init();
      }),
      _LoadTask(0.25, 'MEMUAT GAMBAR CAROUSEL', () async {
        for (final img in st.settings.carouselImages) {
          if (_skipped) return;
          await precacheRef(img);
        }
      }),
      _LoadTask(0.10, 'MENYIAPKAN AUDIO LATAR', () async {
        if (st.soundOn) {
          await AudioService.I.startBgm(st.settings.bgmAudio);
        }
      }),
      _LoadTask(0.25, 'MENYIAPKAN VIDEO INTRO', () async {
        await st.preInitIntro();
      }),
      _LoadTask(0.15, 'FINALISASI', () async {
        await WidgetsBinding.instance.endOfFrame;
      }),
    ];

    for (final task in tasks) {
      if (_skipped || !mounted) return;
      setState(() => _status = task.label);
      try {
        await task.run().timeout(const Duration(seconds: 12), onTimeout: () {});
      } catch (_) {
        // Task gagal tidak menghentikan loading — progres tetap jalan.
      }
      if (!mounted || _skipped) return;
      await Future.delayed(const Duration(milliseconds: 180));
      setState(() {
        _progress = (_progress + task.weight).clamp(0.0, 1.0);
      });
    }

    if (!mounted || _skipped) return;
    setState(() {
      _progress = 1.0;
      _status = 'SELESAI';
    });
    await Future.delayed(const Duration(milliseconds: 550));
    if (!mounted || _skipped || _navigated) return;
    _navigated = true;
    Navigator.of(context)
        .pushReplacement(forgeRoute(const HomeShell()));
  }

  void _skip() {
    if (_navigated) return;
    _skipped = true;
    _navigated = true;
    Navigator.of(context).pushReplacement(forgeRoute(const HomeShell()));
  }

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();

    return Scaffold(
      backgroundColor: kForgeBg,
      body: VideoBackground(
        assetPath: st.settings.loadingVideo,
        overlayChild: Container(
          color: Colors.black.withOpacity(0.5),
          child: SafeArea(
            child: Stack(
              children: [
                // Tombol mute/unmute kiri atas
                Positioned(
                  top: 8,
                  left: 8,
                  child: _RoundIconButton(
                    icon: st.soundOn
                        ? Icons.volume_up_rounded
                        : Icons.volume_off_rounded,
                    onTap: () => context.read<AppState>().setSound(!st.soundOn),
                  ),
                ),
                // Tombol LEWATI kanan atas
                Positioned(
                  top: 8,
                  right: 8,
                  child: GestureDetector(
                    onTap: _skip,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 10),
                      decoration: BoxDecoration(
                        color: kForgeBg.withOpacity(0.7),
                        borderRadius: BorderRadius.circular(99),
                        border: Border.all(
                          color: kForgeYellow.withOpacity(0.7),
                        ),
                      ),
                      child: const Text(
                        'LEWATI',
                        style: TextStyle(
                          color: kForgeYellow,
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                  ),
                ),
                // Konten bawah tengah
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 34,
                  child: Column(
                    children: [
                      const Text(
                        'LOADING...',
                        style: TextStyle(
                          color: kForgeWhite,
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 4,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        '${(_progress * 100).round()}%',
                        style: TextStyle(
                          color: kForgeYellow,
                          fontSize: 40,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2,
                          shadows: [
                            Shadow(
                              color: kForgeYellow.withOpacity(0.5),
                              blurRadius: 20,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),
                      TweenAnimationBuilder<double>(
                        tween: Tween(end: _progress),
                        duration: const Duration(milliseconds: 320),
                        curve: Curves.easeOut,
                        builder: (context, v, __) {
                          return Container(
                            width: 260,
                            height: 8,
                            decoration: BoxDecoration(
                              color: kForgeBorder,
                              borderRadius: BorderRadius.circular(99),
                            ),
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: FractionallySizedBox(
                                widthFactor: v.clamp(0.0, 1.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: kForgeYellow,
                                    borderRadius: BorderRadius.circular(99),
                                    boxShadow: [
                                      BoxShadow(
                                        color: kForgeYellow.withOpacity(0.6),
                                        blurRadius: 10,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 14),
                      Text(
                        _status,
                        style: TextStyle(
                          color: kForgeGray.withOpacity(0.9),
                          fontSize: 10,
                          letterSpacing: 2,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _RoundIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _RoundIconButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: kForgeBg.withOpacity(0.7),
          shape: BoxShape.circle,
          border: Border.all(color: kForgeBorder),
        ),
        child: Icon(icon, size: 20, color: kForgeYellow),
      ),
    );
  }
}
