/// MetodeUnbandByForge — Preview teks final, salin, buka email, status.
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/models.dart';
import '../providers/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class PreviewScreen extends StatefulWidget {
  final AppealDraft draft;

  const PreviewScreen({super.key, required this.draft});

  @override
  State<PreviewScreen> createState() => _PreviewScreenState();
}

class _PreviewScreenState extends State<PreviewScreen> {
  late final TextEditingController _ctrl;
  bool _agree = false;

  @override
  void initState() {
    super.initState();
    _ctrl = TextEditingController(text: widget.draft.finalText);
    _ctrl.addListener(() {
      widget.draft.finalText = _ctrl.text;
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: _ctrl.text));
    if (mounted) forgeToast(context, 'Teks permohonan disalin ke clipboard.');
  }

  Future<void> _save() async {
    final st = context.read<AppState>();
    widget.draft.finalText = _ctrl.text;
    await st.saveDraft(widget.draft);
    if (mounted) forgeToast(context, 'Draft tersimpan di perangkat ini.');
  }

  Future<void> _markReady() async {
    final st = context.read<AppState>();
    widget.draft.finalText = _ctrl.text;
    widget.draft.status = DraftStatus.readyToSend;
    await st.saveDraft(widget.draft);
    if (mounted) forgeToast(context, 'Status: siap dikirim.');
  }

  Future<void> _openEmail() async {
    if (!_agree) {
      forgeToast(
        context,
        'Centang persetujuan terlebih dahulu untuk melanjutkan.',
        error: true,
      );
      return;
    }

    final st = context.read<AppState>();
    final email = st.settings.supportEmail.trim();

    if (email.isEmpty) {
      await forgeConfirm(
        context,
        title: 'EMAIL DUKUNGAN BELUM DIATUR',
        content:
            'Admin belum mengatur email dukungan di Admin Panel > Pengaturan. '
            'Anda tetap dapat menyalin teks dan mengirimnya melalui kanal '
            'resmi WhatsApp (www.whatsapp.com/contact).',
        confirmLabel: 'MENGERTI',
      );
      return;
    }

    // Simpan teks terakhir sebelum membuka email.
    widget.draft.finalText = _ctrl.text;
    await st.saveDraft(widget.draft);

    final subject =
        'Permohonan Peninjauan Akun WhatsApp — ${widget.draft.waNumber}';
    final body = _ctrl.text;

    // Body mailto sangat panjang sering gagal di aplikasi email —
    // berikan pilihan aman secara jujur.
    if (body.length > 1500) {
      final choice = await showDialog<String>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text(
            'TEKS CUKUP PANJANG',
            style: TextStyle(
              color: kForgeYellow,
              fontWeight: FontWeight.w800,
              fontSize: 15,
            ),
          ),
          content: const Text(
            'Teks Anda lebih dari 1500 karakter. Beberapa aplikasi email '
            'tidak dapat membawa isi panjang lewat tautan email. Pilih cara '
            'yang paling aman:',
            style: TextStyle(color: kForgeGray, fontSize: 12.5, height: 1.5),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, 'copy'),
              child: const Text('SALIN TEKS SAJA',
                  style: TextStyle(color: kForgeYellow, fontSize: 12)),
            ),
            TextButton(
              onPressed: () => Navigator.pop(ctx, 'empty'),
              child: const Text('BUKA EMAIL TANPA ISI',
                  style: TextStyle(color: kForgeGray, fontSize: 12)),
            ),
          ],
        ),
      );

      if (choice == 'copy') {
        await _copy();
        return;
      }
      final ok = await _launchMailto(email, subject, null);
      if (ok && mounted) await st.markEmailOpened(widget.draft);
      if (ok && mounted) await _showOpenedDialog();
      return;
    }

    final ok = await _launchMailto(email, subject, body);
    if (ok && mounted) await st.markEmailOpened(widget.draft);
    if (ok && mounted) await _showOpenedDialog();
  }

  Future<bool> _launchMailto(
      String email, String subject, String? body) async {
    try {
      final params = <String, String>{'subject': subject};
      if (body != null) params['body'] = body;
      final uri = Uri(
        scheme: 'mailto',
        path: email,
        queryParameters: params,
      );
      return await launchUrl(
        uri,
        mode: LaunchMode.externalApplication,
      );
    } catch (_) {
      if (mounted) {
        forgeToast(context, 'Tidak dapat membuka aplikasi email di perangkat ini.',
            error: true);
      }
      return false;
    }
  }

  Future<void> _showOpenedDialog() async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text(
          'EMAIL DIBUKA',
          style: TextStyle(
            color: kForgeYellow,
            fontWeight: FontWeight.w800,
            fontSize: 15,
          ),
        ),
        content: const Text(
          'Aplikasi email Anda telah dibuka.\n\n'
          'PENTING:\n'
          '1. Pesan BELUM otomatis terkirim — periksa dan tekan kirim '
          'manual dari aplikasi email.\n'
          '2. Status pada aplikasi ini hanya menandakan bahwa email telah '
          'dibuka, bukan bahwa WhatsApp sudah menerima atau merespons.\n'
          '3. Keputusan akhir sepenuhnya milik WhatsApp.\n'
          '4. Hindari mengirim permohonan berulang-ulang (spam).',
          style: TextStyle(color: kForgeGray, fontSize: 12.5, height: 1.55),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('MENGERTI',
                style: TextStyle(color: kForgeYellow, fontSize: 12)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    final draft = widget.draft;

    return Scaffold(
      backgroundColor: kForgeBg,
      appBar: AppBar(
        title: const Text(
          'PREVIEW TEKS PERMOHONAN',
          style: TextStyle(
            color: kForgeYellow,
            fontWeight: FontWeight.w800,
            fontSize: 14,
            letterSpacing: 1.5,
          ),
        ),
        backgroundColor: kForgeSurface,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ---------------- Status ----------------
            ForgeCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'STATUS PERMOHONAN',
                          style: TextStyle(
                            color: kForgeWhite,
                            fontWeight: FontWeight.w800,
                            fontSize: 12,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ),
                      StatusChip(label: draft.status.label.toUpperCase()),
                    ],
                  ),
                  const SizedBox(height: 16),
                  StatusTimeline(status: draft.status),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // ---------------- Editor teks ----------------
            SectionHeader(
              title: 'TEKS AKHIR (DAPAT DIEDIT)',
              subtitle: 'Perbaiki teks bila perlu sebelum mengirim.',
            ),
            const SizedBox(height: 12),
            Container(
              decoration: BoxDecoration(
                color: kForgeSurface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: kForgeBorder),
              ),
              padding: const EdgeInsets.all(4),
              child: TextFormField(
                controller: _ctrl,
                maxLines: null,
                style: const TextStyle(
                  color: kForgeWhite,
                  fontSize: 11.5,
                  height: 1.5,
                ),
                decoration: const InputDecoration(
                  border: InputBorder.none,
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                ),
              ),
            ),
            const SizedBox(height: 6),
            Align(
              alignment: Alignment.centerRight,
              child: Text(
                '${_ctrl.text.length} karakter',
                style: const TextStyle(color: kForgeGray, fontSize: 10.5),
              ),
            ),
            const SizedBox(height: 16),

            // ---------------- Persetujuan ----------------
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: 24,
                  height: 24,
                  child: Checkbox(
                    value: _agree,
                    activeColor: kForgeYellow,
                    checkColor: kForgeBg,
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    side: const BorderSide(color: kForgeGray),
                    onChanged: (v) => setState(() => _agree = v ?? false),
                  ),
                ),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text(
                    'Saya memahami bahwa teks ini hanya permohonan sopan; '
                    'keputusan pemulihan akun sepenuhnya ditentukan oleh '
                    'WhatsApp, dan saya akan mengirim pesan sendiri.',
                    style: TextStyle(
                      color: kForgeGray,
                      fontSize: 11,
                      height: 1.5,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // ---------------- Tombol aksi ----------------
            Row(
              children: [
                Expanded(
                  child: GlowingButton(
                    label: 'SALIN TEKS',
                    small: true,
                    outline: true,
                    icon: Icons.copy_rounded,
                    onTap: _copy,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: GlowingButton(
                    label: 'SIMPAN',
                    small: true,
                    outline: true,
                    icon: Icons.save_outlined,
                    onTap: _save,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: GlowingButton(
                    label: 'SIAP KIRIM',
                    small: true,
                    outline: true,
                    icon: Icons.check_rounded,
                    onTap: _markReady,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            GlowingButton(
              label: 'BUKA EMAIL',
              icon: Icons.open_in_new_rounded,
              expand: true,
              onTap: _openEmail,
            ),
            const SizedBox(height: 18),

            // ---------------- Disclaimer ----------------
            ForgeCard(
              borderColor: kForgeYellow.withOpacity(0.4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.info_outline_rounded,
                          size: 16, color: kForgeYellow),
                      const SizedBox(width: 8),
                      const Text(
                        'CATATAN PENTING',
                        style: TextStyle(
                          color: kForgeYellow,
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '1. Tidak ada jaminan akun kembali normal — keputusan '
                    'pemulihan hanya dapat dilakukan oleh WhatsApp.\n'
                    '2. Teks dikirim oleh Anda sendiri melalui email/kanal '
                    'resmi; aplikasi tidak melakukan pengiriman otomatis '
                    'dan tidak mengirim berulang.\n'
                    '3. Status "Email dibuka" hanya berarti aplikasi email '
                    'Anda terbuka, bukan konfirmasi penerimaan dari '
                    'WhatsApp.',
                    style: TextStyle(
                      color: kForgeGray.withOpacity(0.95),
                      fontSize: 10.5,
                      height: 1.6,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }
}
