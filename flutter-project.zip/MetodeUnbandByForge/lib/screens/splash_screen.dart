/// MetodeUnbandByForge — Splash animation.
import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../widgets/common.dart';
import 'intro_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  bool _navigated = false;

  @override
  void initState() {
    super.initState();
    _go();
  }

  Future<void> _go() async {
    await Future.delayed(const Duration(milliseconds: 2000));
    if (!mounted || _navigated) return;
    _navigated = true;
    Navigator.of(context).pushReplacement(forgeRoute(const IntroScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kForgeBg,
      body: Center(
        child: TweenAnimationBuilder<double>(
          tween: Tween(begin: 0.0, end: 1.0),
          duration: const Duration(milliseconds: 1400),
          curve: Curves.easeOutCubic,
          builder: (context, t, child) {
            return Opacity(
              opacity: t,
              child: Transform.scale(
                scale: 0.75 + 0.25 * t,
                child: child,
              ),
            );
          },
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const ForgeLogo(size: 110),
              const SizedBox(height: 24),
              Text(
                'MetodeUnbandByForge',
                style: TextStyle(
                  color: kForgeWhite,
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1,
                  shadows: [
                    Shadow(
                      color: kForgeYellow.withOpacity(0.4),
                      blurRadius: 18,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'by FORGE — V1.0.0',
                style: TextStyle(
                  color: kForgeGray,
                  fontSize: 12,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 28),
              const YellowGlowLine(width: 140),
              const SizedBox(height: 28),
              Text(
                'MEMUAT APLIKASI',
                style: TextStyle(
                  color: kForgeGray.withOpacity(0.7),
                  fontSize: 10,
                  letterSpacing: 3,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
