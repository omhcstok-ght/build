/// MetodeUnbandByForge — Kelola pengguna/draft (admin).
///
/// Pada mode lokal, fitur login pengguna akhir tidak diaktifkan: halaman ini
/// menampilkan daftar draft perangkat ini beserta statusnya.
/// Pada mode Firebase, dokumen koleksi forge_users ditampilkan (read-only).
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../providers/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class AdminUsersScreen extends StatelessWidget {
  const AdminUsersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const SectionHeader(
          title: 'PENGGUNA & AKTIVITAS',
          subtitle: 'Privasi: draft pengguna tersimpan lokal pada perangkat '
              'masing-masing dan tidak pernah diunggah.',
        ),
        const SizedBox(height: 14),

        if (st.dbMode == 'local')
          ForgeCard(
            borderColor: kForgeBorder,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.phonelink_lock_rounded,
                    size: 18, color: kForgeYellow),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Mode LOKAL: fitur login pengguna akhir tidak diaktifkan. '
                    'Tidak ada akun pengguna yang terdaftar di server. Data '
                    'yang tersedia hanyalah draft & log di perangkat ini.',
                    style: TextStyle(
                      color: kForgeGray.withOpacity(0.95),
                      fontSize: 11.5,
                      height: 1.55,
                    ),
                  ),
                ),
              ],
            ),
          )
        else
          FutureBuilder<List<Map<String, dynamic>>>(
            future: context.read<AppState>().loadUsers(),
            builder: (context, snap) {
              if (snap.connectionState == ConnectionState.waiting) {
                return const Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(
                    child: CircularProgressIndicator(color: kForgeYellow),
                  ),
                );
              }
              final users = snap.data ?? [];
              if (users.isEmpty) {
                return ForgeCard(
                  child: Text(
                    'Koleksi forge_users kosong. Buat dokumen pengguna melalui '
                    'Firebase Console atau Admin SDK (lihat '
                    'docs/FIREBASE_SETUP.md).',
                    style: TextStyle(
                      color: kForgeGray.withOpacity(0.95),
                      fontSize: 11.5,
                      height: 1.55,
                    ),
                  ),
                );
              }
              return Column(
                children: [
                  for (final u in users)
                    ForgeCard(
                      padding: const EdgeInsets.all(12),
                      margin: const EdgeInsets.only(bottom: 10),
                      child: Row(
                        children: [
                          const Icon(Icons.person_outline_rounded,
                              size: 18, color: kForgeYellow),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  (u['email'] ?? u['username'] ?? u['id'])
                                      .toString(),
                                  style: const TextStyle(
                                    color: kForgeWhite,
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                if (u['status'] != null)
                                  Text(
                                    'Status: ${u['status']}',
                                    style: const TextStyle(
                                        color: kForgeGray, fontSize: 11),
                                  ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              );
            },
          ),

        const SizedBox(height: 20),
        const SectionHeader(
          title: 'DRAFT PERMOHONAN (LOKAL)',
          subtitle: 'Riwayat permohonan yang tersimpan di perangkat ini.',
        ),
        const SizedBox(height: 12),
        if (st.drafts.isEmpty)
          ForgeCard(
            child: Center(
              child: Text(
                'Belum ada draft tersimpan di perangkat ini.',
                style: TextStyle(color: kForgeGray.withOpacity(0.8), fontSize: 12),
              ),
            ),
          )
        else
          for (final d in st.drafts)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: ForgeCard(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    const Icon(Icons.description_outlined,
                        size: 18, color: kForgeYellow),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${d.ownerName} — ${d.waNumber}',
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: kForgeWhite,
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            'Jenis: ${d.issueType}  •  '
                            '${d.updatedAt.day}/${d.updatedAt.month}/${d.updatedAt.year}',
                            style: const TextStyle(
                                color: kForgeGray, fontSize: 10.5),
                          ),
                        ],
                      ),
                    ),
                    StatusChip(
                      label: d.status.label.toUpperCase(),
                      color: d.status == DraftStatus.emailOpened
                          ? const Color(0xFF4ADE80)
                          : kForgeYellow,
                      dot: false,
                    ),
                  ],
                ),
              ),
            ),
        const SizedBox(height: 12),
      ],
    );
  }
}
