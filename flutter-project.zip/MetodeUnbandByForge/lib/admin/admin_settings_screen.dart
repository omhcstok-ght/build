/// MetodeUnbandByForge — Pengaturan website/aplikasi (admin).
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class AdminSettingsScreen extends StatefulWidget {
  const AdminSettingsScreen({super.key});

  @override
  State<AdminSettingsScreen> createState() => _AdminSettingsScreenState();
}

class _AdminSettingsScreenState extends State<AdminSettingsScreen> {
  late final TextEditingController _nameCtrl;
  late final TextEditingController _taglineCtrl;
  late final TextEditingController _descCtrl;
  late final TextEditingController _emailCtrl;
  late final TextEditingController _urlCtrl;
  late final TextEditingController _devCtrl;
  late final TextEditingController _versionCtrl;
  late final TextEditingController _primaryCtrl;
  late final TextEditingController _bgCtrl;

  static const _primaryOptions = ['#FFD400', '#FFC107', '#F9A825', '#FFEA00'];
  static const _bgOptions = ['#080808', '#0D0D0D', '#121212', '#1A1A1A'];

  @override
  void initState() {
    super.initState();
    final s = context.read<AppState>().settings;
    _nameCtrl = TextEditingController(text: s.appName);
    _taglineCtrl = TextEditingController(text: s.tagline);
    _descCtrl = TextEditingController(text: s.description);
    _emailCtrl = TextEditingController(text: s.supportEmail);
    _urlCtrl = TextEditingController(text: s.helpUrl);
    _devCtrl = TextEditingController(text: s.developer);
    _versionCtrl = TextEditingController(text: s.version);
    _primaryCtrl = TextEditingController(text: s.primaryColorHex);
    _bgCtrl = TextEditingController(text: s.backgroundColorHex);
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _taglineCtrl.dispose();
    _descCtrl.dispose();
    _emailCtrl.dispose();
    _urlCtrl.dispose();
    _devCtrl.dispose();
    _versionCtrl.dispose();
    _primaryCtrl.dispose();
    _bgCtrl.dispose();
    super.dispose();
  }

  String? _validateEmail(String? v) {
    final raw = (v ?? '').trim();
    if (raw.isEmpty) return null; // boleh kosong, diatur admin nanti
    final re = RegExp(r'^[\w\.\-+]+@[\w\-]+(\.[\w\-]+)+$');
    if (!re.hasMatch(raw)) return 'Format email tidak valid.';
    return null;
  }

  String? _validateUrl(String? v) {
    final raw = (v ?? '').trim();
    if (raw.isEmpty) return null;
    if (!raw.startsWith('http://') && !raw.startsWith('https://')) {
      return 'URL harus diawali http:// atau https://';
    }
    return null;
  }

  Future<void> _save() async {
    final errors = [
      _validateEmail(_emailCtrl.text),
      _validateUrl(_urlCtrl.text),
    ];
    if (errors.any((e) => e != null)) {
      forgeToast(context, 'Periksa kembali input yang tidak valid.', error: true);
      return;
    }

    final primaryOk = () {
      try {
        colorFromHex(_primaryCtrl.text);
        return true;
      } catch (_) {
        return false;
      }
    }();
    if (!primaryOk) {
      forgeToast(context, 'Warna utama tidak valid (contoh: #FFD400).',
          error: true);
      return;
    }

    final st = context.read<AppState>();
    final s = st.settings;
    s.appName = _nameCtrl.text.trim().isEmpty
        ? s.appName
        : _nameCtrl.text.trim();
    s.tagline = _taglineCtrl.text.trim();
    s.description = _descCtrl.text.trim();
    s.supportEmail = _emailCtrl.text.trim().toLowerCase();
    s.helpUrl = _urlCtrl.text.trim();
    s.developer = _devCtrl.text.trim().isEmpty ? 'FORGE' : _devCtrl.text.trim();
    s.version =
        _versionCtrl.text.trim().isEmpty ? 'V1.0.0' : _versionCtrl.text.trim();
    s.primaryColorHex = _primaryCtrl.text.trim();
    s.backgroundColorHex = _bgCtrl.text.trim();

    await st.updateSettings(s);
    if (mounted) forgeToast(context, 'Pengaturan tersimpan.');
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionHeader(
            title: 'PENGATURAN APLIKASI',
            subtitle: 'Perubahan langsung tercermin di aplikasi. Email '
                'dukungan HARUS email resmi yang sudah Anda verifikasi — '
                'jangan menggunakan email yang tidak Anda kendalikan.',
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _nameCtrl,
            style: const TextStyle(color: kForgeWhite, fontSize: 13),
            decoration:
                const InputDecoration(labelText: 'Nama aplikasi'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _taglineCtrl,
            style: const TextStyle(color: kForgeWhite, fontSize: 13),
            decoration: const InputDecoration(
                labelText: 'Tagline (tampil di halaman intro)'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _descCtrl,
            maxLines: 3,
            style: const TextStyle(color: kForgeWhite, fontSize: 13),
            decoration: const InputDecoration(
                labelText: 'Deskripsi aplikasi', alignLabelWithHint: true),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _emailCtrl,
            keyboardType: TextInputType.emailAddress,
            style: const TextStyle(color: kForgeWhite, fontSize: 13),
            decoration: const InputDecoration(
              labelText: 'Email dukungan terverifikasi',
              hintText: 'admin@domainanda.com (kosongkan bila belum ada)',
              helperText:
                  'Dipakai untuk tombol BUKA EMAIL. Gunakan email resmi Anda.',
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _urlCtrl,
            keyboardType: TextInputType.url,
            style: const TextStyle(color: kForgeWhite, fontSize: 13),
            decoration: const InputDecoration(
              labelText: 'Link bantuan resmi',
              hintText: OmhcSilenceProtect.decode(["NV490Afs","yBOS2l7Z","HRlihEeA","OY3oQ1fo"]),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _devCtrl,
                  style: const TextStyle(color: kForgeWhite, fontSize: 13),
                  decoration: const InputDecoration(labelText: 'Developer'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: _versionCtrl,
                  style: const TextStyle(color: kForgeWhite, fontSize: 13),
                  decoration: const InputDecoration(labelText: 'Versi'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),

          const SectionHeader(title: 'WARNA TEMA'),
          const SizedBox(height: 12),
          _colorField('Warna utama (kuning)', _primaryCtrl, _primaryOptions),
          const SizedBox(height: 12),
          _colorField('Warna latar (hitam)', _bgCtrl, _bgOptions),
          const SizedBox(height: 22),

          GlowingButton(
            label: 'SIMPAN PENGATURAN',
            icon: Icons.save_rounded,
            expand: true,
            onTap: _save,
          ),
          const SizedBox(height: 14),
          ForgeCard(
            child: Text(
              'Keamanan: nilai pengaturan hanya diubah melalui panel admin '
              'yang terproteksi. Pada mode Firebase, penulisan dibatasi oleh '
              'security rules (admin-claim) di admin/firestore.rules.',
              style: TextStyle(
                color: kForgeGray.withOpacity(0.95),
                fontSize: 10.5,
                height: 1.6,
              ),
            ),
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }

  Widget _colorField(
      String label, TextEditingController ctrl, List<String> options) {
    return Row(
      children: [
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: colorFromHex(ctrl.text),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: kForgeBorder),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: TextField(
            controller: ctrl,
            onChanged: (_) => setState(() {}),
            style: const TextStyle(color: kForgeWhite, fontSize: 13),
            decoration: InputDecoration(labelText: label),
          ),
        ),
        const SizedBox(width: 8),
        for (final o in options)
          GestureDetector(
            onTap: () {
              ctrl.text = o;
              setState(() {});
            },
            child: Container(
              width: 26,
              height: 26,
              margin: const EdgeInsets.only(left: 6),
              decoration: BoxDecoration(
                color: colorFromHex(o),
                shape: BoxShape.circle,
                border: Border.all(
                  color: ctrl.text == o ? kForgeWhite : kForgeBorder,
                  width: ctrl.text == o ? 2 : 1,
                ),
              ),
            ),
          ),
      ],
    );
  }
}
