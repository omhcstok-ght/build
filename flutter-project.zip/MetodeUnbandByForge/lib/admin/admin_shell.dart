/// MetodeUnbandByForge — Shell Admin Panel dengan 5 tab modul.
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import 'admin_dashboard_screen.dart';
import 'admin_media_screen.dart';
import 'admin_settings_screen.dart';
import 'admin_templates_screen.dart';
import 'admin_users_screen.dart';

class AdminShell extends StatelessWidget {
  const AdminShell({super.key});

  Future<void> _logout(BuildContext context) async {
    final ok = await forgeConfirm(
      context,
      title: 'KELUAR ADMIN?',
      content: 'Sesi admin akan diakhiri dan Anda kembali ke aplikasi.',
      confirmLabel: 'YA, KELUAR',
    );
    if (!ok) return;
    if (!context.mounted) return;
    context.read<AppState>().adminLogout();
    Navigator.of(context).popUntil((r) => r.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    if (!st.isAdmin) {
      return const Scaffold(
        backgroundColor: kForgeBg,
        body: Center(
          child: Text(
            'Akses ditolak. Silakan login sebagai admin.',
            style: TextStyle(color: kForgeGray),
          ),
        ),
      );
    }

    return DefaultTabController(
      length: 5,
      child: Scaffold(
        backgroundColor: kForgeBg,
        appBar: AppBar(
          backgroundColor: kForgeSurface,
          title: Row(
            children: [
              const ForgeLogo(size: 32, glow: false),
              const SizedBox(width: 10),
              const Text(
                'ADMIN PANEL',
                style: TextStyle(
                  color: kForgeYellow,
                  fontWeight: FontWeight.w900,
                  fontSize: 15,
                  letterSpacing: 1.5,
                ),
              ),
              const SizedBox(width: 10),
              StatusChip(
                label: st.dbMode.toUpperCase(),
                color: st.dbMode == 'firebase'
                    ? const Color(0xFF4ADE80)
                    : kForgeGray,
                dot: false,
              ),
            ],
          ),
          actions: [
            IconButton(
              tooltip: 'Logout admin',
              onPressed: () => _logout(context),
              icon: const Icon(Icons.logout_rounded, color: kForgeGray),
            ),
          ],
          bottom: const TabBar(
            isScrollable: true,
            labelColor: kForgeYellow,
            unselectedLabelColor: kForgeGray,
            indicatorColor: kForgeYellow,
            labelStyle: TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
            tabs: [
              Tab(icon: Icon(Icons.dashboard_rounded, size: 16), text: 'DASHBOARD'),
              Tab(icon: Icon(Icons.translate_rounded, size: 16), text: 'TEMPLATE'),
              Tab(icon: Icon(Icons.image_rounded, size: 16), text: 'MEDIA'),
              Tab(icon: Icon(Icons.settings_rounded, size: 16), text: 'PENGATURAN'),
              Tab(icon: Icon(Icons.people_outline_rounded, size: 16), text: 'PENGGUNA'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            AdminDashboardScreen(),
            AdminTemplatesScreen(),
            AdminMediaScreen(),
            AdminSettingsScreen(),
            AdminUsersScreen(),
          ],
        ),
      ),
    );
  }
}
