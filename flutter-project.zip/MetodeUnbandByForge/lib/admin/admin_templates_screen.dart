/// MetodeUnbandByForge — Kelola template: tambah, edit, hapus, aktif/nonaktif.
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../providers/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class AdminTemplatesScreen extends StatelessWidget {
  const AdminTemplatesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();

    return Scaffold(
      backgroundColor: kForgeBg,
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: kForgeYellow,
        foregroundColor: kForgeBg,
        onPressed: () => _openEditor(context, null),
        icon: const Icon(Icons.add_rounded),
        label: const Text('TEMPLATE BARU',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (st.templates.isEmpty)
            ForgeCard(
              child: Center(
                child: Text(
                  'Belum ada template. Tambahkan template baru.',
                  style: TextStyle(color: kForgeGray.withOpacity(0.8), fontSize: 12),
                ),
              ),
            ),
          for (final t in st.templates)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: ForgeCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            t.name,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: t.isActive ? kForgeWhite : kForgeGray,
                              fontWeight: FontWeight.w800,
                              fontSize: 13,
                            ),
                          ),
                        ),
                        Switch(
                          value: t.isActive,
                          onChanged: (v) async {
                            await context.read<AppState>().upsertTemplate(
                                  t.copyWith(isActive: v),
                                );
                          },
                        ),
                      ],
                    ),
                    Text(
                      t.description,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: kForgeGray, fontSize: 11.5, height: 1.4),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(99),
                            border:
                                Border.all(color: kForgeYellow.withOpacity(0.5)),
                          ),
                          child: Text(
                            '${t.languageCount} BAHASA',
                            style: const TextStyle(
                              color: kForgeYellow,
                              fontSize: 9.5,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'ID: ${t.id}',
                          style: TextStyle(
                            color: kForgeGray.withOpacity(0.7),
                            fontSize: 9.5,
                          ),
                        ),
                        const Spacer(),
                        IconButton(
                          tooltip: 'Edit',
                          onPressed: () => _openEditor(context, t),
                          icon: const Icon(Icons.edit_rounded,
                              size: 18, color: kForgeYellow),
                        ),
                        IconButton(
                          tooltip: 'Lihat teks',
                          onPressed: () => showBodyDialog(
                              context, title: t.name, body: t.body),
                          icon: const Icon(Icons.visibility_outlined,
                              size: 18, color: kForgeGray),
                        ),
                        IconButton(
                          tooltip: 'Hapus',
                          onPressed: () async {
                            final ok = await forgeConfirm(
                              context,
                              title: 'HAPUS TEMPLATE?',
                              content:
                                  '"${t.name}" akan dihapus permanen dari '
                                  'database.',
                              confirmLabel: 'HAPUS',
                              danger: true,
                            );
                            if (ok && context.mounted) {
                              await context.read<AppState>().deleteTemplate(t.id);
                              if (context.mounted) {
                                forgeToast(context, 'Template dihapus.');
                              }
                            }
                          },
                          icon: const Icon(Icons.delete_outline_rounded,
                              size: 18, color: Color(0xFFFF5252)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 70),
        ],
      ),
    );
  }

  Future<void> _openEditor(BuildContext context, AppealTemplate? template) async {
    final saved = await Navigator.of(context).push<bool>(
      forgeRoute(TemplateEditorPage(template: template)),
    );
    if (saved == true && context.mounted) {
      forgeToast(context, 'Template tersimpan.');
    }
  }
}

// ---------------------------------------------------------------------------
// Editor template (halaman penuh)
// ---------------------------------------------------------------------------
class TemplateEditorPage extends StatefulWidget {
  final AppealTemplate? template;

  const TemplateEditorPage({super.key, this.template});

  @override
  State<TemplateEditorPage> createState() => _TemplateEditorPageState();
}

class _TemplateEditorPageState extends State<TemplateEditorPage> {
  late final TextEditingController _nameCtrl;
  late final TextEditingController _descCtrl;
  late final TextEditingController _bodyCtrl;
  late final TextEditingController _langCtrl;
  late bool _isActive;

  @override
  void initState() {
    super.initState();
    final t = widget.template;
    _nameCtrl = TextEditingController(text: t?.name ?? 'V1 — TEMPLATE BARU');
    _descCtrl =
        TextEditingController(text: t?.description ?? 'Deskripsi template...');
    _bodyCtrl = TextEditingController(text: t?.body ?? '');
    _langCtrl =
        TextEditingController(text: (t?.languages ?? const []).join('\n'));
    _isActive = t?.isActive ?? true;
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _descCtrl.dispose();
    _bodyCtrl.dispose();
    _langCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_nameCtrl.text.trim().isEmpty || _bodyCtrl.text.trim().isEmpty) {
      forgeToast(context, 'Nama dan isi template wajib diisi.', error: true);
      return;
    }
    final langs = _langCtrl.text
        .split(RegExp(r'[\n,]'))
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();

    final st = context.read<AppState>();
    final isNew = widget.template == null;
    final AppealTemplate result;
    if (isNew) {
      result = AppealTemplate(
        id: 'v1_custom_${DateTime.now().millisecondsSinceEpoch}',
        name: _nameCtrl.text.trim(),
        description: _descCtrl.text.trim(),
        body: _bodyCtrl.text,
        languages: langs,
        isActive: _isActive,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
    } else {
      result = widget.template!.copyWith(
        name: _nameCtrl.text.trim(),
        description: _descCtrl.text.trim(),
        body: _bodyCtrl.text,
        languages: langs,
        isActive: _isActive,
      );
    }
    await st.upsertTemplate(result);
    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    final isNew = widget.template == null;

    return Scaffold(
      backgroundColor: kForgeBg,
      appBar: AppBar(
        backgroundColor: kForgeSurface,
        title: Text(
          isNew ? 'TEMPLATE BARU' : 'EDIT TEMPLATE',
          style: const TextStyle(
            color: kForgeYellow,
            fontWeight: FontWeight.w800,
            fontSize: 14,
            letterSpacing: 1.5,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _nameCtrl,
              style: const TextStyle(color: kForgeWhite, fontSize: 13),
              decoration: const InputDecoration(labelText: 'Nama template'),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _descCtrl,
              maxLines: 2,
              style: const TextStyle(color: kForgeWhite, fontSize: 13),
              decoration:
                  const InputDecoration(labelText: 'Deskripsi singkat'),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _bodyCtrl,
              maxLines: 14,
              minLines: 10,
              style: const TextStyle(
                color: kForgeWhite,
                fontSize: 11.5,
                height: 1.5,
                fontFamily: 'monospace',
              ),
              decoration: const InputDecoration(
                labelText: 'Isi template (gunakan variabel {…})',
                alignLabelWithHint: true,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Variabel tersedia: {OWNER_NAME}, {WA_NUMBER}, {ISSUE_TYPE}, '
              '{ISSUE_DETAILS}, {SUPPORT_EMAIL}, {APP_NAME}, {DATE}',
              style: TextStyle(
                color: kForgeGray.withOpacity(0.85),
                fontSize: 10.5,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _langCtrl,
              maxLines: 8,
              minLines: 5,
              style: const TextStyle(color: kForgeWhite, fontSize: 12),
              decoration: const InputDecoration(
                labelText: 'Daftar bahasa (satu per baris atau dipisah koma)',
                alignLabelWithHint: true,
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Template aktif',
                    style: TextStyle(color: kForgeWhite, fontSize: 13),
                  ),
                ),
                Switch(
                  value: _isActive,
                  onChanged: (v) => setState(() => _isActive = v),
                ),
              ],
            ),
            const SizedBox(height: 20),
            GlowingButton(
              label: 'SIMPAN TEMPLATE',
              icon: Icons.save_rounded,
              expand: true,
              onTap: _save,
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }
}
