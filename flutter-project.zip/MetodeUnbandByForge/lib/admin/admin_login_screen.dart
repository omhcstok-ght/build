/// MetodeUnbandByForge — Login Admin (password hash SHA-256, lockout).
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/app_state.dart';
import '../services/auth_service.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import 'admin_shell.dart';

class AdminLoginScreen extends StatefulWidget {
  const AdminLoginScreen({super.key});

  @override
  State<AdminLoginScreen> createState() => _AdminLoginScreenState();
}

class _AdminLoginScreenState extends State<AdminLoginScreen> {
  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _busy = false;
  String? _error;
  int _lockSeconds = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _refreshLock();
  }

  @override
  void dispose() {
    _userCtrl.dispose();
    _passCtrl.dispose();
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _refreshLock() async {
    final st = context.read<AppState>();
    final s = await st.auth.remainingLockSeconds();
    if (!mounted) return;
    setState(() => _lockSeconds = s);
    if (s > 0) {
      _timer?.cancel();
      _timer = Timer.periodic(const Duration(seconds: 1), (_) async {
        final st = context.read<AppState>();
        final s = await st.auth.remainingLockSeconds();
        if (!mounted) return;
        setState(() => _lockSeconds = s);
        if (s <= 0) _timer?.cancel();
      });
    }
  }

  Future<void> _login() async {
    if (_busy || _lockSeconds > 0) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    final st = context.read<AppState>();
    final result = await st.adminLogin(
      _userCtrl.text.trim(),
      _passCtrl.text,
    );

    if (!mounted) return;
    setState(() => _busy = false);

    switch (result) {
      case AdminLoginResult.ok:
        if (st.adminMustChange) {
          await _forceChangePassword(st);
          if (!mounted || !st.isAdmin) return;
        }
        if (!mounted) return;
        Navigator.of(context).pushReplacement(forgeRoute(const AdminShell()));
        break;
      case AdminLoginResult.invalid:
        setState(() => _error = 'Username atau password salah.');
        await _refreshLock();
        break;
      case AdminLoginResult.locked:
        setState(() => _error = 'Akun terkunci sementara. Tunggu beberapa detik.');
        await _refreshLock();
        break;
    }
  }

  Future<void> _forceChangePassword(AppState st) async {
    final newCtrl = TextEditingController();
    final confirmCtrl = TextEditingController();
    String? dialogError;

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text(
            'GANTI PASSWORD (WAJIB)',
            style: TextStyle(
              color: kForgeYellow,
              fontWeight: FontWeight.w800,
              fontSize: 15,
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Ini login pertama dengan password awal. Atur password baru '
                'Anda (minimal 8 karakter).',
                style: TextStyle(color: kForgeGray, fontSize: 12, height: 1.5),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: newCtrl,
                obscureText: true,
                style: const TextStyle(color: kForgeWhite, fontSize: 13),
                decoration: const InputDecoration(
                  labelText: 'Password baru',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: confirmCtrl,
                obscureText: true,
                style: const TextStyle(color: kForgeWhite, fontSize: 13),
                decoration: const InputDecoration(
                  labelText: 'Konfirmasi password baru',
                ),
              ),
              if (dialogError != null) ...[
                const SizedBox(height: 10),
                Text(
                  dialogError!,
                  style: const TextStyle(
                      color: Color(0xFFFF5252), fontSize: 11.5),
                ),
              ],
            ],
          ),
          actions: [
            TextButton(
              onPressed: () async {
                final valid =
                    st.auth.validateNewPassword(newCtrl.text, confirmCtrl.text);
                if (!valid) {
                  setDialogState(() {
                    dialogError =
                        'Password minimal 8 karakter dan konfirmasi harus sama.';
                  });
                  return;
                }
                await st.adminChangePassword(newCtrl.text);
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text('SIMPAN & MASUK',
                  style: TextStyle(color: kForgeYellow, fontSize: 12)),
            ),
          ],
        ),
      ),
    );
    newCtrl.dispose();
    confirmCtrl.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();

    return Scaffold(
      backgroundColor: kForgeBg,
      appBar: AppBar(
        title: const Text(
          'ADMIN PANEL — LOGIN',
          style: TextStyle(
            color: kForgeYellow,
            fontWeight: FontWeight.w800,
            fontSize: 14,
            letterSpacing: 1.5,
          ),
        ),
        backgroundColor: kForgeSurface,
      ),
      body: st.isAdmin
          ? const Center(
              child: CircularProgressIndicator(color: kForgeYellow),
            )
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Center(child: ForgeLogo(size: 72)),
                  const SizedBox(height: 22),
                  const SectionHeader(
                    title: 'AUTENTIKASI ADMINISTRATOR',
                    subtitle:
                        'Halaman ini hanya untuk administrator. Password '
                        'disimpan sebagai hash SHA-256 dan terkunci sementara '
                        'setelah 5 percobaan gagal.',
                  ),
                  const SizedBox(height: 18),
                  TextField(
                    controller: _userCtrl,
                    style: const TextStyle(color: kForgeWhite, fontSize: 13),
                    decoration: const InputDecoration(
                      labelText: 'Username admin',
                      prefixIcon: Icon(Icons.person_outline_rounded,
                          size: 18, color: kForgeGray),
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: _passCtrl,
                    obscureText: true,
                    onSubmitted: (_) => _login(),
                    style: const TextStyle(color: kForgeWhite, fontSize: 13),
                    decoration: const InputDecoration(
                      labelText: 'Password',
                      prefixIcon: Icon(Icons.key_rounded,
                          size: 18, color: kForgeGray),
                    ),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 12),
                    Text(
                      _error!,
                      style: const TextStyle(
                          color: Color(0xFFFF5252), fontSize: 12),
                    ),
                  ],
                  if (_lockSeconds > 0) ...[
                    const SizedBox(height: 12),
                    Text(
                      'Terkunci — coba lagi dalam $_lockSeconds detik.',
                      style: const TextStyle(
                          color: kForgeYellow, fontSize: 12),
                    ),
                  ],
                  const SizedBox(height: 20),
                  GlowingButton(
                    label: _busy ? 'MEMPROSES...' : 'MASUK ADMIN',
                    icon: Icons.login_rounded,
                    expand: true,
                    onTap: (_busy || _lockSeconds > 0) ? null : _login,
                  ),
                  const SizedBox(height: 18),
                  ForgeCard(
                    child: Text(
                      'Kredensial awal admin didokumentasikan pada README.md '
                      '(bagian Admin Panel) dan WAJIB diganti pada login '
                      'pertama. Password tidak pernah disimpan dalam bentuk '
                      'plain text.',
                      style: TextStyle(
                        color: kForgeGray.withOpacity(0.95),
                        fontSize: 11,
                        height: 1.55,
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
