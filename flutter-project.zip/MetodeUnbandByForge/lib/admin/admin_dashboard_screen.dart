/// MetodeUnbandByForge — Dashboard admin: statistik + aktivitas terbaru.
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../providers/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    final emailOpened = st.drafts
        .where((d) => d.status == DraftStatus.emailOpened)
        .length;
    final activeCount = st.templates.where((t) => t.isActive).length;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 2,
          childAspectRatio: 1.7,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          children: [
            _StatCard(
              icon: Icons.translate_rounded,
              value: '${st.templates.length}',
              label: 'TOTAL TEMPLATE',
            ),
            _StatCard(
              icon: Icons.check_circle_outline_rounded,
              value: '$activeCount',
              label: 'TEMPLATE AKTIF',
            ),
            _StatCard(
              icon: Icons.description_rounded,
              value: '${st.drafts.length}',
              label: 'TOTAL DRAFT',
            ),
            _StatCard(
              icon: Icons.mark_email_read_outlined,
              value: '$emailOpened',
              label: 'EMAIL DIBUKA',
            ),
          ],
        ),
        const SizedBox(height: 18),
        ForgeCard(
          child: Row(
            children: [
              Icon(
                st.dbMode == 'firebase'
                    ? Icons.cloud_done_rounded
                    : Icons.phone_android_rounded,
                size: 18,
                color: st.dbMode == 'firebase'
                    ? const Color(0xFF4ADE80)
                    : kForgeYellow,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  st.dbMode == 'firebase'
                      ? 'Mode database: FIREBASE (Firestore).'
                      : 'Mode database: LOKAL (SharedPreferences). '
                          'Draft & log tersimpan di perangkat.',
                  style: const TextStyle(
                      color: kForgeGray, fontSize: 11.5, height: 1.4),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        Row(
          children: [
            const Expanded(child: SectionHeader(title: 'AKTIVITAS TERBARU')),
            TextButton(
              onPressed: st.logs.isEmpty
                  ? null
                  : () async {
                      final ok = await forgeConfirm(
                        context,
                        title: 'BERSIHKAN LOG?',
                        content: 'Semua catatan aktivitas lokal akan dihapus.',
                        confirmLabel: 'HAPUS',
                        danger: true,
                      );
                      if (ok && context.mounted) {
                        await context.read<AppState>().clearLogs();
                      }
                    },
              child: const Text('BERSIHKAN',
                  style: TextStyle(color: kForgeGray, fontSize: 11)),
            ),
          ],
        ),
        const SizedBox(height: 10),
        if (st.logs.isEmpty)
          ForgeCard(
            child: Center(
              child: Text(
                'Belum ada aktivitas tercatat.',
                style: TextStyle(color: kForgeGray.withOpacity(0.8), fontSize: 12),
              ),
            ),
          )
        else
          Container(
            constraints: const BoxConstraints(maxHeight: 320),
            decoration: BoxDecoration(
              color: kForgeBg,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: kForgeBorder),
            ),
            child: ListView.separated(
              shrinkWrap: true,
              padding: const EdgeInsets.all(10),
              itemCount: st.logs.length,
              separatorBuilder: (_, __) =>
                  const Divider(color: kForgeBorder, height: 1),
              itemBuilder: (context, i) {
                final log = st.logs[i];
                final t = log.at;
                final hh = t.hour.toString().padLeft(2, '0');
                final mm = t.minute.toString().padLeft(2, '0');
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    children: [
                      const Icon(Icons.bolt_rounded,
                          size: 14, color: kForgeYellow),
                      const SizedBox(width: 8),
                      Text(
                        log.action,
                        style: const TextStyle(
                          color: kForgeYellow,
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          log.detail,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: kForgeGray, fontSize: 11),
                        ),
                      ),
                      Text(
                        '${t.day}/${t.month} $hh:$mm',
                        style: TextStyle(
                            color: kForgeGray.withOpacity(0.7), fontSize: 10),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        const SizedBox(height: 12),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;

  const _StatCard({
    required this.icon,
    required this.value,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return ForgeCard(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            children: [
              Icon(icon, size: 16, color: kForgeYellow),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  label,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: kForgeGray,
                    fontSize: 9.5,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(
              color: kForgeWhite,
              fontSize: 24,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}
