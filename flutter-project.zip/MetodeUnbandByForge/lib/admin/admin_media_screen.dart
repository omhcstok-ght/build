/// MetodeUnbandByForge — Kelola media: carousel, video intro/loading, musik.
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../providers/app_state.dart';
import '../services/media_service.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import '../widgets/media_widgets.dart';

class AdminMediaScreen extends StatelessWidget {
  const AdminMediaScreen({super.key});

  Future<void> _replaceImage(
      BuildContext context, AppState st, int index) async {
    final ref = await MediaService.pickImage();
    if (ref == null) return;
    if (index >= 0 && index < st.settings.carouselImages.length) {
      st.settings.carouselImages[index] = ref;
    } else {
      st.settings.carouselImages.add(ref);
    }
    await st.updateSettings(st.settings);
    if (context.mounted) forgeToast(context, 'Foto carousel diperbarui.');
  }

  Future<void> _removeImage(
      BuildContext context, AppState st, int index) async {
    if (st.settings.carouselImages.length <= 1) {
      forgeToast(context, 'Minimal satu foto harus tersisa.', error: true);
      return;
    }
    final ok = await forgeConfirm(
      context,
      title: 'HAPUS FOTO?',
      content: 'Foto pada slot ${index + 1} akan dihapus dari carousel.',
      confirmLabel: 'HAPUS',
      danger: true,
    );
    if (!ok) return;
    st.settings.carouselImages.removeAt(index);
    await st.updateSettings(st.settings);
    if (context.mounted) forgeToast(context, 'Foto dihapus.');
  }

  Future<void> _pickVideo(
      BuildContext context, AppState st, String key, String label) async {
    final ref = await MediaService.pickVideo();
    if (ref == null) return;
    if (key == 'intro') {
      st.settings.introVideo = ref;
      st.disposeIntro();
    } else {
      st.settings.loadingVideo = ref;
    }
    await st.updateSettings(st.settings);
    if (context.mounted) forgeToast(context, '$label diperbarui.');
  }

  Future<void> _pickAudio(BuildContext context, AppState st) async {
    final ref = await MediaService.pickAudio();
    if (ref == null) return;
    st.settings.bgmAudio = ref;
    await st.updateSettings(st.settings);
    if (context.mounted) {
      forgeToast(context,
          'Musik latar diperbarui. Perubahan terdengar pada loading berikutnya.');
    }
  }

  Future<void> _reset(BuildContext context, AppState st, String key) async {
    final defaults = AppSettings.defaults();
    switch (key) {
      case 'intro':
        st.settings.introVideo = defaults.introVideo;
        st.disposeIntro();
        break;
      case 'loading':
        st.settings.loadingVideo = defaults.loadingVideo;
        break;
      case 'bgm':
        st.settings.bgmAudio = defaults.bgmAudio;
        break;
    }
    await st.updateSettings(st.settings);
    if (context.mounted) forgeToast(context, 'Dikembalikan ke asset bawaan.');
  }

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    final images = st.settings.carouselImages;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const SectionHeader(
          title: 'CAROUSEL FOTO',
          subtitle: 'Ganti, hapus, atau tambah foto carousel. Pratinjau '
              'ditampilkan langsung sebelum dipublikasikan.',
        ),
        const SizedBox(height: 12),
        for (var i = 0; i < images.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: ForgeCard(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  SizedBox(
                    width: 64,
                    height: 44,
                    child: MediaResolverImage(
                      ref: images[i],
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'SLOT ${i + 1}\n${images[i]}',
                      overflow: TextOverflow.ellipsis,
                      maxLines: 2,
                      style: TextStyle(
                        color: kForgeGray.withOpacity(0.9),
                        fontSize: 10,
                        height: 1.4,
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () => _replaceImage(context, st, i),
                    child: const Text('GANTI',
                        style: TextStyle(
                            color: kForgeYellow,
                            fontSize: 11,
                            fontWeight: FontWeight.w800)),
                  ),
                  IconButton(
                    tooltip: 'Hapus foto',
                    onPressed: () => _removeImage(context, st, i),
                    icon: const Icon(Icons.delete_outline_rounded,
                        size: 18, color: Color(0xFFFF5252)),
                  ),
                ],
              ),
            ),
          ),
        GlowingButton(
          label: 'TAMBAH FOTO',
          small: true,
          outline: true,
          icon: Icons.add_photo_alternate_outlined,
          onTap: () => _replaceImage(context, st, images.length),
        ),
        const SizedBox(height: 22),

        const SectionHeader(
          title: 'VIDEO & AUDIO',
          subtitle: 'Atur video intro, video loading, dan musik latar. '
              'Video disarankan H.264 + AAC (yuv420p), di bawah 10 MB.',
        ),
        const SizedBox(height: 12),
        _mediaRow(
          context,
          icon: Icons.movie_creation_rounded,
          label: 'VIDEO INTRO',
          value: st.settings.introVideo,
          onPick: () => _pickVideo(context, st, 'intro', 'Video intro'),
          onReset: () => _reset(context, st, 'intro'),
        ),
        _mediaRow(
          context,
          icon: Icons.slow_motion_video_rounded,
          label: 'VIDEO LOADING',
          value: st.settings.loadingVideo,
          onPick: () => _pickVideo(context, st, 'loading', 'Video loading'),
          onReset: () => _reset(context, st, 'loading'),
        ),
        _mediaRow(
          context,
          icon: Icons.music_note_rounded,
          label: 'MUSIK LATAR',
          value: st.settings.bgmAudio,
          onPick: () => _pickAudio(context, st),
          onReset: () => _reset(context, st, 'bgm'),
        ),
        const SizedBox(height: 14),
        ForgeCard(
          borderColor: kForgeBorder,
          child: Text(
            'Catatan teknis:\n'
            '1. Di Android, file yang diunggah disalin ke direktori dokumen '
            'aplikasi.\n'
            '2. Di Flutter Web, file disimpan sebagai data URL — batasi '
            'ukuran di bawah 2 MB agar stabil.\n'
            '3. Untuk mengganti musik dari video MP4 ketiga Anda, ekstrak '
            'audionya terlebih dahulu (lihat docs/ASSET_GUIDE.md) atau pilih '
            'file audio langsung.\n'
            '4. Perubahan media di Admin Panel tersimpan pada database yang '
            'aktif (lokal/Firebase).',
            style: TextStyle(
              color: kForgeGray.withOpacity(0.95),
              fontSize: 10.5,
              height: 1.6,
            ),
          ),
        ),
        const SizedBox(height: 12),
      ],
    );
  }

  Widget _mediaRow(
    BuildContext context, {
    required IconData icon,
    required String label,
    required String value,
    required VoidCallback onPick,
    required VoidCallback onReset,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: ForgeCard(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: kForgeBg,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: kForgeBorder),
              ),
              child: Icon(icon, size: 18, color: kForgeYellow),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: const TextStyle(
                      color: kForgeWhite,
                      fontSize: 11.5,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    value,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: kForgeGray.withOpacity(0.85),
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
            TextButton(
              onPressed: onPick,
              child: const Text('UNGGAH',
                  style: TextStyle(
                      color: kForgeYellow,
                      fontSize: 11,
                      fontWeight: FontWeight.w800)),
            ),
            IconButton(
              tooltip: 'Kembalikan asset bawaan',
              onPressed: onReset,
              icon: const Icon(Icons.restore_rounded,
                  size: 18, color: kForgeGray),
            ),
          ],
        ),
      ),
    );
  }
}
