/// MetodeUnbandByForge — Default appeal templates (seed data). Developer: FORGE.
library default_templates;
import '../models/models.dart';

/// Seed data: lima template surat permohonan tinjauan akun WhatsApp yang sopan,
/// jujur, dan dikirim sendiri oleh pengguna melalui email miliknya.
final List<AppealTemplate> kDefaultTemplates = [
  AppealTemplate(
    id: 'v1_professional_appeal',
    name: 'V1 — PROFESSIONAL APPEAL',
    description:
        'Surat appeal bergaya profesional dengan pembagian bagian bernomor yang rapi. '
        'Cocok untuk menyampaikan permohonan tinjauan akun secara formal, tenang, dan mudah dibaca.',
    body: r'''
Subject: Request for Account Review — WhatsApp {WA_NUMBER}
Subjek: Permohonan Tinjauan Akun — WhatsApp {WA_NUMBER}

To: WhatsApp Support Team ({SUPPORT_EMAIL})

1. OPENING STATEMENT (MULTILINGUAL)
[Indonesian]
Akun WhatsApp saya dengan nomor {WA_NUMBER} telah dibatasi aksesnya. Saya dengan hormat memohon tinjauan resmi terhadap akun saya.
[English]
My WhatsApp account {WA_NUMBER} has been restricted. I kindly request an official review of my account.
[Arabic]
حسابي على واتساب {WA_NUMBER} تم تقييده، وأرجو منكم التكرم بمراجعة حسابي رسمياً.
[Mandarin (Simplified)]
我的 WhatsApp 账号 {WA_NUMBER} 已被限制使用，恳请对我的账号进行官方审查。
[Spanish]
Mi cuenta de WhatsApp {WA_NUMBER} ha sido restringida y solicito amablemente una revisión oficial de mi cuenta.
[Hindi]
मेरा WhatsApp खाता {WA_NUMBER} प्रतिबंधित कर दिया गया है। कृपया मेरे खाते की आधिकारिक समीक्षा करें।
[French]
Mon compte WhatsApp {WA_NUMBER} a été restreint et je demande respectueusement un examen officiel de mon compte.
[Portuguese]
Minha conta do WhatsApp {WA_NUMBER} foi restringida e peço gentilmente uma revisão oficial da minha conta.
[Russian]
Мой аккаунт WhatsApp {WA_NUMBER} был ограничен, и я вежливо прошу провести официальную проверку моего аккаунта.
[Japanese]
私のWhatsAppアカウント（{WA_NUMBER}）は制限されました。公式な再審査をお願いいたします。

2. ACCOUNT INFORMATION
[English]
Owner: {OWNER_NAME}
Number: {WA_NUMBER}
Issue type: {ISSUE_TYPE}
Date of this letter: {DATE}
[Indonesian]
Pemilik akun: {OWNER_NAME}
Nomor: {WA_NUMBER}
Jenis masalah: {ISSUE_TYPE}
Tanggal surat: {DATE}

3. EXPLANATION AND GOOD-FAITH STATEMENTS
[English]
I would like to explain my situation honestly: {ISSUE_DETAILS}. I respect the work of the WhatsApp team and I understand that every account must follow the same rules.
[Indonesian]
Saya ingin menjelaskan keadaan saya dengan jujur: {ISSUE_DETAILS}. Saya menghargai kerja tim WhatsApp dan memahami bahwa setiap akun harus mematuhi aturan yang sama.
[Mandarin (Simplified)]
我恳请 WhatsApp 公正地审查我的账号。
[Japanese]
WhatsAppに公平にアカウントを審査していただきたく、お願い申し上げます。
[Korean]
WhatsApp에 제 계정을 공정하게 검토해 주시기를 정중히 부탁드립니다.
[German]
Ich bitte WhatsApp respektvoll, mein Konto fair zu prüfen.
[Turkish]
WhatsApp'tan hesabımı adil bir şekilde incelemesini saygıyla rica ediyorum.
[Urdu]
میں WhatsApp سے احترام کے ساتھ درخواست کرتا ہوں کہ میرے اکاؤنٹ کا منصفانہ جائزہ لیا جائے۔
[Bengali]
আমি WhatsApp-কে সম্মানের সাথে অনুরোধ করছি যে আমার অ্যাকাউন্ট ন্যায্যভাবে পর্যালোচনা করুন।
[Persian]
با احترام از واتساپ درخواست می‌کنم که حسابم را عادلانه بررسی کند.
[Italian]
Chiedo rispettosamente a WhatsApp di esaminare il mio account in modo equo.
[Dutch]
Ik verzoek WhatsApp respectvol om mijn account eerlijk te beoordelen.
[Polish]
Z szacunkiem proszę WhatsApp o uczciwe rozpatrzenie mojego konta.
[Ukrainian]
Я з повагою прошу WhatsApp справедливо розглянути мій акаунт.
[Thai]
ฉันพยายามปฏิบัติตามข้อกำหนดการใช้บริการเสมอมา
[Vietnamese]
Tôi luôn cố gắng tuân thủ Điều khoản Dịch vụ.
[Tagalog]
Laging sinikap kong sundin ang Mga Tuntunin ng Serbisyo.
[Malay]
Saya sentiasa berusaha mematuhi Terma Perkhidmatan.
[Greek]
Έχω πάντα προσπαθήσει να τηρώ τους Όρους Χρήσης.
[Hebrew]
תמיד ניסיתי לציית לתנאי השימוש.
[Swahili]
Kila wakati najitahidi kufuata Masharti ya Huduma.
[Hausa]
Ko da yaushe ina ƙoƙarin bin ka'idojin amfani da sabis ɗin.
[Amharic]
ሁልጊዜ የአገልግሎት ውሎችን ለመከታተል ሞክሬ አውቃለሁ።
[Zulu]
Ngijwayele ukuzama ukulandelela Imigomo Yesevisi.
[Afrikaans]
Ek het altyd probeer om die Diensvoorwaardes na te kom.
[Somali]
Had iyo jeer waan isku dayay inaan raaco Shuruudaha Adeegga.
[Nepali]
तपाईंको समय र ध्यानका लागि धन्यवाद।
[Sinhala]
ඔබේ කාලය සහ සැලකිල්ලට ස්තූතියි.
[Tamil]
உங்கள் நேரம் மற்றும் கருத்திற்கு நன்றி.
[Telugu]
మీ సమయం మరియు పరిగణనకు ధన్యవాదాలు.
[Marathi]
आपल्या वेळेसाठी आणि विचारांसाठी धन्यवाद.
[Gujarati]
તમારા સમય અને વિચાર બદલ આભાર.
[Punjabi]
ਤੁਹਾਡੇ ਸਮੇਂ ਅਤੇ ਵਿਚਾਰ ਲਈ ਧੰਨਵਾਦ।
[Javanese]
Matur nuwun kangge wekdal lan kawigatosan panjenengan.
[Sundanese]
Hatur nuhun kanggo waktos sareng perhatosanana.
[Burmese]
သင့်အချိန်နှင့် စိတ်ဝင်စားမှုအတွက် ကျေးဇူးတင်ပါသည်။
[Khmer]
អរគុណចំពោះពេលវេលា និងការយកចិត្តទុកដាក់របស់អ្នក។
[Lao]
ຂອບໃຈສຳລັບເວລາ ແລະ ຄວາມສົນໃຈຂອງທ່ານ.
[Mongolian]
Таны цаг хугацаа, анхаарал халамжид баярлалаа.
[Kazakh]
Уақытыңыз бен назарыңызға рахмет.
[Uzbek]
Vaqtingiz va e'tiboringiz uchun rahmat.
[Azerbaijani]
Vaxtınız və diqqətiniz üçün təşəkkür edirəm.
[Georgian]
გმადლობთ თქვენს დროსა და ყურადღებას.
[Armenian]
Շնորհակալություն ձեր ժամանակի և ուշադրության համար:

4. GOOD-FAITH COMMITMENTS
[Indonesian]
Saya berkomitmen untuk mematuhi seluruh ketentuan layanan WhatsApp, sekarang dan di masa mendatang.
[English]
I promise to comply with all WhatsApp policies.
[Arabic]
أعد بالامتثال لجميع سياسات واتساب.
[French]
Je m'engage à respecter toutes les politiques de WhatsApp.
[Spanish]
Prometo cumplir todas las políticas de WhatsApp.
[Hindi]
मैं WhatsApp की सभी नीतियों का पालन करने का वादा करता हूँ।
[Portuguese]
Prometo cumprir todas as políticas do WhatsApp.
[Russian]
Я обещаю соблюдать все политики WhatsApp.
[Italian]
Mi impegno a rispettare tutte le politiche di WhatsApp.
[German]
Ich verspreche, alle WhatsApp-Richtlinien einzuhalten.

5. POLITE REQUEST
[English]
If no violation of the Terms of Service is found, please restore access to my account.
[Indonesian]
Apabila tidak ditemukan pelanggaran ketentuan layanan, saya mohon agar akses akun saya dipulihkan kembali.
[Arabic]
أرجو استعادة وصولي إذا لم يتم العثور على أي مخالفة.
[Spanish]
Por favor, restauren mi acceso si no se encuentra ninguna violación.
[Hindi]
यदि कोई उल्लंघन नहीं पाया जाता, तो कृपया मेरी पहुंच बहाल करें।
[French]
Veuillez rétablir mon accès si aucune violation n'est constatée.
[Portuguese]
Por favor, restabeleçam meu acesso se nenhuma violação for encontrada.
[Russian]
Пожалуйста, восстановите мой доступ, если нарушений не обнаружено.
[Japanese]
違反が見つからない場合は、アクセスの回復をお願いいたします。
[Korean]
위반이 발견되지 않으면 접근 권한을 복구해 주시기 바랍니다.
[German]
Bitte stellen Sie meinen Zugang wieder her, wenn kein Verstoß festgestellt wird.
[Turkish]
Herhangi bir ihlal bulunmazsa erişimimi geri yüklemenizi rica ederim.
[Urdu]
اگر کوئی خلاف ورزی نہ ملے تو براہ کرم میری رسائی بحال کریں۔

6. CLOSING COURTESY
[English]
Thank you very much for your time and consideration.
[Indonesian]
Terima kasih banyak atas waktu dan perhatian tim WhatsApp.
[Arabic]
شكراً جزيلاً لكم على وقتكم واهتمامكم.
[Mandarin (Simplified)]
感谢您的时间和考虑。
[Spanish]
Muchas gracias por su tiempo y consideración.
[Hindi]
आपके समय और विचार के लिए बहुत-बहुत धन्यवाद।
[French]
Merci beaucoup pour votre temps et votre attention.
[Portuguese]
Muito obrigado pelo seu tempo e consideração.
[Russian]
Большое спасибо за ваше время и внимание.
[Japanese]
お時間をいただき、誠にありがとうございます。
[Korean]
시간과 관심을 가져주셔서 진심으로 감사합니다.

Respectfully, / Hormat saya,
{OWNER_NAME}
WhatsApp: {WA_NUMBER}
Sent via {APP_NAME}
Date: {DATE}

DISCLAIMER
[English]
This message is a polite request only. WhatsApp makes the final decision.
[Indonesian]
Pesan ini hanya permohonan sopan. Keputusan akhir sepenuhnya ada pada WhatsApp.
''',
    languages: [
      'Indonesian',
      'English',
      'Arabic',
      'Mandarin (Simplified)',
      'Spanish',
      'Hindi',
      'French',
      'Portuguese',
      'Russian',
      'Japanese',
      'Korean',
      'German',
      'Turkish',
      'Urdu',
      'Bengali',
      'Persian',
      'Italian',
      'Dutch',
      'Polish',
      'Ukrainian',
      'Thai',
      'Vietnamese',
      'Tagalog',
      'Malay',
      'Greek',
      'Hebrew',
      'Swahili',
      'Hausa',
      'Amharic',
      'Zulu',
      'Afrikaans',
      'Somali',
      'Nepali',
      'Sinhala',
      'Tamil',
      'Telugu',
      'Marathi',
      'Gujarati',
      'Punjabi',
      'Javanese',
      'Sundanese',
      'Burmese',
      'Khmer',
      'Lao',
      'Mongolian',
      'Kazakh',
      'Uzbek',
      'Azerbaijani',
      'Georgian',
      'Armenian',
    ],
  ),
  AppealTemplate(
    id: 'v1_formal_review',
    name: 'V1 — FORMAL REVIEW',
    description:
        'Surat tinjauan formal dengan gaya korespondensi resmi dan penomoran angka Romawi. '
        'Ditujukan bagi pengguna yang ingin nada baku, lugas, dan terstruktur seperti surat dinas.',
    body: r'''
Subject: Request for Account Review — WhatsApp {WA_NUMBER}
Subjek: Permohonan Tinjauan Formal — WhatsApp {WA_NUMBER}

To: WhatsApp Support Team ({SUPPORT_EMAIL})
Re: Formal review request — WhatsApp {WA_NUMBER}
Date: {DATE}

I. PURPOSE OF THIS LETTER
[Indonesian]
Melalui surat ini, saya {OWNER_NAME}, mengajukan permohonan tinjauan formal atas pembatasan pada akun WhatsApp saya {WA_NUMBER}.
[English]
Through this letter I, {OWNER_NAME}, formally request a review of the restriction applied to my WhatsApp account {WA_NUMBER}.
[Arabic]
أكتب هذا الخطاب لأطلب رسمياً مراجعة التقييد المفروض على حسابي في واتساب {WA_NUMBER}.
[Mandarin (Simplified)]
我写这封信是为了正式申请对受限的 WhatsApp 账号 {WA_NUMBER} 进行审查。
[Spanish]
Escribo esta carta para solicitar formalmente la revisión de la restricción aplicada a mi cuenta de WhatsApp {WA_NUMBER}.
[Hindi]
मैं यह पत्र इसलिए लिख रहा हूँ ताकि मेरे प्रतिबंधित WhatsApp खाते {WA_NUMBER} की औपचारिक समीक्षा की जा सके।
[French]
J'écris cette lettre pour demander officiellement la révision de la restriction appliquée à mon compte WhatsApp {WA_NUMBER}.
[Portuguese]
Escrevo esta carta para solicitar formalmente a revisão da restrição aplicada à minha conta do WhatsApp {WA_NUMBER}.
[Russian]
Я пишу это письмо, чтобы официально просить о пересмотре ограничения моего аккаунта WhatsApp {WA_NUMBER}.
[Japanese]
制限されたWhatsAppアカウント（{WA_NUMBER}）の再審査を正式にお願いするために、この手紙を書いております。

II. ACCOUNT DATA
[English]
Owner: {OWNER_NAME}
Number: {WA_NUMBER}
Issue type: {ISSUE_TYPE}
Letter date: {DATE}
[Indonesian]
Pemilik: {OWNER_NAME}
Nomor: {WA_NUMBER}
Jenis masalah: {ISSUE_TYPE}
Tanggal surat: {DATE}

III. STATEMENT OF FACTS
[English]
Here are the facts as I understand them: {ISSUE_DETAILS}. I am sharing this openly and honestly, without exaggeration.
[Indonesian]
Berikut fakta sejauh pemahaman saya: {ISSUE_DETAILS}. Saya menyampaikannya secara terbuka dan jujur, tanpa melebih-lebihkan.
[Japanese]
もし誤りがあった場合は、心からお詫びし、今後より注意して規則を守ることをお約束します。
[Korean]
잘못이 있었다면 진심으로 사과하며, 앞으로 더 신중하게 규칙을 지키겠습니다.
[German]
Falls ich einen Fehler gemacht habe, entschuldige ich mich aufrichtig und verspreche, die Regeln künftig sorgfältiger zu beachten.
[Turkish]
Bir hata yaptıysam içtenlikle özür dilerim ve kurallara daha dikkatli uyacağım.
[Urdu]
اگر میں نے کوئی غلطی کی ہے تو میں مخلصانہ معافی چاہتا ہوں اور قواعد کی مزید احتیاط سے پابندی کا وعدہ کرتا ہوں۔
[Bengali]
আমি যদি ভুল করে থাকি, তবে আন্তরিকভাবে ক্ষমা চাই এবং নিয়মগুলি আরও সতর্কভাবে মানার প্রতিশ্রুতি দিচ্ছি।
[Persian]
اگر اشتباهی کرده‌ام، صادقانه عذرخواهی می‌کنم و قول می‌دهم قوانین را با دقت بیشتری رعایت کنم.
[Italian]
Se ho commesso un errore, mi scuso sinceramente e prometto di seguire le regole con più attenzione.
[Dutch]
Als ik een fout heb gemaakt, bied ik oprecht mijn excuses aan en beloof ik de regels zorgvuldiger na te leven.
[Polish]
Jeśli popełniłem błąd, szczerze przepraszam i obiecuję przestrzegać zasad uważniej.
[Ukrainian]
Якщо я припустився помилки, я щиро прошу вибачення та обіцяю дотримуватися правил уважніше.
[Romanian]
Dacă am greșit, îmi cer sincer scuze și promit să respect regulile mai atent.
[Hungarian]
Ha hibát követtek el, őszintén elnézést kérek, és megígérem, hogy a szabályokat a jövőben gondosabban betartom.
[Czech]
Pokud jsem udělal chybu, upřímně se omlouvám a slibuji, že pravidla budu dodržovat pozorneji.
[Slovak]
Ak som urobil chybu, úprimne sa ospravedlňujem a sľubujem, že pravidlá budem dodržiavať pozornejšie.
[Bulgarian]
Ако съм допуснал грешка, искрено се извинявам и обещавам да спазвам правилата по-внимателно.
[Serbian]
Ako sam pogrešio, iskreno se izvinjavam i obećavam da ću pravila poštovati pažljivije.
[Croatian]
Ako sam pogriješio, iskreno se ispričavam i obećavam da ću pravila poštivati pažljivije.
[Slovenian]
Če sem naredil napako, iskreno prosim za odpuščanje in obljubljam, da bom pravila spoštoval skrbneje.
[Bosnian]
Ako sam pogriješio, iskreno se ispričavam i obećavam da ću pravila poštovati pažljivije.
[Macedonian]
Ако направив грешка, искрено се извинувам и ветувам дека ќе ги почитувам правилата подетално.
[Albanian]
Nëse kam bërë një gabim, kërkoj sinqerisht falje dhe premtoj t'i përmbahem rregullave më me kujdes.
[Swedish]
Tack för er tid och ert övervägande.
[Norwegian]
Takk for tiden deres og hensynet.
[Danish]
Tak for jeres tid og hensyn.
[Finnish]
Kiitos ajastanne ja huomiostanne.
[Estonian]
Aitäh teie aja ja tähelepanu eest.
[Latvian]
Paldies par jūsu laiku un uzmanību.
[Lithuanian]
Dėkoju už jūsų laiką ir dėmesį.
[Catalan]
Gràcies pel vostre temps i atenció.
[Esperanto]
Dankon pro via tempo kaj atento.

IV. WHY THIS ACCOUNT MATTERS
[English]
This account is important for my daily communication with family and work.
[Indonesian]
Akun ini penting bagi komunikasi harian saya dengan keluarga dan pekerjaan.
[Spanish]
Esta cuenta es muy importante para mi comunicación diaria con mi familia y mi trabajo.
[Hindi]
यह खाता मेरे परिवार और काम के दैनिक संपर्क के लिए बहुत महत्वपूर्ण है।
[French]
Ce compte est très important pour ma communication quotidienne avec ma famille et mon travail.
[Portuguese]
Esta conta é muito importante para minha comunicação diária com família e trabalho.
[Russian]
Этот аккаунт очень важен для моего ежедневного общения с семьёй и для работы.
[Thai]
บัญชีนี้มีความสำคัญมากต่อการติดต่อประจำวันกับครอบครัวและการทำงานของฉัน
[Vietnamese]
Tài khoản này rất quan trọng cho việc liên lạc hàng ngày của tôi với gia đình và công việc.
[Tagalog]
Mahalaga ang account na ito sa aking pang-araw-araw na komunikasyon sa pamilya at trabaho.
[Malay]
Akaun ini sangat penting untuk komunikasi harian saya dengan keluarga dan tempat kerja.
[Cantonese]
呢個帳號對我同屋企人同工作嘅日常聯絡非常重要。
[Cebuano]
Importante kaayo kini nga account alang sa akong adlaw-adlaw nga komunikasyon sa pamilya ug trabaho.

V. GOOD-FAITH DECLARATIONS
[English]
I have always tried to follow the Terms of Service, and I will continue to do so.
[Indonesian]
Saya selalu berusaha mematuhi Ketentuan Layanan dan akan terus berusaha demikian.
[Arabic]
لقد حاولت دائماً الالتزام بشروط الخدمة، وسأواصل ذلك.
[Korean]
저는 항상 서비스 약관을 준수하려고 노력해 왔습니다.
[Greek]
Έχω πάντα προσπαθήσει να τηρώ τους Όρους Χρήσης.
[Hebrew]
תמיד ניסיתי לציית לתנאי השימוש.

VI. THE REQUEST
[English]
I respectfully ask WhatsApp to review my account fairly, and if no violation is found, to restore my access.
[Indonesian]
Saya dengan hormat meminta WhatsApp meninjau akun saya secara adil, dan apabila tidak ditemukan pelanggaran, memulihkan akses saya.
[Arabic]
أرجو استعادة وصولي إذا لم يتم العثور على أي مخالفة.
[Spanish]
Por favor, restauren mi acceso si no se encuentra ninguna violación.
[Italian]
Vi prego di ripristinare il mio accesso se non viene trovata alcuna violazione.
[Dutch]
Herstel alstublieft mijn toegang als er geen overtreding wordt gevonden.
[Polish]
Proszę przywrócić mój dostęp, jeśli nie zostanie znalezione żadne naruszenie.
[Ukrainian]
Будь ласка, відновіть мій доступ, якщо порушень не виявлено.
[Greek]
Παρακαλώ επαναφέρετε την πρόσβασή μου αν δεν βρεθεί παραβίαση.
[Hebrew]
אנא שחררו את הגישה שלי אם לא נמצאה הפרה.

VII. CLOSING
[English]
Thank you for your time and consideration. I await your response respectfully.
[Indonesian]
Terima kasih atas waktu dan perhatian Anda. Saya menunggu tanggapan Anda dengan hormat.
[Arabic]
شكراً لكم على وقتكم واهتمامكم. أنتظر ردكم باحترام.
[Mandarin (Simplified)]
感谢您的时间和考虑。我恭敬地等待您的回复。
[Spanish]
Gracias por su tiempo y consideración. Espero su respuesta con respeto.
[Hindi]
आपके समय और विचार के लिए धन्यवाद। मैं आपके उत्तर का सम्मानपूर्वक इंतजार करूंगा।
[French]
Merci pour votre temps et votre attention. J'attends votre réponse avec respect.
[Portuguese]
Obrigado pelo seu tempo e consideração. Aguardo sua resposta com respeito.
[Russian]
Спасибо за ваше время и внимание. Я с уважением жду вашего ответа.
[Japanese]
お時間をいただきありがとうございます。ご回答を心よりお待ちしております。
[Korean]
시간과 관심을 가져주셔서 감사합니다. 정중하게 답변을 기다리겠습니다.
[German]
Vielen Dank für Ihre Zeit und Aufmerksamkeit. Ich warte respektvoll auf Ihre Antwort.
[Turkish]
Zamanınız ve ilginiz için teşekkür ederim. Saygılarımla yanıtınızı bekliyorum.
[Urdu]
آپ کے وقت اور توجہ کا شکریہ۔ میں احترام سے آپ کے جواب کا انتظار کروں گا۔
[Bengali]
আপনার সময় এবং বিবেচনার জন্য ধন্যবাদ। আমি সম্মানের সাথে আপনার উত্তরের অপেক্ষায় আছি।
[Persian]
از وقت و توجه شما سپاسگزارم. پاسخ شما را با احترام منتظرم.
[Cantonese]
多謝你哋嘅時間同考慮。我恭候你哋嘅回覆。
[Esperanto]
Dankon pro via tempo kaj atento. Mi atendas vian respondon kun respekto.

Respectfully submitted, / Dengan hormat,
{OWNER_NAME}
WhatsApp: {WA_NUMBER}
Sent via {APP_NAME}
Date: {DATE}

NOTICE / CATATAN
[English]
This message is a polite request only. WhatsApp makes the final decision.
[Indonesian]
Pesan ini hanya permohonan sopan. Keputusan akhir sepenuhnya ada pada WhatsApp.
''',
    languages: [
      'Indonesian',
      'English',
      'Arabic',
      'Mandarin (Simplified)',
      'Spanish',
      'Hindi',
      'French',
      'Portuguese',
      'Russian',
      'Japanese',
      'Korean',
      'German',
      'Turkish',
      'Urdu',
      'Bengali',
      'Persian',
      'Italian',
      'Dutch',
      'Polish',
      'Ukrainian',
      'Romanian',
      'Hungarian',
      'Czech',
      'Slovak',
      'Bulgarian',
      'Serbian',
      'Croatian',
      'Slovenian',
      'Bosnian',
      'Macedonian',
      'Albanian',
      'Greek',
      'Hebrew',
      'Swedish',
      'Norwegian',
      'Danish',
      'Finnish',
      'Estonian',
      'Latvian',
      'Lithuanian',
      'Catalan',
      'Thai',
      'Vietnamese',
      'Tagalog',
      'Malay',
      'Cantonese',
      'Cebuano',
      'Esperanto',
    ],
  ),
  AppealTemplate(
    id: 'v1_multilingual_request',
    name: 'V1 — MULTILINGUAL REQUEST',
    description:
        'Permohonan multibahasa yang menonjolkan keragaman bahasa pada setiap bagian surat. '
        'Setiap bahasa menyumbang kalimat santun berbeda sehingga surat terasa ramah bagi tim dukungan internasional.',
    body: r'''
Subject: Request for Account Review — WhatsApp {WA_NUMBER}
Subjek: Permohonan Tinjauan Multibahasa — WhatsApp {WA_NUMBER}

To: WhatsApp Support Team ({SUPPORT_EMAIL})

PART 1 — OPENING IN SEVERAL LANGUAGES
[Indonesian]
Akun WhatsApp saya {WA_NUMBER} telah dibatasi. Saya dengan hormat memohon tinjauan resmi terhadap akun saya.
[English]
My WhatsApp account {WA_NUMBER} has been restricted. I kindly request an official review of my account.
[Arabic]
حسابي على واتساب {WA_NUMBER} تم تقييده. أرجو مراجعة حسابي رسمياً بلطف.
[Mandarin (Simplified)]
我的 WhatsApp 账号 {WA_NUMBER} 已被限制。恳请对我的账号进行官方审查。
[Spanish]
Mi cuenta de WhatsApp {WA_NUMBER} ha sido restringida. Solicito amablemente una revisión oficial de mi cuenta.
[Hindi]
मेरा WhatsApp खाता {WA_NUMBER} प्रतिबंधित हो गया है। कृपया मेरे खाते की आधिकारिक समीक्षा करें।

PART 2 — ACCOUNT IDENTITY
[English]
Owner: {OWNER_NAME}
Number: {WA_NUMBER}
Issue type: {ISSUE_TYPE}
Date: {DATE}
[Indonesian]
Pemilik: {OWNER_NAME}
Nomor: {WA_NUMBER}
Jenis masalah: {ISSUE_TYPE}
Tanggal: {DATE}

PART 3 — VOICES FROM MANY LANGUAGES
[English]
I want to be transparent about my case: {ISSUE_DETAILS}. The sentences below are written in many languages, and each carries the same respectful message: please review my account fairly.
[Indonesian]
Saya ingin terbuka mengenai kasus saya: {ISSUE_DETAILS}. Kalimat-kalimat di bawah ditulis dalam banyak bahasa, dan masing-masing menyampaikan pesan yang sama penuh hormat: mohon tinjau akun saya secara adil.
[French]
J'ai toujours essayé de respecter les Conditions d'utilisation.
[Portuguese]
Sempre tentei cumprir os Termos de Serviço.
[Russian]
Я всегда старался соблюдать Условия использования.
[Japanese]
私は常に利用規約を守るよう努めてまいりました。
[Korean]
저는 항상 서비스 약관을 준수하려고 노력해 왔습니다.
[German]
Ich habe mich stets bemüht, die Nutzungsbedingungen einzuhalten.
[Turkish]
Hizmet Şartları'na her zaman uymaya çalıştım.
[Urdu]
میں نے ہمیشہ خدمات کی شرائط کی پابندی کی کوشش کی ہے۔
[Bengali]
আমি সবসময় সেবার শর্তাবলী মেনে চলার চেষ্টা করেছি।
[Persian]
من همیشه تلاش کرده‌ام شرایط استفاده را رعایت کنم.
[Italian]
Ho sempre cercato di rispettare i Termini di servizio.
[Dutch]
Ik heb altijd geprobeerd de Servicevoorwaarden na te leven.
[Polish]
Zawsze starałem się przestrzegać Warunków korzystania z usług.
[Ukrainian]
Я завжди намагався дотримуватися Умов надання послуг.
[Thai]
ฉันพยายามปฏิบัติตามข้อกำหนดการใช้บริการเสมอมา
[Vietnamese]
Tôi luôn cố gắng tuân thủ Điều khoản Dịch vụ.
[Tagalog]
Magalang kong hinihiling sa WhatsApp na suriin nang patas ang aking account.
[Malay]
Saya memohon dengan hormat agar WhatsApp menilai akaun saya secara adil.
[Greek]
Ζητώ με σεβασμό από το WhatsApp να εξετάσει τον λογαριασμό μου δίκαια.
[Hebrew]
אני פונה בכבוד לוואטסאפ לבחון את החשבון שלי בהוגנות.
[Swahili]
Naomba kwa heshima WhatsApp ifikirie akaunti yangu kwa usawa.
[Hausa]
Na roki WhatsApp da girmamawa a duba asusun na da adalci.
[Amharic]
WhatsApp አካውንቴን በፍትሃዊነት እንዲመረመር በአክብሮት እጠይቃለሁ።
[Zulu]
Ngicela ngokuhlonipha ukuthi i-WhatsApp ihlole i-akhawunti yami ngokulungile.
[Afrikaans]
Ek vra respekvol dat WhatsApp my rekening regverdig sal oorweeg.
[Somali]
Si naxariis leh ayaan ka codsanayaa WhatsApp inuu akoonkayga si caddaalad ah u eego.
[Yoruba]
Mo ń bẹ̀ WhatsApp pẹ̀lú ọ̀wọ́ kí ó ṣe àyẹ̀wò àkántì mi ní ọ̀nà tó dára.
[Igbo]
M na-arịọ WhatsApp n'ụzọ nsọpụrụ ka ha nyocha akaụntụ m n'ụzọ ziri ezi.
[Malagasy]
Mangataka amin'ny WhatsApp hanao fanadinana ara-drariny ny kaontiko aho.
[Cebuano]
Nagapangayo ko ug respetong surihi sa WhatsApp ang akong account sa patas nga paagi.
[Javanese]
Kula nyuwun kanthi ngajeni supados WhatsApp nliti akun kula kanthi adil.
[Sundanese]
Abdi nyuhunkeun ka WhatsApp supados nileu akun abdi sacara adil.
[Nepali]
तपाईंको समय र ध्यानका लागि धन्यवाद।
[Sinhala]
ඔබේ කාලය සහ සැලකිල්ලට ස්තූතියි.
[Tamil]
உங்கள் நேரம் மற்றும் கருத்திற்கு நன்றி.
[Telugu]
మీ సమయం మరియు పరిగణనకు ధన్యవాదాలు.
[Marathi]
आपल्या वेळेसाठी आणि विचारांसाठी धन्यवाद.
[Gujarati]
તમારા સમય અને વિચાર બદલ આભાર.
[Punjabi]
ਤੁਹਾਡੇ ਸਮੇਂ ਅਤੇ ਵਿਚਾਰ ਲਈ ਧੰਨਵਾਦ।
[Burmese]
သင့်အချိန်နှင့် စိတ်ဝင်စားမှုအတွက် ကျေးဇူးတင်ပါသည်။
[Khmer]
អរគុណចំពោះពេលវេលា និងការយកចិត្តទុកដាក់របស់អ្នក។
[Lao]
ຂອບໃຈສຳລັບເວລາ ແລະ ຄວາມສົນໃຈຂອງທ່ານ.
[Mongolian]
Таны цаг хугацаа, анхаарал халамжид баярлалаа.
[Kazakh]
Уақытыңыз бен назарыңызға рахмет.
[Uzbek]
Vaqtingiz va e'tiboringiz uchun rahmat.
[Georgian]
გმადლობთ თქვენს დროსა და ყურადღებას.

PART 4 — THE REQUEST, IN MAJOR LANGUAGES
[Indonesian]
Mohon tinjau kembali akun saya, dan apabila tidak ditemukan pelanggaran, mohon pulihkan akses saya.
[English]
Please review my account again, and if no violation is found, please restore my access.
[Arabic]
أرجو مراجعة حسابي مرة أخرى، وإن لم يوجد أي مخالفة فأرجو استعادة وصولي.
[Mandarin (Simplified)]
请再次审查我的账号，如果没有发现违规，请恢复我的访问权限。
[Spanish]
Por favor revisen mi cuenta nuevamente y, si no hay violaciones, restauren mi acceso.
[Hindi]
कृपया मेरे खाते की फिर समीक्षा करें, और यदि कोई उल्लंघन नहीं मिलता तो मेरी पहुंच बहाल करें।
[French]
Veuillez examiner à nouveau mon compte et, si aucune violation n'est constatée, rétablir mon accès.
[Portuguese]
Por favor, analisem novamente minha conta e, se nenhuma violação for encontrada, restabeleçam meu acesso.
[Russian]
Пожалуйста, рассмотрите мой аккаунт ещё раз, и если нарушений нет, восстановите мой доступ.
[Japanese]
もう一度私のアカウントを審査いただき、違反が見つからない場合はアクセスの回復をお願いいたします。
[Korean]
제 계정을 다시 검토해 주시고, 위반이 없다면 접근 권한을 복구해 주시기 바랍니다.

PART 5 — THANKS AND SIGN-OFF
[English]
Thank you very much for your time and consideration.
[Indonesian]
Terima kasih banyak atas waktu dan perhatian yang diberikan.
[German]
Vielen Dank für Ihre Zeit und Aufmerksamkeit.
[Turkish]
Zamanınız ve ilginiz için teşekkür ederim.
[Urdu]
آپ کے وقت اور توجہ کا شکریہ۔
[Bengali]
আপনার সময় এবং বিবেচনার জন্য ধন্যবাদ।
[Persian]
از وقت و توجه شما سپاسگزارم.
[Italian]
Grazie mille per il tempo e la considerazione.
[Dutch]
Hartelijk bedankt voor uw tijd en aandacht.
[Polish]
Dziękuję bardzo za poświęcony czas i uwagę.
[Ukrainian]
Щиро дякую за ваш час і увагу.
[Japanese]
ご検討のほど、よろしくお願いいたします。
[Korean]
검토해 주셔서 감사합니다.

Respectfully, / Hormat saya,
{OWNER_NAME}
WhatsApp: {WA_NUMBER}
Sent via {APP_NAME}
Date: {DATE}

[English]
This message is a polite request only. WhatsApp makes the final decision.
[Indonesian]
Pesan ini hanya permohonan sopan. Keputusan akhir sepenuhnya ada pada WhatsApp.
''',
    languages: [
      'Indonesian',
      'English',
      'Arabic',
      'Mandarin (Simplified)',
      'Spanish',
      'Hindi',
      'French',
      'Portuguese',
      'Russian',
      'Japanese',
      'Korean',
      'German',
      'Turkish',
      'Urdu',
      'Bengali',
      'Persian',
      'Italian',
      'Dutch',
      'Polish',
      'Ukrainian',
      'Thai',
      'Vietnamese',
      'Tagalog',
      'Malay',
      'Greek',
      'Hebrew',
      'Swahili',
      'Hausa',
      'Amharic',
      'Zulu',
      'Afrikaans',
      'Somali',
      'Yoruba',
      'Igbo',
      'Malagasy',
      'Cebuano',
      'Javanese',
      'Sundanese',
      'Nepali',
      'Sinhala',
      'Tamil',
      'Telugu',
      'Marathi',
      'Gujarati',
      'Punjabi',
      'Burmese',
      'Khmer',
      'Lao',
      'Mongolian',
      'Kazakh',
      'Uzbek',
      'Georgian',
    ],
  ),
  AppealTemplate(
    id: 'v1_account_recovery_request',
    name: 'V1 — ACCOUNT RECOVERY REQUEST',
    description:
        'Permintaan pemulihan akses yang berfokus pada penjelasan kondisi akun dan harapan agar akses dibuka kembali. '
        'Disusun sopan dengan blok data akun dan janji kepatuhan yang jelas.',
    body: r'''
Subject: Request for Account Review — WhatsApp {WA_NUMBER}
Subjek: Permohonan Pemulihan Akses Akun — WhatsApp {WA_NUMBER}

To: WhatsApp Support Team ({SUPPORT_EMAIL})

BRIEF OPENING
[Indonesian]
Saya {OWNER_NAME}, memohon dengan hormat agar akses akun WhatsApp saya {WA_NUMBER} dapat ditinjau dan dipulihkan.
[English]
I am {OWNER_NAME}, and I respectfully ask that access to my WhatsApp account {WA_NUMBER} be reviewed and restored.
[Arabic]
أنا {OWNER_NAME}، وأطلب باحترام أن تتم مراجعة الوصول إلى حسابي في واتساب {WA_NUMBER} واستعادته.
[Mandarin (Simplified)]
我是 {OWNER_NAME}，恳请审查并恢复我的 WhatsApp 账号 {WA_NUMBER} 的访问权限。
[Spanish]
Soy {OWNER_NAME} y pido respetuosamente que se revise y restaure el acceso a mi cuenta de WhatsApp {WA_NUMBER}.

MY ACCOUNT DETAILS
[English]
Owner: {OWNER_NAME}
Number: {WA_NUMBER}
Issue type: {ISSUE_TYPE}
Date: {DATE}
[Indonesian]
Pemilik: {OWNER_NAME}
Nomor: {WA_NUMBER}
Jenis masalah: {ISSUE_TYPE}
Tanggal: {DATE}

WHAT HAPPENED
[English]
Honestly, here is what happened: {ISSUE_DETAILS}. I do not hide anything and I accept whatever the verification shows.
[Indonesian]
Dengan jujur, berikut kejadiannya: {ISSUE_DETAILS}. Saya tidak menyembunyikan apa pun dan saya menerima hasil verifikasi yang benar.

RECOVERY REQUEST IN MANY LANGUAGES
[Hindi]
मैं विनम्रता से निवेदन करता हूँ कि मेरे खाते की निष्पक्ष समीक्षा की जाए।
[French]
Je demande poliment à WhatsApp d'examiner mon compte de manière équitable.
[Portuguese]
Peço respeitosamente ao WhatsApp que analise minha conta de forma justa.
[Russian]
Я уважительно прошу WhatsApp справедливо рассмотреть мой аккаунт.
[Japanese]
WhatsAppに公平にアカウントを審査していただきたく、お願い申し上げます。
[Korean]
WhatsApp에 제 계정을 공정하게 검토해 주시기를 정중히 부탁드립니다.
[German]
Ich bitte WhatsApp respektvoll, mein Konto fair zu prüfen.
[Turkish]
WhatsApp'tan hesabımı adil bir şekilde incelemesini saygıyla rica ediyorum.
[Urdu]
میں WhatsApp سے احترام کے ساتھ درخواست کرتا ہوں کہ میرے اکاؤنٹ کا منصفانہ جائزہ لیا جائے۔
[Bengali]
আমি WhatsApp-কে সম্মানের সাথে অনুরোধ করছি যে আমার অ্যাকাউন্ট ন্যায্যভাবে পর্যালোচনা করুন।
[Persian]
با احترام از واتساپ درخواست می‌کنم که حسابم را عادلانه بررسی کند.
[Italian]
Chiedo rispettosamente a WhatsApp di esaminare il mio account in modo equo.
[Dutch]
Ik verzoek WhatsApp respectvol om mijn account eerlijk te beoordelen.
[Polish]
Z szacunkiem proszę WhatsApp o uczciwe rozpatrzenie mojego konta.
[Ukrainian]
Я з повагою прошу WhatsApp справедливо розглянути мій акаунт.
[Romanian]
Rog respectuos ca WhatsApp să analizeze contul meu în mod echitabil.
[Hungarian]
Tisztelettel kérem a WhatsApp-ot, hogy vizsgálja felül a fiókomat méltányosan.
[Czech]
S respektem prosím WhatsApp, aby můj účet posoudil spravedlivě.
[Slovak]
S úctou prosím WhatsApp, aby posúdil môj účet spravodlivo.
[Serbian]
Uvaženo molim WhatsApp da moj nalog ispita pravedno.
[Croatian]
Uvaženo molim WhatsApp da moj račun pregleda pravedno.
[Greek]
Ζητώ με σεβασμό από το WhatsApp να εξετάσει τον λογαριασμό μου δίκαια.
[Hebrew]
אני פונה בכבוד לוואטסאפ לבחון את החשבון שלי בהוגנות.
[Swedish]
Jag ber respektfullt WhatsApp att granska mitt konto på ett rättvist sätt.
[Norwegian]
Jeg ber respektfullt WhatsApp om å vurdere kontoen min på en rettferdig måte.
[Danish]
Jeg beder respektfuldt WhatsApp om at vurdere min konto retfærdigt.
[Finnish]
Pyydän kunnioittavasti WhatsAppia tarkastelemaan tilini oikeudenmukaisesti.
[Estonian]
Palun austavalt, et WhatsApp hindaks mu kontot õiglaselt.
[Latvian]
Ar cieņu lūdzu WhatsApp godīgi izvērtēt manu kontu.
[Lithuanian]
Pagarbiai prašau WhatsApp sąžiningai peržiūrėti mano paskyrą.
[Albanian]
Kërkoj me nderim nga WhatsApp që të shqyrtojë llogarinë time në mënyrë të drejtë.
[Thai]
ขอความกรุณา WhatsApp พิจารณาบัญชีของฉันอย่างเป็นธรรมด้วยความเคารพ
[Vietnamese]
Tôi trân trọng đề nghị WhatsApp xem xét tài khoản của tôi một cách công bằng.
[Tagalog]
Magalang kong hinihiling sa WhatsApp na suriin nang patas ang aking account.
[Malay]
Saya memohon dengan hormat agar WhatsApp menilai akaun saya secara adil.
[Tamil]
எனது கணக்கை நியாயமாக மறுஆய்வு செய்யுமாறு WhatsApp-ஐ மரியாதையுடன் கேட்கிறேன்.
[Telugu]
నా ఖాతాను న్యాయంగా సమీక్షించాలని WhatsApp ను గౌరవపూర్వకంగా కోరుతున్నాను.
[Nepali]
म मर्यादापूर्वक अनुरोध गर्दछु कि WhatsApp मेरो खाताको निष्पक्ष समीक्षा गरोस्।
[Sinhala]
මගේ ගිණුම සාධාරණව සමාලෝචනය කරන ලෙස WhatsApp ට ආචාරශීලීව ඉල්ලා සිටිමි.
[Kazakh]
WhatsApp-тан аккаунтымды әділ қарауын сыйластықпен сұраймын.
[Azerbaijani]
WhatsApp-dan hesabımı ədalətli şəkildə araşdırmasını hörmətlə xahiş edirəm.
[Armenian]
Հարգանքով խնդրում եմ WhatsApp-ին իմ հաշիվը արդարացի վերանայել:

READY TO COOPERATE
[Indonesian]
Jika ada pertanyaan, saya siap menjawab melalui kontak yang tercantum pada surat ini.
[English]
I am ready to provide any additional information needed for the verification.
[French]
Je suis prêt à fournir toute information supplémentaire nécessaire.
[Spanish]
Estoy listo para proporcionar cualquier información adicional necesaria.
[Hindi]
मैं कोई भी अतिरिक्त जानकारी देने के लिए तैयार हूँ।
[Japanese]
必要な追加情報があれば、喜んでご提供いたします。
[Korean]
필요한 추가 정보를 기꺼이 제공하겠습니다.
[German]
Ich stelle gerne alle zusätzlichen Informationen bereit, die benötigt werden.
[Arabic]
أنا مستعد لتقديم أي معلومات إضافية مطلوبة.
[Portuguese]
Estou pronto para fornecer qualquer informação adicional necessária.
[Russian]
Я готов предоставить любую дополнительную информацию.
[Italian]
Sono pronto a fornire qualsiasi informazione aggiuntiva necessaria.
[Turkish]
Gereken ek bilgileri sağlamaya hazırım.
[Urdu]
میں کوئی بھی اضافی معلومات فراہم کرنے کے لیے تیار ہوں۔
[Bengali]
প্রয়োজনীয় যেকোনো অতিরিক্ত তথ্য দিতে আমি প্রস্তুত।
[Persian]
آماده هستم هر اطلاعات اضافی مورد نیاز را ارائه دهم.
[Dutch]
Ik ben bereid alle benodigde aanvullende informatie te verstrekken.
[Polish]
Jestem gotów dostarczyć wszelkie potrzebne dodatkowe informacje.
[Ukrainian]
Я готовий надати будь-яку додаткову інформацію.

MY COMMITMENTS
[Indonesian]
Saya berjanji mematuhi semua kebijakan WhatsApp dan menjaga akun saya dengan baik.
[English]
I promise to comply with all WhatsApp policies and to keep my account in good standing.
[Hindi]
मैं WhatsApp की सभी नीतियों का पालन करने का वादा करता हूँ।
[French]
Je m'engage à respecter toutes les politiques de WhatsApp.
[Russian]
Я обещаю соблюдать все политики WhatsApp.

FINAL WORDS
[English]
Thank you for your time and consideration. I await your response respectfully.
[Indonesian]
Terima kasih atas waktu dan perhatian Anda. Saya menunggu tanggapan Anda dengan hormat.
[Japanese]
お時間をいただき、ありがとうございます。ご回答を心よりお待ちしております。
[Korean]
시간과 관심을 가져주셔서 감사합니다. 정중하게 답변을 기다리겠습니다.

Respectfully, / Hormat saya,
{OWNER_NAME}
WhatsApp: {WA_NUMBER}
Sent via {APP_NAME}
Date: {DATE}

FOOTNOTE / CATATAN KAKI
[English]
This message is a polite request only. WhatsApp makes the final decision.
[Indonesian]
Pesan ini hanya permohonan sopan. Keputusan akhir sepenuhnya ada pada WhatsApp.
''',
    languages: [
      'Indonesian',
      'English',
      'Arabic',
      'Mandarin (Simplified)',
      'Spanish',
      'Hindi',
      'French',
      'Portuguese',
      'Russian',
      'Japanese',
      'Korean',
      'German',
      'Turkish',
      'Urdu',
      'Bengali',
      'Persian',
      'Italian',
      'Dutch',
      'Polish',
      'Ukrainian',
      'Romanian',
      'Hungarian',
      'Czech',
      'Slovak',
      'Serbian',
      'Croatian',
      'Greek',
      'Hebrew',
      'Swedish',
      'Norwegian',
      'Danish',
      'Finnish',
      'Estonian',
      'Latvian',
      'Lithuanian',
      'Albanian',
      'Thai',
      'Vietnamese',
      'Tagalog',
      'Malay',
      'Tamil',
      'Telugu',
      'Nepali',
      'Sinhala',
      'Kazakh',
      'Azerbaijani',
      'Armenian',
    ],
  ),
  AppealTemplate(
    id: 'v1_priority_review_request',
    name: 'V1 — PRIORITY REVIEW REQUEST',
    description:
        'Permintaan tinjauan prioritas dengan struktur ringkas namun tetap santun. '
        'Menekankan harapan agar kasus dapat ditinjau lebih cepat tanpa menuntut hasil tertentu.',
    body: r'''
Subject: Request for Account Review — WhatsApp {WA_NUMBER}
Subjek: Permohonan Tinjauan Prioritas — WhatsApp {WA_NUMBER}

To: WhatsApp Support Team ({SUPPORT_EMAIL})

WHY THIS LETTER IS SENT (POLITE AND PATIENT)
[English]
My WhatsApp account {WA_NUMBER} was restricted on {DATE}. I am not demanding anything; I am only asking, politely, for a priority review because this account supports my daily communication.
[Indonesian]
Akun WhatsApp saya {WA_NUMBER} dibatasi pada {DATE}. Saya tidak menuntut apa pun; saya hanya memohon dengan santun agar tinjauan dapat dilakukan lebih awal karena akun ini menopang komunikasi harian saya.
[English]
For transparency: {ISSUE_DETAILS}. I trust the team will verify everything properly.

ACCOUNT FACTS
[English]
Owner: {OWNER_NAME} — Number: {WA_NUMBER} — Issue type: {ISSUE_TYPE} — Date: {DATE}
[Indonesian]
Pemilik: {OWNER_NAME} — Nomor: {WA_NUMBER} — Jenis masalah: {ISSUE_TYPE} — Tanggal: {DATE}

OPENING VOICES (MULTILINGUAL)
[Arabic]
حسابي على واتساب {WA_NUMBER} تم تقييده. أرجو مراجعة حسابي رسمياً.
[Mandarin (Simplified)]
我的 WhatsApp 账号 {WA_NUMBER} 已被限制使用。我恳请官方对我的账号进行审查。
[Spanish]
Mi cuenta de WhatsApp {WA_NUMBER} ha sido restringida. Solicito amablemente una revisión oficial de mi cuenta.
[Hindi]
मेरा WhatsApp खाता {WA_NUMBER} प्रतिबंधित कर दिया गया है। कृपया मेरे खाते की आधिकारिक समीक्षा करें।
[French]
Mon compte WhatsApp {WA_NUMBER} a été restreint. Je demande respectueusement un examen officiel de mon compte.
[Portuguese]
Minha conta do WhatsApp {WA_NUMBER} foi restringida. Peço gentilmente uma revisão oficial da minha conta.
[Russian]
Мой аккаунт WhatsApp {WA_NUMBER} был ограничен. Я вежливо прошу провести официальную проверку моего аккаунта.
[Japanese]
私のWhatsAppアカウント（{WA_NUMBER}）は制限されました。公式な再審査をお願いいたします。
[Korean]
제 WhatsApp 계정({WA_NUMBER})이 제한되었습니다. 공식적인 재검토를 정중히 요청드립니다.

POLITE PRIORITY REQUEST (IN MANY LANGUAGES)
[Indonesian]
Jika memungkinkan, saya berharap kasus saya dapat ditinjau lebih awal dengan tetap mengikuti antrean dan prosedur resmi.
[English]
If possible, I hope my case can be reviewed sooner, while fully respecting the official queue and procedures.
[German]
Dieses Konto ist sehr wichtig für meine tägliche Kommunikation mit Familie und Arbeit.
[Turkish]
Bu hesap, ailem ve işimle günlük iletişimim için çok önemli.
[Urdu]
یہ اکاؤنٹ میرے خاندان اور کام سے روزمرہ رابطے کے لیے بہت اہم ہے۔
[Bengali]
এই অ্যাকাউন্টটি আমার পরিবার এবং কাজের দৈনন্দিন যোগাযোগের জন্য খুবই গুরুত্বপূর্ণ।
[Persian]
این حساب برای ارتباط روزانه من با خانواده و کارم بسیار مهم است.
[Italian]
Questo account è molto importante per la mia comunicazione quotidiana con la famiglia e il lavoro.
[Dutch]
Dit account is erg belangrijk voor mijn dagelijkse communicatie met familie en werk.
[Polish]
To konto jest bardzo ważne dla mojej codziennej komunikacji z rodziną i w pracy.
[Ukrainian]
Цей акаунт дуже важливий для мого щоденного спілкування з родиною та для роботи.
[Thai]
บัญชีนี้มีความสำคัญมากต่อการติดต่อประจำวันกับครอบครัวและการทำงานของฉัน
[Vietnamese]
Tài khoản này rất quan trọng cho việc liên lạc hàng ngày của tôi với gia đình và công việc.
[Tagalog]
Mahalaga ang account na ito sa aking pang-araw-araw na komunikasyon sa pamilya at trabaho.
[Malay]
Akaun ini sangat penting untuk komunikasi harian saya dengan keluarga dan tempat kerja.
[Greek]
Αυτός ο λογαριασμός είναι πολύ σημαντικός για την καθημερινή επικοινωνία μου με την οικογένεια και την εργασία.
[Hebrew]
החשבון הזה חשוב מאוד לתקשורת היומיומית שלי עם המשפחה והעבודה.
[Swahili]
Akaunti hii ni muhimu sana kwa mawasiliano yangu ya kila siku na familia na kazi.
[Hausa]
Wannan asusun yana da matuƙar muhimmanci ga sadarwar yau da kullum da iyali da aiki.
[Amharic]
ይህ አካውንት ከቤተሰብና ከሥራ ጋር ያለውን የዕለት ተዕለት ግንኙነቴ በጣም ያስፈልገኛል።
[Somali]
Akoonkan waa muhiim yahay xiriirka maalinlaha ah ee qoyskayga iyo shaqada.
[Afrikaans]
Hierdie rekening is baie belangrik vir my daaglikse kommunikasie met familie en werk.
[Zulu]
Le akhawunti ibalulekile kakhulu ekuxoxisaneni kwami kwansuku zonke nomndeni nangomsebenzi.
[Nepali]
यो खाता मेरो परिवार र कामसँगको दैनिक सम्पर्कका लागि निकै महत्त्वपूर्ण छ।
[Sinhala]
මෙම ගිණුම මගේ පවුල සහ රැකියාව සමඟ දෛනික සන්නිවේදනයට ඉතා වැදගත් වේ.
[Tamil]
இந்த கணக்கு எனது குடும்பம் மற்றும் பணியுடனான தினசரி தொடர்புக்கு மிகவும் முக்கியமானது.
[Burmese]
ဤအကောင့်သည် မိသားစုနှင့် အလုပ်နှင့် နေ့စဉ်ဆက်သွယ်ရန် အလွန်အရေးကြီးပါသည်။
[Khmer]
គណនីនេះសំខាន់ណាស់សម្រាប់ទំនាក់ទំនងប្រចាំថ្ងៃរបស់ខ្ញុំជាមួយគ្រួសារនិងការងារ។
[Lao]
ບັນຊີນີ້ສຳຄັນຫຼາຍສຳລັບການຕິດຕໍ່ປະຈຳວັນຂອງຂ້ອຍກັບຄອບຄົວ ແລະ ວຽກ.
[Mongolian]
Энэ данс нь гэр бүл, ажилтай өдөр тутмын харилцаанд маш чухал ач холбогдолтой.
[Uzbek]
Bu akkaunt oilam va ishim bilan kundalik aloqam uchun juda muhim.
[Kazakh]
Бұл аккаунт отбасыммен және жұмысыммен күнделікті байланысым үшін өте маңызды.
[Azerbaijani]
Bu hesab ailəm və işimlə gündəlik ünsiyyətim üçün çox vacibdir.
[Georgian]
ეს ანგარიში ძალიან მნიშვნელოვანია ოჯახთან და საქმესთან ყოველდღიური კავშირისთვის.
[Armenian]
Այս հաշիվը շատ կարևոր է ընտանիքի և աշխատանքի հետ իմ ամենօրյա կապի համար:
[Romanian]
Acest cont este foarte important pentru comunicarea mea zilnică cu familia și munca.
[Hungarian]
Ez a fiók nagyon fontos a családommal és a munkámmal való napi kapcsolattartásomhoz.
[Czech]
Tento účet je pro mou každodenní komunikaci s rodinou a prací velmi důležitý.
[Esperanto]
Ĉi tiu konto estas tre grava por mia ĉiutaga komunikado kun familio kaj laboro.
[Cantonese]
呢個帳號對我同屋企人同工作嘅日常聯絡非常重要。
[Cebuano]
Importante kaayo kini nga account alang sa akong adlaw-adlaw nga komunikasyon sa pamilya ug trabaho.
[Hausa]
Na gode da lokacinku.
[Amharic]
ስለሰጡኝ ጊዜና ትኩረት አመሰግናለሁ።
[Swahili]
Asante kwa muda wenu.
[Zulu]
Ngiyabonga ngesikhathi sakho.
[Somali]
Mahadsantihiin waqtigiinna.
[Khmer]
អរគុណសម្រាប់ពេលវេលារបស់អ្នក។
[Lao]
ຂອບໃຈຫຼາຍໆ.
[Burmese]
ကျေးဇူးတင်ပါသည်။
[Mongolian]
Баярлалаа.
[Esperanto]
Dankon tre multe.

PROMISE OF COMPLIANCE
[Indonesian]
Saya berjanji akan mematuhi seluruh kebijakan WhatsApp.
[English]
I promise to comply with all WhatsApp policies.
[German]
Ich verspreche, alle WhatsApp-Richtlinien einzuhalten.
[Italian]
Mi impegno a rispettare tutte le politiche di WhatsApp.
[Portuguese]
Prometo cumprir todas as políticas do WhatsApp.

THANK YOU
[English]
Thank you very much for your time and consideration.
[Indonesian]
Terima kasih banyak atas waktu dan perhatian Anda.
[Arabic]
شكراً جزيلاً لكم على وقتكم واهتمامكم.
[Spanish]
Muchas gracias por su tiempo y consideración.
[Hindi]
आपके समय और विचार के लिए बहुत धन्यवाद।
[French]
Merci beaucoup pour votre temps et votre attention.
[Japanese]
誠にありがとうございます。
[Korean]
진심으로 감사합니다.

Respectfully, / Hormat saya,
{OWNER_NAME}
WhatsApp: {WA_NUMBER}
Sent via {APP_NAME}
Date: {DATE}

FINAL NOTE / CATATAN AKHIR
[English]
This message is a polite request only. WhatsApp makes the final decision.
[Indonesian]
Pesan ini hanya permohonan sopan. Keputusan akhir sepenuhnya ada pada WhatsApp.
''',
    languages: [
      'Indonesian',
      'English',
      'Arabic',
      'Mandarin (Simplified)',
      'Spanish',
      'Hindi',
      'French',
      'Portuguese',
      'Russian',
      'Japanese',
      'Korean',
      'German',
      'Turkish',
      'Urdu',
      'Bengali',
      'Persian',
      'Italian',
      'Dutch',
      'Polish',
      'Ukrainian',
      'Thai',
      'Vietnamese',
      'Tagalog',
      'Malay',
      'Greek',
      'Hebrew',
      'Swahili',
      'Hausa',
      'Amharic',
      'Somali',
      'Afrikaans',
      'Zulu',
      'Nepali',
      'Sinhala',
      'Tamil',
      'Burmese',
      'Khmer',
      'Lao',
      'Mongolian',
      'Uzbek',
      'Kazakh',
      'Azerbaijani',
      'Georgian',
      'Armenian',
      'Romanian',
      'Hungarian',
      'Czech',
      'Esperanto',
      'Cantonese',
      'Cebuano',
    ],
  ),
];
