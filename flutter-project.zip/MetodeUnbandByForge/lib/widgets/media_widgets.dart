/// MetodeUnbandByForge — Widget media: video background, resolver gambar,
/// carousel otomatis dengan efek zoom.
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import '../services/platform_media.dart';
import '../theme/app_theme.dart';

// ---------------------------------------------------------------------------
// Video background fullscreen (BoxFit.cover) dengan fallback aman
// ---------------------------------------------------------------------------
class VideoBackground extends StatefulWidget {
  /// Path asset (assets/...) atau path file lokal.
  final String? assetPath;

  /// Controller yang sudah di-pra-inisialisasi (opsional).
  final VideoPlayerController? controller;

  final Widget? overlayChild;

  const VideoBackground({
    super.key,
    this.assetPath,
    this.controller,
    this.overlayChild,
  });

  @override
  State<VideoBackground> createState() => _VideoBackgroundState();
}

class _VideoBackgroundState extends State<VideoBackground> {
  VideoPlayerController? _c;
  bool _external = false;
  bool _ready = false;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    if (widget.controller != null) {
      _c = widget.controller;
      _external = true;
      _ready = _c!.value.isInitialized;
      _play();
    } else if (widget.assetPath != null) {
      _initFromAsset();
    } else {
      _failed = true;
    }
  }

  Future<void> _initFromAsset() async {
    try {
      final controller = videoControllerFor(widget.assetPath!);
      if (controller == null) {
        if (mounted) setState(() => _failed = true);
        return;
      }
      await controller.initialize();
      if (!mounted) {
        await controller.dispose();
        return;
      }
      setState(() {
        _c = controller;
        _ready = true;
      });
      _play();
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
  }

  Future<void> _play() async {
    try {
      await _c?.setLooping(true);
      await _c?.play();
    } catch (_) {}
  }

  @override
  void dispose() {
    if (!_external) {
      try {
        _c?.dispose();
      } catch (_) {}
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        if (_ready && _c != null)
          FittedBox(
            fit: BoxFit.cover,
            child: SizedBox(
              width: _c!.value.size.width == 0
                  ? 1280
                  : _c!.value.size.width,
              height: _c!.value.size.height == 0 ? 720 : _c!.value.size.height,
              child: VideoPlayer(_c!),
            ),
          )
        else
          _FallbackGradient(
            showHint: _failed,
          ),
        if (widget.overlayChild != null)
          Positioned.fill(child: widget.overlayChild!),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Fallback gradien animasi bila video tidak tersedia/gagal
// ---------------------------------------------------------------------------
class _FallbackGradient extends StatefulWidget {
  final bool showHint;

  const _FallbackGradient({required this.showHint});

  @override
  State<_FallbackGradient> createState() => _FallbackGradientState();
}

class _FallbackGradientState extends State<_FallbackGradient>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 2600),
  )..repeat(reverse: true);

  static const _begin = Alignment(-1, -1);
  static const _end = Alignment(1, 1);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final alignment = Alignment.lerp(_begin, _end, _c.value)!;
        return Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: alignment,
              end: -alignment,
              colors: const [
                kForgeBg,
                Color(0xFF1A1700),
                Color(0xFF241F00),
                kForgeBg,
              ],
            ),
          ),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'FORGE',
                  style: TextStyle(
                    color: kForgeYellow.withOpacity(0.85),
                    fontSize: 46,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 6,
                    shadows: [
                      Shadow(
                        color: kForgeYellow.withOpacity(0.4),
                        blurRadius: 24,
                      ),
                    ],
                  ),
                ),
                if (widget.showHint)
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Text(
                      'Media tidak tersedia — mode fallback aktif',
                      style: TextStyle(
                        color: kForgeGray.withOpacity(0.8),
                        fontSize: 11,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ---------------------------------------------------------------------------
// Resolver gambar: asset / data URL / file lokal — dengan fallback
// ---------------------------------------------------------------------------
class MediaResolverImage extends StatelessWidget {
  final String ref;
  final BoxFit fit;
  final double? width;
  final double? height;
  final BorderRadius? borderRadius;

  const MediaResolverImage({
    super.key,
    required this.ref,
    this.fit = BoxFit.cover,
    this.width,
    this.height,
    this.borderRadius,
  });

  @override
  Widget build(BuildContext context) {
    final provider = imageProviderFor(ref);
    Widget child;
    if (provider == null) {
      child = const _MediaFallback();
    } else {
      child = Image(
        image: provider,
        fit: fit,
        width: width,
        height: height,
        errorBuilder: (_, __, ___) => const _MediaFallback(),
      );
    }
    if (borderRadius != null) {
      return ClipRRect(borderRadius: borderRadius!, child: child);
    }
    return child;
  }
}

class _MediaFallback extends StatelessWidget {
  const _MediaFallback();

  @override
  Widget build(BuildContext context) {
    return Container(
      color: kForgeSurface,
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.image_outlined, color: Color(0xFF555555)),
            const SizedBox(height: 6),
            Text(
              'MEDIA',
              style: TextStyle(
                color: kForgeGray.withOpacity(0.8),
                fontSize: 9,
                letterSpacing: 2,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Carousel otomatis infinite dengan indikator titik + efek zoom
// ---------------------------------------------------------------------------
class AutoCarousel extends StatefulWidget {
  final List<String> images;
  final double aspect;

  const AutoCarousel({super.key, required this.images, this.aspect = 16 / 10});

  @override
  State<AutoCarousel> createState() => _AutoCarouselState();
}

class _AutoCarouselState extends State<AutoCarousel> {
  late final PageController _pc;
  Timer? _timer;
  double _page = 0;

  static const _bigOffset = 900;

  @override
  void initState() {
    super.initState();
    _pc = PageController(
      viewportFraction: 0.9,
      initialPage: _bigOffset,
    );
    _page = _bigOffset.toDouble();
    _pc.addListener(() {
      final p = _pc.page;
      if (p != null && p != _page && mounted) {
        setState(() => _page = p);
      }
    });
    _startTimer();
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(milliseconds: 4200), (_) {
      if (!mounted || !_pc.hasClients) return;
      _pc.nextPage(
        duration: const Duration(milliseconds: 480),
        curve: Curves.easeInOutCubic,
      );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final images = widget.images;
    if (images.isEmpty) {
      return AspectRatio(
        aspectRatio: widget.aspect,
        child: Container(
          decoration: BoxDecoration(
            color: kForgeSurface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: kForgeBorder),
          ),
          child: const Center(
            child: Text(
              'Belum ada foto carousel.\nAtur di Admin Panel > Media.',
              textAlign: TextAlign.center,
              style: TextStyle(color: kForgeGray, fontSize: 12),
            ),
          ),
        ),
      );
    }

    final n = images.length;

    return Column(
      children: [
        AspectRatio(
          aspectRatio: widget.aspect,
          child: PageView.builder(
            controller: _pc,
            itemCount: null,
            itemBuilder: (context, index) {
              final img = images[((index % n) + n) % n];
              final diff = (_page - index).abs().clamp(0.0, 1.0);
              final scale = 1.0 - diff * 0.06;
              return Transform.scale(
                scale: scale,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      MediaResolverImage(
                        ref: img,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      Positioned.fill(
                        child: IgnorePointer(
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              gradient: const LinearGradient(
                                begin: Alignment.bottomCenter,
                                end: Alignment.center,
                                colors: [
                                  Colors.black54,
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        left: 14,
                        bottom: 12,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: kForgeBg.withOpacity(0.65),
                            borderRadius: BorderRadius.circular(99),
                            border: Border.all(
                              color: kForgeYellow.withOpacity(0.6),
                            ),
                          ),
                          child: Text(
                            'FORGE  ${(index % n) + 1} / $n',
                            style: const TextStyle(
                              color: kForgeYellow,
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(n, (i) {
            final idx = (((_page.round() % n) + n) % n);
            final active = idx == i;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 260),
              width: active ? 20 : 7,
              height: 7,
              margin: const EdgeInsets.symmetric(horizontal: 3),
              decoration: BoxDecoration(
                color: active ? kForgeYellow : kForgeBorder,
                borderRadius: BorderRadius.circular(99),
                boxShadow: active
                    ? [
                        BoxShadow(
                          color: kForgeYellow.withOpacity(0.45),
                          blurRadius: 6,
                        ),
                      ]
                    : null,
              ),
            );
          }),
        ),
      ],
    );
  }
}
