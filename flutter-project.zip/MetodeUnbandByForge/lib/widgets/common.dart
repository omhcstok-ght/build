/// MetodeUnbandByForge — Komponen UI bersama.
/// Developer: FORGE
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/models.dart';
import '../theme/app_theme.dart';

// ---------------------------------------------------------------------------
// Logo
// ---------------------------------------------------------------------------
class ForgeLogo extends StatelessWidget {
  final double size;
  final bool glow;

  const ForgeLogo({super.key, this.size = 44, this.glow = true});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: kForgeSurface,
        borderRadius: BorderRadius.circular(size * 0.22),
        border: Border.all(color: kForgeYellow, width: 2),
        boxShadow: glow
            ? [
                BoxShadow(
                  color: kForgeYellow.withOpacity(0.35),
                  blurRadius: 14,
                  spreadRadius: 1,
                ),
              ]
            : null,
      ),
      child: Center(
        child: Text(
          'FORGE',
          style: TextStyle(
            color: kForgeYellow,
            fontWeight: FontWeight.w900,
            fontSize: size * 0.21,
            letterSpacing: size * 0.01,
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Garis dekorasi kuning ber-glow
// ---------------------------------------------------------------------------
class YellowGlowLine extends StatelessWidget {
  final double? width;

  const YellowGlowLine({super.key, this.width});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: 2,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(2),
        gradient: const LinearGradient(
          colors: [
            Colors.transparent,
            kForgeYellow,
            Colors.transparent,
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: kForgeYellow.withOpacity(0.5),
            blurRadius: 8,
            spreadRadius: 0.5,
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Header seksi
// ---------------------------------------------------------------------------
class SectionHeader extends StatelessWidget {
  final String title;
  final String? subtitle;

  const SectionHeader({super.key, required this.title, this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 4,
              height: 18,
              decoration: BoxDecoration(
                color: kForgeYellow,
                borderRadius: BorderRadius.circular(2),
                boxShadow: [
                  BoxShadow(
                    color: kForgeYellow.withOpacity(0.5),
                    blurRadius: 6,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  color: kForgeWhite,
                  fontWeight: FontWeight.w800,
                  fontSize: 16,
                  letterSpacing: 0.5,
                ),
              ),
            ),
          ],
        ),
        if (subtitle != null) ...[
          const SizedBox(height: 6),
          Text(
            subtitle!,
            style: const TextStyle(color: kForgeGray, fontSize: 12.5, height: 1.4),
          ),
        ],
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Tombol dengan efek glow + animasi tekan
// ---------------------------------------------------------------------------
class GlowingButton extends StatefulWidget {
  final String label;
  final VoidCallback? onTap;
  final IconData? icon;
  final bool outline;
  final bool small;
  final bool expand;
  final bool danger;

  const GlowingButton({
    super.key,
    required this.label,
    this.onTap,
    this.icon,
    this.outline = false,
    this.small = false,
    this.expand = false,
    this.danger = false,
  });

  @override
  State<GlowingButton> createState() => _GlowingButtonState();
}

class _GlowingButtonState extends State<GlowingButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onTap != null;
    final accent = widget.danger ? const Color(0xFFFF5252) : kForgeYellow;

    Widget content = Row(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (widget.icon != null) ...[
          Icon(widget.icon,
              size: widget.small ? 14 : 17,
              color: widget.outline ? accent : kForgeBg),
          SizedBox(width: widget.small ? 6 : 8),
        ],
        Flexible(
          child: Text(
            widget.label,
            textAlign: TextAlign.center,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: widget.outline ? accent : kForgeBg,
              fontWeight: FontWeight.w800,
              fontSize: widget.small ? 12 : 14,
              letterSpacing: 1.0,
            ),
          ),
        ),
      ],
    );

    Decoration decoration;
    if (widget.outline || !enabled) {
      decoration = BoxDecoration(
        color: enabled ? Colors.transparent : kForgeSurface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: enabled ? accent : kForgeBorder),
      );
    } else {
      decoration = BoxDecoration(
        color: accent,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: accent.withOpacity(_pressed ? 0.25 : 0.45),
            blurRadius: _pressed ? 6 : 16,
            spreadRadius: _pressed ? 0 : 1,
          ),
        ],
      );
    }

    return Listener(
      onPointerDown: enabled ? (_) => setState(() => _pressed = true) : null,
      onPointerUp: (_) => setState(() => _pressed = false),
      onPointerCancel: (_) => setState(() => _pressed = false),
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedScale(
          scale: _pressed ? 0.96 : 1.0,
          duration: const Duration(milliseconds: 120),
          curve: Curves.easeOut,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            width: widget.expand ? double.infinity : null,
            padding: EdgeInsets.symmetric(
              horizontal: widget.small ? 14 : 22,
              vertical: widget.small ? 10 : 14,
            ),
            decoration: decoration,
            child: content,
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Kartu
// ---------------------------------------------------------------------------
class ForgeCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? borderColor;
  final bool glow;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry? margin;

  const ForgeCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.borderColor,
    this.glow = false,
    this.onTap,
    this.margin,
  });

  @override
  Widget build(BuildContext context) {
    final card = Container(
      margin: margin,
      padding: padding,
      decoration: BoxDecoration(
        color: kForgeSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor ?? kForgeBorder),
        boxShadow: glow
            ? [
                BoxShadow(
                  color: (borderColor ?? kForgeYellow).withOpacity(0.25),
                  blurRadius: 14,
                  spreadRadius: 0.5,
                ),
              ]
            : null,
      ),
      child: child,
    );
    if (onTap != null) {
      return GestureDetector(onTap: onTap, child: card);
    }
    return card;
  }
}

// ---------------------------------------------------------------------------
// Chip status
// ---------------------------------------------------------------------------
class StatusChip extends StatelessWidget {
  final String label;
  final Color color;
  final bool dot;

  const StatusChip({
    super.key,
    required this.label,
    this.color = kForgeYellow,
    this.dot = true,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(99),
        border: Border.all(color: color.withOpacity(0.6)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (dot) ...[
            Container(
              width: 6,
              height: 6,
              decoration:
                  BoxDecoration(color: color, shape: BoxShape.circle),
            ),
            const SizedBox(width: 6),
          ],
          Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 10.5,
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Skeleton (shimmer sederhana)
// ---------------------------------------------------------------------------
class SkeletonBox extends StatefulWidget {
  final double? width;
  final double height;
  final double radius;

  const SkeletonBox({
    super.key,
    this.width,
    required this.height,
    this.radius = 12,
  });

  @override
  State<SkeletonBox> createState() => _SkeletonBoxState();
}

class _SkeletonBoxState extends State<SkeletonBox>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final t = _c.value;
        return Container(
          width: widget.width,
          height: widget.height,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(widget.radius),
            color: Color.lerp(kForgeSurface, kForgeBorder, t),
            border: Border.all(color: kForgeBorder.withOpacity(0.6)),
          ),
        );
      },
    );
  }
}

// ---------------------------------------------------------------------------
// Timeline status permohonan
// ---------------------------------------------------------------------------
class StatusTimeline extends StatelessWidget {
  final DraftStatus status;

  const StatusTimeline({super.key, required this.status});

  @override
  Widget build(BuildContext context) {
    const steps = [
      'Belum dikirim',
      'Draft tersimpan',
      'Siap dikirim',
      'Email dibuka',
    ];
    final current = status.index;

    return Row(
      children: List.generate(steps.length * 2 - 1, (i) {
        if (i.isOdd) {
          final done = (i ~/ 2) + 1 <= current;
          return Expanded(
            child: Container(
              height: 2,
              margin: const EdgeInsets.symmetric(horizontal: 2),
              color: done ? kForgeYellow : kForgeBorder,
            ),
          );
        }
        final idx = i ~/ 2;
        final done = idx < current;
        final active = idx == current;
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 26,
              height: 26,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: done ? kForgeYellow : Colors.transparent,
                border: Border.all(
                  color: done || active ? kForgeYellow : kForgeBorder,
                  width: active ? 2 : 1.2,
                ),
                boxShadow: active
                    ? [
                        BoxShadow(
                          color: kForgeYellow.withOpacity(0.4),
                          blurRadius: 8,
                        ),
                      ]
                    : null,
              ),
              child: Center(
                child: done
                    ? const Icon(Icons.check, size: 14, color: kForgeBg)
                    : Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: active
                              ? kForgeYellow
                              : kForgeBorder,
                        ),
                      ),
              ),
            ),
            const SizedBox(height: 6),
            SizedBox(
              width: 64,
              child: Text(
                steps[idx],
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 9.5,
                  height: 1.2,
                  color: done || active ? kForgeYellow : kForgeGray,
                  fontWeight: active ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ),
          ],
        );
      }),
    );
  }
}

// ---------------------------------------------------------------------------
// Toast / SnackBar helper
// ---------------------------------------------------------------------------
void forgeToast(BuildContext context, String message, {bool error = false}) {
  ScaffoldMessenger.of(context).hideCurrentSnackBar();
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Row(
        children: [
          Icon(
            error ? Icons.error_outline : Icons.check_circle_outline,
            size: 16,
            color: error ? const Color(0xFFFF5252) : kForgeYellow,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              message,
              style: const TextStyle(color: kForgeWhite, fontSize: 12.5),
            ),
          ),
        ],
      ),
      backgroundColor: kForgeSurface,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: error
              ? const Color(0xFFFF5252).withOpacity(0.6)
              : kForgeYellow.withOpacity(0.6),
        ),
      ),
    ),
  );
}

// ---------------------------------------------------------------------------
// Dialog konfirmasi
// ---------------------------------------------------------------------------
Future<bool> forgeConfirm(
  BuildContext context, {
  required String title,
  required String content,
  String confirmLabel = 'YA, LANJUT',
  bool danger = false,
}) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(
        title,
        style: TextStyle(
          color: danger ? const Color(0xFFFF5252) : kForgeYellow,
          fontWeight: FontWeight.w800,
          fontSize: 16,
        ),
      ),
      content: Text(
        content,
        style: const TextStyle(color: kForgeGray, fontSize: 12.5, height: 1.5),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: const Text('BATAL',
              style: TextStyle(color: kForgeGray, fontSize: 12)),
        ),
        TextButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(
            confirmLabel,
            style: TextStyle(
              color: danger ? const Color(0xFFFF5252) : kForgeYellow,
              fontWeight: FontWeight.w800,
              fontSize: 12,
            ),
          ),
        ),
      ],
    ),
  );
  return result ?? false;
}

// ---------------------------------------------------------------------------
// Dialog untuk melihat isi teks template
// ---------------------------------------------------------------------------
Future<void> showBodyDialog(
  BuildContext context, {
  required String title,
  required String body,
}) async {
  await showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(
        title,
        style: const TextStyle(
          color: kForgeYellow,
          fontWeight: FontWeight.w800,
          fontSize: 14.5,
        ),
      ),
      content: SizedBox(
        width: double.maxFinite,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Catatan: variabel {…} akan diisi otomatis dari formulir.',
              style: TextStyle(
                color: kForgeGray,
                fontSize: 11,
                fontStyle: FontStyle.italic,
              ),
            ),
            const SizedBox(height: 10),
            Flexible(
              child: Container(
                constraints: const BoxConstraints(maxHeight: 380),
                decoration: BoxDecoration(
                  color: kForgeBg,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: kForgeBorder),
                ),
                padding: const EdgeInsets.all(12),
                child: SingleChildScrollView(
                  child: SelectableText(
                    body,
                    style: const TextStyle(
                      color: kForgeWhite,
                      fontSize: 11.5,
                      height: 1.5,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton.icon(
          onPressed: () async {
            await Clipboard.setData(ClipboardData(text: body));
            if (ctx.mounted) {
              Navigator.pop(ctx);
              forgeToast(context, 'Template mentah disalin ke clipboard.');
            }
          },
          icon: const Icon(Icons.copy_rounded, size: 14, color: kForgeYellow),
          label: const Text('SALIN MENTAH',
              style: TextStyle(color: kForgeYellow, fontSize: 12)),
        ),
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: const Text('TUTUP',
              style: TextStyle(color: kForgeGray, fontSize: 12)),
        ),
      ],
    ),
  );
}

// ---------------------------------------------------------------------------
// Transisi halaman (fade + slide halus)
// ---------------------------------------------------------------------------
Route<T> forgeRoute<T>(Widget page) {
  return PageRouteBuilder<T>(
    transitionDuration: const Duration(milliseconds: 280),
    reverseTransitionDuration: const Duration(milliseconds: 220),
    pageBuilder: (_, animation, ___) => page,
    transitionsBuilder: (_, animation, __, child) {
      final curved =
          CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
      return FadeTransition(
        opacity: curved,
        child: SlideTransition(
          position:
              Tween(begin: const Offset(0, 0.04), end: Offset.zero)
                  .animate(curved),
          child: child,
        ),
      );
    },
  );
}
