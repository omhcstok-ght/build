/// Implementasi platform IO (Android/iOS/desktop).
import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/painting.dart'
    show AssetImage, FileImage, ImageProvider, MemoryImage;
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';

String mimeFor(String ext) {
  switch (ext.toLowerCase()) {
    case 'png':
      return 'image/png';
    case 'jpg':
    case 'jpeg':
      return 'image/jpeg';
    case 'webp':
      return 'image/webp';
    case 'gif':
      return 'image/gif';
    case 'mp4':
      return 'video/mp4';
    case 'mov':
      return 'video/quicktime';
    case 'mp3':
      return 'audio/mpeg';
    case 'm4a':
      return 'audio/mp4';
    case 'aac':
      return 'audio/aac';
    case 'wav':
      return 'audio/wav';
    default:
      return 'application/octet-stream';
  }
}

/// Menyimpan file hasil pick ke direktori dokumen aplikasi (mobile).
Future<String?> persistPickedMedia(PlatformFile f) async {
  final src = f.path;
  if (src == null) return null;
  final dir = await getApplicationDocumentsDirectory();
  final name = 'forge_${DateTime.now().millisecondsSinceEpoch}_${f.name}';
  final out = await File(src).copy('${dir.path}/$name');
  return out.path;
}

/// Mengubah referensi media menjadi ImageProvider yang sesuai.
ImageProvider? imageProviderFor(String ref) {
  if (ref.startsWith('assets/')) return AssetImage(ref);
  if (ref.startsWith('data:')) {
    try {
      return MemoryImage(base64Decode(ref.split(',').last));
    } catch (_) {
      return null;
    }
  }
  return FileImage(File(ref));
}

/// Membuat VideoPlayerController yang sesuai untuk sebuah referensi.
VideoPlayerController? videoControllerFor(String ref) {
  if (ref.startsWith('assets/')) return VideoPlayerController.asset(ref);
  if (ref.startsWith('data:')) return null;
  return VideoPlayerController.file(File(ref));
}
