/// MetodeUnbandByForge — Picker media untuk Admin Panel.
/// Mobile: file disalin ke direktori dokumen aplikasi.
/// Web: file disimpan sebagai data URL (batasi < 2 MB).
import 'package:file_picker/file_picker.dart';

import 'platform_media.dart';

class MediaService {
  MediaService._();

  /// Mengembalikan referensi media:
  /// - 'assets/...' (asset bawaan)
  /// - '/path/ke/file' (file lokal mobile)
  /// - 'data:...;base64,...' (web)
  /// atau null bila dibatalkan/gagal.
  static Future<String?> pickMedia({
    bool image = false,
    bool video = false,
    bool audio = false,
  }) async {
    try {
      final FileType type = audio
          ? FileType.audio
          : (video ? FileType.video : FileType.image);
      final result = await FilePicker.platform.pickFiles(
        type: type,
        withData: true,
      );
      final file = result?.files.single;
      if (file == null) return null;
      return await persistPickedMedia(file);
    } catch (_) {
      return null;
    }
  }

  static Future<String?> pickImage() => pickMedia(image: true);
  static Future<String?> pickVideo() => pickMedia(video: true);
  static Future<String?> pickAudio() => pickMedia(audio: true);
}
