/// MetodeUnbandByForge — Database lokal (SharedPreferences) + penyimpanan
/// draft/log yang selalu lokal demi privasi pengguna.
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/models.dart';
import 'database_service.dart';

class LocalDatabaseService implements DatabaseService {
  static const _kSettings = 'forge_settings';
  static const _kTemplates = 'forge_templates';
  static const _kDrafts = 'forge_drafts';
  static const _kLogs = 'forge_logs';
  static const _kSound = 'forge_sound_on';

  @override
  String get mode => 'local';

  Future<SharedPreferences> get _p => SharedPreferences.getInstance();

  // ---------- Pengaturan ----------
  @override
  Future<AppSettings> loadSettings(AppSettings fallback) async {
    try {
      final raw = (await _p).getString(_kSettings);
      if (raw == null) return fallback;
      return AppSettings.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return fallback;
    }
  }

  @override
  Future<void> saveSettings(AppSettings settings) async {
    try {
      await (await _p).setString(_kSettings, jsonEncode(settings.toJson()));
    } catch (_) {}
  }

  // ---------- Template ----------
  @override
  Future<List<AppealTemplate>> loadTemplates() async {
    try {
      final raw = (await _p).getString(_kTemplates);
      if (raw == null) return [];
      final list = jsonDecode(raw) as List<dynamic>;
      return list
          .map((e) => AppealTemplate.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return [];
    }
  }

  @override
  Future<void> saveTemplate(AppealTemplate template) async {
    final list = await loadTemplates();
    final idx = list.indexWhere((t) => t.id == template.id);
    if (idx >= 0) {
      list[idx] = template;
    } else {
      list.add(template);
    }
    await (await _p)
        .setString(_kTemplates, jsonEncode(list.map((t) => t.toJson()).toList()));
  }

  @override
  Future<void> deleteTemplate(String id) async {
    final list = await loadTemplates();
    list.removeWhere((t) => t.id == id);
    await (await _p)
        .setString(_kTemplates, jsonEncode(list.map((t) => t.toJson()).toList()));
  }

  // ---------- Draft (selalu lokal) ----------
  Future<List<AppealDraft>> loadDrafts() async {
    try {
      final raw = (await _p).getString(_kDrafts);
      if (raw == null) return [];
      final list = jsonDecode(raw) as List<dynamic>;
      return list
          .map((e) => AppealDraft.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> saveDraft(AppealDraft draft) async {
    final list = await loadDrafts();
    final idx = list.indexWhere((d) => d.id == draft.id);
    if (idx >= 0) {
      list[idx] = draft;
    } else {
      list.insert(0, draft);
    }
    await (await _p)
        .setString(_kDrafts, jsonEncode(list.map((d) => d.toJson()).toList()));
  }

  Future<void> deleteDraft(String id) async {
    final list = await loadDrafts();
    list.removeWhere((d) => d.id == id);
    await (await _p)
        .setString(_kDrafts, jsonEncode(list.map((d) => d.toJson()).toList()));
  }

  // ---------- Log aktivitas (selalu lokal) ----------
  Future<List<ActivityLog>> loadLogs({int limit = 100}) async {
    try {
      final raw = (await _p).getString(_kLogs);
      if (raw == null) return [];
      final list = jsonDecode(raw) as List<dynamic>;
      return list
          .map((e) => ActivityLog.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> saveLogs(List<ActivityLog> logs) async {
    try {
      await (await _p)
          .setString(_kLogs, jsonEncode(logs.map((l) => l.toJson()).toList()));
    } catch (_) {}
  }

  // ---------- Preferensi suara ----------
  Future<bool> loadSoundOn() async => (await _p).getBool(_kSound) ?? true;

  Future<void> saveSoundOn(bool on) async {
    await (await _p).setBool(_kSound, on);
  }

  @override
  Future<List<Map<String, dynamic>>> loadUsers() async => [];
}
