/// MetodeUnbandByForge — STUB konfigurasi Firebase.
///
/// File ini adalah STUB. Saat Anda menjalankan `flutterfire configure`
/// (lihat docs/FIREBASE_SETUP.md), file lib/firebase_options.dart akan
/// di-GENERATE ULANG oleh FlutterFire CLI dengan konfigurasi asli dan
/// aplikasi otomatis beralih ke mode Firebase.
///
/// Tanpa konfigurasi, `initializeApp` akan gagal dan aplikasi berjalan
/// penuh dalam MODE LOKAL (SharedPreferences) tanpa error.
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform => throw UnsupportedError(
      'Firebase belum dikonfigurasi. Jalankan: flutterfire configure '
      '(lihat docs/FIREBASE_SETUP.md). Aplikasi akan berjalan dalam mode lokal.');
}
