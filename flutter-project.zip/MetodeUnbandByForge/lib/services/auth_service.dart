/// MetodeUnbandByForge — Autentikasi admin lokal (hash SHA-256).
///
/// Password TIDAK pernah disimpan dalam bentuk plain text. Kredensial awal
/// (admin / ForgeAdmin#2024) di-seed sekali pada run pertama dan WAJIB
/// digunakan untuk login pertama lalu diganti (forced change).
import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/models.dart';

enum AdminLoginResult { ok, invalid, locked }

class AuthService {
  static const _kKey = 'forge_admin';
  static const _salt = 'forge.v1.salt';
  static const _defaultUsername = 'admin';
  static const _defaultPassword = 'ForgeAdmin#2024';

  String hash(String username, String password) => sha256
      .convert(utf8.encode('$_salt:$username:$password'))
      .toString();

  Future<AdminAccount> load() async {
    try {
      final raw =
          (await SharedPreferences.getInstance()).getString(_kKey);
      if (raw != null) {
        return AdminAccount.fromJson(jsonDecode(raw) as Map<String, dynamic>);
      }
    } catch (_) {}
    // Seed akun default sekali (hash saja, tanpa plain text tersimpan).
    final seed = AdminAccount(
      username: _defaultUsername,
      passwordHash: hash(_defaultUsername, _defaultPassword),
      mustChangePassword: true,
    );
    await save(seed);
    return seed;
  }

  Future<void> save(AdminAccount account) async {
    try {
      await (await SharedPreferences.getInstance())
          .setString(_kKey, jsonEncode(account.toJson()));
    } catch (_) {}
  }

  Future<AdminLoginResult> login(String username, String password) async {
    final account = await load();
    final now = DateTime.now().millisecondsSinceEpoch;
    if (account.lockUntilMs > now) return AdminLoginResult.locked;

    if (username.trim() == account.username &&
        hash(account.username, password) == account.passwordHash) {
      account.failCount = 0;
      account.lockUntilMs = 0;
      await save(account);
      return AdminLoginResult.ok;
    }

    account.failCount += 1;
    if (account.failCount >= 5) {
      account.lockUntilMs = now + 30000; // kunci 30 detik
      account.failCount = 0;
    }
    await save(account);
    return AdminLoginResult.invalid;
  }

  Future<void> changePassword(String newPassword) async {
    final account = await load();
    account.passwordHash = hash(account.username, newPassword);
    account.mustChangePassword = false;
    await save(account);
  }

  /// Sisa detik lockout (0 bila tidak terkunci).
  Future<int> remainingLockSeconds() async {
    final account = await load();
    final diff = account.lockUntilMs - DateTime.now().millisecondsSinceEpoch;
    return diff > 0 ? (diff / 1000).ceil() : 0;
  }

  bool validateNewPassword(String password, String confirm) {
    if (password.length < 8) return false;
    if (password != confirm) return false;
    return true;
  }
}
