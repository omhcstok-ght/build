/// Implementasi platform Web (tanpa dart:io).
import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/painting.dart'
    show AssetImage, ImageProvider, MemoryImage;
import 'package:video_player/video_player.dart';

String mimeFor(String ext) {
  switch (ext.toLowerCase()) {
    case 'png':
      return 'image/png';
    case 'jpg':
    case 'jpeg':
      return 'image/jpeg';
    case 'webp':
      return 'image/webp';
    case 'gif':
      return 'image/gif';
    case 'mp4':
      return 'video/mp4';
    case 'mov':
      return 'video/quicktime';
    case 'mp3':
      return 'audio/mpeg';
    case 'm4a':
      return 'audio/mp4';
    case 'aac':
      return 'audio/aac';
    case 'wav':
      return 'audio/wav';
    default:
      return 'application/octet-stream';
  }
}

/// Web: file yang dipilih disimpan sebagai data URL (batasi ukuran < 2 MB).
Future<String?> persistPickedMedia(PlatformFile f) async {
  final bytes = f.bytes;
  if (bytes == null) return null;
  return 'data:${mimeFor(f.extension ?? '')};base64,${base64Encode(bytes)}';
}

ImageProvider? imageProviderFor(String ref) {
  if (ref.startsWith('assets/')) return AssetImage(ref);
  if (ref.startsWith('data:')) {
    try {
      return MemoryImage(base64Decode(ref.split(',').last));
    } catch (_) {
      return null;
    }
  }
  return null;
}

VideoPlayerController? videoControllerFor(String ref) {
  if (ref.startsWith('assets/')) return VideoPlayerController.asset(ref);
  if (ref.startsWith('data:')) {
    // Data URL dapat diputar langsung oleh <video> pada browser.
    return VideoPlayerController.networkUrl(Uri.parse(ref));
  }
  return null;
}
