/// MetodeUnbandByForge — Service audio latar (loop, volume wajar).
import 'package:audioplayers/audioplayers.dart';

class AudioService {
  AudioService._();
  static final AudioService I = AudioService._();

  final AudioPlayer _player = AudioPlayer();
  bool _started = false;
  bool muted = false;

  /// Memulai musik latar dari asset. Aman dipanggil berulang — hanya
  /// memulai sekali agar tidak ada audio ganda.
  Future<void> startBgm(String assetPath) async {
    if (_started) return;
    try {
      final rel = assetPath.replaceFirst(RegExp(r'^assets/'), '');
      await _player.setReleaseMode(ReleaseMode.loop);
      await _player.setVolume(muted ? 0 : 0.35);
      await _player.play(AssetSource(rel));
      _started = true;
    } catch (_) {
      // Audio dapat gagal (mis. kebijakan autoplay web) — abaikan.
    }
  }

  Future<void> setMuted(bool m) async {
    muted = m;
    try {
      await _player.setVolume(m ? 0 : 0.35);
    } catch (_) {}
  }

  Future<void> resume() async {
    try {
      await _player.resume();
    } catch (_) {}
  }

  void dispose() {
    try {
      _player.dispose();
    } catch (_) {}
  }
}
