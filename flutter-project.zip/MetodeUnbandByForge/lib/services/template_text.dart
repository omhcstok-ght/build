/// MetodeUnbandByForge — Penggantian variabel pada template teks banding.
/// Tanpa dependensi tambahan (label tanggal bahasa Indonesia dibangun manual).

const List<String> _kDays = [
  'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu',
];

const List<String> _kMonths = [
  'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
  'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember',
];

String todayLabel() {
  final now = DateTime.now();
  final day = _kDays[now.weekday - 1];
  final month = _kMonths[now.month - 1];
  return '$day, ${now.day} $month ${now.year}';
}

/// Mengganti seluruh placeholder {VAR} pada body template dengan data
/// formulir pengguna.
String buildFinalText({
  required String body,
  required String ownerName,
  required String waNumber,
  required String issueType,
  required String issueDetails,
  required String supportEmail,
  required String appName,
}) {
  final date = todayLabel();
  return body
      .replaceAll('{OWNER_NAME}', ownerName.trim())
      .replaceAll('{WA_NUMBER}', waNumber.trim())
      .replaceAll('{ISSUE_TYPE}', issueType)
      .replaceAll('{ISSUE_DETAILS}',
          issueDetails.trim().isEmpty ? '-' : issueDetails.trim())
      .replaceAll('{SUPPORT_EMAIL}',
          supportEmail.trim().isEmpty ? 'WhatsApp official support' : supportEmail.trim())
      .replaceAll('{APP_NAME}', appName)
      .replaceAll('{DATE}', date);
}
