/// MetodeUnbandByForge — Implementasi Firestore (mode Firebase opsional).
///
/// Koleksi: forge_settings (doc: app), forge_templates, forge_users.
/// Draft dan log tetap lokal. Security rules ada di admin/firestore.rules.
import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/models.dart';
import 'database_service.dart';

class FirebaseDatabaseService implements DatabaseService {
  final FirebaseFirestore _fs = FirebaseFirestore.instance;

  @override
  String get mode => 'firebase';

  @override
  Future<AppSettings> loadSettings(AppSettings fallback) async {
    try {
      final doc = await _fs.collection('forge_settings').doc('app').get();
      if (!doc.exists || doc.data() == null) return fallback;
      return AppSettings.fromJson(doc.data()!);
    } catch (_) {
      return fallback;
    }
  }

  @override
  Future<void> saveSettings(AppSettings settings) async {
    await _fs.collection('forge_settings').doc('app').set(
          settings.toJson(),
          SetOptions(merge: true),
        );
  }

  @override
  Future<List<AppealTemplate>> loadTemplates() async {
    try {
      final snap = await _fs.collection('forge_templates').get();
      return snap.docs
          .map((d) => AppealTemplate.fromJson(d.data()))
          .toList();
    } catch (_) {
      return [];
    }
  }

  @override
  Future<void> saveTemplate(AppealTemplate template) async {
    await _fs
        .collection('forge_templates')
        .doc(template.id)
        .set(template.toJson(), SetOptions(merge: true));
  }

  @override
  Future<void> deleteTemplate(String id) async {
    await _fs.collection('forge_templates').doc(id).delete();
  }

  @override
  Future<List<Map<String, dynamic>>> loadUsers() async {
    try {
      final snap = await _fs.collection('forge_users').get();
      return snap.docs
          .map((d) => {'id': d.id, ...d.data()})
          .toList();
    } catch (_) {
      return [];
    }
  }
}
