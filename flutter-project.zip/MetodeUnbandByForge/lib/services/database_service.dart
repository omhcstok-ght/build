/// MetodeUnbandByForge — Abstraksi database + pilihan mode (Firebase / lokal).
import 'package:firebase_core/firebase_core.dart';

import '../models/models.dart';
import 'firebase_database_service.dart';
import 'firebase_options.dart';
import 'local_database_service.dart';

/// Antarmuka database untuk pengaturan, template, dan daftar pengguna.
/// Draft dan log AKTIVITAS selalu disimpan lokal (privasi) — lihat
/// LocalDatabaseService.
abstract class DatabaseService {
  /// 'local' atau 'firebase'.
  String get mode;

  Future<AppSettings> loadSettings(AppSettings fallback);
  Future<void> saveSettings(AppSettings settings);

  Future<List<AppealTemplate>> loadTemplates();
  Future<void> saveTemplate(AppealTemplate template);
  Future<void> deleteTemplate(String id);

  /// Hanya tersedia pada mode Firebase (koleksi forge_users).
  Future<List<Map<String, dynamic>>> loadUsers();
}

/// Mencoba menginisialisasi Firebase; bila gagal (belum dikonfigurasi),
/// otomatis memakai mode lokal sehingga aplikasi selalu berjalan.
Future<DatabaseService> createDatabaseService() async {
  try {
    if (Firebase.apps.isEmpty) {
      await Firebase.initializeApp(
          options: DefaultFirebaseOptions.currentPlatform);
    }
    return FirebaseDatabaseService();
  } catch (_) {
    return LocalDatabaseService();
  }
}
