/// Jembatan platform (io/web) — dipilih otomatis saat kompilasi.
export 'platform_media_io.dart' if (dart.library.html) 'platform_media_web.dart';
