/// MetodeUnbandByForge — Data Models
/// Developer: FORGE | Version: V1.0.0
library models;

/// Template teks permohonan peninjauan akun WhatsApp.
class AppealTemplate {
  String id;
  String name;
  String description;
  String body;
  List<String> languages;
  bool isActive;
  DateTime createdAt;
  DateTime updatedAt;

  AppealTemplate({
    required this.id,
    required this.name,
    required this.description,
    required this.body,
    required this.languages,
    this.isActive = true,
    DateTime? createdAt,
    DateTime? updatedAt,
  })  : createdAt = createdAt ?? DateTime(2025, 1, 1),
        updatedAt = updatedAt ?? DateTime(2025, 1, 1);

  int get languageCount => languages.length;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'description': description,
        'body': body,
        'languages': languages,
        'isActive': isActive,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
      };

  factory AppealTemplate.fromJson(Map<String, dynamic> json) => AppealTemplate(
        id: json['id'] as String,
        name: json['name'] as String,
        description: json['description'] as String,
        body: json['body'] as String,
        languages: (json['languages'] as List<dynamic>)
            .map((e) => e.toString())
            .toList(),
        isActive: json['isActive'] as bool? ?? true,
        createdAt: json['createdAt'] != null
            ? DateTime.tryParse(json['createdAt'] as String)
            : null,
        updatedAt: json['updatedAt'] != null
            ? DateTime.tryParse(json['updatedAt'] as String)
            : null,
      );

  AppealTemplate copyWith({
    String? id,
    String? name,
    String? description,
    String? body,
    List<String>? languages,
    bool? isActive,
    DateTime? updatedAt,
  }) =>
      AppealTemplate(
        id: id ?? this.id,
        name: name ?? this.name,
        description: description ?? this.description,
        body: body ?? this.body,
        languages: languages ?? this.languages,
        isActive: isActive ?? this.isActive,
        createdAt: createdAt,
        updatedAt: updatedAt ?? DateTime.now(),
      );
}

/// Status permohonan banding pengguna.
enum DraftStatus { notSent, draftSaved, readyToSend, emailOpened }

extension DraftStatusX on DraftStatus {
  String get label {
    switch (this) {
      case DraftStatus.notSent:
        return 'Belum dikirim';
      case DraftStatus.draftSaved:
        return 'Draft tersimpan';
      case DraftStatus.readyToSend:
        return 'Siap dikirim';
      case DraftStatus.emailOpened:
        return 'Email dibuka';
    }
  }

  int get index0 => index;
}

class AppealDraft {
  String id;
  String ownerName;
  String waNumber;
  String issueType;
  String issueDetails;
  String templateId;
  String finalText;
  DraftStatus status;
  DateTime createdAt;
  DateTime updatedAt;

  AppealDraft({
    required this.id,
    required this.ownerName,
    required this.waNumber,
    required this.issueType,
    required this.issueDetails,
    required this.templateId,
    required this.finalText,
    this.status = DraftStatus.notSent,
    DateTime? createdAt,
    DateTime? updatedAt,
  })  : createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toJson() => {
        'id': id,
        'ownerName': ownerName,
        'waNumber': waNumber,
        'issueType': issueType,
        'issueDetails': issueDetails,
        'templateId': templateId,
        'finalText': finalText,
        'status': status.index,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
      };

  factory AppealDraft.fromJson(Map<String, dynamic> json) => AppealDraft(
        id: json['id'] as String,
        ownerName: json['ownerName'] as String,
        waNumber: json['waNumber'] as String,
        issueType: json['issueType'] as String,
        issueDetails: json['issueDetails'] as String,
        templateId: json['templateId'] as String,
        finalText: json['finalText'] as String,
        status: DraftStatus.values[(json['status'] as int? ?? 0)
            .clamp(0, DraftStatus.values.length - 1)],
        createdAt: DateTime.tryParse(json['createdAt'] as String) ??
            DateTime.now(),
        updatedAt: DateTime.tryParse(json['updatedAt'] as String) ??
            DateTime.now(),
      );
}

/// Pengaturan aplikasi yang dapat diubah lewat Admin Panel.
class AppSettings {
  String appName;
  String tagline;
  String description;
  String developer;
  String version;
  String supportEmail;
  String helpUrl;
  String introVideo;
  String loadingVideo;
  String bgmAudio;
  List<String> carouselImages;
  String primaryColorHex;
  String backgroundColorHex;

  AppSettings({
    required this.appName,
    required this.tagline,
    required this.description,
    required this.developer,
    required this.version,
    required this.supportEmail,
    required this.helpUrl,
    required this.introVideo,
    required this.loadingVideo,
    required this.bgmAudio,
    required this.carouselImages,
    required this.primaryColorHex,
    required this.backgroundColorHex,
  });

  factory AppSettings.defaults() => AppSettings(
        appName: 'MetodeUnbandByForge',
        tagline: 'WhatsApp Account Review Assistant',
        description:
            'Platform pembantu penyusunan permohonan peninjauan akun WhatsApp '
            'secara praktis, terstruktur, dan profesional.',
        developer: 'FORGE',
        version: 'V1.0.0',
        supportEmail: '',
        helpUrl: OmhcSilenceProtect.decode(["NV490Afs","yBOS2l7Z","HRlihEeA","OY3oQ1fo"]),
        introVideo: 'assets/videos/intro.mp4',
        loadingVideo: 'assets/videos/loading.mp4',
        bgmAudio: 'assets/audio/bgm.mp3',
        carouselImages: [
          'assets/images/1000023802.png',
          'assets/images/1000014144.webp',
          'assets/images/1000014143.webp',
        ],
        primaryColorHex: '#FFD400',
        backgroundColorHex: '#080808',
      );

  Map<String, dynamic> toJson() => {
        'appName': appName,
        'tagline': tagline,
        'description': description,
        'developer': developer,
        'version': version,
        'supportEmail': supportEmail,
        'helpUrl': helpUrl,
        'introVideo': introVideo,
        'loadingVideo': loadingVideo,
        'bgmAudio': bgmAudio,
        'carouselImages': carouselImages,
        'primaryColorHex': primaryColorHex,
        'backgroundColorHex': backgroundColorHex,
      };

  factory AppSettings.fromJson(Map<String, dynamic> json) => AppSettings(
        appName: json['appName'] as String? ?? 'MetodeUnbandByForge',
        tagline: json['tagline'] as String? ?? '',
        description: json['description'] as String? ?? '',
        developer: json['developer'] as String? ?? 'FORGE',
        version: json['version'] as String? ?? 'V1.0.0',
        supportEmail: json['supportEmail'] as String? ?? '',
        helpUrl: json['helpUrl'] as String? ?? OmhcSilenceProtect.decode(["NV490Afs","yBOS2l7Z","HRlihEeA","OY3oQ1fo"]),
        introVideo: json['introVideo'] as String? ?? 'assets/videos/intro.mp4',
        loadingVideo:
            json['loadingVideo'] as String? ?? 'assets/videos/loading.mp4',
        bgmAudio: json['bgmAudio'] as String? ?? 'assets/audio/bgm.mp3',
        carouselImages: (json['carouselImages'] as List<dynamic>?)
                ?.map((e) => e.toString())
                .toList() ??
            AppSettings.defaults().carouselImages,
        primaryColorHex: json['primaryColorHex'] as String? ?? '#FFD400',
        backgroundColorHex: json['backgroundColorHex'] as String? ?? '#080808',
      );
}

/// Log aktivitas untuk dashboard admin.
class ActivityLog {
  String id;
  String action;
  String detail;
  DateTime at;

  ActivityLog({
    required this.id,
    required this.action,
    required this.detail,
    DateTime? at,
  }) : at = at ?? DateTime.now();

  Map<String, dynamic> toJson() => {
        'id': id,
        'action': action,
        'detail': detail,
        'at': at.toIso8601String(),
      };

  factory ActivityLog.fromJson(Map<String, dynamic> json) => ActivityLog(
        id: json['id'] as String,
        action: json['action'] as String,
        detail: json['detail'] as String,
        at: DateTime.tryParse(json['at'] as String) ?? DateTime.now(),
      );
}

/// Akun admin tersimpan lokal (hash SHA-256, tanpa plain text).
class AdminAccount {
  String username;
  String passwordHash;
  bool mustChangePassword;
  int failCount;
  int lockUntilMs;

  AdminAccount({
    required this.username,
    required this.passwordHash,
    this.mustChangePassword = true,
    this.failCount = 0,
    this.lockUntilMs = 0,
  });

  Map<String, dynamic> toJson() => {
        'username': username,
        'passwordHash': passwordHash,
        'mustChangePassword': mustChangePassword,
        'failCount': failCount,
        'lockUntilMs': lockUntilMs,
      };

  factory AdminAccount.fromJson(Map<String, dynamic> json) => AdminAccount(
        username: json['username'] as String? ?? 'admin',
        passwordHash: json['passwordHash'] as String,
        mustChangePassword: json['mustChangePassword'] as bool? ?? true,
        failCount: json['failCount'] as int? ?? 0,
        lockUntilMs: json['lockUntilMs'] as int? ?? 0,
      );
}
