/// MetodeUnbandByForge — Tema aplikasi (hitam / kuning / putih).
/// Developer: FORGE | Version: V1.0.0
import 'package:flutter/material.dart';

import '../models/models.dart';

const Color kForgeBg = Color(0xFF080808);
const Color kForgeSurface = Color(0xFF121212);
const Color kForgeYellow = Color(0xFFFFD400);
const Color kForgeWhite = Color(0xFFFFFFFF);
const Color kForgeGray = Color(0xFF888888);
const Color kForgeBorder = Color(0xFF292929);

/// Konversi string hex (#RRGGBB / #AARRGGBB) menjadi Color.
Color colorFromHex(String hex) {
  var h = hex.trim().replaceFirst('#', '');
  if (h.length == 6) h = 'FF$h';
  final v = int.tryParse(h, radix: 16);
  return Color(v ?? 0xFFFFD400);
}

/// Membangun ThemeData gelap dari pengaturan yang dikelola Admin Panel.
ThemeData buildForgeTheme(AppSettings s) {
  final primary = colorFromHex(s.primaryColorHex);
  final bg = colorFromHex(s.backgroundColorHex);
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: bg,
    colorScheme: ColorScheme.dark(
      primary: primary,
      secondary: primary,
      surface: kForgeSurface,
      onSurface: kForgeWhite,
      onPrimary: kForgeBg,
      outline: kForgeBorder,
      error: const Color(0xFFFF5252),
    ),
    dividerColor: kForgeBorder,
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      foregroundColor: kForgeWhite,
      centerTitle: false,
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: kForgeSurface,
      contentTextStyle: const TextStyle(color: kForgeWhite, fontSize: 13),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: kForgeSurface,
      hintStyle: const TextStyle(color: Color(0xFF555555), fontSize: 13),
      labelStyle: const TextStyle(color: kForgeGray, fontSize: 13),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: kForgeBorder),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: kForgeBorder),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: primary, width: 1.4),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0xFFFF5252)),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0xFFFF5252), width: 1.4),
      ),
    ),
    dropdownMenuTheme: DropdownMenuThemeData(
      textStyle: const TextStyle(color: kForgeWhite, fontSize: 13),
    ),
    dialogTheme: DialogTheme(
      backgroundColor: kForgeSurface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: kForgeBorder),
      ),
    ),
    expansionTileTheme: const ExpansionTileThemeData(
      backgroundColor: kForgeSurface,
      collapsedBackgroundColor: kForgeSurface,
      iconColor: kForgeYellow,
      collapsedIconColor: kForgeGray,
      textColor: kForgeWhite,
      collapsedTextColor: kForgeWhite,
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith((states) =>
          states.contains(WidgetState.selected) ? primary : kForgeGray),
      trackColor: WidgetStateProperty.resolveWith((states) =>
          states.contains(WidgetState.selected)
              ? primary.withOpacity(0.35)
              : kForgeBorder),
    ),
  );
}
