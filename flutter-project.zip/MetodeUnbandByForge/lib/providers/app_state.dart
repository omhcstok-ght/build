/// MetodeUnbandByForge — State global aplikasi (Provider).
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:video_player/video_player.dart';

import '../data/default_templates.dart';
import '../models/models.dart';
import '../services/audio_service.dart';
import '../services/auth_service.dart';
import '../services/database_service.dart';
import '../services/local_database_service.dart';

class AppState extends ChangeNotifier {
  DatabaseService? db;
  String dbMode = 'local';

  AppSettings settings = AppSettings.defaults();
  List<AppealTemplate> templates = [];
  List<AppealDraft> drafts = [];
  List<ActivityLog> logs = [];

  bool loaded = false;
  bool soundOn = true;

  bool isAdmin = false;
  bool adminMustChange = false;

  String? selectedTemplateId;

  VideoPlayerController? _introController;

  final LocalDatabaseService _local = LocalDatabaseService();
  final AuthService auth = AuthService();
  final Random _rand = Random();

  String _newId(String prefix) =>
      '$prefix${DateTime.now().millisecondsSinceEpoch}_${_rand.nextInt(9000) + 100}';

  // ---------- Inisialisasi ----------
  Future<void> init() async {
    try {
      final d = await createDatabaseService();
      db = d;
      dbMode = d.mode;
      settings = await d.loadSettings(settings);
      final stored = await d.loadTemplates();
      if (stored.isEmpty) {
        templates = List<AppealTemplate>.from(kDefaultTemplates);
        for (final t in templates) {
          await d.saveTemplate(t);
        }
      } else {
        templates = stored;
      }
      drafts = await _local.loadDrafts();
      drafts.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
      logs = await _local.loadLogs();
      soundOn = await _local.loadSoundOn();
    } catch (_) {
      templates = List<AppealTemplate>.from(kDefaultTemplates);
    }
    loaded = true;
    notifyListeners();
  }

  // ---------- Template ----------
  List<AppealTemplate> get activeTemplates =>
      templates.where((t) => t.isActive).toList();

  AppealTemplate? templateById(String id) {
    for (final t in templates) {
      if (t.id == id) return t;
    }
    return null;
  }

  AppealTemplate? get selectedTemplate {
    if (selectedTemplateId == null) return null;
    return templateById(selectedTemplateId!);
  }

  void selectTemplate(String? id) {
    selectedTemplateId = id;
    notifyListeners();
  }

  Future<void> upsertTemplate(AppealTemplate t) async {
    final idx = templates.indexWhere((x) => x.id == t.id);
    if (idx >= 0) {
      templates[idx] = t;
    } else {
      templates.add(t);
    }
    await db?.saveTemplate(t);
    await addLog('TEMPLATE_SAVE', t.name);
    notifyListeners();
  }

  Future<void> deleteTemplate(String id) async {
    templates.removeWhere((t) => t.id == id);
    if (selectedTemplateId == id) selectedTemplateId = null;
    await db?.deleteTemplate(id);
    await addLog('TEMPLATE_DELETE', id);
    notifyListeners();
  }

  // ---------- Draft (selalu lokal) ----------
  AppealDraft? get latestDraft =>
      drafts.isEmpty ? null : drafts.first;

  Future<AppealDraft> createDraft({
    required String ownerName,
    required String waNumber,
    required String issueType,
    required String issueDetails,
    required String templateId,
    required String finalText,
  }) async {
    final draft = AppealDraft(
      id: _newId('d'),
      ownerName: ownerName,
      waNumber: waNumber,
      issueType: issueType,
      issueDetails: issueDetails,
      templateId: templateId,
      finalText: finalText,
      status: DraftStatus.draftSaved,
    );
    drafts.insert(0, draft);
    await _local.saveDraft(draft);
    await addLog('DRAFT_CREATE', '${draft.waNumber} — ${draft.status.label}');
    notifyListeners();
    return draft;
  }

  Future<void> saveDraft(AppealDraft draft) async {
    draft.updatedAt = DateTime.now();
    await _local.saveDraft(draft);
    drafts.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    notifyListeners();
  }

  Future<void> markEmailOpened(AppealDraft draft) async {
    draft.status = DraftStatus.emailOpened;
    await saveDraft(draft);
    await addLog('EMAIL_OPENED', draft.waNumber);
    notifyListeners();
  }

  Future<void> deleteDraft(String id) async {
    drafts.removeWhere((d) => d.id == id);
    await _local.deleteDraft(id);
    notifyListeners();
  }

  // ---------- Pengaturan ----------
  Future<void> updateSettings(AppSettings s) async {
    settings = s;
    await db?.saveSettings(s);
    await addLog('SETTINGS_SAVE', 'pengaturan diperbarui');
    notifyListeners();
  }

  // ---------- Suara ----------
  Future<void> setSound(bool on) async {
    soundOn = on;
    await AudioService.I.setMuted(!on);
    await _local.saveSoundOn(on);
    notifyListeners();
  }

  // ---------- Log aktivitas ----------
  Future<void> addLog(String action, String detail) async {
    final log = ActivityLog(id: _newId('l'), action: action, detail: detail);
    logs.insert(0, log);
    if (logs.length > 100) {
      logs.removeRange(100, logs.length);
    }
    await _local.saveLogs(logs);
  }

  Future<void> clearLogs() async {
    logs.clear();
    await _local.saveLogs(logs);
    notifyListeners();
  }

  // ---------- Admin ----------
  Future<AdminLoginResult> adminLogin(String username, String password) async {
    final result = await auth.login(username, password);
    if (result == AdminLoginResult.ok) {
      final account = await auth.load();
      isAdmin = true;
      adminMustChange = account.mustChangePassword;
      await addLog('ADMIN_LOGIN', account.username);
      notifyListeners();
    }
    return result;
  }

  Future<void> adminChangePassword(String newPassword) async {
    await auth.changePassword(newPassword);
    adminMustChange = false;
    await addLog('ADMIN_PASSWORD_CHANGE', 'password admin diperbarui');
    notifyListeners();
  }

  void adminLogout() {
    isAdmin = false;
    notifyListeners();
  }

  Future<List<Map<String, dynamic>>> loadUsers() async {
    return await db?.loadUsers() ?? [];
  }

  // ---------- Video intro (pra-init saat loading) ----------
  VideoPlayerController? get introController => _introController;

  Future<bool> preInitIntro() async {
    if (_introController != null) return true;
    try {
      final c = VideoPlayerController.asset(settings.introVideo);
      await c.initialize();
      _introController = c;
      return true;
    } catch (_) {
      return false;
    }
  }

  void disposeIntro() {
    try {
      _introController?.dispose();
    } catch (_) {}
    _introController = null;
  }
}
