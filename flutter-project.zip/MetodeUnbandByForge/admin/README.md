# admin/ — Keamanan dan Rules (MetodeUnbandByForge)

**Developer:** FORGE | **Version:** V1.0.0

Folder ini berisi security rules Firebase dan panduan keamanan singkat untuk fitur Admin Panel.

## Isi Folder

| File | Fungsi |
| --- | --- |
| `firestore.rules` | Rules Cloud Firestore: baca publik untuk template/pengaturan, tulis admin-only, default deny. |
| `storage.rules` | Rules Cloud Storage: baca publik untuk `forge_media/**`, tulis admin-only, default deny. |

## Lokasi Panel Admin

Kode panel admin berada di `lib/admin/` dan TIDAK di folder ini. Panel diakses dari dalam aplikasi:

1. Buka tab TENTANG.
2. Tekan tombol Admin Panel.
3. Login (default: username `admin`, password `ForgeAdmin#2024`).
4. Sistem MEMAKSA penggantian password pada login pertama.

Modul yang tersedia: Dashboard (statistik + log), Template (CRUD), Media (media manager), Pengaturan (app settings), Pengguna (users/drafts).

## Ringkasan Model Keamanan

- Password admin disimpan sebagai HASH SHA-256, tidak pernah sebagai teks biasa. Password default tidak ditulis sebagai kredensial aktif di kode publik.
- Lockout: akun admin terkunci sementara setelah 5 percobaan login gagal.
- Draft pengguna SELALU tersimpan lokal (SharedPreferences) di perangkat pengguna; tidak dikirim ke server.
- Mode Firebase (opsional):
  - Login admin via Firebase Auth (Email/Password).
  - Security rules di folder ini mengontrol akses Firestore dan Storage.
  - Hak akses admin diset lewat CUSTOM CLAIM `admin: true` (rules memeriksa `request.auth.token.admin == true`). Cara set claim ada di `docs/FIREBASE_SETUP.md`.
  - Jika `initializeApp` gagal atau Firebase belum dikonfigurasi, aplikasi otomatis fallback ke mode lokal.

## Aturan Praktis

- JANGAN commit kredensial: tidak ada password, keystore, `key.properties`, atau `google-services.json` di git (lihat `.gitignore` di root).
- Ganti password default pada login pertama; jangan pernah membagikannya setelah diganti.
- Rules di folder ini dipublikasikan ke console (Firestore > Rules, Storage > Rules) dan hanya berlaku untuk project Firebase milik Anda.
