# Panduan Build — MetodeUnbandByForge

**Developer:** FORGE | **Version:** V1.0.0

Panduan ini mencakup prasyarat, pembuatan ulang folder platform, signing APK, build APK/appbundle/Web, deploy web, tips performa, dan tabel troubleshooting.

## 1. Prasyarat Detail

| Komponen | Kebutuhan |
| --- | --- |
| Flutter SDK | 3.22 atau lebih baru (Dart 3.4+) |
| Android Studio | Versi stabil terbaru, dengan Android SDK Platform + SDK Command-line Tools |
| JDK | 17 (dibutuhkan Gradle plugin Android modern) |
| Target Android | minSdk 21 |
| Browser (untuk Web) | Chrome direkomendasikan untuk `flutter run -d chrome` |

Instal Android Studio, buka SDK Manager, pastikan terpasang: Android SDK Platform (API terbaru yang didukung Flutter), SDK Platform-Tools, SDK Command-line Tools.

Verifikasi lingkungan:

```bash
flutter doctor
flutter doctor --android-licenses
```

Pastikan baris Flutter, Android toolchain, dan (jika build web) Chrome tidak bermasalah.

## 2. Buat Ulang Folder Platform

Folder `android/` dan `web/` tidak disertakan dalam paket proyek. Buat ulang dengan:

```bash
cd MetodeUnbandByForge
flutter create --platforms=android,web .
flutter pub get
```

Perintah ini hanya menambah file platform yang belum ada; `lib/` dan `assets/` yang sudah ada tidak ditimpa. Setelah itu `flutter run` dapat langsung dipakai.

## 3. Signing APK (Release)

### 3.1 Buat keystore

```bash
keytool -genkey -v -keystore ~/forge-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias forge-release
```

Simpan keystore, alias, dan password dengan aman. JANGAN commit keystore ke git.

### 3.2 Buat file key.properties

Buat file `android/key.properties` (jangan di-commit):

```properties
storePassword=<password keystore Anda>
keyPassword=<password key Anda>
keyAlias=forge-release
storeFile=/jalur/absolut/ke/forge-release-key.jks
```

### 3.3 Konfigurasi build.gradle

Pada `android/app/build.gradle`, konfigurasikan signingConfig release membaca `key.properties`. Konsepnya:

```gradle
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

android {
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
            storePassword keystoreProperties['storePassword']
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
        }
    }
}
```

Catatan: pada project Flutter modern, `key.properties` diletakkan di `android/key.properties` dan path `storeFile` ditulis relatif terhadap folder `android/` (contoh: `../forge-release-key.jks` jika keystore berada di root proyek). Sesuaikan dengan lokasi keystore Anda.

Tanpa konfigurasi ini, `flutter build apk --release` tetap berhasil memakai debug signing, tetapi APK tidak layak dipublikasikan.

## 4. Build APK

```bash
flutter build apk --release
```

Hasil: `build/app/outputs/flutter-apk/app-release.apk`

### 4.1 Split per ABI (APK lebih kecil)

```bash
flutter build apk --release --split-per-abi
```

Hasil (contoh):

```
build/app/outputs/flutter-apk/app-armeabi-v7a-release.apk
build/app/outputs/flutter-apk/app-arm64-v8a-release.apk
build/app/outputs/flutter-apk/app-x86_64-release.apk
```

Instal ke perangkat sesuai arsitektur CPU (kebanyakan ponsel modern: arm64-v8a).

### 4.2 Build App Bundle (untuk Google Play)

```bash
flutter build appbundle --release
```

Hasil: `build/app/outputs/bundle/release/app-release.aab`

## 5. Build dan Deploy Flutter Web

### 5.1 Build

```bash
flutter build web
```

Hasil: folder `build/web/` (berisi `index.html`, `main.dart.js`, aset, dan lainnya). Folder ini dapat disajikan sebagai situs statis.

### 5.2 Deploy ke Firebase Hosting

```bash
npm install -g firebase-tools
firebase login
firebase init hosting
# Public directory: build/web
# Single-page app: Yes
flutter build web
firebase deploy --only hosting
```

### 5.3 Deploy ke hosting statis lain (Netlify, dsb.)

Unggah seluruh isi `build/web/` ke hosting statis apa pun. Untuk SPA routing sederhana aplikasi ini (navigasi berbasis widget, bukan URL routing), cukup hosting file statis biasa tanpa rewrite khusus.

## 6. Performa

- Jaga ukuran video tetap kecil: usahakan setiap video di bawah 10 MB, resolusi 720p. Video besar memperlambat pra-muat aset di loading screen dan menghabiskan memori.
- Gunakan H.264 + AAC dengan piksel format yuv420p agar decode cepat di hampir semua perangkat.
- Untuk Web, pertimbangkan mengecilkan bitrate video dan audio (lihat docs/ASSET_GUIDE.md).
- Jalankan versi release saat menguji performa nyata (`flutter run --release`), karena debug jauh lebih lambat.

## 7. Troubleshooting

| Masalah | Penyebab umum | Solusi |
| --- | --- | --- |
| Build gagal: Gradle version mismatch | Versi Gradle/AGP tidak cocok dengan Flutter/JDK | Gunakan JDK 17. Sesuaikan versi Gradle di `android/gradle/wrapper/gradle-wrapper.properties` dan AGP di `android/settings.gradle` sesuai rekomendasi versi Flutter Anda. |
| Build gagal: minSdk error | Plugin membutuhkan minSdk lebih tinggi | Aplikasi ini menarget minSdk 21. Pastikan `flutter.minSdkVersion` atau set eksplisit minSdk 21 atau lebih tinggi di `android/app/build.gradle`. |
| Video tidak muncul / layar hitam | Codec bukan H.264 atau piksel format bukan yuv420p | Normalisasi dengan ffmpeg: `ffmpeg -i input.mp4 -vf "scale=1280:-2,format=yuv420p" -c:v libx264 -preset medium -crf 23 -c:a aac -movflags +faststart output.mp4` |
| Audio BGM tidak bunyi di Web | Browser membatasi autoplay tanpa interaksi | Pastikan ada interaksi pengguna sebelum play. Ini keterbatasan browser, bukan bug. Di Android tidak ada batasan ini. |
| file_picker gagal/batal memilih file | Izin penyimpanan atau bug emulator tertentu | Uji di perangkat fisik. Untuk Android 13+ file_picker memakai photo picker/saf dan tidak butuh izin storage legacy; pastikan versi plugin terbaru via `flutter pub upgrade`. |
| `flutter pub get` gagal versi tidak cocok | SDK constraint pubspec vs Flutter lokal | Jalankan `flutter pub upgrade`, dan pastikan Flutter 3.22+. |
| Web build gagal di flutterfire | `firebase_options.dart` masih stub | Jalankan `flutterfire configure` (lihat docs/FIREBASE_SETUP.md), atau biarkan mode lokal aktif. |
| APK tidak terinstal di perangkat | Arsitektur ABI tidak cocok | Gunakan APK gabungan atau pilih APK split sesuai ABI (umumnya arm64-v8a). |
