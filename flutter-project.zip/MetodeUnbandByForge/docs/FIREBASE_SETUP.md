# Panduan Firebase (Opsional) — MetodeUnbandByForge

**Developer:** FORGE | **Version:** V1.0.0

## Ringkasan Penting: Firebase SIFATNYA OPSIONAL

MetodeUnbandByForge berjalan PENUH tanpa Firebase. Mode lokal (SharedPreferences) adalah mode default dan selalu tersedia. Jika `initializeApp` gagal atau `lib/firebase_options.dart` masih berupa stub, factory `createDatabaseService` (di `lib/services/database_service.dart`) otomatis jatuh (fallback) ke `LocalDatabaseService`. Anda hanya perlu Firebase jika ingin:

- Sinkronisasi template/pengaturan/log antar perangkat.
- Login admin via Firebase Auth (Email/Password).
- Penyimpanan media di Cloud Storage.

Draft pengguna TETAP disimpan lokal di perangkat (privasi), apa pun mode yang aktif.

## Langkah Setup

### 1. Buat project Firebase

1. Buka `https://console.firebase.google.com`.
2. Klik Add project, beri nama (contoh: `metodeunband-by-forge`), ikuti wizard.
3. Anda tidak wajib mengaktifkan Google Analytics untuk project ini.

### 2. Aktifkan Authentication (Email/Password)

1. Di console, masuk ke Build > Authentication > Get started.
2. Pada tab Sign-in method, aktifkan provider Email/Password.
3. Buat user admin: tab Users > Add user.
   - Email contoh: `admin@forge.local`
   - Password: pilih password kuat Anda sendiri.
   - PENTING: `admin@forge.local` hanyalah CONTOH identifier untuk login admin di Firebase Auth. Ini bukan email resmi WhatsApp dan tidak digunakan untuk mengirim email ke WhatsApp. Kanal resmi WhatsApp tetap: `https://faq.whatsapp.com` dan formulir kontak `https://www.whatsapp.com/contact`.

### 3. Aktifkan Cloud Firestore dan Storage

1. Build > Firestore Database > Create database. Pilih lokasi, mulai dalam mode production (security rules akan diatur pada langkah 6).
2. Build > Storage > Get started. Terima lokasi default.

### 4. Install FlutterFire CLI

```bash
dart pub global activate flutterfire_cli
```

Pastikan direktori `~/.pub-cache/bin` (Linux/macOS) atau `%LOCALAPPDATA%\Pub\Cache\bin` (Windows) ada di PATH Anda.

### 5. Jalankan flutterfire configure

Dari dalam folder proyek:

```bash
flutterfire configure
```

Perintah ini akan:

- Menanyakan project Firebase yang dipilih dan platform yang diaktifkan (pilih android dan web).
- MENGgantikan stub `lib/firebase_options.dart` dengan konfigurasi nyata hasil generate. Stub bawaan sengaja melempar `UnsupportedError` jika dipakai sebelum dikonfigurasi; setelah perintah ini, aplikasi dapat memanggil `initializeApp` dengan aman.
- Mendaftarkan aplikasi di project Firebase Anda.

### 6. google-services.json (opsional)

File `android/app/google-services.json` HANYA diperlukan jika Anda mengaktifkan plugin Gradle Google Services di sisi Android. Alur FlutterFire dengan `firebase_options.dart` (Firebase init dari Dart) tidak membutuhkannya. Jika Anda tetap menginginkannya:

1. Di console: Project settings > Your apps > aplikasi Android > Download google-services.json.
2. Letakkan di `android/app/google-services.json`.
3. File ini dikecualikan dari git oleh `.gitignore` (jangan commit kredensial).

### 7. Tempel security rules

1. Buka `admin/firestore.rules` di folder proyek ini, salin seluruh isinya, tempel di console: Firestore Database > Rules > lalu Publish.
2. Buka `admin/storage.rules`, salin seluruh isinya, tempel di console: Storage > Rules > lalu Publish.
3. Rules ini mengatur: baca publik untuk template/pengaturan, tulis hanya untuk admin (custom claim), dan default deny untuk lainnya.

### 8. Set custom claim admin

Security rules memeriksa `request.auth.token.admin == true`. Claim ini tidak bisa diset dari aplikasi; gunakan Admin SDK dari mesin yang Anda percaya.

Contoh skrip Node.js (`set_admin_claim.js`):

```js
// Jalankan: node set_admin_claim.js <UID_USER>
// Prasyarat: npm install firebase-admin
// Autentikasi: gcloud auth application-default login (Application Default Credentials)
const admin = require('firebase-admin');

admin.initializeApp({
  credential: admin.credential.applicationDefault(),
});

const uid = process.argv[2];
if (!uid) {
  console.error('Pemakaian: node set_admin_claim.js <UID_USER>');
  process.exit(1);
}

admin
  .auth()
  .setCustomUserClaims(uid, { admin: true })
  .then(() => {
    console.log('Custom claim admin:true telah diset untuk UID:', uid);
    process.exit(0);
  })
  .catch((err) => {
    console.error('Gagal:', err.message);
    process.exit(1);
  });
```

Ambil UID dari console (Authentication > Users) atau dengan `admin.auth().getUserByEmail('admin@forge.local')`. Setelah claim diset, user admin harus login ulang agar token baru membawa claim.

### 9. Struktur koleksi Firestore

| Path | Isi | Akses |
| --- | --- | --- |
| `forge_settings/app` | Dokumen AppSettings (nama aplikasi, warna, path media, dan lainnya) | Read publik, write admin |
| `forge_templates/{id}` | Dokumen AppealTemplate (5 template seri V1) | Read publik, write admin |
| `forge_logs/{id}` | Dokumen ActivityLog | Read/write admin-claim only |
| `forge_users/{id}` | Data pengguna/draft agregat | Read admin-claim only, write denied (dikelola via console atau Admin SDK) |

Semua path lain ditolak (default deny). Draft pengguna tetap lokal dan TIDAK ditulis ke Firestore oleh aplikasi.

### 10. Cara kerja fallback otomatis

- Saat aplikasi mulai, `createDatabaseService` mencoba `Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform)`.
- Jika `lib/firebase_options.dart` masih stub (melempar `UnsupportedError`), atau inisialisasi gagal (tanpa internet, konfigurasi salah, kota/limit), factory langsung mengembalikan `LocalDatabaseService`.
- Tidak ada crash, tidak ada setup tambahan: aplikasi selalu bisa dipakai.

### 11. Memverifikasi mode aktif

Masuk Admin Panel (Tentang > Admin Panel), buka Dashboard. Di sana ditampilkan chip status database:

- Chip `LOKAL`: mode SharedPreferences aktif (Firebase tidak terpasang atau gagal init).
- Chip `FIREBASE`: mode Firestore aktif dan terhubung.

Anda juga bisa melihat log aktivitas di Dashboard; operasi tulis sukses pada mode Firebase akan tercatat dan tersinkron ke `forge_logs`.

### 12. Catatan biaya dan kuota (paket Spark gratis)

- Paket Spark gratis mencakup Firestore dengan kuota baca/tulis/penyimpanan harian yang cukup untuk penggunaan internal skala kecil (puluhan pengguna, tulis jarang).
- Storage gratis 5 GB (cek angka terbaru di halaman pricing Firebase; angka dapat berubah).
- Cloud Function tidak digunakan oleh aplikasi ini, sehingga tidak ada biaya function.
- Jika kuota habis, operasi Firestore akan gagal dan aplikasi TIDAK otomatis berpindah mode saat runtime (fallback hanya saat init). Untuk skala lebih besar, naik ke paket Blaze dengan anggaran alert.
- Tips hemat kuota: batasi jumlah log, gunakan Security Rules yang ketat, dan jangan mengaktifkan streaming listener yang tidak perlu.

## Checklist Cepat

1. Project dibuat di console Firebase.
2. Authentication Email/Password aktif + user admin dibuat.
3. Firestore + Storage aktif.
4. `dart pub global activate flutterfire_cli` selesai.
5. `flutterfire configure` menimpa `lib/firebase_options.dart`.
6. Rules Firestore dan Storage ditempel dan dipublish.
7. Custom claim `admin: true` diset via Admin SDK.
8. Dashboard admin menampilkan chip FIREBASE.
