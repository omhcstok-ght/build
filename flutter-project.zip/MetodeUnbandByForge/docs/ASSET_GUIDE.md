# Panduan Aset & Media — MetodeUnbandByForge

**Developer:** FORGE | **Version:** V1.0.0

Panduan teknis mengganti semua media aplikasi. SEMUA file media saat ini adalah PLACEHOLDER buatan otomatis (bertema hitam-kuning FORGE), BUKAN file asli Anda. Ganti dengan file asli milik Anda dengan NAMA FILE YANG SAMA.

## 1. Spesifikasi Ideal Tiap Slot

| Slot | File | Spesifikasi ideal |
| --- | --- | --- |
| Video intro | `assets/videos/intro.mp4` | Durasi 8-15 detik, minimal 720p (720p-1080p), codec H.264 + AAC, piksel format yuv420p, `+faststart` agar cepat mulai di web. |
| Video loading | `assets/videos/loading.mp4` | Durasi 10-20 detik dan loopable (awal-akhir menyambung halus), 720p cukup (diputar di belakang overlay), H.264 + AAC yuv420p. |
| Musik latar | `assets/audio/bgm.mp3` | MP3 bitrate 96-192 kbps, durasi sekitar 60 detik, dirancang agar loop terdengar mulus (hindari jeda diam panjang di akhir). |
| Foto carousel 1 | `assets/images/1000023802.png` | 1280x720 (landscape) atau 1080x1350 (portrait), PNG/WebP/JPEG. |
| Foto carousel 2 | `assets/images/1000014144.webp` | Sama seperti di atas. WebP memberi ukuran lebih kecil. |
| Foto carousel 3 | `assets/images/1000014143.webp` | Sama seperti di atas. |
| Logo | `assets/images/forge_logo.png` | PNG dengan latar transparan, sisi terpanjang minimal 512 px agar tajam. |

Catatan umum:

- Pertahankan NAMA FILE persis sama (termasuk ekstensi) agar tidak perlu mengubah kode maupun pubspec.
- Jaga ukuran tiap video di bawah 10 MB; total aset kecil membuat loading screen cepat.

## 2. Konversi dengan ffmpeg

### 2.1 Normalisasi video (intro dan loading)

Perintah ini menyeragamkan resolusi, piksel format, codec, dan faststart:

```bash
ffmpeg -i input.mp4 -vf "scale=1280:-2,format=yuv420p" -c:v libx264 -preset medium -crf 23 -c:a aac -movflags +faststart output.mp4
```

- `scale=1280:-2` menjaga rasio aspek dan memastikan tinggi genap (syarat yuv420p).
- `format=yuv420p` wajib untuk kompatibilitas Android dan browser.
- `crf 23` keseimbangan kualitas/ukuran; naikkan ke 26-28 bila file masih terlalu besar.

Untuk video loading yang loopable, pangkas bagian akhir yang tidak menyambung:

```bash
ffmpeg -i input.mp4 -t 15 -vf "scale=1280:-2,format=yuv420p" -c:v libx264 -preset medium -crf 23 -an -movflags +faststart output.mp4
```

(`-an` menghapus audio video loading; overlay musik memakai bgm.mp3.)

### 2.2 Ekstrak audio dari video menjadi BGM

Jika musik latar Anda berasal dari video MP4 ketiga:

```bash
ffmpeg -i video3.mp4 -vn -c:a libmp3lame -b:a 128k bgm.mp3
```

Alternatif dengan container AAC (m4a):

```bash
ffmpeg -i video3.mp4 -vn -c:a aac -b:a 128k bgm.m4a
```

Audioplayers mendukung mp3 maupun aac/m4a; namun simpan sebagai `assets/audio/bgm.mp3` agar tidak perlu mengubah kode. Untuk loop mulus, potong hiasan awal/akhir:

```bash
ffmpeg -i bgm.mp3 -af "afade=t=in:st=0:d=1,afade=t=out:st=58:d=2" bgm_loop.mp3
```

(Contoh di atas untuk durasi 60 detik: fade in 1 detik, fade out 2 detik.)

## 3. Peringatan WebP

- WebP didukung baik di Android maupun Flutter Web; ukurannya jauh lebih kecil dari PNG.
- PASTIKAN ekstensi file sesuai isi sebenarnya: file webp yang direname dari jpg/png bisa gagal dimuat.
- Jika Anda hanya punya PNG/JPEG dan ingin slot tetap `.webp`, konversi dulu:

```bash
ffmpeg -i foto.png foto_baru.webp
```

- Jangan me-rename ekstensi tanpa konversi. Jika lebih mudah, simpan foto sebagai PNG dengan nama file slot yang bertipe `.png` (yaitu `1000023802.png`), dan biarkan dua slot webp tetap webp.

## 4. Cara Mengganti Media

### 4.1 Lewat Admin Panel > Media (direkomendasikan untuk pengguna akhir)

1. Buka aplikasi > tab TENTANG > tombol Admin Panel > login.
2. Masuk modul MEDIA.
3. Pilih slot media dan unggah file dari perangkat (memakai file_picker).
4. File tersimpan di penyimpanan aplikasi dan path-nya langsung dipakai oleh AppSettings (tanpa rebuild).

Cocok untuk pergantian rutin tanpa menyentuh kode. Catatan: media bawaan (placeholder di `assets/`) tetap ada sebagai fallback bila path media kustom tidak tersedia.

### 4.2 Cara manual: replace file di folder assets/

Untuk pengembang yang mem-build APK/Web sendiri:

1. Siapkan file sesuai spesifikasi di atas dengan nama persis sama.
2. Timpa file di folder:

```
assets/videos/intro.mp4
assets/videos/loading.mp4
assets/audio/bgm.mp3
assets/images/1000023802.png
assets/images/1000014144.webp
assets/images/1000014143.webp
assets/images/forge_logo.png
```

3. Jalankan:

```bash
flutter clean
flutter pub get
flutter run
```

`flutter clean` penting bila Anda mengganti aset dengan ukuran/nama sama tetapi build lama masih ter-cache; pada web, juga hapus cache browser bila perlu.

4. Build ulang APK/Web setelah penggantian (aset dibundel saat build).

## 5. Checklist Akhir Media

- Semua nama file tetap sama.
- Video H.264 + AAC, yuv420p, di bawah 10 MB per file.
- bgm.mp3 berloop mulus, 96-192 kbps.
- Foto carousel tidak blur di 1280x720 / 1080x1350.
- Logo transparan dan tajam.
- Aplikasi diuji ulang di Android dan Chrome setelah replace.
