# Voice Changer Android

Starter project Android native (Kotlin) untuk pemrosesan suara langsung.

## Fitur
- Normal, Robot, Echo, dan Radio
- Input mikrofon dan output speaker/headset secara real-time
- UI gelap modern
- Izin mikrofon diminta saat pengguna menekan MULAI

## Cara membuka dan membangun APK
1. Ekstrak ZIP ini.
2. Buka folder `VoiceChangerAndroid` di Android Studio (versi yang mendukung Android Gradle Plugin 8.7.3).
3. Tunggu Gradle Sync selesai.
4. Hubungkan HP Android atau gunakan emulator, lalu tekan Run.
5. Untuk APK: pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Catatan
- Ini adalah starter project sumber, bukan APK yang sudah dikompilasi.
- Real-time audio memakai jalur mikrofon-ke-output; latensi bergantung perangkat.
- Gunakan headset agar suara keluaran tidak masuk kembali ke mikrofon.
- Efek Robot/Echo/Radio adalah efek DSP sederhana, bukan kloning suara atau pengubah identitas suara.
- Pada beberapa perangkat, routing audio dan izin mikrofon dapat berbeda.
