import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:audioplayers/audioplayers.dart';
import 'dart:convert';

// ================= KONFIGURASI =================
const String API_URL = 'http://nashapanel.hyungseok.web.id:2165/api'; // 👈 GANTI URL PTERO
// ===============================================

void main() => runApp(const VenusApp());

class VenusApp extends StatelessWidget {
  const VenusApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Venus V1',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF050508),
        textTheme: GoogleFonts.shareTechMonoTextTheme(Theme.of(context).textTheme),
        primaryColor: const Color(0xFF00F3FF),
      ),
      home: const SplashScreen(),
    );
  }
}

// ================= 1. SPLASH SCREEN =================
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _checkSession();
  }

  Future<void> _checkSession() async {
    await Future.delayed(const Duration(seconds: 3)); // Loading 3 detik
    final prefs = await SharedPreferences.getInstance();
    final role = prefs.getString('role');

    if (!mounted) return;
    if (role != null) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => MainScreen(role: role, username: prefs.getString('username') ?? 'User')));
    } else {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.security, size: 100, color: Color(0xFF00F3FF)),
            const SizedBox(height: 20),
            const Text("VENUS V1", style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold, color: Color(0xFF00F3FF), letterSpacing: 5, shadows: [Shadow(color: Color(0xFF00F3FF), blurRadius: 25)])),
            const SizedBox(height: 20),
            const CircularProgressIndicator(color: Color(0xFF00F3FF)),
            const SizedBox(height: 20),
            const Text("Initializing System...", style: TextStyle(color: Colors.grey, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}

// ================= 2. LOGIN SCREEN =================
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _user = TextEditingController();
  final _pass = TextEditingController();
  bool _loading = false;

  Future<void> _login() async {
    if (_user.text.isEmpty || _pass.text.isEmpty) return;
    setState(() => _loading = true);

    try {
      final res = await http.post(Uri.parse('$API_URL/login'), headers: {'Content-Type': 'application/json'}, body: jsonEncode({'username': _user.text, 'password': _pass.text}));
      final data = jsonDecode(res.body);

      if (data['success']) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('username', _user.text);
        await prefs.setString('role', data['role']);
        
        if (!mounted) return;
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => MainScreen(role: data['role'], username: _user.text)));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(data['message'])));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Server Offline!")));
    }
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(30),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.fingerprint, size: 100, color: Color(0xFF00F3FF)),
              const SizedBox(height: 20),
              const Text("SYSTEM LOGIN", style: TextStyle(fontSize: 24, color: Color(0xFF00F3FF), letterSpacing: 3)),
              const SizedBox(height: 40),
              TextField(controller: _user, style: const TextStyle(color: Colors.white), decoration: InputDecoration(labelText: "Username", labelStyle: const TextStyle(color: Colors.grey), filled: true, fillColor: const Color(0xFF0F172A), border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)))),
              const SizedBox(height: 15),
              TextField(controller: _pass, obscureText: true, style: const TextStyle(color: Colors.white), decoration: InputDecoration(labelText: "Password", labelStyle: const TextStyle(color: Colors.grey), filled: true, fillColor: const Color(0xFF0F172A), border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)))),
              const SizedBox(height: 30),
              _loading ? const CircularProgressIndicator(color: Color(0xFF00F3FF)) : SizedBox(
                width: double.infinity, height: 55,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF00F3FF), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                  onPressed: _login,
                  child: const Text("CONNECT", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 16, letterSpacing: 2)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ================= 3. MAIN SCREEN (DASHBOARD & NAVIGATION) =================
class MainScreen extends StatefulWidget {
  final String role;
  final String username;
  const MainScreen({super.key, required this.role, required this.username});
  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    // List halaman yang bakal ditampilin di Bottom Nav
    final screens = [
      DashboardTab(username: widget.username, role: widget.role),
      BugTab(role: widget.role),
      ProfileTab(username: widget.username, role: widget.role),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFF050508),
      appBar: AppBar(
        title: const Text("VENUS V1", style: TextStyle(color: Color(0xFF00F3FF), letterSpacing: 2)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(icon: const Icon(Icons.music_note, color: Color(0xFF00F3FF)), onPressed: () {}),
        ],
      ),
      body: screens[_currentIndex],
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [Color(0xFF0F172A), Color(0xFF1E293B)], begin: Alignment.topLeft, end: Alignment.bottomRight),
          border: Border(top: BorderSide(color: Color(0xFF00F3FF), width: 1)),
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) => setState(() => _currentIndex = index),
          backgroundColor: Colors.transparent,
          selectedItemColor: const Color(0xFF00F3FF),
          unselectedItemColor: Colors.grey,
          type: BottomNavigationBarType.fixed,
          elevation: 0,
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.dashboard), label: "Dashboard"),
            BottomNavigationBarItem(icon: Icon(Icons.bug_report), label: "Bug Tools"),
            BottomNavigationBarItem(icon: Icon(Icons.person), label: "Akun"),
          ],
        ),
      ),
    );
  }
}

// ================= 4. TAB DASHBOARD (FITUR UTAMA) =================
class DashboardTab extends StatelessWidget {
  final String username;
  final String role;
  const DashboardTab({super.key, required this.username, required this.role});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Welcome back,", style: TextStyle(color: Colors.grey[400], fontSize: 14)),
                  Text(username, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                ],
              ),
              CircleAvatar(
                radius: 25,
                backgroundColor: const Color(0xFF00F3FF).withOpacity(0.2),
                child: const Icon(Icons.person, color: Color(0xFF00F3FF)),
              )
            ],
          ),
          const SizedBox(height: 30),

          // Info Card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [const Color(0xFF1E293B), const Color(0xFF0F172A)], begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF00F3FF).withOpacity(0.3)),
              boxShadow: [BoxShadow(color: const Color(0xFF00F3FF).withOpacity(0.1), blurRadius: 20)],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("STATUS AKUN", style: TextStyle(color: Color(0xFF00F3FF), fontSize: 12, letterSpacing: 1)),
                const SizedBox(height: 10),
                Text("Role: ${role.toUpperCase()}", style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 5),
                const Text("Server: Terhubung", style: TextStyle(color: Colors.green, fontSize: 12)),
              ],
            ),
          ),
          const SizedBox(height: 30),

          // Grid Menu Fitur (Visual Only)
          const Text("MENU FITUR", style: TextStyle(color: Colors.grey, fontSize: 12, letterSpacing: 1)),
          const SizedBox(height: 15),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 15,
            mainAxisSpacing: 15,
            childAspectRatio: 1.5,
            children: [
              _buildFeatureCard(Icons.mobile_screen_share, "Sender Manager", Colors.purpleAccent),
              _buildFeatureCard(Icons.image, "AI Image", Colors.blueAccent),
              _buildFeatureCard(Icons.download, "Media Downloader", Colors.orangeAccent),
              _buildFeatureCard(Icons.group, "Group Manager", Colors.greenAccent),
            ],
          )
        ],
      ),
    );
  }

  Widget _buildFeatureCard(IconData icon, String title, Color color) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 30),
          const SizedBox(height: 10),
          Text(title, style: const TextStyle(color: Colors.white, fontSize: 12), textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

// ================= 5. TAB BUG TOOLS (CRASH, DELAY, SPAM) =================
class BugTab extends StatefulWidget {
  final String role;
  const BugTab({super.key, required this.role});
  @override
  State<BugTab> createState() => _BugTabState();
}

class _BugTabState extends State<BugTab> {
  final _target = TextEditingController();
  String _selectedBug = 'crash';
  bool _loading = false;

  // Pilihan Bug
  final List<Map<String, String>> _bugList = [
    {'id': 'crash', 'name': 'CRASH', 'icon': '💀', 'desc': 'Android Force Close'},
    {'id': 'delay', 'name': 'DELAY', 'icon': '⏱️', 'desc': 'Blank Screen'},
    {'id': 'spam', 'name': 'SPAM', 'icon': '💣', 'desc': 'Massive Message'},
  ];

  Future<void> _executeBug() async {
    if (_target.text.isEmpty) return;
    setState(() => _loading = true);

    try {
      final res = await http.post(
        Uri.parse('$API_URL/execute'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'target': _target.text, 'mode': _selectedBug, 'senderId': 'global'}),
      );
      final data = jsonDecode(res.body);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(data['message'])));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Server Error!")));
    }
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("TARGET NUMBER", style: TextStyle(color: Color(0xFF00F3FF), fontSize: 12, letterSpacing: 1)),
          const SizedBox(height: 8),
          TextField(
            controller: _target,
            keyboardType: TextInputType.phone,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: "Masukkan Nomor (628xxx)",
              hintStyle: const TextStyle(color: Colors.grey),
              filled: true,
              fillColor: const Color(0xFF0F172A),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
              prefixIcon: const Icon(Icons.phone, color: Color(0xFF00F3FF)),
            ),
          ),
          const SizedBox(height: 30),

          const Text("SELECT BUG TYPE", style: TextStyle(color: Color(0xFF00F3FF), fontSize: 12, letterSpacing: 1)),
          const SizedBox(height: 15),
          
          // Grid Bug
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              childAspectRatio: 1.1,
            ),
            itemCount: _bugList.length,
            itemBuilder: (context, index) {
              final bug = _bugList[index];
              final isActive = _selectedBug == bug['id'];
              return GestureDetector(
                onTap: () => setState(() => _selectedBug = bug['id']!),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  decoration: BoxDecoration(
                    color: isActive ? const Color(0xFF00F3FF).withOpacity(0.2) : const Color(0xFF0F172A),
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: isActive ? const Color(0xFF00F3FF) : Colors.grey.withOpacity(0.3), width: isActive ? 2 : 1),
                    boxShadow: isActive ? [BoxShadow(color: const Color(0xFF00F3FF).withOpacity(0.2), blurRadius: 10)] : [],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(bug['icon']!, style: const TextStyle(fontSize: 24)),
                      const SizedBox(height: 8),
                      Text(bug['name']!, style: TextStyle(color: isActive ? Colors.white : Colors.grey, fontSize: 10, fontWeight: FontWeight.bold)),
                      Text(bug['desc']!, style: const TextStyle(color: Colors.grey, fontSize: 7), textAlign: TextAlign.center),
                    ],
                  ),
                ),
              );
            },
          ),
          
          const SizedBox(height: 40),

          _loading ? const Center(child: CircularProgressIndicator(color: Color(0xFF00F3FF))) : SizedBox(
            width: double.infinity, height: 55,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFF0055),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                elevation: 10,
                shadowColor: const Color(0xFFFF0055),
              ),
              onPressed: _executeBug,
              child: const Text("LAUNCH ATTACK 🚀", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16, letterSpacing: 2)),
            ),
          ),
        ],
      ),
    );
  }
}

// ================= 6. TAB PROFILE =================
class ProfileTab extends StatelessWidget {
  final String username;
  final String role;
  const ProfileTab({super.key, required this.username, required this.role});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const CircleAvatar(radius: 60, backgroundColor: Color(0xFF0F172A), child: Icon(Icons.person, size: 60, color: Color(0xFF00F3FF))),
          const SizedBox(height: 20),
          Text(username, style: const TextStyle(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold)),
          Text("Role: ${role.toUpperCase()}", style: const TextStyle(fontSize: 14, color: Color(0xFF00F3FF))),
          const SizedBox(height: 40),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              if (context.mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
            },
            child: const Text("LOGOUT", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }
}