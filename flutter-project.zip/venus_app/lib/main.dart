import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'package:audioplayers/audioplayers.dart';
import 'dart:convert';
import 'dart:async';

// ================= KONFIGURASI =================
const String API_URL = 'http://nashapanel.hyungseok.web.id:2165/api'; // 👈 GANTI URL PTERO
const String VIDEO_LOADING = 'https://files.catbox.moe/kqeev5.mp4'; // 👈 VIDEO LOADING
const String VIDEO_DASHBOARD = 'https://files.catbox.moe/3tzk4c.mp4'; // 👈 VIDEO DASHBOARD
const String MUSIC_URL = 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3'; // 👈 BGM
// ===============================================

void main() => runApp(const VenusApp());

class VenusApp extends StatelessWidget {
  const VenusApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF050508),
        textTheme: GoogleFonts.shareTechMonoTextTheme(Theme.of(context).textTheme),
      ),
      home: const SplashScreen(),
    );
  }
}

// ================= WIDGET VIDEO BACKGROUND =================
class VideoBackground extends StatefulWidget {
  final String videoUrl;
  final Widget child;
  const VideoBackground({super.key, required this.videoUrl, required this.child});
  @override
  State<VideoBackground> createState() => _VideoBackgroundState();
}

class _VideoBackgroundState extends State<VideoBackground> {
  late VideoPlayerController _controller;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.networkUrl(Uri.parse(widget.videoUrl))
      ..initialize().then((_) {
        _controller.setLooping(true);
        _controller.setVolume(0);
        _controller.play();
        setState(() {});
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        if (_controller.value.isInitialized)
          SizedBox.expand(
            child: FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _controller.value.size.width,
                height: _controller.value.size.height,
                child: VideoPlayer(_controller),
              ),
            ),
          ),
        Container(color: Colors.black.withOpacity(0.7)),
        widget.child,
      ],
    );
  }
}

// ================= 1. SPLASH SCREEN =================
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _checkSession();
  }

  Future<void> _checkSession() async {
    await Future.delayed(const Duration(seconds: 4));
    final prefs = await SharedPreferences.getInstance();
    final role = prefs.getString('role');

    if (!mounted) return;
    if (role != null) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => MainScreen(role: role, username: prefs.getString('username') ?? 'User')));
    } else {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: VideoBackground(
        videoUrl: VIDEO_LOADING, // Video Loading
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.security, size: 100, color: Color(0xFF00F3FF)),
              const SizedBox(height: 20),
              const Text("VENUS V1", style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold, color: Color(0xFF00F3FF), letterSpacing: 5, shadows: [Shadow(color: Color(0xFF00F3FF), blurRadius: 25)])),
              const SizedBox(height: 20),
              const CircularProgressIndicator(color: Color(0xFF00F3FF)),
              const SizedBox(height: 20),
              const Text("Initializing System...", style: TextStyle(color: Colors.white70, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}

// ================= 2. LOGIN SCREEN =================
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _user = TextEditingController();
  final _pass = TextEditingController();
  bool _loading = false;

  Future<void> _login() async {
    if (_user.text.isEmpty || _pass.text.isEmpty) return;
    setState(() => _loading = true);

    try {
      final res = await http.post(Uri.parse('$API_URL/login'), headers: {'Content-Type': 'application/json'}, body: jsonEncode({'username': _user.text, 'password': _pass.text}));
      final data = jsonDecode(res.body);

      if (data['success']) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('username', _user.text);
        await prefs.setString('role', data['role']);
        
        if (!mounted) return;
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => MainScreen(role: data['role'], username: _user.text)));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(data['message'])));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Server Offline!")));
    }
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: VideoBackground(
        videoUrl: VIDEO_LOADING, // Pake video loading juga (atau ganti sendiri)
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(30),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.fingerprint, size: 100, color: Color(0xFF00F3FF)),
                const SizedBox(height: 20),
                const Text("SYSTEM LOGIN", style: TextStyle(fontSize: 24, color: Color(0xFF00F3FF), letterSpacing: 3)),
                const SizedBox(height: 40),
                TextField(controller: _user, style: const TextStyle(color: Colors.white), decoration: InputDecoration(labelText: "Username", labelStyle: const TextStyle(color: Colors.grey), filled: true, fillColor: Colors.black.withOpacity(0.5), border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)))),
                const SizedBox(height: 15),
                TextField(controller: _pass, obscureText: true, style: const TextStyle(color: Colors.white), decoration: InputDecoration(labelText: "Password", labelStyle: const TextStyle(color: Colors.grey), filled: true, fillColor: Colors.black.withOpacity(0.5), border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)))),
                const SizedBox(height: 30),
                _loading ? const CircularProgressIndicator(color: Color(0xFF00F3FF)) : SizedBox(
                  width: double.infinity, height: 55,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF00F3FF), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                    onPressed: _login,
                    child: const Text("CONNECT", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 16, letterSpacing: 2)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ================= 3. MAIN SCREEN (PAKE VIDEO DASHBOARD) =================
class MainScreen extends StatefulWidget {
  final String role;
  final String username;
  const MainScreen({super.key, required this.role, required this.username});
  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isMusicPlaying = false;
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _playMusic();
  }

  void _playMusic() async {
    await _audioPlayer.play(UrlSource(MUSIC_URL));
    _audioPlayer.setReleaseMode(ReleaseMode.loop);
    setState(() => _isMusicPlaying = true);
  }

  void _toggleMusic() async {
    if (_isMusicPlaying) {
      await _audioPlayer.pause();
    } else {
      await _audioPlayer.resume();
    }
    setState(() => _isMusicPlaying = !_isMusicPlaying);
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isPrivileged = widget.role == 'owner' || widget.role == 'reseller' || widget.role == 'pt';
    
    final screens = [
      DashboardTab(username: widget.username, role: widget.role),
      BugTab(role: widget.role),
      if (isPrivileged) SenderTab(role: widget.role),
      ProfileTab(username: widget.username, role: widget.role),
    ];

    return Scaffold(
      body: VideoBackground(
        videoUrl: VIDEO_DASHBOARD, // Video Dashboard
        child: Stack(
          children: [
            screens[_currentIndex],
            Positioned(
              top: 50,
              right: 20,
              child: IconButton(
                icon: Icon(_isMusicPlaying ? Icons.music_note : Icons.music_off, color: const Color(0xFF00F3FF), size: 30),
                onPressed: _toggleMusic,
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [Color(0xFF0F172A), Color(0xFF1E293B)]),
          border: Border(top: BorderSide(color: Color(0xFF00F3FF), width: 1)),
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) => setState(() => _currentIndex = index),
          backgroundColor: Colors.transparent,
          selectedItemColor: const Color(0xFF00F3FF),
          unselectedItemColor: Colors.grey,
          type: BottomNavigationBarType.fixed,
          elevation: 0,
          items: [
            const BottomNavigationBarItem(icon: Icon(Icons.dashboard), label: "Home"),
            const BottomNavigationBarItem(icon: Icon(Icons.bug_report), label: "Bug Tools"),
            if (isPrivileged) const BottomNavigationBarItem(icon: Icon(Icons.mobile_screen_share), label: "Sender"),
            const BottomNavigationBarItem(icon: Icon(Icons.person), label: "Akun"),
          ],
        ),
      ),
    );
  }
}

// ================= 4. TAB DASHBOARD =================
class DashboardTab extends StatelessWidget {
  final String username;
  final String role;
  const DashboardTab({super.key, required this.username, required this.role});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 60),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Welcome back,", style: TextStyle(color: Colors.grey[400], fontSize: 14)),
                  Text(username, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                ],
              ),
              const CircleAvatar(radius: 25, backgroundColor: Color(0xFF1E293B), child: Icon(Icons.person, color: Color(0xFF00F3FF))),
            ],
          ),
          const SizedBox(height: 30),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.5),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF00F3FF).withOpacity(0.3)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("STATUS AKUN", style: TextStyle(color: Color(0xFF00F3FF), fontSize: 12, letterSpacing: 1)),
                const SizedBox(height: 10),
                Text("Role: ${role.toUpperCase()}", style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 5),
                const Text("Server: Online", style: TextStyle(color: Colors.green, fontSize: 12)),
              ],
            ),
          ),
          const SizedBox(height: 30),
          const Text("MENU FITUR", style: TextStyle(color: Colors.grey, fontSize: 12, letterSpacing: 1)),
          const SizedBox(height: 15),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 15,
            mainAxisSpacing: 15,
            childAspectRatio: 1.5,
            children: [
              _buildCard(Icons.mobile_screen_share, "Sender Manager", Colors.purpleAccent),
              _buildCard(Icons.image, "AI Image", Colors.blueAccent),
              _buildCard(Icons.download, "Media", Colors.orangeAccent),
              _buildCard(Icons.group, "Group", Colors.greenAccent),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCard(IconData icon, String title, Color color) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.6),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 30),
          const SizedBox(height: 10),
          Text(title, style: const TextStyle(color: Colors.white, fontSize: 12)),
        ],
      ),
    );
  }
}

// ================= 5. TAB BUG TOOLS =================
class BugTab extends StatefulWidget {
  final String role;
  const BugTab({super.key, required this.role});
  @override
  State<BugTab> createState() => _BugTabState();
}

class _BugTabState extends State<BugTab> {
  final _target = TextEditingController();
  String _selectedBug = 'crash';
  bool _loading = false;

  final List<Map<String, String>> _bugList = [
    {'id': 'crash', 'name': 'CRASH', 'icon': '💀', 'desc': 'Android Force Close'},
    {'id': 'delay', 'name': 'DELAY', 'icon': '⏱️', 'desc': 'Blank Screen'},
    {'id': 'spam', 'name': 'SPAM', 'icon': '💣', 'desc': 'Massive Message'},
  ];

  Future<void> _executeBug() async {
    if (_target.text.isEmpty) return;
    setState(() => _loading = true);

    try {
      final res = await http.post(
        Uri.parse('$API_URL/execute'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'target': _target.text, 'mode': _selectedBug, 'senderId': 'global'}),
      );
      final data = jsonDecode(res.body);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(data['message'])));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Server Error!")));
    }
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 60),
          const Text("TARGET NUMBER", style: TextStyle(color: Color(0xFF00F3FF), fontSize: 12)),
          const SizedBox(height: 8),
          TextField(
            controller: _target,
            keyboardType: TextInputType.phone,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: "628xxx",
              filled: true,
              fillColor: Colors.black.withOpacity(0.5),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 30),
          const Text("SELECT BUG TYPE", style: TextStyle(color: Color(0xFF00F3FF), fontSize: 12)),
          const SizedBox(height: 15),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.1),
            itemCount: _bugList.length,
            itemBuilder: (context, index) {
              final bug = _bugList[index];
              final isActive = _selectedBug == bug['id'];
              return GestureDetector(
                onTap: () => setState(() => _selectedBug = bug['id']!),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  decoration: BoxDecoration(
                    color: isActive ? const Color(0xFF00F3FF).withOpacity(0.2) : Colors.black.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: isActive ? const Color(0xFF00F3FF) : Colors.grey.withOpacity(0.3)),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(bug['icon']!, style: const TextStyle(fontSize: 24)),
                      const SizedBox(height: 8),
                      Text(bug['name']!, style: TextStyle(color: isActive ? Colors.white : Colors.grey, fontSize: 10, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 40),
          _loading ? const Center(child: CircularProgressIndicator(color: Color(0xFF00F3FF))) : SizedBox(
            width: double.infinity, height: 55,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFF0055), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
              onPressed: _executeBug,
              child: const Text("LAUNCH ATTACK 🚀", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
            ),
          ),
        ],
      ),
    );
  }
}

// ================= 6. TAB SENDER =================
class SenderTab extends StatefulWidget {
  final String role;
  const SenderTab({super.key, required this.role});
  @override
  State<SenderTab> createState() => _SenderTabState();
}

class _SenderTabState extends State<SenderTab> {
  final _number = TextEditingController();
  bool _loading = false;
  String? _pairingCode;
  Timer? _pollingTimer;

  Future<void> _addSender() async {
    if (_number.text.isEmpty) return;
    setState(() => _loading = true);

    final clean = _number.text.replaceAll(RegExp(r'[^0-9]'), '').replaceFirst(RegExp(r'^0'), '62');

    try {
      final res = await http.post(
        Uri.parse('$API_URL/add-sender'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'number': clean, 'role': widget.role}),
      );
      final data = jsonDecode(res.body);
      if (data['success']) {
        _startPolling(data['senderId']);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(data['message'])));
      }
    } cat