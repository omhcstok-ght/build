import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

// ================= KONFIGURASI =================
const String API_URL = 'http://nashapanel.hyungseok.web.id:2165/api'; // 👈 GANTI URL PTERO LO
// ===============================================

void main() => runApp(const VenusApp());

class VenusApp extends StatelessWidget {
  const VenusApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Venus V1',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF050508),
        textTheme: GoogleFonts.shareTechMonoTextTheme(Theme.of(context).textTheme),
      ),
      home: const SplashScreen(),
    );
  }
}

// ================= 1. SPLASH SCREEN =================
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _checkSession();
  }

  Future<void> _checkSession() async {
    await Future.delayed(const Duration(seconds: 3));
    final prefs = await SharedPreferences.getInstance();
    final role = prefs.getString('role');

    if (!mounted) return;
    if (role != null) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => MainScreen(role: role, username: prefs.getString('username') ?? 'User')));
    } else {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.security, size: 100, color: Color(0xFF00F3FF)),
            SizedBox(height: 20),
            Text("VENUS V1", style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold, color: Color(0xFF00F3FF), letterSpacing: 5, shadows: [Shadow(color: Color(0xFF00F3FF), blurRadius: 25)])),
            SizedBox(height: 20),
            CircularProgressIndicator(color: Color(0xFF00F3FF)),
          ],
        ),
      ),
    );
  }
}

// ================= 2. LOGIN SCREEN =================
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _user = TextEditingController();
  final _pass = TextEditingController();
  bool _loading = false;

  Future<void> _login() async {
    if (_user.text.isEmpty || _pass.text.isEmpty) return;
    setState(() => _loading = true);

    try {
      final res = await http.post(Uri.parse('$API_URL/login'), headers: {'Content-Type': 'application/json'}, body: jsonEncode({'username': _user.text, 'password': _pass.text}));
      final data = jsonDecode(res.body);

      if (data['success']) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('username', _user.text);
        await prefs.setString('role', data['role']);
        
        if (!mounted) return;
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => MainScreen(role: data['role'], username: _user.text)));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(data['message'])));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Server Offline!")));
    }
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(30),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.fingerprint, size: 100, color: Color(0xFF00F3FF)),
              const SizedBox(height: 20),
              const Text("SYSTEM LOGIN", style: TextStyle(fontSize: 24, color: Color(0xFF00F3FF), letterSpacing: 3)),
              const SizedBox(height: 40),
              TextField(controller: _user, decoration: const InputDecoration(labelText: "Username", filled: true, fillColor: Color(0xFF0F172A), border: OutlineInputBorder())),
              const SizedBox(height: 15),
              TextField(controller: _pass, obscureText: true, decoration: const InputDecoration(labelText: "Password", filled: true, fillColor: Color(0xFF0F172A), border: OutlineInputBorder())),
              const SizedBox(height: 30),
              _loading ? const CircularProgressIndicator(color: Color(0xFF00F3FF)) : SizedBox(
                width: double.infinity, height: 55,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF00F3FF), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                  onPressed: _login,
                  child: const Text("CONNECT", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 16)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ================= 3. MAIN SCREEN (NAVIGATION) =================
class MainScreen extends StatefulWidget {
  final String role;
  final String username;
  const MainScreen({super.key, required this.role, required this.username});
  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    final screens = [
      DashboardTab(username: widget.username, role: widget.role),
      BugTab(role: widget.role),
      ProfileTab(username: widget.username, role: widget.role),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("VENUS V1", style: TextStyle(color: Color(0xFF00F3FF), letterSpacing: 2)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings, color: Color(0xFF00F3FF)),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingScreen()));
            },
          )
        ],
      ),
      body: screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        backgroundColor: const Color(0xFF0F172A),
        selectedItemColor: const Color(0xFF00F3FF),
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.bug_report), label: "Bug"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Akun"),
        ],
      ),
    );
  }
}

// ================= 4. DASHBOARD TAB =================
class DashboardTab extends StatelessWidget {
  final String username;
  final String role;
  const DashboardTab({super.key, required this.username, required this.role});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("Welcome back,", style: TextStyle(color: Colors.grey, fontSize: 14)),
                  Text(username, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                ],
              ),
              const CircleAvatar(radius: 25, backgroundColor: Color(0xFF1E293B), child: Icon(Icons.person, color: Color(0xFF00F3FF))),
            ],
          ),
          const SizedBox(height: 30),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF1E293B), Color(0xFF0F172A)]),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF00F3FF).withOpacity(0.3)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("STATUS AKUN", style: TextStyle(color: Color(0xFF00F3FF), fontSize: 12)),
                const SizedBox(height: 10),
                Text("Role: ${role.toUpperCase()}", style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 5),
                const Text("Server: Online", style: TextStyle(color: Colors.green, fontSize: 12)),
              ],
            ),
          ),
          const SizedBox(height: 30),
          const Text("MENU FITUR", style: TextStyle(color: Colors.grey, fontSize: 12)),
          const SizedBox(height: 15),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 15,
            mainAxisSpacing: 15,
            childAspectRatio: 1.5,
            children: [
              _buildCard(Icons.mobile_screen_share, "Sender", Colors.purpleAccent),
              _buildCard(Icons.image, "AI Image", Colors.blueAccent),
              _buildCard(Icons.download, "Media", Colors.orangeAccent),
              _buildCard(Icons.group, "Group", Colors.greenAccent),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCard(IconData icon, String title, Color color) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 30),
          const SizedBox(height: 10),
          Text(title, style: const TextStyle(color: Colors.white, fontSize: 12)),
        ],
      ),
    );
  }
}

// ================= 5. BUG TAB =================
class BugTab extends StatefulWidget {
  final String role;
  const BugTab({super.key, required this.role});
  @override
  State<BugTab> createState() => _BugTabState();
}

class _BugTabState extends State<BugTab> {
  final _target = TextEditingController();
  String _selectedBug = 'crash';
  bool _loading = false;

  final List<Map<String, String>> _bugList = [
    {'id': 'crash', 'name': 'CRASH', 'icon': '💀'},
    {'id': 'delay', 'name': 'DELAY', 'icon': '⏱️'},
    {'id': 'spam', 'name': 'SPAM', 'icon': '💣'},
  ];

  Future<void> _executeBug() async {
    if (_target.text.isEmpty) return;
    setState(() => _loading = true);

    try {
      final res = await http.post(
        Uri.parse('$API_URL/execute'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'target': _target.text, 'mode': _selectedBug, 'senderId': 'global'}),
      );
      final data = jsonDecode(res.body);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(data['message'])));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Server Error!")));
    }
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("TARGET NUMBER", style: TextStyle(color: Color(0xFF00F3FF), fontSize: 12)),
          const SizedBox(height: 8),
          TextField(controller: _target, keyboardType: TextInputType.phone, decoration: const InputDecoration(hintText: "628xxx", filled: true, fillColor: Color(0xFF0F172A), border: OutlineInputBorder())),
          const SizedBox(height: 30),
          const Text("SELECT BUG TYPE", style: TextStyle(color: Color(0xFF00F3FF), fontSize: 12)),
          const SizedBox(height: 15),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.1),
            itemCount: _bugList.length,
            itemBuilder: (context, index) {
              final bug = _bugList[index];
              final isActive = _selectedBug == bug['id'];
              return GestureDetector(
                onTap: () => setState(() => _selectedBug = bug['id']!),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  decoration: BoxDecoration(
                    color: isActive ? const Color(0xFF00F3FF).withOpacity(0.2) : const Color(0xFF0F172A),
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: isActive ? const Color(0xFF00F3FF) : Colors.grey.withOpacity(0.3)),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(bug['icon']!, style: const TextStyle(fontSize: 24)),
                      const SizedBox(height: 8),
                      Text(bug['name']!, style: TextStyle(color: isActive ? Colors.white : Colors.grey, fontSize: 10, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 40),
          _loading ? const Center(child: CircularProgressIndicator()) : SizedBox(
            width: double.infinity, height: 55,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFF0055), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
              onPressed: _executeBug,
              child: const Text("LAUNCH ATTACK 🚀", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
            ),
          ),
        ],
      ),
    );
  }
}

// ================= 6. TAB PROFILE =================
class ProfileTab extends StatelessWidget {
  final String username;
  final String role;
  const ProfileTab({super.key, required this.username, required this.role});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const CircleAvatar(radius: 60, backgroundColor: Color(0xFF0F172A), child: Icon(Icons.person, size: 60, color: Color(0xFF00F3FF))),
          const SizedBox(height: 20),
          Text(username, style: const TextStyle(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold)),
          Text("Role: ${role.toUpperCase()}", style: const TextStyle(fontSize: 14, color: Color(0xFF00F3FF))),
          const SizedBox(height: 40),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              if (context.mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
            },
            child: const Text("LOGOUT", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }
}

// ================= 7. SETTING SCREEN =================
class SettingScreen extends StatefulWidget {
  const SettingScreen({super.key});
  @override
  State<SettingScreen> createState() => _SettingScreenState();
}

class _SettingScreenState extends State<SettingScreen> {
  bool _notifEnabled = true;
  bool _darkMode = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("SETTINGS"), backgroundColor: Colors.transparent, elevation: 0),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          SwitchListTile(
            title: const Text("Notifikasi"),
            subtitle: const Text("Aktifkan notifikasi bug"),
            value: _notifEnabled,
            activeColor: const Color(0xFF00F3FF),
            onChanged: (val) => setState(() => _notifEnabled = val),
          ),
          SwitchListTile(
            title: const Text("Dark Mode"),
            subtitle: const Text("Tema gelap"),
            value: _darkMode,
            activeColor: const Color(0xFF00F3FF),
            onChanged: (val) => setState(() => _darkMode = val),
          ),
          const SizedBox(height: 20),
          ListTile(
            leading: const Icon(Icons.info, color: Color(0xFF00F3FF)),
            title: const Text("Tentang Aplikasi"),
            subtitle: const Text("Venus V1 - Premium Tools"),
            onTap: () {},
          ),
          ListTile(
            leading: const Icon(Icons.security, color: Color(0xFF00F3FF)),
            title: const Text("Kebijakan Privasi"),
            onTap: () {},
          ),
        ],
      ),
    );
  }
}