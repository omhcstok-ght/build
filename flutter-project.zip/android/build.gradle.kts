allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

val newBuildDir: Directory = rootProject.layout.buildDirectory.dir("../../build").get()
rootProject.layout.buildDirectory.value(newBuildDir)

subprojects {
    val newSubprojectBuildDir: Directory = newBuildDir.dir(project.name)
    project.layout.buildDirectory.value(newSubprojectBuildDir)
}

// ═══════════════════════════════════════════════════════════
// ⚠️ CATATAN PERBAIKAN:
// Baris `subprojects { project.evaluationDependsOn(":app") }` 
// SUDAH DIHAPUS karena memicu error "Install NDK failed" di CI/CD.
// ═══════════════════════════════════════════════════════════

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}