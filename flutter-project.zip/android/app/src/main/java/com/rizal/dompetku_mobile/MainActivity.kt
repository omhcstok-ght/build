
package com.rizal.dompetku_mobile
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
