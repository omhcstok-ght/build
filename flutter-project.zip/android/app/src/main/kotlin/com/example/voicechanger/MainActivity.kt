package com.example.voicechanger

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
