@echo off
echo This project ZIP is configured for Linux Flutter build runners.
echo Use android\gradlew from a Linux or CI environment.
exit /b 1
