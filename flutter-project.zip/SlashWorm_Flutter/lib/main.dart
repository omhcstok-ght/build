import 'dart:math' as math;
import 'package:flutter/material.dart';

void main() => runApp(const SlashWormApp());

const bg = Color(0xFF080D1B);
const mint = Color(0xFF00E6B8);
const panel = Color(0xFF111B2D);

class SlashWormApp extends StatelessWidget {
  const SlashWormApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'SlashWorm',
    theme: ThemeData.dark().copyWith(
      scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: mint, brightness: Brightness.dark),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: panel,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      ),
    ),
    home: const AuthScreen(),
  );
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}
class _AuthScreenState extends State<AuthScreen> {
  final name = TextEditingController();
  final pass = TextEditingController();
  bool register = false;
  void enter() {
    if (name.text.trim().isEmpty || pass.text.length < 4) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Isi username dan password minimal 4 karakter.')));
      return;
    }
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => HomeScreen(player: name.text.trim())));
  }
  @override
  void dispose() { name.dispose(); pass.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(26), child: Column(
      mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.bubble_chart_rounded, color: mint, size: 76),
        const SizedBox(height: 8),
        const Text('SLASHWORM', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 3, color: mint)),
        const SizedBox(height: 6),
        const Text('GROW BIG • MOVE FAST • RULE THE ARENA', style: TextStyle(fontSize: 10, letterSpacing: 1.4, color: Colors.white60)),
        const SizedBox(height: 38),
        Text(register ? 'CREATE ACCOUNT' : 'WELCOME BACK', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 20),
        TextField(controller: name, decoration: const InputDecoration(prefixIcon: Icon(Icons.person_outline), hintText: 'Username')),
        const SizedBox(height: 12),
        TextField(controller: pass, obscureText: true, decoration: const InputDecoration(prefixIcon: Icon(Icons.lock_outline), hintText: 'Password')),
        const SizedBox(height: 20),
        SizedBox(width: double.infinity, height: 52, child: FilledButton(
          style: FilledButton.styleFrom(backgroundColor: mint, foregroundColor: bg),
          onPressed: enter, child: Text(register ? 'REGISTER' : 'LOGIN', style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
        )),
        TextButton(onPressed: () => setState(() => register = !register),
          child: Text(register ? 'Sudah punya akun? Login' : 'Belum punya akun? Register')),
        const SizedBox(height: 10),
        const Text('Prototype offline • akun demo lokal', style: TextStyle(color: Colors.white38, fontSize: 11)),
      ],
    )))),
  );
}

class HomeScreen extends StatelessWidget {
  final String player;
  const HomeScreen({super.key, required this.player});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: Padding(padding: const EdgeInsets.all(26), child: Column(
      mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.bubble_chart_rounded, color: mint, size: 70),
        const Text('SLASHWORM', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: mint, letterSpacing: 2)),
        Text('PLAYER  ${player.toUpperCase()}', style: const TextStyle(color: Colors.white70, letterSpacing: 1)),
        const SizedBox(height: 34),
        SizedBox(width: double.infinity, height: 56, child: FilledButton(
          style: FilledButton.styleFrom(backgroundColor: mint, foregroundColor: bg),
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GameScreen())),
          child: const Text('PLAY NOW', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2)),
        )),
        const SizedBox(height: 12),
        _MenuTile(icon: Icons.palette_outlined, title: 'Worm skins', subtitle: 'More looks coming soon'),
        _MenuTile(icon: Icons.emoji_events_outlined, title: 'Leaderboard', subtitle: 'Online leaderboard coming soon'),
        _MenuTile(icon: Icons.settings_outlined, title: 'Settings', subtitle: 'Sound and graphics coming soon'),
        const SizedBox(height: 20),
        TextButton(onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AuthScreen())), child: const Text('LOG OUT')),
      ],
    )))),
  );
}
class _MenuTile extends StatelessWidget {
  final IconData icon; final String title; final String subtitle;
  const _MenuTile({required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(top: 10), padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)),
    child: Row(children: [Icon(icon, color: mint), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 11))
    ]))]),
  );
}

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});
  @override
  State<GameScreen> createState() => _GameScreenState();
}
class _GameScreenState extends State<GameScreen> with SingleTickerProviderStateMixin {
  late final Ticker ticker;
  Duration last = Duration.zero;
  double angle = -math.pi / 2;
  double score = 0;
  Offset? target;
  bool boost = false;
  final List<Offset> body = List.generate(24, (i) => Offset(0.5, 0.56 + i * 0.009));
  final List<Offset> foods = List.generate(34, (i) => Offset(.08 + ((i * 37) % 83) / 100, .12 + ((i * 53) % 72) / 100));

  @override
  void initState() { super.initState(); ticker = createTicker(_tick)..start(); }
  void _tick(Duration elapsed) {
    final dt = last == Duration.zero ? 0.016 : ((elapsed - last).inMicroseconds / 1e6).clamp(0.0, 0.035);
    last = elapsed;
    if (target != null && mounted) {
      final head = body.first;
      final desired = math.atan2(target!.dy - head.dy, target!.dx - head.dx);
      var diff = (desired - angle + math.pi * 3) % (math.pi * 2) - math.pi;
      angle += diff.clamp(-2.8 * dt, 2.8 * dt);
    }
    final head = body.first;
    final speed = boost ? .72 : .43;
    var next = Offset((head.dx + math.cos(angle) * speed * dt).clamp(.025, .975),
                      (head.dy + math.sin(angle) * speed * dt).clamp(.06, .94));
    body.insert(0, next);
    final desiredLength = 24 + score.toInt() * 2;
    while (body.length > desiredLength) body.removeLast();
    for (var i = 1; i < body.length; i++) {
      final prev = body[i - 1], cur = body[i];
      final delta = prev - cur; final dist = delta.distance;
      if (dist > .018) body[i] = cur + delta / dist * (dist - .018);
    }
    for (var i = 0; i < foods.length; i++) {
      if ((foods[i] - next).distance < .035) {
        score++;
        foods[i] = Offset(.04 + math.Random().nextDouble() * .92, .08 + math.Random().nextDouble() * .84);
      }
    }
    if (mounted) setState(() {});
  }
  @override
  void dispose() { ticker.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: LayoutBuilder(builder: (context, constraints) {
      return GestureDetector(
        onPanStart: (d) => target = Offset(d.localPosition.dx / constraints.maxWidth, d.localPosition.dy / constraints.maxHeight),
        onPanUpdate: (d) {
          target = Offset(d.localPosition.dx / constraints.maxWidth, d.localPosition.dy / constraints.maxHeight);
          boost = d.localPosition.dx > constraints.maxWidth * .72 && d.localPosition.dy > constraints.maxHeight * .72;
        },
        onPanEnd: (_) => boost = false,
        child: Stack(children: [
          Positioned.fill(child: CustomPaint(painter: ArenaPainter(body: body, foods: foods, score: score, angle: angle))),
          Positioned(left: 18, top: 16, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('SCORE  ${score.toInt()}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
            const Text('Drag to steer • hold bottom-right to boost', style: TextStyle(color: Colors.white54, fontSize: 10)),
          ])),
          Positioned(right: 12, top: 8, child: IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.pause_circle_outline, color: Colors.white, size: 30))),
          Positioned(right: 18, bottom: 18, child: Container(
            width: 76, height: 76, decoration: BoxDecoration(shape: BoxShape.circle, color: mint.withOpacity(.18), border: Border.all(color: mint, width: 2)),
            child: const Center(child: Text('BOOST', style: TextStyle(color: mint, fontWeight: FontWeight.w900, fontSize: 11))),
          )),
        ]),
      );
    })),
  );
}

class ArenaPainter extends CustomPainter {
  final List<Offset> body, foods; final double score, angle;
  ArenaPainter({required this.body, required this.foods, required this.score, required this.angle});
  @override
  void paint(Canvas canvas, Size size) {
    final bgPaint = Paint()..color = bg;
    canvas.drawRect(Offset.zero & size, bgPaint);
    final grid = Paint()..color = const Color(0xFF17243A)..strokeWidth = 1;
    for (double x = 0; x < size.width; x += 30) { canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid); }
    for (double y = 0; y < size.height; y += 30) { canvas.drawLine(Offset(0, y), Offset(size.width, y), grid); }
    final foodPaint = Paint()..color = const Color(0xFFFFC15A);
    for (final f in foods) canvas.drawCircle(Offset(f.dx * size.width, f.dy * size.height), 4, foodPaint);
    for (var i = body.length - 1; i >= 0; i--) {
      final p = Offset(body[i].dx * size.width, body[i].dy * size.height);
      final paint = Paint()..color = i == 0 ? const Color(0xFFB5FFF0) : (i % 3 == 0 ? mint : const Color(0xFF00A88E));
      canvas.drawCircle(p, i == 0 ? 10 : 9, paint);
    }
    if (body.isNotEmpty) {
      final h = Offset(body.first.dx * size.width, body.first.dy * size.height);
      final eye = Paint()..color = Colors.white;
      canvas.drawCircle(h + Offset(math.cos(angle - .45) * 4, math.sin(angle - .45) * 4), 2, eye);
      canvas.drawCircle(h + Offset(math.cos(angle + .45) * 4, math.sin(angle + .45) * 4), 2, eye);
    }
  }
  @override
  bool shouldRepaint(covariant ArenaPainter oldDelegate) => true;
}
