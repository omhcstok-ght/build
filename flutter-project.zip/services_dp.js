// ============================================================
// 💰 SERVICES & DP PAYMENT SYSTEM — by Yuzakura Fable Pro 18
// File: services_dp.js
// v9.0 — ULTRA PREMIUM EDITION
// - Full custom emoji premium
// - Testimoni + ACC owner dengan foto tertaut
// - Fallback 4-layer untuk foto
// - Rich styling full
// ============================================================
const fs = require('fs');
const path = require('path');

module.exports = function initServicesDP(bot, ctx = {}) {
  const {
    ADMIN_GROUP_ID = "-18880837641",
    CHANNEL_ID = "-1003664576719",
    INFORMATION_URL = "https://t.me/Mclareninfo",
    telegramIsOwner = () => false,
  } = ctx;

  const PEMBELI_FILE      = path.join(__dirname, 'pembeli.json');
  const PENDING_PAY_FILE  = path.join(__dirname, 'pending_payments.json');
  const OWNER_ACC_FILE    = path.join(__dirname, 'owner_acc.json');
  const GROUP_LINKS_FILE  = path.join(__dirname, 'group_links.json');
  const TELEGRAM_FILE     = path.join(__dirname, 'telegram.json');
  const PAYMENT_INFO_FILE = path.join(__dirname, 'payment_info.json');
  const STORES_FILE       = path.join(__dirname, 'stores.json');
  const QUEUE_FILE        = path.join(__dirname, 'queue.json');

  const DP_MINIMUM = 3000;
  const DP_MAXIMUM = 100000;
  const DP_MAX_DAYS = 5;
  const PAYMENT_TIMEOUT = 20 * 60 * 1000;
  const REMINDER_INTERVAL = 7 * 60 * 60 * 1000;
  const STORE_EXPIRY_CHECK = 60 * 60 * 1000;
  const QUEUE_CLEAN_INTERVAL = 60 * 60 * 1000;

  // ═══════════════════════════════════════════════════════════
  // 💰 ROLE PRICES
  // ═══════════════════════════════════════════════════════════
  const ROLE_PRICES = {
    vip:             { price: 15000,  label: "Vip Permanen",     style: 'success', emoji: '⭐️' },
    reseller:        { price: 17000,  label: "Reseller",         style: 'primary', emoji: '💰' },
    tukang_bubur:    { price: 20000,  label: "Tukang Bubur",     style: 'primary', emoji: '🍲' },
    admin:           { price: 28000,  label: "Admin",            style: 'primary', emoji: '🔧' },
    partner:         { price: 30000,  label: "Partner",          style: 'primary', emoji: '🤝' },
    partner_pribadi: { price: 35000,  label: "Partner Pribadi",  style: 'primary', emoji: '🤝' },
    tangan_kiri:     { price: 37000,  label: "Tangan Kiri",      style: 'primary', emoji: '🤝' },
    tangan_kanan:    { price: 39000,  label: "Tangan Kanan",     style: 'primary', emoji: '🤝' },
    developers:      { price: 45000,  label: "Developers",       style: 'primary', emoji: '💻' },
    ceo_utama:       { price: 49000,  label: "Ceo Utama",        style: 'success', emoji: '💼' },
    moderator:       { price: 59000,  label: "Moderator",        style: 'success', emoji: '🛡️' },
    forius_utama:    { price: 69000,  label: "Forius Utama",     style: 'danger',  emoji: '🔥' },
    executorius:     { price: 70000,  label: "Executorius",      style: 'danger',  emoji: '⚡' },
    staff:           { price: 80000,  label: "Staff / Security", style: 'danger',  emoji: '🛠️' },
    owner:           { price: 155000, label: "Owner",            style: 'danger',  emoji: '👑' },
    owner_utama:     { price: 250000, label: "Owner Utama",      style: 'danger',  emoji: '👑' },
  };

  const ROLE_ORDER = [
    'member','vip','reseller','tukang_bubur','admin','partner',
    'partner_pribadi','tangan_kiri','tangan_kanan','developers',
    'ceo_utama','moderator','forius_utama','executorius',
    'staff','owner','owner_utama'
  ];

  // ═══════════════════════════════════════════════════════════
  // 🎨 PREMIUM EMOJI (CUSTOM ID)
  // ═══════════════════════════════════════════════════════════
  const EMOJI = {
    services:   "5341715473882955310",
    buy:        "5402186569006210455",
    up:         "5375338737028841420",
    money:      "6098166408502320493",
    warning:    "5447644880824181073",
    check:      "5206607081334906820",
    cross:      "5210952531676504517",
    clock:      "5348090777308251395",
    info:       "5334544901428229844",
    exit:       "5210952531676504517",
    next:       "5206607081334906820",
    user:       "5210956306952758910",
    receipt:    "5210956306952758910",
    group:      "5210956306952758910",
    guide:      "5334544901428229844",
    bell:       "6098230596788556786",
    fire:       "5447644880824181073",
    store:      "5350295774863311434",
    plus:       "5348412779596365405",
    trash:      "5348407054404958928",
    queue:      "5350295774863311434",
    refresh:    "6098166408502320493",
    crown:      "5341715473882955310",
    star:       "5375338737028841420",
    gem:        "5341715473882955310",
    rocket:     "5402186569006210455",
    shield:     "5447644880824181073",
    gift:       "5348412779596365405",
    wallet:     "6098166408502320493",
    chart:      "5350295774863311434",
    verified:   "5206607081334906820",
    mega:       "6098230596788556786",
    sparkle:    "5375338737028841420",
    trophy:     "5341715473882955310",
  };

  // ═══════════════════════════════════════════════════════════
  // 🛠️ HELPERS
  // ═══════════════════════════════════════════════════════════
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  const readJSON = (file, def = []) => {
    try {
      if (!fs.existsSync(file)) {
        fs.writeFileSync(file, JSON.stringify(def, null, 2));
        return def;
      }
      const d = JSON.parse(fs.readFileSync(file, 'utf8'));
      return d ?? def;
    } catch (e) {
      console.error(`[DP] read ${file}:`, e.message);
      return def;
    }
  };

  const writeJSON = (file, data) => {
    try {
      const tmp = file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
      fs.renameSync(tmp, file);
      return true;
    } catch (e) {
      console.error(`[DP] write ${file}:`, e.message);
      return false;
    }
  };

  const esc = (v) => String(v ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  const ce  = (id, fb) => `<tg-emoji emoji-id="${id}">${fb}</tg-emoji>`;
  const rp  = (n) => `Rp ${Number(n).toLocaleString('id-ID')}`;

  // Rich helpers
  const richTable = (rows, headers = ["Information", "Detail"]) => {
    let out = `<table bordered striped compact>\n`;
    out += `<tr><th>${esc(headers[0])}</th><th>${esc(headers[1])}</th></tr>\n`;
    for (const [a, b] of rows) out += `<tr><td>${esc(a)}</td><td>${esc(b)}</td></tr>\n`;
    out += `</table>`;
    return out;
  };
  const richHeader = (text, emoji = '📌') => `<blockquote><b>${emoji} ${esc(text)}</b></blockquote>`;
  const richQuote  = (text) => `<blockquote>${text}</blockquote>`;
  const richDiv    = () => `<hr/>`;
  const richPara   = (text) => `<p>${text}</p>`;

  // ═══════════════════════════════════════════════════════════
  // 🧹 STRIP RICH TAGS — untuk caption foto biasa
  // ═══════════════════════════════════════════════════════════
  function stripRichTags(text) {
    if (!text) return '';
    return String(text)
      .replace(/<blockquote>\s*<b>(.*?)<\/b>\s*<\/blockquote>/gs, '<b>$1</b>')
      .replace(/<blockquote>(.*?)<\/blockquote>/gs, '$1')
      .replace(/<table[^>]*>/g, '')
      .replace(/<\/table>/g, '')
      .replace(/<tr[^>]*>/g, '\n')
      .replace(/<\/tr>/g, '')
      .replace(/<th[^>]*>(.*?)<\/th>/gs, '$1 | ')
      .replace(/<td[^>]*>(.*?)<\/td>/gs, '$1 | ')
      .replace(/<hr\s*\/?>/g, '\n━━━━━━━━━━━━━━━\n')
      .replace(/<p>/g, '\n')
      .replace(/<\/p>/g, '')
      .replace(/<footer>(.*?)<\/footer>/gs, '\n<i>$1</i>')
      .replace(/<\/?(ol|ul)>/g, '')
      .replace(/<li>(.*?)<\/li>/gs, '• $1\n')
      .replace(/<tg-emoji[^>]*>(.*?)<\/tg-emoji>/gs, '$1')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
  }

  // ═══════════════════════════════════════════════════════════
  // 📸 SEND RICH PHOTO — 4-LAYER FALLBACK (DIJAMIN MUNCUL)
  // ═══════════════════════════════════════════════════════════
  async function sendRichPhoto(chatId, fileId, caption, extraOpts = {}) {
    // ATTEMPT 1: sendPhoto dengan caption stripped
    if (fileId) {
      try {
        return await bot.sendPhoto(chatId, fileId, {
          caption: stripRichTags(caption),
          parse_mode: 'HTML',
          ...extraOpts
        });
      } catch (e1) {
        console.error(`[DP] sendRichPhoto attempt1 fail:`, e1.message);
      }
    }

    // ATTEMPT 2: sendPhoto tanpa caption + RichMessage terpisah
    if (fileId) {
      try {
        await bot.sendPhoto(chatId, fileId).catch(() => {});
        return await bot.sendRichMessage(chatId, caption, {
          parse_mode: 'HTML', ...extraOpts
        });
      } catch (e2) {
        console.error(`[DP] sendRichPhoto attempt2 fail:`, e2.message);
      }
    }

    // ATTEMPT 3: RichMessage teks aja
    try {
      return await bot.sendRichMessage(chatId, caption, {
        parse_mode: 'HTML', ...extraOpts
      });
    } catch (e3) {
      console.error(`[DP] sendRichPhoto attempt3 fail:`, e3.message);
    }

    return null;
  }

  // ═══════════════════════════════════════════════════════════
  // 📸 SEND RICH TEXT (fallback ke plain)
  // ═══════════════════════════════════════════════════════════
  async function sendOrEditRich(chatId, messageId, text, replyMarkup = null) {
    const opts = {};
    if (replyMarkup) opts.reply_markup = replyMarkup;
    try {
      if (messageId && typeof bot.editRichMessage === 'function') {
        return await bot.editRichMessage(text, { chat_id: chatId, message_id: messageId, ...opts });
      }
      if (messageId) await bot.deleteMessage(chatId, messageId).catch(() => {});
      return await bot.sendRichMessage(chatId, text, opts);
    } catch (e) {
      try { return await bot.sendRichMessage(chatId, text, opts); } catch (_) {}
      return null;
    }
  }

  async function animateLoading(chatId, messageId, title = "Memproses") {
    if (!messageId) return;
    for (let i = 1; i <= 10; i++) {
      const pct = Math.round((i / 10) * 100);
      const bar = '█'.repeat(i) + '░'.repeat(10 - i);
      try {
        await bot.editMessageText(`<b>⏳ ${esc(title)}...</b>\n\n<code>ᯓ ${bar}  ${pct}%</code>`, {
          chat_id: chatId, message_id: messageId, parse_mode: 'HTML'
        });
      } catch (_) {}
      await sleep(90);
    }
  }

  function loadPaymentInfo() {
    return readJSON(PAYMENT_INFO_FILE, {
      qris_url: "https://files.catbox.moe/ycl8sk.jpg",
      dana: "083180820605", ovo: "083180820605", gopay: "", shopeepay: ""
    });
  }

  // ═══════════════════════════════════════════════════════════
  // 🏪 STORE SYSTEM
  // ═══════════════════════════════════════════════════════════
  const loadAllStores = () => {
    const d = readJSON(STORES_FILE, []);
    return Array.isArray(d) ? d : [];
  };
  const saveAllStores = (list) => writeJSON(STORES_FILE, list);

  const loadActiveStores = () => {
    const now = Date.now();
    return loadAllStores().filter(s => {
      if (!s.active) return false;
      if (s.permanent) return true;
      if (!s.expiresAt) return true;
      return new Date(s.expiresAt).getTime() > now;
    });
  };

  const findStoreById = (id) => loadAllStores().find(s => s.id === id) || null;

  function ensureDefaultStores() {
    const all = loadAllStores();
    let changed = false;

    if (!all.find(s => s.id === 'store_developers_default')) {
      all.push({
        id: 'store_developers_default',
        name: 'Store Developers (Rekomendasi)',
        highestRole: 'developers',
        qrisUrl: 'https://files.catbox.moe/ycl8sk.jpg',
        dana: '083180820605', ovo: '083180820605', gopay: '', shopeepay: '',
        ownerId: 0, permanent: true, durationDays: 0, durationLabel: 'PERMANEN',
        createdAt: new Date().toISOString(), expiresAt: null,
        active: true, createdBy: 'system', default: true,
        description: 'Rekomendasi resmi dari Mclaren Project',
        special: 'developer'
      });
      changed = true;
      console.log('[DP] 💎 Auto-add: Store Developers');
    }

    if (!all.find(s => s.id === 'store_admin_default')) {
      all.push({
        id: 'store_admin_default',
        name: 'Store Admin / Owner',
        highestRole: 'owner_utama',
        qrisUrl: 'https://files.catbox.moe/ycl8sk.jpg',
        dana: '083180820605', ovo: '083180820605', gopay: '', shopeepay: '',
        ownerId: 0, permanent: true, durationDays: 0, durationLabel: 'PERMANEN',
        createdAt: new Date().toISOString(), expiresAt: null,
        active: true, createdBy: 'system', default: true,
        description: 'Store resmi Admin & Owner Mclaren',
        special: 'admin'
      });
      changed = true;
      console.log('[DP] 👑 Auto-add: Store Admin');
    }

    if (changed) saveAllStores(all);
  }
  ensureDefaultStores();

  setInterval(() => {
    const all = loadAllStores();
    let changed = false;
    const now = Date.now();
    for (const s of all) {
      if (!s.active || s.permanent || !s.expiresAt) continue;
      if (new Date(s.expiresAt).getTime() <= now) {
        s.active = false;
        s.expiredAt = new Date().toISOString();
        changed = true;
      }
    }
    if (changed) saveAllStores(all);
  }, STORE_EXPIRY_CHECK);

  // ═══════════════════════════════════════════════════════════
  // 📋 QUEUE SYSTEM
  // ═══════════════════════════════════════════════════════════
  const loadQueue = () => {
    const d = readJSON(QUEUE_FILE, []);
    return Array.isArray(d) ? d : [];
  };
  const saveQueue = (q) => writeJSON(QUEUE_FILE, q);

  function addToQueue(payload) {
    const q = loadQueue();
    if (q.find(item => item.txnId === payload.txnId)) return q;
    const nextNumber = (q.length > 0 ? Math.max(...q.map(x => x.queueNo || 0)) : 0) + 1;
    q.push({
      queueNo: nextNumber,
      txnId: payload.txnId,
      userId: payload.userId,
      username: payload.username,
      role: payload.role,
      mode: payload.mode,
      payAmount: payload.payAmount,
      storeName: payload.storeName || null,
      status: 'waiting',
      joinedAt: new Date().toISOString(),
      processedAt: null,
      processedBy: null
    });
    saveQueue(q);
    console.log(`[DP] 📋 Queue add: #${nextNumber} ${payload.username}`);
    return q;
  }

  function getQueuePosition(txnId) {
    const q = loadQueue().filter(x => x.status === 'waiting');
    const idx = q.findIndex(x => x.txnId === txnId);
    return idx === -1 ? null : { position: idx + 1, total: q.length, queueNo: q[idx].queueNo };
  }

  function markQueueProcessed(txnId, byUser) {
    const q = loadQueue();
    const item = q.find(x => x.txnId === txnId);
    if (!item) return;
    item.status = 'processed';
    item.processedAt = new Date().toISOString();
    item.processedBy = byUser || 'admin';
    saveQueue(q);
  }

  setInterval(() => {
    const q = loadQueue();
    const now = Date.now();
    const fresh = q.filter(item => {
      if (item.status !== 'processed') return true;
      if (!item.processedAt) return true;
      return (now - new Date(item.processedAt).getTime()) < 24 * 60 * 60 * 1000;
    });
    if (fresh.length !== q.length) saveQueue(fresh);
  }, QUEUE_CLEAN_INTERVAL);

  // ═══════════════════════════════════════════════════════════
  // 🔑 OWNER LOADERS
  // ═══════════════════════════════════════════════════════════
  function loadOwnerAcc() {
    try {
      const data = readJSON(OWNER_ACC_FILE, []);
      if (Array.isArray(data)) return data.map(Number).filter(n => !isNaN(n) && n > 0);
    } catch (_) {}
    return [];
  }
  const isOwnerAcc = (id) => loadOwnerAcc().includes(Number(id));
  const isOwner = (id) => isOwnerAcc(id) || telegramIsOwner(id);

  const loadGroupLinks = () => readJSON(GROUP_LINKS_FILE, {
    member:"",vip:"",reseller:"",tukang_bubur:"",admin:"",partner:"",
    partner_pribadi:"",tangan_kiri:"",tangan_kanan:"",developers:"",
    ceo_utama:"",moderator:"",forius_utama:"",executorius:"",
    staff:"",owner:"",owner_utama:"",_guide:"https://t.me/Mclareninfo"
  });

  const getAccessibleRoles = (role) => {
    const idx = ROLE_ORDER.indexOf(role);
    if (idx === -1) return [role];
    return ROLE_ORDER.slice(0, idx + 1);
  };

  const getStoreSellableRoles = (store) => {
    if (!store || !store.highestRole) return [];
    return getAccessibleRoles(store.highestRole);
  };

  const getUserCurrentRole = (telegramId) => {
    const pembeli = readJSON(PEMBELI_FILE, []);
    const purchases = pembeli
      .filter(p => Number(p.userId) === Number(telegramId) && p.accessGiven)
      .sort((a, b) => new Date(b.purchasedAt) - new Date(a.purchasedAt));
    return purchases.length ? purchases[0].role : null;
  };

  const findPembeliByTxn = (txnId) => readJSON(PEMBELI_FILE, []).find(p => p.txnId === txnId) || null;
  const updatePembeliByTxn = (txnId, patch) => {
    const pembeli = readJSON(PEMBELI_FILE, []);
    const idx = pembeli.findIndex(p => p.txnId === txnId);
    if (idx === -1) return null;
    pembeli[idx] = { ...pembeli[idx], ...patch };
    writeJSON(PEMBELI_FILE, pembeli);
    return pembeli[idx];
  };

  const serviceState = new Map();
  const paymentTimer = new Map();
  const storeWizard = new Map();

  // ═══════════════════════════════════════════════════════════
  // 📢 BUILD SUCCESS BROADCAST (PREMIUM STYLE)
  // ═══════════════════════════════════════════════════════════
  function buildSuccessBroadcast(record) {
    const info = ROLE_PRICES[record.role];
    const isDp = record.mode === 'dp';
    const price = info?.price || 0;
    const sisa = price - (record.totalPaid || 0);
    const deadlineStr = record.deadline
      ? new Date(record.deadline).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' })
      : '♾️ PERMANEN';
    const store = record.storeId ? findStoreById(record.storeId) : null;

    const rows = [
      ["👤 Username", record.username || '-'],
      ["🆔 Telegram ID", String(record.userId)],
      ["🎭 Role", `${info?.emoji || '🎭'} ${info?.label || record.role.toUpperCase()}`]
    ];
    if (store) rows.push(["🏪 Store", store.name]);
    if (record.isUpgrade && record.previousRole) rows.push(["⬆️ Upgrade Dari", ROLE_PRICES[record.previousRole]?.label || record.previousRole.toUpperCase()]);
    rows.push(
      ["📊 Status", record.isUpgrade ? '⬆️ UPGRADE ROLE' : '🆕 PEMBELIAN BARU'],
      ["💳 Tipe Bayar", isDp ? '💸 DP (Down Payment)' : '✅ FULL PAYMENT'],
      ["💰 Harga Asli", rp(price)],
      ["✅ Nominal Bayar", rp(record.totalPaid || 0)],
      ["📌 Status DP", isDp ? (sisa > 0 ? `❌ Belum Lunas — Sisa ${rp(sisa)}` : '✅ LUNAS') : '✅ LUNAS (FULL)'],
      ["⏰ Deadline DP", isDp ? deadlineStr : '♾️ PERMANEN'],
      ["🧾 TX ID", record.txnId]
    );

    return [
      richHeader("PEMBELIAN BERHASIL — MCLAREN PROJECT", '🎉'),
      richPara(`Selamat! Pembelian kamu telah <b>diverifikasi</b> dan <b>diaktifkan</b>.`),
      richDiv(),
      richHeader("DETAIL TRANSAKSI", ce(EMOJI.receipt, '🧾')),
      richTable(rows),
      richDiv(),
      richQuote(`💎 <b>Terima kasih</b> telah mempercayai <b>Mclaren Project</b>!`),
      richPara(`📌 <i>Role dan akses group private sudah otomatis diberikan ke akun kamu.</i>`),
      `<footer>© Mclaren Project • Secure Payment System • Verified Transaction</footer>`
    ].join('\n');
  }

  // ═══════════════════════════════════════════════════════════
  // 📢 SEND TESTIMONIAL TO CHANNEL (FOTO TERTAUT)
  // ═══════════════════════════════════════════════════════════
  async function sendTestimonialToChannel(record, proofFileId) {
    const info = ROLE_PRICES[record.role];
    const isDp = record.mode === 'dp';
    const price = info?.price || 0;
    const sisa = price - (record.totalPaid || 0);
    const store = record.storeId ? findStoreById(record.storeId) : null;

    const rows = [
      ["👤 Buyer", record.username || '-'],
      ["🎭 Role", `${info?.emoji || '🎭'} ${info?.label || record.role.toUpperCase()}`],
      ["💳 Metode", isDp ? '💸 DP SETENGAH' : '✅ FULL PAYMENT'],
      ["💵 Nominal", rp(record.totalPaid || 0)]
    ];
    if (store) rows.push(["🏪 Store", store.name]);
    if (isDp && sisa > 0) rows.push(["📌 Sisa", rp(sisa)]);
    rows.push(["✅ Status", isDp && sisa > 0 ? '⏳ MENUNGGU PELUNASAN' : '✅ LUNAS']);

    const caption = [
      richHeader("TESTIMONI PEMBELIAN SUKSES", '🎉'),
      richPara(`Seorang buyer telah berhasil melakukan <b>pembayaran</b> dan telah <b>diverifikasi</b>! ✅`),
      richDiv(),
      richHeader("DETAIL TRANSAKSI", ce(EMOJI.receipt, '🧾')),
      richTable(rows),
      richDiv(),
      richQuote(`💎 <b>Terima kasih</b> telah order di <b>Mclaren Project</b>!`),
      richPara(`🔥 <b>Bukti nyata, bukan hoax!</b> 🔥`),
      `<footer>© Mclaren Project • Secure Payment System • Real-Time Testimonial</footer>`
    ].join('\n');

    // Kirim ke channel dengan foto tertaut (fallback 4-layer)
    const result = await sendRichPhoto(CHANNEL_ID, proofFileId, caption);
    if (result) console.log(`[DP] 📢 Testimonial sent to channel ${CHANNEL_ID}`);
    else console.error(`[DP] ❌ Testimonial failed for channel ${CHANNEL_ID}`);
    return result;
  }

  // ═══════════════════════════════════════════════════════════
  // 📢 SEND NOTIF TO OWNER (FOTO TERTAUT)
  // ═══════════════════════════════════════════════════════════
  async function sendNotifToOwner(ownerId, photoFileId, caption, keyboard) {
    try {
      return await sendRichPhoto(ownerId, photoFileId, caption, {
        reply_markup: keyboard
      });
    } catch (e) {
      console.error(`[DP] sendNotifToOwner ${ownerId}:`, e.message);
      // Fallback: kirim text aja
      try {
        return await bot.sendRichMessage(ownerId, caption, {
          parse_mode: 'HTML', reply_markup: keyboard
        });
      } catch (_) {}
    }
    return null;
  }

  async function sendNotifToOwners(photoFileId, adminText, keyboard) {
    const ownerList = loadOwnerAcc();
    if (!ownerList.length) return console.warn('[DP] ⚠️ owner_acc.json KOSONG');
    for (const ownerId of ownerList) {
      await sendNotifToOwner(ownerId, photoFileId, adminText, keyboard);
      await sleep(200);
    }
  }

  async function sendGroupLinksToBuyer(userId, role, txnId, mode, isUpgrade) {
    const info = ROLE_PRICES[role];
    const links = loadGroupLinks();
    const accessible = getAccessibleRoles(role);
    const groupButtons = [];
    const labels = [];
    for (const r of accessible) {
      const link = links[r];
      if (link && typeof link === 'string' && link.startsWith('http')) {
        groupButtons.push([{
          text: `🔗 ${ROLE_PRICES[r]?.label || r.toUpperCase()}`,
          url: link, style: "primary", icon_custom_emoji_id: EMOJI.group
        }]);
        labels.push(ROLE_PRICES[r]?.label || r.toUpperCase());
      }
    }
    const text = [
      richHeader("AKSES GROUP DIBERIKAN", ce(EMOJI.check, '🎉')),
      richPara(`Selamat! Akses group kamu sudah <b>aktif</b>.`),
      richDiv(),
      richHeader("DETAIL AKSES", ce(EMOJI.receipt, '🧾')),
      richTable([
        ["TX ID", txnId],
        ["Role", `${info?.emoji || '🎭'} ${info?.label || role.toUpperCase()}`],
        ["Tipe", isUpgrade ? '⬆️ Upgrade' : '🆕 Baru'],
        ["Total Group", `${groupButtons.length} group`]
      ]),
      richDiv(),
      richHeader("LINK GROUP PRIVATE", ce(EMOJI.group, '🔗')),
      richPara(`Kamu dapat mengakses <b>${labels.length} group private</b>:`),
      `<ul>`,
      ...labels.map(l => `<li>${esc(l)}</li>`),
      `</ul>`,
      richDiv(),
      richPara(`👇 Klik tombol di bawah untuk join group:`)
    ].join('\n');
    try {
      await bot.sendRichMessage(userId, text, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: groupButtons.length ? groupButtons : [[{ text: "ℹ️ Info Owner", url: INFORMATION_URL, style: "primary" }]] }
      });
    } catch (e) { console.error('[DP] sendGroupLinksToBuyer:', e.message); }
  }

  async function askCreatePermission(userId, txnId) {
    const text = [
      richHeader("IZIN MEMBUAT AKUN", ce(EMOJI.user, '👤')),
      richPara(`Apakah ID kamu akan <b>diizinkan membuat akun</b> di bot ini?`),
      richDiv(),
      richHeader("DETAIL", ce(EMOJI.receipt, '🧾')),
      richTable([
        ["TX ID", txnId],
        ["Status", "⏳ Menunggu Konfirmasi"]
      ]),
      richDiv(),
      richPara(`👇 Pilih opsi di bawah:`)
    ].join('\n');
    try {
      await bot.sendRichMessage(userId, text, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [[
          { text: "✅ Lanjut (Izinkan)", callback_data: `svc_perm_allow_${txnId}`, style: "success", icon_custom_emoji_id: EMOJI.check },
          { text: "❌ Tolak",            callback_data: `svc_perm_deny_${txnId}`,  style: "danger",  icon_custom_emoji_id: EMOJI.cross }
        ]]}
      });
    } catch (e) { console.error('[DP] askCreatePermission:', e.message); }
  }

  async function askCreateOrLater(userId, txnId, role) {
    const info = ROLE_PRICES[role];
    const text = [
      richHeader("AKSES BERHASIL DIBERIKAN", ce(EMOJI.check, '✅')),
      richPara(`ID kamu sudah <b>diizinkan</b> membuat akun di bot ini!`),
      richDiv(),
      richHeader("DETAIL", ce(EMOJI.receipt, '🧾')),
      richTable([
        ["TX ID", txnId],
        ["Role", `${info?.emoji || '🎭'} ${info?.label || role.toUpperCase()}`],
        ["Status", "✅ AKTIF — DAPAT BUAT AKUN"]
      ]),
      richDiv(),
      richPara(`Kamu juga bisa membuat akun kapan saja lewat command <code>/create</code>.`),
      richDiv(),
      richPara(`👇 Mau buat akun sekarang?`)
    ].join('\n');
    try {
      await bot.sendRichMessage(userId, text, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [
          [{ text: "📝 Create Akun Sekarang", callback_data: `svc_perm_create_${txnId}`, style: "success", icon_custom_emoji_id: EMOJI.next }],
          [{ text: "⏰ Nanti Saja",           callback_data: `svc_perm_later_${txnId}`,  style: "primary", icon_custom_emoji_id: EMOJI.clock }]
        ]}
      });
    } catch (e) { console.error('[DP] askCreateOrLater:', e.message); }
  }

  async function sendCreateMethodPicker(userId) {
    const text = [
      richHeader("PILIH METODE PEMBUATAN AKUN", ce(EMOJI.user, '📝')),
      richPara(`Pilih metode untuk membuat akun baru:`),
      richDiv(),
      richHeader("OPSI METODE", ce(EMOJI.guide, '📖')),
      `<p>📝 <b>Manual Custom Request</b> — kamu isi username, password, role, durasi sendiri.</p>`,
      `<p>⚡ <b>Otomatis Create</b> — bot generate username & password acak.</p>`,
      richDiv(),
      richPara(`👇 Pilih metode di bawah:`)
    ].join('\n');
    try {
      await bot.sendRichMessage(userId, text, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [
          [
            { text: "📝 Manual Custom Request", callback_data: "create_method_manual", style: "primary", icon_custom_emoji_id: EMOJI.next },
            { text: "⚡ Otomatis Create",        callback_data: "create_method_auto",   style: "success", icon_custom_emoji_id: EMOJI.check }
          ],
          [{ text: "❌ Batal", callback_data: "cancel_create", style: "danger", icon_custom_emoji_id: EMOJI.cross }]
        ]}
      });
    } catch (e) { console.error('[DP] sendCreateMethodPicker:', e.message); }
  }

  // ═══════════════════════════════════════════════════════════
  // 🧩 KEYBOARDS (dengan premium emoji)
  // ═══════════════════════════════════════════════════════════
  function keyboardServiceMenu(userId) {
    const rows = [
      [
        { text: "💳 Buy Access Role",  callback_data: "svc_buy_role",  style: "success", icon_custom_emoji_id: EMOJI.buy },
        { text: "⬆️ Up Access Role",   callback_data: "svc_up_role",   style: "primary", icon_custom_emoji_id: EMOJI.up }
      ],
      [{ text: "💸 Cek DP Saya", callback_data: "svc_my_dp", style: "primary", icon_custom_emoji_id: EMOJI.money }],
      [
        { text: "📋 Cek Antrian",    callback_data: "svc_queue_check",   style: "primary", icon_custom_emoji_id: EMOJI.queue },
        { text: "🔄 Refresh Antrian", callback_data: "svc_queue_refresh", style: "success", icon_custom_emoji_id: EMOJI.refresh }
      ]
    ];
    if (isOwner(userId)) {
      rows.push([
        { text: "➕ Tambah Layanan", callback_data: "aln_open", style: "success", icon_custom_emoji_id: EMOJI.plus },
        { text: "📋 Kelola Store",   callback_data: "aln_manage", style: "primary", icon_custom_emoji_id: EMOJI.store }
      ]);
    }
    rows.push([{ text: "❌ Exit Layanan", callback_data: "svc_exit", style: "danger", icon_custom_emoji_id: EMOJI.exit }]);
    return { inline_keyboard: rows };
  }

  const keyboardBuyConfirm = () => ({ inline_keyboard: [[
    { text: "➡️ Lanjutkan Beli", callback_data: "svc_continue_buy", style: "success", icon_custom_emoji_id: EMOJI.next },
    { text: "❌ Exit Layanan",   callback_data: "svc_exit",         style: "danger",  icon_custom_emoji_id: EMOJI.exit }
  ]]});

  function keyboardRoleList(roles) {
    const list = roles || Object.keys(ROLE_PRICES);
    const rows = [];
    list.forEach(role => {
      const info = ROLE_PRICES[role];
      if (!info) return;
      rows.push([{
        text: `${info.emoji} ${info.label} — ${rp(info.price)}`,
        callback_data: `svc_role_${role}`, style: info.style, icon_custom_emoji_id: EMOJI.money
      }]);
    });
    rows.push([{ text: "❌ Exit Layanan", callback_data: "svc_exit", style: "danger", icon_custom_emoji_id: EMOJI.exit }]);
    return { inline_keyboard: rows };
  }

  const keyboardRoleDetail = (role) => ({ inline_keyboard: [
    [
      { text: "🛒 Beli Full",   callback_data: `svc_buy_full_${role}`, style: "success", icon_custom_emoji_id: EMOJI.buy },
      { text: "💸 DP (Min 3k)", callback_data: `svc_buy_dp_${role}`,   style: "primary", icon_custom_emoji_id: EMOJI.money }
    ],
    [{ text: "ℹ️ Information", url: INFORMATION_URL, style: "primary", icon_custom_emoji_id: EMOJI.info }],
    [{ text: "❌ Exit Layanan", callback_data: "svc_exit", style: "danger", icon_custom_emoji_id: EMOJI.exit }]
  ]});

  const keyboardPaymentConfirm = (userId, mode, role) => ({ inline_keyboard: [
    [{ text: "📸 Konfirmasi Pembayaran", callback_data: `svc_pay_proof_${userId}_${mode}_${role}`, style: "success", icon_custom_emoji_id: EMOJI.receipt }],
    [{ text: "❌ Batalkan",              callback_data: `svc_pay_cancel_${userId}`,               style: "danger",  icon_custom_emoji_id: EMOJI.cross }]
  ]});

  function keyboardDpAmount(role) {
    const presets = [5000, 10000, 15000, 20000, 25000];
    const rows = []; let buf = [];
    for (const amt of presets) {
      buf.push({ text: `💸 ${rp(amt)}`, callback_data: `svc_dp_amt_${role}_${amt}`, style: "primary", icon_custom_emoji_id: EMOJI.money });
      if (buf.length === 2) { rows.push([...buf]); buf = []; }
    }
    if (buf.length) rows.push(buf);
    rows.push([{ text: "✏️ Custom Amount", callback_data: `svc_dp_custom_${role}`, style: "success", icon_custom_emoji_id: EMOJI.next }]);
    rows.push([{ text: "❌ Batalkan", callback_data: "svc_buy_role", style: "danger", icon_custom_emoji_id: EMOJI.cross }]);
    return { inline_keyboard: rows };
  }

  function keyboardUpRoleList(currentRole, allowedRoles) {
    const currentIdx = ROLE_ORDER.indexOf(currentRole);
    const rows = [];
    ROLE_ORDER.forEach((role, idx) => {
      if (idx <= currentIdx) return;
      if (allowedRoles && !allowedRoles.includes(role)) return;
      const info = ROLE_PRICES[role]; if (!info) return;
      const diff = info.price - (ROLE_PRICES[currentRole]?.price || 0);
      rows.push([{
        text: `${info.emoji} ${info.label} — ${rp(diff)}`,
        callback_data: `svc_up_target_${role}`, style: info.style, icon_custom_emoji_id: EMOJI.money
      }]);
    });
    rows.push([{ text: "❌ Exit Layanan", callback_data: "svc_exit", style: "danger", icon_custom_emoji_id: EMOJI.exit }]);
    return { inline_keyboard: rows };
  }

  function keyboardUpRoleCurrentList() {
    const rows = [];
    ROLE_ORDER.forEach(role => {
      const info = ROLE_PRICES[role]; if (!info) return;
      rows.push([{
        text: `${info.emoji} ${info.label}`,
        callback_data: `svc_up_current_${role}`, style: info.style, icon_custom_emoji_id: EMOJI.user
      }]);
    });
    rows.push([{ text: "❌ Exit Layanan", callback_data: "svc_exit", style: "danger", icon_custom_emoji_id: EMOJI.exit }]);
    return { inline_keyboard: rows };
  }

  function keyboardStoreList(action) {
    const stores = loadActiveStores();
    const rows = [];
    if (!stores.length) {
      rows.push([{
        text: `🏪 Mclaren Official`,
        callback_data: `svc_store_default_${action}`,
        style: "success", icon_custom_emoji_id: EMOJI.store
      }]);
    } else {
      stores.forEach(s => {
        const highLabel = ROLE_PRICES[s.highestRole]?.label || s.highestRole?.toUpperCase() || '-';
        let style = "success";
        let icon = EMOJI.store;
        let prefix = "🏪";
        if (s.special === 'developer') { style = "primary"; prefix = "💎"; }
        if (s.special === 'admin') { style = "danger"; prefix = "👑"; }
        rows.push([{
          text: `${prefix} ${s.name}  •  ⬆️ ${highLabel}`,
          callback_data: `svc_store_${s.id}_${action}`,
          style, icon_custom_emoji_id: icon
        }]);
      });
    }
    rows.push([{ text: "❌ Exit Layanan", callback_data: "svc_exit", style: "danger", icon_custom_emoji_id: EMOJI.exit }]);
    return { inline_keyboard: rows };
  }

  // ═══════════════════════════════════════════════════════════
  // 🧾 SERVICE MENU
  // ═══════════════════════════════════════════════════════════
  async function showServiceMenu(chatId, messageId, userId) {
    serviceState.delete(userId);
    if (messageId) await animateLoading(chatId, messageId, "Membuka menu layanan");
    const stores = loadActiveStores();
    const storeRows = stores.length
      ? stores.map(s => {
          const prefix = s.special === 'developer' ? '💎' : s.special === 'admin' ? '👑' : '🏪';
          return [`${prefix} ${s.name}`, `⬆️ ${ROLE_PRICES[s.highestRole]?.label || s.highestRole || '-'}`];
        })
      : [["🏪 Mclaren Official", "Full Role"]];

    const queueCount = loadQueue().filter(x => x.status === 'waiting').length;
    const isOwnerUser = isOwner(userId);

    const text = [
      richHeader("MENU LAYANAN — MCLAREN PROJECT", ce(EMOJI.services, '🛒')),
      richPara(`Beli akses role, upgrade role, atau DP dengan sistem otomatis.`),
      richDiv(),
      richHeader("INFO PENTING", ce(EMOJI.info, '📌')),
      richTable([
        ["💸 Minimal DP", rp(DP_MINIMUM)],
        ["💸 Maksimal DP", rp(DP_MAXIMUM)],
        ["⏰ Batas Pelunasan", `${DP_MAX_DAYS} hari`],
        ["💳 Metode", "QRIS / DANA / OVO / GOPAY / ShopeePay"],
        ["⏳ Timer Bayar", "20 menit"],
        ["🏪 Store Aktif", String(stores.length || 1)],
        ["📋 Antrian Aktif", `${queueCount} orang`],
        ["👤 Status Kamu", isOwnerUser ? "👑 OWNER — Akses Panel" : "👤 Member"]
      ]),
      richDiv(),
      richHeader("STORE TERSEDIA", ce(EMOJI.store, '🏪')),
      richTable(storeRows, ["Store", "Max Role"]),
      richDiv(),
      isOwnerUser ? richPara(`👑 <b>Owner Panel:</b> kamu bisa tambah/kelola store di tombol bawah.`) : '',
      richPara(`👇 Silakan pilih layanan di bawah:`),
      `<footer>© Mclaren Project • Secure Payment System • v9.0 Ultra</footer>`
    ].filter(Boolean).join('\n');

    await sendOrEditRich(chatId, messageId, text, keyboardServiceMenu(userId));
  }

  // ═══════════════════════════════════════════════════════════
  // 📋 QUEUE VIEW
  // ═══════════════════════════════════════════════════════════
  async function showQueue(chatId, messageId, userId, isRefresh = false) {
    if (messageId) await animateLoading(chatId, messageId, isRefresh ? "Refresh antrian" : "Memuat antrian");

    const all = loadQueue();
    const waiting = all.filter(x => x.status === 'waiting').sort((a, b) => a.queueNo - b.queueNo);
    const myTxn = [...all].reverse().find(x => Number(x.userId) === Number(userId) && x.status === 'waiting');
    let myInfo = '';
    if (myTxn) {
      const pos = waiting.findIndex(x => x.txnId === myTxn.txnId) + 1;
      myInfo = [
        richHeader("POSISI KAMU", ce(EMOJI.user, '👤')),
        richTable([
          ["🔢 No. Antrian", `#${myTxn.queueNo}`],
          ["📍 Posisi", `${pos} dari ${waiting.length}`],
          ["🎭 Role", ROLE_PRICES[myTxn.role]?.label || myTxn.role.toUpperCase()],
          ["⏳ Status", "Menunggu diproses owner"]
        ])
      ].join('\n');
    }

    let listText = '';
    if (waiting.length === 0) {
      listText = richPara(`✅ <b>Tidak ada antrian</b>. Semua sudah diproses!`);
    } else {
      const rows = waiting.slice(0, 15).map((x) => {
        const isMe = Number(x.userId) === Number(userId);
        const name = isMe ? `👤 ${x.username} (Kamu)` : x.username;
        return [`#${x.queueNo}`, `${name}\n${ROLE_PRICES[x.role]?.label || x.role.toUpperCase()}`];
      });
      listText = richTable(rows, ["No", "Buyer"]);
      if (waiting.length > 15) listText += `\n<p>... dan <b>${waiting.length - 15}</b> orang lagi</p>`;
    }

    const text = [
      richHeader("DAFTAR ANTRIAN TRANSAKSI", ce(EMOJI.queue, '📋')),
      richPara(`Total: <b>${waiting.length}</b> orang menunggu`),
      richDiv(),
      myInfo ? myInfo + `\n<hr/>` : '',
      richHeader("LIST ANTRIAN", '📝'),
      listText,
      richDiv(),
      richPara(`🔄 Klik <b>Refresh Antrian</b> untuk lihat status terbaru`),
      `<footer>© Mclaren Project • Queue System v9.0</footer>`
    ].filter(Boolean).join('\n');

    await sendOrEditRich(chatId, messageId, text, {
      inline_keyboard: [
        [{ text: "🔄 Refresh Antrian", callback_data: "svc_queue_refresh", style: "success", icon_custom_emoji_id: EMOJI.refresh }],
        [{ text: "💸 Cek DP Saya",     callback_data: "svc_my_dp",          style: "primary", icon_custom_emoji_id: EMOJI.money }],
        [{ text: "❌ Kembali",         callback_data: "svc_menu",           style: "danger",  icon_custom_emoji_id: EMOJI.exit }]
      ]
    });
  }

  // ═══════════════════════════════════════════════════════════
  // 🛒 BUY FLOW
  // ═══════════════════════════════════════════════════════════
  async function showBuyIntro(chatId, messageId, userId) {
    if (messageId) await animateLoading(chatId, messageId, "Menyiapkan menu");
    const text = [
      richHeader("BUY ACCESS ROLE", ce(EMOJI.buy, '🛒')),
      richPara(`Beli <b>akses role</b> baru di Mclaren Project.`),
      richDiv(),
      richHeader("PANDUAN", ce(EMOJI.guide, '📖')),
      `<ol>`,
      `<li>Pilih <b>store</b> tempat kamu beli.</li>`,
      `<li>Pilih role yang diinginkan.</li>`,
      `<li>Bayar <b>FULL</b> atau <b>DP minimal ${rp(DP_MINIMUM)}</b>.</li>`,
      `<li>Scan QRIS / DANA / OVO.</li>`,
      `<li>Kirim bukti transfer ke bot.</li>`,
      `<li>Tunggu verifikasi owner store.</li>`,
      `<li>Akses + group private otomatis diberikan. ✅</li>`,
      `</ol>`,
      richDiv(),
      richPara(`Klik <b>Lanjutkan Beli</b> untuk memilih store.`)
    ].join('\n');
    await sendOrEditRich(chatId, messageId, text, keyboardBuyConfirm());
    serviceState.set(userId, { step: 'buy_intro' });
  }

  async function showStoreListForBuy(chatId, messageId, userId, action) {
    if (messageId) await animateLoading(chatId, messageId, "Memuat store");
    const stores = loadActiveStores();
    const text = [
      richHeader("PILIH STORE", ce(EMOJI.store, '🏪')),
      richPara(`Silakan pilih store tempat kamu akan ${action === 'up' ? 'upgrade' : 'beli'} role.`),
      richDiv(),
      stores.length
        ? richTable(stores.map(s => {
            const prefix = s.special === 'developer' ? '💎' : s.special === 'admin' ? '👑' : '🏪';
            return [`${prefix} ${s.name}`, `⬆️ Max: ${ROLE_PRICES[s.highestRole]?.label || s.highestRole || '-'}`];
          }), ["Store", "Info"])
        : richPara(`Belum ada store custom, menggunakan <b>Mclaren Official</b>.`),
      richDiv(),
      richPara(`👇 Klik store di bawah:`)
    ].join('\n');
    await sendOrEditRich(chatId, messageId, text, keyboardStoreList(action));
  }

  async function showRoleList(chatId, messageId, userId, store) {
    if (messageId) await animateLoading(chatId, messageId, "Memuat daftar role");
    const allowedRoles = store ? getStoreSellableRoles(store) : Object.keys(ROLE_PRICES);
    const priceRows = allowedRoles
      .filter(r => ROLE_PRICES[r])
      .map(r => [`${ROLE_PRICES[r].emoji} ${ROLE_PRICES[r].label}`, rp(ROLE_PRICES[r].price)]);
    const storeName = store ? `${store.special === 'developer' ? '💎' : store.special === 'admin' ? '👑' : '🏪'} ${store.name}` : '🏪 Mclaren Official';
    const text = [
      richHeader(`DAFTAR ROLE — ${storeName.toUpperCase()}`, ce(EMOJI.money, '💎')),
      richPara(`Pilih role yang kamu inginkan:`),
      richDiv(),
      richTable(priceRows, ["Role", "Harga"]),
      richDiv(),
      richHeader("PANDUAN DP", ce(EMOJI.info, '📌')),
      richPara(`DP minimal <b>${rp(DP_MINIMUM)}</b>, maksimal <b>${rp(DP_MAXIMUM)}</b>. Sisa wajib dilunasi maksimal <b>${DP_MAX_DAYS} hari</b>.`),
      richDiv(),
      richPara(`👇 Pilih role di bawah:`)
    ].join('\n');
    await sendOrEditRich(chatId, messageId, text, keyboardRoleList(allowedRoles));
    serviceState.set(userId, { step: 'role_list', store: store || null });
  }

  async function showRoleDetail(chatId, messageId, userId, role) {
    const info = ROLE_PRICES[role];
    if (!info) return showServiceMenu(chatId, messageId, userId);
    if (messageId) await animateLoading(chatId, messageId, `Memuat ${info.label}`);
    const st = serviceState.get(userId) || {};
    const store = st.store || null;
    const text = [
      richHeader(`DETAIL ROLE : ${info.label.toUpperCase()}`, `${info.emoji}`),
      store ? richTable([["🏪 Store", store.name]]) : '',
      richHeader("DETAIL ROLE", ce(EMOJI.receipt, '🧾')),
      richTable([
        ["🎭 Role", info.label],
        ["💰 Harga Full", rp(info.price)],
        ["💸 Minimal DP", rp(DP_MINIMUM)],
        ["💸 Maksimal DP", rp(DP_MAXIMUM)],
        ["⏰ Batas Pelunasan", `${DP_MAX_DAYS} hari`]
      ]),
      richDiv(),
      richHeader("OPSI PEMBAYARAN", ce(EMOJI.info, '📖')),
      richQuote(`1️⃣ <b>Full Payment</b> → Bayar ${rp(info.price)} lunas.\n\n2️⃣ <b>DP Custom</b> → Bayar minimal ${rp(DP_MINIMUM)}, sisa wajib lunas ${DP_MAX_DAYS} hari.`),
      richDiv(),
      richPara(`👇 Pilih opsi di bawah:`)
    ].filter(Boolean).join('\n');
    serviceState.set(userId, { ...st, step: 'role_detail', role, mode: null });
    await sendOrEditRich(chatId, messageId, text, keyboardRoleDetail(role));
  }

  async function showUpRoleIntro(chatId, messageId, userId) {
    if (messageId) await animateLoading(chatId, messageId, "Memuat up role");
    const currentRole = getUserCurrentRole(userId);
    if (currentRole && ROLE_PRICES[currentRole]) {
      const info = ROLE_PRICES[currentRole];
      const text = [
        richHeader("UP ACCESS ROLE", ce(EMOJI.up, '⬆️')),
        richPara(`Kamu terdeteksi memiliki role saat ini:`),
        richDiv(),
        richTable([
          ["🎭 Role Saat Ini", `${info.emoji} ${info.label}`],
          ["✅ Status", "AKTIF"]
        ]),
        richDiv(),
        richPara(`Langkah berikut: <b>pilih store</b> tempat kamu akan upgrade.`)
      ].join('\n');
      serviceState.set(userId, { step: 'up_store', currentRole });
      return sendOrEditRich(chatId, messageId, text, keyboardStoreList('up'));
    }
    const text = [
      richHeader("UP ACCESS ROLE", ce(EMOJI.up, '⬆️')),
      richPara(`Role kamu tidak terdeteksi otomatis. Silakan pilih role saat ini:`)
    ].join('\n');
    serviceState.set(userId, { step: 'up_role_current' });
    return sendOrEditRich(chatId, messageId, text, keyboardUpRoleCurrentList());
  }

  async function showUpRoleDetail(chatId, messageId, userId, currentRole, targetRole, store) {
    const currInfo = ROLE_PRICES[currentRole];
    const tgtInfo  = ROLE_PRICES[targetRole];
    if (!currInfo || !tgtInfo) return showServiceMenu(chatId, messageId, userId);
    if (messageId) await animateLoading(chatId, messageId, "Menghitung harga up");
    const diffPrice = tgtInfo.price - currInfo.price;
    const dpMin = Math.max(DP_MINIMUM, Math.floor(diffPrice * 0.5));
    const text = [
      richHeader(`UP ROLE : ${currInfo.label} → ${tgtInfo.label}`, ce(EMOJI.up, '⬆️')),
      store ? richTable([["🏪 Store", store.name]]) : '',
      richHeader("DETAIL UPGRADE", ce(EMOJI.receipt, '🧾')),
      richTable([
        ["🎭 Role Saat Ini", `${currInfo.emoji} ${currInfo.label}`],
        ["🎯 Role Target", `${tgtInfo.emoji} ${tgtInfo.label}`],
        ["💰 Harga Role Target", rp(tgtInfo.price)],
        ["💰 Harga Role Sekarang", rp(currInfo.price)],
        ["💵 Harga Upgrade", rp(diffPrice)],
        ["💸 Minimal DP", rp(dpMin)]
      ]),
      richDiv(),
      richHeader("OPSI PEMBAYARAN", ce(EMOJI.info, '📖')),
      richQuote(`1️⃣ <b>Full</b> → Bayar ${rp(diffPrice)} lunas.\n\n2️⃣ <b>DP</b> → Bayar minimal ${rp(dpMin)}.`)
    ].filter(Boolean).join('\n');
    serviceState.set(userId, { step: 'up_role_detail', currentRole, targetRole, store });
    const kb = { inline_keyboard: [
      [
        { text: "🛒 Upgrade Full",        callback_data: `svc_up_full_${targetRole}`, style: "success", icon_custom_emoji_id: EMOJI.buy },
        { text: "💸 Upgrade DP (Min 3k)", callback_data: `svc_up_dp_${targetRole}`,   style: "primary", icon_custom_emoji_id: EMOJI.money }
      ],
      [{ text: "ℹ️ Information", url: INFORMATION_URL, style: "primary", icon_custom_emoji_id: EMOJI.info }],
      [{ text: "❌ Exit Layanan", callback_data: "svc_exit", style: "danger", icon_custom_emoji_id: EMOJI.exit }]
    ]};
    await sendOrEditRich(chatId, messageId, text, kb);
  }

  async function askDpAmount(chatId, messageId, userId, role, isUpgrade = false, currentRole = null) {
    const info = ROLE_PRICES[role];
    if (!info) return showServiceMenu(chatId, messageId, userId);
    let fullPrice = info.price;
    if (isUpgrade && currentRole) fullPrice = info.price - (ROLE_PRICES[currentRole]?.price || 0);
    const minDp = Math.max(DP_MINIMUM, Math.floor(fullPrice * 0.5));
    const maxDp = Math.min(DP_MAXIMUM, fullPrice);
    if (messageId) await animateLoading(chatId, messageId, "Menyiapkan DP");
    const text = [
      richHeader("PILIH NOMINAL DP", ce(EMOJI.money, '💸')),
      richPara(`Pilih nominal DP atau custom amount:`),
      richDiv(),
      richTable([
        ["💰 Total Harga", rp(fullPrice)],
        ["💸 Minimal DP", rp(minDp)],
        ["💸 Maksimal DP", rp(maxDp)],
        ["⏰ Sisa wajib lunas", `${DP_MAX_DAYS} hari`]
      ]),
      richDiv(),
      richPara(`👇 Pilih nominal preset atau klik Custom Amount:`)
    ].join('\n');
    const st = serviceState.get(userId) || {};
    serviceState.set(userId, { ...st, step: 'awaiting_dp_amount_pick', isUpgrade, currentRole, role, fullPrice, minDp, maxDp, messageId });
    await sendOrEditRich(chatId, messageId, text, keyboardDpAmount(role));
  }

  async function showPaymentConfirmation(chatId, messageId, userId, mode, role, customAmount = null, isUpgrade = false, currentRole = null) {
    const info = ROLE_PRICES[role];
    if (!info) return showServiceMenu(chatId, messageId, userId);
    let fullPrice = info.price;
    if (isUpgrade && currentRole) fullPrice = info.price - (ROLE_PRICES[currentRole]?.price || 0);
    const dpMin = Math.max(DP_MINIMUM, Math.floor(fullPrice * 0.5));
    const payAmount = mode === 'dp' ? (customAmount || dpMin) : fullPrice;
    const sisa = fullPrice - payAmount;
    if (messageId) await animateLoading(chatId, messageId, "Menyiapkan QRIS");

    const st = serviceState.get(userId) || {};
    const store = st.store || null;
    const pm = store ? {
      qris_url: store.qrisUrl || "https://files.catbox.moe/ycl8sk.jpg",
      dana: store.dana || '-', ovo: store.ovo || '-',
      gopay: store.gopay || '-', shopeepay: store.shopeepay || '-'
    } : loadPaymentInfo();

    const tableRows = [
      ["🎭 Role", isUpgrade ? `${currentRole} → ${info.label}` : info.label],
      ["💳 Mode", mode === 'dp' ? 'DP CUSTOM' : 'FULL PAYMENT'],
      ["💵 Nominal Bayar", rp(payAmount)]
    ];
    if (store) tableRows.push(["🏪 Store", store.name]);
    if (mode === 'dp') {
      tableRows.push(["💸 Sisa", rp(sisa)]);
      tableRows.push(["⏰ Deadline", `${DP_MAX_DAYS} hari`]);
    }

    const text = [
      richHeader("KONFIRMASI PEMBAYARAN", ce(EMOJI.receipt, '💳')),
      richPara(`Silakan transfer sesuai nominal berikut:`),
      richDiv(),
      richHeader("DETAIL PEMBAYARAN", ce(EMOJI.receipt, '🧾')),
      richTable(tableRows),
      richDiv(),
      richHeader("METODE PEMBAYARAN", ce(EMOJI.wallet, '💳')),
      richPara(`📱 <b>QRIS:</b> Scan gambar di atas`),
      richPara(`💙 <b>DANA:</b> <code>${pm.dana || '-'}</code>`),
      richPara(`💜 <b>OVO:</b> <code>${pm.ovo || '-'}</code>`),
      pm.gopay && pm.gopay !== '-' ? richPara(`💚 <b>GOPAY:</b> <code>${pm.gopay}</code>`) : '',
      pm.shopeepay && pm.shopeepay !== '-' ? richPara(`🧡 <b>SHOPEEPAY:</b> <code>${pm.shopeepay}</code>`) : '',
      richDiv(),
      richHeader("TIMER PEMBAYARAN", ce(EMOJI.clock, '⏳')),
      richQuote(`⏰ <b>20 menit</b> — jika melewati batas, transaksi otomatis <b>dibatalkan</b>.`),
      richDiv(),
      richPara(`👇 Kirim bukti transfer lewat tombol di bawah:`)
    ].filter(Boolean).join('\n');

    if (messageId) await bot.deleteMessage(chatId, messageId).catch(() => {});

    let sent;
    const qrisUrl = pm.qris_url || "https://files.catbox.moe/ycl8sk.jpg";
    const kb = keyboardPaymentConfirm(userId, mode, role);

    // Kirim QRIS + caption (strip rich tags)
    try {
      sent = await bot.sendPhoto(chatId, qrisUrl, {
        caption: stripRichTags(text),
        parse_mode: 'HTML',
        reply_markup: kb
      });
    } catch (e1) {
      console.error('[DP] sendPhoto QRIS fail:', e1.message);
      // Fallback: kirim teks rich aja
      try {
        sent = await bot.sendRichMessage(chatId, text, {
          parse_mode: 'HTML', reply_markup: kb
        });
      } catch (e2) {
        sent = await bot.sendMessage(chatId, stripRichTags(text), {
          parse_mode: 'HTML', reply_markup: kb
        }).catch(() => null);
      }
    }

    serviceState.set(userId, {
      ...st, step: 'awaiting_proof', role, mode, payAmount, sisa, fullPrice,
      isUpgrade, currentRole, store,
      messageId: sent?.message_id, chatId, startedAt: Date.now()
    });

    if (paymentTimer.has(userId)) clearTimeout(paymentTimer.get(userId));
    const timer = setTimeout(async () => {
      const cur = serviceState.get(userId);
      if (cur && cur.step === 'awaiting_proof') {
        serviceState.delete(userId);
        paymentTimer.delete(userId);
        try {
          await bot.sendRichMessage(chatId,
            [richHeader("TRANSAKSI DIBATALKAN", ce(EMOJI.cross, '❌')),
             richPara(`Waktu pembayaran <b>20 menit</b> habis.`),
             richDiv(),
             richPara(`Silakan order lagi kalau masih berminat.`)].join('\n'),
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: "🛒 Menu Layanan", callback_data: "svc_menu", style: "success", icon_custom_emoji_id: EMOJI.services }]] } });
        } catch (_) {}
      }
    }, PAYMENT_TIMEOUT);
    paymentTimer.set(userId, timer);
  }

  // ═══════════════════════════════════════════════════════════
  // 📸 HANDLE PAYMENT PROOF
  // ═══════════════════════════════════════════════════════════
  async function handlePaymentProof(msg) {
    const userId = Number(msg.from.id);
    const st = serviceState.get(userId);
    if (!st || st.step !== 'awaiting_proof') return false;
    if (!msg.photo || !msg.photo.length) {
      await bot.sendRichMessage(msg.chat.id,
        [richHeader("KIRIM FOTO", ce(EMOJI.warning, '⚠️')), richPara(`Harap kirim bukti transfer dalam bentuk FOTO.`)].join('\n'),
        { parse_mode: 'HTML' });
      return true;
    }
    if (paymentTimer.has(userId)) { clearTimeout(paymentTimer.get(userId)); paymentTimer.delete(userId); }

    const fileId = msg.photo[msg.photo.length - 1].file_id;
    const caption = msg.caption || '';
    const txnId = `TXN-${Date.now().toString(36).toUpperCase()}`;

    const pending = readJSON(PENDING_PAY_FILE, {});
    pending[txnId] = {
      type: 'new_purchase', txnId, userId,
      username: msg.from.username || msg.from.first_name || `User_${userId}`,
      firstName: msg.from.first_name || '',
      lastName: msg.from.last_name || '',
      role: st.role, mode: st.mode,
      payAmount: st.payAmount, sisa: st.sisa || 0, fullPrice: st.fullPrice || 0,
      isUpgrade: !!st.isUpgrade, currentRole: st.currentRole || null,
      storeId: st.store?.id || null, storeName: st.store?.name || null,
      proofFileId: fileId, caption, chatId: msg.chat.id,
      createdAt: new Date().toISOString(), status: 'pending'
    };
    writeJSON(PENDING_PAY_FILE, pending);
    serviceState.delete(userId);

    addToQueue({
      txnId, userId,
      username: pending[txnId].username,
      role: st.role, mode: st.mode,
      payAmount: st.payAmount,
      storeName: st.store?.name || 'Mclaren Official'
    });
    const pos = getQueuePosition(txnId);

    await bot.sendRichMessage(msg.chat.id,
      [richHeader("BUKTI DITERIMA", ce(EMOJI.check, '✅')),
       richPara(`Bukti transfer sudah dikirim ke owner untuk diverifikasi.`),
       richDiv(),
       richHeader("DETAIL", ce(EMOJI.receipt, '🧾')),
       richTable([
         ["🧾 TX ID", txnId],
         ["📋 Antrian", `#${pos?.queueNo || '-'} (pos ${pos?.position || '-'}/${pos?.total || '-'})`]
       ]),
       richDiv(),
       richQuote(`⏳ <i>Tunggu verifikasi maks 5 menit.</i>`),
       richDiv(),
       richPara(`Klik <b>📋 Cek Antrian</b> untuk lihat posisi kamu.`)].join('\n'),
      { parse_mode: 'HTML', reply_markup: { inline_keyboard: [
        [{ text: "📋 Cek Antrian", callback_data: "svc_queue_check", style: "primary", icon_custom_emoji_id: EMOJI.queue }],
        [{ text: "🛒 Menu Layanan", callback_data: "svc_menu", style: "success", icon_custom_emoji_id: EMOJI.services }]
      ]}});

    const info = ROLE_PRICES[st.role];
    const adminRows = [
      ["🧾 TX ID", txnId],
      ["📋 Antrian", `#${pos?.queueNo || '-'}`],
      ["👤 User", pending[txnId].username],
      ["🆔 User ID", String(userId)],
      ["🎭 Role", info?.label || st.role.toUpperCase()],
      ["💳 Mode", st.mode === 'dp' ? `DP CUSTOM (${rp(st.payAmount)})` : 'FULL PAYMENT'],
      ["💵 Bayar", rp(st.payAmount)]
    ];
    if (st.store) adminRows.push(["🏪 Store", st.store.name]);
    if (st.isUpgrade && st.currentRole) adminRows.push(["⬆️ Upgrade Dari", st.currentRole.toUpperCase()]);
    if (st.mode === 'dp') adminRows.push(["💸 Sisa", rp(st.sisa)]);

    const adminText = [
      richHeader("NEW PAYMENT REQUEST", ce(EMOJI.bell, '🔔')),
      richPara(`Ada permintaan pembayaran baru yang menunggu verifikasi!`),
      richDiv(),
      richHeader("DETAIL PERMINTAAN", ce(EMOJI.receipt, '🧾')),
      richTable(adminRows),
      richDiv(),
      richQuote(`👇 Silakan verifikasi bukti transfer di bawah ini.`),
      `<footer>© Mclaren Project • Owner Verification Required</footer>`
    ].join('\n');

    const kb = { inline_keyboard: [[
      { text: "✅ ACC",   callback_data: `svc_acc_${txnId}`,  style: "success", icon_custom_emoji_id: EMOJI.check },
      { text: "❌ Tolak", callback_data: `svc_rej_${txnId}`, style: "danger",  icon_custom_emoji_id: EMOJI.cross }
    ]]};

    // Kirim ke owner (foto tertaut)
    const targets = new Set(loadOwnerAcc());
    if (st.store?.ownerId) targets.add(Number(st.store.ownerId));
    for (const targetId of targets) {
      await sendNotifToOwner(targetId, fileId, adminText, kb);
      await sleep(200);
    }
    return true;
  }

  async function handleDpAmountInput(msg) {
    const userId = Number(msg.from.id);
    const chatId = msg.chat.id;
    const st = serviceState.get(userId);
    if (!st || st.step !== 'awaiting_dp_amount') return false;
    const amount = parseInt((msg.text || '').replace(/[^\d]/g, ''), 10);
    const minDp = st.minDp || DP_MINIMUM;
    const maxDp = st.maxDp || Math.min(DP_MAXIMUM, st.fullPrice || DP_MAXIMUM);
    if (!amount || amount < minDp) {
      await bot.sendRichMessage(chatId, [richHeader("NOMINAL KURANG", ce(EMOJI.warning, '⚠️')), richPara(`Minimal ${rp(minDp)}.`)].join('\n'), { parse_mode: 'HTML' });
      return true;
    }
    if (amount > maxDp) {
      await bot.sendRichMessage(chatId, [richHeader("NOMINAL BERLEBIH", ce(EMOJI.warning, '⚠️')), richPara(`Maksimal ${rp(maxDp)}.`)].join('\n'), { parse_mode: 'HTML' });
      return true;
    }
    await showPaymentConfirmation(chatId, st.messageId, userId, 'dp', st.role, amount, st.isUpgrade, st.currentRole);
    return true;
  }

  // ═══════════════════════════════════════════════════════════
  // ✅ OWNER ACC / REJECT
  // ═══════════════════════════════════════════════════════════
  async function handleAccReject(query, txnId, isAcc) {
    const userId = Number(query.from.id);
    const pending = readJSON(PENDING_PAY_FILE, {});
    const txn = pending[txnId];
    if (!txn) {
      return bot.answerCallbackQuery(query.id, { text: "❌ Transaksi tidak ditemukan.", show_alert: true }).catch(() => {});
    }

    const isMainOwner = isOwnerAcc(userId);
    const isStoreOwner = txn.storeId && (() => {
      const s = findStoreById(txn.storeId);
      return s && Number(s.ownerId) === Number(userId);
    })();
    if (!isMainOwner && !isStoreOwner) {
      return bot.answerCallbackQuery(query.id, { text: "❌ Kamu tidak berhak ACC!", show_alert: true }).catch(() => {});
    }

    if (txn.status === 'accepted' || txn.status === 'rejected') {
      return bot.answerCallbackQuery(query.id, {
        text: `⚠️ Sudah di-${txn.status === 'accepted' ? 'ACC' : 'TOLAK'}.`,
        show_alert: true
      }).catch(() => {});
    }

    const isDpLunas = txn.type === 'dp_lunas';
    const info = ROLE_PRICES[txn.role];

    // ─── REJECT ─────────────────────────────────────────────
    if (!isAcc) {
      txn.status = 'rejected';
      txn.rejectedAt = new Date().toISOString();
      txn.rejectedBy = query.from.username || String(userId);
      writeJSON(PENDING_PAY_FILE, pending);
      markQueueProcessed(txnId, 'rejected');
      await bot.sendRichMessage(txn.chatId,
        [richHeader("TRANSAKSI DITOLAK", ce(EMOJI.cross, '❌')),
         richPara(`Maaf, bukti transfer kamu <b>ditolak</b>.`),
         richDiv(),
         richPara(`Silakan kirim ulang bukti transfer yang valid.`)].join('\n'),
        { parse_mode: 'HTML' }).catch(() => {});
      try {
        await bot.editMessageCaption(
          (query.message.caption || '') + `\n\n<b>❌ REJECTED by @${esc(query.from.username || userId)}</b>`,
          { chat_id: query.message.chat.id, message_id: query.message.message_id, parse_mode: 'HTML' });
        await bot.editMessageReplyMarkup({ inline_keyboard: [] }, { chat_id: query.message.chat.id, message_id: query.message.message_id });
      } catch (_) {}
      return bot.answerCallbackQuery(query.id, { text: "❌ Ditolak." }).catch(() => {});
    }

    // ─── ACC ────────────────────────────────────────────────
    txn.status = 'accepted';
    txn.acceptedAt = new Date().toISOString();
    txn.acceptedBy = query.from.username || String(userId);
    writeJSON(PENDING_PAY_FILE, pending);
    markQueueProcessed(txnId, query.from.username || String(userId));

    // ─── DP LUNAS ───────────────────────────────────────────
    if (isDpLunas) {
      const original = findPembeliByTxn(txn.originalTxnId);
      if (original) {
        const newTotalPaid = (original.totalPaid || 0) + (txn.amount || 0);
        const newSisa = Math.max(0, (original.price || 0) - newTotalPaid);
        const nowLunas = newSisa <= 0;
        updatePembeliByTxn(txn.originalTxnId, {
          totalPaid: newTotalPaid, sisa: newSisa, isLunas: nowLunas,
          lunasAt: nowLunas ? new Date().toISOString() : null
        });
        const infoLunas = ROLE_PRICES[original.role];
        const text = [
          richHeader(nowLunas ? "DP LUNAS ✅" : "PEMBAYARAN DITERIMA", nowLunas ? '🎉' : '💸'),
          richPara(nowLunas ? 'Selamat! DP kamu sudah LUNAS.' : 'Pembayaran tambahan kamu sudah diterima.'),
          richDiv(),
          richTable([
            ["🧾 TX ID", original.txnId],
            ["🎭 Role", infoLunas?.label || original.role.toUpperCase()],
            ["💵 Nominal Bayar", rp(txn.amount || 0)],
            ["💰 Total Dibayar", rp(newTotalPaid)],
            ["📊 Sisa", nowLunas ? '✅ LUNAS' : rp(newSisa)]
          ])
        ].join('\n');
        await bot.sendRichMessage(original.userId, text, { parse_mode: 'HTML' }).catch(() => {});
      }
      try {
        await bot.editMessageCaption(
          (query.message.caption || '') + `\n\n<b>✅ ACCEPTED by @${esc(query.from.username || userId)}</b>`,
          { chat_id: query.message.chat.id, message_id: query.message.message_id, parse_mode: 'HTML' });
        await bot.editMessageReplyMarkup({ inline_keyboard: [] }, { chat_id: query.message.chat.id, message_id: query.message.message_id });
      } catch (_) {}
      return bot.answerCallbackQuery(query.id, { text: "✅ Pelunasan di-ACC." }).catch(() => {});
    }

    // ─── NEW PURCHASE ───────────────────────────────────────
    const price = info?.price || 0;
    const isUpgrade = !!txn.isUpgrade;
    const isDp = txn.mode === 'dp';
    const totalPaid = txn.payAmount || 0;
    const sisa = Math.max(0, price - totalPaid);
    const isLunas = !isDp || sisa <= 0;

    const record = {
      txnId, userId: txn.userId, username: txn.username,
      role: txn.role, roleLabel: info?.label || txn.role,
      mode: txn.mode, payAmount: totalPaid, totalPaid, price,
      sisa: isLunas ? 0 : sisa, isLunas,
      isUpgrade, previousRole: txn.currentRole || null,
      storeId: txn.storeId || null, storeName: txn.storeName || null,
      dpAt: isDp ? new Date().toISOString() : null,
      deadline: (isDp && !isLunas) ? new Date(Date.now() + DP_MAX_DAYS * 86400000).toISOString() : null,
      accessGiven: false, createdAccount: false,
      purchasedAt: new Date().toISOString(),
      rawUsername: txn.username, nameHistory: [txn.username],
      acceptedAt: new Date().toISOString(),
      acceptedBy: query.from.username || String(userId),
      stage: 'awaiting_perm',
      proofFileId: txn.proofFileId || null
    };
    const pembeli = readJSON(PEMBELI_FILE, []);
    pembeli.push(record);
    writeJSON(PEMBELI_FILE, pembeli);

    // ─── Broadcast text ke admin group ──────────────────────
    const broadcastText = buildSuccessBroadcast(record);
    try { await bot.sendRichMessage(ADMIN_GROUP_ID, broadcastText, { parse_mode: 'HTML' }); } catch (_) {}

    // ─── TESTIMONIAL ke CHANNEL dengan FOTO BUKTI (tertaut) ──
    await sendTestimonialToChannel(record, txn.proofFileId);

    // ─── Kirim links + tanya create ────────────────────────
    await sendGroupLinksToBuyer(txn.userId, txn.role, txnId, txn.mode, isUpgrade);
    await askCreatePermission(txn.userId, txnId);

    try {
      await bot.editMessageCaption(
        (query.message.caption || '') + `\n\n<b>✅ ACCEPTED by @${esc(query.from.username || userId)}</b>`,
        { chat_id: query.message.chat.id, message_id: query.message.message_id, parse_mode: 'HTML' });
      await bot.editMessageReplyMarkup({ inline_keyboard: [] }, { chat_id: query.message.chat.id, message_id: query.message.message_id });
    } catch (_) {}

    return bot.answerCallbackQuery(query.id, { text: "✅ ACC! Notif dikirim." }).catch(() => {});
  }

  async function handleAllow(txnId, callbackUserId) {
    const record = findPembeliByTxn(txnId);
    if (!record) return { ok: false, msg: "❌ Data tidak ditemukan." };
    if (Number(record.userId) !== Number(callbackUserId)) return { ok: false, msg: "❌ Bukan transaksi kamu!" };
    if (record.accessGiven) return { ok: false, msg: "⏳ Sudah diberikan." };
    updatePembeliByTxn(txnId, { accessGiven: true, accessGivenAt: new Date().toISOString(), stage: 'perm_granted' });
    try {
      const cfg = fs.existsSync(TELEGRAM_FILE) ? JSON.parse(fs.readFileSync(TELEGRAM_FILE, 'utf8')) : { ownerList: [], userList: [] };
      cfg.userList = Array.isArray(cfg.userList) ? cfg.userList : [];
      if (!cfg.userList.includes(record.userId)) cfg.userList.push(record.userId);
      fs.writeFileSync(TELEGRAM_FILE, JSON.stringify(cfg, null, 2));
    } catch (_) {}
    await askCreateOrLater(record.userId, txnId, record.role);
    return { ok: true, msg: "✅ Akses create aktif!" };
  }

  async function handleDeny(txnId, callbackUserId) {
    const record = findPembeliByTxn(txnId);
    if (!record) return { ok: false, msg: "❌ Data tidak ditemukan." };
    if (Number(record.userId) !== Number(callbackUserId)) return { ok: false, msg: "❌ Bukan transaksi kamu!" };
    updatePembeliByTxn(txnId, { accessGiven: false, accessDeniedAt: new Date().toISOString(), stage: 'denied' });
    try {
      await bot.sendRichMessage(record.userId,
        [richHeader("AKSES DITOLAK", ce(EMOJI.cross, '❌')), richPara(`Baik, ID kamu tidak diizinkan membuat akun.`)].join('\n'),
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: "🏠 Menu Utama", callback_data: "mainmenu", style: "primary" }]] } });
    } catch (_) {}
    return { ok: true, msg: "❌ Akses ditolak." };
  }

  async function handleDoCreate(txnId, callbackUserId) {
    const record = findPembeliByTxn(txnId);
    if (!record) return { ok: false, msg: "❌ Data tidak ditemukan." };
    if (Number(record.userId) !== Number(callbackUserId)) return { ok: false, msg: "❌ Bukan transaksi kamu!" };
    if (!record.accessGiven) return { ok: false, msg: "❌ Belum diizinkan." };
    await sendCreateMethodPicker(record.userId);
    return { ok: true, msg: "✅ Pilih metode." };
  }

  async function handleLater(txnId, callbackUserId) {
    const record = findPembeliByTxn(txnId);
    if (!record) return { ok: false, msg: "❌ Data tidak ditemukan." };
    if (Number(record.userId) !== Number(callbackUserId)) return { ok: false, msg: "❌ Bukan transaksi kamu!" };
    try {
      await bot.sendRichMessage(record.userId,
        [richHeader("BAIK, NANTI SAJA", ce(EMOJI.clock, '⏰')),
         richPara(`Akses create kamu <b>sudah aktif</b>. Bisa buat kapan saja lewat <code>/create</code>.`)].join('\n'),
        { parse_mode: 'HTML' });
    } catch (_) {}
    return { ok: true, msg: "⏰ Nanti saja." };
  }

  async function showMyDP(chatId, messageId, userId) {
    const pembeli = readJSON(PEMBELI_FILE, []);
    const my = pembeli.filter(p => Number(p.userId) === Number(userId) && !p.isLunas);
    if (messageId) await animateLoading(chatId, messageId, "Mengambil data DP");
    if (!my.length) {
      return sendOrEditRich(chatId, messageId,
        [richHeader("TIDAK ADA DP", ce(EMOJI.check, '✅')),
         richPara(`Kamu tidak memiliki tagihan DP yang belum lunas. Terima kasih! 🙏`)].join('\n'),
        { inline_keyboard: [[{ text: "🔙 Kembali", callback_data: "svc_menu", style: "primary", icon_custom_emoji_id: EMOJI.exit }]] });
    }
    let lines = [richHeader("TAGIHAN DP KAMU", ce(EMOJI.money, '💸')), ``];
    const lunasinButtons = [];
    my.forEach((p, i) => {
      const sisa = Math.max(0, (p.price || 0) - (p.totalPaid || 0));
      const deadline = p.deadline ? new Date(p.deadline) : null;
      const daysLeft = deadline ? Math.max(0, Math.ceil((deadline - Date.now()) / 86400000)) : 0;
      const deadlineStr = deadline ? deadline.toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' }) : '-';
      lines.push(richHeader(`${i + 1}. TX ${p.txnId}`, ce(EMOJI.receipt, '🧾')));
      lines.push(richTable([
        ["🎭 Role", p.roleLabel || p.role.toUpperCase()],
        ["💰 Harga Total", rp(p.price)],
        ["✅ Sudah Dibayar", rp(p.totalPaid)],
        ["💸 Sisa Harus Bayar", rp(sisa)],
        ["⏰ Batas Pelunasan", deadlineStr],
        ["⏳ Sisa Hari", `${daysLeft} hari lagi`]
      ]));
      lines.push(``);
      lunasinButtons.push([{
        text: `💳 LUNASIN - ${p.roleLabel || p.role.toUpperCase()}`,
        callback_data: `svc_dp_lunasin_${p.txnId}`,
        style: "danger", icon_custom_emoji_id: EMOJI.fire
      }]);
    });
    lines.push(richDiv());
    lines.push(richQuote(`⚠️ Lunasi sebelum deadline untuk menghindari <b>freeze akun</b>.`));
    const keyboard = { inline_keyboard: [...lunasinButtons, [{ text: "🔙 Kembali", callback_data: "svc_menu", style: "primary", icon_custom_emoji_id: EMOJI.exit }]] };
    return sendOrEditRich(chatId, messageId, lines.join('\n'), keyboard);
  }

  async function startLunasin(chatId, messageId, userId, txnId) {
    const record = findPembeliByTxn(txnId);
    if (!record) return sendOrEditRich(chatId, messageId, [richHeader("DATA TIDAK DITEMUKAN", ce(EMOJI.cross, '❌'))].join('\n'), { inline_keyboard: [[{ text: "🔙 Kembali", callback_data: "svc_my_dp", style: "primary" }]] });
    if (Number(record.userId) !== Number(userId)) return sendOrEditRich(chatId, messageId, [richHeader("BUKAN MILIK KAMU", ce(EMOJI.cross, '❌'))].join('\n'), { inline_keyboard: [[{ text: "🔙 Kembali", callback_data: "svc_my_dp", style: "primary" }]] });
    if (record.isLunas) return sendOrEditRich(chatId, messageId, [richHeader("SUDAH LUNAS", ce(EMOJI.check, '✅'))].join('\n'), { inline_keyboard: [[{ text: "🔙 Kembali", callback_data: "svc_my_dp", style: "primary" }]] });

    await animateLoading(chatId, messageId, "Mengambil data pelunasan");
    const sisa = Math.max(0, (record.price || 0) - (record.totalPaid || 0));
    const deadline = record.deadline ? new Date(record.deadline) : null;
    const daysLeft = deadline ? Math.max(0, Math.ceil((deadline - Date.now()) / 86400000)) : 0;
    const store = record.storeId ? findStoreById(record.storeId) : null;
    const pm = store ? {
      qris_url: store.qrisUrl || "https://files.catbox.moe/ycl8sk.jpg",
      dana: store.dana || '-', ovo: store.ovo || '-',
      gopay: store.gopay || '-', shopeepay: store.shopeepay || '-'
    } : loadPaymentInfo();
    const info = ROLE_PRICES[record.role];

    const text = [
      richHeader("PELUNASAN DP", ce(EMOJI.money, '💳')),
      richPara(`Silakan transfer sisa DP kamu.`),
      richDiv(),
      richHeader("DETAIL PELUNASAN", ce(EMOJI.receipt, '🧾')),
      richTable([
        ["🧾 TX ID", record.txnId],
        ["🎭 Role", info?.label || record.role.toUpperCase()],
        ["💸 Sisa yang Harus Dibayar", rp(sisa)],
        ["⏰ Deadline", deadline ? deadline.toLocaleDateString('id-ID') : '-'],
        ["⏳ Sisa Hari", `${daysLeft} hari lagi`]
      ]),
      richDiv(),
      richHeader("METODE PEMBAYARAN", ce(EMOJI.wallet, '💳')),
      richPara(`📱 <b>QRIS:</b> Scan gambar di bawah`),
      richPara(`💙 <b>DANA:</b> <code>${pm.dana}</code>`),
      richPara(`💜 <b>OVO:</b> <code>${pm.ovo}</code>`),
      pm.gopay && pm.gopay !== '-' ? richPara(`💚 <b>GOPAY:</b> <code>${pm.gopay}</code>`) : '',
      pm.shopeepay && pm.shopeepay !== '-' ? richPara(`🧡 <b>SHOPEEPAY:</b> <code>${pm.shopeepay}</code>`) : '',
      richDiv(),
      richPara(`👇 Klik <b>Lanjutkan Lunas</b> untuk kirim bukti TF.`)
    ].filter(Boolean).join('\n');

    if (messageId) await bot.deleteMessage(chatId, messageId).catch(() => {});

    const kb = { inline_keyboard: [
      [{ text: "✅ Lanjutkan Lunas", callback_data: `svc_dp_lunas_go_${txnId}`, style: "success", icon_custom_emoji_id: EMOJI.check }],
      [{ text: "❌ Tunda Lunas",     callback_data: `svc_dp_lunas_later_${txnId}`, style: "danger", icon_custom_emoji_id: EMOJI.clock }]
    ]};

    try {
      await bot.sendPhoto(chatId, pm.qris_url, {
        caption: stripRichTags(text),
        parse_mode: 'HTML',
        reply_markup: kb
      });
    } catch (e) {
      await bot.sendRichMessage(chatId, text, { parse_mode: 'HTML', reply_markup: kb });
    }
  }

  async function proceedLunasin(chatId, messageId, userId, txnId) {
    const record = findPembeliByTxn(txnId);
    if (!record) return;
    await animateLoading(chatId, messageId, "Menyiapkan form pelunasan");
    const sisa = Math.max(0, (record.price || 0) - (record.totalPaid || 0));
    const store = record.storeId ? findStoreById(record.storeId) : null;
    const pm = store ? {
      qris_url: store.qrisUrl || "https://files.catbox.moe/ycl8sk.jpg",
      dana: store.dana || '-', ovo: store.ovo || '-',
      gopay: store.gopay || '-', shopeepay: store.shopeepay || '-'
    } : loadPaymentInfo();

    const text = [
      richHeader("KIRIM BUKTI TF PELUNASAN", '📸'),
      richPara(`Silakan kirim bukti transfer sisa DP kamu.`),
      richDiv(),
      richHeader("DETAIL", ce(EMOJI.receipt, '🧾')),
      richTable([
        ["🧾 TX ID", record.txnId],
        ["💸 Sisa yang Harus Dibayar", rp(sisa)]
      ]),
      richDiv(),
      richHeader("METODE PEMBAYARAN", ce(EMOJI.wallet, '💳')),
      richPara(`📱 <b>QRIS:</b> Scan gambar di atas`),
      richPara(`💙 <b>DANA:</b> <code>${pm.dana}</code>`),
      richPara(`💜 <b>OVO:</b> <code>${pm.ovo}</code>`),
      richDiv(),
      richHeader("INSTRUKSI", ce(EMOJI.guide, '📖')),
      richPara(`Kirim <b>FOTO bukti transfer</b> + <b>caption nominal</b>.`),
      richQuote(`Contoh caption: <code>${sisa}</code>`)
    ].filter(Boolean).join('\n');

    if (messageId) await bot.deleteMessage(chatId, messageId).catch(() => {});
    try {
      await bot.sendPhoto(chatId, pm.qris_url, { caption: stripRichTags(text), parse_mode: 'HTML' });
    } catch (e) {
      await bot.sendRichMessage(chatId, text, { parse_mode: 'HTML' });
    }
    serviceState.set(userId, { step: 'awaiting_dp_lunas_proof', txnId, sisaExpected: sisa });
  }

  async function handleDpLunasProof(msg) {
    const userId = Number(msg.from.id);
    const chatId = msg.chat.id;
    const st = serviceState.get(userId);
    if (!st || st.step !== 'awaiting_dp_lunas_proof') return false;
    if (!msg.photo || !msg.photo.length) {
      await bot.sendRichMessage(chatId, [richHeader("KIRIM FOTO", ce(EMOJI.warning, '⚠️'))].join('\n'), { parse_mode: 'HTML' });
      return true;
    }
    const caption = (msg.caption || '').trim();
    const amount = parseInt(caption.replace(/[^\d]/g, ''), 10);
    if (!amount || amount <= 0) {
      await bot.sendRichMessage(chatId,
        [richHeader("NOMINAL TIDAK VALID", ce(EMOJI.warning, '⚠️')),
         richPara(`Kirim ulang foto + <b>caption nominal</b>.`)].join('\n'), { parse_mode: 'HTML' });
      return true;
    }
    const record = findPembeliByTxn(st.txnId);
    if (!record) { serviceState.delete(userId); return true; }
    const sisaNow = Math.max(0, (record.price || 0) - (record.totalPaid || 0));
    const fileId = msg.photo[msg.photo.length - 1].file_id;
    const lunasId = `LNS-${Date.now().toString(36).toUpperCase()}`;
    const pending = readJSON(PENDING_PAY_FILE, {});
    pending[lunasId] = {
      type: 'dp_lunas', txnId: lunasId, originalTxnId: st.txnId, userId,
      username: msg.from.username || msg.from.first_name || `User_${userId}`,
      role: record.role, amount, sisaBefore: sisaNow, willBeLunas: amount >= sisaNow,
      proofFileId: fileId, caption, chatId,
      storeId: record.storeId || null,
      createdAt: new Date().toISOString(), status: 'pending'
    };
    writeJSON(PENDING_PAY_FILE, pending);
    serviceState.delete(userId);

    await bot.sendRichMessage(chatId,
      [richHeader("BUKTI PELUNASAN DITERIMA", ce(EMOJI.check, '✅')),
       richPara(`Bukti pelunasan sudah dikirim ke owner.`),
       richDiv(),
       richTable([
         ["🧾 Pelunasan ID", lunasId],
         ["💵 Nominal", rp(amount)],
         ["📊 Status", amount >= sisaNow ? '✅ FULL LUNAS' : `⚠️ Sisa: ${rp(sisaNow - amount)}`]
       ]),
       richDiv(),
       richQuote(`⏳ <i>Tunggu verifikasi owner maks 5 menit.</i>`)].join('\n'), { parse_mode: 'HTML' });

    const info = ROLE_PRICES[record.role];
    const adminText = [
      richHeader("DP LUNAS REQUEST", ce(EMOJI.receipt, '💰')),
      richPara(`Ada permintaan pelunasan DP!`),
      richDiv(),
      richHeader("DETAIL PELUNASAN", ce(EMOJI.receipt, '🧾')),
      richTable([
        ["🧾 Pelunasan ID", lunasId],
        ["🧾 Original TX", st.txnId],
        ["👤 User", pending[lunasId].username],
        ["🆔 User ID", String(userId)],
        ["🎭 Role", info?.label || record.role.toUpperCase()],
        ["💵 Nominal", rp(amount)],
        ["💸 Sisa Sebelum", rp(sisaNow)],
        ["📊 Status", amount >= sisaNow ? '✅ LUNAS' : `Sisa: ${rp(sisaNow - amount)}`]
      ]),
      richDiv(),
      richQuote(`👇 Silakan verifikasi bukti pelunasan di bawah ini.`),
      `<footer>© Mclaren Project • Owner Verification Required</footer>`
    ].join('\n');

    const kb = { inline_keyboard: [[
      { text: "✅ ACC",   callback_data: `svc_acc_${lunasId}`,  style: "success", icon_custom_emoji_id: EMOJI.check },
      { text: "❌ Tolak", callback_data: `svc_rej_${lunasId}`, style: "danger",  icon_custom_emoji_id: EMOJI.cross }
    ]]};
    const targets = new Set(loadOwnerAcc());
    const store = record.storeId ? findStoreById(record.storeId) : null;
    if (store?.ownerId) targets.add(Number(store.ownerId));
    for (const targetId of targets) {
      await sendNotifToOwner(targetId, fileId, adminText, kb);
      await sleep(200);
    }
    return true;
  }

  // ═══════════════════════════════════════════════════════════
  // 🔔 REMINDERS
  // ═══════════════════════════════════════════════════════════
  async function sendDpReminders() {
    const pembeli = readJSON(PEMBELI_FILE, []);
    const unpaid = pembeli.filter(p => !p.isLunas && p.deadline);
    for (const p of unpaid) {
      const sisa = Math.max(0, (p.price || 0) - (p.totalPaid || 0));
      if (sisa <= 0) continue;
      const deadline = new Date(p.deadline);
      const daysLeft = Math.max(0, Math.ceil((deadline - Date.now()) / 86400000));
      const info = ROLE_PRICES[p.role];
      const text = [
        richHeader("REMINDER DP BELUM LUNAS", ce(EMOJI.bell, '🔔')),
        richPara(`Halo <b>${esc(p.username)}</b>, DP kamu masih belum lunas!`),
        richDiv(),
        richTable([
          ["🧾 TX ID", p.txnId],
          ["🎭 Role", info?.label || p.role.toUpperCase()],
          ["💸 Sisa", rp(sisa)],
          ["⏰ Deadline", deadline.toLocaleDateString('id-ID')],
          ["⏳ Sisa Hari", `${daysLeft} hari lagi`]
        ])
      ].join('\n');
      try {
        await bot.sendRichMessage(p.userId, text, {
          parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [
            [{ text: "💳 LUNASIN", callback_data: `svc_dp_lunasin_${p.txnId}`, style: "danger", icon_custom_emoji_id: EMOJI.fire }],
            [{ text: "📋 Cek DP", callback_data: "svc_my_dp", style: "primary", icon_custom_emoji_id: EMOJI.money }]
          ]}
        });
      } catch (_) {}
    }
  }
  setInterval(() => { sendDpReminders().catch(() => {}); }, REMINDER_INTERVAL);

  async function checkUsernameChanges() {
    const pembeli = readJSON(PEMBELI_FILE, []);
    let changed = false;
    for (const p of pembeli) {
      if (p.isLunas) continue;
      try {
        const chat = await bot.getChat(p.userId);
        const current = chat.username || chat.first_name || p.username;
        if (p.username !== current) {
          const oldName = p.username;
          p.nameHistory = p.nameHistory || [oldName];
          p.nameHistory.push(current);
          p.username = current;
          changed = true;
          await bot.sendRichMessage(p.userId,
            [richHeader("PERINGATAN KERAS", '🚨'),
             richPara(`Kamu terdeteksi ganti nama untuk hindari DP!`),
             richDiv(),
             richTable([
               ["🧾 TX ID", p.txnId],
               ["👤 Nama Lama", oldName],
               ["👤 Nama Baru", current],
               ["💸 Sisa", rp(p.price - p.totalPaid)]
             ])].join('\n'), { parse_mode: 'HTML' }).catch(() => {});
        }
      } catch (_) {}
    }
    if (changed) writeJSON(PEMBELI_FILE, pembeli);
  }
  setInterval(() => { checkUsernameChanges().catch(() => {}); }, 6 * 60 * 60 * 1000);

  // ═══════════════════════════════════════════════════════════
  // 🏪 ADD LAYANAN WIZARD
  // ═══════════════════════════════════════════════════════════
  const WS = {
    NAME: 'name', ROLE: 'role', QRIS: 'qris',
    DANA: 'dana', OVO: 'ovo', GOPAY: 'gopay', SHOPEEPAY: 'shopeepay',
    OWNERID: 'ownerid', DURATION: 'duration', DURATION_CUSTOM: 'duration_custom'
  };

  const STEP_LABEL = {
    [WS.NAME]: "1 / 9 — 📛 Nama Store",
    [WS.ROLE]: "2 / 9 — 🎭 Role Tertinggi",
    [WS.QRIS]: "3 / 9 — 📱 URL QRIS",
    [WS.DANA]: "4 / 9 — 💙 Nomor DANA",
    [WS.OVO]:  "5 / 9 — 💜 Nomor OVO",
    [WS.GOPAY]:"6 / 9 — 💚 Nomor GOPAY",
    [WS.SHOPEEPAY]:"7 / 9 — 🧡 Nomor ShopeePay",
    [WS.OWNERID]: "8 / 9 — 👤 Owner ID",
    [WS.DURATION]:"9 / 9 — ⏳ Durasi Store",
    [WS.DURATION_CUSTOM]: "9 / 9 — ✏️ Custom Durasi"
  };

  async function showAddLayananIntro(chatId, messageId, userId) {
    const text = [
      richHeader("TAMBAH LAYANAN STORE", ce(EMOJI.store, '🏪')),
      richPara(`Fitur ini untuk menambahkan <b>store baru</b> ke Menu Layanan.`),
      richDiv(),
      richHeader("PANDUAN 9 STEP", ce(EMOJI.guide, '📖')),
      richTable([
        ["Step 1", "📛 Nama store"],
        ["Step 2", "🎭 Role tertinggi"],
        ["Step 3", "📱 URL QRIS"],
        ["Step 4-7", "💙💜💚🧡 Nomor e-wallet"],
        ["Step 8", "👤 Telegram ID owner store"],
        ["Step 9", "⏳ Durasi aktif store"]
      ]),
      richDiv(),
      richQuote(`⚠️ <b>Catatan:</b> Store lama tidak akan terhapus saat menambah store baru.`),
      richPara(`👇 Klik tombol di bawah untuk memulai:`)
    ].join('\n');

    const kb = { inline_keyboard: [
      [{ text: "➕ Tambahkan Layanan Baru", callback_data: "aln_start", style: "success", icon_custom_emoji_id: EMOJI.plus }],
      [{ text: "📋 Kelola Store", callback_data: "aln_manage", style: "primary", icon_custom_emoji_id: EMOJI.store }],
      [{ text: "❌ Exit Layanan", callback_data: "svc_exit", style: "danger", icon_custom_emoji_id: EMOJI.exit }]
    ]};

    await sendOrEditRich(chatId, messageId, text, kb);
  }

  async function startAddLayanan(chatId, messageId, userId) {
    storeWizard.set(userId, { step: WS.NAME, data: {} });
    await animateLoading(chatId, messageId, "Memulai wizard");

    const text = [
      richHeader(STEP_LABEL[WS.NAME], '📛'),
      richPara(`Kirim <b>nama store</b> yang ingin ditampilkan.`),
      richDiv(),
      richTable([
        ["Minimal", "2 karakter"],
        ["Maksimal", "30 karakter"],
        ["Contoh", "Kyuro, Cloude, Vinz"]
      ]),
      richDiv(),
      richPara(`Ketik <b>/batal</b> untuk membatalkan.`)
    ].join('\n');

    await sendOrEditRich(chatId, messageId, text, {
      inline_keyboard: [[{ text: "❌ Batal Wizard", callback_data: "aln_exit", style: "danger", icon_custom_emoji_id: EMOJI.cross }]]
    });
  }

  async function showStoreManager(chatId, messageId, userId) {
    if (messageId) await animateLoading(chatId, messageId, "Memuat store");
    const stores = loadAllStores();
    if (!stores.length) {
      return sendOrEditRich(chatId, messageId,
        [richHeader("BELUM ADA STORE", ce(EMOJI.store, '🏪')),
         richPara(`Belum ada store yang ditambahkan.`),
         richDiv(),
         richPara(`Klik tombol di bawah untuk menambahkan store baru.`)].join('\n'),
        { inline_keyboard: [
          [{ text: "➕ Tambah Layanan Baru", callback_data: "aln_start", style: "success", icon_custom_emoji_id: EMOJI.plus }],
          [{ text: "❌ Exit", callback_data: "svc_menu", style: "danger", icon_custom_emoji_id: EMOJI.exit }]
        ]});
    }

    const rows = stores.map(s => {
      const highLabel = ROLE_PRICES[s.highestRole]?.label || s.highestRole || '-';
      const status = s.permanent ? '♾️' : (s.active ? '✅' : '❌');
      const exp = s.permanent ? 'PERMANEN' : (s.expiresAt ? new Date(s.expiresAt).toLocaleDateString('id-ID') : '-');
      const prefix = s.special === 'developer' ? '💎' : s.special === 'admin' ? '👑' : '🏪';
      return [`${status} ${prefix} ${s.name}`, `${highLabel} • ${exp}`];
    });

    const text = [
      richHeader("KELOLA STORE", ce(EMOJI.store, '🏪')),
      richPara(`Total: <b>${stores.length} store</b>`),
      richDiv(),
      richTable(rows, ["Store", "Info"]),
      richDiv(),
      richPara(`Pilih store untuk dihapus di bawah 👇`),
      richPara(`<i>⚠️ Store default (💎 / 👑) akan otomatis dibuat ulang jika dihapus.</i>`)
    ].join('\n');

    const delRows = stores.map(s => ([{
      text: `🗑️ Hapus: ${s.name}`,
      callback_data: `aln_del_${s.id}`,
      style: "danger", icon_custom_emoji_id: EMOJI.trash
    }]));
    delRows.push([{ text: "➕ Tambah Baru", callback_data: "aln_start", style: "success", icon_custom_emoji_id: EMOJI.plus }]);
    delRows.push([{ text: "🔙 Kembali", callback_data: "svc_menu", style: "primary", icon_custom_emoji_id: EMOJI.exit }]);

    await sendOrEditRich(chatId, messageId, text, { inline_keyboard: delRows });
  }

  async function handleAddLayananText(msg) {
    const userId = Number(msg.from.id);
    const chatId = msg.chat.id;
    const st = storeWizard.get(userId);
    if (!st) return false;
    const text = (msg.text || '').trim();

    if (/^\/batal$/i.test(text)) {
      storeWizard.delete(userId);
      await bot.sendRichMessage(chatId, richHeader("WIZARD DIBATALKAN", ce(EMOJI.cross, '❌')), { parse_mode: 'HTML' });
      return true;
    }
    if (/^\//.test(text)) return false;

    const nextPrompt = async (step, promptText, extraKb = null) => {
      st.step = step;
      storeWizard.set(userId, st);
      const kb = extraKb || { inline_keyboard: [[{ text: "❌ Batal Wizard", callback_data: "aln_exit", style: "danger", icon_custom_emoji_id: EMOJI.cross }]] };
      await bot.sendRichMessage(chatId,
        [richHeader(STEP_LABEL[step], ''), promptText].join('\n'),
        { parse_mode: 'HTML', reply_markup: kb });
    };

    if (st.step === WS.NAME) {
      if (text.length < 2 || text.length > 30) {
        return bot.sendRichMessage(chatId, [richHeader("NAMA TIDAK VALID", ce(EMOJI.warning, '⚠️')), richPara(`2-30 karakter.`)].join('\n'), { parse_mode: 'HTML' }).then(() => true);
      }
      st.data.name = text;
      const rows = [];
      ROLE_ORDER.filter(r => ROLE_PRICES[r]).forEach(role => {
        const info = ROLE_PRICES[role];
        rows.push([{
          text: `${info.emoji} ${info.label}`,
          callback_data: `aln_role_${role}`,
          style: info.style || 'primary',
          icon_custom_emoji_id: EMOJI.money
        }]);
      });
      rows.push([{ text: "❌ Batal", callback_data: "aln_exit", style: "danger", icon_custom_emoji_id: EMOJI.cross }]);
      await nextPrompt(WS.ROLE,
        [richPara(`Pilih <b>role tertinggi</b> yang store jual.`),
         richPara(`Role di bawahnya otomatis termasuk.`),
         richDiv(),
         richPara(`Contoh: <b>Partner</b> → jual <code>member … partner</code>`)].join('\n'),
        { inline_keyboard: rows });
      return true;
    }

    if (st.step === WS.QRIS) {
      if (!text.startsWith('http')) {
        return bot.sendRichMessage(chatId, [richHeader("URL TIDAK VALID", ce(EMOJI.warning, '⚠️')), richPara(`Harus diawali http/https.`)].join('\n'), { parse_mode: 'HTML' }).then(() => true);
      }
      st.data.qrisUrl = text;
      await nextPrompt(WS.DANA, richPara(`Kirim nomor <b>DANA</b> atau ketik <code>-</code> kalau kosong.`));
      return true;
    }

    if (st.step === WS.DANA) {
      st.data.dana = text === '-' ? '' : text;
      await nextPrompt(WS.OVO, richPara(`Kirim nomor <b>OVO</b> atau ketik <code>-</code>.`));
      return true;
    }

    if (st.step === WS.OVO) {
      st.data.ovo = text === '-' ? '' : text;
      await nextPrompt(WS.GOPAY, richPara(`Kirim nomor <b>GOPAY</b> atau ketik <code>-</code>.`));
      return true;
    }

    if (st.step === WS.GOPAY) {
      st.data.gopay = text === '-' ? '' : text;
      await nextPrompt(WS.SHOPEEPAY, richPara(`Kirim nomor <b>SHOPEEPAY</b> atau ketik <code>-</code>.`));
      return true;
    }

    if (st.step === WS.SHOPEEPAY) {
      st.data.shopeepay = text === '-' ? '' : text;
      await nextPrompt(WS.OWNERID, [richPara(`Kirim <b>Telegram ID</b> owner store.`), richPara(`Contoh: <code>8880837641</code>`)].join('\n'));
      return true;
    }

    if (st.step === WS.OWNERID) {
      const id = Number(text.replace(/\D/g, ''));
      if (!id || id < 1) {
        return bot.sendRichMessage(chatId, [richHeader("ID TIDAK VALID", ce(EMOJI.warning, '⚠️'))].join('\n'), { parse_mode: 'HTML' }).then(() => true);
      }
      st.data.ownerId = id;
      const durationButtons = [
        [
          { text: "📅 1 Hari",  callback_data: "aln_dur_1_day",  style: "primary" },
          { text: "📅 7 Hari",  callback_data: "aln_dur_7_day",  style: "primary" }
        ],
        [
          { text: "📅 30 Hari", callback_data: "aln_dur_30_day", style: "success" },
          { text: "📅 90 Hari", callback_data: "aln_dur_90_day", style: "success" }
        ],
        [
          { text: "📅 180 Hari",callback_data: "aln_dur_180_day",style: "success" },
          { text: "📅 365 Hari",callback_data: "aln_dur_365_day",style: "success" }
        ],
        [
          { text: "✏️ Custom",   callback_data: "aln_dur_custom",style: "primary" },
          { text: "♾️ PERMANEN", callback_data: "aln_dur_permanent", style: "danger" }
        ],
        [{ text: "❌ Batal", callback_data: "aln_exit", style: "danger", icon_custom_emoji_id: EMOJI.cross }]
      ];
      await nextPrompt(WS.DURATION,
        [richPara(`Pilih berapa lama store aktif di Menu Layanan.`),
         richPara(`Setelah kadaluarsa, store otomatis <b>di-nonaktifkan</b>.`)].join('\n'),
        { inline_keyboard: durationButtons });
      return true;
    }

    if (st.step === WS.DURATION_CUSTOM) {
      const m = text.match(/^(\d+)\s+(hari|day|days|minggu|week|weeks|bulan|month|months)$/i);
      if (!m) {
        return bot.sendRichMessage(chatId,
          [richHeader("FORMAT SALAH", ce(EMOJI.warning, '⚠️')),
           richPara(`Format: <code>3 minggu</code> / <code>2 bulan</code> / <code>14 hari</code>`)].join('\n'),
          { parse_mode: 'HTML' }).then(() => true);
      }
      const num = parseInt(m[1], 10);
      const unit = m[2].toLowerCase();
      let days = num;
      if (/minggu|week/i.test(unit)) days = num * 7;
      else if (/bulan|month/i.test(unit)) days = num * 30;

      st.data.durationDays = days;
      st.data.durationLabel = `${num} ${unit}`;
      st.data.permanent = false;
      storeWizard.delete(userId);
      await saveNewStore(chatId, userId, st.data);
      return true;
    }

    return false;
  }

  async function saveNewStore(chatId, userId, data) {
    const stores = loadAllStores();
    const id = `store_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`;
    const expiresAt = data.permanent ? null : new Date(Date.now() + data.durationDays * 86400000).toISOString();

    const newStore = {
      id, name: data.name, highestRole: data.highestRole,
      qrisUrl: data.qrisUrl,
      dana: data.dana || '', ovo: data.ovo || '',
      gopay: data.gopay || '', shopeepay: data.shopeepay || '',
      ownerId: data.ownerId,
      permanent: !!data.permanent,
      durationDays: data.permanent ? 0 : data.durationDays,
      durationLabel: data.permanent ? 'PERMANEN' : data.durationLabel,
      createdAt: new Date().toISOString(),
      expiresAt, active: true, createdBy: userId
    };
    stores.push(newStore);
    saveAllStores(stores);

    console.log(`[DP] ✅ Store saved: ${data.name} (total: ${stores.length})`);

    try {
      await bot.sendRichMessage(data.ownerId,
        [richHeader("STORE DITAMBAHKAN", ce(EMOJI.check, '🎉')),
         richPara(`Store kamu telah didaftarkan di Menu Layanan Mclaren Project.`),
         richDiv(),
         richTable([
           ["🏪 Nama Store", data.name],
           ["🎭 Role Tertinggi", ROLE_PRICES[data.highestRole]?.label || data.highestRole],
           ["⏰ Durasi", data.permanent ? '♾️ PERMANEN' : data.durationLabel],
           ["📅 Expired", data.permanent ? 'Selamanya' : new Date(expiresAt).toLocaleDateString('id-ID')]
         ]),
         richDiv(),
         richPara(`Kamu akan menerima notifikasi ketika ada pembeli.`)].join('\n'),
        { parse_mode: 'HTML' });
    } catch (_) {}

    await sendOrEditRich(chatId, null,
      [richHeader("STORE BERHASIL DITAMBAHKAN", ce(EMOJI.check, '🎉')),
       richPara(`Store baru sudah aktif di Menu Layanan.`),
       richDiv(),
       richTable([
         ["🆔 ID Store", id],
         ["🏪 Nama", data.name],
         ["🎭 Role Tertinggi", ROLE_PRICES[data.highestRole]?.label || data.highestRole],
         ["⏰ Durasi", data.permanent ? '♾️ PERMANEN' : data.durationLabel],
         ["📅 Expired", data.permanent ? 'Selamanya' : new Date(expiresAt).toLocaleDateString('id-ID')],
         ["👤 Owner ID", String(data.ownerId)],
         ["📊 Total Store", `${stores.length} store`]
       ]),
       richDiv(),
       richPara(`Store ini sekarang aktif di Menu Layanan.`)].join('\n'),
      { inline_keyboard: [
        [{ text: "🛒 Menu Layanan", callback_data: "svc_menu", style: "success", icon_custom_emoji_id: EMOJI.services }],
        [{ text: "📋 Kelola Store",  callback_data: "aln_manage", style: "primary", icon_custom_emoji_id: EMOJI.store }]
      ]});
  }

  try {
    bot.onText(/^\/addlayanan$/i, async (msg) => {
      const chatId = msg.chat.id;
      const userId = Number(msg.from.id);
      if (!isOwner(userId)) {
        return bot.sendRichMessage(chatId,
          [richHeader("AKSES DITOLAK", ce(EMOJI.cross, '❌')), richPara(`Hanya owner.`)].join('\n'),
          { parse_mode: 'HTML' });
      }
      storeWizard.delete(userId);
      await showAddLayananIntro(chatId, null, userId);
    });
    console.log('[DP] ✅ /addlayanan registered');
  } catch (e) { console.error('[DP] register /addlayanan:', e.message); }

  // ═══════════════════════════════════════════════════════════
  // 🎯 CALLBACK ROUTER
  // ═══════════════════════════════════════════════════════════
  async function handleCallback(query) {
    const userId  = Number(query.from.id);
    const chatId  = query.message.chat.id;
    const messageId = query.message.message_id;
    const data    = query.data || "";

    // ─── ADDLAYANAN WIZARD ─────────────────────────────────
    if (typeof data === 'string' && data.startsWith('aln_')) {
      if (!isOwner(userId)) {
        return bot.answerCallbackQuery(query.id, { text: "❌ Hanya owner!", show_alert: true }).catch(() => {});
      }

      if (data === 'aln_exit') {
        storeWizard.delete(userId);
        await animateLoading(chatId, messageId, "Kembali ke menu");
        try { await bot.deleteMessage(chatId, messageId); } catch (_) {}
        try { await sendMainMenuSafe(chatId); } catch (_) {}
        return bot.answerCallbackQuery(query.id).catch(() => {});
      }

      if (data === 'aln_open') {
        await showAddLayananIntro(chatId, messageId, userId);
        return bot.answerCallbackQuery(query.id, { text: "✅ Panel tambah layanan" }).catch(() => {});
      }

      if (data === 'aln_manage') {
        await showStoreManager(chatId, messageId, userId);
        return bot.answerCallbackQuery(query.id, { text: "📋 Kelola store" }).catch(() => {});
      }

      if (data === 'aln_start') {
        await startAddLayanan(chatId, messageId, userId);
        return bot.answerCallbackQuery(query.id, { text: "✅ Mulai wizard" }).catch(() => {});
      }

      if (data.startsWith('aln_del_')) {
        const storeId = data.replace('aln_del_', '');
        const all = loadAllStores();
        const idx = all.findIndex(s => s.id === storeId);
        if (idx === -1) {
          return bot.answerCallbackQuery(query.id, { text: "❌ Store tidak ditemukan.", show_alert: true }).catch(() => {});
        }
        const removed = all.splice(idx, 1)[0];
        saveAllStores(all);
        console.log(`[DP] 🗑️ Store deleted: ${removed.name}`);
        await showStoreManager(chatId, messageId, userId);
        return bot.answerCallbackQuery(query.id, { text: `🗑️ ${removed.name} dihapus.` }).catch(() => {});
      }

      if (data.startsWith('aln_role_')) {
        const role = data.replace('aln_role_', '');
        const st = storeWizard.get(userId);
        if (!st) return bot.answerCallbackQuery(query.id, { text: "❌ Sesi expired.", show_alert: true }).catch(() => {});
        st.data.highestRole = role;
        st.step = WS.QRIS;
        storeWizard.set(userId, st);
        await sendOrEditRich(chatId, messageId,
          [richHeader(STEP_LABEL[WS.QRIS], '📱'),
           richPara(`Kirim <b>URL QRIS</b> (upload ke catbox.moe dulu).`),
           richPara(`Contoh: <code>https://files.catbox.moe/xxxx.jpg</code>`),
           richDiv(),
           richPara(`Ketik <b>/batal</b> untuk membatalkan.`)].join('\n'),
          { inline_keyboard: [[{ text: "❌ Batal Wizard", callback_data: "aln_exit", style: "danger", icon_custom_emoji_id: EMOJI.cross }]] });
        return bot.answerCallbackQuery(query.id, { text: `✅ Role: ${ROLE_PRICES[role]?.label || role}` }).catch(() => {});
      }

      if (data.startsWith('aln_dur_')) {
        const st = storeWizard.get(userId);
        if (!st) return bot.answerCallbackQuery(query.id, { text: "❌ Sesi expired.", show_alert: true }).catch(() => {});
        const val = data.replace('aln_dur_', '');

        if (val === 'custom') {
          st.step = WS.DURATION_CUSTOM;
          storeWizard.set(userId, st);
          await sendOrEditRich(chatId, messageId,
            [richHeader(STEP_LABEL[WS.DURATION_CUSTOM], '✏️'),
             richPara(`Kirim durasi custom dengan format:`),
             richTable([
               ["Hari", "14 hari"],
               ["Minggu", "3 minggu"],
               ["Bulan", "2 bulan"]
             ]),
             richDiv(),
             richPara(`Ketik <b>/batal</b> untuk membatalkan.`)].join('\n'),
            { inline_keyboard: [[{ text: "❌ Batal Wizard", callback_data: "aln_exit", style: "danger", icon_custom_emoji_id: EMOJI.cross }]] });
          return bot.answerCallbackQuery(query.id).catch(() => {});
        }

        if (val === 'permanent') {
          st.data.permanent = true;
          st.data.durationDays = 0;
          st.data.durationLabel = 'PERMANEN';
          storeWizard.delete(userId);
          await saveNewStore(chatId, userId, st.data);
          return bot.answerCallbackQuery(query.id, { text: "✅ Permanen!" }).catch(() => {});
        }

        const parts = val.split('_');
        const days = parseInt(parts[0], 10);
        const unit = parts[1] || 'day';
        st.data.durationDays = days;
        st.data.durationLabel = `${days} ${unit}${days > 1 ? 's' : ''}`;
        st.data.permanent = false;
        storeWizard.delete(userId);
        await saveNewStore(chatId, userId, st.data);
        return bot.answerCallbackQuery(query.id, { text: `✅ ${days} ${unit}` }).catch(() => {});
      }

      return bot.answerCallbackQuery(query.id).catch(() => {});
    }

    // ─── SERVICE FLOW ──────────────────────────────────────
    if (typeof data !== 'string' || !data.startsWith('svc_')) return false;

    if (data.startsWith('svc_acc_')) return handleAccReject(query, data.replace('svc_acc_', ''), true);
    if (data.startsWith('svc_rej_')) return handleAccReject(query, data.replace('svc_rej_', ''), false);

    if (data === 'svc_queue_check') {
      await showQueue(chatId, messageId, userId, false);
      return bot.answerCallbackQuery(query.id, { text: "📋 Antrian" }).catch(() => {});
    }
    if (data === 'svc_queue_refresh') {
      await showQueue(chatId, messageId, userId, true);
      return bot.answerCallbackQuery(query.id, { text: "🔄 Refreshed!" }).catch(() => {});
    }

    if (data.startsWith('svc_perm_allow_')) {
      const res = await handleAllow(data.replace('svc_perm_allow_', ''), userId);
      return bot.answerCallbackQuery(query.id, { text: res.msg }).catch(() => {});
    }
    if (data.startsWith('svc_perm_deny_')) {
      const res = await handleDeny(data.replace('svc_perm_deny_', ''), userId);
      return bot.answerCallbackQuery(query.id, { text: res.msg }).catch(() => {});
    }
    if (data.startsWith('svc_perm_create_')) {
      const res = await handleDoCreate(data.replace('svc_perm_create_', ''), userId);
      return bot.answerCallbackQuery(query.id, { text: res.msg }).catch(() => {});
    }
    if (data.startsWith('svc_perm_later_')) {
      const res = await handleLater(data.replace('svc_perm_later_', ''), userId);
      return bot.answerCallbackQuery(query.id, { text: res.msg }).catch(() => {});
    }

    if (data.startsWith('svc_dp_lunasin_')) {
      await startLunasin(chatId, messageId, userId, data.replace('svc_dp_lunasin_', ''));
      return bot.answerCallbackQuery(query.id).catch(() => {});
    }
    if (data.startsWith('svc_dp_lunas_go_')) {
      await proceedLunasin(chatId, messageId, userId, data.replace('svc_dp_lunas_go_', ''));
      return bot.answerCallbackQuery(query.id).catch(() => {});
    }
    if (data.startsWith('svc_dp_lunas_later_')) {
      const txnId = data.replace('svc_dp_lunas_later_', '');
      serviceState.delete(userId);
      await animateLoading(chatId, messageId, "Kembali...");
      try { await bot.deleteMessage(chatId, messageId); } catch (_) {}
      await bot.sendRichMessage(chatId,
        [richHeader("PELUNASAN DITUNDA", ce(EMOJI.warning, '⚠️')),
         richPara(`Kamu menunda pelunasan DP <code>${txnId}</code>.`),
         richDiv(),
         richQuote(`⚠️ <b>Peringatan:</b> Jika tidak dilunasi sebelum deadline, akun akan di-<b>freeze</b>!`)].join('\n'),
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [
          [{ text: "💳 LUNASIN SEKARANG", callback_data: `svc_dp_lunasin_${txnId}`, style: "danger", icon_custom_emoji_id: EMOJI.fire }],
          [{ text: "📋 Cek DP", callback_data: "svc_my_dp", style: "primary", icon_custom_emoji_id: EMOJI.money }]
        ]}});
      return bot.answerCallbackQuery(query.id).catch(() => {});
    }

    if (data === 'svc_menu') { await showServiceMenu(chatId, messageId, userId); return bot.answerCallbackQuery(query.id).catch(() => {}); }
    if (data === 'svc_exit') {
      serviceState.delete(userId);
      await animateLoading(chatId, messageId, "Kembali ke menu utama");
      try { await bot.deleteMessage(chatId, messageId); } catch (_) {}
      try { await sendMainMenuSafe(chatId); } catch (_) {}
      return bot.answerCallbackQuery(query.id).catch(() => {});
    }
    if (data === 'svc_buy_role') { await showBuyIntro(chatId, messageId, userId); return bot.answerCallbackQuery(query.id).catch(() => {}); }
    if (data === 'svc_continue_buy') { await showStoreListForBuy(chatId, messageId, userId, 'buy'); return bot.answerCallbackQuery(query.id).catch(() => {}); }
    if (data === 'svc_my_dp') { await showMyDP(chatId, messageId, userId); return bot.answerCallbackQuery(query.id).catch(() => {}); }
    if (data === 'svc_up_role') { await showUpRoleIntro(chatId, messageId, userId); return bot.answerCallbackQuery(query.id).catch(() => {}); }

    if (data.startsWith('svc_store_')) {
      const rest = data.replace('svc_store_', '');
      const parts = rest.split('_');
      const action = parts.pop();
      const storeIdRaw = parts.join('_');
      let store = null;
      if (storeIdRaw !== 'default') store = findStoreById(storeIdRaw);
      const st = serviceState.get(userId) || {};
      serviceState.set(userId, { ...st, store });

      if (action === 'buy') {
        await showRoleList(chatId, messageId, userId, store);
      } else if (action === 'up') {
        const currentRole = st.currentRole || getUserCurrentRole(userId);
        if (!currentRole) { await showServiceMenu(chatId, messageId, userId); return bot.answerCallbackQuery(query.id).catch(() => {}); }
        const allowedRoles = store ? getStoreSellableRoles(store) : Object.keys(ROLE_PRICES);
        const text = [
          richHeader("PILIH ROLE TARGET", ce(EMOJI.up, '⬆️')),
          richPara(`Role saat ini: <b>${ROLE_PRICES[currentRole]?.label || currentRole}</b>`),
          store ? richPara(`Store: <b>🏪 ${store.name}</b>`) : richPara(`Store: <b>🏪 Mclaren Official</b>`),
          richDiv(),
          richPara(`Pilih role target upgrade 👇`)
        ].join('\n');
        await sendOrEditRich(chatId, messageId, text, keyboardUpRoleList(currentRole, allowedRoles));
      }
      return bot.answerCallbackQuery(query.id).catch(() => {});
    }

    if (data.startsWith('svc_role_')) {
      await showRoleDetail(chatId, messageId, userId, data.replace('svc_role_', ''));
      return bot.answerCallbackQuery(query.id).catch(() => {});
    }
    if (data.startsWith('svc_buy_full_')) {
      await showPaymentConfirmation(chatId, messageId, userId, 'full', data.replace('svc_buy_full_', ''));
      return bot.answerCallbackQuery(query.id).catch(() => {});
    }
    if (data.startsWith('svc_buy_dp_')) {
      const role = data.replace('svc_buy_dp_', '');
      const info = ROLE_PRICES[role]; if (!info) return bot.answerCallbackQuery(query.id).catch(() => {});
      const fullPrice = info.price;
      const minDp = Math.max(DP_MINIMUM, Math.floor(fullPrice * 0.5));
      const maxDp = Math.min(DP_MAXIMUM, fullPrice);
      const st = serviceState.get(userId) || {};
      serviceState.set(userId, { ...st, step: 'awaiting_dp_amount_pick', role, isUpgrade: false, currentRole: null, fullPrice, minDp, maxDp, messageId });
      await askDpAmount(chatId, messageId, userId, role, false, null);
      return bot.answerCallbackQuery(query.id).catch(() => {});
    }

    if (data.startsWith('svc_dp_amt_')) {
      const rest = data.replace('svc_dp_amt_', '');
      const parts = rest.split('_');
      const amt = parseInt(parts.pop(), 10);
      const role = parts.join('_');
      const st = serviceState.get(userId);
      if (!st || !amt) return bot.answerCallbackQuery(query.id).catch(() => {});
      await showPaymentConfirmation(chatId, st.messageId || messageId, userId, 'dp', role, amt, st.isUpgrade, st.currentRole);
      return bot.answerCallbackQuery(query.id).catch(() => {});
    }
    if (data.startsWith('svc_dp_custom_')) {
      const role = data.replace('svc_dp_custom_', '');
      const st = serviceState.get(userId) || {};
      const info = ROLE_PRICES[role]; if (!info) return bot.answerCallbackQuery(query.id).catch(() => {});
      let fullPrice = info.price;
      if (st.isUpgrade && st.currentRole) fullPrice = info.price - (ROLE_PRICES[st.currentRole]?.price || 0);
      const minDp = Math.max(DP_MINIMUM, Math.floor(fullPrice * 0.5));
      const maxDp = Math.min(DP_MAXIMUM, fullPrice);
      serviceState.set(userId, { ...st, step: 'awaiting_dp_amount', role, fullPrice, minDp, maxDp, messageId });
      await sendOrEditRich(chatId, messageId,
        [richHeader("CUSTOM DP AMOUNT", ce(EMOJI.money, '💸')),
         richTable([["💰 Total", rp(fullPrice)], ["💸 Minimal DP", rp(minDp)], ["💸 Maksimal DP", rp(maxDp)]]),
         richDiv(),
         richPara(`Kirim nominal DP (angka saja). Contoh: <code>5000</code>`)].join('\n'),
        { inline_keyboard: [[{ text: "❌ Batalkan", callback_data: "svc_buy_role", style: "danger", icon_custom_emoji_id: EMOJI.cross }]] });
      return bot.answerCallbackQuery(query.id).catch(() => {});
    }

    if (data.startsWith('svc_up_current_')) {
      const currentRole = data.replace('svc_up_current_', '');
      const st = serviceState.get(userId) || {};
      serviceState.set(userId, { ...st, step: 'up_store', currentRole });
      await showStoreListForBuy(chatId, messageId, userId, 'up');
      return bot.answerCallbackQuery(query.id).catch(() => {});
    }
    if (data.startsWith('svc_up_target_')) {
      const targetRole = data.replace('svc_up_target_', '');
      const st = serviceState.get(userId) || {};
      const currentRole = st.currentRole || getUserCurrentRole(userId);
      if (!currentRole) return bot.answerCallbackQuery(query.id).catch(() => {});
      await showUpRoleDetail(chatId, messageId, userId, currentRole, targetRole, st.store || null);
      return bot.answerCallbackQuery(query.id).catch(() => {});
    }
    if (data.startsWith('svc_up_full_')) {
      const targetRole = data.replace('svc_up_full_', '');
      const st = serviceState.get(userId) || {};
      const currentRole = st.currentRole || getUserCurrentRole(userId);
      await showPaymentConfirmation(chatId, messageId, userId, 'full', targetRole, null, true, currentRole);
      return bot.answerCallbackQuery(query.id).catch(() => {});
    }
    if (data.startsWith('svc_up_dp_')) {
      const targetRole = data.replace('svc_up_dp_', '');
      const st = serviceState.get(userId) || {};
      const currentRole = st.currentRole || getUserCurrentRole(userId);
      const currInfo = ROLE_PRICES[currentRole];
      const tgtInfo = ROLE_PRICES[targetRole];
      if (!currInfo || !tgtInfo) return bot.answerCallbackQuery(query.id).catch(() => {});
      const fullPrice = tgtInfo.price - currInfo.price;
      const minDp = Math.max(DP_MINIMUM, Math.floor(fullPrice * 0.5));
      const maxDp = Math.min(DP_MAXIMUM, fullPrice);
      serviceState.set(userId, { ...st, step: 'awaiting_dp_amount_pick', role: targetRole, isUpgrade: true, currentRole, fullPrice, minDp, maxDp, messageId });
      await askDpAmount(chatId, messageId, userId, targetRole, true, currentRole);
      return bot.answerCallbackQuery(query.id).catch(() => {});
    }

    if (data.startsWith('svc_pay_cancel_')) {
      const uid = Number(data.replace('svc_pay_cancel_', ''));
      if (paymentTimer.has(uid)) { clearTimeout(paymentTimer.get(uid)); paymentTimer.delete(uid); }
      serviceState.delete(uid);
      await bot.deleteMessage(chatId, messageId).catch(() => {});
      return bot.answerCallbackQuery(query.id).catch(() => {});
    }

    if (data.startsWith('svc_pay_proof_')) {
      const rest = data.replace('svc_pay_proof_', '');
      const parts = rest.split('_');
      const mode = parts[1];
      const role = parts.slice(2).join('_');
      const st = serviceState.get(userId) || {};
      serviceState.set(userId, { ...st, step: 'awaiting_proof', role, mode });
      await bot.sendRichMessage(chatId,
        [richHeader("KIRIM BUKTI TRANSFER", '📸'),
         richPara(`Kirim <b>foto bukti transfer</b> kamu sekarang.`),
         richDiv(),
         richPara(`Contoh: kirim foto + caption nominal.`)].join('\n'),
        { parse_mode: 'HTML' });
      return bot.answerCallbackQuery(query.id).catch(() => {});
    }

    return bot.answerCallbackQuery(query.id).catch(() => {});
  }

  let sendMainMenuSafe = async (chatId) => {
    try { await bot.sendRichMessage(chatId, "🏠 Ketik /menu untuk membuka menu utama.", { parse_mode: 'HTML' }); } catch (_) {}
  };
  function setMainMenuSender(fn) { if (typeof fn === 'function') sendMainMenuSafe = fn; }

  // ═══════════════════════════════════════════════════════════
  // 🎯 MESSAGE ROUTER
  // ═══════════════════════════════════════════════════════════
  async function handleMessage(msg) {
    if (!msg || !msg.from) return false;
    const userId = Number(msg.from.id);

    if (storeWizard.has(userId)) {
      const handled = await handleAddLayananText(msg);
      if (handled) return true;
    }

    const st = serviceState.get(userId);
    if (!st) return false;

    if (st.step === 'awaiting_dp_amount' && msg.text && !/^\//.test(msg.text)) {
      await handleDpAmountInput(msg);
      return true;
    }
    if (st.step === 'awaiting_dp_lunas_proof' && msg.photo && msg.photo.length) {
      await handleDpLunasProof(msg);
      return true;
    }
    if (st.step === 'awaiting_proof' && msg.photo && msg.photo.length) {
      await handlePaymentProof(msg);
      return true;
    }

    return false;
  }

  // ═══════════════════════════════════════════════════════════
  // 📤 EXPORT
  // ═══════════════════════════════════════════════════════════
  console.log('[DP] ✅ services_dp v9.0 ULTRA initialized');
  console.log('[DP] ✅ Queue system ready');
  console.log('[DP] ✅ Default stores ensured');
  console.log('[DP] ✅ Photo fallback 4-layer ready');

  return {
    handleCallback, handleMessage,
    showServiceMenu, showMyDP, sendGroupLinksToBuyer,
    loadOwnerAcc, isOwnerAcc, isOwner,
    loadAllStores, loadActiveStores, findStoreById, saveAllStores,
    loadQueue, addToQueue, getQueuePosition, showQueue,
    ROLE_PRICES, ROLE_ORDER, DP_MINIMUM, DP_MAXIMUM, DP_MAX_DAYS,
    setMainMenuSender
  };
};