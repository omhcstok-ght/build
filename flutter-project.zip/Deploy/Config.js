module.exports = {
  Token: [
  "8819949500:AAEM5cT2dLYNkDuunQPFuFqv8Psd8QsFzsQ",
  "8881536125:AAEmr9V8G-zEVIAZtslAYPLsorzsREpj4OI"
],
  Owner: [
  "1285623735",
  "7981296808"
]
};