import 'dart:ui';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late AnimationController _floatController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _floatAnimation;

  // --- KONFIGURASI TEMA ---
  static const String _kFontFamily = 'Rajdhani';

  final Color ColorBg = const Color(0xFF050505); 
  final Color ColorAccent = const Color(0xFFE63946); 

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeOut),
    );

    // Animasi melayang halus untuk gambar
    _floatController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat(reverse: true);
    _floatAnimation = Tween<double>(begin: -5, end: 5).animate(
      CurvedAnimation(parent: _floatController, curve: Curves.easeInOut),
    );

    _fadeController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _floatController.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      debugPrint("Could not launch $uri");
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: _kFontFamily, // Global Font: Rajdhani
        textTheme: const TextTheme(
          bodyLarge: TextStyle(fontFamily: _kFontFamily),
          bodyMedium: TextStyle(fontFamily: _kFontFamily),
          displayLarge: TextStyle(fontFamily: _kFontFamily),
          displayMedium: TextStyle(fontFamily: _kFontFamily),
          labelLarge: TextStyle(fontFamily: _kFontFamily),
        ),
      ),
      home: Scaffold(
        backgroundColor: ColorBg,
        body: Stack(
          children: [
            // 1. BACKGROUND GLOW (Cahaya ambient, tidak mengganggu gambar)
            _buildAmbientGlow(),

            // 2. KONTEN UTAMA
            Center(
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(height: 60),

                      // HERO IMAGE (REZE) - VERSION FIXED
                      _buildHeroImageFixed(),

                      const SizedBox(height: 35),

                      // JUDUL
                      Text(
                        "REVENGERS",
                        style: TextStyle(
                          fontFamily: _kFontFamily,
                          fontSize: 52,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 10,
                          color: Colors.white,
                          height: 1.0,
                        ),
                      ),

                      const SizedBox(height: 5),

                      // SUBTITLE
                      Text(
                        "PREMIUM DIGITAL ACCESS",
                        style: TextStyle(
                          fontFamily: _kFontFamily,
                          fontSize: 13,
                          letterSpacing: 4,
                          color: ColorAccent,
                          fontWeight: FontWeight.w600,
                        ),
                      ),

                      const SizedBox(height: 45),

                      // GLASS PANEL
                      _buildGlassPanel(),

                      const SizedBox(height: 30),

                      // FOOTER
                      Text(
                        "SECURE • PRIVATE • EXCLUSIVE",
                        style: TextStyle(
                          fontFamily: _kFontFamily,
                          fontSize: 10,
                          letterSpacing: 2,
                          color: Colors.white.withOpacity(0.4),
                        ),
                      ),
                      
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --- BACKGROUND GLOW ---
  Widget _buildAmbientGlow() {
    return Stack(
      children: [
        // Glow Merah di belakang (memberikan kesan atmosfer)
        Positioned(
          top: -50,
          left: -50,
          child: Container(
            width: 300,
            height: 300,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [ColorAccent.withOpacity(0.25), Colors.transparent],
              ),
            ),
          ),
        ),
        // Glow Biru Gelap di bawah
        Positioned(
          bottom: -50,
          right: -50,
          child: Container(
            width: 350,
            height: 350,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  const Color(0xFF1A0B2E).withOpacity(0.4), 
                  Colors.transparent
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  // --- HERO IMAGE FIXED (BERSIH & JERNIH) ---
  Widget _buildHeroImageFixed() {
    return AnimatedBuilder(
      animation: _floatAnimation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, _floatAnimation.value),
          child: Container(
            width: 240,
            height: 240,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              // Menggunakan shadow GELAP di dalam dan MERAH di luar agar gambar menonjol
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.8), // Shadow hitam pekat agar gambar pop out
                  spreadRadius: 5,
                  blurRadius: 20,
                ),
                BoxShadow(
                  color: ColorAccent.withOpacity(0.3), // Glow merah halus
                  blurRadius: 40,
                  spreadRadius: 0,
                )
              ],
            ),
            child: ClipOval(
              child: Image.asset(
                "assets/images/reze.png",
                fit: BoxFit.cover,
                // TIDAK ADA color atau colorBlendMode di sini agar gambar asli muncul 100%
              ),
            ),
          ),
        );
      },
    );
  }

  // --- GLASS PANEL ---
  Widget _buildGlassPanel() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 25, sigmaY: 25),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.04), // Sedikit lebih transparan
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: Colors.white.withOpacity(0.1),
              width: 1,
            ),
          ),
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              // TOMBOL SIGN IN
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: ColorAccent,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 0,
                  ).copyWith(
                    overlayColor: MaterialStateProperty.all(Colors.white24),
                  ),
                  onPressed: () {
                    Navigator.pushNamed(context, "/login");
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "LOGIN",
                        style: TextStyle(
                          fontFamily: _kFontFamily,
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 2,
                        ),
                      ),
                      const SizedBox(width: 10),
                      const FaIcon(FontAwesomeIcons.arrowRight, size: 14)
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 14),

              // TOMBOL BUY ACCESS
              SizedBox(
                width: double.infinity,
                height: 50,
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.white,
                    side: BorderSide(color: Colors.white.withOpacity(0.2)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: () => _openUrl("https://t.me/InfoChDarkness/292"),
                  child: Text(
                    "BUY ACCESS",
                    style: TextStyle(
                      fontFamily: _kFontFamily,
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 1.5,
                      color: Colors.white70,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // DIVIDER
              Container(
                height: 1,
                margin: const EdgeInsets.symmetric(horizontal: 10),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      Colors.white.withOpacity(0.2),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 18),

              // SOSIAL MEDIA BUTTONS
              Row(
                children: [
                  Expanded(
                    child: _socialBtn(
                      FontAwesomeIcons.telegram,
                      "Telegram",
                      const Color(0xFF229ED9),
                      "https://t.me/fantzy_reals13",
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _socialBtn(
                      FontAwesomeIcons.whatsapp,
                      "WhatsApp",
                      const Color(0xFF25D366),
                      "https://wa.me/6283165770011",
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _socialBtn(IconData icon, String label, Color color, String url) {
    return InkWell(
      onTap: () => _openUrl(url),
      borderRadius: BorderRadius.circular(10),
      child: Container(
        height: 48,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.white.withOpacity(0.08)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(icon, color: color, size: 16),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                fontFamily: _kFontFamily,
                color: Colors.white70,
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            )
          ],
        ),
      ),
    );
  }
}