import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _fadeController;
  late AnimationController _pulseController;
  String selectedBugId = "";

  // --- State Baru: Mode Target ---
  String _selectedBugMode = "number";

  bool _isSending = false;
  String? _responseMessage;

  // --- Tema Baru: Elegant Black Glassmorphism ---
  // Background sangat gelap (bukan hitam solid tapi dark grey/black)
  static const Color primaryBg = Color(0xFF050505); 
  static const Color glassBg = Color(0x12121212); // Transparan hitam (Alpha tinggi)
  static const Color glassBorder = Color(0x33FFFFFF); // Border putih transparan (10%)
  
  // Aksen warna (Tetap menggunakan merah agar identitas app tetap ada, tapi lebih elegan)
  static const Color primaryRed = Color(0xFFFF1744); 
  static const Color textWhite = Colors.white;
  static const Color textGrey = Color(0xFFB0B0B0);

  // Gradients
  final LinearGradient accentGradient = const LinearGradient(
    colors: [Color(0xFFFF1744), Color(0xFFD50000)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // Video Player Variables
  late VideoPlayerController _videoController;
  late ChewieController _chewieController;
  bool _isVideoInitialized = false;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    // Set default bug pertama
    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }

    _initializeVideoPlayer();
  }

  void _initializeVideoPlayer() {
    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4');

    _videoController.initialize().then((_) {
      setState(() {
        _videoController.setVolume(0.1);
        _chewieController = ChewieController(
          videoPlayerController: _videoController,
          autoPlay: true,
          looping: true,
          showControls: false,
          autoInitialize: true,
        );
        _isVideoInitialized = true;
      });
    }).catchError((error) {
      print("Video initialization error: $error");
      setState(() {
        _isVideoInitialized = false;
      });
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _pulseController.dispose();
    targetController.dispose();
    _videoController.dispose();
    _chewieController.dispose();
    super.dispose();
  }

  // --- LOGIC UTAMA (TIDAK DIUBAR) ---
  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert("⚠️ Peringatan", "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert("⚠️ Peringatan", "Masukkan link group WA yang valid (contoh: https://chat.whatsapp.com/...).");
        return;
      }
    }

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });

    try {
      final res = await http.get(Uri.parse(
          "http://jscloud.my.id:2010/sendBug?key=$key&target=$rawInput&bug=$selectedBugId"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        setState(() => _responseMessage = "⏳ Cooldown: Tunggu beberapa saat.");
      } else if (data["valid"] == false) {
        setState(() => _responseMessage = "❌ Key Invalid: Silakan login ulang.");
      } else if (data["sended"] == false) {
        setState(() => _responseMessage = "⚠️ Gagal: Server sedang maintenance.");
      } else {
        setState(() => _responseMessage = "✅ Berhasil mengirim bug!");
        targetController.clear();
      }
    } catch (_) {
      setState(() => _responseMessage = "❌ Error: Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: primaryRed, width: 1),
        ),
        title: Text(title, style: const TextStyle(color: primaryRed, fontWeight: FontWeight.bold)),
        content: Text(msg, style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK", style: TextStyle(color: primaryRed)),
          ),
        ],
      ),
    );
  }

  // --- WIDGET UI BARU ---

  // Helper untuk membuat efek kaca (Glass)
  BoxDecoration _glassBoxDecoration({double borderRadius = 20}) {
    return BoxDecoration(
      color: glassBg,
      borderRadius: BorderRadius.circular(borderRadius),
      border: Border.all(color: glassBorder, width: 1),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.4),
          blurRadius: 20,
          offset: const Offset(0, 10),
        ),
      ],
    );
  }

  Widget _buildHeaderPanel() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: _glassBoxDecoration(),
      child: Row(
        children: [
          // Avatar with Glow
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: accentGradient,
              boxShadow: [
                BoxShadow(color: primaryRed.withOpacity(0.4), blurRadius: 15, spreadRadius: 1),
              ],
            ),
            child: CircleAvatar(
              radius: 28,
              backgroundColor: Colors.transparent,
              backgroundImage: const AssetImage('assets/images/logo.png'),
            ),
          ),
          const SizedBox(width: 20),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.username,
                  style: const TextStyle(
                    color: textWhite,
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: primaryRed.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: primaryRed.withOpacity(0.3)),
                      ),
                      child: Text(
                        widget.role.toUpperCase(),
                        style: const TextStyle(
                          color: primaryRed,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      "Exp: ${widget.expiredDate}",
                      style: const TextStyle(
                        color: textGrey,
                        fontSize: 12,
                        fontFamily: 'monospace', // Menggunakan font mono untuk kesan tech
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoPlayer() {
    if (!_isVideoInitialized) {
      return Container(
        width: double.infinity,
        height: 180,
        margin: const EdgeInsets.symmetric(vertical: 20),
        decoration: _glassBoxDecoration(),
        child: const Center(
          child: CircularProgressIndicator(color: primaryRed, strokeWidth: 2),
        ),
      );
    }

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(color: primaryRed.withOpacity(0.2), blurRadius: 20, spreadRadius: 1),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: AspectRatio(
          aspectRatio: _videoController.value.aspectRatio,
          child: Stack(
            children: [
              Chewie(controller: _chewieController),
              // Overlay Gelap Tipis agar video menyatu dengan background
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      Colors.black.withOpacity(0.3),
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // --- MODE SELECTOR (Style Toggle Switch) ---
  Widget _buildModeSelector() {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: glassBorder),
      ),
      child: Row(
        children: [
          _buildModeItem(
            label: "NOMOR",
            icon: Icons.phone_iphone_rounded,
            isSelected: _selectedBugMode == "number",
            onTap: () {
              setState(() {
                _selectedBugMode = "number";
                targetController.clear();
              });
            },
          ),
          _buildModeItem(
            label: "GROUP",
            icon: Icons.group_work_rounded,
            isSelected: _selectedBugMode == "group",
            onTap: () {
              setState(() {
                _selectedBugMode = "group";
                targetController.clear();
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _buildModeItem({
    required String label,
    required IconData icon,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? primaryRed : Colors.transparent,
            borderRadius: BorderRadius.circular(10),
            boxShadow: isSelected
                ? [BoxShadow(color: primaryRed.withOpacity(0.4), blurRadius: 10)]
                : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: isSelected ? Colors.white : textGrey,
                size: 18,
              ),
              const SizedBox(width: 8),
              Text(
                label,
                style: TextStyle(
                  color: isSelected ? Colors.white : textGrey,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // --- HORIZONTAL BUG SELECTOR (Sesuai Permintaan) ---
  Widget _buildHorizontalBugSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 4, bottom: 12),
          child: Text(
            "SELECT BUG PAYLOAD",
            style: TextStyle(
              color: textGrey,
              fontSize: 12,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.5,
            ),
          ),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          child: Row(
            children: widget.listBug.map((bug) {
              final bool isSelected = selectedBugId == bug['bug_id'];
              return Padding(
                padding: const EdgeInsets.only(right: 10),
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      selectedBugId = bug['bug_id'];
                    });
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    decoration: BoxDecoration(
                      color: isSelected ? primaryRed : Colors.black.withOpacity(0.4),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isSelected ? primaryRed : glassBorder,
                        width: 1,
                      ),
                      boxShadow: isSelected
                          ? [BoxShadow(color: primaryRed.withOpacity(0.3), blurRadius: 8)]
                          : null,
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.bug_report_rounded,
                          color: isSelected ? Colors.white : textGrey,
                          size: 16,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          bug['bug_name'],
                          style: TextStyle(
                            color: isSelected ? Colors.white : textGrey,
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildInputPanel() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: _glassBoxDecoration(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // 1. MODE SELECTOR
          _buildModeSelector(),

          const SizedBox(height: 30),

          // 2. INPUT TARGET
          TextField(
            controller: targetController,
            style: const TextStyle(color: Colors.white, fontSize: 16),
            cursorColor: primaryRed,
            keyboardType: _selectedBugMode == "number" ? TextInputType.phone : TextInputType.url,
            decoration: InputDecoration(
              hintText: _selectedBugMode == "number"
                  ? "Masukkan Nomor Target (+62...)"
                  : "Masukkan Link Group WhatsApp",
              hintStyle: TextStyle(color: textGrey.withOpacity(0.4)),
              filled: true,
              fillColor: Colors.black.withOpacity(0.2),
              contentPadding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide(color: glassBorder),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: const BorderSide(color: primaryRed, width: 2),
              ),
              prefixIcon: Icon(
                _selectedBugMode == "number" ? Icons.call_rounded : Icons.link_rounded,
                color: primaryRed,
              ),
            ),
          ),

          const SizedBox(height: 30),

          // 3. HORIZONTAL BUG SELECTOR
          _buildHorizontalBugSelector(),
        ],
      ),
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return GestureDetector(
          onTap: _isSending ? null : _sendBug,
          child: Container(
            height: 70,
            width: double.infinity,
            decoration: BoxDecoration(
              gradient: accentGradient,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: primaryRed.withOpacity(0.4 + (_pulseController.value * 0.2)),
                  blurRadius: 25 + (_pulseController.value * 10),
                  spreadRadius: _pulseController.value * 2,
                ),
              ],
            ),
            child: Center(
              child: _isSending
                  ? const SizedBox(
                      height: 28,
                      width: 28,
                      child: CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 3,
                      ),
                    )
                  : const Text(
                      "EXECUTE",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2.5,
                      ),
                    ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();

    Color msgColor;
    IconData msgIcon;

    if (_responseMessage!.startsWith('✅')) {
      msgColor = Colors.greenAccent;
      msgIcon = Icons.check_circle_outline;
    } else if (_responseMessage!.startsWith('❌')) {
      msgColor = Colors.redAccent;
      msgIcon = Icons.error_outline;
    } else {
      msgColor = Colors.orangeAccent;
      msgIcon = Icons.info_outline;
    }

    return Container(
      margin: const EdgeInsets.only(top: 20),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.6),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: msgColor.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(msgIcon, color: msgColor, size: 24),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _responseMessage!,
              style: TextStyle(
                color: msgColor,
                fontWeight: FontWeight.w600,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryBg,
      // Tambahkan background pattern halus jika diinginkan (opsional)
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Column(
            children: [
              // Header
              _buildHeaderPanel(),
              const SizedBox(height: 25),
              
              // Video
              _buildVideoPlayer(),
              const SizedBox(height: 25),
              
              // Main Glass Card (Input & Bug)
              _buildInputPanel(),
              const SizedBox(height: 30),
              
              // Action Button
              _buildSendButton(),
              
              // Status
              _buildResponseMessage(),
            ],
          ),
        ),
      ),
    );
  }
}