import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_page.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late VideoPlayerController _videoController;
  late AnimationController _fadeController;
  // Controller khusus untuk animasi loading bar
  late AnimationController _loadingController;
  
  bool _fadeOutStarted = false;
  bool _navigated = false;

  @override
  void initState() {
    super.initState();

    // Controller untuk transisi fade out
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    );

    // Controller untuk animasi loading bar (berkedip)
    _loadingController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..repeat(reverse: true); // Berulang maju mundur

    _videoController = VideoPlayerController.asset("assets/videos/splash.mp4")
      ..initialize().then((_) {
        setState(() {});
        _videoController.setLooping(false);
        _videoController.play();

        _videoController.addListener(() {
          final position = _videoController.value.position;
          final duration = _videoController.value.duration;

          if (duration != null &&
              position >= duration - const Duration(seconds: 1) &&
              !_fadeOutStarted) {
            _fadeOutStarted = true;
            _fadeController.forward();
          }

          if (position >= duration && !_navigated) {
            _navigateToDashboard();
          }
        });
      });
  }

  void _navigateToDashboard() {
    if (_navigated) return;
    _navigated = true;

    _videoController.pause();
    // Jangan lupa stop animasi loading saat navigasi
    _loadingController.stop();

    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _videoController.dispose();
    _fadeController.dispose();
    _loadingController.dispose(); // Dispose animasi loading
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      // Menerapkan font Rajdhani ke seluruh widget di dalam scope ini
      data: Theme.of(context).copyWith(
        textTheme: Theme.of(context).textTheme.apply(
              fontFamily: 'Rajdhani',
            ),
      ),
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(
          children: [
            /// VIDEO BACKGROUND
            if (_videoController.value.isInitialized)
              Positioned.fill(
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _videoController.value.size.width,
                    height: _videoController.value.size.height,
                    child: VideoPlayer(_videoController),
                  ),
                ),
              )
            else
              const Center(child: CircularProgressIndicator()),

            /// SKIP BUTTON (FONT RAJDHANI + WARNA PINK)
            Positioned(
              top: 50,
              right: 20,
              child: GestureDetector(
                onTap: _navigateToDashboard,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.pink.withOpacity(0.5)),
                  ),
                  child: Text(
                    "SKIP",
                    style: TextStyle(
                      fontFamily: 'Rajdhani', // Paksa pakai font ini
                      color: Colors.pink, // Warna Pink
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
              ),
            ),

            /// TITLE + LOADING BAR
            Positioned(
              bottom: 80,
              left: 0,
              right: 0,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // JUDUL (RONOVA) - WARNA PINK
                  Text(
                    "REVENGE",
                    style: TextStyle(
                      fontFamily: 'Rajdhani',
                      fontSize: 52,
                      fontWeight: FontWeight.bold,
                      color: Colors.pink, // Warna Pink
                      letterSpacing: 4,
                      shadows: [
                        Shadow(
                          color: Colors.pinkAccent.withOpacity(0.8),
                          blurRadius: 20,
                          offset: const Offset(0, 0),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  
                  // ANIMASI GARIS LOADING
                  SizedBox(
                    width: 200,
                    height: 4,
                    child: AnimatedBuilder(
                      animation: _loadingController,
                      builder: (context, child) {
                        return ClipRRect(
                          borderRadius: BorderRadius.circular(2),
                          child: LinearProgressIndicator(
                            value: _loadingController.value,
                            backgroundColor: Colors.white.withOpacity(0.2),
                            valueColor: AlwaysStoppedAnimation<Color>(
                              Colors.pink, // Warna Garis Loading Pink
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  
                  const SizedBox(height: 10),
                  
                  // TEKS STATUS
                  Text(
                    "LOADING...",
                    style: TextStyle(
                      fontFamily: 'Rajdhani',
                      fontSize: 14,
                      color: Colors.white.withOpacity(0.7),
                      letterSpacing: 2,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),

            /// FADE OUT EFFECT
            if (_fadeOutStarted)
              FadeTransition(
                opacity: _fadeController.drive(
                  Tween(begin: 1.0, end: 0.0),
                ),
                child: Container(color: Colors.black),
              ),
          ],
        ),
      ),
    );
  }
}