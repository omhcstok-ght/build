import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

// Import halaman lain
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'partner_page.dart';
import 'moderator_page.dart';
import 'control_panel.dart';
import 'widgets/custom_popup.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;
  final String? uid;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
    this.uid,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  // --- State Variabel (TIDAK DIUBAH) ---
  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;
  late String? uid;

  String androidId = "unknown";
  File? _profileImage;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const Placeholder();

  int onlineUsers = 0;
  int activeConnections = 0;

  // --- Variabel Banner/News (TIDAK DIUBAH) ---
  late PageController _newsPageController;
  double _currentNewsPage = 0.0;
  Timer? _newsTimer;
  VideoPlayerController? _videoController;

  // --- TEMA WARNA CYBERPUNK / NEO-BRUTALISM ---
  static const Color bgMain = Color(0xFFF5F5F7);
  static const Color bgSurface = Color(0xFFFFFFFF);
  static const Color bgCard = Color(0xFFFFFFFF);
  static const Color textMain = Color(0xFF1A1A1A);
  static const Color textSub = Color(0xFF666666);
  static const Color accentYellow = Color(0xFFFFC107);
  static const Color accentYellowDark = Color(0xFFFFA000);
  static const Color containerGray = Color(0xFFD9D9D9);
  static const Color pinkTag = Color(0xFFE91E63);
  static const Color borderBlack = Color(0xFF000000);
  static const Color borderLight = Color(0xFFE0E0E0);
  static const Color borderGlass = Color(0xFFE0E0E0);
  // Kompatibilitas mundur untuk metode yang masih mereferensikan ini
  static const Color accentBlue = Color(0xFF0288D1);
  static const Color accentDarkBlue = Color(0xFF01579B);

  @override
  void initState() {
    super.initState();

    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;
    uid = widget.uid;

    _videoController = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        setState(() {});
        _videoController?.setVolume(1.0);
        _videoController?.setLooping(true);
        _videoController?.play();
      });

    _initNewsBanner();
    _selectedPage = _buildNewsPage();

    _controller = AnimationController(
      duration: const Duration(milliseconds: 450),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _initAndroidIdAndConnect();
    _loadProfileImage();
  }

  void _initNewsBanner() {
    _newsPageController = PageController(
      initialPage: 0,
      viewportFraction: 0.9,
    );

    _newsPageController.addListener(() {
      if (_newsPageController.hasClients && _newsPageController.page != null) {
        _currentNewsPage = _newsPageController.page!;
      }
    });

    if (newsList.isNotEmpty) {
      _newsTimer = Timer.periodic(const Duration(seconds: 5), (Timer timer) {
        if (_newsPageController.hasClients) {
          int targetIndex = (_currentNewsPage + 1).round() % newsList.length;
          _newsPageController.animateToPage(
            targetIndex,
            duration: const Duration(milliseconds: 800),
            curve: Curves.easeInOut,
          );
        }
      });
    }
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(
      Uri.parse('wss://ws-pxp.darkverse.my.id'),
    );
    channel.sink.add(
      jsonEncode({
        "type": "validate",
        "key": sessionKey,
        "androidId": androidId,
      }),
    );
    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      }
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    });
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    CustomPopup.show(
      context,
      title: "Session Expired",
      message: message,
      icon: Icons.error_outline,
      iconColor: Colors.redAccent,
      confirmText: "OK",
      onConfirm: () {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LoginPage()),
          (route) => false,
        );
      },
    );
  }

  void _onBottomNavTapped(int index) {
    if (index == 1) {
      _showWhatsAppMenu();
      return;
    }
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) {
        _selectedPage = _buildNewsPage();
      } else if (index == 2) {
        _selectedPage = InfoPage(sessionKey: sessionKey);
      } else if (index == 3) {
        _selectedPage = ToolsPage(
          sessionKey: sessionKey,
          userRole: role,
          listDoos: listDoos,
        );
      } else if (index == 4) {
        _selectedPage = const ControlPanelPage();
      }
    });
  }

  void _showWhatsAppMenu() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.4),
      builder: (context) {
        return BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
          child: Dialog(
            backgroundColor: Colors.transparent,
            elevation: 0,
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: bgSurface,
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: borderBlack, width: 3),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black,
                    offset: const Offset(6, 6),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: accentYellow,
                      shape: BoxShape.circle,
                      border: Border.all(color: borderBlack, width: 2.5),
                    ),
                    child: const Icon(
                      FontAwesomeIcons.whatsapp,
                      size: 36,
                      color: textMain,
                    ),
                  ),
                  const SizedBox(height: 18),
                  Text(
                    "WHATSAPP HUB",
                    style: TextStyle(
                      color: textMain,
                      fontFamily: 'Orbitron',
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.0,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    "Choose your action below",
                    style: TextStyle(
                      color: textSub,
                      fontSize: 13,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                  const SizedBox(height: 24),
                  _buildWhatsAppOption(
                    icon: Icons.bug_report,
                    color: Colors.redAccent,
                    title: "WhatsApp Crash",
                    subtitle: "Send payloads & crash codes",
                    onTap: () {
                      Navigator.pop(context);
                      setState(() {
                        _bottomNavIndex = 1;
                        _selectedPage = HomePage(
                          username: username,
                          password: password,
                          listBug: listBug,
                          role: role,
                          expiredDate: expiredDate,
                          sessionKey: sessionKey,
                        );
                      });
                    },
                  ),
                  const SizedBox(height: 12),
                  _buildWhatsAppOption(
                    icon: Icons.devices,
                    color: accentYellow,
                    title: "Manage Sender",
                    subtitle: "Pair devices & manage sessions",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => BugSenderPage(
                            sessionKey: sessionKey,
                            username: username,
                            role: role,
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          color: containerGray,
                          borderRadius: BorderRadius.circular(4),
                          border: Border.all(color: borderBlack, width: 2.5),
                        ),
                        child: Center(
                          child: Text(
                            "CLOSE",
                            style: TextStyle(
                              fontWeight: FontWeight.w900,
                              fontSize: 14,
                              color: textMain,
                              fontFamily: 'Orbitron',
                              letterSpacing: 2,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildWhatsAppOption({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: containerGray,
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: borderBlack, width: 2.5),
          boxShadow: [
            BoxShadow(
              color: Colors.black,
              offset: const Offset(4, 4),
              blurRadius: 0,
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: accentYellow,
                shape: BoxShape.circle,
                border: Border.all(color: borderBlack, width: 2),
              ),
              child: Icon(icon, color: textMain, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: textMain,
                      fontWeight: FontWeight.w900,
                      fontSize: 15,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      color: textSub,
                      fontSize: 12,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward,
              color: textMain,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }

  void _onSidebarTabSelected(int index) {
    setState(() {
      if (index == 1) {
        _selectedPage = SellerPage(keyToken: sessionKey);
      } else if (index == 2) {
        _selectedPage = AdminPage(sessionKey: sessionKey);
      } else if (index == 3) {
        _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
      } else if (index == 4) {
        _selectedPage = PartnerPage(sessionKey: sessionKey, username: username);
      } else if (index == 5) {
        _selectedPage = ModeratorPage(
          sessionKey: sessionKey,
          username: username,
        );
      }
    });
    Navigator.pop(context);
  }

  // Dipertahankan untuk kompatibilitas meskipun tidak dipanggil di layout utama
  Widget _buildInfoChip({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Column(
      children: [
        Row(
          children: [
            Icon(icon, color: accentYellow, size: 14),
            const SizedBox(width: 6),
            Text(
              label,
              style: const TextStyle(
                color: textSub,
                fontSize: 10,
                fontWeight: FontWeight.w600,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            color: textMain,
            fontSize: 13,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
          ),
        ),
      ],
    );
  }

  // ============================================================
  // HALAMAN UTAMA (DIDESAIN ULANG SESUAI REFERENSI)
  // ============================================================
  Widget _buildNewsPage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 12),

          // === 1. PROFILE CARD ===
          _buildProfileCard(),

          const SizedBox(height: 16),

          // === 2. GLOBAL CHAT SECTION ===
          _buildGlobalChatSection(),

          const SizedBox(height: 16),

          // === 3. PROMO BANNER (Bug WhatsApp) ===
          _buildPromoBanner(),

          const SizedBox(height: 16),

          // === 4. QUICK ACTIONS ===
          _buildQuickActions(),

          const SizedBox(height: 20),

          // === 5. COMMUNITY HUB (dipertahankan, restyled) ===
          _buildCommunityHub(),

          const SizedBox(height: 16),

          // === 6. NEWS CAROUSEL (dipertahankan, restyled) ===
          _buildNewsCarousel(),

          const SizedBox(height: 80),
        ],
      ),
    );
  }

  // --- PROFILE CARD ---
  Widget _buildProfileCard() {
    return Container(
      decoration: BoxDecoration(
        color: containerGray,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderBlack, width: 3),
        boxShadow: [
          BoxShadow(
            color: Colors.black,
            offset: const Offset(5, 5),
            blurRadius: 0,
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Baris 1: Foto profil, nama, tag
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 26,
                        backgroundColor: accentYellow,
                        backgroundImage: _profileImage != null
                            ? FileImage(_profileImage!)
                            : null,
                        child: _profileImage == null
                            ? const Icon(Icons.person,
                                color: textMain, size: 28)
                            : null,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              username.toUpperCase(),
                              style: const TextStyle(
                                color: textMain,
                                fontSize: 16,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1.0,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 6),
                            Row(
                              children: [
                                // Tag OWNER (kuning)
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: accentYellow,
                                    borderRadius: BorderRadius.circular(4),
                                    border: Border.all(
                                        color: borderBlack, width: 1.5),
                                  ),
                                  child: Text(
                                    role.toUpperCase(),
                                    style: const TextStyle(
                                      color: textMain,
                                      fontSize: 9,
                                      fontWeight: FontWeight.w900,
                                      fontFamily: 'Orbitron',
                                      letterSpacing: 1.5,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                // Tag Tanggal (pink)
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: pinkTag,
                                    borderRadius: BorderRadius.circular(4),
                                    border: Border.all(
                                        color: borderBlack, width: 1.5),
                                  ),
                                  child: Text(
                                    expiredDate,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 9,
                                      fontWeight: FontWeight.w700,
                                      fontFamily: 'ShareTechMono',
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 14),

                  // Baris 2: 3 Info Grid
                  Row(
                    children: [
                      Expanded(
                          child: _buildInfoBox("DEVICE", androidId.length > 12
                              ? androidId.substring(0, 12)
                              : androidId)),
                      const SizedBox(width: 8),
                      Expanded(
                          child: _buildInfoBox("BATTERY", "83%")),
                      const SizedBox(width: 8),
                      Expanded(
                          child: _buildInfoBox(
                              "DEVICES", activeConnections.toString())),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // Banner VORCE vertikal di sisi kanan
          Container(
            width: 36,
            height: 170,
            decoration: BoxDecoration(
              color: accentYellow,
              borderRadius: const BorderRadius.only(
                topRight: Radius.circular(9),
                bottomRight: Radius.circular(9),
              ),
              border: Border.all(color: borderBlack, width: 2),
            ),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: ['V', 'O', 'R', 'C', 'E']
                    .map((c) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 2),
                          child: Text(
                            c,
                            style: const TextStyle(
                              color: textMain,
                              fontSize: 11,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ))
                    .toList(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoBox(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
      decoration: BoxDecoration(
        color: bgSurface,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: borderBlack, width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: textSub,
              fontSize: 9,
              fontWeight: FontWeight.w700,
              fontFamily: 'Orbitron',
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              color: textMain,
              fontSize: 12,
              fontWeight: FontWeight.w900,
              fontFamily: 'ShareTechMono',
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  // --- GLOBAL CHAT SECTION ---
  Widget _buildGlobalChatSection() {
    return GestureDetector(
      onTap: () {
        // Navigasi ke halaman chat/community
        _openUrl("https://t.me/Ciyyooalways");
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: containerGray,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: borderBlack, width: 3),
          boxShadow: [
            BoxShadow(
              color: Colors.black,
              offset: const Offset(4, 4),
              blurRadius: 0,
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: accentYellow,
                shape: BoxShape.circle,
                border: Border.all(color: borderBlack, width: 2),
              ),
              child: const Icon(Icons.chat_bubble, color: textMain, size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "GLOBAL CHAT",
                    style: const TextStyle(
                      color: textMain,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    "$onlineUsers users online · Tap to join",
                    style: const TextStyle(
                      color: textSub,
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: accentYellow,
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: borderBlack, width: 2),
              ),
              child: const Icon(Icons.arrow_forward,
                  color: textMain, size: 18),
            ),
          ],
        ),
      ),
    );
  }

  // --- PROMO BANNER (Bug WhatsApp) ---
  Widget _buildPromoBanner() {
    return Container(
      height: 200,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: borderBlack, width: 3),
        boxShadow: [
          BoxShadow(
            color: Colors.black,
            offset: const Offset(5, 5),
            blurRadius: 0,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Background: video atau gradient
            if (_videoController != null &&
                _videoController!.value.isInitialized)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController!.value.size.width,
                  height: _videoController!.value.size.height,
                  child: VideoPlayer(_videoController!),
                ),
              )
            else
              Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF1A1A2E), Color(0xFF16213E)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),

            // Overlay gelap
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.black.withOpacity(0.75),
                    Colors.black.withOpacity(0.45),
                  ],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
              ),
            ),

            // Konten
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: Colors.redAccent,
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(color: borderBlack, width: 1.5),
                    ),
                    child: const Text(
                      "NEW FEATURE",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 9,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    "Coba Fitur Bug\nWhatsApp!",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      height: 1.2,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Kirim payload crash ke target secara anonim dan cepat.",
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.7),
                      fontSize: 12,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                  const SizedBox(height: 16),
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        _bottomNavIndex = 1;
                        _selectedPage = HomePage(
                          username: username,
                          password: password,
                          listBug: listBug,
                          role: role,
                          expiredDate: expiredDate,
                          sessionKey: sessionKey,
                        );
                      });
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 18, vertical: 10),
                      decoration: BoxDecoration(
                        color: accentYellow,
                        borderRadius: BorderRadius.circular(4),
                        border: Border.all(color: borderBlack, width: 2.5),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black,
                            offset: const Offset(3, 3),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.bug_report, color: textMain, size: 16),
                          SizedBox(width: 8),
                          Text(
                            "Buka Halaman Bug",
                            style: TextStyle(
                              color: textMain,
                              fontSize: 12,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Orbitron',
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --- QUICK ACTIONS ---
  Widget _buildQuickActions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Tag QUICK ACTIONS (kuning)
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: accentYellow,
            borderRadius: BorderRadius.circular(4),
            border: Border.all(color: borderBlack, width: 2.5),
          ),
          child: const Text(
            "QUICK ACTIONS",
            style: TextStyle(
              color: textMain,
              fontSize: 12,
              fontWeight: FontWeight.w900,
              fontFamily: 'Orbitron',
              letterSpacing: 2,
            ),
          ),
        ),
        const SizedBox(height: 14),

        // Grid 2 kolom
        Row(
          children: [
            Expanded(
              child: _buildActionCard(
                icon: Icons.bug_report,
                title: "Bug WhatsApp",
                description: "Kirim crash & bug payload ke nomor target",
                onTap: () {
                  setState(() {
                    _bottomNavIndex = 1;
                    _selectedPage = HomePage(
                      username: username,
                      password: password,
                      listBug: listBug,
                      role: role,
                      expiredDate: expiredDate,
                      sessionKey: sessionKey,
                    );
                  });
                },
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildActionCard(
                icon: Icons.dns_rounded,
                title: "DDoS Attack",
                description: "Serang server target dengan metode flood",
                onTap: () {
                  setState(() {
                    _bottomNavIndex = 3;
                    _selectedPage = ToolsPage(
                      sessionKey: sessionKey,
                      userRole: role,
                      listDoos: listDoos,
                    );
                  });
                },
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildActionCard({
    required IconData icon,
    required String title,
    required String description,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: containerGray,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: borderBlack, width: 2.5),
          boxShadow: [
            BoxShadow(
              color: Colors.black,
              offset: const Offset(4, 4),
              blurRadius: 0,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: accentYellow,
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: borderBlack, width: 2),
              ),
              child: Icon(icon, color: textMain, size: 22),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: const TextStyle(
                color: textMain,
                fontSize: 14,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
              ),
            ),
            const SizedBox(height: 6),
            Text(
              description,
              style: const TextStyle(
                color: textSub,
                fontSize: 11,
                fontFamily: 'ShareTechMono',
                height: 1.4,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --- COMMUNITY HUB (dipertahankan, restyled) ---
  Widget _buildCommunityHub() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: containerGray,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: borderBlack, width: 3),
        boxShadow: [
          BoxShadow(
            color: Colors.black,
            offset: const Offset(5, 5),
            blurRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: accentYellow,
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: borderBlack, width: 2),
                ),
                child: const Icon(
                  FontAwesomeIcons.telegram,
                  color: textMain,
                  size: 18,
                ),
              ),
              const SizedBox(width: 12),
              const Text(
                "COMMUNITY HUB",
                style: TextStyle(
                  color: textMain,
                  fontWeight: FontWeight.w900,
                  fontSize: 14,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            "Stay connected with the VORCELIGHT community. Get real-time updates and exclusive payloads.",
            style: const TextStyle(
              color: textSub,
              fontSize: 12,
              height: 1.5,
              fontFamily: 'ShareTechMono',
            ),
          ),
          const SizedBox(height: 14),
          GestureDetector(
            onTap: () => _openUrl("https://t.me/Ciyyooalways"),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                color: accentYellow,
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: borderBlack, width: 2.5),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black,
                    offset: const Offset(3, 3),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(FontAwesomeIcons.telegram, color: textMain, size: 18),
                  SizedBox(width: 10),
                  Text(
                    "JOIN TELEGRAM",
                    style: TextStyle(
                      color: textMain,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // --- NEWS CAROUSEL (dipertahankan, restyled) ---
  Widget _buildNewsCarousel() {
    if (newsList.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: accentYellow,
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: borderBlack, width: 2),
              ),
              child: const Icon(
                Icons.newspaper,
                color: textMain,
                size: 18,
              ),
            ),
            const SizedBox(width: 12),
            const Text(
              "LATEST UPDATES",
              style: TextStyle(
                color: textMain,
                fontWeight: FontWeight.w900,
                fontSize: 14,
                fontFamily: 'Orbitron',
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Container(
          width: double.infinity,
          height: 190,
          child: Stack(
            children: [
              PageView.builder(
                controller: _newsPageController,
                itemCount: newsList.length,
                itemBuilder: (context, index) {
                  final item = newsList[index];
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: containerGray,
                      border: Border.all(color: borderBlack, width: 2.5),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black,
                          offset: const Offset(3, 3),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          if (item['image'] != null &&
                              item['image'].toString().isNotEmpty)
                            NewsMedia(url: item['image'])
                          else
                            Container(
                              color: containerGray,
                              child: Center(
                                child: Icon(Icons.newspaper,
                                    color: Colors.grey[400], size: 50),
                              ),
                            ),
                          Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.white.withOpacity(0.9),
                                  Colors.white.withOpacity(0.3),
                                ],
                                begin: Alignment.bottomCenter,
                                end: Alignment.topCenter,
                              ),
                            ),
                          ),
                          Positioned(
                            bottom: 20,
                            left: 16,
                            right: 12,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: accentYellow,
                                    borderRadius: BorderRadius.circular(4),
                                    border: Border.all(
                                        color: borderBlack, width: 1.5),
                                  ),
                                  child: const Text(
                                    "NEWS",
                                    style: TextStyle(
                                      color: textMain,
                                      fontSize: 9,
                                      fontWeight: FontWeight.w900,
                                      fontFamily: 'Orbitron',
                                      letterSpacing: 2.0,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  item['title'] ?? 'No Title',
                                  style: const TextStyle(
                                    color: textMain,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: 'Orbitron',
                                    height: 1.3,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  item['desc'] ?? '',
                                  style: const TextStyle(
                                    color: textSub,
                                    fontSize: 12,
                                    fontFamily: 'ShareTechMono',
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),

              // Indikator halaman
              Positioned(
                bottom: 8,
                left: 0,
                right: 0,
                child: AnimatedBuilder(
                  animation: _newsPageController,
                  builder: (context, child) {
                    double currentNewsPage = 0.0;
                    if (_newsPageController.hasClients &&
                        _newsPageController.page != null) {
                      currentNewsPage = _newsPageController.page!;
                    } else {
                      currentNewsPage = _currentNewsPage;
                    }

                    return Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(newsList.length, (index) {
                        double diff = (index - currentNewsPage).abs();
                        double width = 6.0;
                        double isActive = 0.0;

                        if (diff < 1) {
                          width = 24.0 - (diff * 18.0);
                          isActive = 1.0 - diff;
                        }

                        return AnimatedContainer(
                          duration: const Duration(milliseconds: 300),
                          margin: const EdgeInsets.symmetric(horizontal: 3),
                          width: width,
                          height: 4,
                          decoration: BoxDecoration(
                            color: isActive > 0.5
                                ? accentYellow
                                : Colors.black.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(4),
                          ),
                        );
                      }),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ============================================================
  // SIDEBAR / DRAWER (DIDESAIN ULANG)
  // ============================================================
  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: bgMain,
      width: MediaQuery.of(context).size.width * 0.6,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            height: 200,
            decoration: BoxDecoration(
              color: accentYellow,
              border: Border.all(color: borderBlack, width: 3),
            ),
            child: SafeArea(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: bgSurface,
                      border: Border.all(color: borderBlack, width: 3),
                    ),
                    child: ClipOval(
                      child: Image.asset(
                        'assets/images/logo.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        username.toUpperCase(),
                        style: const TextStyle(
                          color: textMain,
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.0,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Container(
                        width: 16,
                        height: 16,
                        decoration: BoxDecoration(
                          color: bgSurface,
                          shape: BoxShape.circle,
                          border: Border.all(color: borderBlack, width: 2),
                        ),
                        child: const Icon(
                          Icons.check,
                          color: textMain,
                          size: 10,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                    decoration: BoxDecoration(
                      color: bgSurface,
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(color: borderBlack, width: 1.5),
                    ),
                    child: Text(
                      role.toUpperCase(),
                      style: const TextStyle(
                        color: textMain,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.0,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: Container(
              color: bgMain,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 10),
                children: [
                  if (role == "reseller")
                    _buildDrawerMenuItem(
                      icon: Icons.storefront,
                      label: "Seller Page",
                      onTap: () => _onSidebarTabSelected(1),
                    ),
                  if (role == "admin")
                    _buildDrawerMenuItem(
                      icon: Icons.admin_panel_settings,
                      label: "Admin Page",
                      onTap: () => _onSidebarTabSelected(2),
                    ),
                  if (role == "partner")
                    _buildDrawerMenuItem(
                      icon: FontAwesomeIcons.handshake,
                      label: "Partner Page",
                      onTap: () => _onSidebarTabSelected(4),
                    ),
                  if (role == "moderator")
                    _buildDrawerMenuItem(
                      icon: FontAwesomeIcons.userShield,
                      label: "Moderator Page",
                      onTap: () => _onSidebarTabSelected(5),
                    ),
                  if (role == "owner")
                    _buildDrawerMenuItem(
                      icon: Icons.workspace_premium,
                      label: "Owner Page",
                      onTap: () => _onSidebarTabSelected(3),
                    ),
                  _buildDrawerMenuItem(
                    icon: Icons.history_rounded,
                    label: "Riwayat Aktivitas",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => RiwayatPage(
                            sessionKey: sessionKey,
                            role: role,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDrawerMenuItem(
                    icon: Icons.headset_mic_outlined,
                    label: "Customer Service",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const ContactPage()),
                      );
                    },
                  ),
                  _buildDrawerMenuItem(
                    icon: FontAwesomeIcons.userCircle,
                    label: "My Profile",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ProfilePage(
                            username: username,
                            password: password,
                            role: role,
                            expiredDate: expiredDate,
                            sessionKey: sessionKey,
                            uid: uid,
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 20),
                  _buildDrawerMenuItem(
                    icon: Icons.logout,
                    label: "Log Out",
                    isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(builder: (_) => const LoginPage()),
                        (route) => false,
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerMenuItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: isLogout ? Colors.redAccent.withOpacity(0.15) : containerGray,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(
          color: isLogout ? Colors.redAccent : borderBlack,
          width: 2,
        ),
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: isLogout ? Colors.redAccent : accentYellow,
            borderRadius: BorderRadius.circular(4),
            border: Border.all(
              color: isLogout ? Colors.redAccent : borderBlack,
              width: 1.5,
            ),
          ),
          child: Icon(
            icon,
            color: isLogout ? Colors.white : textMain,
            size: 18,
          ),
        ),
        title: Text(
          label,
          style: TextStyle(
            color: isLogout ? Colors.redAccent : textMain,
            fontWeight: FontWeight.w800,
            fontSize: 13,
            fontFamily: 'Orbitron',
          ),
        ),
        trailing: Icon(
          Icons.arrow_forward,
          color: isLogout ? Colors.redAccent : textMain,
          size: 16,
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 8),
        horizontalTitleGap: 10,
        onTap: onTap,
      ),
    );
  }

  // ============================================================
  // BOTTOM NAVIGATION BAR (DIDESAIN ULANG)
  // ============================================================
  Widget _buildBottomNav() {
    final items = [
      {'icon': Icons.home, 'label': 'Home'},
      {'icon': FontAwesomeIcons.whatsapp, 'label': 'WhatsApp'},
      {'icon': Icons.info_outline, 'label': 'Info'},
      {'icon': Icons.build, 'label': 'Tools'},
      {'icon': Icons.settings_remote, 'label': 'Rat'},
    ];

    return Container(
      margin: const EdgeInsets.only(left: 16, right: 16, bottom: 12),
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: bgSurface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderBlack, width: 3),
        boxShadow: [
          BoxShadow(
            color: Colors.black,
            offset: const Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: List.generate(items.length, (index) {
          final isActive = index == _bottomNavIndex;
          return Expanded(
            child: GestureDetector(
              onTap: () => _onBottomNavTapped(index),
              behavior: HitTestBehavior.opaque,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: isActive ? accentYellow : Colors.transparent,
                      shape: BoxShape.circle,
                      border: isActive
                          ? Border.all(color: borderBlack, width: 2)
                          : null,
                    ),
                    child: Icon(
                      items[index]['icon'] as IconData,
                      color: isActive ? textMain : textSub,
                      size: 20,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    items[index]['label'] as String,
                    style: TextStyle(
                      color: isActive ? textMain : textSub,
                      fontSize: 9,
                      fontWeight: isActive ? FontWeight.w900 : FontWeight.w500,
                      fontFamily: 'Orbitron',
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
          );
        }),
      ),
    );
  }

  // ============================================================
  // BUILD UTAMA (DIDESAIN ULANG)
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        leading: Builder(
          builder: (innerContext) => GestureDetector(
            onTap: () => Scaffold.of(innerContext).openDrawer(),
            child: Container(
              margin: const EdgeInsets.only(left: 12),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: accentYellow,
                shape: BoxShape.circle,
                border: Border.all(color: borderBlack, width: 2.5),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black,
                    offset: const Offset(3, 3),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: const Icon(Icons.menu, color: textMain, size: 20),
            ),
          ),
        ),
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "Vorcelight",
              style: TextStyle(
                color: textMain,
                fontWeight: FontWeight.w900,
                fontSize: 15,
                fontFamily: 'Orbitron',
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(width: 4),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: accentYellow,
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: borderBlack, width: 1.5),
              ),
              child: const Text(
                "project",
                style: TextStyle(
                  color: textMain,
                  fontWeight: FontWeight.w900,
                  fontSize: 11,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1.5,
                ),
              ),
            ),
          ],
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ProfilePage(
                  username: username,
                  password: password,
                  role: role,
                  expiredDate: expiredDate,
                  sessionKey: sessionKey,
                  uid: uid,
                ),
              ),
            ),
            child: Container(
              margin: const EdgeInsets.only(right: 12),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: accentYellow,
                shape: BoxShape.circle,
                border: Border.all(color: borderBlack, width: 2.5),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black,
                    offset: const Offset(3, 3),
                    blurRadius: 0,
                  ),
                ],
              ),
              child:
                  const Icon(Icons.settings, color: textMain, size: 20),
            ),
          ),
        ],
      ),
      drawer: _buildCustomDrawer(),
      body: SafeArea(
        child: FadeTransition(
          opacity: _animation,
          child: _selectedPage,
        ),
      ),
      extendBody: true,
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  @override
  void dispose() {
    _videoController?.dispose();
    _newsTimer?.cancel();
    _newsPageController.dispose();
    channel.sink.close(status.goingAway);
    _controller.dispose();
    super.dispose();
  }
}

class NewsMedia extends StatelessWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  Widget build(BuildContext context) {
    if (url.endsWith(".mp4") || url.endsWith(".webm") || url.endsWith(".mov")) {
      return Container(
        color: const Color(0xFFD9D9D9),
        child: const Center(
          child: Icon(
            Icons.videocam_off,
            color: Colors.grey,
            size: 50,
          ),
        ),
      );
    }
    return Image.network(
      url,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        color: const Color(0xFFD9D9D9),
        child: const Center(
          child: Icon(
            Icons.broken_image,
            color: Colors.grey,
          ),
        ),
      ),
    );
  }
}