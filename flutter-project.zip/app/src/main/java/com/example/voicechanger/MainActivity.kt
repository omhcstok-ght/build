package com.example.voicechanger

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.AudioManager
import android.media.AudioAttributes
import android.media.AudioPlaybackCaptureConfiguration
import android.os.Process
import android.view.ViewGroup
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.math.PI
import kotlin.math.sin

class MainActivity : Activity() {
    private var engine: VoiceEngine? = null
    private var selected = Effect.NORMAL
    private lateinit var status: TextView
    private lateinit var startButton: Button
    private lateinit var effectButtons: MutableMap<Effect, Button>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 18, 38)
        window.navigationBarColor = Color.rgb(16, 18, 38)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(28), dp(24), dp(24))
            setBackgroundColor(Color.rgb(16, 18, 38))
        }
        val title = TextView(this).apply {
            text = "VOICE CHANGER"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "Ubah karakter suaramu secara langsung"
            textSize = 14f
            setTextColor(Color.rgb(170, 174, 199))
            setPadding(0, dp(8), 0, dp(24))
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(22), dp(18), dp(22))
            background = rounded(Color.rgb(30, 33, 60), 24)
        }
        status = TextView(this).apply {
            text = "SIAP DIGUNAKAN"
            textSize = 12f
            letterSpacing = .12f
            setTextColor(Color.rgb(172, 163, 255))
            typeface = Typeface.DEFAULT_BOLD
        }
        startButton = Button(this).apply {
            text = "MULAI"
            textSize = 16f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(111, 83, 255), 18)
            setPadding(dp(34), dp(12), dp(34), dp(12))
            setOnClickListener { toggleEngine() }
        }
        panel.addView(status)
        panel.addView(startButton, LinearLayout.LayoutParams(-2, dp(58)).apply { topMargin = dp(18) })
        val effectsTitle = TextView(this).apply {
            text = "PILIH EFEK SUARA"
            textSize = 13f
            letterSpacing = .08f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(28), 0, dp(14))
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(panel)
        root.addView(effectsTitle)

        effectButtons = mutableMapOf()
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val choices = listOf(Effect.NORMAL, Effect.ROBOT, Effect.ECHO, Effect.RADIO)
        for (i in choices.indices step 2) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            choices.slice(i..i+1).forEach { effect ->
                val b = Button(this).apply {
                    text = effect.label
                    isAllCaps = false
                    textSize = 14f
                    setTextColor(Color.WHITE)
                    background = rounded(if (effect == selected) Color.rgb(82, 67, 160) else Color.rgb(39, 42, 70), 16)
                    setOnClickListener { chooseEffect(effect) }
                }
                effectButtons[effect] = b
                row.addView(b, LinearLayout.LayoutParams(0, dp(58), 1f).apply {
                    if (effect == choices[i]) rightMargin = dp(8) else leftMargin = dp(8)
                    bottomMargin = dp(12)
                })
            }
            grid.addView(row)
        }
        root.addView(grid)
        val note = TextView(this).apply {
            text = "Gunakan headset untuk mengurangi feedback. Efek diproses di perangkat; jangan gunakan untuk menyamar atau menipu orang lain."
            textSize = 12f
            setTextColor(Color.rgb(145, 150, 179))
            setPadding(0, dp(14), 0, 0)
        }
        root.addView(note)
        setContentView(root)
    }

    private fun chooseEffect(effect: Effect) {
        selected = effect
        effectButtons.forEach { (key, button) ->
            button.background = rounded(
                if (key == selected) Color.rgb(82, 67, 160) else Color.rgb(39, 42, 70), 16
            )
        }
        engine?.effect = effect
    }

    private fun toggleEngine() {
        if (engine?.running == true) {
            engine?.stop()
            engine = null
            status.text = "SIAP DIGUNAKAN"
            startButton.text = "MULAI"
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 41)
            return
        }
        try {
            engine = VoiceEngine(selected).also { it.start() }
            status.text = "LIVE • MICROPHONE AKTIF"
            startButton.text = "HENTIKAN"
        } catch (e: Exception) {
            engine = null
            Toast.makeText(this, "Tidak dapat memulai audio: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == 41 && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) {
            toggleEngine()
        } else {
            Toast.makeText(this, "Izin mikrofon diperlukan untuk mengubah suara.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        engine?.stop()
        engine = null
        super.onDestroy()
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}

enum class Effect(val label: String) {
    NORMAL("Normal"), ROBOT("Robot"), ECHO("Echo"), RADIO("Radio")
}

private class VoiceEngine(@Volatile var effect: Effect) {
    @Volatile var running = false
        private set
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    private var worker: Thread? = null
    private val sampleRate = 44100
    private val delay = ShortArray(sampleRate / 3)
    private var delayIndex = 0
    private var phase = 0.0

    fun start() {
        val minIn = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val minOut = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        require(minIn > 0 && minOut > 0) { "Perangkat tidak mendukung audio mono" }
        val bufferSize = maxOf(minIn, minOut, 4096)
        val input = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION, sampleRate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize
        )
        val output = AudioTrack(
            AudioManager.STREAM_MUSIC, sampleRate,
            AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
            bufferSize, AudioTrack.MODE_STREAM
        )
        require(input.state == AudioRecord.STATE_INITIALIZED && output.state == AudioTrack.STATE_INITIALIZED) {
            "Audio input/output gagal diinisialisasi"
        }
        recorder = input
        player = output
        input.startRecording()
        output.play()
        running = true
        worker = Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
            val buffer = ShortArray(1024)
            while (running) {
                val count = input.read(buffer, 0, buffer.size)
                if (count > 0) {
                    process(buffer, count)
                    output.write(buffer, 0, count)
                }
            }
        }.apply { name = "VoiceChangerAudio"; start() }
    }

    private fun process(samples: ShortArray, count: Int) {
        for (i in 0 until count) {
            val x = samples[i].toDouble()
            val y = when (effect) {
                Effect.NORMAL -> x
                Effect.ROBOT -> {
                    phase += 2.0 * PI * 35.0 / sampleRate
                    if (phase >= 2.0 * PI) phase -= 2.0 * PI
                    x * sin(phase) * 1.7
                }
                Effect.ECHO -> {
                    val delayed = delay[delayIndex].toDouble()
                    val out = x + delayed * 0.48
                    delay[delayIndex] = (x + delayed * 0.22).toInt().coerceIn(-32768, 32767).toShort()
                    delayIndex = (delayIndex + 1) % delay.size
                    out
                }
                Effect.RADIO -> {
                    val clipped = (x * 2.2).toInt().coerceIn(-9000, 9000)
                    clipped.toDouble()
                }
            }
            samples[i] = y.toInt().coerceIn(-32768, 32767).toShort()
        }
    }

    fun stop() {
        running = false
        try { worker?.join(500) } catch (_: InterruptedException) {}
        try { recorder?.stop() } catch (_: Exception) {}
        try { player?.pause(); player?.flush(); player?.stop() } catch (_: Exception) {}
        recorder?.release()
        player?.release()
        recorder = null
        player = null
        worker = null
    }
}
