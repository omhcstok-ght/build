const express = require('express');
const path = require('path');
require('dotenv').config();
const app = express();
app.use(express.json({limit:'100kb'}));
app.use(express.static(path.join(__dirname,'public')));
app.get('/api/status',(req,res)=>res.json({
  ok:true,
  whatsappConfigured:Boolean(process.env.WHATSAPP_TOKEN && process.env.PHONE_NUMBER_ID)
}));
app.get('/webhook',(req,res)=>{
  const mode=req.query['hub.mode'], token=req.query['hub.verify_token'], challenge=req.query['hub.challenge'];
  if(mode==='subscribe' && token && token===process.env.VERIFY_TOKEN) return res.status(200).send(challenge);
  res.sendStatus(403);
});
app.post('/webhook',(req,res)=>{
  // Terima event webhook resmi; balasan otomatis dapat ditambahkan
  // dengan validasi X-Hub-Signature-256 menggunakan APP_SECRET.
  const body=req.body;
  if(body?.object==='whatsapp_business_account'){
    console.log('WhatsApp webhook event received');
    return res.sendStatus(200);
  }
  res.sendStatus(404);
});
const port=process.env.PORT||3000;
app.listen(port,'0.0.0.0',()=>console.log(`LIZC server running on http://localhost:${port}`));
