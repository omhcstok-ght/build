const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.json({ ok: true, game: "Sepeda Ontel Online" }));

const players = new Map();
const clamp = (n, min, max) => Math.max(min, Math.min(max, n));

io.on("connection", socket => {
  socket.on("join", raw => {
    const name = String(raw?.name || "Ontel Rider").trim().slice(0, 18) || "Ontel Rider";
    const color = /^#[0-9a-fA-F]{6}$/.test(raw?.color) ? raw.color : "#d97706";
    const player = {
      id: socket.id, name, color,
      x: Math.random() * 8 - 4, z: Math.random() * 8 - 4,
      rot: 0, speed: 0, score: 0, coins: 100,
      lastUpdate: Date.now()
    };
    players.set(socket.id, player);
    socket.emit("welcome", { id: socket.id, players: [...players.values()] });
    socket.broadcast.emit("playerJoined", player);
  });

  socket.on("move", data => {
    const p = players.get(socket.id);
    if (!p || !data) return;
    p.x = clamp(Number(data.x) || 0, -450, 450);
    p.z = clamp(Number(data.z) || 0, -450, 450);
    p.rot = Number(data.rot) || 0;
    p.speed = clamp(Number(data.speed) || 0, 0, 18);
    p.lastUpdate = Date.now();
    socket.broadcast.emit("playerMoved", p);
  });

  socket.on("chat", raw => {
    const p = players.get(socket.id);
    if (!p) return;
    const message = String(raw || "").trim().slice(0, 180);
    if (!message) return;
    io.emit("chat", { id: socket.id, name: p.name, message, time: Date.now() });
  });

  socket.on("coinPickup", () => {
    const p = players.get(socket.id);
    if (!p) return;
    p.coins += 5;
    p.score += 10;
    socket.emit("wallet", { coins: p.coins, score: p.score });
  });

  socket.on("disconnect", () => {
    players.delete(socket.id);
    io.emit("playerLeft", socket.id);
  });
});

// Remove stale positions if a client disappears without a clean disconnect.
setInterval(() => {
  const cutoff = Date.now() - 60000;
  for (const [id, p] of players) {
    if (p.lastUpdate < cutoff) {
      players.delete(id);
      io.emit("playerLeft", id);
    }
  }
}, 15000);

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Sepeda Ontel Online running on http://localhost:${PORT}`);
});
