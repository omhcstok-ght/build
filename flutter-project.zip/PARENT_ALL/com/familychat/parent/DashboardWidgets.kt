package com.familychat.parent

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.concurrent.thread

/**
 * Clock, calendar, weather, prayer times, mini music player.
 * UI-only helpers — does not touch remote-control Firebase logic.
 */
object DashboardWidgets {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var clockRunnable: Runnable? = null
    private var mediaPlayer: MediaPlayer? = null
    private var musicPlaying = false

    // ---- Clock / Calendar ----
    fun bindClock(tvClock: TextView, tvDate: TextView) {
        val timeFmt = SimpleDateFormat("HH:mm", Locale("id", "ID"))
        val dateFmt = SimpleDateFormat("EEE, d MMM yyyy", Locale("id", "ID"))
        clockRunnable?.let { mainHandler.removeCallbacks(it) }
        val r = object : Runnable {
            override fun run() {
                val now = Date()
                tvClock.text = timeFmt.format(now)
                tvDate.text = dateFmt.format(now).replaceFirstChar {
                    if (it.isLowerCase()) it.titlecase(Locale("id", "ID")) else it.toString()
                }
                mainHandler.postDelayed(this, 15_000)
            }
        }
        clockRunnable = r
        r.run()
    }

    fun stopClock() {
        clockRunnable?.let { mainHandler.removeCallbacks(it) }
        clockRunnable = null
    }

    // ---- Weather (Open-Meteo, no API key) ----
    // Default: Gresik, East Java
    fun loadWeather(
        tvTemp: TextView,
        tvDesc: TextView,
        tvIcon: TextView,
        tvLoc: TextView,
        lat: Double = -7.1568,
        lon: Double = 112.6558,
        place: String = "Gresik"
    ) {
        tvLoc.text = place
        thread {
            try {
                val url =
                    "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code&timezone=Asia%2FJakarta"
                val body = httpGet(url) ?: return@thread
                val cur = JSONObject(body).getJSONObject("current")
                val temp = cur.getDouble("temperature_2m")
                val code = cur.getInt("weather_code")
                val (icon, desc) = weatherCode(code)
                mainHandler.post {
                    tvTemp.text = "${temp.toInt()}°C"
                    tvDesc.text = desc
                    tvIcon.text = icon
                }
            } catch (_: Exception) {
                mainHandler.post {
                    tvTemp.text = "—"
                    tvDesc.text = "Cuaca offline"
                }
            }
        }
    }

    private fun weatherCode(code: Int): Pair<String, String> = when (code) {
        0 -> "☀️" to "Cerah"
        1, 2 -> "⛅" to "Berawan cerah"
        3 -> "☁️" to "Berawan"
        45, 48 -> "🌫️" to "Berkabut"
        51, 53, 55, 56, 57 -> "🌦️" to "Gerimis"
        61, 63, 65, 66, 67 -> "🌧️" to "Hujan"
        71, 73, 75, 77 -> "🌨️" to "Salju"
        80, 81, 82 -> "🌧️" to "Hujan deras"
        95, 96, 99 -> "⛈️" to "Badai"
        else -> "🌡️" to "Cuaca"
    }

    // ---- Prayer times (Aladhan API) ----
    fun loadPrayerTimes(
        tvFajr: TextView,
        tvDhuhr: TextView,
        tvAsr: TextView,
        tvMaghrib: TextView,
        tvIsha: TextView,
        tvNext: TextView,
        city: String = "Gresik",
        country: String = "Indonesia"
    ) {
        thread {
            try {
                val url =
                    "https://api.aladhan.com/v1/timingsByCity?city=${Uri.encode(city)}&country=${Uri.encode(country)}&method=20"
                // method 20 ≈ Kemenag Indonesia
                val body = httpGet(url) ?: return@thread
                val timings = JSONObject(body).getJSONObject("data").getJSONObject("timings")
                fun clean(k: String): String = timings.getString(k).substringBefore(" ")
                val fajr = clean("Fajr")
                val dhuhr = clean("Dhuhr")
                val asr = clean("Asr")
                val maghrib = clean("Maghrib")
                val isha = clean("Isha")
                val next = nextPrayerLabel(fajr, dhuhr, asr, maghrib, isha)
                mainHandler.post {
                    tvFajr.text = "Subuh\n$fajr"
                    tvDhuhr.text = "Dzuhur\n$dhuhr"
                    tvAsr.text = "Ashar\n$asr"
                    tvMaghrib.text = "Maghrib\n$maghrib"
                    tvIsha.text = "Isya\n$isha"
                    tvNext.text = "Berikutnya: $next"
                }
            } catch (_: Exception) {
                mainHandler.post {
                    tvNext.text = "Berikutnya: — (offline)"
                }
            }
        }
    }

    private fun nextPrayerLabel(
        fajr: String, dhuhr: String, asr: String, maghrib: String, isha: String
    ): String {
        val now = Calendar.getInstance(TimeZone.getTimeZone("Asia/Jakarta"))
        val mins = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        fun toMin(t: String): Int {
            val p = t.split(":")
            return p[0].toInt() * 60 + p[1].toInt()
        }
        val list = listOf(
            "Subuh" to toMin(fajr),
            "Dzuhur" to toMin(dhuhr),
            "Ashar" to toMin(asr),
            "Maghrib" to toMin(maghrib),
            "Isya" to toMin(isha)
        )
        for ((name, m) in list) {
            if (m > mins) {
                val hh = m / 60
                val mm = m % 60
                return "$name %02d:%02d".format(hh, mm)
            }
        }
        return "Subuh $fajr (besok)"
    }

    // ---- Music: search + play in-app (iTunes preview 30s / direct URL) ----
    data class Track(val title: String, val artist: String, val previewUrl: String, val artwork: String = "")

    private val searchResults = mutableListOf<Track>()
    private var searchIndex = 0

    /**
     * Cari lagu FULL length (bukan cuma 30 detik).
     * 1) Internet Archive mp3 full
     * 2) Radio Browser live stream full
     * 3) iTunes preview hanya fallback
     */
    fun searchTracks(query: String, onDone: (List<Track>) -> Unit) {
        thread {
            val list = mutableListOf<Track>()
            try { list.addAll(searchInternetArchive(query)) } catch (_: Exception) {}
            try { if (list.size < 8) list.addAll(searchRadioStations(query)) } catch (_: Exception) {}
            try { if (list.isEmpty()) list.addAll(searchItunesPreview(query)) } catch (_: Exception) {}
            mainHandler.post { onDone(list) }
        }
    }

    private fun searchInternetArchive(query: String): List<Track> {
        val q = Uri.encode("($query) AND mediatype:audio")
        val searchUrl =
            "https://archive.org/advancedsearch.php?q=$q&fl[]=identifier&fl[]=title&fl[]=creator&sort[]=downloads+desc&rows=12&page=1&output=json"
        val body = httpGet(searchUrl) ?: return emptyList()
        val docs = JSONObject(body).getJSONObject("response").getJSONArray("docs")
        val out = mutableListOf<Track>()
        for (i in 0 until docs.length()) {
            if (out.size >= 10) break
            val doc = docs.getJSONObject(i)
            val id = doc.optString("identifier", "")
            if (id.isBlank()) continue
            val title = doc.optString("title", id)
            val creator = doc.optString("creator", "Internet Archive")
            val meta = httpGet("https://archive.org/metadata/$id") ?: continue
            val files = JSONObject(meta).optJSONArray("files") ?: continue
            var mp3Name: String? = null
            var bestSize = 0L
            for (j in 0 until files.length()) {
                val f = files.getJSONObject(j)
                val name = f.optString("name", "")
                if (!name.lowercase().endsWith(".mp3")) continue
                val sz = f.optString("size", "0").toLongOrNull() ?: 0L
                if (sz > bestSize && sz in 500_000L..(40L * 1024 * 1024)) {
                    bestSize = sz
                    mp3Name = name
                }
            }
            if (mp3Name == null) continue
            val encoded = Uri.encode(mp3Name).replace("+", "%20")
            val stream = "https://archive.org/download/$id/$encoded"
            out.add(Track(title = title.take(60), artist = creator.toString().take(40), previewUrl = stream))
        }
        return out
    }

    private fun searchRadioStations(query: String): List<Track> {
        val url =
            "https://de1.api.radio-browser.info/json/stations/search?name=${Uri.encode(query)}&limit=8&hidebroken=true&order=clickcount&reverse=true"
        val body = httpGet(url) ?: return emptyList()
        val arr = org.json.JSONArray(body)
        val out = mutableListOf<Track>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val stream = o.optString("url_resolved", o.optString("url", ""))
            if (stream.isBlank()) continue
            out.add(
                Track(
                    title = o.optString("name", "Radio").take(50),
                    artist = ("Radio · " + o.optString("country", "")).take(40),
                    previewUrl = stream
                )
            )
        }
        return out
    }

    private fun searchItunesPreview(query: String): List<Track> {
        val url =
            "https://itunes.apple.com/search?term=${Uri.encode(query)}&media=music&entity=song&limit=10"
        val body = httpGet(url) ?: return emptyList()
        val arr = JSONObject(body).getJSONArray("results")
        val out = mutableListOf<Track>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val preview = o.optString("previewUrl", "")
            if (preview.isBlank()) continue
            out.add(
                Track(
                    title = o.optString("trackName", "Unknown") + " (full stream).,
                    artist = o.optString("artistName", ""),
                    previewUrl = preview
                )
            )
        }
        return out
    }

    /** Dialog: ketik judul/artis → pilih hasil → langsung play di app */
    fun showSearchAndPlay(
        ctx: Context,
        tvTitle: TextView,
        tvArtist: TextView,
        playBtn: TextView
    ) {
        val input = android.widget.EditText(ctx).apply {
            hint = "Judul lagu / artis (contoh: Tulus Hati-Hati di Jalan)"
        }
        android.app.AlertDialog.Builder(ctx)
            .setTitle("Cari & Play Lagu")
            .setMessage("Cari lagu, pilih hasil, langsung diputar di app (full stream).")
            .setView(input)
            .setPositiveButton("Cari") { _, _ ->
                val q = input.text.toString().trim()
                if (q.isEmpty()) return@setPositiveButton
                tvTitle.text = "Mencari…"
                tvArtist.text = q
                searchTracks(q) { list ->
                    if (list.isEmpty()) {
                        Toast.makeText(ctx, "Tidak ketemu. Coba kata lain / buka YT Music.", Toast.LENGTH_SHORT).show()
                        tvTitle.text = "Tidak ketemu"
                        // fallback buka YT Music search
                        openYoutubeMusic(ctx, q)
                        return@searchTracks
                    }
                    searchResults.clear()
                    searchResults.addAll(list)
                    searchIndex = 0
                    val labels = list.map { "${it.title} — ${it.artist}" }.toTypedArray()
                    android.app.AlertDialog.Builder(ctx)
                        .setTitle("Hasil (${list.size})")
                        .setItems(labels) { _, which ->
                            searchIndex = which
                            val t = list[which]
                            playUrl(ctx, t.previewUrl, tvTitle, tvArtist, playBtn, t.title, t.artist)
                        }
                        .setNegativeButton("Batal", null)
                        .setNeutralButton("Buka di YT Music") { _, _ -> openYoutubeMusic(ctx, q) }
                        .show()
                }
            }
            .setNeutralButton("YT Music") { _, _ ->
                openYoutubeMusic(ctx, input.text.toString().trim())
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    fun playUrl(
        ctx: Context,
        url: String,
        tvTitle: TextView,
        tvArtist: TextView,
        playBtn: TextView,
        title: String? = null,
        artist: String? = null
    ) {
        stopMusic()
        if (url.contains("youtube.com") || url.contains("youtu.be") || url.contains("music.youtube")) {
            openYoutubeMusic(ctx, url)
            tvTitle.text = "YouTube Music"
            tvArtist.text = "Dibuka di app / browser"
            return
        }
        thread {
            try {
                val mp = MediaPlayer()
                mediaPlayer = mp
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                mp.setDataSource(url)
                mp.setOnPreparedListener {
                    it.start()
                    musicPlaying = true
                    mainHandler.post {
                        tvTitle.text = (title ?: url.substringAfterLast('/')).take(48)
                        tvArtist.text = artist ?: "Streaming…"
                        playBtn.text = "⏸"
                    }
                }
                mp.setOnCompletionListener {
                    musicPlaying = false
                    mainHandler.post { playBtn.text = "▶️" }
                }
                mp.setOnErrorListener { _, _, _ ->
                    mainHandler.post {
                        Toast.makeText(ctx, "Gagal play stream", Toast.LENGTH_SHORT).show()
                        playBtn.text = "▶️"
                    }
                    true
                }
                mp.prepareAsync()
            } catch (e: Exception) {
                mainHandler.post {
                    Toast.makeText(ctx, "Gagal putar: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun playNext(ctx: Context, tvTitle: TextView, tvArtist: TextView, playBtn: TextView) {
        if (searchResults.isEmpty()) {
            openYoutubeMusic(ctx, "trending")
            return
        }
        searchIndex = (searchIndex + 1) % searchResults.size
        val t = searchResults[searchIndex]
        playUrl(ctx, t.previewUrl, tvTitle, tvArtist, playBtn, t.title, t.artist)
    }

    fun playPrev(ctx: Context, tvTitle: TextView, tvArtist: TextView, playBtn: TextView) {
        if (searchResults.isEmpty()) {
            openYoutubeMusic(ctx)
            return
        }
        searchIndex = if (searchIndex <= 0) searchResults.lastIndex else searchIndex - 1
        val t = searchResults[searchIndex]
        playUrl(ctx, t.previewUrl, tvTitle, tvArtist, playBtn, t.title, t.artist)
    }

    fun togglePlay(playBtn: TextView) {
        val mp = mediaPlayer ?: return
        if (musicPlaying) {
            mp.pause()
            musicPlaying = false
            playBtn.text = "▶️"
        } else {
            mp.start()
            musicPlaying = true
            playBtn.text = "⏸"
        }
    }

    fun stopMusic() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (_: Exception) {}
        mediaPlayer = null
        musicPlaying = false
    }

    fun openYoutubeMusic(ctx: Context, queryOrUrl: String = "") {
        try {
            val uri = when {
                queryOrUrl.startsWith("http") -> Uri.parse(queryOrUrl)
                queryOrUrl.isNotBlank() -> Uri.parse(
                    "https://music.youtube.com/search?q=${Uri.encode(queryOrUrl)}"
                )
                else -> Uri.parse("https://music.youtube.com/")
            }
            val i = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(ctx, "Tidak ada app untuk membuka link", Toast.LENGTH_SHORT).show()
        }
    }

    private fun httpGet(url: String): String? {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 8000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "SoraParent/1.0")
        }
        return try {
            if (conn.responseCode !in 200..299) return null
            conn.inputStream.bufferedReader().readText()
        } finally {
            conn.disconnect()
        }
    }
}
