# LIZC WhatsApp Panel

## Menjalankan di Termux
1. Install Node.js: `pkg update && pkg install nodejs-lts unzip -y`
2. Ekstrak ZIP, lalu masuk ke folder `LIZC`.
3. Install dependensi: `npm install`
4. Salin konfigurasi: `cp .env.example .env`
5. Jalankan: `npm start`
6. Buka `http://127.0.0.1:3000`

Login awal lokal:
- Username: `lizc`
- Password: `LIZC-2026`

Ganti mekanisme login sebelum deployment publik. Login contoh ini hanya untuk prototipe lokal dan bukan autentikasi produksi.

## Animasi
Video referensi kedua disimpan sebagai `public/assets/intro.mp4` dan diputar sebagai latar halaman login.

## WhatsApp
Server menyediakan endpoint verifikasi dan penerimaan webhook WhatsApp Cloud API:
- GET `/webhook`
- POST `/webhook`

Isi `.env` menggunakan kredensial Meta Developer milik sendiri. Untuk deployment publik, gunakan HTTPS, validasi signature `X-Hub-Signature-256`, autentikasi admin sisi server, pembatasan laju, dan penyimpanan rahasia di environment hosting.

Panel ini tidak menyertakan fitur crash, spam massal, atau gangguan terhadap nomor/grup. Gunakan Cloud API untuk komunikasi yang mendapat persetujuan penerima.
