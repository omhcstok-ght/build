# Voice Changer (Flutter)

Flutter Android source project with Normal, Robot, Echo, and Radio-style live microphone effects.

## Build

The ZIP must be extracted so that `pubspec.yaml` is at the project root. Run:

```sh
flutter pub get
flutter create --platforms=android .
flutter build apk --release
```

APK output: `build/app/outputs/flutter-apk/app-release.apk`

## Notes

- Requires microphone permission.
- Use earphones to reduce acoustic feedback.
- Real-time latency and audio routing depend on the Android device and its audio hardware.
