# Voice Changer (Flutter)

Flutter Android app with live microphone monitoring and four simple audio effects:
Normal, Robot, Echo, and Radio.

## Build

This archive is structured as a Flutter project root. Extract the ZIP so that
`pubspec.yaml` is directly in the project root, then run:

```bash
flutter pub get
flutter build apk --debug
```

The debug APK is created at `build/app/outputs/flutter-apk/app-debug.apk`.

## Notes

- Android microphone permission is declared in the manifest.
- Use earphones to reduce acoustic feedback.
- Real-time monitoring latency and microphone routing depend on the Android device.
- This project source has not been compiled in this environment because the Flutter SDK
  is not installed here. The Telegram build result is the final compatibility check.
