# Sepeda Ontel Online

Game web 3D dengan server multiplayer berbasis Node.js, Express, dan Socket.IO.

## Jalankan di komputer

1. Install Node.js 18 atau lebih baru.
2. Ekstrak ZIP ini.
3. Buka terminal pada folder proyek.
4. Jalankan:
   ```bash
   npm install
   npm start
   ```
5. Buka `http://localhost:3000`.

## Main bersama melalui jaringan lokal

Pastikan semua perangkat berada di Wi-Fi yang sama, lalu buka `http://IP-KOMPUTER:3000` dari HP lain.

## Agar bisa dimainkan orang lain lewat internet

Deploy folder proyek ini ke hosting Node.js yang mendukung WebSocket (misalnya Render, Railway, Fly.io, atau VPS). Atur port menggunakan environment variable `PORT`. Setelah deploy, bagikan URL HTTPS dari hosting kepada pemain lain.

## Catatan penting

- Ini adalah implementasi multiplayer real-time dasar: posisi, pemain masuk/keluar, dan chat dibagikan lewat server.
- Server belum memiliki akun terverifikasi, database permanen, anti-cheat kuat, moderasi chat, pembayaran, atau sistem keamanan produksi.
- Koin dan skor pada versi ini adalah progres sesi; jangan gunakan untuk transaksi atau hadiah bernilai uang.
- Three.js dimuat dari CDN, sehingga browser memerlukan koneksi internet.
- Untuk produksi publik, tambahkan autentikasi, validasi gerakan server-side, rate limiting, database, moderasi, dan HTTPS.
