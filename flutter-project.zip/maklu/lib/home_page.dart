import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

const _baseUrl = 'https://syahmishop.zhaher.my.id:2775';

// ─── Palette: 100% TRAMSXVLOID UI Presisi Berdasarkan Gambar ───────────────────
class _C {
  static const bg        = Color(0xFF000000);
  static const surface   = Color(0xFF050102);
  static const card      = Color(0xFF0F090A);
  static const border    = Color(0xFF2C0A0E);
  static const blue      = Color(0xFFE50914);
  static const blueMid   = Color(0xFFE50914);
  static const blueLight = Color(0xFFFF1E27);
  static const blueFrost = Color(0xFFFFFFFF);
  static const green     = Color(0xFF22C55E);
  static const greenDim  = Color(0xFF16A34A);
  static const amber     = Color(0xFFF59E0B);
  static const red       = Color(0xFFE50914);
  static const text      = Color(0xFFFFFFFF);
  static const textSub   = Color(0xFF555555);
  static const textDim   = Color(0xFF333333);

  static const LinearGradient btnGrad = LinearGradient(
    colors: [Color(0xFFB80710), Color(0xFFE50914)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'owner':    return const Color(0xFFE50914);
    case 'admin':    return const Color(0xFFE50914);
    case 'moderator': return const Color(0xFF22C55E);
    case 'partner':  return const Color(0xFFFFFFFF);
    case 'vip':      return const Color(0xFFE50914);
    case 'reseller': return const Color(0xFF22C55E);
    default:         return const Color(0xFFE50914);
  }
}

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetCtrl = TextEditingController();

  String selectedBugId = '';
  String _bugMode      = 'number';
  String _senderType   = 'private';
  bool   _isSending    = false;
  String? _responseMsg;

  List<String> _globalSenders   = [];
  bool         _isLoadingSenders = false;

  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _sendBtnCtrl;
  late AnimationController _resultCtrl;
  late AnimationController _waveCtrl;

  late Animation<double> _entrance;
  late Animation<double> _sendPulse;
  late Animation<double> _sendGlow;
  late Animation<double> _resultFade;
  late Animation<Offset>  _resultSlide;

  late VideoPlayerController _videoCtrl;
  ChewieController? _chewieCtrl;
  bool _videoReady = false;

  bool get canAccessGlobalSender {
    final r = widget.role.toLowerCase();
    return r == 'admin' || r == 'vip' || r == 'owner';
  }

  @override
  void initState() {
    super.initState();
    if (widget.listBug.isNotEmpty) selectedBugId = widget.listBug[0]['bug_id'];

    _bgCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 16))..repeat();

    _entranceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _entrance = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic);

    _sendBtnCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..repeat(reverse: true);
    _sendPulse = Tween<double>(begin: 1.0, end: 1.02).animate(CurvedAnimation(parent: _sendBtnCtrl, curve: Curves.easeInOut));
    _sendGlow = Tween<double>(begin: 0.3, end: 0.6).animate(CurvedAnimation(parent: _sendBtnCtrl, curve: Curves.easeInOut));

    _resultCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 450));
    _resultFade  = CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOut);
    _resultSlide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero).animate(CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOutCubic));

    _waveCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat();

    _entranceCtrl.forward();
    _initVideo();
    _loadGlobalSenders();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _sendBtnCtrl.dispose();
    _resultCtrl.dispose();
    _waveCtrl.dispose();
    targetCtrl.dispose();
    _videoCtrl.dispose();
    _chewieCtrl?.dispose();
    super.dispose();
  }

  void _initVideo() {
    _videoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4');
    _videoCtrl.initialize().then((_) {
      if (!mounted) return;
      _videoCtrl.setVolume(1.0);
      setState(() {
        _chewieCtrl = ChewieController(
          videoPlayerController: _videoCtrl,
          autoPlay: true,
          looping: true,
          showControls: false,
          allowFullScreen: false,
          allowMuting: false,
        );
        _videoReady = true;
      });
    }).catchError((error) {
      print('Error initializing video: $error');
      setState(() {
        _videoReady = false;
      });
    });
  }

  Future<void> _loadGlobalSenders() async {
    setState(() => _isLoadingSenders = true);
    try {
      final res = await http.get(Uri.parse(
        '$_baseUrl/getActiveSenders?key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 10));

      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['senders'] != null) {
        if (mounted) setState(() => _globalSenders = List<String>.from(data['senders']));
      } else {
        if (mounted) setState(() => _globalSenders = []);
      }
    } catch (_) {
      if (mounted) setState(() => _globalSenders = []);
    } finally {
      if (mounted) setState(() => _isLoadingSenders = false);
    }
  }

  Future<void> _sendBug() async {
    final rawInput = targetCtrl.text.trim();
    final key      = widget.sessionKey;

    if (_bugMode == 'number') {
      if (formatPhone(rawInput) == null) {
        _showAlert('Nomor Tidak Valid', 'Gunakan format internasional.\nContoh: +62812xxxxxxxx');
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert('Link Tidak Valid', 'Masukkan link grup WhatsApp yang valid.\nContoh: https://chat.whatsapp.com/XXX');
        return;
      }
    }

    if (_senderType == 'global' && !canAccessGlobalSender) {
      _showAlert('Akses Ditolak', 'Sender Global hanya untuk Admin!');
      return;
    }

    if (selectedBugId.isEmpty) {
      _showAlert('Pilih Bug', 'Silakan pilih bug terlebih dahulu.');
      return;
    }

    setState(() { _isSending = true; _responseMsg = null; });
    _resultCtrl.reset();

    try {
      final encodedTarget = Uri.encodeComponent(rawInput);
      final url = Uri.parse(
        '$_baseUrl/sendBug'
        '?key=$key'
        '&target=$encodedTarget'
        '&bug=$selectedBugId'
        '${_senderType == 'global' ? '&senderMode=global' : ''}',
      );

      final res  = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      if (data['valid'] == false) {
        _setResponse('error', 'Session key tidak valid. Silakan login ulang.');
      } else if (data['cooldown'] == true) {
        final wait = data['wait'] ?? 0;
        _setResponse('warning', 'Cooldown aktif! Tunggu $wait detik lagi.');
      } else if (data['sended'] == true) {
        final label = _bugMode == 'group' ? 'grup target' : rawInput;
        final role  = data['role'] ?? widget.role;
        _setResponse('success', 'Bug berhasil dikirim ke $label! [$role]');
        targetCtrl.clear();
      } else {
        _setResponse('error', 'Gagal mengirim. Server sedang maintenance.');
      }
    } on Exception catch (e) {
      if (e.toString().contains('TimeoutException')) {
        _setResponse('error', 'Request timeout. Periksa koneksi internet.');
      } else {
        _setResponse('error', 'Koneksi error. Periksa jaringan dan coba lagi.');
      }
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _setResponse(String type, String msg) {
    if (!mounted) return;
    setState(() => _responseMsg = '$type|$msg');
    _resultCtrl.forward(from: 0);
  }

  String? formatPhone(String s) {
    final c = s.replaceAll(RegExp(r'[^\d+]'), '');
    return (c.startsWith('+') && c.length >= 8) ? c : null;
  }

  bool isValidGroupLink(String s) => s.startsWith('https://') && s.contains('chat.whatsapp.com');

  void _showAlert(String title, String msg) {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black87,
      transitionDuration: const Duration(milliseconds: 300),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _C.blue.withOpacity(0.3), width: 1.5),
            boxShadow: [BoxShadow(color: _C.blue.withOpacity(0.12), blurRadius: 40)],
          ),
          padding: const EdgeInsets.all(26),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 52, height: 52,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.blue.withOpacity(0.1),
                border: Border.all(color: _C.blue.withOpacity(0.3)),
              ),
              child: const Icon(Icons.warning_amber_rounded, color: _C.blue, size: 26),
            ),
            const SizedBox(height: 14),
            Text(title, style: const TextStyle(color: _C.text, fontSize: 17, fontWeight: FontWeight.w900, fontFamily: 'ShareTechMono')),
            const SizedBox(height: 8),
            Text(msg, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70, fontSize: 13, height: 1.5, fontFamily: 'ShareTechMono')),
            const SizedBox(height: 22),
            _GradBtn(label: 'OK', fullWidth: true, onTap: () => Navigator.pop(ctx)),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: _C.bg,
      child: Stack(children: [
        Positioned.fill(child: _AnimatedBg(controller: _bgCtrl)),
        FadeTransition(
          opacity: _entrance,
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 30),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildVideoBanner(),
                const SizedBox(height: 20),
                _buildModeToggle(),
                const SizedBox(height: 24),
                if (_bugMode == 'number') ...[
                  _buildSectionHeader("TARGET NUMBER"),
                  const SizedBox(height: 10),
                  _buildTargetInput(),
                ] else ...[
                  _buildSectionHeader("TARGET GROUP LINK"),
                  const SizedBox(height: 10),
                  _buildTargetInput(),
                ],
                const SizedBox(height: 24),
                _buildSectionHeader("SELECT PAYLOAD BUG"),
                const SizedBox(height: 10),
                _buildBugSelector(),
                const SizedBox(height: 28),
                _buildSenderSectionHeader(),
                const SizedBox(height: 12),
                _buildSenderGrid(),
                const SizedBox(height: 32),
                _buildSendButton(),
                const SizedBox(height: 20),
                _buildSessionFooter(),
                if (_responseMsg != null) ...[
                  const SizedBox(height: 16),
                  _buildResultBanner(),
                ]
              ],
            ),
          ),
        ),
      ]),
    );
  }

  // ─── VIDEO BANNER DENGAN UKURAN LEBIH BESAR ───────────────────────────────
  Widget _buildVideoBanner() {
    return Container(
      width: double.infinity,
      height: 300, // Diubah dari 200 menjadi 300 untuk ukuran lebih besar
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.border, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: _C.blue.withOpacity(0.15),
            blurRadius: 30,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      clipBehavior: Clip.hardEdge,
      child: _videoReady && _chewieCtrl != null
          ? Chewie(
              controller: _chewieCtrl!,
            )
          : Container(
              color: _C.card,
              child: const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(
                      strokeWidth: 2,
                      color: _C.blue,
                    ),
                    SizedBox(height: 12),
                    Text(
                      'Memuat Banner...',
                      style: TextStyle(
                        color: Colors.white38,
                        fontSize: 12,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Text(
      title,
      style: const TextStyle(
        color: _C.blue,
        fontSize: 13,
        fontWeight: FontWeight.w900,
        fontFamily: 'ShareTechMono',
        letterSpacing: 0.5,
      ),
    );
  }

  Widget _buildModeToggle() {
    return Row(
      children: [
        Expanded(
          child: _ToggleTab(
            icon: Icons.phone_android_rounded,
            label: 'BUG NOMOR',
            active: _bugMode == 'number',
            onTap: () => setState(() { _bugMode = 'number'; targetCtrl.clear(); }),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _ToggleTab(
            icon: Icons.group_add_rounded,
            label: 'BUG GROUP',
            active: _bugMode == 'group',
            onTap: () => setState(() { _bugMode = 'group'; targetCtrl.clear(); }),
          ),
        ),
      ],
    );
  }

  Widget _buildTargetInput() {
    return Container(
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: const Color(0xFF000000),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _C.border, width: 1.5),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 24,
            height: 24,
            child: Center(
              child: Icon(
                _bugMode == 'number' 
                    ? Icons.phone_android_rounded 
                    : Icons.link_rounded,
                color: _C.blue,
                size: 20,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: TextField(
              controller: targetCtrl,
              keyboardType: _bugMode == 'number' 
                  ? TextInputType.phone 
                  : TextInputType.url,
              style: const TextStyle(
                color: Colors.white, 
                fontSize: 14, 
                fontFamily: 'ShareTechMono',
                height: 1.2,
              ),
              cursorColor: _C.blue,
              decoration: InputDecoration(
                hintText: _bugMode == 'number' 
                    ? 'e.g. +628xxxxxxxxxx' 
                    : 'https://chat.whatsapp.com/...',
                hintStyle: const TextStyle(
                  color: _C.textSub, 
                  fontSize: 14, 
                  fontFamily: 'ShareTechMono',
                  height: 1.2,
                ),
                border: InputBorder.none,
                contentPadding: EdgeInsets.zero,
                isDense: true,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBugSelector() {
    return Container(
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: const Color(0xFF000000),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _C.border, width: 1.5),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: selectedBugId.isNotEmpty ? selectedBugId : null,
          isExpanded: true,
          dropdownColor: _C.card,
          icon: const Icon(Icons.arrow_drop_down_rounded, color: _C.blue, size: 24),
          style: const TextStyle(color: Colors.white, fontSize: 13, fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold),
          items: widget.listBug.map((bug) {
            return DropdownMenuItem<String>(
              value: bug['bug_id'],
              child: Row(
                children: [
                  const Icon(Icons.cancel_outlined, color: Colors.white60, size: 16),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      bug['bug_name'].toString().toUpperCase(),
                      style: const TextStyle(color: Colors.white, overflow: TextOverflow.ellipsis),
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
          onChanged: (v) => setState(() => selectedBugId = v ?? ''),
        ),
      ),
    );
  }

  Widget _buildSenderSectionHeader() {
    return Row(
      children: [
        const Icon(Icons.swap_horiz_rounded, color: _C.blue, size: 18),
        const SizedBox(width: 8),
        const Text(
          "SENDER MODE",
          style: TextStyle(
            color: _C.blue,
            fontSize: 13,
            fontWeight: FontWeight.w900,
            fontFamily: 'ShareTechMono',
            letterSpacing: 0.5,
          ),
        ),
        const Spacer(),
        GestureDetector(
          onTap: _loadGlobalSenders,
          child: _isLoadingSenders
              ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 1.5, color: _C.blue))
              : const Icon(Icons.refresh_rounded, color: Colors.white38, size: 16),
        ),
      ],
    );
  }

  Widget _buildSenderGrid() {
    return Row(
      children: [
        Expanded(
          child: _SenderBox(
            title: "PRIVATE",
            subtitle: "0 Active",
            active: _senderType == 'private',
            onTap: () => setState(() => _senderType = 'private'),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _SenderBox(
            title: "GLOBAL",
            subtitle: _isLoadingSenders ? "Loading..." : "${_globalSenders.length} Active",
            active: _senderType == 'global',
            onTap: () {
              if (!canAccessGlobalSender) {
                _showAlert('Akses Ditolak', 'Sender Global hanya untuk Admin!');
                return;
              }
              setState(() => _senderType = 'global');
              _loadGlobalSenders();
            },
          ),
        ),
      ],
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _sendBtnCtrl,
      builder: (_, __) => GestureDetector(
        onTap: _isSending ? null : _sendBug,
        child: Transform.scale(
          scale: _isSending ? 1.0 : _sendPulse.value,
          child: Container(
            height: 56,
            width: double.infinity,
            decoration: BoxDecoration(
              gradient: _C.btnGrad,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: _C.blue.withOpacity(_isSending ? 0.2 : _sendGlow.value * 0.45),
                  blurRadius: 20,
                  offset: const Offset(0, 4),
                )
              ],
            ),
            child: Stack(
              children: [
                if (_isSending)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: AnimatedBuilder(
                      animation: _waveCtrl,
                      builder: (_, __) => CustomPaint(
                        painter: _WavePainter(_waveCtrl.value),
                        size: const Size(double.infinity, 56),
                      ),
                    ),
                  ),
                Center(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 200),
                    child: _isSending
                        ? const Row(
                            key: ValueKey('sending'),
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2.2, color: Colors.white)),
                              const SizedBox(width: 12),
                              Text('ATTACKING...', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'ShareTechMono', letterSpacing: 1)),
                            ],
                          )
                        : const Row(
                            key: ValueKey('idle'),
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 18),
                              SizedBox(width: 10),
                              Text('LAUNCH ATTACK', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 14, fontFamily: 'ShareTechMono', letterSpacing: 1)),
                            ],
                          ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSessionFooter() {
    return const Center(
      child: Text(
        "Session: 99999-09-99",
        style: TextStyle(
          color: Color(0xFF595455),
          fontSize: 11,
          fontFamily: 'ShareTechMono',
        ),
      ),
    );
  }

  Widget _buildResultBanner() {
    if (_responseMsg == null) return const SizedBox();
    final parts = _responseMsg!.split('|');
    final type  = parts[0];
    final msg   = parts.length > 1 ? parts[1] : '';

    Color color;
    IconData icon;
    switch (type) {
      case 'success': color = _C.green;   icon = Icons.check_circle_rounded; break;
      case 'warning': color = _C.amber;   icon = Icons.warning_rounded; break;
      default:        color = _C.red;     icon = Icons.error_rounded;
    }

    return FadeTransition(
      opacity: _resultFade,
      child: SlideTransition(
        position: _resultSlide,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withOpacity(0.4)),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: color, size: 18),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(type == 'success' ? 'SUCCESS' : type == 'warning' ? 'WARNING' : 'FAILED', style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: 'ShareTechMono')),
                    const SizedBox(height: 4),
                    Text(msg, style: const TextStyle(color: Colors.white70, fontSize: 12, height: 1.4, fontFamily: 'ShareTechMono')),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () { setState(() => _responseMsg = null); _resultCtrl.reset(); },
                child: const Icon(Icons.close_rounded, color: Colors.white30, size: 16),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── KOMPONEN PENDUKUNG ──────────────────────────────────────────────────────

class _ToggleTab extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;

  const _ToggleTab({required this.icon, required this.label, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: const Color(0xFF000000),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: active ? _C.blue : _C.border, width: 1.5),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 16, color: active ? _C.blue : Colors.white38),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: active ? _C.blue : Colors.white38,
                fontSize: 13,
                fontWeight: FontWeight.w900,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SenderBox extends StatelessWidget {
  final String title;
  final String subtitle;
  final bool active;
  final VoidCallback onTap;

  const _SenderBox({required this.title, required this.subtitle, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: const Color(0xFF000000),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: active ? _C.blue : _C.border, width: 1.5),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title,
              style: TextStyle(
                color: active ? _C.blue : Colors.white70,
                fontSize: 13,
                fontWeight: FontWeight.w900,
                fontFamily: 'ShareTechMono',
                letterSpacing: 0.5,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: const TextStyle(
                color: Colors.white38,
                fontSize: 11,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _WavePainter extends CustomPainter {
  final double t;
  _WavePainter(this.t);
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white.withOpacity(0.08)..style = PaintingStyle.fill;
    final path = Path(); path.moveTo(0, size.height);
    for (double x = 0; x <= size.width; x++) {
      final y = size.height * 0.5 + math.sin((x / size.width * 4 * math.pi) + (t * math.pi * 2)) * size.height * 0.15;
      path.lineTo(x, y);
    }
    path.lineTo(size.width, size.height); path.close(); canvas.drawPath(path, paint);
  }
  @override
  bool shouldRepaint(_WavePainter old) => old.t != t;
}

class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) => CustomPaint(painter: _BgPainter(controller.value)),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = const Color(0xFF1A0507).withOpacity(0.15)..strokeWidth = 0.5;
    const step = 40.0;
    for (double x = 0; x < size.width; x += step) canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    for (double y = 0; y < size.height; y += step) canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    final glow = Paint()..shader = RadialGradient(colors: [_C.blue.withOpacity(0.04), Colors.transparent], radius: 0.8).createShader(Rect.fromCircle(center: Offset(size.width / 2, 0), radius: size.width));
    canvas.drawCircle(Offset(size.width / 2, 0), size.width, glow);
  }
  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}

class _GradBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final bool fullWidth;
  const _GradBtn({required this.label, required this.onTap, this.fullWidth = false});
  @override
  State<_GradBtn> createState() => _GradBtnState();
}

class _GradBtnState extends State<_GradBtn> {
  bool _down = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) { setState(() => _down = false); widget.onTap(); },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.96 : 1.0, duration: const Duration(milliseconds: 120),
        child: Container(
          height: 46, width: widget.fullWidth ? double.infinity : null,
          decoration: BoxDecoration(gradient: _C.btnGrad, borderRadius: BorderRadius.circular(12)),
          child: Center(child: Text(widget.label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'ShareTechMono'))),
        ),
      ),
    );
  }
}