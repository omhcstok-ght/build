// dashboard_page.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';

import 'admin_page.dart';
import 'partner_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'tools_gateway.dart';
import 'public_chat_page.dart'; // IMPORT PUBLIC CHAT PAGE

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? _profileImage;

  int _bottomNavIndex = 0;
  int _whatsappSubIndex = 0; // State internal untuk navigasi sub-menu WhatsApp
  Widget _selectedPage = const Placeholder();

  int onlineUsers = 0;
  int activeConnections = 0;

  // ===== 100% MATCH DARKVERSE COLOR PALETTE =====
  final Color bgDark        = const Color(0xFF000000);
  final Color primarySilver = const Color(0xFF0A0203); 
  final Color accentSilver  = const Color(0xFFFF0033); 
  final Color lightSilver   = const Color(0xFFED001E); 
  final Color primaryWhite  = Colors.white;
  final Color accentGrey    = const Color(0xFF1F080A); 
  final Color cardGlass     = const Color(0x1AFF0022);
  final Color borderGlass   = const Color(0x26FF0033);

  @override
  void initState() {
    super.initState();
    sessionKey  = widget.sessionKey;
    username    = widget.username;
    password    = widget.password;
    role        = widget.role;
    expiredDate = widget.expiredDate;
    listBug     = widget.listBug;
    listDoos    = widget.listDoos;
    newsList    = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _updateActivePage(0);
    _initAndroidIdAndConnect();
    _loadProfileImage();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() => _profileImage = File(imagePath));
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('wss://ws-dark.darkverse.my.id'));
    channel.sink.add(jsonEncode({"type": "stats"}));
    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers        = data['onlineUsers'] ?? 0;
          activeConnections  = data['activeConnections'] ?? 0;
        });
      }
    }, onError: (e) => debugPrint("WS error: $e"));
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _onBottomNavTapped(int index) {
    setState(() {
      _bottomNavIndex = index;
      if (index != 1) {
        _whatsappSubIndex = 0; // Reset sub-menu jika berpindah tab lain
      }
      _updateActivePage(index);
    });
  }

  void _updateActivePage(int index) {
    switch (index) {
      case 0:
        _selectedPage = _buildHomePage();
        break;
      case 1:
        _selectedPage = _buildWhatsAppMenuPage();
        break;
      case 2:
        _selectedPage = InfoPage(sessionKey: sessionKey);
        break;
      case 3:
        _selectedPage = ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos);
        break;
      case 4:
        _selectedPage = PublicChatPage(
          sessionKey: sessionKey,
          username: username,
          role: role,
        );
        break;
    }
  }

  // Komponen Sub-Menu WhatsApp agar AppBar dan BottomNav tetap terjaga utuh
  Widget _buildWhatsAppMenuPage() {
    if (_whatsappSubIndex == 1) {
      return HomePage(
        username: username,
        password: password,
        sessionKey: sessionKey,
        listBug: listBug,
        role: role,
        expiredDate: expiredDate,
      );
    }

    return Container(
      color: bgDark,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 30),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "WHATSAPP PANEL",
            style: TextStyle(
              color: accentSilver,
              fontSize: 14,
              fontWeight: FontWeight.w900,
              fontFamily: 'Orbitron',
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            "Select specialized modules to execute actions",
            style: TextStyle(color: Colors.white38, fontSize: 12, fontFamily: 'ShareTechMono'),
          ),
          const SizedBox(height: 24),
          
          // Tombol 1: WhatsApp Crash
          GestureDetector(
            onTap: () {
              setState(() {
                _whatsappSubIndex = 1;
                _updateActivePage(1);
              });
            },
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFF0A0203),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: const Color(0xFF1F080A), width: 1.5),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: accentSilver.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(FontAwesomeIcons.whatsapp, color: accentSilver, size: 24),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "WHATSAPP CRASH",
                          style: TextStyle(color: primaryWhite, fontSize: 15, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
                        ),
                        const SizedBox(height: 4),
                        const Text(
                          "Launch automated payload bug parameters",
                          style: TextStyle(color: Colors.white54, fontSize: 11, fontFamily: 'ShareTechMono'),
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white30, size: 16),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 14),
          
          // Tombol 2: Manage Sender
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => BugSenderPage(
                    sessionKey: sessionKey, 
                    username: username, 
                    role: role,
                  ),
                ),
              );
            },
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFF0A0203),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: const Color(0xFF1F080A), width: 1.5),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.05),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.cell_tower_rounded, color: Colors.white60, size: 24),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "MANAGE SENDER",
                          style: TextStyle(color: primaryWhite, fontSize: 15, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
                        ),
                        const SizedBox(height: 4),
                        const Text(
                          "Configure personal device client gateway",
                          style: TextStyle(color: Colors.white54, fontSize: 11, fontFamily: 'ShareTechMono'),
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white30, size: 16),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _onSidebarTabSelected(int index) {
    setState(() {
      if (index == 1) _selectedPage = SellerPage(keyToken: sessionKey);
      else if (index == 2) _selectedPage = AdminPage(sessionKey: sessionKey);
      else if (index == 3) _selectedPage = PartnerPage(sessionKey: sessionKey, username: username);
      else if (index == 4) _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
    });
    Navigator.pop(context);
  }

  Widget _buildHomePage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 10),
          _sectionPad(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
              decoration: BoxDecoration(
                color: const Color(0xFF0A0203),
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: const Color(0xFF1F080A), width: 1.5),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    width: 68, height: 68,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: accentSilver, width: 2),
                    ),
                    child: _profileImage != null
                        ? ClipOval(child: Image.file(_profileImage!, fit: BoxFit.cover))
                        : const Icon(Icons.account_circle_rounded, color: Colors.white54, size: 40),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(username.toUpperCase(),
                          style: TextStyle(
                            color: primaryWhite, fontSize: 22,
                            fontWeight: FontWeight.bold, fontFamily: 'Orbitron',
                            letterSpacing: 1,
                          )),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                          decoration: BoxDecoration(
                            color: const Color(0xFF140506),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: const Color(0xFF1F080A)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(role.toUpperCase(),
                                style: TextStyle(
                                  color: accentSilver, fontSize: 11,
                                  fontWeight: FontWeight.w900, fontFamily: 'Orbitron',
                                  letterSpacing: 0.5,
                                )),
                              const SizedBox(height: 2),
                              Text(expiredDate,
                                style: const TextStyle(
                                  color: Colors.white38, fontSize: 11, 
                                  fontFamily: 'ShareTechMono'
                                )),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _buildHeaderStatusIndicator("ONLINE", true),
                      const SizedBox(height: 12),
                      _buildHeaderStatusIndicator("LINKED", false),
                    ],
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          if (newsList != null && newsList.isNotEmpty)
            _sectionPad(
              child: SizedBox(
                height: 220,
                child: PageView.builder(
                  controller: PageController(viewportFraction: 1.0),
                  itemCount: newsList.length,
                  itemBuilder: (ctx, i) {
                    final item = newsList[i];
                    return Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(28),
                        color: const Color(0xFF0A0203),
                        border: Border.all(color: const Color(0xFF1F080A), width: 1.5),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(28),
                        child: Stack(fit: StackFit.expand, children: [
                          if (item['image'] != null && item['image'].toString().isNotEmpty)
                            NewsMedia(url: item['image']),
                          Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.black.withOpacity(0.95),
                                  Colors.black.withOpacity(0.3),
                                  Colors.transparent,
                                ],
                                begin: Alignment.bottomCenter,
                                end: Alignment.topCenter,
                              ),
                            ),
                          ),
                          Positioned(
                            top: 18, left: 18,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                              decoration: BoxDecoration(
                                color: const Color(0xFF1F080A),
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: accentSilver.withOpacity(0.5)),
                              ),
                              child: const Text(
                                "NEWS",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 1,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            bottom: 20, left: 20, right: 20,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(item['title'] ?? '',
                                  style: TextStyle(
                                    color: primaryWhite, fontSize: 18,
                                    fontFamily: 'Orbitron', fontWeight: FontWeight.bold,
                                    shadows: [Shadow(color: Colors.black.withOpacity(0.9), blurRadius: 8)],
                                  )),
                                const SizedBox(height: 6),
                                Text(item['desc'] ?? '',
                                  style: const TextStyle(color: Colors.white54, fontSize: 12),
                                  maxLines: 1, overflow: TextOverflow.ellipsis),
                                const SizedBox(height: 10),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      width: 8, height: 4,
                                      decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)),
                                    ),
                                    const SizedBox(width: 4),
                                    Container(
                                      width: 20, height: 4,
                                      decoration: BoxDecoration(color: accentSilver, borderRadius: BorderRadius.circular(2)),
                                    ),
                                    const SizedBox(width: 4),
                                    Container(
                                      width: 8, height: 4,
                                      decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)),
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ),
                        ]),
                      ),
                    );
                  },
                ),
              ),
            ),

          const SizedBox(height: 20),

          _sectionPad(
            child: GestureDetector(
              onTap: () => _openUrl("https://t.me/ProjectHoxten"),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 18),
                decoration: BoxDecoration(
                  color: const Color(0xFF0A0203),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: const Color(0xFF1F080A), width: 1.5),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(FontAwesomeIcons.telegram, color: accentSilver, size: 20),
                    const SizedBox(width: 12),
                    Text(
                      "Join Channel",
                      style: TextStyle(
                        color: accentSilver,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _buildHeaderStatusIndicator(String label, bool isOnline) {
    return Container(
      width: 76,
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF000000),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF1F080A)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (isOnline)
                Container(
                  width: 6, height: 6,
                  decoration: const BoxDecoration(color: Colors.green, shape: BoxShape.circle),
                )
              else
                Icon(Icons.link_rounded, color: accentSilver, size: 10),
              const SizedBox(width: 6),
              Icon(Icons.crop_square_sharp, color: primaryWhite, size: 14),
            ],
          ),
          const SizedBox(height: 6),
          Text(label,
            style: const TextStyle(
              color: Colors.white30, fontSize: 9, 
              fontWeight: FontWeight.bold, fontFamily: 'Orbitron', letterSpacing: 0.5
            )),
        ],
      ),
    );
  }

  Widget _sectionPad({required Widget child}) =>
      Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: child);

  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: bgDark,
      child: SafeArea(
        child: Column(children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primarySilver.withOpacity(0.3), bgDark],
                begin: Alignment.topCenter, end: Alignment.bottomCenter,
              ),
            ),
            child: Row(children: [
              Container(
                width: 56, height: 56,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: accentSilver),
                ),
                child: _profileImage != null
                    ? ClipOval(child: Image.file(_profileImage!, fit: BoxFit.cover))
                    : const Icon(Icons.person_rounded, color: Colors.white54, size: 30),
              ),
              const SizedBox(width: 14),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(username,
                    style: TextStyle(
                      color: primaryWhite, fontWeight: FontWeight.bold,
                      fontSize: 16, fontFamily: 'Orbitron',
                    )),
                  const SizedBox(height: 4),
                  Text(role.toUpperCase(), style: TextStyle(color: accentSilver, fontSize: 11, fontFamily: 'Orbitron')),
                ],
              )),
            ]),
          ),
          Expanded(
            child: ListView(children: [
              _buildDrawerMenuItem(
                icon: Icons.headset_mic_outlined,
                label: "Customer Service",
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(context, MaterialPageRoute(builder: (_) => ContactPage()));
                },
              ),
              _buildDrawerMenuItem(
                icon: FontAwesomeIcons.userCircle,
                label: "My Profile",
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ProfilePage(
                        username: username, password: password,
                        role: role, expiredDate: expiredDate, sessionKey: sessionKey,
                      ),
                    ),
                  );
                },
              ),
              if (role == 'seller' || role == 'reseller')
                _buildDrawerMenuItem(
                  icon: Icons.storefront_rounded,
                  label: "Seller Page",
                  onTap: () => _onSidebarTabSelected(1),
                ),
              if (role == 'admin')
                _buildDrawerMenuItem(
                  icon: Icons.admin_panel_settings_rounded,
                  label: "Admin Page",
                  onTap: () => _onSidebarTabSelected(2),
                ),
              if (role == 'partner')
                _buildDrawerMenuItem(
                  icon: Icons.handshake_rounded,
                  label: "Partner Page",
                  onTap: () => _onSidebarTabSelected(3),
                ),
              if (role == 'owner')
                _buildDrawerMenuItem(
                  icon: Icons.workspace_premium_rounded,
                  label: "Owner Page",
                  onTap: () => _onSidebarTabSelected(4),
                ),
              _buildDrawerMenuItem(
                icon: Icons.history_rounded,
                label: "Riwayat Aktivitas",
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(context, MaterialPageRoute(
                    builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role),
                  ));
                },
              ),
              _buildDrawerMenuItem(
                icon: Icons.lock_outline_rounded,
                label: "Ganti Password",
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(context, MaterialPageRoute(
                    builder: (_) => ChangePasswordPage(username: username, sessionKey: sessionKey),
                  ));
                },
              ),
              const SizedBox(height: 8),
              _buildDrawerMenuItem(
                icon: Icons.logout_rounded,
                label: "Log Out",
                isLogout: true,
                onTap: () async {
                  Navigator.pop(context);
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.clear();
                  if (!mounted) return;
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
                  );
                },
              ),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _buildDrawerMenuItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    final color = isLogout ? Colors.redAccent : primaryWhite;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      decoration: BoxDecoration(
        color: isLogout ? Colors.red.withOpacity(0.1) : const Color(0xFF0A0203),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: isLogout ? Colors.red.withOpacity(0.4) : const Color(0xFF1F080A)),
      ),
      child: ListTile(
        leading: Icon(icon, color: isLogout ? Colors.redAccent : accentSilver, size: 20),
        title: Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 14)),
        trailing: const Icon(Icons.arrow_forward_ios, color: Colors.white24, size: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        dense: true,
        onTap: onTap,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      extendBodyBehindAppBar: false,
      appBar: AppBar(
        title: const Text("TRAMSXVLOID",
          style: TextStyle(
            color: Colors.white, fontWeight: FontWeight.bold,
            fontSize: 22, fontFamily: 'Orbitron', letterSpacing: 1,
          )),
        centerTitle: true,
        backgroundColor: bgDark,
        elevation: 0,
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.notes, color: Color(0xFFFF0033)), 
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.headset, color: Colors.white),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ContactPage())),
          ),
          IconButton(
            icon: const Icon(Icons.account_circle_outlined, color: Colors.white),
            onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => ProfilePage(
                username: username, password: password, role: role, expiredDate: expiredDate, sessionKey: sessionKey,
              )),
            ),
          ),
        ],
      ),
      drawer: _buildCustomDrawer(),
      body: Container(
        color: bgDark,
        child: SafeArea(
          child: FadeTransition(
            opacity: _animation,
            child: _selectedPage,
          ),
        ),
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: const BoxDecoration(
          color: Color(0xFF000000),
          border: Border(top: BorderSide(color: Color(0xFF1F080A), width: 1.5)),
        ),
        child: BottomNavigationBar(
          backgroundColor: Colors.transparent,
          selectedItemColor: accentSilver,
          unselectedItemColor: const Color(0xFF423536),
          currentIndex: _bottomNavIndex,
          onTap: _onBottomNavTapped,
          elevation: 0,
          selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 10, fontFamily: 'Orbitron'),
          unselectedLabelStyle: const TextStyle(fontSize: 10, fontFamily: 'Orbitron'),
          type: BottomNavigationBarType.fixed,
          items: [
            BottomNavigationBarItem(
              icon: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                decoration: _bottomNavIndex == 0 ? BoxDecoration(
                  color: const Color(0xFF1C0507), borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: accentSilver.withOpacity(0.4))
                ) : null,
                child: const Icon(Icons.home_filled),
              ),
              label: "Home",
            ),
            BottomNavigationBarItem(
              icon: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                decoration: _bottomNavIndex == 1 ? BoxDecoration(
                  color: const Color(0xFF1C0507), borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: accentSilver.withOpacity(0.4))
                ) : null,
                child: const Icon(FontAwesomeIcons.whatsapp),
              ),
              label: "WhatsApp",
            ),
            BottomNavigationBarItem(
              icon: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                decoration: _bottomNavIndex == 2 ? BoxDecoration(
                  color: const Color(0xFF1C0507), borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: accentSilver.withOpacity(0.4))
                ) : null,
                child: const Icon(Icons.notifications_sharp),
              ),
              label: "Info",
            ),
            BottomNavigationBarItem(
              icon: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                decoration: _bottomNavIndex == 3 ? BoxDecoration(
                  color: const Color(0xFF1C0507), borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: accentSilver.withOpacity(0.4))
                ) : null,
                child: const Icon(Icons.grid_view_rounded),
              ),
              label: "Tools",
            ),
            BottomNavigationBarItem(
              icon: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                decoration: _bottomNavIndex == 4 ? BoxDecoration(
                  color: const Color(0xFF1C0507), borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: accentSilver.withOpacity(0.4))
                ) : null,
                child: const Icon(Icons.public_rounded),
              ),
              label: "Chat",
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _controller.dispose();
    super.dispose();
  }
}

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});
  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) =>
      url.endsWith('.mp4') || url.endsWith('.webm') ||
      url.endsWith('.mov') || url.endsWith('.mkv');

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      }
      return const Center(child: CircularProgressIndicator(color: Color(0xFFFF0033)));
    }
    return Image.network(
      widget.url, fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        color: const Color(0xFF0A0203),
        child: const Icon(Icons.error, color: Color(0xFFFF0033)),
      ),
    );
  }
}