import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_page.dart';

class _C {
  static const bg        = Color(0xFF000000);
  static const textWhite = Color(0xFFFFFFFF);
}

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late VideoPlayerController _videoCtrl;
  bool _videoReady = false;

  late AnimationController _uiCtrl;
  late Animation<double> _uiFade;

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _initVideo();
    
    // FORCE NAVIGATE AFTER 5 SECONDS (BACKUP)
    Future.delayed(const Duration(seconds: 5), () {
      if (mounted) _navigate();
    });
  }

  void _initAnimations() {
    _uiCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));
    _uiFade = CurvedAnimation(parent: _uiCtrl, curve: Curves.easeOut);
  }

  void _initVideo() {
    _videoCtrl = VideoPlayerController.asset('assets/videos/splash.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => _videoReady = true);
        _videoCtrl.setLooping(true);
        _videoCtrl.play();

        Future.delayed(const Duration(milliseconds: 200), () {
          if (mounted) {
            _uiCtrl.forward();
          }
        });
        
        // Navigate after video loads + 2 seconds
        Future.delayed(const Duration(seconds: 3), () {
          if (mounted) _navigate();
        });
      }).catchError((_) {
        if (mounted) {
          setState(() => _videoReady = false);
          _uiCtrl.forward();
          // Navigate immediately if video fails
          Future.delayed(const Duration(milliseconds: 500), () {
            if (mounted) _navigate();
          });
        }
      });
  }

  void _navigate() {
    if (!mounted) return;
    try {
      Navigator.of(context).pushReplacementNamed(
        '/dashboard',
        arguments: {
          'username': widget.username,
          'password': widget.password,
          'role': widget.role,
          'key': widget.sessionKey,
          'expiredDate': widget.expiredDate,
          'listBug': widget.listBug,
          'listDoos': widget.listDoos,
          'news': widget.news,
        },
      );
    } catch (e) {
      debugPrint("ERROR NAVIGATING: $e");
      // Fallback: pake MaterialPageRoute langsung
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => DashboardPage(
            username: widget.username,
            password: widget.password,
            role: widget.role,
            expiredDate: widget.expiredDate,
            sessionKey: widget.sessionKey,
            listBug: widget.listBug,
            listDoos: widget.listDoos,
            news: widget.news,
          ),
        ),
      );
    }
  }

  void _skipSplash() => _navigate();

  @override
  void dispose() {
    _videoCtrl.dispose();
    _uiCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // 1. Background Video Fullscreen Cover
          if (_videoReady)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoCtrl.value.size.width,
                  height: _videoCtrl.value.size.height,
                  child: VideoPlayer(_videoCtrl),
                ),
              ),
            ),
          
          // Layer overlay gelap tipis agar teks tetap terbaca jernih jika video terlalu terang
          Positioned.fill(
            child: Container(
              color: Colors.black.withOpacity(_videoReady ? 0.15 : 0.0),
            ),
          ),

          // 2. Tombol Skip Oval Transparan di Kanan Atas (Sesuai Gambar)
          Positioned(
            top: 24,
            right: 20,
            child: FadeTransition(
              opacity: _uiFade,
              child: GestureDetector(
                onTap: _skipSplash,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.18),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.white.withOpacity(0.25), width: 1),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Skip',
                        style: TextStyle(
                          color: _C.textWhite,
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          letterSpacing: 0.5,
                        ),
                      ),
                      SizedBox(width: 4),
                      Icon(Icons.play_arrow_rounded, color: _C.textWhite, size: 14),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // 3. Teks Judul DARKVERSE di Bagian Bawah (Sesuai Gambar)
          Positioned(
            bottom: 70,
            left: 0,
            right: 0,
            child: FadeTransition(
              opacity: _uiFade,
              child: const Center(
                child: Text(
                  'TRAMSXVLOID',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: _C.textWhite,
                    letterSpacing: 7,
                    fontFamily: 'ShareTechMono', // Mengikuti tema font mono dashboard
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
