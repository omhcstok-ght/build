import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class InfoPage extends StatefulWidget {
  final String sessionKey;

  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> with SingleTickerProviderStateMixin {
  // --- State Data ---
  Map<String, dynamic>? serverInfo;
  bool isLoading = true;

  // API Status State
  bool isApiOnline = false;
  int apiPingMs = 0;
  Color apiStatusColor = Colors.grey;
  String apiStatusText = "Checking...";
  Timer? _pingTimer;

  // --- TEMA WARNA MERAH (TRAMSXVLOID Style) ---
  final Color bgDark = const Color(0xFF0A0A0A); // Hitam Pekat
  final Color cardBg = const Color(0xFF141414); // Abu Sangat Gelap
  final Color borderRed = const Color(0xFFCC0000); // Merah Utama
  final Color accentRed = const Color(0xFFFF3333); // Merah Terang
  final Color textRed = const Color(0xFFFF1744); // Merah untuk teks
  final Color whiteText = Colors.white;
  final Color grayText = Colors.grey.shade500;

  late AnimationController _glowCtrl;
  late Animation<double> _glowAnim;

  @override
  void initState() {
    super.initState();
    _fetchServerInfo();
    _startApiPingLoop();

    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.3, end: 0.8).animate(
      CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    _glowCtrl.dispose();
    super.dispose();
  }

  Future<void> _fetchServerInfo() async {
    try {
      final res = await http.get(
        Uri.parse('https://syahmishop.zhaher.my.id:2775/getServerInfo?key=${widget.sessionKey}'),
      );
      if (res.statusCode == 200) {
        setState(() {
          serverInfo = jsonDecode(res.body);
          isLoading = false;
        });
      } else {
        setState(() => isLoading = false);
      }
    } catch (e) {
      setState(() => isLoading = false);
    }
  }

  void _startApiPingLoop() {
    _checkApiPing();
    _pingTimer = Timer.periodic(const Duration(seconds: 5), (_) => _checkApiPing());
  }

  Future<void> _checkApiPing() async {
    final start = DateTime.now();
    try {
      final res = await http.get(
        Uri.parse('https://syahmishop.zhaher.my.id:2775/ping?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 3));

      final end = DateTime.now();
      final duration = end.difference(start).inMilliseconds;

      if (res.statusCode == 200) {
        setState(() {
          isApiOnline = true;
          apiPingMs = duration;
          apiStatusColor = duration < 300 ? Colors.greenAccent : Colors.amber;
          apiStatusText = "Online (${duration}ms)";
        });
      } else {
        throw Exception("Failed");
      }
    } catch (e) {
      setState(() {
        isApiOnline = false;
        apiPingMs = 0;
        apiStatusColor = Colors.redAccent;
        apiStatusText = "Offline";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        backgroundColor: bgDark,
        body: const Center(
          child: CircularProgressIndicator(color: Color(0xFFFF1744)),
        ),
      );
    }

    return Scaffold(
      backgroundColor: bgDark,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ─── HEADER: EULAS SYSTEMINFO ──────────────────────────────
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'EULAS SYSTEMINFO',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.5,
                    ),
                  ),
                  _buildStatusPing(),
                ],
              ),
              const SizedBox(height: 24),

              // ─── USERPROTOCOLS HEADER ──────────────────────────────────
              Row(
                children: [
                  Container(
                    width: 4,
                    height: 20,
                    decoration: BoxDecoration(
                      color: accentRed,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    'USERPROTOCOLS',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // ─── RULES CARDS ────────────────────────────────────────────
              _buildRuleCard(
                number: '01',
                title: 'NO ACCOUNT BARTERING',
                description:
                    'Akun eksklusif TRAMSXVLOID tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun.\nPelanggaran log akan terpantau.',
              ),
              const SizedBox(height: 14),

              _buildRuleCard(
                number: '02',
                title: 'STRICTLY PERSONAL USE',
                description:
                    'Setiap akun terenkripsi untuk satu pengguna dan hanya boleh diakses oleh pemilik perangkat yang mendaftar (terikat Device ID).',
              ),
              const SizedBox(height: 14),

              _buildRuleCard(
                number: '03',
                title: 'RESELLING PROHIBITED',
                description:
                    'Member reguler dilarang menjual akun. Penjualan akun hanya boleh dilakukan oleh role yang diizinkan secara resmi.',
              ),
              const SizedBox(height: 24),

              // ─── FOOTER DIVIDER ─────────────────────────────────────────
              Container(
                height: 1,
                width: double.infinity,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.transparent, accentRed.withOpacity(0.5), Colors.transparent],
                  ),
                ),
              ),
              const SizedBox(height: 16),

              Center(
                child: Text(
                  'DARKVERSE © 2026 • ALL RIGHTS RESERVED',
                  style: TextStyle(
                    color: grayText,
                    fontSize: 10,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatusPing() {
    return AnimatedBuilder(
      animation: _glowAnim,
      builder: (_, __) {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: apiStatusColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: apiStatusColor.withOpacity(_glowAnim.value),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: apiStatusColor.withOpacity(_glowAnim.value * 0.3),
                blurRadius: 12,
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: apiStatusColor,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: apiStatusColor.withOpacity(0.8),
                      blurRadius: 8,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Text(
                'SYS.ONLINE::${apiPingMs}ms',
                style: TextStyle(
                  color: apiStatusColor,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildRuleCard({
    required String number,
    required String title,
    required String description,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: borderRed.withOpacity(0.3),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: borderRed.withOpacity(0.05),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: accentRed.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: accentRed.withOpacity(0.3)),
                ),
                child: Text(
                  number,
                  style: TextStyle(
                    color: accentRed,
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    fontFamily: 'Orbitron',
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            description,
            style: TextStyle(
              color: grayText,
              fontSize: 12,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}