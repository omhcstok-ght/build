import 'dart:ui';
import 'package:flutter/material.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'phone_lookup.dart';
import 'snake_game.dart';
import 'game_2048.dart';
import 'text_tools.dart';
import 'fake_identity.dart';
import 'plat_nomor.dart';
import 'converter_page.dart';
import 'url_shortener.dart';
import 'typosquat_checker.dart';
import 'speed_test.dart';
import 'whois_page.dart';

class ToolsPage extends StatelessWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  // ===== WARNA PREMIUM SESUAI SCREENSHOT =====
  static const Color bgDark       = Color(0xFF000000); // Hitam Pekat murni latar belakang
  static const Color cardDark     = Color(0xFF0A0506); // Background Card Merah Gelap Sangat Tua
  static const Color accentRed     = Color(0xFFDC143C); // Merah Crimson Terang Utama
  static const Color mutedRed     = Color(0xFF220A0C); // Border / Background container kecil merah redup
  static const Color textGray     = Color(0xFF6B6667); // Teks sekunder abu-abu bawaan screenshot
  static const Color textWhite    = Color(0xFFE5E5E5);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: SafeArea(
        child: Column(
          children: [
            // ── DASHBOARD HEADER ───────────────────────────────────────
            Container(
              width: double.infinity,
              margin: const EdgeInsets.only(left: 16, right: 16, top: 24, bottom: 16),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
              decoration: BoxDecoration(
                color: cardDark,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFF381215), width: 1.5),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Ikon Perisai dengan latar belakang kotak tumpul
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: const Color(0xFF250D10),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Icon(
                      Icons.shield,
                      color: accentRed,
                      size: 26,
                    ),
                  ),
                  const SizedBox(width: 20),
                  // Teks Judul Utama Dashboard
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "TOOLS\nDASHBOAR\nD",
                          style: TextStyle(
                            color: textWhite,
                            fontSize: 26,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'monospace',
                            letterSpacing: 2.0,
                            height: 1.05,
                          ),
                        ),
                        const SizedBox(height: 10),
                        const Text(
                          "Advanced Security &\nOSINT Tools",
                          style: TextStyle(
                            color: textGray,
                            fontSize: 12,
                            fontFamily: 'monospace',
                            height: 1.3,
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Tombol OWNER Kanan Atas
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFF250D10),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFF4A1A1E), width: 1),
                    ),
                    child: const Text(
                      "OWNER",
                      style: TextStyle(
                        color: accentRed,
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'monospace',
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // ── BARIS STATUS INFO (Methods, Categories, Role) ───────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Expanded(
                    child: _buildStatusCapsule(
                      icon: Icons.flash_on, 
                      label: "0 Methods"
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _buildStatusCapsule(
                      icon: Icons.category, 
                      label: "7 Catego..."
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _buildStatusCapsule(
                      icon: Icons.lock, 
                      label: "OWNER",
                      isHighlight: true
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // ── DAFTAR UTAMA LIST MENU ──
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                physics: const BouncingScrollPhysics(),
                children: [
                  _buildMainListTile(
                    icon: Icons.flash_on,
                    title: "DDoS Tools",
                    subtitle: "Attack & Server",
                    onTap: () => _showDDoSTools(context),
                  ),
                  _buildMainListTile(
                    icon: Icons.wifi,
                    title: "Network",
                    subtitle: "WiFi & Spam",
                    onTap: () => _showNetworkTools(context),
                  ),
                  _buildMainListTile(
                    icon: Icons.search,
                    title: "OSINT",
                    subtitle: "Investigation",
                    onTap: () => _showOSINTTools(context),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Widget Kapsul Info Status di bawah Header
  Widget _buildStatusCapsule({
    required IconData icon, 
    required String label, 
    bool isHighlight = false
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF2A1013), width: 1.2),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: isHighlight ? accentRed : const Color(0xFF9E1B22), size: 14),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(
              color: isHighlight ? accentRed : textWhite,
              fontSize: 10.5,
              fontWeight: FontWeight.bold,
              fontFamily: 'monospace',
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  // Widget Item Baris List Menu Utama Sesuai Gambar
  Widget _buildMainListTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF1F0D0F), width: 1.2),
      ),
      child: Theme(
        data: ThemeData(splashColor: Colors.transparent, highlightColor: Colors.transparent),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          leading: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFF1A0A0C),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: accentRed, size: 22),
          ),
          title: Text(
            title,
            style: const TextStyle(
              color: accentRed,
              fontSize: 17,
              fontWeight: FontWeight.bold,
              fontFamily: 'monospace',
              letterSpacing: 0.5,
            ),
          ),
          subtitle: Padding(
            padding: const EdgeInsets.only(top: 4.0),
            child: Text(
              subtitle,
              style: const TextStyle(
                color: textGray,
                fontSize: 12,
                fontFamily: 'monospace',
              ),
            ),
          ),
          trailing: const Icon(
            Icons.keyboard_arrow_down,
            color: Color(0xFF4E3638),
            size: 26,
          ),
          onTap: onTap,
        ),
      ),
    );
  }

  // ─── BOTTOM SHEETS STYLING ───────────────────────────────────────────────

  Widget _buildSheet(BuildContext context, String title, IconData icon, List<Widget> options) {
    return Container(
      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.75),
      decoration: const BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: mutedRed,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(24),
                topRight: Radius.circular(24),
              ),
            ),
            child: Row(
              children: [
                Icon(icon, color: accentRed),
                const SizedBox(width: 12),
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'monospace',
                  ),
                ),
              ],
            ),
          ),
          Flexible(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(children: options),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildToolOption({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Card(
      color: bgDark,
      margin: const EdgeInsets.symmetric(vertical: 6),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: const BorderSide(color: mutedRed),
      ),
      child: ListTile(
        leading: Icon(icon, color: accentRed, size: 20),
        title: Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontFamily: 'monospace',
          ),
        ),
        trailing: const Icon(Icons.arrow_forward_ios, color: textGray, size: 14),
        onTap: onTap,
      ),
    );
  }

  // ─── SHOW FUNCTIONS ───────────────────────────────────────────────────────

  void _showDDoSTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => _buildSheet(ctx, "DDoS Tools", Icons.flash_on, [
        _buildToolOption(
          icon: Icons.flash_on,
          label: "Attack Panel",
          color: accentRed,
          onTap: () {
            Navigator.pop(ctx);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AttackPanel(sessionKey: sessionKey, listDoos: listDoos),
              ),
            );
          },
        ),
        _buildToolOption(
          icon: Icons.dns,
          label: "Manage Server",
          color: accentRed,
          onTap: () {
            Navigator.pop(ctx);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ManageServerPage(keyToken: sessionKey),
              ),
            );
          },
        ),
      ]),
    );
  }

  void _showNetworkTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => _buildSheet(ctx, "Network Tools", Icons.wifi, [
        _buildToolOption(
          icon: Icons.newspaper_outlined,
          label: "Spam NGL",
          color: accentRed,
          onTap: () {
            Navigator.pop(ctx);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const NglPage()),
            );
          },
        ),
        _buildToolOption(
          icon: Icons.wifi_off,
          label: "WiFi Killer (Internal)",
          color: accentRed,
          onTap: () {
            Navigator.pop(ctx);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const WifiKillerPage()),
            );
          },
        ),
        if (userRole == "vip" || userRole == "owner")
          _buildToolOption(
            icon: Icons.router,
            label: "WiFi Killer (External)",
            color: accentRed,
            onTap: () {
              Navigator.pop(ctx);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => WifiInternalPage(sessionKey: sessionKey),
                ),
              );
            },
          ),
      ]),
    );
  }

  void _showOSINTTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => _buildSheet(ctx, "OSINT Tools", Icons.search, [
        _buildToolOption(
          icon: Icons.badge,
          label: "NIK Detail",
          color: accentRed,
          onTap: () {
            Navigator.pop(ctx);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const NikCheckerPage()),
            );
          },
        ),
        _buildToolOption(
          icon: Icons.domain,
          label: "Domain OSINT",
          color: accentRed,
          onTap: () {
            Navigator.pop(ctx);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const DomainOsintPage()),
            );
          },
        ),
        _buildToolOption(
          icon: Icons.phone_android,
          label: "Phone Lookup",
          color: accentRed,
          onTap: () {
            Navigator.pop(ctx);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const PhoneLookupPage()),
            );
          },
        ),
        _buildToolOption(
          icon: Icons.manage_search,
          label: "WHOIS Lookup",
          color: accentRed,
          onTap: () {
            Navigator.pop(ctx);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const WhoisPage()),
            );
          },
        ),
        _buildToolOption(
          icon: Icons.find_replace,
          label: "Typosquat Checker",
          color: accentRed,
          onTap: () {
            Navigator.pop(ctx);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const TyposquatPage()),
            );
          },
        ),
      ]),
    );
  }
}
