import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';

const String baseUrl = "https://syahmishop.zhaher.my.id:2775";

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with SingleTickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePassword = true;
  String? androidId;

  late AnimationController _controller;
  late Animation<double> _fadeAnim;

  // --- 100% MATCH DARKVERSE THEME COLOR PALETTE FROM SCREENSHOT ---
  final Color bgDark = const Color(0xFF000000);
  final Color bgCardDark = const Color(0xFF0F090A); // Merah Gelap Sangat Tua Pekat
  final Color borderDark = const Color(0xFF2C0A0E); // Border Merah Muted Presisi
  final Color primaryRed = const Color(0xFFE50914); // Merah Utama Terang ala TRAMSXVLOID
  final Color accentRed = const Color(0xFFE50914);
  final Color whiteText = Colors.white;
  final Color grayPlaceholder = const Color(0xFF555555);

  @override
  void initState() {
    super.initState();
    _initAnim();
    initLogin();
  }

  void _initAnim() {
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..forward();
    _fadeAnim = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
  }

  Future<void> initLogin() async {
    androidId = await getAndroidId();

    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
          "$baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey");

      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);

        if (data['valid'] == true) {
          if (mounted) {
            Navigator.pushReplacementNamed(
              context,
              '/splash',
              arguments: {
                'username': savedUser,
                'password': savedPass,
                'role': data['role'],
                'key': data['key'],
                'expiredDate': data['expiredDate'],
                'listBug': (data['listBug'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                'listDoos': (data['listDDoS'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                'news': (data['news'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
              },
            );
          }
        }
      } catch (_) {
        // Biarkan user login manual
      }
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id ?? "unknown_device";
  }

  Future<void> login() async {
    if (!_formKey.currentState!.validate()) return;

    final username = userController.text.trim();
    final password = passController.text.trim();

    setState(() => isLoading = true);

    try {
      final validate = await http.post(
        Uri.parse("$baseUrl/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      );

      final validData = jsonDecode(validate.body);

      if (validData['expired'] == true) {
        _showPopup(
          title: "⏳ Access Expired",
          message: "Masa akses Anda telah habis.\nSilakan perpanjang akses.",
          color: Colors.orange,
          showContact: true,
        );
      }
      else if (validData['valid'] != true) {
        final String errorMsg = (validData['message'] ?? "").toLowerCase();

        if (errorMsg.contains("perangkat") ||
            errorMsg.contains("device") ||
            errorMsg.contains("another")) {
          _showPopup(
            title: "⚠️ Sesi Aktif",
            message: "Akun ini sedang login di perangkat lain.\nSilakan logout terlebih dahulu di perangkat lama.",
            color: Colors.orangeAccent,
          );
        } else {
          _showPopup(
            title: "❌ Login Gagal",
            message: "Username atau password salah.",
            color: Colors.redAccent,
          );
        }
      }
      else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);

        if (mounted) {
          Navigator.pushReplacementNamed(
            context,
            '/splash',
            arguments: {
              'username': username,
              'password': password,
              'role': validData['role'],
              'key': validData['key'],
              'expiredDate': validData['expiredDate'],
              'listBug': (validData['listBug'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
              'listDoos': (validData['listDDoS'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
              'news': (validData['news'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
            },
          );
        }
      }
    } catch (e) {
      _showPopup(
        title: "⚠️ Connection Error",
        message: "Gagal terhubung ke server.\nPeriksa koneksi internet Anda.",
        color: Colors.red,
      );
    }

    setState(() => isLoading = false);
  }

  void _showPopup({
    required String title,
    required String message,
    Color color = Colors.redAccent,
    bool showContact = false,
  }) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF0F090A),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: accentRed.withOpacity(0.3)),
        ),
        title: Text(
          title,
          style: TextStyle(
              color: color, fontWeight: FontWeight.bold, fontSize: 20),
        ),
        content: Text(
          message,
          style: const TextStyle(color: Colors.white70, fontSize: 15),
        ),
        actions: [
          if (showContact)
            TextButton(
              onPressed: () async {
                await launchUrl(Uri.parse("https://t.me/xxfanz"),
                    mode: LaunchMode.externalApplication);
              },
              child: const Text(
                "Contact Admin",
                style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
              ),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              "Close",
              style: TextStyle(color: Colors.white54),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        width: double.infinity,
        height: double.infinity,
        color: bgDark,
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(height: 10),
                    // BRANDING LOGO AREA (WINGS LOGO ASSET)
                    Hero(
                      tag: "logo",
                      child: Container(
                        width: 200,
                        height: 140,
                        alignment: Alignment.center,
                        child: Image.asset(
                          'assets/images/logo.png',
                          fit: BoxFit.contain,
                          errorBuilder: (context, error, stackTrace) {
                            return Container(
                              width: 60, height: 60,
                              decoration: BoxDecoration(shape: BoxShape.circle, color: accentRed.withOpacity(0.2)),
                              child: Icon(Icons.security, color: accentRed, size: 30),
                            );
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 5),

                    // NEON DASH DIVIDER LINE SAMA SEPERTI DI GAMBAR
                    Container(
                      width: 45,
                      height: 3.5,
                      decoration: BoxDecoration(
                        color: accentRed,
                        borderRadius: BorderRadius.circular(2),
                        boxShadow: [
                          BoxShadow(
                            color: accentRed.withOpacity(0.8),
                            blurRadius: 10,
                            spreadRadius: 1,
                          )
                        ],
                      ),
                    ),
                    const SizedBox(height: 25),

                    // SUBTITLE SUB-TEXT (FONT MONO SESUAI GAMBAR)
                    const Text(
                      "Authenticate to proceed",
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: Colors.white54,
                        fontFamily: 'ShareTechMono',
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 16),

                    // MAIN INPUT CARD GLASS BLOCK
                    Form(
                      key: _formKey,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 28),
                        decoration: BoxDecoration(
                          color: bgCardDark,
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(color: borderDark, width: 1.5),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // SIGN IN LABEL HEADER (FONT DIUBAH KONTRAST FIXED DARI BLACK KE W900)
                            Text(
                              "SIGN IN",
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w900,
                                color: accentRed,
                                fontFamily: 'ShareTechMono',
                                letterSpacing: 1.0,
                              ),
                            ),
                            const SizedBox(height: 24),

                            // USERNAME FIELD WITH SECTION HEADER
                            const Text(
                              "USERNAME",
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: Colors.white38,
                                fontFamily: 'ShareTechMono',
                                letterSpacing: 0.5,
                              ),
                            ),
                            const SizedBox(height: 8),
                            _buildInput(userController, "Enter your username", Icons.person_outline_rounded),
                            
                            const SizedBox(height: 20),

                            // PASSWORD FIELD WITH SECTION HEADER
                            const Text(
                              "PASSWORD",
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: Colors.white38,
                                fontFamily: 'ShareTechMono',
                                letterSpacing: 0.5,
                              ),
                            ),
                            const SizedBox(height: 8),
                            _buildInput(passController, "Enter your password", Icons.lock_outline_rounded, true),
                            
                            const SizedBox(height: 32),
                            
                            // SUBMIT BUTTON MATCHED
                            _buildButton(),
                            
                            const SizedBox(height: 24),

                            // FOOTER NO ACCESS PURCHASE HERE LINK
                            Center(
                              child: GestureDetector(
                                onTap: () async {
                                  await launchUrl(Uri.parse("https://t.me/rangzhost"),
                                      mode: LaunchMode.externalApplication);
                                },
                                child: RichText(
                                  text: TextSpan(
                                    style: const TextStyle(fontSize: 13, fontFamily: 'ShareTechMono', letterSpacing: 0.5),
                                    children: [
                                      const TextSpan(text: "No Access? ", style: TextStyle(color: Colors.white38)),
                                      TextSpan(text: "Purchase Here", style: TextStyle(color: accentRed, fontWeight: FontWeight.bold, decoration: TextDecoration.underline)),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // WIDGET INPUT FIELD SOLID KOTAK HITAM (100% SESUAI CONTOH GAMBAR)
  Widget _buildInput(TextEditingController controller, String hint, IconData icon, [bool isPassword = false]) {
    return Container(
      height: 54,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFF000000),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: borderDark, width: 1.5),
      ),
      child: Center(
        child: TextFormField(
          controller: controller,
          obscureText: isPassword ? _obscurePassword : false,
          style: const TextStyle(color: Colors.white, fontSize: 14, fontFamily: 'ShareTechMono'),
          cursorColor: accentRed,
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(color: grayPlaceholder, fontSize: 14, fontFamily: 'ShareTechMono'),
            prefixIcon: Icon(icon, color: Colors.white38, size: 20),
            suffixIcon: isPassword
                ? IconButton(
                    icon: Icon(
                      _obscurePassword ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                      color: Colors.white38,
                      size: 20,
                    ),
                    onPressed: () {
                      setState(() {
                        _obscurePassword = !_obscurePassword;
                      });
                    },
                  )
                : null,
            border: InputBorder.none,
            focusedBorder: InputBorder.none,
            enabledBorder: InputBorder.none,
            errorBorder: InputBorder.none,
            disabledBorder: InputBorder.none,
            contentPadding: EdgeInsets.zero,
          ),
        ),
      ),
    );
  }

  // WIDGET BUTTON LOGIN GRADIENT MERAH DENGAN GLOW EFFECT BAWAH
  Widget _buildButton() {
    final double fullButtonWidth = MediaQuery.of(context).size.width;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      width: isLoading ? 54 : fullButtonWidth,
      height: 52,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [primaryRed, accentRed],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: accentRed.withOpacity(0.4),
            blurRadius: 20,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: isLoading ? null : login,
          borderRadius: BorderRadius.circular(14),
          child: Center(
            child: isLoading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  )
                : const Text(
                    "LOGIN",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'ShareTechMono',
                      letterSpacing: 1.5,
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}
