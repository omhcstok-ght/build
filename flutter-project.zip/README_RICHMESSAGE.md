MCLAREN RichMessage native build

- No config.js
- No .env
- Put BOT_TOKEN in index.js
- Native bot.sendRichMessage() and bot.sendRichMessageDraft()
- /start and menu transitions use the RichMessage loading animation
- Existing menu handlers/features are preserved
