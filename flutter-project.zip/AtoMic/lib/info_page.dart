import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// ─── NEUBRUTALISM PALETTE ─────────────────────────────────────
class _NB {
  // Background
  static const bg = Color(0xFFFFFFFF);

  // Surfaces
  static const surface = Color(0xFFF5F3FF);
  static const card = Color(0xFFFAFAFA);

  // Borders
  static const border = Color(0xFF000000);

  // Ungu (solid, not too thick)
  static const purpleMain = Color(0xFF7C3AED);
  static const purpleMid = Color(0xFF8B5CF6);
  static const purpleLight = Color(0xFFA78BFA);
  static const purplePale = Color(0xFFEDE9FE);

  // Pink (solid, not too thick)
  static const pinkMain = Color(0xFFEC4899);
  static const pinkMid = Color(0xFFF472B6);
  static const pinkLight = Color(0xFFF9A8D4);
  static const pinkPale = Color(0xFFFCE7F3);

  // Biru (solid, not too thick)
  static const blueMain = Color(0xFF3B82F6);
  static const blueMid = Color(0xFF60A5FA);
  static const blueLight = Color(0xFF93BBFC);
  static const bluePale = Color(0xFFDBEAFE);

  // Text
  static const text = Color(0xFF1A1A1A);
  static const textSub = Color(0xFF4B4B4B);
  static const textDim = Color(0xFF888888);

  // Status
  static const green = Color(0xFF059669);
  static const red = Color(0xFFDC2626);
  static const orange = Color(0xFFF59E0B);

  // Gradien
  static const LinearGradient purpleGrad = LinearGradient(
    colors: [purpleMain, purpleMid],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class InfoPage extends StatefulWidget {
  final String sessionKey;

  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> with TickerProviderStateMixin {
  bool isLoading = true;

  bool isApiOnline = false;
  int apiPingMs = 0;
  Color apiStatusColor = _NB.textDim;
  String apiStatusText = "Checking...";
  Timer? _pingTimer;

  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  // ─── FITUR ─────────────────────────────────────────────────────────────
  final List<Map<String, dynamic>> featuresList = [
    {
      "title": "WhatsApp Crash",
      "icon": Icons.bug_report_rounded,
      "color": _NB.pinkMain,
      "desc":
          "Kemampuan mengirimkan payload secara masif ke target Private (Nomor) maupun Global (Grup) dengan hit rate tinggi dan efisiensi waktu.",
    },
    {
      "title": "Bug Sender",
      "icon": Icons.devices_rounded,
      "color": _NB.purpleMain,
      "desc":
          "Pairing & konfigurasi perangkat sender untuk manajemen sesi pengiriman payload yang lebih terstruktur dan efisien.",
    },
    {
      "title": "Riwayat Aktivitas",
      "icon": Icons.history_rounded,
      "color": _NB.blueMain,
      "desc":
          "Rekam dan pantau seluruh histori aktivitas akun kamu secara real-time, lengkap dengan log pengiriman dan status operasi.",
    },
    {
      "title": "Profile & Akun",
      "icon": Icons.person_rounded,
      "color": _NB.purpleMid,
      "desc":
          "Kelola data profil, ubah password, dan pantau status akun serta masa aktif langganan kamu dengan mudah.",
    },
    {
      "title": "Global Chat",
      "icon": Icons.groups_2_rounded,
      "color": _NB.pinkMid,
      "desc":
          "Ruang komunitas eksklusif untuk berdiskusi, berbagi pengalaman, dan berinteraksi langsung dengan seluruh pengguna QUEEN PROJECT.",
    },
  ];

  // ─── KEBIJAKAN ─────────────────────────────────────────────────────
  final List<Map<String, dynamic>> rulesList = [
    {
      "title": "NO ACCOUNT BARTERING",
      "icon": Icons.swap_horizontal_circle_outlined,
      "desc":
          "Akun eksklusif QUEEN PROJECT tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun. Pelanggaran log akan terpantau.",
    },
    {
      "title": "STRICTLY PERSONAL USE",
      "icon": Icons.person_off_outlined,
      "desc":
          "Setiap akun terenkripsi untuk satu pengguna dan hanya boleh diakses oleh pemilik perangkat yang mendaftar (terikat Device ID).",
    },
    {
      "title": "RESELLING PROHIBITED",
      "icon": Icons.money_off_csred_outlined,
      "desc":
          "Member reguler dilarang memperjualbelikan akun. Akses penjualan eksklusif milik role berwenang (Partner, Owner, atau Reseller).",
    },
    {
      "title": "ILLEGAL DURATION SALES",
      "icon": Icons.timer_off_outlined,
      "desc":
          "Sangat dilarang membagi atau menjual akses eceran (harian, mingguan, trial) yang mengelabui skema periode resmi.",
    },
    {
      "title": "PRICE DUMPING BAN",
      "icon": Icons.trending_down_rounded,
      "desc":
          "Dilarang keras merusak standar harga pasar (banting harga) di bawah kesepakatan jaminan keamanan platform kami.",
    },
  ];

  // ──────────────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
        vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.2, end: 1.0).animate(
        CurvedAnimation(parent: _glowController, curve: Curves.easeInOut));
    _fetchServerInfo();
    _startApiPingLoop();
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    _glowController.dispose();
    super.dispose();
  }

  Future<void> _fetchServerInfo() async {
    try {
      await http.get(Uri.parse(
          'http://api.babehmodss-vvip.my.id:2046/getServerInfo?key=${widget.sessionKey}'));
      if (mounted) setState(() => isLoading = false);
    } catch (_) {
      if (mounted) setState(() => isLoading = false);
    }
  }

  void _startApiPingLoop() {
    _checkApiPing();
    _pingTimer =
        Timer.periodic(const Duration(seconds: 5), (_) => _checkApiPing());
  }

  Future<void> _checkApiPing() async {
    final start = DateTime.now();
    try {
      final res = await http
          .get(Uri.parse(
              'http://api.babehmodss-vvip.my.id:2046/ping?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 3));
      final duration = DateTime.now().difference(start).inMilliseconds;
      if (res.statusCode == 200 && mounted) {
        setState(() {
          isApiOnline = true;
          apiPingMs   = duration;
          if (duration < 200) {
            apiStatusColor = _NB.green;
          } else if (duration < 500) {
            apiStatusColor = _NB.orange;
          } else {
            apiStatusColor = _NB.red;
          }
          apiStatusText = "Sys.Online :: ${duration}ms";
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          isApiOnline    = false;
          apiPingMs      = 0;
          apiStatusColor = _NB.red;
          apiStatusText  = "Sys.Offline :: DEST";
        });
      }
    }
  }

  // ─── BANNER ────────────────────────────────────────────────────────────
  Widget _buildBanner() {
    return Container(
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: _NB.border, width: 2.5),
        ),
      ),
      child: SizedBox(
        height: 210,
        width: double.infinity,
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset('assets/images/banner.jpg', fit: BoxFit.cover),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.25),
                    Colors.black.withOpacity(0.68),
                  ],
                ),
              ),
            ),
            const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    "Info Queen",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 40,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 3,
                      fontFamily: 'Aktura',
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    "Fitur Dan Kebijakan Queen",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 13,
                      letterSpacing: 0.8,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── STATUS HEADER ─────────────────────────────────────────────────────
  Widget _buildStatusHeader() {
    return Container(
      margin: const EdgeInsets.only(bottom: 24),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      decoration: BoxDecoration(
        color: _NB.card,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _NB.border, width: 2),
        boxShadow: const [
          BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(4, 4)),
        ],
      ),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _glowAnimation,
            builder: (_, __) => Container(
              width: 12,
              height: 12,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: apiStatusColor,
                border: Border.all(color: _NB.border, width: 1),
                boxShadow: [
                  BoxShadow(
                    color: apiStatusColor.withOpacity(_glowAnimation.value * 0.6),
                    blurRadius: 10,
                    spreadRadius: 2,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              apiStatusText.toUpperCase(),
              style: TextStyle(
                color: apiStatusColor == _NB.textDim ? _NB.text : apiStatusColor,
                fontFamily: 'ShareTechMono',
                fontWeight: FontWeight.w800,
                fontSize: 13,
                letterSpacing: 1.5,
              ),
            ),
          ),
          Icon(Icons.memory, color: _NB.textDim, size: 20),
        ],
      ),
    );
  }

  // ─── SECTION HEADER ───────────────────────────────────────────────────
  Widget _buildSectionHeader(String title, IconData icon) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.only(left: 10),
          decoration: BoxDecoration(
            border: Border(
              left: BorderSide(color: _NB.border, width: 3.5),
            ),
          ),
          child: Row(
            children: [
              Icon(icon, color: _NB.text, size: 20),
              const SizedBox(width: 8),
              Text(
                "!! $title",
                style: const TextStyle(
                  color: _NB.text,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Container(
          width: 60,
          height: 4,
          decoration: BoxDecoration(
            color: _NB.border,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      ],
    );
  }

  // ─── TENTANG QUEEN ────────────────────────────────────────────────────
  Widget _buildTentangSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader("Tentang Queen", Icons.info_outline_rounded),
        const SizedBox(height: 14),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: _NB.card,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _NB.border, width: 2),
            boxShadow: const [
              BoxShadow(
                color: _NB.border,
                blurRadius: 0,
                offset: Offset(4, 4),
              ),
            ],
          ),
          child: const Text(
            "Queen Project adalah sebuah sistem utilitas tingkat lanjut yang dirancang khusus untuk memfasilitasi pengujian stabilitas dan pengiriman payload (Bug Testing). Dibangun dengan arsitektur berkinerja tinggi, sistem ini menjamin kecepatan eksekusi, keamanan enkripsi sesi, dan presisi dalam pengiriman data baik secara personal maupun publik. Kami menyediakan infrastruktur server yang kuat untuk kelancaran tugas Anda.",
            style: TextStyle(
              color: _NB.text,
              fontSize: 13,
              height: 1.75,
              fontFamily: 'ShareTechMono',
            ),
            textAlign: TextAlign.justify,
          ),
        ),
      ],
    );
  }

  // ─── FEATURE CARD ──────────────────────────────────────────────────────
  Widget _buildFeatureCard(Map<String, dynamic> feature) {
    final Color c = feature['color'] as Color;
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _NB.card,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _NB.border, width: 2),
        boxShadow: const [
          BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(4, 4)),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: c.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _NB.border, width: 1.5),
            ),
            child: Icon(feature['icon'] as IconData, color: c, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  feature['title'] as String,
                  style: const TextStyle(
                    color: _NB.text,
                    fontWeight: FontWeight.w800,
                    fontSize: 14,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  feature['desc'] as String,
                  style: const TextStyle(
                    color: _NB.textSub,
                    fontSize: 12,
                    height: 1.55,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── FITUR SECTION ─────────────────────────────────────────────────────
  Widget _buildFiturSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader("Fitur-fitur Utama", Icons.rocket_launch_rounded),
        const SizedBox(height: 14),
        ...featuresList.map(_buildFeatureCard).toList(),
      ],
    );
  }

  // ─── RULE CARD ─────────────────────────────────────────────────────────
  Widget _buildRuleCard(int index, Map<String, dynamic> rule) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: _NB.card,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _NB.border, width: 2),
        boxShadow: const [
          BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(4, 4)),
        ],
      ),
      child: Theme(
        data: ThemeData(dividerColor: Colors.transparent),
        child: ExpansionTile(
          iconColor: _NB.purpleMain,
          collapsedIconColor: _NB.textDim,
          tilePadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          leading: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: _NB.purplePale,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _NB.border, width: 1.5),
            ),
            child:
                Icon(rule['icon'] as IconData, color: _NB.purpleMain, size: 22),
          ),
          title: Text(
            rule['title'] as String,
            style: const TextStyle(
              color: _NB.text,
              fontWeight: FontWeight.bold,
              fontSize: 13,
              fontFamily: 'Orbitron',
              letterSpacing: 0.8,
            ),
          ),
          children: [
            Container(
              padding: const EdgeInsets.only(
                  left: 20, right: 20, bottom: 18, top: 2),
              width: double.infinity,
              child: Text(
                rule['desc'] as String,
                style: const TextStyle(
                  color: _NB.textSub,
                  fontSize: 12,
                  height: 1.55,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── PENALTY BOX ───────────────────────────────────────────────────────
  Widget _buildPenaltyBox() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 8, bottom: 28),
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: _NB.card,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _NB.red, width: 2),
        boxShadow: const [
          BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(4, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.warning_amber_rounded,
                  color: _NB.red, size: 26),
              SizedBox(width: 10),
              Text(
                "VIOLATION PENALTY",
                style: TextStyle(
                  color: _NB.red,
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          const Text(
            "Jika pengguna terdeteksi melanggar salah satu protokol kerahasiaan & aturan di atas secara sengaja:",
            style: TextStyle(
                color: _NB.text,
                fontSize: 12,
                fontFamily: 'ShareTechMono',
                height: 1.5),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 12),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: _NB.red.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                  color: _NB.red.withOpacity(0.5), width: 2),
            ),
            child: const Text(
              "AKUN AKAN DIHAPUS PERMANEN",
              style: TextStyle(
                  color: _NB.text,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            "TIDAK ADA PENGEMBALIAN SALDO ATAU KOMPENSASI.",
            style: TextStyle(
              color: _NB.red,
              fontSize: 11,
              fontWeight: FontWeight.bold,
              fontFamily: 'ShareTechMono',
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  // ─── BUILD ─────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(
        backgroundColor: _NB.bg,
        body: Center(
          child: SizedBox(
            width: 40,
            height: 40,
            child: CircularProgressIndicator(
              color: _NB.purpleMain,
              strokeWidth: 3,
            ),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: _NB.bg,
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(child: _buildBanner()),

            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              sliver: SliverList(
                delegate: SliverChildListDelegate([
                  _buildStatusHeader(),
                  _buildTentangSection(),
                  const SizedBox(height: 28),
                  _buildFiturSection(),
                  const SizedBox(height: 28),
                  _buildSectionHeader(
                      "Kebijakan Pengguna", Icons.shield_outlined),
                  const SizedBox(height: 14),
                  ...rulesList
                      .asMap()
                      .entries
                      .map((e) => _buildRuleCard(e.key, e.value))
                      .toList(),
                  _buildPenaltyBox(),
                  Center(
                    child: Column(
                      children: [
                        Icon(Icons.shield_moon_rounded,
                            color: _NB.textDim, size: 28),
                        const SizedBox(height: 12),
                        const Text(
                          "Peraturan ini dibuat semata-mata untuk menjaga keamanan, kenyamanan, dan kestabilan ekosistem server Queen. Dengan mengakses aplikasi, Anda secara otomatis menyetujui seluruh protokol di atas.",
                          style: TextStyle(
                            color: _NB.textDim,
                            fontSize: 11,
                            fontStyle: FontStyle.italic,
                            fontFamily: 'ShareTechMono',
                            height: 1.55,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 16),
                        Container(
                          height: 3,
                          width: 40,
                          decoration: BoxDecoration(
                            color: _NB.textDim,
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                        const SizedBox(height: 100),
                      ],
                    ),
                  ),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}