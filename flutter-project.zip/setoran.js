// ============================================================
// 💰 SETORAN BUYER SYSTEM — by Yuzakura Fable Pro 21
// File: setoran.js
// v9.0 — OWNER SETORAN ACCESS CONTROL + /ADDC GROUP FLOW
// ✅ Foto + caption ringkas tetap 1 pesan
// ✅ RichMessage premium + custom emoji fallback
// ✅ FULL BLOCKQUOTE
// ✅ Receipt auto-edit + User ID tracking
// ✅ Role detection: tag member→moderator, promote executorius→owner_utama
// ============================================================
const fs = require('fs');
const path = require('path');

module.exports = function initSetoran(bot, ctx = {}) {
  const {
    ADMIN_GROUP_ID = "-18880837641",
    CHANNEL_ID = "-1003664576719",
    INFORMATION_URL = "https://t.me/Mclareninfo",
  } = ctx;

  // Owner operator dapat berasal dari config runtime atau owner_acc.json.
  // owner_acc.json tetap menjadi sumber akses ACC setoran setelah bootstrap.
  const OWNER_OPERATOR_IDS = new Set(
    [
      ctx.OWNER_ID,
      ctx.OWNER_MAIN_ID,
      ctx.OWNER_UTAMA_ID,
      ...(Array.isArray(ctx.OWNER_IDS) ? ctx.OWNER_IDS : [])
    ]
      .flatMap(value => String(value ?? '').split(','))
      .map(value => Number(value.trim()))
      .filter(Number.isSafeInteger)
      .filter(value => value > 0)
  );

  const PEMBELI_FILE       = path.join(__dirname, 'pembeli.json');
  const PENDING_SETOR_FILE = path.join(__dirname, 'pending_setoran.json');
  const OWNER_ACC_FILE     = path.join(__dirname, 'owner_acc.json');
  const GROUP_LINKS_FILE   = path.join(__dirname, 'group_links.json');
  const TELEGRAM_FILE      = path.join(__dirname, 'telegram.json');
  const VERIFIED_FILE      = path.join(__dirname, 'verified_buyer.json');
  const BOT_USERS_FILE     = path.join(__dirname, 'bot_users.json');
  const BOT_CHATS_FILE     = path.join(__dirname, 'bot_chats.json');
  let botStartUrlPromise = null;

  const ROLE_PRICES = {
    member:          { price: 0,      label: "Member",            emoji: '👤' },
    vip:             { price: 15000,  label: "Vip Permanen",      emoji: '⭐️' },
    reseller:        { price: 17000,  label: "Reseller",          emoji: '💰' },
    tukang_bubur:    { price: 20000,  label: "Tukang Bubur",      emoji: '🍲' },
    admin:           { price: 28000,  label: "Admin",             emoji: '🔧' },
    partner:         { price: 30000,  label: "Partner",           emoji: '🤝' },
    partner_pribadi: { price: 35000,  label: "Partner Pribadi",   emoji: '🤝' },
    tangan_kiri:     { price: 37000,  label: "Tangan Kiri",       emoji: '🤝' },
    tangan_kanan:    { price: 39000,  label: "Tangan Kanan",      emoji: '🤝' },
    developers:      { price: 45000,  label: "Developers",        emoji: '💻' },
    ceo_utama:       { price: 49000,  label: "Ceo Utama",         emoji: '💼' },
    moderator:       { price: 59000,  label: "Moderator",         emoji: '🛡️' },
    forius_utama:    { price: 69000,  label: "Forius Utama",      emoji: '🔥' },
    executorius:     { price: 70000,  label: "Executorius",       emoji: '⚡' },
    staff:           { price: 80000,  label: "Staff / Security",  emoji: '🛠️' },
    owner:           { price: 155000, label: "Owner",             emoji: '👑' },
    owner_utama:     { price: 250000, label: "Owner Utama",       emoji: '👑' },
  };

  const ROLE_ORDER = [
    'member','vip','reseller','tukang_bubur','admin','partner',
    'partner_pribadi','tangan_kiri','tangan_kanan','developers',
    'ceo_utama','moderator','forius_utama','executorius',
    'staff','owner','owner_utama'
  ];

  const PROMOTE_ROLES = [
    'executorius', 'staff', 'owner', 'owner_utama'
  ];

  const ROLE_TAG_PREFIX = {
    owner_utama:  '👑 OWNER UTAMA',
    owner:        '👑 OWNER',
    staff:        '🛠️ STAFF',
    executorius:  '⚡ EXECUTORIUS',
    forius_utama: '🔥 FORIUS UTAMA',
    moderator:    '🛡️ MODERATOR',
    ceo_utama:    '💼 CEO UTAMA',
    developers:   '💻 DEVELOPERS',
    tangan_kanan: '🤝 TANGAN KANAN',
    tangan_kiri:  '🤝 TANGAN KIRI',
    partner_pribadi: '🤝 PARTNER PRIBADI',
    partner:      '🤝 PARTNER',
    admin:        '🔧 ADMIN',
    reseller:     '💰 RESELLER',
    tukang_bubur: '🍲 TUKANG BUBUR',
    vip:          '⭐️ VIP',
    member:       '👤 MEMBER'
  };

  // ═══════════════════════════════════════════════════════════
  // 🎨 PREMIUM CUSTOM EMOJI IDS
  // ═══════════════════════════════════════════════════════════
  // Premium custom emoji terpusat. Semua UI setoran memakai registry ini.
  const EMOJI = Object.freeze({
    brand: "5350404703823883106", info: "5334544901428229844", user: "5210956306952758910",
    receipt: "5210956306952758910", diamond: "5769454896138949400", money: "6098166408502320493", payment: "5350295774863311434",
    check: "5206607081334906820", verify: "6028565819225542441", warning: "5447644880824181073",
    cross: "5210952531676504517", clock: "5348090777308251395", target: "6185808707985608949",
    group: "5210956306952758910", guide: "5334544901428229844", shield: "6028551194861899805",
    lock: "5296369303661067030", key: "5352761996624292287", bell: "6098230596788556786", exit: "5210952531676504517", next: "5206607081334906820", deposit: "5350295774863311434", party: "5785281906459283269", star: "5375338737028841420",
    sparkle: "5350404703823883106", lightning: "5917828256525979606", gem: "5890847821728322055",
    heart: "5917968238100091256", rocket: "5780773956030043338", medal: "5440539497383087970",
    gift: "5785281906459283269", bag: "6028517788606272241", crown: "5341715473882955310",
    buy: "5402186569006210455"
  });

  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  const readJSON = (file, def = []) => {
    try {
      if (!fs.existsSync(file)) { fs.writeFileSync(file, JSON.stringify(def, null, 2)); return def; }
      const d = JSON.parse(fs.readFileSync(file, 'utf8'));
      return d ?? def;
    } catch { return def; }
  };
  const writeJSON = (file, data) => {
    try { fs.writeFileSync(file, JSON.stringify(data, null, 2)); }
    catch (e) { console.error(`[STN] write ${file}:`, e.message); }
  };

  const setoranState = new Map();

  const esc = (v) => String(v ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  const ce  = (id, fb) => `<tg-emoji emoji-id="${id}">${fb}</tg-emoji>`;
  const rp  = (n) => `Rp ${Number(n || 0).toLocaleString('id-ID')}`;

  const richTable = (rows, headers = ["Information", "Detail"]) => {
    let out = `<table bordered striped compact>\n`;
    out += `<tr><th>${esc(headers[0])}</th><th>${esc(headers[1])}</th></tr>\n`;
    for (const [a, b] of rows) out += `<tr><td>${esc(a)}</td><td>${esc(b)}</td></tr>\n`;
    out += `</table>`;
    return out;
  };
  const richHeader = (text, emoji = '📌') => `<blockquote><b>${emoji} ${esc(text)}</b></blockquote>`;
  const richQuote  = (text) => `<blockquote>${text}</blockquote>`;
  const richDiv    = () => `<hr/>`;
  const richPara   = (text) => `<p>${text}</p>`;

  async function sendOrEditRich(chatId, messageId, text, replyMarkup = null) {
    const opts = {};
    if (replyMarkup) opts.reply_markup = replyMarkup;
    try {
      if (messageId && typeof bot.editRichMessage === 'function') {
        return await bot.editRichMessage(text, { chat_id: chatId, message_id: messageId, ...opts });
      }
      if (messageId) await bot.deleteMessage(chatId, messageId).catch(() => {});
      return await bot.sendRichMessage(chatId, text, opts);
    } catch (e) {
      try { return await bot.sendRichMessage(chatId, text, opts); } catch (_) {}
      return null;
    }
  }

  // ═══════════════════════════════════════════════════════════
  // 📸 TESTIMONI HTML — FULL TG EMOJI + FULL BLOCKQUOTE
  // ═══════════════════════════════════════════════════════════
  function buildTestimonialRich(setId, data, userInfo) {
    const roleTarget = String(data.role || data.record?.role || 'member');
    const roleInfo = ROLE_PRICES[roleTarget] || { price: Number(data.amount || 0), label: roleTarget.toUpperCase(), emoji: '🎯' };
    const isDp = data.buyerType === 'dp' || data.mode === 'dp';
    const targetUserId = Number(data.targetUserId || data.userId);
    const targetName = data.targetUsername ? `@${data.targetUsername}` : (data.targetDisplayName || `User_${targetUserId}`);
    const buyerName = userInfo?.username ? `@${userInfo.username}` : (userInfo?.displayName || `User_${data.userId}`);
    const verifiedBy = data.acceptedBy ? `@${data.acceptedBy}` : '@Owner';
    const waktu = new Date(data.acceptedAt || data.createdAt || Date.now()).toLocaleString('id-ID', {
      timeZone: 'Asia/Jakarta', day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
    });
    const e = (key, fallback) => ce(EMOJI[key], fallback);
    const row = (key, fallback, label, value) =>
      `<blockquote>${e(key, fallback)} <b>${esc(label)}</b> · ${value}</blockquote>`;

    return [
      `<blockquote><b>${e('sparkle', '✨')} TESTIMONI SETORAN ${e('check', '✓')}</b></blockquote>`,
      `<blockquote><i>${e('shield', '🛡️')} Transaksi berhasil diverifikasi oleh owner.</i></blockquote>`,
      richDiv(),
      `<blockquote><b>${e('receipt', '🧾')} RINGKASAN TRANSAKSI</b></blockquote>`,
      row('diamond', '💎', 'ID', `<code>${esc(setId)}</code>`),
      row('user', '👤', 'Buyer', `<b>${esc(buyerName)}</b>`),
      row('target', '🎯', 'Target', `<b>${esc(targetName)}</b> <code>${targetUserId}</code>`),
      row('bag', '🛍️', 'Role', `<b>${esc(roleInfo.emoji)} ${esc(roleInfo.label)}</b>`),
      row('money', '💸', 'Nominal', `<b>${esc(rp(data.amount))}</b>`),
      row('payment', '💰', 'Pembayaran', isDp ? '<b>DP</b>' : '<b>FULL PAYMENT</b>'),
      row('check', '✅', 'Status', '<b>LUNAS / VERIFIED</b>'),
      row('clock', '🕒', 'Waktu', esc(waktu)),
      richDiv(),
      `<blockquote>${e('heart', '🤍')} Terima kasih sudah mempercayai <b>Mclaren Project</b>.</blockquote>`,
      `<blockquote>${e('verify', '☑️')} Verified by <b>${esc(verifiedBy)}</b> · ${e('lock', '🔒')} Official Record</blockquote>`,
      `<blockquote>${e('rocket', '🚀')} <b>Fast • Secure • Verified</b></blockquote>`,
      `<footer>${e('crown', '👑')} Mclaren Project • Secure Payment System</footer>`
    ].join('\n');
  }

  // ═══════════════════════════════════════════════════════════
  // 📸 CONVERT RICH → HTML CAPTION (strip tg-emoji & blockquote)
  // ═══════════════════════════════════════════════════════════
  function richToCaptionHtml(richText) {
    if (!richText) return '';
    let out = String(richText);
    out = out.replace(/<blockquote>/gi, '').replace(/<\/blockquote>/gi, '\n');
    out = out.replace(/<hr\s*\/?>/gi, '\n━━━━━━━━━━━━━━━━━━\n');
    out = out.replace(/\n{3,}/g, '\n\n').trim();
    if (out.length > 1024) out = `${out.slice(0, 1000).trim()}\n<i>...</i>`;
    return out;
  }

  async function getBotStartUrl() {
    if (!botStartUrlPromise) {
      botStartUrlPromise = Promise.resolve(bot.getMe())
        .then(me => {
          if (!me?.username) throw new Error('Bot username tidak tersedia');
          return `https://t.me/${me.username}?start=buy`;
        })
        .catch(error => {
          botStartUrlPromise = null;
          throw error;
        });
    }
    return botStartUrlPromise;
  }

  // ═══════════════════════════════════════════════════════════
  // 📸 SEND TESTIMONI — FOTO + TEKS 100% GABUNG
  // ═══════════════════════════════════════════════════════════
  async function sendTestimonialPhoto(chatId, fileId, setId, data, userInfo, extraOpts = {}) {
    const richCaption = buildTestimonialRich(setId, data, userInfo);
    const captionHtml = richToCaptionHtml(richCaption);

    if (!fileId) {
      try {
        return await bot.sendRichMessage(chatId, richCaption, { parse_mode: 'HTML', ...extraOpts });
      } catch (error) {
        console.error(`[STN] testimonial rich send failed:`, error.message);
        return null;
      }
    }

    let replyMarkup = extraOpts.reply_markup;
    if (!replyMarkup) {
      try {
        const startUrl = await getBotStartUrl();
        replyMarkup = {
          inline_keyboard: [[
            { text: '🚀 Lihat Produk', url: startUrl, style: 'success', icon_custom_emoji_id: EMOJI.buy }
          ]]
        };
      } catch (_) {
        replyMarkup = undefined;
      }
    }

    try {
      return await bot.sendPhoto(chatId, fileId, {
        caption: captionHtml,
        parse_mode: 'HTML',
        ...extraOpts,
        ...(replyMarkup ? { reply_markup: replyMarkup } : {})
      });
    } catch (error) {
      console.error(`[STN] testimonial photo send failed ${chatId}:`, error.message);
    }

    try {
      return await bot.sendRichMessage(chatId, richCaption, {
        parse_mode: 'HTML',
        ...extraOpts,
        ...(replyMarkup ? { reply_markup: replyMarkup } : {})
      });
    } catch (error) {
      console.error(`[STN] testimonial fallback failed ${chatId}:`, error.message);
      return null;
    }
  }

  async function animateLoading(chatId, messageId, title = "Memproses") {
    if (!messageId) return;
    for (let i = 1; i <= 10; i++) {
      const pct = Math.round((i / 10) * 100);
      const bar = '█'.repeat(i) + '░'.repeat(10 - i);
      try {
        await bot.editMessageText(`<b>⏳ ${esc(title)}...</b>\n\n<code>ᯓ ${bar}  ${pct}%</code>`, {
          chat_id: chatId, message_id: messageId, parse_mode: 'HTML'
        });
      } catch (_) {}
      await sleep(90);
    }
  }

  const WAVE_FRAMES = [
    "▁▂▃▄▅▆▇█▇▆▅▄▃▂▁",
    "▂▃▄▅▆▇█▇▆▅▄▃▂▁▂",
    "▃▄▅▆▇█▇▆▅▄▃▂▁▂▃",
    "▄▅▆▇█▇▆▅▄▃▂▁▂▃▄",
    "▅▆▇█▇▆▅▄▃▂▁▂▃▄▅",
    "▆▇█▇▆▅▄▃▂▁▂▃▄▅▆",
    "▇█▇▆▅▄▃▂▁▂▃▄▅▆▇",
    "█▇▆▅▄▃▂▁▂▃▄▅▆▇█",
  ];

  async function startWaveLoading(chatId, messageId, title = "Menunggu verifikasi owner") {
    let idx = 0;
    const interval = setInterval(async () => {
      try {
        const wave = WAVE_FRAMES[idx % WAVE_FRAMES.length];
        await bot.editMessageText(
          `<b>⏳ ${esc(title)}...</b>\n\n<code>${wave}</code>\n\n<i>Mohon tunggu, sedang diproses admin</i>`,
          { chat_id: chatId, message_id: messageId, parse_mode: 'HTML' }
        );
        idx++;
      } catch (_) {}
    }, 400);
    return interval;
  }

  const loadBotUsers = () => readJSON(BOT_USERS_FILE, {});
  const saveBotUsers = (d) => writeJSON(BOT_USERS_FILE, d);
  const loadBotChats = () => readJSON(BOT_CHATS_FILE, {});
  const saveBotChats = (d) => writeJSON(BOT_CHATS_FILE, d);

  let _usersCache = null, _chatsCache = null;

  function trackUser(user) {
    try {
      if (!user || !user.id || user.is_bot) return;
      const uid = Number(user.id);
      if (uid <= 0) return;
      if (!_usersCache) _usersCache = new Set(Object.keys(loadBotUsers()));
      const key = String(uid);
      if (_usersCache.has(key)) return;
      const all = loadBotUsers();
      all[key] = {
        userId: uid,
        username: user.username || '',
        firstName: user.first_name || '',
        lastName: user.last_name || '',
        firstSeenAt: new Date().toISOString()
      };
      saveBotUsers(all);
      _usersCache.add(key);
    } catch (_) {}
  }

  function trackChat(chat) {
    try {
      if (!chat || !chat.id) return;
      const id = Number(chat.id);
      const type = chat.type || (id < 0 ? 'group' : 'private');
      if (type === 'private') return;
      if (!_chatsCache) _chatsCache = new Set(Object.keys(loadBotChats()));
      const key = String(id);
      if (_chatsCache.has(key)) return;
      const all = loadBotChats();
      all[key] = {
        chatId: id, type,
        title: chat.title || '',
        username: chat.username || '',
        firstSeenAt: new Date().toISOString()
      };
      saveBotChats(all);
      _chatsCache.add(key);
    } catch (_) {}
  }

  const loadOwnerAcc = () => {
    try {
      const data = readJSON(OWNER_ACC_FILE, []);
      if (!Array.isArray(data)) return [];
      return [...new Set(
        data
          .map(Number)
          .filter(Number.isSafeInteger)
          .filter(id => id > 0)
      )];
    } catch (_) {
      return [];
    }
  };

  const isOwnerAcc = (id) => loadOwnerAcc().includes(Number(id));
  const isOwnerOperator = (id) => {
    const uid = Number(id);
    return Number.isSafeInteger(uid) && uid > 0 && (OWNER_OPERATOR_IDS.has(uid) || isOwnerAcc(uid));
  };

  function isGroupChat(chat) {
    return chat?.type === 'group' || chat?.type === 'supergroup';
  }

  function writeOwnerAcc(ids) {
    const normalized = [...new Set(
      ids
        .map(Number)
        .filter(Number.isSafeInteger)
        .filter(id => id > 0)
    )];
    const tempFile = `${OWNER_ACC_FILE}.tmp`;
    fs.writeFileSync(tempFile, JSON.stringify(normalized, null, 2));
    fs.renameSync(tempFile, OWNER_ACC_FILE);
    return normalized;
  }

  function ownerAccUserLabel(userId, userInfo = {}) {
    if (userInfo.username) return `@${esc(userInfo.username)}`;
    return esc(userInfo.displayName || `User_${userId}`);
  }

  function buildAddOwnerAccessRich(title, body, rows = [], status = 'info') {
    const statusMap = {
      success: ['verify', '✅'],
      error: ['cross', '❌'],
      warning: ['warning', '⚠️'],
      info: ['info', 'ℹ️']
    };
    const [key, fallback] = statusMap[status] || statusMap.info;
    return [
      richHeader(title, ce(EMOJI[key], fallback)),
      richPara(body),
      richDiv(),
      rows.length ? richTable(rows, ['Access Control', 'Detail']) : '',
      rows.length ? richDiv() : '',
      richQuote(`${ce(EMOJI.shield, '🛡️')} <b>OWNER ACCESS CONTROL</b> • Setoran Verification System`),
      `<footer>${ce(EMOJI.crown, '👑')} Mclaren Project • Secure Owner Authorization</footer>`
    ].filter(Boolean).join('\n');
  }

  async function promptAddOwnerAccess(chatId, messageId = null) {
    const text = [
      richHeader('ADD SETORAN ACC', ce(EMOJI.key, '🔐')),
      richPara(`Fitur ini khusus <b>OWNER</b> untuk menambahkan <b>User ID</b> baru yang diberi akses melakukan <b>ACC Setoran</b>.`),
      richDiv(),
      richHeader('CARA PENGGUNAAN', ce(EMOJI.guide, '📖')),
      richQuote([
        `${ce(EMOJI.target, '🎯')} Kirim <b>User ID Telegram</b> yang ingin diberi akses.`,
        `${ce(EMOJI.check, '✅')} Setelah ID valid diterima, bot akan otomatis menyimpan ke <code>owner_acc.json</code>.`,
        `${ce(EMOJI.bell, '🔔')} Pesan ini akan otomatis berubah menjadi notifikasi <b>SUCCESS</b>.`
      ].join('\n')),
      richDiv(),
      richQuote(`${ce(EMOJI.warning, '⚠️')} Gunakan <b>command /addc</b> di <b>GROUP / SUPERGROUP</b>. Fitur tidak aktif di private chat.`),
      `<footer>${ce(EMOJI.lock, '🔒')} Owner-only • No public access</footer>`
    ].join('\n');

    const options = {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [[
          { text: '❌ Batal', callback_data: 'stn_addc_cancel', style: 'danger', icon_custom_emoji_id: EMOJI.cross }
        ]]
      }
    };

    const sent = messageId
      ? await sendOrEditRich(chatId, messageId, text, options.reply_markup)
      : await bot.sendRichMessage(chatId, text, options);

    return sent;
  }

  async function handleAddOwnerAccessInput(msg) {
    const userId = Number(msg.from?.id);
    const chatId = msg.chat?.id;
    const state = setoranState.get(userId);
    if (!state || state.step !== 'awaiting_owner_acc_id') return false;

    if (!isGroupChat(msg.chat)) {
      setoranState.delete(userId);
      await bot.sendRichMessage(chatId, buildAddOwnerAccessRich(
        'ACCESS DITOLAK',
        `Fitur <b>Add Setoran Acc</b> hanya dapat digunakan di <b>GROUP / SUPERGROUP</b>.`,
        [['User ID', String(userId)], ['Status', '❌ GROUP REQUIRED']],
        'error'
      ), { parse_mode: 'HTML' });
      return true;
    }

    const raw = String(msg.text || '').trim().replace(/[`\s]/g, '');
    if (!/^-?\d+$/.test(raw)) {
      await bot.sendRichMessage(chatId, buildAddOwnerAccessRich(
        'ID TIDAK VALID',
        `Kirim <b>User ID Telegram berupa angka</b> saja.`,
        [['Format', '<code>123456789</code>'], ['Input', esc(msg.text || '-')], ['Status', '❌ INVALID ID']],
        'error'
      ), { parse_mode: 'HTML' });
      return true;
    }

    const targetId = Number(raw);
    if (!Number.isSafeInteger(targetId) || targetId <= 0) {
      await bot.sendRichMessage(chatId, buildAddOwnerAccessRich(
        'ID TIDAK VALID',
        `User ID harus berupa bilangan bulat positif yang valid.`,
        [['Input', `<code>${esc(raw)}</code>`], ['Status', '❌ INVALID USER ID']],
        'error'
      ), { parse_mode: 'HTML' });
      return true;
    }

    const current = loadOwnerAcc();
    if (current.includes(targetId)) {
      setoranState.delete(userId);
      await bot.sendRichMessage(chatId, buildAddOwnerAccessRich(
        'ACCESS SUDAH TERDAFTAR',
        `User ID tersebut sudah memiliki akses <b>ACC Setoran</b>.`,
        [['Target ID', `<code>${targetId}</code>`], ['Status', '🟡 ALREADY AUTHORIZED'], ['Total Owner Access', String(current.length)]],
        'warning'
      ), { parse_mode: 'HTML' });
      return true;
    }

    try {
      const updated = writeOwnerAcc([...current, targetId]);
      setoranState.delete(userId);

      const actorInfo = await autoDetectUserInfo(userId);
      const targetInfo = await autoDetectUserInfo(targetId);
      const targetLabel = ownerAccUserLabel(targetId, targetInfo);

      const successText = buildAddOwnerAccessRich(
        'ACCESS ACC SETORAN BERHASIL',
        `${ce(EMOJI.party, '🎉')} Akses owner baru berhasil <b>ditambahkan</b> dan langsung aktif.`,
        [
          ['Target', targetLabel],
          ['Target User ID', `<code>${targetId}</code>`],
          ['Ditambahkan Oleh', ownerAccUserLabel(userId, actorInfo)],
          ['Group', esc(msg.chat.title || `Chat ${chatId}`)],
          ['Status', '🟢 ACTIVE / AUTHORIZED'],
          ['Owner Access Total', String(updated.length)],
          ['Storage', '<code>owner_acc.json</code>']
        ],
        'success'
      );

      await bot.sendRichMessage(chatId, successText, { parse_mode: 'HTML' });
      return true;
    } catch (error) {
      setoranState.delete(userId);
      await bot.sendRichMessage(chatId, buildAddOwnerAccessRich(
        'GAGAL MENYIMPAN ACCESS',
        `Sistem gagal menyimpan akses owner baru. Tidak ada perubahan yang dianggap berhasil.`,
        [['Target ID', `<code>${targetId}</code>`], ['Status', '🔴 SAVE FAILED'], ['Error', esc(error.message || 'Unknown error')]],
        'error'
      ), { parse_mode: 'HTML' });
      return true;
    }
  }

  async function handleAddOwnerAccessCommand(msg) {
    if (!msg?.from || !msg.chat || !/^\/addc(?:@\w+)?$/i.test(String(msg.text || '').trim())) return false;

    const userId = Number(msg.from.id);
    const chatId = msg.chat.id;

    if (!isGroupChat(msg.chat)) {
      await bot.sendRichMessage(chatId, buildAddOwnerAccessRich(
        'ADD SETORAN ACC — GROUP ONLY',
        `Command <code>/addc</code> hanya dapat digunakan di <b>GROUP / SUPERGROUP</b>.`,
        [['Status', '❌ PRIVATE CHAT BLOCKED']],
        'error'
      ), { parse_mode: 'HTML' });
      return true;
    }

    if (!isOwnerOperator(userId)) {
      await bot.sendRichMessage(chatId, buildAddOwnerAccessRich(
        'AKSES DITOLAK',
        `Command ini hanya dapat digunakan oleh <b>OWNER</b> yang terdaftar pada konfigurasi owner bot.`,
        [['Requester ID', `<code>${userId}</code>`], ['Status', '🔒 OWNER ONLY']],
        'error'
      ), { parse_mode: 'HTML' });
      return true;
    }

    const prompt = await promptAddOwnerAccess(chatId);
    setoranState.set(userId, {
      step: 'awaiting_owner_acc_id',
      addOwnerAccMsgId: prompt?.message_id || null,
      addOwnerAccChatId: chatId,
      createdAt: Date.now()
    });
    return true;
  }
  const loadGroupLinks = () => readJSON(GROUP_LINKS_FILE, {
    member:"",vip:"",reseller:"",tukang_bubur:"",admin:"",partner:"",
    partner_pribadi:"",tangan_kiri:"",tangan_kanan:"",developers:"",
    ceo_utama:"",moderator:"",forius_utama:"",executorius:"",
    staff:"",owner:"",owner_utama:"",_guide:"https://t.me/Mclareninfo"
  });
  const loadVerified = () => readJSON(VERIFIED_FILE, {});
  const saveVerified = (data) => writeJSON(VERIFIED_FILE, data);

  const getAccessibleRoles = (role) => {
    const idx = ROLE_ORDER.indexOf(role);
    if (idx === -1) return [role];
    return ROLE_ORDER.slice(0, idx + 1);
  };

  const detectBuyerType = (userId) => {
    const pembeli = readJSON(PEMBELI_FILE, []);
    const records = pembeli.filter(p => Number(p.userId) === Number(userId));
    if (!records.length) return { type: 'unknown' };
    records.sort((a, b) => new Date(b.purchasedAt || 0) - new Date(a.purchasedAt || 0));
    const unpaidDp = records.find(p => !p.isLunas && p.mode === 'dp');
    if (unpaidDp) return { type: 'dp', record: unpaidDp };
    const fullLunas = records.find(p => p.isLunas);
    if (fullLunas) return { type: 'full', record: fullLunas };
    return { type: 'full', record: records[0] };
  };

  async function sendNotifToOwners(photoFileId, text, keyboard) {
    const owners = loadOwnerAcc();
    if (!owners.length) {
      console.warn('[STN] ⚠️ owner_acc.json kosong');
      return;
    }
    for (const ownerId of owners) {
      try {
        await sendRichPhoto(ownerId, photoFileId, text, { reply_markup: keyboard });
      } catch (e1) {
        try { await bot.sendRichMessage(ownerId, text, { parse_mode: 'HTML', reply_markup: keyboard }); } catch (_) {}
      }
    }
  }

  // ═══════════════════════════════════════════════════════════
  // 📸 SEND RICH PHOTO (buat notif owner + flow lain)
  // ═══════════════════════════════════════════════════════════
  async function sendRichPhoto(chatId, fileId, caption, extraOpts = {}) {
    // Convert rich ke caption (strip tg-emoji & blockquote)
    let captionHtml = richToCaptionHtml(caption);
    if (captionHtml.length > 1024) {
      captionHtml = captionHtml.substring(0, 1000).trim() + '\n<i>...</i>';
    }

    if (fileId) {
      try {
        return await bot.sendPhoto(chatId, fileId, {
          caption: captionHtml,
          parse_mode: 'HTML',
          ...extraOpts
        });
      } catch (e1) {
        console.error(`[STN] sendRichPhoto attempt1 fail:`, e1.message);
      }

      try {
        await bot.sendPhoto(chatId, fileId).catch(() => {});
        return await bot.sendRichMessage(chatId, caption, {
          parse_mode: 'HTML', ...extraOpts
        });
      } catch (e2) {
        console.error(`[STN] sendRichPhoto attempt2 fail:`, e2.message);
      }
    }

    try {
      return await bot.sendRichMessage(chatId, caption, {
        parse_mode: 'HTML', ...extraOpts
      });
    } catch (e3) {
      console.error(`[STN] sendRichPhoto attempt3 fail:`, e3.message);
    }

    return null;
  }

  function buildUserMention(userId, userInfo) {
    const safeId = Number(userId);
    if (!Number.isSafeInteger(safeId) || safeId <= 0) return esc(userInfo?.displayName || `User_${userId}`);
    const label = userInfo?.username ? `@${userInfo.username}` : (userInfo?.displayName || `User_${safeId}`);
    return `<a href="tg://user?id=${safeId}">${esc(label)}</a>`;
  }

  async function editMessageSafe(chatId, messageId, text, options = {}) {
    if (!messageId || typeof bot.editMessageText !== 'function') return null;
    try {
      return await bot.editMessageText(text, { chat_id: chatId, message_id: messageId, parse_mode: 'HTML', ...options });
    } catch (error) {
      console.error(`[STN] edit message failed ${chatId}:${messageId}:`, error.message);
      return null;
    }
  }

  async function autoDetectUserInfo(userId) {
    try {
      const chat = await bot.getChat(userId);
      const username = chat.username || '';
      const firstName = chat.first_name || '';
      const lastName = chat.last_name || '';
      const displayName = [firstName, lastName].filter(Boolean).join(' ') || username || `User_${userId}`;
      return { username, firstName, lastName, displayName, id: userId };
    } catch (e) {
      return { username: '', firstName: '', lastName: '', displayName: `User_${userId}`, id: userId };
    }
  }

  function saveVerifiedBuyer(userId, role, setoranId, extra = {}) {
    const verified = loadVerified();
    const key = String(userId);
    const prev = verified[key] || {};
    verified[key] = {
      ...prev, userId, role,
      roleLabel: ROLE_PRICES[role]?.label || role.toUpperCase(),
      setoranId,
      verifiedAt: new Date().toISOString(),
      ...extra
    };
    saveVerified(verified);
    console.log(`[STN] ✅ Verified buyer: ${userId} → ${role}`);
    return verified[key];
  }

  function getVerifiedBuyer(userId) {
    const verified = loadVerified();
    return verified[String(userId)] || null;
  }

  async function showSetoranIntro(chatId, messageId, userId) {
    setoranState.delete(userId);
    if (messageId) await animateLoading(chatId, messageId, "Mendeteksi data buyer");

    const buyer = detectBuyerType(userId);
    let title, desc, emoji;
    if (buyer.type === 'dp') {
      title = "SETORAN BUYER DP";
      desc = "Kamu terdeteksi sebagai Buyer dengan sistem <b>DP (Down Payment)</b>.";
      emoji = ce(EMOJI.money, '💸');
    } else if (buyer.type === 'full') {
      title = "SETORAN BUYER FULL";
      desc = "Kamu terdeteksi sebagai Buyer dengan <b>Full Payment</b>.";
      emoji = ce(EMOJI.check, '✅');
    } else {
      title = "SETORAN BUYER";
      desc = "Kamu belum terdeteksi sebagai buyer. Tenang, tetap bisa lanjut setoran manual.";
      emoji = ce(EMOJI.warning, '⚠️');
    }

    const record = buyer.record;
    const roleLabel = record ? (ROLE_PRICES[record.role]?.label || record.role?.toUpperCase()) : '-';

    const guideText = [
      richHeader(title, emoji),
      richPara(desc),
      richDiv(),
      richHeader("PANDUAN SETORAN WAJIB", ce(EMOJI.guide, '📖')),
      `<ol>`,
      `<li>Setiap pembeli <b>WAJIB</b> melakukan setoran bukti pembelian.</li>`,
      `<li>Klik <b>➡️ Lanjutkan Penyetoran</b> di bawah.</li>`,
      `<li>Kirim <b>FOTO bukti transfer</b> + <b>caption nominal</b> pembelian.</li>`,
      `<li>Bot akan menanyakan <b>DP</b> atau <b>FULL</b>.</li>`,
      `<li>Pilih <b>Role Target</b> yang kamu beli.</li>`,
      `<li>Admin akan memverifikasi setoran kamu.</li>`,
      `<li>Setelah di-ACC, bot auto-detect <b>ID + ROLE</b> kamu.</li>`,
      `<li>Kamu akan otomatis mendapat <b>group private</b> sesuai role.</li>`,
      `<li>Bukti setoran ditampilkan sebagai <b>testimoni</b> di group & channel.</li>`,
      `</ol>`,
      richDiv(),
      record ? richHeader("TRANSAKSI TERDETEKSI", ce(EMOJI.receipt, '🧾')) : '',
      record ? richTable([
        ["Role Dibeli", roleLabel],
        ["Total Harga", rp(ROLE_PRICES[record.role]?.price || 0)],
        ["Status Bayar", buyer.type === 'dp' ? '💸 DP SETENGAH' : '✅ FULL PAYMENT']
      ]) : richPara(`Silakan lanjut untuk setoran manual.`),
      richDiv(),
      richQuote(`${ce(EMOJI.gem, '💎')} <b>Mclaren Project</b> — Secure Payment System`),
      `<footer>© Mclaren Project • v7.0 True Ultra Merge</footer>`
    ].filter(Boolean).join('\n');

    const kb = {
      inline_keyboard: [
        [{ text: "➡️ Lanjutkan Penyetoran Buyer", callback_data: `stn_continue_${buyer.type}`, style: "success", icon_custom_emoji_id: EMOJI.next }],
        [{ text: "❌ Exit Penyetoran Buyer", callback_data: "stn_exit", style: "danger", icon_custom_emoji_id: EMOJI.exit }]
      ]
    };

    await sendOrEditRich(chatId, messageId, guideText, kb);
    setoranState.set(userId, { step: 'intro', buyerType: buyer.type, record: buyer.record });
  }

  async function proceedSetoran(chatId, messageId, userId, buyerType) {
    const st = setoranState.get(userId) || {};
    if (messageId) await animateLoading(chatId, messageId, "Menyiapkan form setoran");

    const record = st.record || null;
    const roleLabel = record ? (ROLE_PRICES[record.role]?.label || record.role?.toUpperCase()) : '-';

    const text = [
      richHeader("KIRIM BUKTI SETORAN", ce(EMOJI.bag, '📸')),
      richPara(`Silakan kirim <b>FOTO bukti transfer</b> + <b>caption nominal pembelian</b>.`),
      richDiv(),
      richHeader("FORMAT PENGIRIMAN", ce(EMOJI.guide, '📖')),
      richQuote(`1️⃣ Kirim <b>foto</b> bukti transfer.\n2️⃣ Tulis <b>caption nominal</b> (angka saja).\n\n<b>Contoh caption:</b> <code>15000</code> atau <code>30000</code>`),
      richDiv(),
      record ? richHeader("DETAIL TRANSAKSI", ce(EMOJI.receipt, '🧾')) : '',
      record ? richTable([
        ["Role", roleLabel],
        ["Total Harga", rp(ROLE_PRICES[record.role]?.price || 0)],
        ["Mode Bayar", record.mode === 'dp' ? '💸 DP' : '✅ FULL'],
        ["Sudah Bayar", rp(record.totalPaid || 0)],
        ["Sisa", rp(Math.max(0, (record.price || 0) - (record.totalPaid || 0)))]
      ]) : '',
      richDiv(),
      richQuote(`⏱️ Setelah dikirim, admin akan memverifikasi dalam <b>maks 5 menit</b>.`),
      `<footer>© Mclaren Project • Secure Payment System</footer>`
    ].filter(Boolean).join('\n');

    const targetPrompt = [
      richHeader("TARGET SETORAN", ce(EMOJI.target, '🎯')),
      richPara(`Sebelum kirim bukti, kirim <b>User ID Telegram target</b> yang akan menerima role di group.`),
      richDiv(),
      richQuote(`${ce(EMOJI.user, '👤')} <b>Contoh:</b> <code>123456789</code>\n\nID ini yang akan dipakai sistem untuk <b>detect saat join group</b>, lalu <b>tag / auto-promote</b> sesuai role.`),
      richDiv(),
      richQuote(`${ce(EMOJI.warning, '⚠️')} Pastikan ID benar. Setelah ACC, role akan dikaitkan ke ID target tersebut.`),
      `<footer>${ce(EMOJI.shield, '🛡️')} Target Binding • Mclaren Project</footer>`
    ].join('\n');

    await sendOrEditRich(chatId, messageId, targetPrompt, {
      inline_keyboard: [[
        { text: "❌ Batal Setoran", callback_data: "stn_exit", style: "danger", icon_custom_emoji_id: EMOJI.cross }
      ]]
    });

    setoranState.set(userId, { ...st, step: 'awaiting_target_id', buyerType: buyerType || st.buyerType, targetMsgId: messageId });
  }

  async function handleTargetIdInput(msg) {
    const requesterId = Number(msg.from?.id);
    const chatId = msg.chat?.id;
    const st = setoranState.get(requesterId);
    if (!st || st.step !== 'awaiting_target_id') return false;

    const raw = String(msg.text || '').trim().replace(/[\s`]/g, '');
    if (!/^\d+$/.test(raw)) {
      await bot.sendRichMessage(chatId, [
        richHeader("TARGET ID TIDAK VALID", ce(EMOJI.warning, '⚠️')),
        richPara(`Kirim <b>User ID Telegram berupa angka</b> saja.`),
        richQuote(`Contoh: <code>123456789</code>`)
      ].join('\n'), { parse_mode: 'HTML' });
      return true;
    }

    const targetUserId = Number(raw);
    if (!Number.isSafeInteger(targetUserId) || targetUserId <= 0) {
      await bot.sendRichMessage(chatId, [
        richHeader("TARGET ID TIDAK VALID", ce(EMOJI.warning, '⚠️')),
        richPara(`User ID harus berupa angka positif yang valid.`)
      ].join('\n'), { parse_mode: 'HTML' });
      return true;
    }

    const targetInfo = await autoDetectUserInfo(targetUserId);
    const targetLabel = targetInfo.username ? `@${targetInfo.username}` : targetInfo.displayName;
    const nextState = {
      ...st,
      step: 'awaiting_proof',
      targetUserId,
      targetUsername: targetInfo.username || '',
      targetDisplayName: targetInfo.displayName,
      targetMsgId: null
    };
    setoranState.set(requesterId, nextState);

    const nextText = [
      richHeader("TARGET TERKUNCI", ce(EMOJI.check, '✅')),
      richTable([
        ["Target", esc(targetLabel)],
        ["Target ID", `<code>${targetUserId}</code>`],
        ["Aksi Setelah ACC", "🏷️ AUTO-TAG / ⚡ AUTO-PROMOTE"]
      ]),
      richDiv(),
      richPara(`Sekarang kirim <b>FOTO bukti transfer</b> + <b>caption nominal</b>.`),
      richQuote(`Contoh caption: <code>15000</code>`),
      `<footer>${ce(EMOJI.lock, '🔒')} Role akan diterapkan ke Target ID ini.</footer>`
    ].join('\n');

    try {
      await bot.sendRichMessage(chatId, nextText, { parse_mode: 'HTML' });
    } catch (_) {}
    return true;
  }

  async function showPaymentModePicker(chatId, messageId, setId) {
    const pending = readJSON(PENDING_SETOR_FILE, {});
    const data = pending[setId];
    if (!data) return;

    const text = [
      richHeader("PILIH MODE PEMBAYARAN", ce(EMOJI.money, '💳')),
      richPara(`Bukti transfer kamu sudah diterima. Sekarang pilih <b>mode pembayaran</b>:`),
      richDiv(),
      richHeader("DETAIL SETORAN", ce(EMOJI.receipt, '🧾')),
      richTable([
        ["Setoran ID", setId],
        ["Nominal", rp(data.amount)],
        ["Bukti", "✅ Foto diterima"]
      ]),
      richDiv(),
      richHeader("PILIHAN MODE", ce(EMOJI.info, '📖')),
      richQuote(`💸 <b>DP (Down Payment)</b>\nBayar sebagian dulu, sisanya nanti.\n\n✅ <b>FULL PAYMENT</b>\nBayar lunas sekaligus.`),
      richDiv(),
      richQuote(`⚠️ Pilih salah satu untuk melanjutkan ke pemilihan <b>Role Target</b>.`),
      `<footer>© Mclaren Project • v7.0 True Ultra Merge</footer>`
    ].join('\n');

    await sendOrEditRich(chatId, messageId, text, {
      inline_keyboard: [
        [{ text: "💸 DP (Down Payment)", callback_data: `stn_mode_dp_${setId}`,   style: "primary", icon_custom_emoji_id: EMOJI.money }],
        [{ text: "✅ FULL PAYMENT",      callback_data: `stn_mode_full_${setId}`, style: "success", icon_custom_emoji_id: EMOJI.check }],
        [{ text: "❌ Batal",             callback_data: "stn_exit",                style: "danger",  icon_custom_emoji_id: EMOJI.cross }]
      ]
    });
  }

  async function showRolePicker(chatId, messageId, setId) {
    const pending = readJSON(PENDING_SETOR_FILE, {});
    const data = pending[setId];
    if (!data) return;

    const rows = [];
    const roleList = Object.keys(ROLE_PRICES);
    for (let i = 0; i < roleList.length; i += 2) {
      const row = [];
      for (let j = 0; j < 2 && i + j < roleList.length; j++) {
        const role = roleList[i + j];
        const info = ROLE_PRICES[role];
        row.push({
          text: `${info.emoji} ${info.label}`,
          callback_data: `stn_role_${setId}_${role}`,
          style: role === 'owner_utama' || role === 'owner' ? 'danger'
               : role === 'vip' || role === 'staff' ? 'success'
               : 'primary'
        });
      }
      rows.push(row);
    }

    rows.push([{
      text: "✏️ Role Custom (Ketik Manual)",
      callback_data: `stn_role_${setId}_custom`,
      style: "success"
    }]);

    rows.push([{
      text: "❌ Batal",
      callback_data: "stn_exit",
      style: "danger"
    }]);

    const text = [
      richHeader("PILIH ROLE TARGET", ce(EMOJI.target, '🎯')),
      richPara(`Pilih <b>role</b> yang kamu beli / targetkan:`),
      richDiv(),
      richHeader("DETAIL SETORAN", ce(EMOJI.receipt, '🧾')),
      richTable([
        ["Setoran ID", setId],
        ["Nominal", rp(data.amount)],
        ["Mode Bayar", data.buyerType === 'dp' || data.mode === 'dp' ? '💸 DP' : '✅ FULL']
      ]),
      richDiv(),
      richQuote(`💡 Pilih role dari tombol di bawah.\nKalau role kamu tidak ada di list, pilih <b>✏️ Role Custom</b>.`),
      `<footer>© Mclaren Project • v7.0 True Ultra Merge</footer>`
    ].join('\n');

    await sendOrEditRich(chatId, messageId, text, { inline_keyboard: rows });
  }

  async function handleCustomRoleInput(msg) {
    const userId = Number(msg.from.id);
    const chatId = msg.chat.id;
    const st = setoranState.get(userId);
    if (!st || st.step !== 'awaiting_custom_role') return false;

    const raw = (msg.text || '').trim();
    if (!raw || raw.length < 2) {
      await bot.sendRichMessage(chatId,
        [richHeader("INPUT TIDAK VALID", ce(EMOJI.warning, '⚠️')),
         richPara(`Ketik <b>nama role custom</b> minimal 2 karakter.`)].join('\n'),
        { parse_mode: 'HTML' });
      return true;
    }

    const setId = st.setId;
    await finalizeSetoranWithRole(chatId, st.waveMsgId || st.formMsgId, userId, setId, raw.toLowerCase(), true);
    return true;
  }

  async function finalizeSetoranWithRole(chatId, messageId, userId, setId, role, isCustom = false) {
    const pending = readJSON(PENDING_SETOR_FILE, {});
    const data = pending[setId];
    if (!data) {
      await bot.sendRichMessage(chatId,
        [richHeader("DATA HILANG", ce(EMOJI.cross, '❌')),
         richPara(`Setoran tidak ditemukan. Silakan ulangi dari menu.`)].join('\n'),
        { parse_mode: 'HTML' });
      return;
    }

    data.role = role;
    data.isCustomRole = isCustom;
    data.roleLabel = ROLE_PRICES[role]?.label || role.toUpperCase();
    data.status = 'pending';
    pending[setId] = data;
    writeJSON(PENDING_SETOR_FILE, pending);

    const userInfo = await autoDetectUserInfo(userId);
    const roleLabel = ROLE_PRICES[role]?.label || role.toUpperCase();

    const confirmText = [
      richHeader("SETORAN DIKIRIM KE ADMIN", ce(EMOJI.check, '✅')),
      richPara(`Bukti setoran kamu sudah dikirim ke admin untuk diverifikasi.`),
      richDiv(),
      richHeader("DETAIL SETORAN", ce(EMOJI.receipt, '🧾')),
      richTable([
        ["Setoran ID", setId],
        ["Nominal", rp(data.amount)],
        ["Mode Bayar", data.buyerType === 'dp' || data.mode === 'dp' ? '💸 DP' : '✅ FULL'],
        ["Role Target", `${ROLE_PRICES[role]?.emoji || '🎯'} ${roleLabel}`],
        ["Status", "⏳ MENUNGGU ACC OWNER"]
      ]),
      richDiv(),
      richQuote(`⏳ <i>Mohon tunggu, admin sedang memverifikasi bukti transfer kamu...</i>`),
      `<footer>© Mclaren Project • Secure Payment System</footer>`
    ].join('\n');

    await sendOrEditRich(chatId, messageId, confirmText, {
      inline_keyboard: [[
        { text: "❌ Batalkan Setoran", callback_data: `stn_cancel_pending_${setId}`, style: "danger" }
      ]]
    });

    const current = setoranState.get(userId) || {};
    setoranState.set(userId, { ...current, step: 'waiting_acc', setId, role, roleLabel });

    const ownerText = [
      richHeader("SETORAN BUYER BARU", ce(EMOJI.deposit, '💰')),
      richPara(`Ada setoran baru yang menunggu verifikasi!`),
      richDiv(),
      richHeader("DETAIL SETORAN", ce(EMOJI.receipt, '🧾')),
      richTable([
        ["Setoran ID", setId],
        ["User", userInfo.username ? `@${userInfo.username}` : userInfo.displayName],
        ["Payer ID", String(userId)],
        ["Target ID", String(data.targetUserId)],
        ["Target", data.targetUsername ? `@${data.targetUsername}` : (data.targetDisplayName || `User_${data.targetUserId}`)],
        ["Role Target", `${ROLE_PRICES[role]?.emoji || '🎯'} ${roleLabel}`],
        ["Tipe Buyer", data.buyerType === 'dp' || data.mode === 'dp' ? '💸 DP SETENGAH' : '✅ FULL PAYMENT'],
        ["Nominal", rp(data.amount)],
        ["Waktu", new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })]
      ]),
      richDiv(),
      richQuote(`👇 Silakan verifikasi bukti setoran di bawah ini.`),
      `<footer>© Mclaren Project • Owner Verification Required</footer>`
    ].join('\n');

    const kb = {
      inline_keyboard: [[
        { text: "✅ ACC Setoran", callback_data: `stn_acc_${setId}`, style: "success", icon_custom_emoji_id: EMOJI.check },
        { text: "❌ Tolak",       callback_data: `stn_rej_${setId}`, style: "danger",  icon_custom_emoji_id: EMOJI.cross }
      ]]
    };

    await sendNotifToOwners(data.fileId, ownerText, kb);
  }

  async function handleSetoranProof(msg) {
    const userId = Number(msg.from.id);
    const chatId = msg.chat.id;
    const st = setoranState.get(userId);
    if (!st || st.step !== 'awaiting_proof') return false;

    if (!msg.photo || !msg.photo.length) {
      await bot.sendRichMessage(chatId,
        [richHeader("KIRIM FOTO", ce(EMOJI.warning, '⚠️')),
         richPara(`Harap kirim bukti transfer dalam bentuk <b>FOTO</b>.`)].join('\n'),
        { parse_mode: 'HTML' });
      return true;
    }

    const caption = (msg.caption || '').trim();
    const amount = parseInt(caption.replace(/[^\d]/g, ''), 10);

    if (!amount || amount <= 0) {
      await bot.sendRichMessage(chatId,
        [richHeader("NOMINAL TIDAK VALID", ce(EMOJI.warning, '⚠️')),
         richPara(`Kirim ulang <b>foto + caption nominal</b>.`),
         richQuote(`Contoh caption: <code>15000</code>`)].join('\n'),
        { parse_mode: 'HTML' });
      return true;
    }

    const fileId = msg.photo[msg.photo.length - 1].file_id;
    const setId  = `STN-${Date.now().toString(36).toUpperCase()}`;

    const userInfo = await autoDetectUserInfo(userId);
    const targetUserId = Number(st.targetUserId);
    if (!Number.isSafeInteger(targetUserId) || targetUserId <= 0) {
      await bot.sendRichMessage(chatId, [
        richHeader("TARGET ID BELUM DIISI", ce(EMOJI.warning, '⚠️')),
        richPara(`Setoran <b>wajib</b> memiliki Target Telegram User ID.`),
        richQuote(`Kirim kembali User ID target berupa angka. Contoh: <code>123456789</code>`)
      ].join('\n'), { parse_mode: 'HTML' });
      setoranState.set(userId, { ...st, step: 'awaiting_target_id' });
      return true;
    }

    const pending = readJSON(PENDING_SETOR_FILE, {});
    pending[setId] = {
      setId, userId,
      username: userInfo.username || userInfo.displayName || `User_${userId}`,
      displayName: userInfo.displayName,
      firstName: userInfo.firstName,
      amount, fileId, caption,
      buyerType: st.buyerType,
      record: st.record || null,
      targetUserId: st.targetUserId,
      targetUsername: st.targetUsername || '',
      targetDisplayName: st.targetDisplayName || '',
      chatId,
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    writeJSON(PENDING_SETOR_FILE, pending);

    const receivedText = [
      richHeader("BUKTI TRANSAKSI DITERIMA", ce(EMOJI.check, '✅')),
      richPara(`${ce(EMOJI.verify, '☑️')} Sistem berhasil menerima foto bukti transaksi kamu.`),
      richDiv(),
      richTable([
        ["User ID", String(userId)],
        ["Setoran ID", setId],
        ["Nominal", rp(amount)],
        ["Status", "✅ FOTO DITERIMA & TERCATAT"]
      ]),
      richDiv(),
      richQuote(`${ce(EMOJI.info, 'ℹ️')} <b>Langkah berikutnya:</b> pilih mode pembayaran lalu tentukan role target.`),
      `<footer>${ce(EMOJI.lock, '🔒')} Secure Setoran System • Mclaren Project</footer>`
    ].join('\n');

    const edited = await editMessageSafe(chatId, st.formMsgId, receivedText, { reply_markup: { inline_keyboard: [] } });
    const modeMsg = edited?.message_id
      ? edited
      : await bot.sendRichMessage(chatId, receivedText, { parse_mode: 'HTML' });

    setoranState.set(userId, {
      ...st, step: 'choosing_mode', setId, buyerType: st.buyerType, record: st.record,
      formMsgId: modeMsg?.message_id || st.formMsgId || null
    });

    await showPaymentModePicker(chatId, modeMsg?.message_id || null, setId);
    return true;
  }

  function safeReadPending(setId) {
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        if (fs.existsSync(PENDING_SETOR_FILE)) {
          const raw = fs.readFileSync(PENDING_SETOR_FILE, 'utf8');
          const data = JSON.parse(raw);
          if (data && data[setId]) return data[setId];
        }
      } catch (e) {
        console.error(`[STN] safeReadPending attempt ${attempt}:`, e.message);
      }
    }
    return null;
  }

  async function handleAccReject(query, setId, isAcc) {
    const userId = Number(query.from.id);

    if (!isOwnerAcc(userId)) {
      return bot.answerCallbackQuery(query.id, {
        text: "❌ Kamu tidak terdaftar di owner_acc.json!", show_alert: true
      }).catch(() => {});
    }

    const data = safeReadPending(setId);
    if (!data) {
      return bot.answerCallbackQuery(query.id, {
        text: `❌ Setoran ${setId} tidak ditemukan.`, show_alert: true
      }).catch(() => {});
    }

    if (data.status === 'accepted' || data.status === 'rejected') {
      return bot.answerCallbackQuery(query.id, {
        text: `⚠️ Sudah di-${data.status === 'accepted' ? 'ACC' : 'TOLAK'}.`, show_alert: true
      }).catch(() => {});
    }

    const stUser = setoranState.get(data.userId);
    if (stUser && stUser.waveInterval) clearInterval(stUser.waveInterval);

    const info = ROLE_PRICES[data.role] || {};

    if (!isAcc) {
      data.status = 'rejected';
      data.rejectedAt = new Date().toISOString();
      data.rejectedBy = query.from.username || String(userId);

      const pendingAll = readJSON(PENDING_SETOR_FILE, {});
      pendingAll[setId] = data;
      writeJSON(PENDING_SETOR_FILE, pendingAll);

      setoranState.delete(data.userId);
      if (data.targetUserId && Number(data.targetUserId) !== Number(data.userId)) {
        setoranState.delete(Number(data.targetUserId));
      }

      try {
        await bot.sendRichMessage(data.chatId,
          [richHeader("SETORAN DITOLAK", ce(EMOJI.cross, '❌')),
           richPara(`Maaf, bukti setoran kamu <b>ditolak</b>.`),
           richDiv(),
           richQuote(`Silakan kirim ulang bukti setoran yang valid.`)].join('\n'),
          { parse_mode: 'HTML', reply_markup: {
            inline_keyboard: [
              [{ text: "🔄 Coba Lagi", callback_data: "stn_menu", style: "success", icon_custom_emoji_id: EMOJI.next }],
              [{ text: "❌ Exit", callback_data: "stn_exit", style: "danger", icon_custom_emoji_id: EMOJI.exit }]
            ]
          }});
      } catch (_) {}

      try {
        await bot.editMessageCaption(
          (query.message.caption || '') + `\n\n<b>❌ REJECTED by @${esc(query.from.username || userId)}</b>`,
          { chat_id: query.message.chat.id, message_id: query.message.message_id, parse_mode: 'HTML' });
        await bot.editMessageReplyMarkup({ inline_keyboard: [] }, { chat_id: query.message.chat.id, message_id: query.message.message_id });
      } catch (_) {}

      return bot.answerCallbackQuery(query.id, { text: "❌ Ditolak." }).catch(() => {});
    }

    data.status = 'accepted';
    data.acceptedAt = new Date().toISOString();
    data.acceptedBy = query.from.username || String(userId);

    const pendingAll = readJSON(PENDING_SETOR_FILE, {});
    pendingAll[setId] = data;
    writeJSON(PENDING_SETOR_FILE, pendingAll);

    const targetUserId = Number(data.targetUserId || data.userId);
    const targetInfo = await autoDetectUserInfo(targetUserId);
    const userInfo = await autoDetectUserInfo(data.userId);

    try {
      const pembeli = readJSON(PEMBELI_FILE, []);
      const idx = pembeli.findIndex(p => p.txnId === data.record?.txnId);
      if (idx !== -1) {
        pembeli[idx].setoranVerified = true;
        pembeli[idx].setoranVerifiedAt = new Date().toISOString();
        pembeli[idx].setoranAmount = data.amount;
        pembeli[idx].setoranProofId = data.fileId;
        writeJSON(PEMBELI_FILE, pembeli);
      }
    } catch (e) { console.error('[STN] update pembeli:', e.message); }

    const roleTarget = data.role || data.record?.role || 'member';
    saveVerifiedBuyer(targetUserId, roleTarget, setId, {
      username: targetInfo.username,
      payerUserId: data.userId,
      payerUsername: userInfo.username,
      displayName: userInfo.displayName,
      firstName: userInfo.firstName,
      mode: data.mode || data.buyerType || 'full',
      price: ROLE_PRICES[roleTarget]?.price || 0,
      totalPaid: data.amount
    });

    const roleLabel = info.label || roleTarget.toUpperCase();

    const links = loadGroupLinks();
    const accessible = getAccessibleRoles(roleTarget);
    const groupButtons = [];
    const accessibleLabels = [];
    for (const r of accessible) {
      const link = links[r];
      if (link && typeof link === 'string' && link.startsWith('http')) {
        groupButtons.push([{
          text: `🔗 ${ROLE_PRICES[r]?.label || r.toUpperCase()}`,
          url: link, style: "primary", icon_custom_emoji_id: EMOJI.group
        }]);
        accessibleLabels.push(ROLE_PRICES[r]?.label || r.toUpperCase());
      }
    }

    try {
      await bot.sendRichMessage(data.chatId,
        [richHeader("SETORAN DIVERIFIKASI", ce(EMOJI.check, '🎉')),
         richPara(`Selamat! Setoran kamu telah <b>diverifikasi</b> oleh admin.`),
         richDiv(),
         richHeader("DETAIL VERIFIKASI", ce(EMOJI.receipt, '🧾')),
         richTable([
           ["Setoran ID", setId],
           ["Target ID", String(targetUserId)],
           ["Nominal", rp(data.amount)],
           ["Role", roleLabel],
           ["Status", "✅ TERVERIFIKASI"]
         ]),
         richDiv(),
         richHeader("AKSES GROUP PRIVATE", ce(EMOJI.group, '🔗')),
         richPara(`Silakan join group private sesuai role kamu:`),
         `<ul>`,
         ...accessibleLabels.map(l => `<li>${esc(l)}</li>`),
         `</ul>`,
         richDiv(),
         richQuote(`⚠️ <b>Setelah join, kamu akan di-tag oleh bot sebagai <code>[${(ROLE_TAG_PREFIX[roleTarget] || roleLabel)}]</code>.</b>`),
         richDiv(),
         richPara(`👇 Klik tombol di bawah:`)
        ].join('\n'),
        { parse_mode: 'HTML', reply_markup: {
          inline_keyboard: [
            ...groupButtons,
            [{ text: "📝 Create Akun Sekarang", callback_data: `stn_create_${setId}`, style: "success", icon_custom_emoji_id: EMOJI.next }],
            [{ text: "⏰ Nanti Saja",           callback_data: `stn_later_${setId}`,  style: "primary", icon_custom_emoji_id: EMOJI.clock }]
          ]
        }});
    } catch (e) { console.error('[STN] success user:', e.message); }

    setoranState.delete(data.userId);
    if (targetUserId !== data.userId) setoranState.delete(targetUserId);

    // 🔥 BROADCAST TESTIMONI — pakai sendTestimonialPhoto (GABUNG 100%)
    broadcastTestimonial(setId, data, userInfo)
      .catch(e => console.error('[STN] broadcastTestimonial error:', e.message));

    try {
      await bot.editMessageCaption(
        (query.message.caption || '') + `\n\n<b>✅ ACCEPTED by @${esc(query.from.username || userId)}</b>`,
        { chat_id: query.message.chat.id, message_id: query.message.message_id, parse_mode: 'HTML' });
      await bot.editMessageReplyMarkup({ inline_keyboard: [] }, { chat_id: query.message.chat.id, message_id: query.message.message_id });
    } catch (_) {}

    return bot.answerCallbackQuery(query.id, { text: "✅ ACC! User auto-verified." }).catch(() => {});
  }

  // ═══════════════════════════════════════════════════════════
  // 📢 BROADCAST TESTIMONI — TRUE ULTRA MERGE
  // ═══════════════════════════════════════════════════════════
  async function broadcastTestimonial(setId, data, userInfo) {
    const fileId = data.fileId;

    const chatTargets = new Set();
    if (ADMIN_GROUP_ID) chatTargets.add(String(ADMIN_GROUP_ID));
    if (CHANNEL_ID)     chatTargets.add(String(CHANNEL_ID));

    try {
      const chats = loadBotChats();
      for (const id of Object.keys(chats)) chatTargets.add(String(id));
    } catch (_) {}

    chatTargets.delete(String(data.chatId));

    console.log(`[STN] 📢 Broadcasting testimonial ${setId} → ${chatTargets.size} chats + users...`);

    for (const chatId of chatTargets) {
      try {
        let canSend = true;
        try { await bot.getChat(chatId); }
        catch (err) {
          if (err.message && (err.message.includes('member') || err.message.includes('not found'))) {
            canSend = false;
            console.log(`[STN] ⏭️ Skip ${chatId}: bot bukan member`);
          }
        }
        if (canSend) {
          // 🔥 PAKAI sendTestimonialPhoto — FOTO + TEKS GABUNG 100%
          await sendTestimonialPhoto(chatId, fileId, setId, data, userInfo);
        }
      } catch (e) {
        console.log(`[STN] ⏭️ Skip chat ${chatId}: ${e.message}`);
      }
      await sleep(300);
    }

    try {
      const users = loadBotUsers();
      for (const [uid, _info] of Object.entries(users)) {
        if (Number(uid) === Number(data.userId)) continue;
        if (chatTargets.has(String(uid))) continue;
        try {
          await sendTestimonialPhoto(uid, fileId, setId, data, userInfo);
        } catch (e) {
          console.log(`[STN] ⏭️ Skip user ${uid}: ${e.message}`);
        }
        await sleep(150);
      }
    } catch (e) {
      console.error('[STN] broadcast users:', e.message);
    }

    console.log(`[STN] ✅ Broadcast testimonial ${setId} selesai.`);
  }

  async function handleGroupJoin(chatId, userId) {
    try {
      const verified = getVerifiedBuyer(userId);
      if (!verified) return;

      const role = String(verified.role || 'member');
      const roleInfo = ROLE_PRICES[role] || { label: role.toUpperCase(), emoji: '👤' };
      const tagPrefix = ROLE_TAG_PREFIX[role] || `👤 ${roleInfo.label.toUpperCase()}`;
      const userInfo = await autoDetectUserInfo(userId);
      const mention = buildUserMention(userId, userInfo);
      const shouldPromote = PROMOTE_ROLES.includes(role);

      const welcomeText = [
        richHeader("MEMBER VERIFIED TERDETEKSI", ce(EMOJI.verify, '☑️')),
        richPara(`${mention} telah masuk ke group dan berhasil dideteksi oleh sistem.`),
        richDiv(),
        richTable([
          ["Role", `${roleInfo.emoji || '👤'} ${roleInfo.label}`],
          ["Tag Sistem", tagPrefix],
          ["User ID", String(userId)],
          ["Setoran ID", verified.setoranId || '-'],
          ["Aksi", shouldPromote ? "⚡ AUTO-PROMOTE" : "🏷️ AUTO-TAG"]
        ]),
        richDiv(),
        richQuote(shouldPromote
          ? `${ce(EMOJI.crown, '👑')} Role <b>${esc(roleInfo.label)}</b> masuk kategori auto-promote.`
          : `${ce(EMOJI.user, '👤')} Role <b>${esc(roleInfo.label)}</b> hanya ditandai sesuai role dan tidak dipromote.`),
        `<footer>${ce(EMOJI.shield, '🛡️')} Mclaren Project • Role Detection System</footer>`
      ].join('\n');

      try { await bot.sendRichMessage(chatId, welcomeText, { parse_mode: 'HTML' }); }
      catch (error) { console.error(`[STN] group welcome failed ${chatId}:${userId}:`, error.message); }

      let promoted = false;
      if (shouldPromote) {
        try {
          await bot.promoteChatMember(chatId, userId, {
            can_manage_chat: true, can_delete_messages: true, can_manage_video_chats: true,
            can_restrict_members: true, can_promote_members: false, can_change_info: false,
            can_invite_users: true, can_pin_messages: true, can_post_messages: false, can_edit_messages: false
          });
          promoted = true;
        } catch (error) {
          console.error(`[STN] auto-promote failed ${chatId}:${userId}:`, error.message);
        }
      }

      try {
        await bot.sendRichMessage(chatId, [
          richHeader(promoted ? "AUTO-PROMOTE BERHASIL" : "ROLE AUTO-TAG", promoted ? ce(EMOJI.crown, '👑') : ce(EMOJI.user, '👤')),
          richPara(promoted
            ? `${ce(EMOJI.crown, '👑')} ${mention} <b>${esc(tagPrefix)}</b> telah otomatis di-promote.`
            : `${ce(EMOJI.user, '👤')} ${mention} ditandai sebagai <b>${esc(tagPrefix)}</b>.`),
          richDiv(),
          richTable([["User ID", String(userId)], ["Role", roleInfo.label], ["Status", promoted ? "✅ PROMOTED" : "✅ TAGGED / VERIFIED"]])
        ].join('\n'), { parse_mode: 'HTML' });
      } catch (error) {
        console.error(`[STN] group action message failed ${chatId}:${userId}:`, error.message);
      }

      const all = loadVerified();
      if (all[String(userId)]) {
        all[String(userId)] = { ...all[String(userId)], groupJoinedAt: new Date().toISOString(), lastJoinedChatId: chatId, promoted };
        saveVerified(all);
      }
    } catch (error) {
      console.error(`[STN] handleGroupJoin failed ${chatId}:${userId}:`, error.message);
    }
  }

  async function handleCreateOrLater(query, setId, action) {
    const pending = readJSON(PENDING_SETOR_FILE, {});
    const data = pending[setId];
    if (!data) {
      return bot.answerCallbackQuery(query.id, { text: "❌ Data tidak ditemukan.", show_alert: true }).catch(() => {});
    }

    if (action === 'create') {
      try {
        await bot.sendRichMessage(data.userId,
          [richHeader("PILIH METODE CREATE AKUN", ce(EMOJI.user, '📝')),
           richPara(`Klik tombol di bawah untuk memilih metode:`)].join('\n'),
          { parse_mode: 'HTML', reply_markup: {
            inline_keyboard: [[
              { text: "📝 Manual Custom", callback_data: "create_method_manual", style: "primary", icon_custom_emoji_id: EMOJI.next },
              { text: "⚡ Otomatis",     callback_data: "create_method_auto",   style: "success", icon_custom_emoji_id: EMOJI.check }
            ]]
          }});
      } catch (_) {}
    } else {
      try {
        await bot.sendRichMessage(data.userId,
          [richHeader("BAIK, NANTI SAJA", ce(EMOJI.clock, '⏰')),
           richPara(`Kamu bisa buat akun kapan saja lewat <code>/create</code>.`)].join('\n'),
          { parse_mode: 'HTML' });
      } catch (_) {}
    }

    return bot.answerCallbackQuery(query.id, {
      text: action === 'create' ? "✅ Lanjut create." : "⏰ Nanti saja."
    }).catch(() => {});
  }

  async function handleCallback(query) {
    try {
      if (query.from) trackUser(query.from);
      if (query.message && query.message.chat) trackChat(query.message.chat);
    } catch (_) {}

    const userId    = Number(query.from.id);
    const chatId    = query.message.chat.id;
    const messageId = query.message.message_id;
    const data      = query.data || "";

    if (!data.startsWith('stn_')) return false;

    if (data === 'stn_addc_cancel') {
      setoranState.delete(userId);
      await sendOrEditRich(chatId, messageId, buildAddOwnerAccessRich(
        'ADD SETORAN ACC DIBATALKAN',
        `Proses penambahan akses owner dihentikan tanpa mengubah <code>owner_acc.json</code>.`,
        [['Status', '⚪ CANCELLED']],
        'warning'
      ));
      await bot.answerCallbackQuery(query.id, { text: '⚪ Add Setoran Acc dibatalkan.' }).catch(() => {});
      return true;
    }

    if (data === 'stn_addc') {
      if (!isGroupChat(query.message.chat) || !isOwnerOperator(userId)) {
        await bot.answerCallbackQuery(query.id, { text: '🔒 Owner + Group only.', show_alert: true }).catch(() => {});
        return true;
      }
      await promptAddOwnerAccess(chatId, messageId);
      setoranState.set(userId, { step: 'awaiting_owner_acc_id', addOwnerAccMsgId: messageId, addOwnerAccChatId: chatId, createdAt: Date.now() });
      return true;
    }

    if (data.startsWith('stn_acc_')) return handleAccReject(query, data.replace('stn_acc_', ''), true);
    if (data.startsWith('stn_rej_')) return handleAccReject(query, data.replace('stn_rej_', ''), false);

    if (data.startsWith('stn_create_')) return handleCreateOrLater(query, data.replace('stn_create_', ''), 'create');
    if (data.startsWith('stn_later_'))  return handleCreateOrLater(query, data.replace('stn_later_', ''), 'later');

    if (data === 'stn_menu') {
      await showSetoranIntro(chatId, messageId, userId);
      return true;
    }

    if (data === 'stn_exit') {
      const st = setoranState.get(userId);
      if (st && st.waveInterval) clearInterval(st.waveInterval);
      setoranState.delete(userId);
      await animateLoading(chatId, messageId, "Kembali ke menu utama");
      try { await bot.deleteMessage(chatId, messageId); } catch (_) {}
      try { await sendMainMenuSafe(chatId); } catch (_) {}
      return true;
    }

    if (data.startsWith('stn_continue_')) {
      const buyerType = data.replace('stn_continue_', '');
      await proceedSetoran(chatId, messageId, userId, buyerType);
      return true;
    }

    if (data.startsWith('stn_mode_')) {
      const parts = data.split('_');
      const mode = parts[2];
      const setId = parts.slice(3).join('_');

      const pending = readJSON(PENDING_SETOR_FILE, {});
      const item = pending[setId];
      if (!item) {
        await bot.answerCallbackQuery(query.id, { text: "❌ Data setoran hilang.", show_alert: true }).catch(() => {});
        return true;
      }

      item.mode = mode;
      item.buyerType = mode;
      pending[setId] = item;
      writeJSON(PENDING_SETOR_FILE, pending);

      const st = setoranState.get(userId) || {};
      setoranState.set(userId, { ...st, step: 'choosing_role', setId, mode });

      await showRolePicker(chatId, messageId, setId);
      return true;
    }

    if (data.startsWith('stn_role_')) {
      const rest = data.replace('stn_role_', '');
      let setId = null, role = null;
      const stnMatch = rest.match(/^(STN-[A-Z0-9]+)_(.*)/);
      if (stnMatch) {
        setId = stnMatch[1];
        role  = stnMatch[2];
      } else {
        await bot.answerCallbackQuery(query.id, { text: "❌ Format tidak valid.", show_alert: true }).catch(() => {});
        return true;
      }

      if (!setId || !role) {
        await bot.answerCallbackQuery(query.id, { text: "❌ Data tidak lengkap.", show_alert: true }).catch(() => {});
        return true;
      }

      const pending = readJSON(PENDING_SETOR_FILE, {});
      const item = pending[setId];
      if (!item) {
        await bot.answerCallbackQuery(query.id, { text: "❌ Setoran tidak ditemukan.", show_alert: true }).catch(() => {});
        return true;
      }

      if (role === 'custom') {
        const st = setoranState.get(userId) || {};
        setoranState.set(userId, { ...st, step: 'awaiting_custom_role', setId, waveMsgId: messageId });
        await sendOrEditRich(chatId, messageId,
          [richHeader("ROLE CUSTOM", '✏️'),
           richPara(`Ketik <b>nama role custom</b> yang kamu inginkan.`),
           richDiv(),
           richQuote(`Contoh: <code>partner_new</code>, <code>special_member</code>`)].join('\n'),
          { inline_keyboard: [[
            { text: "❌ Batal", callback_data: "stn_exit", style: "danger" }
          ]] });
        return true;
      }

      await finalizeSetoranWithRole(chatId, messageId, userId, setId, role, false);
      return true;
    }

    if (data.startsWith('stn_cancel_pending_')) {
      const setId = data.replace('stn_cancel_pending_', '');
      const pending = readJSON(PENDING_SETOR_FILE, {});
      if (pending[setId]) {
        pending[setId].status = 'cancelled';
        pending[setId].cancelledAt = new Date().toISOString();
        writeJSON(PENDING_SETOR_FILE, pending);
      }
      setoranState.delete(userId);
      await sendOrEditRich(chatId, messageId,
        [richHeader("SETORAN DIBATALKAN", ce(EMOJI.cross, '❌')),
         richPara(`Setoran kamu telah dibatalkan.`)].join('\n'),
        { inline_keyboard: [[
          { text: "🔁 Mulai Lagi", callback_data: "stn_menu", style: "success" }
        ]] });
      return true;
    }

    return true;
  }

  async function handleMessage(msg) {
    if (!msg || !msg.from) return false;

    try {
      trackUser(msg.from);
      if (msg.chat) trackChat(msg.chat);
    } catch (_) {}

    if (msg.new_chat_members && msg.new_chat_members.length) {
      for (const member of msg.new_chat_members) {
        if (member.is_bot) continue;
        const joinedId = Number(member.id);
        await handleGroupJoin(msg.chat.id, joinedId);
      }
      return true;
    }

    const userId = Number(msg.from.id);

    if (msg.text && /^\/addc(?:@\w+)?$/i.test(String(msg.text).trim())) {
      return handleAddOwnerAccessCommand(msg);
    }

    const st = setoranState.get(userId);
    if (!st) return false;

    if (st.step === 'awaiting_owner_acc_id' && msg.text) {
      return handleAddOwnerAccessInput(msg);
    }

    if (st.step === 'awaiting_custom_role' && msg.text) {
      await handleCustomRoleInput(msg);
      return true;
    }

    if (st.step === 'awaiting_target_id' && msg.text) {
      return handleTargetIdInput(msg);
    }

    if (st.step === 'awaiting_proof' && msg.photo && msg.photo.length) {
      await handleSetoranProof(msg);
      return true;
    }

    return false;
  }

  let sendMainMenuSafe = async (chatId) => {
    try { await bot.sendRichMessage(chatId, "🏠 Ketik /menu untuk membuka menu utama.", { parse_mode: 'HTML' }); }
    catch (_) {}
  };
  function setMainMenuSender(fn) { if (typeof fn === 'function') sendMainMenuSafe = fn; }

  return {
    handleCallback,
    handleMessage,
    showSetoranIntro,
    handleGroupJoin,
    getVerifiedBuyer,
    saveVerifiedBuyer,
    setMainMenuSender,
    broadcastTestimonial,
    loadBotUsers,
    getLayananButtons: (userId, chat = {}) => (isOwnerOperator(userId) && isGroupChat(chat) ? [[{
      text: '🔐 Add Setoran Acc',
      callback_data: 'stn_addc',
      style: 'danger',
      icon_custom_emoji_id: EMOJI.key
    }]] : []),
    handleAddOwnerAccessCommand,
    loadBotChats,
  };
};