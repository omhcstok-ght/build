import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'music_page.dart';
import 'package:otax/anime_page.dart';
import 'package:provider/provider.dart';
import 'package:otax/ui/models/providers/appProvider.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'bug_group_page.dart';
import 'enak_page.dart';
import 'ai_page.dart';
import 'fakestory.dart';
import 'faketweet.dart';
import 'iqc.dart';
import 'cpanel.dart';
import 'colong.dart';
import 'ff.dart';
import 'packman.dart';
import 'ular.dart';
import 'gameotax.dart';
import 'tourl.dart';
import 'controller.dart';
import 'dart:math' as math;
import 'auto_detect_page.dart';
import 'create_vps_page.dart';
import 'install_panel_page.dart';
import 'webapk.dart';

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final String username;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.username,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  late final AnimationController _glowController;
  late final Animation<double> _glowAnimation;

  // Palet Warna Baru (Manta Tools Style)
  static const Color bgDark = Color(0xFF0A0A0A);
  static const Color cardDark = Color(0xFF141414);
  static const Color cardBorder = Color(0xFF2A2A2A);
  static const Color accentOrange = Color(0xFFFF6B00); // Oranye/Emas
  static const Color accentOrangeDark = Color(0xFFCC5500);
  static const Color textWhite = Color(0xFFFFFFFF);
  static const Color textGrey = Color(0xFF9E9E9E);

  static const List<_ToolCategory> _categories = [
    _ToolCategory(
      icon: Icons.cloud_outlined,
      title: "Panel",
      subtitle: "Manajemen server",
      tag: "Deploy",
    ),
    _ToolCategory(
      icon: Icons.sports_esports_outlined,
      title: "Game & AI",
      subtitle: "Catur, pacman, asisten",
      tag: "Play",
    ),
    _ToolCategory(
      icon: Icons.flash_on_outlined,
      title: "DDoS",
      subtitle: "Stress test",
      tag: "Drain",
    ),
    _ToolCategory(
      icon: Icons.wifi_outlined,
      title: "Network",
      subtitle: "WiFi, spam",
      tag: "Net",
    ),
    _ToolCategory(
      icon: Icons.search_outlined,
      title: "OSINT",
      subtitle: "NIK, domain, telepon",
      tag: "Search",
    ),
    _ToolCategory(
      icon: Icons.download_outlined,
      title: "Downloader",
      subtitle: "TikTok, Instagram",
      tag: "Save",
    ),
    _ToolCategory(
      icon: Icons.build_outlined,
      title: "OTAXRAT",
      subtitle: "Rat Malware",
      tag: "RAT",
    ),
    _ToolCategory(
      icon: Icons.rocket_launch_outlined,
      title: "Generator",
      subtitle: "Quote, fake story",
      tag: "Gen",
    ),
    _ToolCategory(
      icon: Icons.auto_awesome_outlined,
      title: "Anime",
      subtitle: "Streaming, 18+",
      tag: "Watch",
    ),
  ];

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      duration: const Duration(seconds: 4),
      vsync: this,
    )..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOutSine),
    );
  }

  @override
  void dispose() {
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Stack(
        children: [
          // Background Mobil
          Positioned.fill(
            child: Image.asset(
              'assets/images/mantac.jpg',
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                // Fallback jika gambar tidak ditemukan
                return Container(color: bgDark);
              },
            ),
          ),
          // Overlay Gelap agar teks terbaca
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    bgDark.withOpacity(0.7),
                    bgDark.withOpacity(0.95),
                    bgDark,
                  ],
                  stops: const [0.0, 0.5, 1.0],
                ),
              ),
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.only(bottom: 40),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildTopHeader(),
                  const SizedBox(height: 30),
                  _buildHeroCard(),
                  const SizedBox(height: 20),
                  _buildStatsRow(),
                  const SizedBox(height: 30),
                  _buildSectionTitle(),
                  const SizedBox(height: 16),
                  _buildGrid(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
      child: Row(
        children: [
          // Logo Manta Tools
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: cardDark,
              shape: BoxShape.circle,
              border: Border.all(color: cardBorder),
            ),
            child: Center(
              child: Icon(Icons.android, color: accentOrange, size: 20),
            ),
          ),
          const Spacer(),
          // Role Badge
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: cardDark,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: cardBorder),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.circle, color: accentOrange, size: 8),
                const SizedBox(width: 6),
                Text(
                  widget.userRole.toUpperCase(),
                  style: TextStyle(
                    color: accentOrange,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.0,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: cardBorder),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.wifi_tethering, color: accentOrange, size: 18),
                    const SizedBox(width: 8),
                    Text(
                      "MANTA TOOLS",
                      style: TextStyle(
                        color: accentOrange,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                const Text(
                  "Menu Manta",
                  style: TextStyle(
                    color: textWhite,
                    fontSize: 28,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  "Pusat akses berbagai menu aplikasi Manta untuk kebutuhan harian Anda.",
                  style: TextStyle(
                    color: textGrey,
                    fontSize: 13,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(color: cardBorder),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildHeroStat("ROLE", widget.userRole.toUpperCase()),
                _buildHeroStat("JUMLAH MENU", "${_categories.length} TOOLS"),
                _buildHeroStat("SESSION", "READY"),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroStat(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: textGrey,
            fontSize: 10,
            fontWeight: FontWeight.w600,
            letterSpacing: 0.8,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            color: textWhite,
            fontSize: 13,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }

  Widget _buildStatsRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          _buildMiniStatCard(Icons.bolt, "13", "Tools"),
          const SizedBox(width: 12),
          _buildMiniStatCard(Icons.shield, "OWNER", "Akses"),
          const SizedBox(width: 12),
          _buildMiniStatCard(Icons.access_time, "24/7", "Online"),
        ],
      ),
    );
  }

  Widget _buildMiniStatCard(IconData icon, String value, String label) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(
          color: cardDark,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: cardBorder),
        ),
        child: Column(
          children: [
            Icon(icon, color: accentOrange, size: 20),
            const SizedBox(height: 6),
            Text(
              value,
              style: const TextStyle(
                color: textWhite,
                fontSize: 14,
                fontWeight: FontWeight.w700,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                color: textGrey,
                fontSize: 10,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          const Text(
            "KATEGORI MENU",
            style: TextStyle(
              color: textWhite,
              fontSize: 16,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.0,
            ),
          ),
          const Spacer(),
          Text(
            "${_categories.length} Modules",
            style: TextStyle(
              color: accentOrange,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGrid() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: _categories.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 1.1,
        ),
        itemBuilder: (context, index) {
          final category = _categories[index];
          return _buildMantaCard(category);
        },
      ),
    );
  }

  Widget _buildMantaCard(_ToolCategory category) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => _onCategoryTap(context, category),
        borderRadius: BorderRadius.circular(16),
        splashColor: accentOrange.withOpacity(0.1),
        highlightColor: Colors.transparent,
        child: Container(
          decoration: BoxDecoration(
            color: cardDark,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: cardBorder),
          ),
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: bgDark,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: cardBorder),
                    ),
                    child: Icon(category.icon, color: accentOrange, size: 20),
                  ),
                  if (category.tag != null)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: bgDark,
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: cardBorder),
                      ),
                      child: Text(
                        category.tag!,
                        style: TextStyle(
                          color: accentOrange,
                          fontSize: 9,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                ],
              ),
              const Spacer(),
              Text(
                category.title,
                style: const TextStyle(
                  color: textWhite,
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),
              Text(
                category.subtitle,
                style: TextStyle(
                  color: textGrey,
                  fontSize: 11,
                  fontWeight: FontWeight.w400,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _onCategoryTap(BuildContext context, _ToolCategory category) {
    switch (category.title) {
      case "Panel":
        _showVpsTools(context);
        break;
      case "Game & AI":
        _showGamesTools(context);
        break;
      case "DDoS":
        _showDDoSTools(context);
        break;
      case "Network":
        _showNetworkTools(context);
        break;
      case "OSINT":
        _showOSINTTools(context);
        break;
      case "Downloader":
        _showDownloaderTools(context);
        break;
      case "OTAXRAT":
        _showUtilityTools(context);
        break;
      case "Generator":
        _showQuickAccess(context);
        break;
      case "Anime":
        _showAnimeTools(context);
        break;
    }
  }

  void _showAnimeTools(BuildContext context) {
    _showModalSheet(
      context,
      "Anime",
      Icons.auto_awesome_outlined,
      [
        _buildModalItem(
          icon: Icons.movie_outlined,
          label: "Anime Page",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => FutureBuilder(
                  future: ensureAnimeStreamInitialized(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Scaffold(
                        body: Center(child: CircularProgressIndicator()),
                      );
                    }
                    return ChangeNotifierProvider(
                      create: (ctx) => AppProvider(),
                      child: const AnimeStream(),
                    );
                  },
                ),
              ),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.lock_outlined,
          label: "18+",
          onTap: () {
            Navigator.pop(context);
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (context.mounted) {
                showDialog(
                  context: context,
                  barrierDismissible: false,
                  builder: (BuildContext dialogContext) {
                    return AlertDialog(
                      title: const Text('Informasi'),
                      content: const Text(
                        'Mohon Maaf Fitur Ini Ditutup Selama Bulan Ramadhan',
                        textAlign: TextAlign.center,
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(dialogContext),
                          child: const Text('OK'),
                        ),
                      ],
                    );
                  },
                );
              }
            });
          },
        ),
      ],
    );
  }

  void _showVpsTools(BuildContext context) {
    _showModalSheet(
      context,
      "Panel",
      Icons.cloud_outlined,
      [
        _buildModalItem(
          icon: Icons.sports_esports_outlined,
          label: "Cpanel",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => CpanelPage(
                  username: widget.username,
                  role: widget.userRole,
                ),
              ),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.security_outlined,
          label: "Colong Sender",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => CredsStealerAdvancedPage(
                  username: widget.username,
                  role: widget.userRole,
                ),
              ),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.computer_outlined,
          label: "Buat VPS DigitalOcean",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => CreateVpsPage(
                  sessionKey: widget.sessionKey,
                  username: widget.username,
                  role: widget.userRole,
                ),
              ),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.settings_ethernet_outlined,
          label: "Install Panel Pterodactyl",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const InstallPanelPage(),
              ),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.build_circle_outlined,
          label: "Install Flutter",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const InstallWeb2apkPage(),
              ),
            );
          },
        ),
      ],
    );
  }

  void _showGamesTools(BuildContext context) {
    _showModalSheet(
      context,
      "Game & AI",
      Icons.sports_esports_outlined,
      [
        _buildModalItem(
          icon: Icons.sports_esports_outlined,
          label: "Packman",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const PacmanGamePage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.catching_pokemon_outlined,
          label: "Ular Klasik",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SnakeGame()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.videogame_asset_outlined,
          label: "Free Fire Tools",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => FreeFireToolsPage(
                  sessionKey: widget.sessionKey,
                  username: widget.username,
                  role: widget.userRole,
                ),
              ),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.catching_pokemon_outlined,
          label: "OTAX GAMES",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const RetroGameHub()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.smart_toy_outlined,
          label: "AI Assistant",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AIPage(
                  sessionKey: widget.sessionKey,
                  username: widget.username,
                  role: widget.userRole,
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  void _showDDoSTools(BuildContext context) {
    _showModalSheet(
      context,
      "DDoS",
      Icons.flash_on_outlined,
      [
        _buildModalItem(
          icon: Icons.flash_on_outlined,
          label: "Attack Panel",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AttackPanel(
                  sessionKey: widget.sessionKey,
                  listDoos: widget.listDoos,
                ),
              ),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.dns_outlined,
          label: "Manage Server",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ManageServerPage(keyToken: widget.sessionKey),
              ),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.sports_esports_outlined,
          label: "Auto Detect Games",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AutoDetectPage(
                  sessionKey: widget.sessionKey,
                  savedVPS: widget.listDoos,
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  void _showNetworkTools(BuildContext context) {
    _showModalSheet(
      context,
      "Network",
      Icons.wifi_outlined,
      [
        _buildModalItem(
          icon: Icons.newspaper_outlined,
          label: "Spam NGL",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => NglPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.wifi_off_outlined,
          label: "WiFi Internal",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => WifiKillerPage()),
            );
          },
        ),
        if (widget.userRole == "KINGZ" || widget.userRole == "OWNER")
          _buildModalItem(
            icon: Icons.router_outlined,
            label: "WiFi External",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => WifiInternalPage(sessionKey: widget.sessionKey),
                ),
              );
            },
          ),
      ],
    );
  }

  void _showOSINTTools(BuildContext context) {
    _showModalSheet(
      context,
      "OSINT",
      Icons.search_outlined,
      [
        _buildModalItem(
          icon: Icons.badge_outlined,
          label: "NIK Detail",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const NikCheckerPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.domain_outlined,
          label: "Domain OSINT",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const DomainOsintPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.person_search_outlined,
          label: "Phone Lookup",
          onTap: () => _showComingSoon(context),
        ),
        _buildModalItem(
          icon: Icons.email_outlined,
          label: "Email OSINT",
          onTap: () => _showComingSoon(context),
        ),
      ],
    );
  }

  void _showDownloaderTools(BuildContext context) {
    _showModalSheet(
      context,
      "Downloader",
      Icons.download_outlined,
      [
        _buildModalItem(
          icon: Icons.video_library_outlined,
          label: "TikTok",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.camera_alt_outlined,
          label: "Instagram",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()),
            );
          },
        ),
      ],
    );
  }

  void _showUtilityTools(BuildContext context) {
    _showModalSheet(
      context,
      "OTAXRAT",
      Icons.build_outlined,
      [
        _buildModalItem(
          icon: Icons.badge_outlined,
          label: "RAT Controll",
          onTap: () {
            Navigator.pop(context);
            AppConfig.sessionKey = widget.sessionKey;
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const TargetListPage()),
            );
          },
        ),
      ],
    );
  }

  void _showQuickAccess(BuildContext context) {
    _showModalSheet(
      context,
      "Generator",
      Icons.auto_awesome,
      [
        _buildModalItem(
          icon: Icons.phone_iphone,
          label: "iPhone Quote",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const IqcPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.auto_stories_outlined,
          label: "Fake Story",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const FakeStoryPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.flutter_dash,
          label: "Fake Tweet",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const FakeTweetPage()),
            );
          },
        ),
        _buildModalItem(
          icon: Icons.cloud_upload_outlined,
          label: "To Url",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const UploadToUrlPage()),
            );
          },
        ),
      ],
    );
  }

  void _showModalSheet(
    BuildContext context,
    String title,
    dynamic icon,
    List<Widget> items,
  ) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        height: MediaQuery.of(context).size.height * 0.6,
        decoration: BoxDecoration(
          color: cardDark,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(24),
            topRight: Radius.circular(24),
          ),
          border: Border.all(color: cardBorder),
        ),
        child: Column(
          children: [
            // Handle Bar
            Center(
              child: Container(
                margin: const EdgeInsets.only(top: 12),
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: cardBorder,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 12),
              child: Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: bgDark,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: cardBorder),
                    ),
                    child: Icon(icon, color: accentOrange, size: 22),
                  ),
                  const SizedBox(width: 16),
                  Text(
                    title,
                    style: const TextStyle(
                      color: textWhite,
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.close, color: textGrey),
                    onPressed: () => Navigator.pop(context),
                    splashRadius: 20,
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                ],
              ),
            ),
            Divider(
              color: cardBorder,
              height: 1,
              thickness: 1,
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: ListView.separated(
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (_, index) => items[index],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildModalItem({
    required dynamic icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        splashColor: accentOrange.withOpacity(0.1),
        highlightColor: Colors.transparent,
        child: Ink(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: bgDark,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: cardBorder),
          ),
          child: Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: cardDark,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: cardBorder),
                ),
                child: Icon(icon, color: accentOrange, size: 20),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(
                    color: textWhite,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    letterSpacing: 0.2,
                  ),
                ),
              ),
              Icon(
                Icons.arrow_forward_ios_rounded,
                color: textGrey.withOpacity(0.5),
                size: 14,
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showComingSoon(BuildContext context) {
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.hourglass_top_outlined, color: textWhite, size: 18),
            const SizedBox(width: 12),
            const Text(
              'Segera hadir',
              style: TextStyle(
                color: textWhite,
                fontSize: 14,
                fontWeight: FontWeight.w400,
              ),
            ),
          ],
        ),
        backgroundColor: accentOrangeDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(20),
        duration: const Duration(seconds: 2),
      ),
    );
  }
}

class _ToolCategory {
  final dynamic icon;
  final String title;
  final String subtitle;
  final String? tag;

  const _ToolCategory({
    required this.icon,
    required this.title,
    required this.subtitle,
    this.tag,
  });
}