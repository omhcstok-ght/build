// lib/tools_gateway.dart
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'app_theme.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'quran_page.dart';
import 'asmaul_husna_page.dart';
//import 'device_dashboard.dart';
import 'game_zone/block_blast.dart';
import 'game_zone/catur.dart';
import 'game_zone/ludo_game.dart';
import 'game_zone/pukul_tikus.dart';
import 'api_config.dart';
import 'iqc.dart';
import 'music_downloader_page.dart';
import 'youtube_page.dart';
import 'asupan_page.dart';

// ═══════════════════════════════════════════════════════════
// GLOBAL PULSE
// ═══════════════════════════════════════════════════════════
class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;

  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }

  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

// ═══════════════════════════════════════════════════════════
// _Led
// ═══════════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;

    if (isComic) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18),
        ),
      );
    }

    if (!blink) return _buildLed(1.0);
    return ValueListenableBuilder<double>(
      valueListenable: _Pulse.v,
      builder: (_, v, __) => _buildLed(0.45 + v * 0.55),
    );
  }

  Widget _buildLed(double opacity) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [
            Colors.white.withOpacity(0.85 * opacity),
            color.withOpacity(opacity),
            color.withOpacity(0.6 * opacity),
          ],
          stops: const [0.0, 0.4, 1.0],
        ),
        border: Border.all(
          color: Colors.black.withOpacity(0.85),
          width: size * 0.12,
        ),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.75 * opacity),
            blurRadius: size * 1.4,
            spreadRadius: size * 0.2,
          ),
          BoxShadow(
            color: color.withOpacity(0.35 * opacity),
            blurRadius: size * 2.8,
            spreadRadius: size * 0.5,
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// _Screw
// ═══════════════════════════════════════════════════════════
class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  final double rotation;
  const _Screw({required this.C, this.size = 14, this.rotation = 0.785});

  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.text, C.textSub, C.bg, C.bgDark],
          stops: const [0.0, 0.35, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.9),
            offset: const Offset(0.8, 1.5),
            blurRadius: 2.5,
            spreadRadius: -0.5,
          ),
          const BoxShadow(
            color: Colors.white38,
            offset: Offset(-0.8, -0.8),
            blurRadius: 1.5,
          ),
        ],
      ),
      child: Center(
        child: Transform.rotate(
          angle: rotation,
          child: Container(
            width: size * 0.7,
            height: size * 0.11,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.9),
              borderRadius: BorderRadius.circular(size * 0.05),
              boxShadow: [
                BoxShadow(
                  color: Colors.white.withOpacity(0.15),
                  offset: const Offset(0, 1),
                  blurRadius: 0.5,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// _Rivet
// ═══════════════════════════════════════════════════════════
class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 10});

  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.accentShine, C.accentHi, C.accent, C.primaryLo],
          stops: const [0.0, 0.3, 0.65, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.9),
            offset: const Offset(0.5, 1),
            blurRadius: 1.5,
          ),
          const BoxShadow(
            color: Colors.white54,
            offset: Offset(-0.5, -0.5),
            blurRadius: 1,
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// _MetalPlate
// ═══════════════════════════════════════════════════════════
class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  final bool brass;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 16,
    this.brass = false,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: brass ? C.primaryHi : C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(5, 5),
              blurRadius: 0,
            ),
          ],
        ),
        child: child,
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.75),
            offset: const Offset(0, 6),
            blurRadius: 12,
          ),
          const BoxShadow(
            color: Colors.white12,
            offset: Offset(-1, -1),
            blurRadius: 3,
          ),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// _IndustrialTile (grid mode)
// ═══════════════════════════════════════════════════════════
class _IndustrialTile extends StatefulWidget {
  final AppPalette C;
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _IndustrialTile({
    super.key,
    required this.C,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  State<_IndustrialTile> createState() => _IndustrialTileState();
}

class _IndustrialTileState extends State<_IndustrialTile> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;

    // COMIC
    if (isComic) {
      return RepaintBoundary(
        child: GestureDetector(
          onTapDown: (_) {
            if (!_pressed) setState(() => _pressed = true);
          },
          onTapUp: (_) {
            if (_pressed) setState(() => _pressed = false);
            HapticFeedback.lightImpact();
            widget.onTap();
          },
          onTapCancel: () {
            if (_pressed) setState(() => _pressed = false);
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 90),
            curve: Curves.easeOut,
            transform: Matrix4.translationValues(
              _pressed ? 4 : 0,
              _pressed ? 4 : 0,
              0,
            ),
            decoration: BoxDecoration(
              color: C.bgDark,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.black, width: 4),
              boxShadow: _pressed
                  ? []
                  : const [
                      BoxShadow(
                        color: Colors.black,
                        offset: Offset(5, 5),
                        blurRadius: 0,
                      ),
                    ],
            ),
            padding: const EdgeInsets.all(8),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: widget.color,
                    border: Border.all(color: Colors.black, width: 3.5),
                  ),
                  child: Icon(widget.icon, color: Colors.white, size: 24),
                ),
                const SizedBox(height: 8),
                Text(
                  widget.title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Bangers',
                    letterSpacing: 1,
                    height: 1.1,
                    shadows: [
                      Shadow(
                        color: Colors.black,
                        offset: Offset(1, 1),
                        blurRadius: 0,
                      ),
                    ],
                  ),
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  widget.subtitle,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 9,
                    fontFamily: 'ComicNeue',
                    fontWeight: FontWeight.w700,
                    height: 1.1,
                  ),
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ),
      );
    }

    // ORIGINAL
    return RepaintBoundary(
      child: GestureDetector(
        onTapDown: (_) {
          if (!_pressed) setState(() => _pressed = true);
        },
        onTapUp: (_) {
          if (_pressed) setState(() => _pressed = false);
          HapticFeedback.lightImpact();
          widget.onTap();
        },
        onTapCancel: () {
          if (_pressed) setState(() => _pressed = false);
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 90),
          curve: Curves.easeOut,
          transform: Matrix4.translationValues(
            _pressed ? 2 : 0,
            _pressed ? 2 : 0,
            0,
          ),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [C.text, C.bg, C.bgDark, C.bgDeep],
              stops: const [0.0, 0.4, 0.7, 1.0],
            ),
            boxShadow: _pressed
                ? [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.95),
                      offset: const Offset(0, 1),
                      blurRadius: 2,
                    ),
                  ]
                : [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.75),
                      offset: const Offset(0, 6),
                      blurRadius: 10,
                    ),
                    const BoxShadow(
                      color: Colors.white24,
                      offset: Offset(-1, -1),
                      blurRadius: 3,
                    ),
                  ],
          ),
          padding: const EdgeInsets.all(3),
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(11),
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [C.bg, C.bgDark, C.bgDeep],
              ),
              border: Border.all(color: Colors.black.withOpacity(0.5)),
            ),
            child: Stack(
              children: [
                Positioned(top: 2, left: 2, child: _Rivet(C: C, size: 5)),
                Positioned(top: 2, right: 2, child: _Rivet(C: C, size: 5)),
                Positioned(bottom: 2, left: 2, child: _Rivet(C: C, size: 5)),
                Positioned(bottom: 2, right: 2, child: _Rivet(C: C, size: 5)),
                Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Stack(
                        alignment: Alignment.center,
                        children: [
                          Container(
                            width: 46,
                            height: 46,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: RadialGradient(
                                center: const Alignment(-0.35, -0.35),
                                colors: [
                                  widget.color.withOpacity(0.45),
                                  widget.color.withOpacity(0.15),
                                  Colors.black.withOpacity(0.92),
                                ],
                                stops: const [0.0, 0.5, 1.0],
                              ),
                              border: Border.all(
                                color: widget.color.withOpacity(0.55),
                                width: 1.5,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: widget.color.withOpacity(0.4),
                                  blurRadius: 10,
                                ),
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.85),
                                  offset: const Offset(0, 2),
                                  blurRadius: 5,
                                  spreadRadius: -1,
                                ),
                              ],
                            ),
                            child: Icon(
                              widget.icon,
                              color: widget.color,
                              size: 22,
                              shadows: [
                                Shadow(
                                  color: widget.color.withOpacity(0.8),
                                  blurRadius: 5,
                                ),
                              ],
                            ),
                          ),
                          Positioned(
                            top: 0,
                            right: 0,
                            child: _Led(
                              color: widget.color,
                              size: 6,
                              blink: true,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        widget.title,
                        style: TextStyle(
                          color: C.text,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          letterSpacing: 0.8,
                          height: 1.1,
                          shadows: const [
                            Shadow(
                              color: Colors.black,
                              offset: Offset(0, 1),
                              blurRadius: 2,
                            ),
                          ],
                        ),
                        textAlign: TextAlign.center,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 2),
                      Text(
                        widget.subtitle,
                        style: TextStyle(
                          color: C.text.withOpacity(0.5),
                          fontSize: 7.5,
                          fontFamily: 'ShareTechMono',
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.3,
                          height: 1.1,
                        ),
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// _BigToolCard (carousel mode — 9:16)
// ═══════════════════════════════════════════════════════════
class _BigToolCard extends StatefulWidget {
  final AppPalette C;
  final bool isComic;
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _BigToolCard({
    required this.C,
    required this.isComic,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  State<_BigToolCard> createState() => _BigToolCardState();
}

class _BigToolCardState extends State<_BigToolCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final isComic = widget.isComic;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        HapticFeedback.mediumImpact();
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 100),
        transform: isComic
            ? Matrix4.translationValues(
                _pressed ? 4 : 0, _pressed ? 4 : 0, 0)
            : null,
        decoration: isComic
            ? BoxDecoration(
                color: C.bgDark,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: _pressed
                    ? []
                    : const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(6, 6),
                          blurRadius: 0,
                        ),
                      ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [C.bg, C.bgDark, C.bgDeep],
                  stops: const [0.0, 0.5, 1.0],
                ),
                border: Border.all(
                  color: widget.color.withOpacity(0.5),
                  width: 1.5,
                ),
                boxShadow: _pressed
                    ? []
                    : [
                        BoxShadow(
                          color: widget.color.withOpacity(0.35),
                          blurRadius: 18,
                          spreadRadius: -2,
                        ),
                        BoxShadow(
                          color: Colors.black.withOpacity(0.75),
                          offset: const Offset(0, 6),
                          blurRadius: 12,
                        ),
                      ],
              ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(isComic ? 18 : 16),
          child: Stack(
            children: [
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        widget.color.withOpacity(isComic ? 0.15 : 0.25),
                        widget.color.withOpacity(0.05),
                        (isComic ? C.bgDark : C.bgDeep),
                      ],
                      stops: const [0.0, 0.5, 1.0],
                    ),
                  ),
                ),
              ),

              if (!isComic) ...[
                Positioned(
                  top: 12, right: 12,
                  child: _Led(color: widget.color, size: 8, blink: true),
                ),
                Positioned(top: 12, left: 12, child: _Rivet(C: C, size: 8)),
                Positioned(bottom: 12, left: 12, child: _Rivet(C: C, size: 8)),
                Positioned(bottom: 12, right: 12, child: _Rivet(C: C, size: 8)),
              ] else ...[
                Positioned(
                  top: 12, right: 12,
                  child: Container(
                    width: 12, height: 12,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: widget.color,
                      border: Border.all(color: Colors.black, width: 2.5),
                    ),
                  ),
                ),
              ],

              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Spacer(),

                    Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: isComic
                            ? null
                            : RadialGradient(
                                center: const Alignment(-0.3, -0.3),
                                colors: [
                                  widget.color.withOpacity(0.6),
                                  widget.color.withOpacity(0.3),
                                  Colors.black.withOpacity(0.6),
                                ],
                                stops: const [0.0, 0.5, 1.0],
                              ),
                        color: isComic ? widget.color : null,
                        border: Border.all(
                          color: isComic ? Colors.black : widget.color,
                          width: isComic ? 5 : 3,
                        ),
                        boxShadow: isComic
                            ? null
                            : [
                                BoxShadow(
                                  color: widget.color.withOpacity(0.5),
                                  blurRadius: 24,
                                  spreadRadius: 2,
                                ),
                              ],
                      ),
                      child: Icon(
                        widget.icon,
                        color: Colors.white,
                        size: 48,
                        shadows: const [
                          Shadow(
                            color: Colors.black54,
                            offset: Offset(0, 2),
                            blurRadius: 4,
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 24),

                    Text(
                      widget.title,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: isComic ? Colors.white : C.text,
                        fontSize: isComic ? 26 : 22,
                        fontWeight: FontWeight.w900,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: isComic ? 2 : 2.5,
                        height: 1.1,
                        shadows: isComic
                            ? const [
                                Shadow(
                                  color: Colors.black,
                                  offset: Offset(2, 2),
                                  blurRadius: 0,
                                ),
                              ]
                            : [
                                const Shadow(
                                  color: Colors.black,
                                  offset: Offset(0, 2),
                                  blurRadius: 4,
                                ),
                                Shadow(
                                  color: widget.color.withOpacity(0.6),
                                  blurRadius: 12,
                                ),
                              ],
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),

                    const SizedBox(height: 8),

                    Text(
                      widget.subtitle,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: isComic
                            ? Colors.white70
                            : C.text.withOpacity(0.6),
                        fontSize: isComic ? 14 : 12,
                        fontWeight: FontWeight.w700,
                        fontFamily:
                            isComic ? 'ComicNeue' : 'ShareTechMono',
                        letterSpacing: 1,
                      ),
                    ),

                    const Spacer(),

                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        borderRadius:
                            BorderRadius.circular(isComic ? 8 : 20),
                        color: isComic
                            ? Colors.white.withOpacity(0.15)
                            : Colors.black.withOpacity(0.5),
                        border: Border.all(
                          color: isComic
                              ? Colors.white
                              : widget.color.withOpacity(0.5),
                          width: isComic ? 2 : 1,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.touch_app_rounded,
                            color:
                                isComic ? Colors.white : widget.color,
                            size: 12,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            'TAP TO OPEN',
                            style: TextStyle(
                              color:
                                  isComic ? Colors.white : widget.color,
                              fontSize: isComic ? 11 : 9,
                              fontWeight: FontWeight.w900,
                              fontFamily:
                                  isComic ? 'Bangers' : 'Orbitron',
                              letterSpacing: 1.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// TOOLS PAGE
// ═══════════════════════════════════════════════════════════
class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final String username;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.username,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _gaugeController;

  // ═══ VIEW MODE ═══
  String _viewMode = 'grid';
  bool _hasChosenViewMode = false;
  final PageController _cardPageCtrl = PageController(viewportFraction: 0.75);
  int _cardIndex = 0;

  final List<Map<String, dynamic>> _viewModes = [
    {
      'id': 'grid',
      'label': 'GRID SIMPLE',
      'desc': 'Tampilan grid 3 kolom kayak sekarang',
      'icon': Icons.grid_view_rounded,
      'color': const Color(0xFF2196F3),
    },
    {
      'id': 'carousel',
      'label': 'CARD CAROUSEL',
      'desc': 'Kartu 9:16 bisa digeser kiri-kanan',
      'icon': Icons.view_carousel_rounded,
      'color': const Color(0xFF9C27B0),
    },
  ];

  List<_ToolItem> _tools(AppPalette C) => [
        _ToolItem(
          icon: Icons.menu_book_rounded,
          title: "AL-QUR'AN",
          subtitle: "114 Surah",
          color: C.accentShine,
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const QuranPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.auto_awesome_rounded,
          title: "ASMAUL HUSNA",
          subtitle: "99 Nama",
          color: C.accentShine,
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AsmaulHusnaPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.grid_on_outlined,
          title: "BLOCK BLAST",
          subtitle: "Puzzle",
          color: C.primaryHi,
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const BlockBlastPage()));
          },
        ),
        _ToolItem(
          icon: Icons.extension_outlined,
          title: "CATUR",
          subtitle: "Strategy",
          color: C.primaryHi,
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const CaturPage()));
          },
        ),
        _ToolItem(
          icon: Icons.casino_outlined,
          title: "LUDO",
          subtitle: "Board",
          color: C.primaryHi,
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const LudoGamePage()));
          },
        ),
        _ToolItem(
          icon: Icons.pets_outlined,
          title: "PUKUL TIKUS",
          subtitle: "Casual",
          color: C.primaryHi,
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const PukulTikusPage()));
          },
        ),
        _ToolItem(
          icon: Icons.newspaper_outlined,
          title: "SPAM NGL",
          subtitle: "Message",
          color: C.accentHi,
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const NglPage()));
          },
        ),
        _ToolItem(
          icon: Icons.wifi_off_outlined,
          title: "WIFI INTERNAL",
          subtitle: "Network",
          color: C.accentHi,
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const WifiKillerPage()));
          },
        ),
        if (widget.userRole == "KINGZ" || widget.userRole == "OWNER")
          _ToolItem(
            icon: Icons.router_outlined,
            title: "WIFI EXTERNAL",
            subtitle: "Network",
            color: C.accentHi,
            onTap: () {
              HapticFeedback.lightImpact();
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => WifiInternalPage(
                          sessionKey: widget.sessionKey)));
            },
          ),
        _ToolItem(
          icon: Icons.badge_outlined,
          title: "NIK DETAIL",
          subtitle: "KTP",
          color: C.accent,
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const NikCheckerPage()));
          },
        ),
        _ToolItem(
          icon: Icons.domain_outlined,
          title: "DOMAIN OSINT",
          subtitle: "Domain",
          color: C.accent,
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const DomainOsintPage()));
          },
        ),
        _ToolItem(
          icon: Icons.library_music_rounded,
          title: "MUSIC DL",
          subtitle: "MP3",
          color: C.accentShine,
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const MusicDownloaderPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.video_library_outlined,
          title: "TIKTOK DL",
          subtitle: "Video",
          color: C.accentHi,
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const TiktokDownloaderPage()));
          },
        ),
        _ToolItem(
          icon: Icons.camera_alt_outlined,
          title: "IG DOWNLOADER",
          subtitle: "Photo",
          color: C.accentHi,
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const InstagramDownloaderPage()));
          },
        ),
        _ToolItem(
          icon: Icons.chat_bubble_outline_rounded,
          title: "IQC MAKER",
          subtitle: "Fake Chat",
          color: C.accentShine,
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const IqcPage()),
            );
          },
        ),
        // ❌ DEVICE DASH DIHAPUS (DeviceDashboardPage tidak tersedia)
        _ToolItem(
          icon: Icons.lock_outlined,
          title: "18+ CONTENT",
          subtitle: "Dewasa",
          color: C.primaryHi,
          onTap: () => _showRamadhanWarning(C, context),
        ),
      ];

  @override
  void initState() {
    super.initState();
    _Pulse.ensureStarted();
    _gaugeController = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    )..repeat();

    _loadViewMode();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future.delayed(const Duration(milliseconds: 800), () {
        if (mounted && !_hasChosenViewMode) {
          _showViewModeDialog(AppTheme.current.value);
        }
      });
    });
  }

  @override
  void dispose() {
    _gaugeController.dispose();
    _cardPageCtrl.dispose();
    super.dispose();
  }

  // ═══ SAVE / LOAD VIEW MODE ═══
  Future<void> _saveViewMode(String mode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('tools_view_mode', mode);
  }

  Future<void> _loadViewMode() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('tools_view_mode');
    if (saved != null && mounted) {
      setState(() {
        _viewMode = saved;
        _hasChosenViewMode = true;
      });
    }
  }

  void _showViewModeSnack(AppPalette C, String msg) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: C.primaryHi,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }

  // ═══ DIALOG PILIH VIEW MODE ═══
  void _showViewModeDialog(AppPalette C) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    HapticFeedback.mediumImpact();

    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.9),
      builder: (dialogCtx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 20),
        child: Container(
          decoration: isComic
              ? BoxDecoration(
                  color: C.bgDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.black, width: 4),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(6, 6),
                      blurRadius: 0,
                    ),
                  ],
                )
              : null,
          child: _MetalPlate(
            C: C,
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    _Led(color: C.primaryHi, size: 8, blink: !isComic),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'PILIH TAMPILAN TOOLS',
                        style: TextStyle(
                          color: isComic ? Colors.black : C.accent,
                          fontSize: isComic ? 17 : 13,
                          fontWeight: FontWeight.w900,
                          fontFamily: isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 1.5,
                          shadows: isComic
                              ? const [
                                  Shadow(
                                    color: Colors.black26,
                                    offset: Offset(1, 1),
                                    blurRadius: 0,
                                  ),
                                ]
                              : null,
                        ),
                      ),
                    ),
                    _Led(color: C.accent, size: 8, blink: !isComic),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  'Pilih model tampilan tools yang lu mau.\nBisa diganti kapan aja.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: isComic
                        ? Colors.black.withOpacity(0.6)
                        : C.text.withOpacity(0.6),
                    fontSize: isComic ? 11 : 10,
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 18),
                ..._viewModes.map((mode) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: _buildViewModeTile(C, isComic, mode, dialogCtx),
                  );
                }),
                const SizedBox(height: 6),
                Text(
                  'Pilihan tersimpan di perangkat',
                  style: TextStyle(
                    color: isComic
                        ? Colors.black.withOpacity(0.4)
                        : C.text.withOpacity(0.4),
                    fontSize: 9,
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildViewModeTile(
    AppPalette C,
    bool isComic,
    Map<String, dynamic> mode,
    BuildContext dialogCtx,
  ) {
    final color = mode['color'] as Color;
    final isSelected = _viewMode == mode['id'];

    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() {
          _viewMode = mode['id'] as String;
          _hasChosenViewMode = true;
          _cardIndex = 0;
        });
        _saveViewMode(mode['id'] as String);
        Navigator.pop(dialogCtx);
        _showViewModeSnack(C, '${mode['label']} aktif');
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          color: isComic
              ? (isSelected ? color : Colors.white)
              : color.withOpacity(isSelected ? 0.2 : 0.08),
          borderRadius: BorderRadius.circular(isComic ? 14 : 12),
          border: Border.all(
            color: isComic ? Colors.black : color.withOpacity(0.5),
            width: isComic ? 3.5 : 1.5,
          ),
          boxShadow: isComic
              ? const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(4, 4),
                    blurRadius: 0,
                  ),
                ]
              : null,
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isComic
                    ? (isSelected ? Colors.white : color)
                    : color.withOpacity(0.25),
                border: Border.all(
                  color: isComic ? Colors.black : color,
                  width: isComic ? 2.5 : 1,
                ),
              ),
              child: Icon(
                mode['icon'] as IconData,
                color: isComic
                    ? (isSelected ? Colors.black : Colors.white)
                    : color,
                size: 20,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    mode['label'] as String,
                    style: TextStyle(
                      color: isComic ? Colors.black : C.text,
                      fontSize: isComic ? 14 : 12,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    mode['desc'] as String,
                    style: TextStyle(
                      color: isComic
                          ? Colors.black.withOpacity(0.6)
                          : C.text.withOpacity(0.6),
                      fontSize: isComic ? 11 : 9,
                      fontFamily:
                          isComic ? 'ComicNeue' : 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
            if (isSelected)
              Icon(
                Icons.check_circle_rounded,
                color: isComic ? Colors.black : color,
                size: 22,
              ),
          ],
        ),
      ),
    );
  }

  // ═══ BUILD ═══
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final tools = _tools(C);

            return Scaffold(
              backgroundColor: C.bgDeep,
              body: Stack(
                children: [
                  if (isComic)
                    Positioned.fill(
                      child: Container(
                        color: C.bg,
                        child: CustomPaint(
                          painter: _ComicHalftonePainter(
                              color: C.primaryLo.withOpacity(0.12)),
                        ),
                      ),
                    )
                  else
                    Positioned.fill(
                      child: RepaintBoundary(child: _LeatherWall(C: C)),
                    ),

                  SafeArea(
                    child: Column(
                      children: [
                        const SizedBox(height: 8),
                        _buildHeaderPanel(C, isComic),
                        const SizedBox(height: 12),
                        _buildSectionHeader(C, tools.length, isComic),
                        const SizedBox(height: 12),
                        Expanded(
                          child: Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 14),
                            child: _viewMode == 'grid'
                                ? _buildGridView(C, tools)
                                : _buildCarouselView(C, tools, isComic),
                          ),
                        ),
                        const SizedBox(height: 12),
                        _buildStatusBar(C, isComic),
                        const SizedBox(height: 8),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  // ═══ GRID VIEW ═══
  Widget _buildGridView(AppPalette C, List<_ToolItem> tools) {
    return GridView.builder(
      addAutomaticKeepAlives: false,
      addRepaintBoundaries: false,
      cacheExtent: 500,
      physics: const BouncingScrollPhysics(),
      itemCount: tools.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 0.82,
      ),
      itemBuilder: (context, index) {
        final tool = tools[index];
        return _IndustrialTile(
          key: ValueKey(tool.title),
          C: C,
          icon: tool.icon,
          title: tool.title,
          subtitle: tool.subtitle,
          color: tool.color,
          onTap: tool.onTap,
        );
      },
    );
  }

  // ═══ CAROUSEL VIEW ═══
  Widget _buildCarouselView(
    AppPalette C,
    List<_ToolItem> tools,
    bool isComic,
  ) {
    return Column(
      children: [
        Expanded(
          child: PageView.builder(
            controller: _cardPageCtrl,
            itemCount: tools.length,
            onPageChanged: (i) => setState(() => _cardIndex = i),
            itemBuilder: (context, i) {
              final tool = tools[i];
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: _BigToolCard(
                  C: C,
                  isComic: isComic,
                  icon: tool.icon,
                  title: tool.title,
                  subtitle: tool.subtitle,
                  color: tool.color,
                  onTap: tool.onTap,
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(tools.length, (i) {
            final active = i == _cardIndex;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: active ? 20 : 6,
              height: 6,
              decoration: BoxDecoration(
                color: active
                    ? (isComic ? C.accent : C.primaryHi)
                    : (isComic
                        ? Colors.black.withOpacity(0.3)
                        : C.textSub.withOpacity(0.3)),
                borderRadius: BorderRadius.circular(3),
                border: isComic
                    ? Border.all(color: Colors.black, width: 1.5)
                    : null,
              ),
            );
          }),
        ),
        const SizedBox(height: 8),
        Text(
          '${_cardIndex + 1} / ${tools.length}',
          style: TextStyle(
            color: isComic ? Colors.black : C.accent.withOpacity(0.7),
            fontSize: isComic ? 12 : 10,
            fontWeight: FontWeight.w900,
            fontFamily: isComic ? 'Bangers' : 'Orbitron',
            letterSpacing: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _buildHeaderPanel(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: isComic
            ? BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(6, 6),
                    blurRadius: 0,
                  ),
                ],
              )
            : null,
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: isComic
                          ? null
                          : RadialGradient(
                              center: const Alignment(-0.3, -0.3),
                              colors: [C.text, C.bg, C.bgDark],
                            ),
                      color: isComic ? C.primaryHi : null,
                      border: Border.all(
                          color: isComic ? Colors.black : C.accent,
                          width: isComic ? 4 : 2.5),
                      boxShadow: isComic
                          ? null
                          : [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.85),
                                offset: const Offset(0, 4),
                                blurRadius: 8,
                              ),
                              BoxShadow(
                                color: C.accent.withOpacity(0.4),
                                blurRadius: 12,
                                spreadRadius: 1,
                              ),
                            ],
                    ),
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.all(6),
                        child: Image.asset(
                          'assets/images/otaxlogo.png',
                          fit: BoxFit.contain,
                          errorBuilder: (_, __, ___) => Icon(
                            Icons.shield_moon_outlined,
                            color:
                                isComic ? Colors.white : C.accentShine,
                            size: 22,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: -2,
                    child: _Led(color: C.primaryHi, size: 6, blink: !isComic),
                  ),
                  if (!isComic)
                    Positioned(
                      bottom: -2,
                      child: _Led(color: C.accent, size: 6, blink: true),
                    ),
                ],
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'SYAX',
                      style: TextStyle(
                        color: C.accentHi,
                        fontSize: isComic ? 22 : 18,
                        fontWeight: FontWeight.w900,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: isComic ? 1 : 2,
                        height: 1,
                        shadows: isComic
                            ? const [
                                Shadow(
                                  color: Colors.black,
                                  offset: Offset(2, 2),
                                  blurRadius: 0,
                                ),
                              ]
                            : [
                                Shadow(
                                  color: C.primaryLo,
                                  offset: const Offset(0, 1),
                                  blurRadius: 1,
                                ),
                                const Shadow(
                                  color: Colors.black,
                                  offset: Offset(0, 2),
                                  blurRadius: 4,
                                ),
                              ],
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        _Led(
                            color: C.primaryHi, size: 5, blink: !isComic),
                        const SizedBox(width: 5),
                        Text(
                          'TOOLS GATEWAY',
                          style: TextStyle(
                            color: C.text.withOpacity(0.6),
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                            fontFamily:
                                isComic ? 'ComicNeue' : 'ShareTechMono',
                            letterSpacing: 1.5,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(isComic ? 10 : 6),
                  gradient: isComic
                      ? null
                      : LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [C.accentHi, C.accent, C.primary],
                        ),
                  color: isComic ? C.accent : null,
                  border: Border.all(
                      color: isComic ? Colors.black : C.accentShine,
                      width: isComic ? 3 : 1),
                  boxShadow: isComic
                      ? const [
                          BoxShadow(
                            color: Colors.black,
                            offset: Offset(3, 3),
                            blurRadius: 0,
                          ),
                        ]
                      : [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.7),
                            offset: const Offset(0, 3),
                            blurRadius: 5,
                          ),
                        ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'ROLE',
                      style: TextStyle(
                        color: isComic
                            ? Colors.white70
                            : C.primaryLo.withOpacity(0.8),
                        fontSize: isComic ? 8 : 6,
                        fontWeight: FontWeight.w900,
                        fontFamily: isComic ? 'ComicNeue' : 'Orbitron',
                        letterSpacing: 1.5,
                      ),
                    ),
                    const SizedBox(height: 1),
                    Text(
                      widget.userRole.toUpperCase(),
                      style: TextStyle(
                        color: isComic ? Colors.white : C.bgDeep,
                        fontSize: isComic ? 12 : 10,
                        fontWeight: FontWeight.w900,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(AppPalette C, int count, bool isComic) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          _Led(color: C.primaryHi, size: 8, blink: !isComic),
          const SizedBox(width: 10),
          Text(
            'ALL TOOLS',
            style: TextStyle(
              color: C.accent,
              fontSize: isComic ? 14 : 11,
              fontWeight: FontWeight.w900,
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              letterSpacing: isComic ? 1.5 : 2.5,
              shadows: isComic
                  ? const [
                      Shadow(
                        color: Colors.black,
                        offset: Offset(1, 1),
                        blurRadius: 0,
                      ),
                    ]
                  : const [
                      Shadow(
                        color: Colors.black,
                        offset: Offset(0, 1),
                        blurRadius: 2,
                      ),
                    ],
            ),
          ),
          const SizedBox(width: 10),

          // ═══ Tombol ganti tampilan ═══
          GestureDetector(
            onTap: () => _showViewModeDialog(C),
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(isComic ? 6 : 4),
                color: isComic ? C.accent : C.bgDark,
                border: Border.all(
                  color: isComic ? Colors.black : C.accent,
                  width: isComic ? 2 : 1,
                ),
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(2, 2),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    _viewMode == 'grid'
                        ? Icons.grid_view_rounded
                        : Icons.view_carousel_rounded,
                    color: isComic ? Colors.white : C.accent,
                    size: 11,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    _viewMode == 'grid' ? 'GRID' : 'CARD',
                    style: TextStyle(
                      color: isComic ? Colors.white : C.accent,
                      fontSize: isComic ? 9 : 7,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(width: 8),
          Expanded(
            child: isComic
                ? Container(height: 3, color: Colors.black)
                : AnimatedBuilder(
                    animation: _gaugeController,
                    builder: (_, __) => CustomPaint(
                      size: const Size(double.infinity, 4),
                      painter: _GaugeLinePainter(
                        C: C,
                        progress: _gaugeController.value,
                      ),
                    ),
                  ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(isComic ? 6 : 4),
              color: isComic ? C.accent : Colors.black.withOpacity(0.6),
              border: Border.all(
                  color: isComic ? Colors.black : C.primaryLo,
                  width: isComic ? 2.5 : 1),
              boxShadow: isComic
                  ? const [
                      BoxShadow(
                        color: Colors.black,
                        offset: Offset(2, 2),
                        blurRadius: 0,
                      ),
                    ]
                  : [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.8),
                        offset: const Offset(0, 2),
                        blurRadius: 3,
                      ),
                    ],
            ),
            child: Text(
              '$count ITEMS',
              style: TextStyle(
                color: isComic ? Colors.white : C.accent.withOpacity(0.9),
                fontSize: isComic ? 10 : 8,
                fontWeight: FontWeight.w900,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: 1.2,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusBar(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        height: 34,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(isComic ? 10 : 8),
          gradient: isComic
              ? null
              : LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [C.bg, C.bgDark, C.bgDeep],
                ),
          color: isComic ? C.bgDark : null,
          border: Border.all(
            color: isComic ? Colors.black : C.textSub.withOpacity(0.5),
            width: isComic ? 3 : 1,
          ),
          boxShadow: isComic
              ? const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(3, 3),
                    blurRadius: 0,
                  ),
                ]
              : [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.75),
                    offset: const Offset(0, 4),
                    blurRadius: 8,
                  ),
                ],
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: [
              if (!isComic) _Screw(C: C, size: 10),
              if (!isComic) const SizedBox(width: 8),
              _Led(color: C.primaryHi, size: 6, blink: !isComic),
              const SizedBox(width: 8),
              Text(
                'SYSTEM READY',
                style: TextStyle(
                  color:
                      isComic ? Colors.white : C.primaryHi.withOpacity(0.9),
                  fontSize: isComic ? 11 : 8,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: isComic ? 1 : 1.5,
                  shadows: isComic
                      ? const [
                          Shadow(
                            color: Colors.black,
                            offset: Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
              const Spacer(),
              if (!isComic) ...[
                _Led(color: C.accent, size: 5, blink: true),
                const SizedBox(width: 6),
                Text(
                  'SECURE · FAST · RELIABLE',
                  style: TextStyle(
                    color: C.accent.withOpacity(0.75),
                    fontSize: 7,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'ShareTechMono',
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(width: 8),
                _Led(color: C.primaryHi, size: 5, blink: true),
                const SizedBox(width: 8),
                _Screw(C: C, size: 10, rotation: 0),
              ],
            ],
          ),
        ),
      ),
    );
  }

  // ─── WARNING RAMADHAN ───
  void _showRamadhanWarning(AppPalette C, BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    HapticFeedback.lightImpact();
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (dialogContext) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          decoration: isComic
              ? BoxDecoration(
                  color: C.bgDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.black, width: 4),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(6, 6),
                      blurRadius: 0,
                    ),
                  ],
                )
              : null,
          child: _MetalPlate(
            C: C,
            padding: const EdgeInsets.all(22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _Led(color: C.accent, size: 10, blink: !isComic),
                    const SizedBox(width: 10),
                    Text(
                      'INFORMASI',
                      style: TextStyle(
                        color: isComic ? Colors.black : C.accent,
                        fontSize: isComic ? 18 : 14,
                        fontWeight: FontWeight.w900,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: isComic ? 1.5 : 2,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Text(
                  'Mohon Maaf Fitur Ini Ditutup\nSelama Bulan Ramadhan',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: isComic
                        ? Colors.black.withOpacity(0.7)
                        : C.text,
                    fontSize: 12,
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                    height: 1.6,
                  ),
                ),
                const SizedBox(height: 20),
                GestureDetector(
                  onTap: () => Navigator.pop(dialogContext),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 30, vertical: 12),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(isComic ? 12 : 8),
                      gradient: isComic
                          ? null
                          : LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [C.accent, C.accent, C.primary],
                            ),
                      color: isComic ? C.primaryHi : null,
                      border: Border.all(
                        color: isComic
                            ? Colors.black
                            : Colors.black.withOpacity(0.6),
                        width: isComic ? 4 : 1.5,
                      ),
                      boxShadow: isComic
                          ? const [
                              BoxShadow(
                                color: Colors.black,
                                offset: Offset(4, 4),
                                blurRadius: 0,
                              ),
                            ]
                          : [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.7),
                                offset: const Offset(0, 4),
                                blurRadius: 6,
                              ),
                            ],
                    ),
                    child: Text(
                      'OK',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: isComic ? 16 : 13,
                        fontWeight: FontWeight.w900,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: isComic ? 1.5 : 2,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// TOOL ITEM MODEL
// ═══════════════════════════════════════════════════════════
class _ToolItem {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _ToolItem({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });
}

// ═══════════════════════════════════════════════════════════
// GAUGE LINE PAINTER
// ═══════════════════════════════════════════════════════════
class _GaugeLinePainter extends CustomPainter {
  final AppPalette C;
  final double progress;
  _GaugeLinePainter({required this.C, required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final trackRRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(0, 0, size.width, size.height),
      Radius.circular(size.height / 2),
    );
    canvas.drawRRect(trackRRect, Paint()..color = C.bgDeep);
    canvas.drawRRect(
      trackRRect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = Colors.black.withOpacity(0.9),
    );

    final lightX = size.width * progress;
    final lightRect = Rect.fromLTWH(
      (lightX - 20).clamp(0, size.width),
      0,
      40,
      size.height,
    );
    canvas.drawRect(
      lightRect,
      Paint()
        ..shader = LinearGradient(
          colors: [
            C.accent.withOpacity(0.0),
            C.accent.withOpacity(0.8),
            C.accentShine,
            C.accent.withOpacity(0.8),
            C.accent.withOpacity(0.0),
          ],
          stops: const [0.0, 0.3, 0.5, 0.7, 1.0],
        ).createShader(lightRect),
    );

    canvas.drawCircle(
      Offset(lightX, size.height / 2),
      6,
      Paint()
        ..color = C.accentShine.withOpacity(0.5)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
    );
  }

  @override
  bool shouldRepaint(_GaugeLinePainter old) =>
      old.progress != progress || old.C != C;
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// LEATHER WALL
// ═══════════════════════════════════════════════════════════
class _LeatherWall extends StatelessWidget {
  final AppPalette C;
  const _LeatherWall({required this.C});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          center: const Alignment(-0.3, -0.3),
          radius: 1.2,
          colors: [C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.6, 1.0],
        ),
      ),
      child: CustomPaint(painter: const _LeatherTexturePainter()),
    );
  }
}

class _LeatherTexturePainter extends CustomPainter {
  const _LeatherTexturePainter();

  @override
  void paint(Canvas canvas, Size size) {
    final rand = math.Random(42);

    final dotPaint = Paint()..color = Colors.black.withOpacity(0.06);
    for (int i = 0; i < 300; i++) {
      canvas.drawCircle(
        Offset(rand.nextDouble() * size.width,
            rand.nextDouble() * size.height),
        rand.nextDouble() * 1.2,
        dotPaint,
      );
    }

    final linePaint = Paint()
      ..color = Colors.black.withOpacity(0.04)
      ..strokeWidth = 0.5;
    for (int i = 0; i < 100; i++) {
      final x = rand.nextDouble() * size.width;
      final y = rand.nextDouble() * size.height;
      final len = rand.nextDouble() * 12 + 3;
      final angle = rand.nextDouble() * math.pi;
      canvas.drawLine(
        Offset(x, y),
        Offset(x + math.cos(angle) * len, y + math.sin(angle) * len),
        linePaint,
      );
    }
  }

  @override
  bool shouldRepaint(_LeatherTexturePainter old) => false;
}