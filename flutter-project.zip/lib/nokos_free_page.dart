// nokos_free_page.dart — NOKOS GRATIS (VIP ONLY)
//
// Fitur:
//   - List negara yang punya nomor tersedia
//   - Tap negara → list nomor
//   - Tap nomor → pilih nomor (consume)
//   - Button CEK SMS → popup OTP / "belum ada SMS, ganti nomor"
//   - Cooldown 5 menit per user per nomor (server-side)
//   - Video background banner.mp4

import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:ui';
import 'package:video_player/video_player.dart';

// ── COLOR SCHEME ──
class _NC {
  static const bg        = Color(0xFF000000);
  static const bg2       = Color(0xFF0a0a0a);
  static const surface   = Color(0xFF111111);
  static const card      = Color(0xFF111111);
  static const accent    = Color(0xFFFF3B30);
  static const accent2   = Color(0xFFFF6B6B);
  static const accent3   = Color(0xFFCC2E25);
  static const gold      = Color(0xFFFFB800);
  static const success   = Color(0xFF34D399);
  static const danger    = Color(0xFFFF3B30);
  static const text      = Color(0xFFE0E7FF);
  static const muted     = Color(0x73E0E7FF);
  static const muted2    = Color(0x38E0E7FF);
  static const border    = Color(0x1AFF3B30);
  static const border2   = Color(0x0FFFFFFF);
}

class NokosFreePage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  NokosFreePage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<NokosFreePage> createState() => _NokosFreePageState();
}

class _NokosFreePageState extends State<NokosFreePage>
    with TickerProviderStateMixin {
  static const _baseUrl = 'https://omhc-host-premium.yakuza.biz.id';
  static const _bgVideoUrl = 'assets/videos/banner.mp4';

  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;

  late AnimationController _pulseController;
  late AnimationController _headerShimmerController;

  // ── State ──
  List<dynamic> _countries = [];
  List<dynamic> _numbers = [];
  Map<String, dynamic>? _stats;
  bool _isLoadingCountries = true;
  bool _isLoadingNumbers = false;
  bool _isCheckingSms = false;
  String? _selectedCountry;
  String? _selectedCountryName;
  String? _selectedCountryFlag;
  String? _consumedNumber;
  String? _consumedFormatted;

  // Cooldown local
  DateTime? _lastCheckAt;
  Timer? _cooldownTimer;
  int _cooldownRemaining = 0;

  @override
  void initState() {
    super.initState();
    _initBgVideo();
    _pulseController = AnimationController(
        vsync: this, duration: const Duration(seconds: 3))
      ..repeat(reverse: true);
    _headerShimmerController = AnimationController(
        vsync: this, duration: const Duration(seconds: 3))
      ..repeat();
    _fetchCountries();
  }

  @override
  void dispose() {
    _cooldownTimer?.cancel();
    _pulseController.dispose();
    _headerShimmerController.dispose();
    _bgVideoController.dispose();
    super.dispose();
  }

  void _initBgVideo() {
    _bgVideoController = VideoPlayerController.asset(_bgVideoUrl)
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bgVideoReady = true);
          _bgVideoController.play();
          _bgVideoController.setLooping(true);
          _bgVideoController.setVolume(0.0);
        }
      }).catchError((e) {
        debugPrint('BG video error: $e');
      });
  }

  // ═══════════════════════════════════════════════════════════════════
  // API CALLS
  // ═══════════════════════════════════════════════════════════════════

  Future<void> _fetchCountries() async {
    setState(() => _isLoadingCountries = true);
    try {
      final res = await http.get(Uri.parse(
        '$_baseUrl/nokos/countries?key=${Uri.encodeComponent(widget.sessionKey)}',
      )).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _countries = data['countries'] ?? [];
            _stats = data['stats'];
            _isLoadingCountries = false;
          });
        } else {
          setState(() => _isLoadingCountries = false);
          if (data['vipOnly'] == true) {
            _showSnack('HANYA UNTUK VIP', isError: true);
            Navigator.pop(context);
          }
        }
      } else if (res.statusCode == 403) {
        setState(() => _isLoadingCountries = false);
        _showSnack('HANYA UNTUK VIP', isError: true);
        Navigator.pop(context);
      } else {
        setState(() => _isLoadingCountries = false);
        _showSnack('Gagal memuat negara', isError: true);
      }
    } catch (e) {
      setState(() => _isLoadingCountries = false);
      _showSnack('Error: $e', isError: true);
    }
  }

  Future<void> _fetchNumbers(String countryCode) async {
    setState(() {
      _isLoadingNumbers = true;
      _numbers = [];
      _selectedCountry = countryCode;
    });
    try {
      final res = await http.get(Uri.parse(
        '$_baseUrl/nokos/list?key=${Uri.encodeComponent(widget.sessionKey)}&country=$countryCode',
      )).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _numbers = data['numbers'] ?? [];
            _isLoadingNumbers = false;
          });
        } else {
          setState(() => _isLoadingNumbers = false);
          _showSnack(data['message'] ?? 'Gagal memuat nomor', isError: true);
        }
      } else {
        setState(() => _isLoadingNumbers = false);
        _showSnack('Server error (${res.statusCode})', isError: true);
      }
    } catch (e) {
      setState(() => _isLoadingNumbers = false);
      _showSnack('Error: $e', isError: true);
    }
  }

  // ✅ FIX: return type diubah dari Future<void> → Future<bool>
  Future<bool> _consumeNumber(String number) async {
    try {
      final res = await http.post(
        Uri.parse('$_baseUrl/nokos/consume'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'number': number,
        }),
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _consumedNumber = data['number'];
            _consumedFormatted = data['formatted'] ?? number;
          });
          return true;
        } else {
          _showSnack(data['message'] ?? 'Gagal pakai nomor', isError: true);
          return false;
        }
      }
      _showSnack('Server error (${res.statusCode})', isError: true);
      return false;
    } catch (e) {
      _showSnack('Error: $e', isError: true);
      return false;
    }
  }

  Future<void> _checkSms() async {
    if (_consumedNumber == null) {
      _showSnack('Pilih nomor dulu', isError: true);
      return;
    }
    if (_isCheckingSms) return;
    if (_cooldownRemaining > 0) {
      _showSnack('Tunggu $_cooldownRemaining detik lagi', isError: true);
      return;
    }

    setState(() => _isCheckingSms = true);

    try {
      final res = await http.post(
        Uri.parse('$_baseUrl/nokos/check-sms'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'number': _consumedNumber,
          'limit': 1,
        }),
      ).timeout(const Duration(seconds: 20));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        setState(() => _isCheckingSms = false);

        if (data['cooldown'] == true) {
          _startCooldown(data['waitSec'] ?? 300);
          _showCooldownDialog(data['message'] ?? 'Tunggu 5 menit', data['waitSec'] ?? 300);
        } else if (data['valid'] == true && data['hasMessage'] == true) {
          _startCooldown(300);
          _showOtpDialog(
            otp: data['otpCode'],
            source: data['source'] ?? 'Unknown',
            message: data['message'] ?? '',
            timestamp: data['timestamp'] ?? '',
          );
        } else if (data['valid'] == true && data['hasMessage'] == false) {
          _startCooldown(300);
          _showNoSmsDialog();
        } else {
          _showSnack(data['message'] ?? 'Gagal cek SMS', isError: true);
        }
      } else {
        setState(() => _isCheckingSms = false);
        _showSnack('Server error (${res.statusCode})', isError: true);
      }
    } catch (e) {
      setState(() => _isCheckingSms = false);
      _showSnack('Error: $e', isError: true);
    }
  }

  void _startCooldown(int seconds) {
    _cooldownRemaining = seconds;
    _lastCheckAt = DateTime.now();
    _cooldownTimer?.cancel();
    _cooldownTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      setState(() {
        _cooldownRemaining--;
        if (_cooldownRemaining <= 0) {
          t.cancel();
          _cooldownRemaining = 0;
        }
      });
    });
    setState(() {});
  }

  // ═══════════════════════════════════════════════════════════════════
  // DIALOGS
  // ═══════════════════════════════════════════════════════════════════

  void _showOtpDialog({
    required String? otp,
    required String source,
    required String message,
    required String timestamp,
  }) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(20),
        child: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF1a1a1a), Color(0xFF0a0a0a)],
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _NC.success.withOpacity(0.4), width: 1.5),
            boxShadow: [
              BoxShadow(color: _NC.success.withOpacity(0.2), blurRadius: 30),
            ],
          ),
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AnimatedBuilder(
                animation: _pulseController,
                builder: (ctx, _) {
                  final p = _pulseController.value;
                  return Container(
                    width: 80, height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [_NC.success, const Color(0xFF059669)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: _NC.success.withOpacity(0.3 + p * 0.2),
                          blurRadius: 20 + p * 10,
                        ),
                      ],
                    ),
                    child: Icon(Icons.message_rounded,
                        color: _NC.text, size: 36),
                  );
                },
              ),
              const SizedBox(height: 20),
              Text('SMS RECEIVED',
                  style: TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 3,
                    color: _NC.success,
                  )),
              const SizedBox(height: 6),
              Container(
                width: 40, height: 2,
                decoration: BoxDecoration(
                    color: _NC.success.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(1)),
              ),
              const SizedBox(height: 20),

              if (otp != null) ...[
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 24, vertical: 20),
                  decoration: BoxDecoration(
                    color: _NC.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                        color: _NC.success.withOpacity(0.3), width: 1.5),
                  ),
                  child: Column(
                    children: [
                      Text('KODE OTP',
                          style: TextStyle(
                            fontSize: 10,
                            fontFamily: 'ShareTechMono',
                            letterSpacing: 2,
                            color: _NC.muted,
                          )),
                      const SizedBox(height: 8),
                      SelectableText(
                        otp,
                        style: TextStyle(
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 8,
                          color: _NC.text,
                          shadows: [
                            Shadow(color: _NC.success, blurRadius: 12),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                GestureDetector(
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: otp));
                    _showSnack('OTP disalin!', isError: false);
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 10),
                    decoration: BoxDecoration(
                      color: _NC.success.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: _NC.success.withOpacity(0.3)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.copy_rounded,
                            color: _NC.success, size: 14),
                        const SizedBox(width: 6),
                        Text('COPY OTP',
                            style: TextStyle(
                              fontFamily: 'MADEEvolveSansEVO',
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.5,
                              color: _NC.success,
                            )),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
              ],

              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _NC.surface,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _NC.border2),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _infoRow('From', source),
                    const SizedBox(height: 4),
                    _infoRow('Time', timestamp),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              if (message.isNotEmpty) ...[
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _NC.surface,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _NC.border2),
                  ),
                  child: Text(
                    message,
                    style: TextStyle(
                      fontFamily: 'ShareTechMono',
                      fontSize: 11,
                      color: _NC.muted,
                      height: 1.5,
                    ),
                  ),
                ),
                const SizedBox(height: 16),
              ],

              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    color: _NC.success,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Text('CLOSE',
                        style: TextStyle(
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                          color: _NC.text,
                        )),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showNoSmsDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(20),
        child: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF1a1a1a), Color(0xFF0a0a0a)],
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _NC.gold.withOpacity(0.4), width: 1.5),
          ),
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 80, height: 80,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [_NC.gold, Color(0xFFCC8A00)],
                  ),
                ),
                child: Icon(Icons.hourglass_empty_rounded,
                    color: _NC.text, size: 36),
              ),
              const SizedBox(height: 20),
              Text('BELUM ADA SMS',
                  style: TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 3,
                    color: _NC.gold,
                  )),
              const SizedBox(height: 6),
              Container(
                width: 40, height: 2,
                decoration: BoxDecoration(
                    color: _NC.gold.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(1)),
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _NC.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _NC.border2),
                ),
                child: Text(
                  'Belum ada SMS masuk ke nomor ini. Kamu bisa:\n\n'
                  '• Tunggu 5-10 menit lalu cek lagi\n'
                  '• Coba nomor lain dari negara yang sama\n'
                  '• Pilih negara lain\n\n'
                  'Cooldown 5 menit berlaku per nomor.',
                  style: TextStyle(
                    fontFamily: 'ShareTechMono',
                    fontSize: 11,
                    color: _NC.muted,
                    height: 1.6,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                        setState(() {
                          _consumedNumber = null;
                          _consumedFormatted = null;
                        });
                        if (_selectedCountry != null) {
                          _fetchNumbers(_selectedCountry!);
                        }
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          color: _NC.surface,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: _NC.border),
                        ),
                        child: Center(
                          child: Text('GANTI NOMOR',
                              style: TextStyle(
                                fontFamily: 'MADEEvolveSansEVO',
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1.5,
                                color: _NC.text,
                              )),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                        setState(() {
                          _selectedCountry = null;
                          _numbers = [];
                          _consumedNumber = null;
                          _consumedFormatted = null;
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          color: _NC.gold.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: _NC.gold.withOpacity(0.3)),
                        ),
                        child: Center(
                          child: Text('GANTI NEGARA',
                              style: TextStyle(
                                fontFamily: 'MADEEvolveSansEVO',
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1.5,
                                color: _NC.gold,
                              )),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showCooldownDialog(String message, int waitSec) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => AlertDialog(
        backgroundColor: _NC.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: _NC.gold.withOpacity(0.4)),
        ),
        title: Row(
          children: [
            Icon(Icons.timer_rounded, color: _NC.gold, size: 22),
            const SizedBox(width: 10),
            Text('COOLDOWN',
                style: TextStyle(
                  fontFamily: 'MADEEvolveSansEVO',
                  fontSize: 14,
                  color: _NC.gold,
                )),
          ],
        ),
        content: Text(
          message,
          style: TextStyle(
            fontFamily: 'ShareTechMono',
            fontSize: 12,
            color: _NC.muted,
            height: 1.5,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('OK', style: TextStyle(color: _NC.gold)),
          ),
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Row(
      children: [
        SizedBox(
          width: 50,
          child: Text('[$label]',
              style: TextStyle(
                fontFamily: 'ShareTechMono',
                fontSize: 10,
                color: _NC.muted2,
              )),
        ),
        Expanded(
          child: Text(value,
              style: TextStyle(
                fontFamily: 'ShareTechMono',
                fontSize: 11,
                color: _NC.text,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis),
        ),
      ],
    );
  }

  void _showSnack(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(message,
          style: TextStyle(
              color: _NC.text,
              fontFamily: 'ShareTechMono',
              fontSize: 12)),
      backgroundColor: isError
          ? _NC.danger.withOpacity(0.9)
          : _NC.success.withOpacity(0.85),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(14),
    ));
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _NC.bg,
      body: Stack(
        children: [
          if (_bgVideoReady && _bgVideoController.value.isInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bgVideoController.value.size.width,
                  height: _bgVideoController.value.size.height,
                  child: VideoPlayer(_bgVideoController),
                ),
              ),
            )
          else
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF000000), Color(0xFF0a0a0a), Color(0xFF111111)],
                ),
              ),
            ),
          Container(color: Colors.black.withOpacity(0.65)),
          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                Expanded(child: _buildContent()),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      height: 62,
      decoration: BoxDecoration(
        color: const Color(0xEB0c0d15),
        border: Border(bottom: BorderSide(color: _NC.border)),
      ),
      child: ClipRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Row(
              children: [
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    width: 38, height: 38,
                    decoration: BoxDecoration(
                      color: _NC.surface,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _NC.border2),
                    ),
                    child: Icon(Icons.arrow_back,
                        color: _NC.text, size: 16),
                  ),
                ),
                const SizedBox(width: 10),
                Container(
                  width: 36, height: 36,
                  decoration: BoxDecoration(
                    color: _NC.gold.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _NC.gold.withOpacity(0.25)),
                  ),
                  child: Center(
                      child: Icon(FontAwesomeIcons.simCard,
                          color: _NC.gold, size: 14)),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AnimatedBuilder(
                        animation: _headerShimmerController,
                        builder: (context, _) {
                          final t = _headerShimmerController.value;
                          return ShaderMask(
                            shaderCallback: (bounds) => LinearGradient(
                              begin: Alignment(-1.0 + (t * 2), 0),
                              end: Alignment(0.0 + (t * 2), 0),
                              colors: [_NC.text, _NC.gold, _NC.text],
                              stops: const [0.0, 0.5, 1.0],
                            ).createShader(bounds),
                            blendMode: BlendMode.srcIn,
                            child: const Text(
                              'NOKOS GRATIS',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'MADEEvolveSansEVO',
                                letterSpacing: 1.5,
                              ),
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 1),
                      Text(
                        'Nomor Virtual untuk OTP',
                        style: TextStyle(
                          color: _NC.muted,
                          fontSize: 10,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: _NC.gold.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _NC.gold.withOpacity(0.3)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.workspace_premium_rounded,
                          color: _NC.gold, size: 12),
                      const SizedBox(width: 4),
                      Text('VIP',
                          style: TextStyle(
                            color: _NC.gold,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'ShareTechMono',
                            letterSpacing: 1,
                          )),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildContent() {
    if (_isLoadingCountries) return _buildLoading();
    if (_selectedCountry == null) return _buildCountryList();
    return _buildNumberList();
  }

  Widget _buildLoading() {
    return const Center(
      child: CircularProgressIndicator(color: _NC.gold),
    );
  }

  Widget _buildCountryList() {
    if (_countries.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 80, height: 80,
                decoration: BoxDecoration(
                  color: _NC.surface,
                  shape: BoxShape.circle,
                  border: Border.all(color: _NC.border2),
                ),
                child: Icon(FontAwesomeIcons.simCard,
                    color: _NC.muted2, size: 32),
              ),
              const SizedBox(height: 20),
              Text('BELUM ADA NOMOR',
                  style: TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                    color: _NC.text,
                  )),
              const SizedBox(height: 8),
              Text('Admin belum menambah nomor.\nCek lagi nanti.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: 'ShareTechMono',
                    fontSize: 11,
                    color: _NC.muted,
                    height: 1.5,
                  )),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: _fetchCountries,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 20, vertical: 10),
                  decoration: BoxDecoration(
                    color: _NC.gold.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _NC.gold.withOpacity(0.3)),
                  ),
                  child: Text('REFRESH',
                      style: TextStyle(
                        fontFamily: 'MADEEvolveSansEVO',
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                        color: _NC.gold,
                      )),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Column(
      children: [
        if (_stats != null)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Row(
              children: [
                _buildStatChip('TOTAL',
                    '${_stats!['total'] ?? 0}', _NC.text),
                const SizedBox(width: 8),
                _buildStatChip('AVAILABLE',
                    '${_stats!['available'] ?? 0}', _NC.success),
                const SizedBox(width: 8),
                _buildStatChip('USED',
                    '${_stats!['used'] ?? 0}', _NC.muted),
              ],
            ),
          ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
          child: Row(
            children: [
              Container(
                width: 3, height: 14,
                decoration: BoxDecoration(
                  color: _NC.gold,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 8),
              Text('PILIH NEGARA',
                  style: TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                    color: _NC.gold,
                  )),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: _countries.length,
            itemBuilder: (context, index) {
              final c = _countries[index];
              final flag = c['flag'] ?? '🌐';
              final name = c['countryName'] ?? c['countryCode'];
              final cc = c['countryCode'] ?? '??';
              final available = c['available'] ?? 0;
              final total = c['total'] ?? 0;
              return _buildCountryCard(flag, name, cc, available, total);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildStatChip(String label, String value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
        decoration: BoxDecoration(
          color: _NC.surface,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: _NC.border2),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label,
                style: TextStyle(
                  fontFamily: 'ShareTechMono',
                  fontSize: 9,
                  letterSpacing: 1,
                  color: _NC.muted,
                )),
            const SizedBox(height: 2),
            Text(value,
                style: TextStyle(
                  fontFamily: 'MADEEvolveSansEVO',
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: color,
                )),
          ],
        ),
      ),
    );
  }

  Widget _buildCountryCard(String flag, String name, String cc,
      int available, int total) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedCountryName = name;
          _selectedCountryFlag = flag;
        });
        _fetchNumbers(cc);
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _NC.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _NC.border),
        ),
        child: Row(
          children: [
            Container(
              width: 48, height: 48,
              decoration: BoxDecoration(
                color: _NC.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _NC.border2),
              ),
              child: Center(
                child: Text(flag, style: const TextStyle(fontSize: 26)),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name,
                      style: TextStyle(
                        fontFamily: 'MADEEvolveSansEVO',
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: _NC.text,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(FontAwesomeIcons.simCard,
                          color: _NC.success, size: 10),
                      const SizedBox(width: 4),
                      Text('$available tersedia',
                          style: TextStyle(
                            fontFamily: 'ShareTechMono',
                            fontSize: 11,
                            color: _NC.success,
                          )),
                      const SizedBox(width: 10),
                      Text('(total $total)',
                          style: TextStyle(
                            fontFamily: 'ShareTechMono',
                            fontSize: 10,
                            color: _NC.muted2,
                          )),
                    ],
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: _NC.muted2, size: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildNumberList() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Row(
            children: [
              GestureDetector(
                onTap: () {
                  setState(() {
                    _selectedCountry = null;
                    _numbers = [];
                    _consumedNumber = null;
                    _consumedFormatted = null;
                  });
                },
                child: Container(
                  width: 38, height: 38,
                  decoration: BoxDecoration(
                    color: _NC.surface,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _NC.border2),
                  ),
                  child: Icon(Icons.arrow_back,
                      color: _NC.text, size: 16),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${_selectedCountryFlag ?? ''} ${_selectedCountryName ?? ''}',
                      style: TextStyle(
                        fontFamily: 'MADEEvolveSansEVO',
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: _NC.text,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text('${_numbers.length} nomor tersedia',
                        style: TextStyle(
                          fontFamily: 'ShareTechMono',
                          fontSize: 10,
                          color: _NC.muted,
                        )),
                  ],
                ),
              ),
            ],
          ),
        ),

        if (_consumedNumber != null)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    _NC.success.withOpacity(0.12),
                    _NC.card,
                  ],
                ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _NC.success.withOpacity(0.35)),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Icon(Icons.check_circle_rounded,
                          color: _NC.success, size: 16),
                      const SizedBox(width: 8),
                      Text('NOMOR TERPILIH',
                          style: TextStyle(
                            fontFamily: 'MADEEvolveSansEVO',
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.5,
                            color: _NC.success,
                          )),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(_consumedFormatted ?? _consumedNumber!,
                      style: TextStyle(
                        fontFamily: 'MADEEvolveSansEVO',
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                        color: _NC.text,
                      )),
                  const SizedBox(height: 12),
                  GestureDetector(
                    onTap: _isCheckingSms || _cooldownRemaining > 0
                        ? null
                        : _checkSms,
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        gradient: (_isCheckingSms || _cooldownRemaining > 0)
                            ? const LinearGradient(
                                colors: [_NC.surface, _NC.surface])
                            : const LinearGradient(
                                colors: [_NC.success, Color(0xFF059669)]),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: (_isCheckingSms || _cooldownRemaining > 0)
                            ? const []
                            : [
                                BoxShadow(
                                  color: _NC.success.withOpacity(0.3),
                                  blurRadius: 15,
                                ),
                              ],
                      ),
                      child: Center(
                        child: _isCheckingSms
                            ? Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const SizedBox(
                                    width: 16, height: 16,
                                    child: CircularProgressIndicator(
                                      color: _NC.text,
                                      strokeWidth: 2,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Text('MENCARI OTP...',
                                      style: TextStyle(
                                        fontFamily: 'MADEEvolveSansEVO',
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 2,
                                        color: _NC.text,
                                      )),
                                ],
                              )
                            : _cooldownRemaining > 0
                                ? Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.timer_rounded,
                                          color: _NC.muted, size: 14),
                                      const SizedBox(width: 8),
                                      Text(
                                          'COOLDOWN ${_formatCooldown(_cooldownRemaining)}',
                                          style: TextStyle(
                                            fontFamily: 'MADEEvolveSansEVO',
                                            fontSize: 11,
                                            fontWeight: FontWeight.bold,
                                            letterSpacing: 1.5,
                                            color: _NC.muted,
                                          )),
                                    ],
                                  )
                                : Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.message_rounded,
                                          color: _NC.text, size: 16),
                                      const SizedBox(width: 8),
                                      Text('CEK SMS',
                                          style: TextStyle(
                                            fontFamily: 'MADEEvolveSansEVO',
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold,
                                            letterSpacing: 2,
                                            color: _NC.text,
                                          )),
                                    ],
                                  ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

        Expanded(
          child: _isLoadingNumbers
              ? _buildLoading()
              : _numbers.isEmpty
                  ? Center(
                      child: Text('Tidak ada nomor tersedia',
                          style: TextStyle(
                            fontFamily: 'ShareTechMono',
                            color: _NC.muted,
                          )),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: _numbers.length,
                      itemBuilder: (context, index) {
                        final n = _numbers[index];
                        return _buildNumberCard(n);
                      },
                    ),
        ),
      ],
    );
  }

  // ✅ FIX: onTap sekarang benar — panggil Future<bool>, tidak pakai `return` void
  Widget _buildNumberCard(Map<String, dynamic> n) {
    final number = (n['number'] ?? '') as String;
    final formatted = (n['formatted'] ?? number) as String;
    final isConsumed = _consumedNumber == number;

    return GestureDetector(
      onTap: () async {
        if (_consumedNumber != null && _consumedNumber != number) {
          _showSnack(
              'Kamu sudah pilih nomor lain. Ganti nomor dengan menekan tombol.',
              isError: true);
          return;
        }
        if (isConsumed) return;

        final ok = await _consumeNumber(number);
        if (ok && mounted) {
          setState(() {});
        }
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isConsumed ? _NC.success.withOpacity(0.08) : _NC.card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isConsumed ? _NC.success.withOpacity(0.4) : _NC.border,
            width: isConsumed ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 38, height: 38,
              decoration: BoxDecoration(
                color: isConsumed
                    ? _NC.success.withOpacity(0.15)
                    : _NC.surface,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                    color: isConsumed
                        ? _NC.success.withOpacity(0.3)
                        : _NC.border2),
              ),
              child: Center(
                child: Icon(FontAwesomeIcons.simCard,
                    color: isConsumed ? _NC.success : _NC.muted, size: 14),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(formatted,
                      style: TextStyle(
                        fontFamily: 'ShareTechMono',
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: isConsumed ? _NC.success : _NC.text,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      Container(
                        width: 6, height: 6,
                        decoration: BoxDecoration(
                          color: isConsumed ? _NC.success : _NC.muted2,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 5),
                      Text(isConsumed ? 'TERPILIH' : 'TERSEDIA',
                          style: TextStyle(
                            fontFamily: 'ShareTechMono',
                            fontSize: 9,
                            letterSpacing: 1,
                            color: isConsumed ? _NC.success : _NC.muted2,
                          )),
                    ],
                  ),
                ],
              ),
            ),
            if (isConsumed)
              Icon(Icons.check_circle_rounded,
                  color: _NC.success, size: 20)
            else
              Icon(Icons.touch_app_rounded,
                  color: _NC.muted2, size: 18),
          ],
        ),
      ),
    );
  }

  String _formatCooldown(int sec) {
    if (sec >= 60) {
      final m = sec ~/ 60;
      final s = sec % 60;
      return '${m}m ${s.toString().padLeft(2, '0')}s';
    }
    return '${sec}s';
  }
}