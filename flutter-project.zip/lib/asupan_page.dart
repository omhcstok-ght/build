// asupan_page.dart
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

// ── Neo Brutalism Colors (pengganti Neo.dart) ──
const Color _neoBg = Color(0xFFFDF6E3);
const Color _neoCream = Color(0xFFFFF8DC);
const Color _neoRed = Color(0xFFFF4D4D);
const Color _neoBlack = Color(0xFF000000);
const Color _neoWhite = Color(0xFFFFFFFF);
const Color _neoTextMuted = Color(0xFF666666);

// ── Helper Shadow Neo ──
List<BoxShadow> _neoShadow({double offset = 3}) => [
      BoxShadow(
        color: _neoBlack,
        offset: Offset(offset, offset),
        blurRadius: 0,
        spreadRadius: 0,
      ),
    ];

class OkepPage extends StatefulWidget {
  const OkepPage({super.key});

  @override
  State<OkepPage> createState() => _OkepPageState();
}

class _OkepPageState extends State<OkepPage> {
  late final WebViewController _controller;
  final TextEditingController _searchCtrl = TextEditingController();

  bool _loading = true;
  double _progress = 0;
  String _currentUrl = 'https://www.xnxx.com/search/squirting?id=72261948';
  bool _showSearchBar = false;

  static const String _homeUrl = 'https://www.xnxx.com/search/squirting?id=72261948';

  @override
  void initState() {
    super.initState();

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(_neoBg)
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            if (mounted) {
              setState(() => _progress = progress / 100);
            }
          },
          onPageStarted: (String url) {
            if (mounted) {
              setState(() {
                _loading = true;
                _currentUrl = url;
              });
            }
          },
          onPageFinished: (String url) {
            if (mounted) {
              setState(() {
                _loading = false;
                _currentUrl = url;
              });
            }
          },
          onWebResourceError: (WebResourceError error) {
            debugPrint('WebView error: ${error.description}');
          },
        ),
      )
      ..loadRequest(Uri.parse(_homeUrl));
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _searchWeb(String query) async {
    final input = query.trim();
    if (input.isEmpty) return;

    final uri = Uri.tryParse(
      input.contains('://') ? input : 'https://$input',
    );

    if (uri == null ||
        !uri.hasAuthority ||
        !{'http', 'https'}.contains(uri.scheme)) {
      return;
    }

    await _controller.loadRequest(uri);

    if (mounted) {
      setState(() {
        _showSearchBar = false;
        _searchCtrl.clear();
      });
    }
  }

  Future<void> _openInBrowser() async {
    final uri = Uri.tryParse(_currentUrl);
    if (uri != null && await canLaunchUrl(uri)) {
      await launchUrl(
        uri,
        mode: LaunchMode.externalApplication,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _neoBg,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          if (_showSearchBar) _buildSearchBar(),
          if (_loading)
            LinearProgressIndicator(
              value: _progress,
              backgroundColor: _neoCream,
              color: _neoRed,
              minHeight: 3,
            ),
          Expanded(
            child: WebViewWidget(controller: _controller),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: _neoBg,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      leading: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Container(
          margin: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: _neoWhite,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _neoBlack, width: 2.5),
            boxShadow: _neoShadow(offset: 3),
          ),
          child: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: _neoBlack,
            size: 16,
          ),
        ),
      ),
      title: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'OKEP',
            style: TextStyle(
              color: _neoTextMuted,
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 1,
            ),
          ),
          Text(
            'Mini Web Browser',
            style: TextStyle(
              color: _neoBlack,
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
      actions: [
        _appBarBtn(
          icon: Icons.home_rounded,
          onTap: () => _controller.loadRequest(
            Uri.parse(_homeUrl),
          ),
        ),
        _appBarBtn(
          icon: Icons.search_rounded,
          onTap: () {
            setState(() => _showSearchBar = !_showSearchBar);
          },
        ),
        _appBarBtn(
          icon: Icons.refresh_rounded,
          onTap: () => _controller.reload(),
        ),
        _appBarBtn(
          icon: Icons.open_in_new_rounded,
          onTap: _openInBrowser,
        ),
        const SizedBox(width: 8),
      ],
    );
  }

  Widget _appBarBtn({
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(
          horizontal: 3,
          vertical: 10,
        ),
        width: 34,
        height: 34,
        decoration: BoxDecoration(
          color: _neoWhite,
          borderRadius: BorderRadius.circular(9),
          border: Border.all(color: _neoBlack, width: 2),
          boxShadow: _neoShadow(offset: 2),
        ),
        child: Icon(icon, color: _neoBlack, size: 16),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 4,
        ),
        decoration: BoxDecoration(
          color: _neoWhite,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _neoBlack, width: 2.5),
          boxShadow: _neoShadow(offset: 4),
        ),
        child: Row(
          children: [
            const Icon(
              Icons.language_rounded,
              color: _neoBlack,
              size: 20,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _searchCtrl,
                autofocus: true,
                keyboardType: TextInputType.url,
                textInputAction: TextInputAction.go,
                onSubmitted: _searchWeb,
                style: const TextStyle(
                  color: _neoBlack,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
                decoration: const InputDecoration(
                  hintText: 'Masukkan URL situs web...',
                  hintStyle: TextStyle(
                    color: _neoTextMuted,
                    fontWeight: FontWeight.w500,
                    fontSize: 13,
                  ),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(
                    vertical: 14,
                  ),
                ),
              ),
            ),
            IconButton(
              onPressed: () => _searchWeb(_searchCtrl.text),
              icon: const Icon(
                Icons.arrow_forward_rounded,
                color: _neoBlack,
                size: 20,
              ),
            ),
          ],
        ),
      ),
    );
  }
}