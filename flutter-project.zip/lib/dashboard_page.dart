// lib/dashboard_page.dart
import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:image_picker/image_picker.dart'; 

import 'api_config.dart'; 
import 'app_theme.dart';
import 'info_page.dart'; 
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'vip_page.dart';
import 'partner_page.dart';
import 'moderator_page.dart';
import 'high_owner_page.dart';
import 'developer_page.dart';
import 'change_password_page.dart';
import 'login_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'tools_gateway.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'bug_group_page.dart';
import 'tqto.dart';
import 'chat.dart';
import 'notification_page.dart';
import 'check_notif_page.dart';
import 'call_crylix_page.dart';
import 'upgrade_role_page.dart';
import 'store_uang_page.dart';
import 'market_page.dart';
import 'theme_page.dart';
import 'music_page.dart';
import 'vinyl_music_page.dart';
import 'welcome_loading_page.dart';
import 'send_bug_loading.dart';
import 'catbox_page.dart';
import 'tiktok_video_page.dart';
import 'story_page.dart'; 

const String wsUrl = 'ws://lelendxdaycintapanel.ymzpterodactyl.biz.id:2079';

// ═══════════════════════════════════════════════════════════
// GLOBAL PULSE
// ═══════════════════════════════════════════════════════════
class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;

  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }

  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

// ═══════════════════════════════════════════════════════════
// LED
// ═══════════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18),
        ),
      );
    }
    if (!blink) return _dot(1.0);
    return ValueListenableBuilder<double>(
      valueListenable: _Pulse.v,
      builder: (_, v, __) => _dot(0.45 + v * 0.55),
    );
  }

  Widget _dot(double opacity) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [
            Colors.white.withOpacity(0.85 * opacity),
            color.withOpacity(opacity),
            color.withOpacity(0.55 * opacity),
          ],
          stops: const [0.0, 0.4, 1.0],
        ),
        border: Border.all(
          color: Colors.black.withOpacity(0.85),
          width: size * 0.1,
        ),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.75 * opacity),
            blurRadius: size * 1.4,
            spreadRadius: size * 0.2,
          ),
          BoxShadow(
            color: color.withOpacity(0.35 * opacity),
            blurRadius: size * 2.6,
            spreadRadius: size * 0.4,
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SCREW
// ═══════════════════════════════════════════════════════════
class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  final double rotation;
  const _Screw({required this.C, this.size = 14, this.rotation = 0.785});

  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.text, C.textSub, C.bg, C.bgDark],
          stops: const [0.0, 0.35, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.9),
            offset: const Offset(0.8, 1.5),
            blurRadius: 2.5,
            spreadRadius: -0.5,
          ),
          const BoxShadow(
            color: Colors.white38,
            offset: Offset(-0.8, -0.8),
            blurRadius: 1.5,
          ),
        ],
      ),
      child: Center(
        child: Transform.rotate(
          angle: rotation,
          child: Container(
            width: size * 0.7,
            height: size * 0.11,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.9),
              borderRadius: BorderRadius.circular(size * 0.05),
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// RIVET
// ═══════════════════════════════════════════════════════════
class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 10});

  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.accentShine, C.accentHi, C.accent, C.primaryLo],
          stops: const [0.0, 0.3, 0.65, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.9),
            offset: const Offset(0.5, 1),
            blurRadius: 1.5,
          ),
          const BoxShadow(
            color: Colors.white54,
            offset: Offset(-0.5, -0.5),
            blurRadius: 1,
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// METAL PLATE
// ═══════════════════════════════════════════════════════════
class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: brass ? C.primaryHi : C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(6, 6),
              blurRadius: 0,
            ),
          ],
        ),
        child: child,
      );
    }
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.75),
            offset: const Offset(0, 6),
            blurRadius: 12,
          ),
          const BoxShadow(
            color: Colors.white12,
            offset: Offset(-1, -1),
            blurRadius: 3,
          ),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// INSET PANEL
// ═══════════════════════════════════════════════════════════
class _InsetPanel extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final Color glowColor;
  final bool glow;
  const _InsetPanel({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(12),
    this.glowColor = Colors.amber,
    this.glow = false,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bg,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.black, width: 3),
        ),
        child: child,
      );
    }
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [C.bgDeep, C.bgDark],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.95),
            offset: const Offset(0, 2),
            blurRadius: 4,
          ),
          const BoxShadow(
            color: Colors.white10,
            offset: Offset(0, -1),
            blurRadius: 1,
          ),
          if (glow)
            BoxShadow(
              color: glowColor.withOpacity(0.35),
              blurRadius: 10,
            ),
        ],
        border: Border.all(
          color: glow ? glowColor.withOpacity(0.7) : C.bgDark,
          width: 1.5,
        ),
      ),
      child: child,
    );
  }
}

// ═══════════════════════════════════════════════════════════
// INDUSTRIAL BUTTON
// ═══════════════════════════════════════════════════════════
class _IndustrialButton extends StatefulWidget {
  final AppPalette C;
  final Widget child;
  final VoidCallback onTap;
  final Color color;
  final double height;
  const _IndustrialButton({
    required this.C,
    required this.child,
    required this.onTap,
    required this.color,
    this.height = 56,
  });

  @override
  State<_IndustrialButton> createState() => _IndustrialButtonState();
}

class _IndustrialButtonState extends State<_IndustrialButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    final light = _lighten(widget.color);
    final dark = _darken(widget.color);
    final widgetDark = _widgetDark(widget.color);
    final textColor =
        isComic ? C.contrastTextOn(widget.color) : Colors.white;
    final textOutline =
        textColor == Colors.white ? Colors.black : Colors.white;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: widget.height,
        transform: isComic
            ? Matrix4.translationValues(
                _pressed ? 4 : 0, _pressed ? 4 : 0, 0)
            : null,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(isComic ? 12 : 12),
          gradient: isComic
              ? null
              : LinearGradient(
                  begin: _pressed
                      ? Alignment.bottomCenter
                      : Alignment.topCenter,
                  end: _pressed
                      ? Alignment.topCenter
                      : Alignment.bottomCenter,
                  colors: _pressed
                      ? [widgetDark, widgetDark, widget.color]
                      : [light, widget.color, dark],
                  stops: const [0.0, 0.5, 1.0],
                ),
          color: isComic ? widget.color : null,
          boxShadow: isComic
              ? (_pressed
                  ? []
                  : const [
                      BoxShadow(
                        color: Colors.black,
                        offset: Offset(4, 4),
                        blurRadius: 0,
                      ),
                    ])
              : (_pressed
                  ? [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.9),
                        offset: const Offset(0, 1),
                        blurRadius: 3,
                      ),
                    ]
                  : [
                      BoxShadow(
                        color: widget.color.withOpacity(0.45),
                        offset: const Offset(0, 5),
                        blurRadius: 10,
                        spreadRadius: -2,
                      ),
                      BoxShadow(
                        color: Colors.black.withOpacity(0.75),
                        offset: const Offset(0, 4),
                        blurRadius: 6,
                      ),
                    ]),
          border: Border.all(
            color: isComic ? Colors.black : dark.withOpacity(0.9),
            width: isComic ? 3.5 : 1.5,
          ),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            if (!isComic)
              Positioned(
                top: 3,
                left: 10,
                right: 10,
                child: Container(
                  height: 12,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.white.withOpacity(_pressed ? 0.08 : 0.3),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
            if (!isComic)
              Positioned(top: 5, left: 5, child: _Rivet(C: C, size: 6)),
            if (!isComic)
              Positioned(top: 5, right: 5, child: _Rivet(C: C, size: 6)),
            if (!isComic)
              Positioned(bottom: 5, left: 5, child: _Rivet(C: C, size: 6)),
            if (!isComic)
              Positioned(bottom: 5, right: 5, child: _Rivet(C: C, size: 6)),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: DefaultTextStyle(
                style: TextStyle(
                  color: textColor,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  fontWeight: FontWeight.w900,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: textOutline,
                            offset: const Offset(2, 2),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
                child: IconTheme(
                  data: IconThemeData(color: textColor),
                  child: widget.child,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  static Color _lighten(Color c) => Color.fromARGB(
        c.alpha,
        (c.red + 40).clamp(0, 255),
        (c.green + 40).clamp(0, 255),
        (c.blue + 30).clamp(0, 255),
      );
  static Color _darken(Color c) => Color.fromARGB(
        c.alpha,
        (c.red - 60).clamp(0, 255),
        (c.green - 50).clamp(0, 255),
        (c.blue - 40).clamp(0, 255),
      );
  static Color _widgetDark(Color c) => Color.fromARGB(
        c.alpha,
        (c.red - 30).clamp(0, 255),
        (c.green - 25).clamp(0, 255),
        (c.blue - 20).clamp(0, 255),
      );
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// DASHBOARD PAGE
// ═══════════════════════════════════════════════════════════
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;

  WebSocketChannel? channel;
  String androidId = 'unknown';
  String deviceModel = 'Unknown';
  String deviceBrand = 'Unknown';
  String androidVersion = 'Unknown';
  VideoPlayerController? _bannerVideoCtrl;

  int _navIndex = 0;
  int onlineUsers = 0;
  int activeConns = 0;

  String networkType = 'Unknown';

  List<StoryItem> _dashMyStories = [];
  List<UserStoryGroup> _dashOtherStories = [];
  bool _loadingStories = true;

  Map<String, dynamic>? _weatherData;
  bool _isLoadingWeather = true;
  String _weatherError = '';
  static const String _weatherRegionCode = '31.71.03.1001';

  bool _hasShownDevMessage = false;
  bool _hasSeenDevMessageToday = false;
  bool _devMessageDismissed = false;

  static const String _devMessageTitle = 'WELCOME MESSAGE';
  static const String _devMessageContent =
      'Selamat Datang Di SYAX 👋\n\n'
      'Terima Kasih Sudah Bergabung Dengan Apk SYAX, Jangan Lupa Join Telegram @syaxinfo Biar Tau Informasi Terbaru, Dan Info Penting Lain Nya\n\n'
      'Kalau Ada Kendala, Hubungi Tim Support Melalui Menu Support'
      'Selamat Menikmati';
  static const String _devMessageAuthor = 'DEV · KaizennTzyy';

  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _glowCtrl;

  Timer? _statsTimer;
  int activeConnections = 0;
  int _signalStrength = 85;
  int batteryLevel = 78;
  String batteryState = 'Charging';
  bool _isBatteryLoaded = false;
  String _clockTime = '';
  Timer? _clockTimer;
  int sdkInt = 33;
  String _accountStatus = 'Active';
  int _accountDaysLeft = 365;
  double _accountProgress = 0.75;

  String? _customSplashVideoPath;

  bool get _isAdmin => role.toLowerCase() == 'admin';

  void _getBatteryLevel() async {
    try {
      final battery = Battery();
      final level = await battery.batteryLevel;
      final state = await battery.batteryState;
      if (!mounted) return;
      setState(() {
        batteryLevel = level;
        batteryState = state.toString().split('.').last;
        _isBatteryLoaded = true;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        batteryLevel = 24;
        batteryState = 'Unknown';
        _isBatteryLoaded = true;
      });
    }
  }

  void _getNetworkInfo() async {
    try {
      final interfaces = await NetworkInterface.list();
      bool hasWifi = false;
      bool hasMobile = false;
      for (var interface in interfaces) {
        if (interface.name.toLowerCase().contains('wlan') || interface.name.toLowerCase().contains('wifi')) {
          hasWifi = true;
        } else if (interface.name.toLowerCase().contains('rmnet') || interface.name.toLowerCase().contains('ccmni') || interface.name.toLowerCase().contains('pdp')) {
          hasMobile = true;
        }
      }
      if (!mounted) return;
      setState(() {
        if (hasWifi) {
          networkType = 'WiFi';
        } else if (hasMobile) {
          networkType = 'Seluler 4G';
        } else {
          networkType = 'Offline';
        }
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => networkType = 'Unknown');
    }
  }

  Future<void> _fetchDashboardStories() async {
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/getStories?key=$sessionKey'),
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          final List allStories = data['stories'] ?? [];
          final items = allStories.map((e) => StoryItem.fromJson(e)).toList();

          final mine = items.where((s) => s.username == username).toList();
          final Map<String, List<StoryItem>> grouped = {};
          for (final s in items.where((s) => s.username != username)) {
            grouped.putIfAbsent(s.username, () => []).add(s);
          }
          final others = grouped.entries.map((e) => UserStoryGroup(
            username: e.key,
            stories: e.value,
            hasUnviewed: e.value.any((s) => s.viewCount == 0),
          )).toList();

          if (mounted) {
            setState(() {
              _dashMyStories = mine;
              _dashOtherStories = others;
              _loadingStories = false;
            });
          }
        } else {
          if (mounted) setState(() => _loadingStories = false);
        }
      } else {
        if (mounted) setState(() => _loadingStories = false);
      }
    } catch (_) {
      if (mounted) setState(() => _loadingStories = false);
    }
  }

  Future<void> _loadCustomSplashVideo() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        _customSplashVideoPath = prefs.getString('custom_splash_video');
      });
    }
  }

  Future<void> _pickSplashVideo() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickVideo(source: ImageSource.gallery);
    if (pickedFile != null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('custom_splash_video', pickedFile.path);
      if (mounted) {
        setState(() {
          _customSplashVideoPath = pickedFile.path;
        });
        _showSkeuoSnack('Video Splash berhasil diubah!');
      }
    }
  }

  Future<void> _resetSplashVideo() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('custom_splash_video');
    if (mounted) {
      setState(() {
        _customSplashVideoPath = null;
      });
      _showSkeuoSnack('Video Splash kembali ke default (Splash.mp4)');
    }
  }

  @override
  void initState() {
    super.initState();
    _Pulse.ensureStarted();

    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _fadeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _glowCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 3))
      ..repeat(reverse: true);

    _initAndroidId();
    _initBannerVideo();
    _getNetworkInfo();
    _fetchDashboardStories(); 
    _loadCustomSplashVideo();

    _clockTimer =
        Timer.periodic(const Duration(seconds: 1), (_) => _updateClock());
    _updateClock();
    _getBatteryLevel();
    Timer.periodic(const Duration(seconds: 30), (_) => _getBatteryLevel());
    _checkDevMessageStatus();
    _loadDevMessageDismissed();
    _fetchWeather();
  }

  @override
  void dispose() {
    _statsTimer?.cancel();
    channel?.sink.close(status.goingAway);
    _fadeCtrl.dispose();
    _glowCtrl.dispose();
    _bannerVideoCtrl?.dispose();
    _clockTimer?.cancel();
    super.dispose();
  }

  void _updateClock() {
    final now = DateTime.now();
    final newTime =
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}';
    if (newTime != _clockTime && mounted) {
      setState(() => _clockTime = newTime);
    }
  }

  void _initBannerVideo() {
    _bannerVideoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (mounted) setState(() {});
        _bannerVideoCtrl?.setLooping(true);
        _bannerVideoCtrl?.setVolume(1.0);
        _bannerVideoCtrl?.play();
      }).catchError((_) {});
  }

  Future<void> _fetchWeather() async {
    if (mounted) setState(() => _isLoadingWeather = true);

    try {
      final res = await http.get(
        Uri.parse(
          'https://api.bmkg.go.id/publik/prakiraan-cuaca?adm4=$_weatherRegionCode',
        ),
      ).timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final cuacaList = data['data']?[0]?['cuaca'];

        if (cuacaList != null && cuacaList.isNotEmpty) {
          final todayForecast = cuacaList[0] as List;
          if (todayForecast.isNotEmpty) {
            final current = todayForecast[0] as Map<String, dynamic>;

            if (mounted) {
              setState(() {
                _weatherData = {
                  'temp': current['t'] ?? 0,
                  'humidity': current['hu'] ?? 0,
                  'windSpeed': current['ws'] ?? 0,
                  'windDir': current['wd'] ?? '',
                  'weatherDesc': current['weather_desc'] ?? 'Tidak diketahui',
                  'weatherDescEn': current['weather_desc_en'] ?? '',
                  'cloudCover': current['tcc'] ?? 0,
                  'visibility': current['vs_text'] ?? '',
                  'localTime': current['local_datetime'] ?? '',
                };
                _isLoadingWeather = false;
                _weatherError = '';
              });
            }
            return;
          }
        }
      }

      if (mounted) {
        setState(() {
          _isLoadingWeather = false;
          _weatherError = 'Gagal memuat cuaca';
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoadingWeather = false;
          _weatherError = 'Koneksi error';
        });
      }
    }
  }

  Future<void> _checkDevMessageStatus() async {
    final prefs = await SharedPreferences.getInstance();
    final lastSeenDate = prefs.getString('dev_message_last_seen');

    final today = DateTime.now();
    final todayKey =
        '${today.year}-${today.month.toString().padLeft(2, '0')}-${today.day.toString().padLeft(2, '0')}';

    if (lastSeenDate == todayKey) {
      if (mounted) setState(() => _hasSeenDevMessageToday = true);
      return;
    }

    await Future.delayed(const Duration(milliseconds: 1500));
    if (mounted) _showDevMessageDialog();
  }

  Future<void> _markDevMessageSeen() async {
    final prefs = await SharedPreferences.getInstance();
    final today = DateTime.now();
    final todayKey =
        '${today.year}-${today.month.toString().padLeft(2, '0')}-${today.day.toString().padLeft(2, '0')}';
    await prefs.setString('dev_message_last_seen', todayKey);
    if (mounted) setState(() => _hasSeenDevMessageToday = true);
  }

  Future<void> _loadDevMessageDismissed() async {
    final prefs = await SharedPreferences.getInstance();
    final dismissed = prefs.getBool('dev_message_dismissed') ?? false;
    if (mounted) setState(() => _devMessageDismissed = dismissed);
  }

  void _showDevMessageDialog() {
    if (_hasShownDevMessage) return;
    _hasShownDevMessage = true;

    final C = AppTheme.current.value;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    HapticFeedback.mediumImpact();

    showDialog(
      context: context,
      barrierDismissible: true,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (dialogContext) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: isComic ? C.bgDark : null,
            gradient: isComic
                ? null
                : LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [C.text, C.bg, C.bgDark, C.bgDeep],
                    stops: const [0.0, 0.4, 0.7, 1.0],
                  ),
            borderRadius: BorderRadius.circular(isComic ? 20 : 19),
            border: Border.all(
              color: isComic
                  ? Colors.black
                  : Colors.black.withOpacity(0.5),
              width: isComic ? 4 : 3,
            ),
            boxShadow: isComic
                ? const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(6, 6),
                      blurRadius: 0,
                    ),
                  ]
                : null,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  if (!isComic) _Screw(C: C, size: 12),
                  if (!isComic) const SizedBox(width: 10),
                  _Led(color: C.primaryHi, size: 8, blink: !isComic),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _devMessageTitle,
                      style: TextStyle(
                        color: isComic ? C.comicText : C.accent,
                        fontSize: isComic ? 17 : 13,
                        fontWeight: FontWeight.w900,
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: isComic ? 2 : 2.5,
                        shadows: isComic
                            ? [
                                Shadow(
                                  color: C.comicTextOutline,
                                  offset: const Offset(1, 1),
                                  blurRadius: 0,
                                ),
                              ]
                            : const [
                                Shadow(
                                  color: Colors.black,
                                  offset: Offset(0, 1),
                                  blurRadius: 2,
                                ),
                              ],
                      ),
                    ),
                  ),
                  _Led(color: C.accent, size: 8, blink: !isComic),
                  if (!isComic) const SizedBox(width: 10),
                  if (!isComic) _Screw(C: C, size: 12, rotation: 0),
                ],
              ),
              const SizedBox(height: 16),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(isComic ? 10 : 20),
                  gradient: isComic
                      ? null
                      : LinearGradient(
                          colors: [C.accentHi, C.accent, C.primaryLo],
                        ),
                  color: isComic ? C.primaryHi : null,
                  border: Border.all(
                    color: isComic ? Colors.black : C.accentShine,
                    width: isComic ? 3 : 1.2,
                  ),
                  boxShadow: isComic
                      ? const [
                          BoxShadow(
                            color: Colors.black,
                            offset: Offset(3, 3),
                            blurRadius: 0,
                          ),
                        ]
                      : [
                          BoxShadow(
                            color: C.accent.withOpacity(0.5),
                            blurRadius: 10,
                          ),
                        ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _Led(
                        color: isComic ? C.comicTextOutline : C.bgDeep,
                        size: 5),
                    const SizedBox(width: 8),
                    Text(
                      'FROM KAIZEN TEAM',
                      style: TextStyle(
                        color: isComic
                            ? C.contrastTextOn(C.primaryHi)
                            : C.bgDeep,
                        fontSize: isComic ? 11 : 9,
                        fontWeight: FontWeight.w900,
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(width: 8),
                    _Led(
                        color: isComic ? C.comicTextOutline : C.bgDeep,
                        size: 5),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              ConstrainedBox(
                constraints: BoxConstraints(
                  maxHeight: MediaQuery.of(context).size.height * 0.35,
                ),
                child: _InsetPanel(
                  C: C,
                  padding: const EdgeInsets.all(14),
                  glow: !isComic,
                  glowColor: C.primaryHi,
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(
                              Icons.format_quote_rounded,
                              color: C.accent,
                              size: 18,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                _devMessageContent,
                                style: TextStyle(
                                  color: isComic
                                      ? C.comicText
                                      : C.text,
                                  fontSize: 12,
                                  height: 1.7,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: isComic
                                      ? 'ComicNeue'
                                      : 'ShareTechMono',
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            _Led(
                                color: C.primaryHi,
                                size: 5,
                                blink: !isComic),
                            const SizedBox(width: 8),
                            Text(
                              _devMessageAuthor,
                              style: TextStyle(
                                color: isComic
                                    ? C.comicText
                                    : C.accent.withOpacity(0.9),
                                fontSize: 10,
                                fontWeight: FontWeight.w900,
                                fontFamily:
                                    isComic ? 'Bangers' : 'Orbitron',
                                letterSpacing: 1.5,
                                shadows: isComic
                                    ? [
                                        Shadow(
                                          color:
                                              C.comicTextOutline,
                                          offset:
                                              const Offset(1, 1),
                                          blurRadius: 0,
                                        ),
                                      ]
                                    : null,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              _IndustrialButton(
                C: C,
                color: C.primaryHi,
                height: 48,
                onTap: () async {
                  HapticFeedback.selectionClick();
                  Navigator.pop(dialogContext);
                  await _markDevMessageSeen();
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.check_circle_rounded,
                      size: 16,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'MENGERTI & TUTUP',
                      style: TextStyle(
                        fontSize: isComic ? 13 : 11,
                        fontWeight: FontWeight.w900,
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: 2,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Pesan ini cuma muncul 1x sehari',
                style: TextStyle(
                  color: isComic
                      ? C.comicTextMuted
                      : C.textSub.withOpacity(0.6),
                  fontSize: 9,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _initAndroidId() async {
    try {
      final info = await DeviceInfoPlugin().androidInfo;
      androidId = info.id;
      deviceModel = info.model ?? 'Unknown';
      deviceBrand = info.brand ?? 'Unknown';
      androidVersion = info.version.release;
      sdkInt = info.version.sdkInt;
    } catch (_) {}
    _connectWS();
  }

  void _connectWS() {
    try {
      channel = WebSocketChannel.connect(Uri.parse(wsUrl));
    } catch (e) {
      Future.delayed(const Duration(seconds: 5), () {
        if (mounted) _connectWS();
      });
      return;
    }

    channel!.sink.add(jsonEncode({
      'type': 'validate',
      'key': sessionKey,
      'androidId': androidId,
    }));

    channel!.stream.listen((event) {
      try {
        final data = jsonDecode(event);
        if (data['type'] == 'myInfo' &&
            data['valid'] == true &&
            mounted) {
          channel!.sink.add(jsonEncode({'type': 'stats'}));
        }
        if (data['type'] == 'stats' && mounted) {
          setState(() {
            onlineUsers = data['onlineUsers'] ?? 0;
            activeConns = data['activeConnections'] ?? 0;
            activeConnections = activeConns;
          });
        }
        if (data['type'] == 'notification' && mounted) {
          _showSkeuoSnack(data['title'] ?? 'Notifikasi baru');
        }
        if (data['type'] == 'myInfo' &&
            data['valid'] == false &&
            mounted) {
          _handleInvalidSession(data['reason'] ?? 'Session invalid');
        }
        if (data['type'] == 'forceLogout' && mounted) {
          _handleInvalidSession(data['reason'] ?? 'Logged out');
        }
      } catch (_) {}
    }, onError: (_) {
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) _connectWS();
      });
    });

    _statsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      try {
        channel?.sink.add(jsonEncode({'type': 'stats'}));
      } catch (_) {}
    });
  }

  void _showSkeuoSnack(String msg) {
    final C = AppTheme.current.value;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            _Led(color: C.primaryHi, size: 8, blink: !isComic),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                msg,
                style: TextStyle(
                  fontSize: isComic ? 14 : 13,
                  fontFamily: isComic ? 'Bangers' : null,
                  fontWeight: FontWeight.w700,
                  color: isComic ? C.comicText : Colors.white,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: C.bgDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(isComic ? 12 : 8),
          side: BorderSide(
            color: isComic ? Colors.black : C.textSub,
            width: isComic ? 3 : 1.5,
          ),
        ),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  void _handleInvalidSession(String message) async {
    final C = AppTheme.current.value;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _Led(color: C.primaryHi, size: 12, blink: !isComic),
                  const SizedBox(width: 10),
                  Text(
                    'SESSION EXPIRED',
                    style: TextStyle(
                      color: isComic ? C.comicText : C.accent,
                      fontSize: isComic ? 16 : 14,
                      fontWeight: FontWeight.w900,
                      fontFamily:
                          isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 2,
                      shadows: isComic
                          ? [
                              Shadow(
                                color: C.comicTextOutline,
                                offset: const Offset(1, 1),
                                blurRadius: 0,
                              ),
                            ]
                          : null,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              Text(
                message,
                style: TextStyle(
                  color: isComic ? C.comicText : C.text,
                  fontSize: 12,
                  fontFamily:
                      isComic ? 'ComicNeue' : null,
                ),
              ),
              const SizedBox(height: 22),
              _IndustrialButton(
                C: C,
                color: C.primaryHi,
                height: 48,
                onTap: () => Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LoginPage()),
                  (_) => false,
                ),
                child: Text(
                  'KEMBALI KE LOGIN',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                    fontFamily:
                        isComic ? 'Bangers' : 'Orbitron',
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _onNavTap(int index) {
    if (index == 2) {
      _showWhatsAppMenu();
      return;
    }
    if (index == 1) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => InfoPage(sessionKey: sessionKey), 
        ),
      );
      return;
    }
    setState(() => _navIndex = index);
  }

  Widget _buildCurrentPage(AppPalette C) {
    switch (_navIndex) {
      case 0:
        return _buildHome(C);
      case 3:
        return CheckNotifPage(
          sessionKey: sessionKey,
          username: username,
          role: role,
        );
      case 4:
        return ToolsPage(
          sessionKey: sessionKey,
          userRole: role,
          username: username,
          listDoos: listDoos,
        );
      default:
        return _buildHome(C);
    }
  }

  Color _getStatusColor(AppPalette C, String status) {
    switch (status.toLowerCase()) {
      case 'active':
        return C.primaryHi;
      case 'expired':
        return C.primaryHi;
      case 'suspended':
        return C.accent;
      default:
        return C.accent;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'active':
        return Icons.check_circle_rounded;
      case 'expired':
        return Icons.cancel_rounded;
      case 'suspended':
        return Icons.warning_rounded;
      default:
        return Icons.info_rounded;
    }
  }

  String _formatDate(String date) {
    if (date.isEmpty) return 'N/A';
    final parts = date.split('-');
    if (parts.length == 3) return '${parts[2]}/${parts[1]}/${parts[0]}';
    return date;
  }

  Widget _buildHome(AppPalette C) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    return FadeTransition(
      opacity: _fadeAnim,
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(14, 8, 14, 100),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildStoryBar(C, isComic),
            const SizedBox(height: 14),

            _buildBannerWithOverlay(C, isComic),
            const SizedBox(height: 14),
            _buildDevMessageCard(C, isComic),
            const SizedBox(height: 14),
            _buildProfilePlate(C, isComic),
            const SizedBox(height: 14),

            // ✅ KEMBALI KE ORIGINAL: Support + Ubah Splash berjejer
            IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(child: _buildSupportDeveloperCard(C, isComic)),
                  const SizedBox(width: 10),
                  Expanded(child: _buildChangeSplashVideoCard(C, isComic)),
                ],
              ),
            ),
            const SizedBox(height: 14),

            // Clock+Calendar & Device Info (tidak berubah)
            _buildSwipeableClockAndDeviceCards(C, isComic),
            const SizedBox(height: 14),

            _buildWeatherCard(C, isComic),
            const SizedBox(height: 14),
            _buildSocialRack(C, isComic),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SWIPEABLE CLOCK+CALENDAR ⇄ DEVICE INFO
  // ═══════════════════════════════════════════════════════════
  Widget _buildSwipeableClockAndDeviceCards(AppPalette C, bool isComic) {
    return _SwipeableInfoCards(
      C: C,
      isComic: isComic,
      page1: _buildCombinedClockCalendarCard(C, isComic),
      page2: _buildDeviceInfoCard(C, isComic),
    );
  }

  Widget _buildStoryBar(AppPalette C, bool isComic) {
    if (_loadingStories) {
      return const SizedBox(
        height: 100,
        child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
      );
    }

    return RepaintBoundary(
      child: Container(
        height: 110,
        decoration: isComic
            ? BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(5, 5),
                    blurRadius: 0,
                  ),
                ],
                color: C.bgDark,
              )
            : null,
        child: isComic
            ? Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: _buildStoryListView(C, isComic),
              )
            : _MetalPlate(
                C: C,
                padding: EdgeInsets.zero,
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: _buildStoryListView(C, isComic),
                ),
              ),
      ),
    );
  }

  Widget _buildStoryListView(AppPalette C, bool isComic) {
    return ListView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      children: [
        GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => StoryPage(
                  sessionKey: sessionKey,
                  username: username,
                ),
              ),
            ).then((_) => _fetchDashboardStories());
          },
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: _dashMyStories.isNotEmpty
                          ? const LinearGradient(colors: [Colors.green, Colors.teal])
                          : null,
                      color: _dashMyStories.isNotEmpty ? null : C.bgDark,
                      border: Border.all(
                        color: isComic ? Colors.black : C.accent,
                        width: isComic ? 3 : 2,
                      ),
                    ),
                    padding: const EdgeInsets.all(2.5),
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: C.bg,
                      ),
                      padding: const EdgeInsets.all(2),
                      child: ClipOval(
                        child: _dashMyStories.isNotEmpty &&
                                _dashMyStories.first.mediaType == 'image'
                            ? Image.network(
                                _dashMyStories.first.mediaUrl,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Icon(
                                  Icons.person,
                                  color: C.textSub,
                                  size: 28,
                                ),
                              )
                            : Icon(
                                Icons.person,
                                color: C.textSub,
                                size: 28,
                              ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: -2,
                    right: -2,
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => StoryPage(
                              sessionKey: sessionKey,
                              username: username,
                            ),
                          ),
                        ).then((_) => _fetchDashboardStories());
                      },
                      child: Container(
                        width: 22,
                        height: 22,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: C.accent,
                          border: Border.all(color: C.bg, width: 2),
                        ),
                        child: Icon(
                          Icons.add,
                          size: 14,
                          color: C.contrastTextOn(C.accent),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                'Cerita Saya',
                style: TextStyle(
                  color: isComic ? C.comicText : C.text,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  fontFamily: isComic ? 'Bangers' : 'ShareTechMono',
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
        const SizedBox(width: 12),
        ..._dashOtherStories.map((group) {
          final first = group.stories.first;
          return Padding(
            padding: const EdgeInsets.only(right: 12),
            child: GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => StoryPage(
                      sessionKey: sessionKey,
                      username: username,
                    ),
                  ),
                ).then((_) => _fetchDashboardStories());
              },
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: group.hasUnviewed
                          ? LinearGradient(
                              colors: [C.primaryHi, C.accent],
                            )
                          : null,
                      color: group.hasUnviewed ? null : C.bgDark,
                      border: Border.all(
                        color: isComic ? Colors.black : C.textSub,
                        width: isComic ? 3 : 1.5,
                      ),
                    ),
                    padding: const EdgeInsets.all(2),
                    child: ClipOval(
                      child: first.mediaType == 'image'
                          ? Image.network(
                              first.mediaUrl,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                color: C.bgDark,
                                child: Icon(
                                  Icons.person,
                                  color: C.textSub,
                                  size: 28,
                                ),
                              ),
                            )
                          : Container(
                              color: C.bgDark,
                              child: Icon(
                                Icons.play_circle_outline,
                                color: C.textSub,
                                size: 28,
                              ),
                            ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    group.username,
                    style: TextStyle(
                      color: isComic ? C.comicText : C.text,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      fontFamily: isComic ? 'Bangers' : 'ShareTechMono',
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          );
        }).toList(),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SUPPORT DEVELOPER CARD (KEMBALI KE UKURAN ORIGINAL)
  // ═══════════════════════════════════════════════════════════
  Widget _buildSupportDeveloperCard(AppPalette C, bool isComic) {
    return RepaintBoundary(
      child: GestureDetector(
        onTap: () => _openUrl('https://t.me/syaxinfo'),
        child: Container(
          decoration: isComic
              ? BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: Colors.black, width: 4),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(6, 6),
                      blurRadius: 0,
                    ),
                  ],
                )
              : null,
          child: _MetalPlate(
            C: C,
            padding: const EdgeInsets.all(8), 
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center, 
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: isComic ? C.primaryHi : C.accent.withOpacity(0.15),
                    border: Border.all(
                      color: isComic ? Colors.black : C.accent,
                      width: isComic ? 3 : 1.5,
                    ),
                    boxShadow: isComic
                        ? null
                        : [
                            BoxShadow(
                              color: C.accent.withOpacity(0.3),
                              blurRadius: 10,
                            ),
                          ],
                  ),
                  child: FaIcon(
                    FontAwesomeIcons.telegram,
                    color: isComic ? C.contrastTextOn(C.primaryHi) : C.accent,
                    size: 24,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'SUPPORT',
                  style: TextStyle(
                    color: isComic ? C.comicText : C.text,
                    fontSize: isComic ? 12 : 10,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 1,
                  ),
                  textAlign: TextAlign.center,
                ),
                Text(
                  'DEVELOPER',
                  style: TextStyle(
                    color: isComic ? C.comicText : C.text,
                    fontSize: isComic ? 12 : 10,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 1,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 10),
                _InsetPanel(
                  C: C,
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  glow: !isComic,
                  glowColor: C.accent,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _Led(color: C.primaryHi, size: 4, blink: !isComic),
                      const SizedBox(width: 6),
                      Text(
                        'HUBUNGI',
                        style: TextStyle(
                          color: isComic ? C.comicText : C.accent,
                          fontSize: isComic ? 9 : 7,
                          fontWeight: FontWeight.w900,
                          fontFamily: isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // UBAH SPLASH VIDEO CARD (ORIGINAL)
  // ═══════════════════════════════════════════════════════════
  Widget _buildChangeSplashVideoCard(AppPalette C, bool isComic) {
    return RepaintBoundary(
      child: GestureDetector(
        onTap: _pickSplashVideo,
        child: Container(
          decoration: isComic
              ? BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: Colors.black, width: 4),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(6, 6),
                      blurRadius: 0,
                    ),
                  ],
                )
              : null,
          child: _MetalPlate(
            C: C,
            padding: const EdgeInsets.all(8),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: isComic ? C.primaryHi : C.primaryHi.withOpacity(0.15),
                    border: Border.all(
                      color: isComic ? Colors.black : C.primaryHi,
                      width: isComic ? 3 : 1.5,
                    ),
                    boxShadow: isComic
                        ? null
                        : [
                            BoxShadow(
                              color: C.primaryHi.withOpacity(0.3),
                              blurRadius: 10,
                            ),
                          ],
                  ),
                  child: Icon(
                    Icons.play_circle_fill_rounded,
                    color: isComic ? C.contrastTextOn(C.primaryHi) : C.primaryHi,
                    size: 24,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'UBAH VIDEO',
                  style: TextStyle(
                    color: isComic ? C.comicText : C.text,
                    fontSize: isComic ? 12 : 10,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 1,
                  ),
                  textAlign: TextAlign.center,
                ),
                Text(
                  'SPLASH',
                  style: TextStyle(
                    color: isComic ? C.comicText : C.text,
                    fontSize: isComic ? 12 : 10,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 1,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 10),
                _InsetPanel(
                  C: C,
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                  glow: !isComic,
                  glowColor: C.primaryHi,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _Led(color: C.primaryHi, size: 4, blink: !isComic),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          _customSplashVideoPath == null ? 'DEFAULT' : 'CUSTOM',
                          style: TextStyle(
                            color: isComic ? C.comicText : C.primaryHi,
                            fontSize: isComic ? 9 : 7,
                            fontWeight: FontWeight.w900,
                            fontFamily: isComic ? 'Bangers' : 'Orbitron',
                            letterSpacing: 0.5,
                          ),
                          textAlign: TextAlign.center,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (_customSplashVideoPath != null) ...[
                        const SizedBox(width: 4),
                        GestureDetector(
                          onTap: _resetSplashVideo,
                          child: Icon(Icons.close, color: C.accent, size: 12),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCombinedClockCalendarCard(AppPalette C, bool isComic) {
    final now = DateTime.now();
    final time = '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
    final seconds = now.second.toString().padLeft(2, '0');
    final days = ['SENIN', 'SELASA', 'RABU', 'KAMIS', 'JUMAT', 'SABTU', 'MINGGU'];
    final months = ['JANUARI', 'FEBRUARI', 'MARET', 'APRIL', 'MEI', 'JUNI', 'JULI', 'AGUSTUS', 'SEPTEMBER', 'OKTOBER', 'NOVEMBER', 'DESEMBER'];
    final monthName = months[now.month - 1];
    final dayName = days[now.weekday - 1];

    final firstDay = DateTime(now.year, now.month, 1);
    final daysInMonth = DateTime(now.year, now.month + 1, 0).day;
    final startWeekday = firstDay.weekday;
    final List<int?> cells = [];
    for (int i = 0; i < startWeekday - 1; i++) cells.add(null);
    for (int i = 1; i <= daysInMonth; i++) cells.add(i);
    while (cells.length % 7 != 0) cells.add(null);

    return RepaintBoundary(
      child: Container(
        decoration: isComic
            ? BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(color: Colors.black, offset: Offset(6, 6), blurRadius: 0),
                ],
              )
            : null,
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(12),
          child: IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(
                  flex: 4,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _Led(color: C.primaryHi, size: 6, blink: !isComic),
                          const SizedBox(width: 6),
                          Text(
                            'WAKTU',
                            style: TextStyle(
                              color: isComic ? C.comicText : C.accent,
                              fontSize: isComic ? 12 : 10,
                              fontWeight: FontWeight.w900,
                              fontFamily: isComic ? 'Bangers' : 'Orbitron',
                              letterSpacing: 2,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      _InsetPanel(
                        C: C,
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                        glow: !isComic,
                        glowColor: C.primaryHi,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.baseline,
                          textBaseline: TextBaseline.alphabetic,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              time,
                              style: TextStyle(
                                color: isComic ? C.comicText : C.primaryHi,
                                fontSize: isComic ? 32 : 28,
                                fontWeight: FontWeight.w900,
                                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                                letterSpacing: 1,
                                height: 1,
                                shadows: isComic
                                    ? [Shadow(color: C.comicTextOutline, offset: const Offset(2, 2), blurRadius: 0)]
                                    : [Shadow(color: C.primaryHi.withOpacity(0.6), blurRadius: 8)],
                              ),
                            ),
                            const SizedBox(width: 2),
                            Text(
                              seconds,
                              style: TextStyle(
                                color: isComic ? C.comicTextSub : C.accent,
                                fontSize: isComic ? 14 : 12,
                                fontWeight: FontWeight.w900,
                                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                                height: 1,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        '$dayName\n${now.day} $monthName',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: isComic ? C.comicTextSub : C.text.withOpacity(0.7),
                          fontSize: isComic ? 11 : 9,
                          fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                          fontWeight: FontWeight.w700,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ),
                
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: Container(
                    width: isComic ? 3 : 1,
                    color: isComic ? Colors.black : C.accent.withOpacity(0.3),
                  ),
                ),

                Expanded(
                  flex: 5,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _Led(color: C.accent, size: 6, blink: !isComic),
                          const SizedBox(width: 6),
                          Text(
                            'KALENDER',
                            style: TextStyle(
                              color: isComic ? C.comicText : C.accent,
                              fontSize: isComic ? 12 : 10,
                              fontWeight: FontWeight.w900,
                              fontFamily: isComic ? 'Bangers' : 'Orbitron',
                              letterSpacing: 2,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      _InsetPanel(
                        C: C,
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                        glow: !isComic,
                        glowColor: C.accent,
                        child: Center(
                          child: Text(
                            '$monthName ${now.year}',
                            style: TextStyle(
                              color: isComic ? C.comicText : C.accent,
                              fontSize: isComic ? 11 : 9,
                              fontWeight: FontWeight.w900,
                              fontFamily: isComic ? 'Bangers' : 'Orbitron',
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: ['S', 'S', 'R', 'K', 'J', 'S', 'M'].map((d) {
                          return Expanded(
                            child: Center(
                              child: Text(
                                d,
                                style: TextStyle(
                                  color: isComic ? C.comicTextSub : C.text.withOpacity(0.5),
                                  fontSize: isComic ? 8 : 7,
                                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 4),
                      ...List.generate(cells.length ~/ 7, (row) {
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 2),
                          child: Row(
                            children: List.generate(7, (col) {
                              final idx = row * 7 + col;
                              final day = cells[idx];
                              final isToday = day == now.day;
                              final isWeekend = col >= 5;

                              return Expanded(
                                child: Center(
                                  child: Container(
                                    width: isComic ? 18 : 16,
                                    height: isComic ? 18 : 16,
                                    decoration: isToday
                                        ? BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: isComic ? C.primaryHi : C.primaryHi.withOpacity(0.25),
                                            border: Border.all(
                                              color: isComic ? Colors.black : C.primaryHi,
                                              width: isComic ? 2 : 1,
                                            ),
                                          )
                                        : null,
                                    alignment: Alignment.center,
                                    child: day == null
                                        ? const SizedBox.shrink()
                                        : Text(
                                            '$day',
                                            style: TextStyle(
                                              color: isToday
                                                  ? (isComic ? C.contrastTextOn(C.primaryHi) : C.primaryHi)
                                                  : isWeekend
                                                      ? (isComic ? C.comicTextMuted : C.textSub)
                                                      : (isComic ? C.comicText : C.text),
                                              fontSize: isComic ? 10 : 9,
                                              fontWeight: isToday ? FontWeight.w900 : FontWeight.w700,
                                              fontFamily: isComic ? 'Bangers' : 'ShareTechMono',
                                            ),
                                          ),
                                  ),
                                ),
                              );
                            }),
                          ),
                        );
                      }),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDeviceInfoCard(AppPalette C, bool isComic) {
    return RepaintBoundary(
      child: Container(
        decoration: isComic
            ? BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(6, 6),
                    blurRadius: 0,
                  ),
                ],
              )
            : null,
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(12), 
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.devices_other_rounded, color: C.primaryHi, size: 18), 
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'DEVICE INFO',
                      style: TextStyle(
                        color: isComic ? C.comicText : C.accent,
                        fontSize: isComic ? 14 : 12, 
                        fontWeight: FontWeight.w900,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: 1,
                        shadows: isComic
                            ? [
                                Shadow(
                                  color: C.comicTextOutline,
                                  offset: const Offset(1, 1),
                                  blurRadius: 0,
                                ),
                              ]
                            : null,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              
              Row(
                children: [
                  Expanded(
                    child: _buildDeviceInfoItem(
                      C: C, 
                      isComic: isComic, 
                      icon: FontAwesomeIcons.android, 
                      label: 'Versi', 
                      value: 'Android $androidVersion',
                      valueColor: C.text,
                    ),
                  ),
                  Container(width: 1, height: 40, color: C.textSub.withOpacity(0.15)),
                  Expanded(
                    child: _buildDeviceInfoItem(
                      C: C, 
                      isComic: isComic, 
                      icon: Icons.battery_charging_full_rounded, 
                      label: 'Baterai', 
                      value: '$batteryLevel%',
                      valueColor: Colors.amber,
                    ),
                  ),
                  Container(width: 1, height: 40, color: C.textSub.withOpacity(0.15)),
                  Expanded(
                    child: _buildDeviceInfoItem(
                      C: C, 
                      isComic: isComic, 
                      icon: Icons.signal_cellular_alt_rounded, 
                      label: 'Jaringan', 
                      value: networkType,
                      valueColor: Colors.lightBlueAccent,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDeviceInfoItem({
    required AppPalette C,
    required bool isComic,
    required Object icon,
    required String label,
    required String value,
    required Color valueColor,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8), 
      child: Row(
        children: [
          icon is IconData
              ? Icon(icon, color: C.accent, size: 18)
              : FaIcon(icon as FaIconData, color: C.accent, size: 18), 
          const SizedBox(width: 8), 
          Expanded( 
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: isComic ? C.comicTextSub : C.textSub.withOpacity(0.7),
                    fontSize: 10, 
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: TextStyle(
                    color: valueColor,
                    fontSize: isComic ? 13 : 12, 
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 0.5,
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBannerWithOverlay(AppPalette C, bool isComic) {
    return RepaintBoundary(
      child: Container(
        decoration: isComic
            ? BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(6, 6),
                    blurRadius: 0,
                  ),
                ],
              )
            : null,
        child: _MetalPlate(
          C: C,
          padding: EdgeInsets.zero,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(isComic ? 14 : 13),
            child: AspectRatio(
              aspectRatio: 20 / 9,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  if (_bannerVideoCtrl != null &&
                      _bannerVideoCtrl!.value.isInitialized)
                    FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _bannerVideoCtrl!.value.size.width,
                        height: _bannerVideoCtrl!.value.size.height,
                        child: VideoPlayer(_bannerVideoCtrl!),
                      ),
                    )
                  else
                    Image.asset(
                      'assets/images/banner.jpg',
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: C.bgDeep,
                        child: Center(
                          child: Text(
                            'KAIZEN',
                            style: TextStyle(
                              color: C.accent,
                              fontSize: isComic ? 28 : 24,
                              fontFamily:
                                  isComic ? 'Bangers' : 'Orbitron',
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ),
                    ),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.black.withOpacity(0.7),
                          Colors.transparent,
                          Colors.transparent,
                          Colors.black.withOpacity(0.8),
                        ],
                        stops: const [0.0, 0.3, 0.7, 1.0],
                      ),
                    ),
                  ),
                  Positioned(
                    top: 10,
                    left: 10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(
                            isComic ? 10 : 20),
                        color: Colors.black.withOpacity(0.75),
                        border: Border.all(
                          color: isComic ? Colors.white : C.textSub,
                          width: isComic ? 2 : 1,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          _Led(
                              color: C.primaryHi,
                              size: 6,
                              blink: !isComic),
                          const SizedBox(width: 6),
                          Text(
                            'LIVE',
                            style: TextStyle(
                              color: isComic
                                  ? C.comicText
                                  : C.text.withOpacity(0.9),
                              fontSize: isComic ? 11 : 9,
                              fontWeight: FontWeight.w900,
                              fontFamily:
                                  isComic ? 'Bangers' : 'Orbitron',
                              letterSpacing: 1.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    top: 10,
                    right: 10,
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          _slideRoute(NotificationPage(
                            sessionKey: sessionKey,
                            username: username,
                            role: role,
                          )),
                        );
                      },
                      child: Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          shape: isComic
                              ? BoxShape.rectangle
                              : BoxShape.circle,
                          borderRadius: isComic
                              ? BorderRadius.circular(8)
                              : null,
                          gradient: isComic
                              ? null
                              : LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [C.textSub, C.bgDark],
                                ),
                          color: isComic ? C.primaryHi : null,
                          border: Border.all(
                            color:
                                isComic ? Colors.black : C.accent,
                            width: isComic ? 3 : 1.5,
                          ),
                          boxShadow: isComic
                              ? const [
                                  BoxShadow(
                                    color: Colors.black,
                                    offset: Offset(3, 3),
                                    blurRadius: 0,
                                  ),
                                ]
                              : [
                                  BoxShadow(
                                    color:
                                        Colors.black.withOpacity(0.7),
                                    offset: const Offset(0, 3),
                                    blurRadius: 6,
                                  ),
                                ],
                        ),
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Icon(Icons.notifications_rounded,
                                color: isComic
                                    ? C.contrastTextOn(C.primaryHi)
                                    : C.accent,
                                size: 20),
                            Positioned(
                              top: 6,
                              right: 6,
                              child: _Led(
                                  color: isComic
                                      ? C.contrastTextOn(C.primaryHi)
                                      : C.primaryHi,
                                  size: 6,
                                  blink: !isComic),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 12,
                    bottom: 10,
                    right: 12,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                'WELCOME BACK,',
                                style: TextStyle(
                                  color: C.accent.withOpacity(0.85),
                                  fontSize: isComic ? 11 : 9,
                                  fontWeight: FontWeight.w900,
                                  fontFamily:
                                      isComic ? 'Bangers' : 'Orbitron',
                                  letterSpacing: 3,
                                  shadows: const [
                                    Shadow(
                                        color: Colors.black,
                                        offset: Offset(0, 1),
                                        blurRadius: 2),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 2),
                              Row(
                                children: [
                                  Flexible(
                                    child: Text(
                                      username.toUpperCase(),
                                      style: TextStyle(
                                        color: C.text,
                                        fontSize: isComic ? 24 : 20,
                                        fontWeight: FontWeight.w900,
                                        fontFamily: isComic
                                            ? 'Bangers'
                                            : 'Orbitron',
                                        letterSpacing:
                                            isComic ? 1 : 1.5,
                                        shadows: const [
                                          Shadow(
                                              color: Colors.black,
                                              offset: Offset(0, 2),
                                              blurRadius: 4),
                                        ],
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 3),
                                    decoration: BoxDecoration(
                                      borderRadius:
                                          BorderRadius.circular(
                                              isComic ? 6 : 4),
                                      gradient: isComic
                                          ? null
                                          : LinearGradient(
                                              colors: [
                                                C.primary,
                                                C.primaryLo
                                              ],
                                            ),
                                      color:
                                          isComic ? C.accent : null,
                                      border: Border.all(
                                        color: isComic
                                            ? Colors.black
                                            : C.accentHi,
                                        width: isComic ? 2 : 1,
                                      ),
                                    ),
                                    child: Text(
                                      role.toUpperCase(),
                                      style: TextStyle(
                                        color: isComic
                                            ? C.contrastTextOn(C.accent)
                                            : C.accentShine,
                                        fontSize: isComic ? 10 : 8,
                                        fontWeight: FontWeight.w900,
                                        fontFamily: isComic
                                            ? 'Bangers'
                                            : 'Orbitron',
                                        letterSpacing: 1.5,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (!isComic)
                    Positioned(
                        top: 4, left: 4, child: _Rivet(C: C, size: 8)),
                  if (!isComic)
                    Positioned(
                        top: 4, right: 4, child: _Rivet(C: C, size: 8)),
                  if (!isComic)
                    Positioned(
                        bottom: 4, left: 4, child: _Rivet(C: C, size: 8)),
                  if (!isComic)
                    Positioned(
                        bottom: 4, right: 4, child: _Rivet(C: C, size: 8)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildWeatherCard(AppPalette C, bool isComic) {
    if (_isLoadingWeather) {
      return _MetalPlate(
        C: C,
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            _Led(color: C.accent, size: 8, blink: !isComic),
            const SizedBox(width: 12),
            Text(
              'MEMUAT CUACA...',
              style: TextStyle(
                color: isComic ? C.comicText : C.textSub,
                fontSize: 10,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                fontWeight: FontWeight.w700,
                letterSpacing: 2,
                shadows: isComic
                    ? [
                        Shadow(
                          color: C.comicTextOutline,
                          offset: const Offset(1, 1),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
            ),
          ],
        ),
      );
    }

    if (_weatherError.isNotEmpty || _weatherData == null) {
      return _MetalPlate(
        C: C,
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            _Led(color: C.primaryHi, size: 8, blink: !isComic),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                _weatherError.isNotEmpty
                    ? 'CUACA: $_weatherError'
                    : 'CUACA TIDAK TERSEDIA',
                style: TextStyle(
                  color: isComic ? C.comicText : C.primaryHi,
                  fontSize: 10,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.5,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
            ),
            GestureDetector(
              onTap: _fetchWeather,
              child: Icon(
                Icons.refresh_rounded,
                color: C.accent,
                size: 16,
              ),
            ),
          ],
        ),
      );
    }

    final weather = _weatherData!;
    final temp = weather['temp'];
    final desc = weather['weatherDesc'] as String;
    final humidity = weather['humidity'];
    final windSpeed = weather['windSpeed'];

    return RepaintBoundary(
      child: Container(
        decoration: isComic
            ? BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(6, 6),
                    blurRadius: 0,
                  ),
                ],
              )
            : null,
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(14),
          child: Column(
            children: [
              Row(
                children: [
                  if (!isComic) _Screw(C: C, size: 12),
                  if (!isComic) const SizedBox(width: 10),
                  _Led(color: C.primaryHi, size: 6, blink: !isComic),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'WEATHER NOW',
                      style: TextStyle(
                        color: isComic ? C.comicText : C.accent,
                        fontSize: isComic ? 13 : 10,
                        fontWeight: FontWeight.w900,
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: 2,
                        shadows: isComic
                            ? [
                                Shadow(
                                  color: C.comicTextOutline,
                                  offset: const Offset(1, 1),
                                  blurRadius: 0,
                                ),
                              ]
                            : const [
                                Shadow(
                                  color: Colors.black,
                                  offset: Offset(0, 1),
                                  blurRadius: 2,
                                ),
                              ],
                      ),
                    ),
                  ),
                  _Led(color: C.accent, size: 6, blink: !isComic),
                  const SizedBox(width: 10),
                  GestureDetector(
                    onTap: _fetchWeather,
                    child: Icon(
                      Icons.refresh_rounded,
                      color: C.accent,
                      size: 14,
                    ),
                  ),
                  if (!isComic) const SizedBox(width: 6),
                  if (!isComic) _Screw(C: C, size: 12, rotation: 0),
                ],
              ),
              const SizedBox(height: 12),
              _InsetPanel(
                C: C,
                padding: const EdgeInsets.all(12),
                glow: !isComic,
                glowColor: C.accent,
                child: Row(
                  children: [
                    Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: isComic
                            ? null
                            : RadialGradient(
                                colors: [
                                  C.accent.withOpacity(0.3),
                                  C.accent.withOpacity(0.1),
                                  Colors.black.withOpacity(0.8),
                                ],
                              ),
                        color: isComic ? C.primaryHi : null,
                        border: Border.all(
                          color: isComic
                              ? Colors.black
                              : C.accent.withOpacity(0.6),
                          width: isComic ? 3 : 1.5,
                        ),
                        boxShadow: isComic
                            ? null
                            : [
                                BoxShadow(
                                  color: C.accent.withOpacity(0.4),
                                  blurRadius: 12,
                                ),
                              ],
                      ),
                      child: Icon(
                        _getWeatherIcon(desc),
                        color: isComic
                            ? C.contrastTextOn(C.primaryHi)
                            : C.accent,
                        size: 28,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                '$temp',
                                style: TextStyle(
                                  color:
                                      isComic ? C.comicText : C.text,
                                  fontSize: isComic ? 30 : 26,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: isComic
                                      ? 'Bangers'
                                      : 'Orbitron',
                                  height: 1,
                                  shadows: isComic
                                      ? [
                                          Shadow(
                                            color:
                                                C.comicTextOutline,
                                            offset:
                                                const Offset(2, 2),
                                            blurRadius: 0,
                                          ),
                                        ]
                                      : [
                                          Shadow(
                                            color: C.accent
                                                .withOpacity(0.5),
                                            blurRadius: 8,
                                          ),
                                        ],
                                ),
                              ),
                              const SizedBox(width: 2),
                              Text(
                                '°C',
                                style: TextStyle(
                                  color: C.accent,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: isComic
                                      ? 'Bangers'
                                      : 'Orbitron',
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 2),
                          Text(
                            desc,
                            style: TextStyle(
                              color: isComic
                                  ? C.comicText.withOpacity(0.85)
                                  : C.text.withOpacity(0.85),
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              fontFamily: isComic
                                  ? 'ComicNeue'
                                  : 'ShareTechMono',
                              shadows: isComic
                                  ? [
                                      Shadow(
                                        color: C.comicTextOutline,
                                        offset: const Offset(1, 1),
                                        blurRadius: 0,
                                      ),
                                    ]
                                  : null,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              _Led(color: C.primaryHi, size: 4),
                              const SizedBox(width: 4),
                              Text(
                                '💧 $humidity%',
                                style: TextStyle(
                                  color: isComic
                                      ? C.comicTextSub
                                      : C.text.withOpacity(0.6),
                                  fontSize: 9,
                                  fontFamily: isComic
                                      ? 'ComicNeue'
                                      : 'ShareTechMono',
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              const SizedBox(width: 10),
                              _Led(color: C.accent, size: 4),
                              const SizedBox(width: 4),
                              Text(
                                '💨 $windSpeed km/j',
                                style: TextStyle(
                                  color: isComic
                                      ? C.comicTextSub
                                      : C.text.withOpacity(0.6),
                                  fontSize: 9,
                                  fontFamily: isComic
                                      ? 'ComicNeue'
                                      : 'ShareTechMono',
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  IconData _getWeatherIcon(String desc) {
    final d = desc.toLowerCase();
    if (d.contains('hujan') && d.contains('petir')) {
      return Icons.thunderstorm_rounded;
    }
    if (d.contains('hujan') && d.contains('lebat')) {
      return Icons.water_drop_rounded;
    }
    if (d.contains('hujan')) return Icons.grain_rounded;
    if (d.contains('berawan') && d.contains('tebal')) {
      return Icons.cloud_rounded;
    }
    if (d.contains('berawan')) return Icons.cloud_queue_rounded;
    if (d.contains('cerah') && d.contains('berawan')) {
      return Icons.wb_cloudy_rounded;
    }
    if (d.contains('cerah')) return Icons.wb_sunny_rounded;
    if (d.contains('kabur') || d.contains('asap')) return Icons.foggy;
    if (d.contains('angin')) return Icons.air_rounded;
    return Icons.cloud_rounded;
  }

  Widget _buildDevMessageCard(AppPalette C, bool isComic) {
    if (_devMessageDismissed) return const SizedBox.shrink();

    return RepaintBoundary(
      child: GestureDetector(
        onTap: () {
          HapticFeedback.selectionClick();
          _showDevMessageDialog();
        },
        behavior: HitTestBehavior.opaque,
        child: Container(
          decoration: isComic
              ? BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.black, width: 4),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(5, 5),
                      blurRadius: 0,
                    ),
                  ],
                )
              : null,
          child: _MetalPlate(
            C: C,
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Row(
              children: [
                Stack(
                  alignment: Alignment.center,
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: isComic
                            ? null
                            : RadialGradient(
                                center:
                                    const Alignment(-0.3, -0.3),
                                colors: [
                                  C.accentHi,
                                  C.accent,
                                  C.primaryLo
                                ],
                              ),
                        color: isComic ? C.primaryHi : null,
                        border: Border.all(
                            color: isComic
                                ? Colors.black
                                : C.accentShine,
                            width: isComic ? 3 : 1.5),
                        boxShadow: isComic
                            ? null
                            : [
                                BoxShadow(
                                  color:
                                      C.accent.withOpacity(0.5),
                                  blurRadius: 10,
                                  spreadRadius: 1,
                                ),
                              ],
                      ),
                      child: Icon(
                        Icons.mark_email_unread_rounded,
                        color: isComic
                            ? C.contrastTextOn(C.primaryHi)
                            : C.bgDeep,
                        size: 20,
                      ),
                    ),
                    Positioned(
                      top: 0,
                      right: 0,
                      child: _Led(
                          color: C.primaryHi,
                          size: 8,
                          blink: !isComic),
                    ),
                  ],
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          if (!isComic)
                            _Led(
                                color: C.primaryHi,
                                size: 5,
                                blink: true),
                          if (!isComic) const SizedBox(width: 6),
                          Text(
                            'MESSAGE FROM DEVELOPER',
                            style: TextStyle(
                              color: isComic
                                  ? C.comicText
                                  : C.accent,
                              fontSize: isComic ? 12 : 9,
                              fontWeight: FontWeight.w900,
                              fontFamily: isComic
                                  ? 'Bangers'
                                  : 'Orbitron',
                              letterSpacing: 1.5,
                              shadows: isComic
                                  ? [
                                      Shadow(
                                        color: C.comicTextOutline,
                                        offset: const Offset(1, 1),
                                        blurRadius: 0,
                                      ),
                                    ]
                                  : const [
                                      Shadow(
                                        color: Colors.black,
                                        offset: Offset(0, 1),
                                        blurRadius: 2,
                                      ),
                                    ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Tap Untuk Lihat Pesan Dari Developer KAIZEN',
                        style: TextStyle(
                          color: isComic
                              ? C.comicText.withOpacity(0.85)
                              : C.text.withOpacity(0.7),
                          fontSize: 10.5,
                          fontWeight: FontWeight.w600,
                          fontFamily: isComic
                              ? 'ComicNeue'
                              : 'ShareTechMono',
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    shape: isComic
                        ? BoxShape.rectangle
                        : BoxShape.circle,
                    borderRadius:
                        isComic ? BorderRadius.circular(6) : null,
                    color:
                        isComic ? C.accent : Colors.black.withOpacity(0.5),
                    border: Border.all(
                      color: isComic
                          ? Colors.black
                          : C.accent.withOpacity(0.5),
                      width: isComic ? 2 : 1,
                    ),
                  ),
                  child: Icon(
                    Icons.arrow_forward_ios_rounded,
                    color: isComic
                        ? C.contrastTextOn(C.accent)
                        : C.accent,
                    size: 12,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProfilePlate(AppPalette C, bool isComic) {
    return RepaintBoundary(
      child: Container(
        decoration: isComic
            ? BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(6, 6),
                    blurRadius: 0,
                  ),
                ],
              )
            : null,
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(14),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: isComic
                          ? null
                          : RadialGradient(
                              colors: [C.text, C.bg, C.bgDark],
                            ),
                      color: isComic ? C.primaryHi : null,
                      border: Border.all(
                        color: isComic ? Colors.black : C.accent,
                        width: isComic ? 3 : 2,
                      ),
                      boxShadow: isComic
                          ? null
                          : [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.8),
                                offset: const Offset(0, 4),
                                blurRadius: 8,
                              ),
                              BoxShadow(
                                color: C.accent.withOpacity(0.3),
                                blurRadius: 12,
                                spreadRadius: 2,
                              ),
                            ],
                    ),
                    padding: const EdgeInsets.all(2),
                    child: ClipOval(
                      child: Image.asset(
                        'assets/images/logo.jpg',
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Icon(
                          Icons.person,
                          color: isComic ? C.contrastTextOn(C.primaryHi) : C.accent,
                          size: 30,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _getGreeting(),
                          style: TextStyle(
                            color: isComic
                                ? C.comicTextSub
                                : C.accent.withOpacity(0.7),
                            fontSize: 9,
                            fontFamily: isComic
                                ? 'ComicNeue'
                                : 'ShareTechMono',
                            letterSpacing: 2,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 4),
                        
                        Row(
                          children: [
                            Flexible(
                              child: Text(
                                username,
                                style: TextStyle(
                                  color: isComic ? C.comicText : C.text,
                                  fontSize: isComic ? 20 : 16,
                                  fontWeight: FontWeight.w900,
                                  fontFamily:
                                      isComic ? 'Bangers' : 'Orbitron',
                                  letterSpacing: 1,
                                  shadows: isComic
                                      ? [
                                          Shadow(
                                            color: C.comicTextOutline,
                                            offset: const Offset(2, 2),
                                            blurRadius: 0,
                                          ),
                                        ]
                                      : const [
                                          Shadow(
                                              color: Colors.black54,
                                              offset: Offset(0, 1),
                                              blurRadius: 2),
                                        ],
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            const SizedBox(width: 6),
                            Icon(
                              Icons.verified,
                              color: Colors.lightBlueAccent,
                              size: isComic ? 20 : 18,
                              shadows: isComic ? const [Shadow(color: Colors.black, blurRadius: 1, offset: Offset(1,1))] : null,
                            ),
                          ],
                        ),
                        
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            _Led(
                                color: _getStatusColor(
                                    C, _accountStatus),
                                size: 5),
                            const SizedBox(width: 6),
                            Text(
                              'ACTIVE · ${_formatDate(expiredDate)}',
                              style: TextStyle(
                                color: isComic
                                    ? C.comicTextSub
                                    : C.text.withOpacity(0.6),
                                fontSize: 9,
                                fontFamily: isComic
                                    ? 'ComicNeue'
                                    : 'ShareTechMono',
                                letterSpacing: 1,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  if (!isComic)
                    Column(
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            _signalBar(C, 3, true),
                            _signalBar(C, 6, true),
                            _signalBar(C, 9, true),
                            _signalBar(C, 12, true),
                          ],
                        ),
                        const SizedBox(height: 3),
                        Text(
                          'SIGNAL',
                          style: TextStyle(
                            color: C.accent.withOpacity(0.7),
                            fontSize: 6,
                            fontFamily: 'Orbitron',
                            letterSpacing: 1,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ],
                    ),
                ],
              ),
              const SizedBox(height: 12),
              Container(
                height: isComic ? 3 : 1,
                color: isComic ? Colors.black : null,
                decoration: isComic
                    ? null
                    : BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.transparent,
                            C.accent.withOpacity(0.4),
                            Colors.transparent,
                          ],
                        ),
                      ),
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.info_outline, color: C.accent, size: 12),
                  const SizedBox(width: 6),
                  Text(
                    'SYAX · TEAM',
                    style: TextStyle(
                      color: isComic
                          ? C.comicTextSub
                          : C.text.withOpacity(0.7),
                      fontSize: 10,
                      fontFamily:
                          isComic ? 'ComicNeue' : 'ShareTechMono',
                      letterSpacing: 1.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Upgrade Role? ',
                    style: TextStyle(
                      color: isComic
                          ? C.comicTextSub
                          : C.text.withOpacity(0.5),
                      fontSize: 10,
                      fontFamily:
                          isComic ? 'ComicNeue' : 'ShareTechMono',
                    ),
                  ),
                  GestureDetector(
                    onTap: () async {
                      final url = Uri.parse("https://t.me/KaizennTzyy");
                      if (await canLaunchUrl(url)) {
                        await launchUrl(url,
                            mode: LaunchMode.externalApplication);
                      }
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        borderRadius:
                            BorderRadius.circular(isComic ? 4 : 3),
                        color: isComic
                            ? C.primaryHi
                            : C.primaryLo.withOpacity(0.5),
                        border: Border.all(
                          color: isComic ? Colors.black : C.accent,
                          width: isComic ? 2 : 0.8,
                        ),
                      ),
                      child: Text(
                        '@KaizennTzyy',
                        style: TextStyle(
                          color: isComic
                              ? C.contrastTextOn(C.primaryHi)
                              : C.accentShine,
                          fontSize: 10,
                          fontFamily:
                              isComic ? 'Bangers' : 'ShareTechMono',
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _signalBar(AppPalette C, double h, bool active) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 1),
      child: Container(
        width: 3,
        height: h,
        decoration: BoxDecoration(
          color: active ? C.primaryHi : C.bgDark,
          borderRadius: BorderRadius.circular(1),
          boxShadow: active
              ? [
                  BoxShadow(
                    color: C.primaryHi.withOpacity(0.6),
                    blurRadius: 4,
                    spreadRadius: 0.5,
                  ),
                ]
              : null,
        ),
      ),
    );
  }

  Widget _buildSocialRack(AppPalette C, bool isComic) {
    return RepaintBoundary(
      child: Container(
        decoration: isComic
            ? BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(5, 5),
                    blurRadius: 0,
                  ),
                ],
              )
            : null,
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Expanded(
                child: _IndustrialButton(
                  C: C,
                  color: const Color(0xFF1E88E5),
                  height: 52,
                  onTap: () => _openUrl('https://t.me/KaizennTzyy'),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      FaIcon(FontAwesomeIcons.telegram, size: 18),
                      const SizedBox(width: 8),
                      const Text(
                        'TELEGRAM',
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 12,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _IndustrialButton(
                  C: C,
                  color: const Color(0xFF212121),
                  height: 52,
                  onTap: () =>
                      _openUrl('https://www.tiktok.com/@anda_siapaku'),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      FaIcon(FontAwesomeIcons.tiktok, size: 18),
                      const SizedBox(width: 8),
                      const Text(
                        'TIKTOK',
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 12,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSheetItem({
    required AppPalette C,
    required Object icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    required bool isComic,
  }) {
    return _IndustrialButton(
      C: C,
      color: C.bg,
      height: 68,
      onTap: onTap,
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: isComic
                  ? null
                  : LinearGradient(
                      colors: [
                        iconColor.withOpacity(0.3),
                        iconColor.withOpacity(0.1),
                      ],
                    ),
              color: isComic ? iconColor : null,
              border: Border.all(
                color: isComic
                    ? Colors.black
                    : iconColor.withOpacity(0.5),
                width: isComic ? 2.5 : 1,
              ),
              boxShadow: isComic
                  ? null
                  : [
                      BoxShadow(
                        color: iconColor.withOpacity(0.4),
                        blurRadius: 8,
                      ),
                    ],
            ),
            child: (icon is IconData ? Icon(icon,
                color: isComic
                    ? iconColor.computeLuminance() > 0.5
                        ? Colors.black
                        : Colors.white
                    : iconColor,
                size: 20) : FaIcon(icon as FaIconData, color: iconColor, size: 20)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: isComic ? C.comicText : Colors.white,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: isComic ? 15 : 13,
                    letterSpacing: isComic ? 1 : 0.8,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.comicTextOutline,
                              offset: const Offset(1, 1),
                              blurRadius: 0,
                            ),
                          ]
                        : null,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: isComic
                        ? C.comicTextSub
                        : C.text.withOpacity(0.55),
                    fontFamily:
                        isComic ? 'ComicNeue' : 'ShareTechMono',
                    fontSize: 10,
                  ),
                ),
              ],
            ),
          ),
          Icon(Icons.arrow_forward_ios_rounded,
              color: C.accent, size: 14),
        ],
      ),
    );
  }

  void _showWhatsAppMenu() {
    final C = AppTheme.current.value;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.85),
      isScrollControlled: true,
      builder: (context) {
        return Container(
          decoration: isComic
              ? BoxDecoration(
                  color: C.bgDark,
                  borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(24)),
                  border: Border.all(color: Colors.black, width: 4),
                )
              : null,
          child: _MetalPlate(
            C: C,
            padding: const EdgeInsets.all(18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 50,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: 20),
                  decoration: BoxDecoration(
                    color: isComic ? Colors.black : C.textSub,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: isComic
                            ? null
                            : LinearGradient(
                                colors: [C.text, C.bg, C.bgDark],
                              ),
                        color: isComic ? C.primaryHi : null,
                        border: Border.all(
                            color: isComic
                                ? Colors.black
                                : C.primaryHi.withOpacity(0.6),
                            width: isComic ? 3 : 1.5),
                        boxShadow: isComic
                            ? null
                            : [
                                BoxShadow(
                                  color:
                                      C.primaryHi.withOpacity(0.4),
                                  blurRadius: 10,
                                ),
                              ],
                      ),
                      child: FaIcon(FontAwesomeIcons.whatsapp,
                          color: isComic
                              ? C.contrastTextOn(C.primaryHi)
                              : C.primaryHi,
                          size: 20),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Text(
                        'WHATSAPP TOOLS',
                        style: TextStyle(
                          color: isComic ? C.comicText : C.accent,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          fontSize: isComic ? 18 : 15,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2,
                          shadows: isComic
                              ? [
                                  Shadow(
                                    color: C.comicTextOutline,
                                    offset: const Offset(1, 1),
                                    blurRadius: 0,
                                  ),
                                ]
                              : null,
                        ),
                      ),
                    ),
                    _Led(
                        color: C.primaryHi,
                        size: 8,
                        blink: !isComic),
                  ],
                ),
                const SizedBox(height: 18),
                _buildSheetItem(
                  C: C,
                  icon: Icons.bug_report_rounded,
                  iconColor: C.primaryHi,
                  title: 'WhatsApp Crash',
                  subtitle: 'Send payloads & crash codes',
                  isComic: isComic,
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => WelcomeLoadingPage(
                          username: username,
                          durationSeconds: 4,
                          nextPage: HomePage(
                            username: username,
                            password: password,
                            sessionKey: sessionKey,
                            listBug: listBug,
                            role: role,
                            expiredDate: expiredDate,
                          ),
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 10),
                _buildSheetItem(
                  C: C,
                  icon: Icons.phone_android_rounded,
                  iconColor: C.primaryHi,
                  title: 'Manage Sender',
                  subtitle: 'Pair devices & manage sessions',
                  isComic: isComic,
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => BugSenderPage(
                          sessionKey: sessionKey,
                          username: username,
                          role: role,
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 10),
                _buildSheetItem(
                  C: C,
                  icon: Icons.groups_rounded,
                  iconColor: C.accent,
                  title: 'Bug Group',
                  subtitle: 'Send bugs to groups',
                  isComic: isComic,
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => BugGroupPage(
                          sessionKey: sessionKey,
                          role: role,
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        );
      },
    );
  }

  String _getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return '☀️ GOOD MORNING';
    if (hour < 18) return '🌤 GOOD AFTERNOON';
    return '🌙 GOOD EVENING';
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              extendBodyBehindAppBar: true,
              extendBody: true,
              appBar: _buildAppBar(C, isComic),
              drawer: _buildDrawer(C, isComic),
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : BoxDecoration(
                        gradient: RadialGradient(
                          center: const Alignment(-0.3, -0.3),
                          radius: 1.2,
                          colors: [C.bg, C.bgDark, C.bgDeep],
                          stops: const [0.0, 0.6, 1.0],
                        ),
                      ),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: RepaintBoundary(
                            child: CustomPaint(
                              painter: _ComicHalftonePainter(
                                  color: C.primaryLo.withOpacity(0.12)),
                            ),
                          ),
                        ),
                      )
                    else
                      Positioned.fill(
                        child: IgnorePointer(
                          child: RepaintBoundary(
                            child: CustomPaint(
                                painter: _LeatherWallPainter(C: C)),
                          ),
                        ),
                      ),
                    SafeArea(
                      bottom: false,
                      child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 300),
                        transitionBuilder: (child, anim) =>
                            FadeTransition(opacity: anim, child: child),
                        child: KeyedSubtree(
                          key: ValueKey(_navIndex),
                          child: _buildCurrentPage(C),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              bottomNavigationBar: _buildBottomNav(C, isComic),
            );
          },
        );
      },
    );
  }

  PreferredSizeWidget _buildAppBar(AppPalette C, bool isComic) {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      iconTheme: IconThemeData(color: C.accent),
      titleSpacing: 0,
      flexibleSpace: Container(
        decoration: BoxDecoration(
          gradient: isComic
              ? null
              : LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [C.bg, C.bgDark, C.bgDeep],
                ),
          color: isComic ? C.bgDark : null,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.7),
              offset: const Offset(0, 4),
              blurRadius: isComic ? 0 : 8,
            ),
          ],
          border: Border(
            bottom: BorderSide(
              color: isComic ? Colors.black : C.primaryLo,
              width: isComic ? 4 : 1.5,
            ),
          ),
        ),
      ),
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (!isComic) _Led(color: C.primaryHi, size: 6, blink: true),
          if (!isComic) const SizedBox(width: 10),
          Text(
            'SYAX',
            style: TextStyle(
              color: isComic ? C.comicText : C.accentHi,
              fontSize: isComic ? 20 : 16,
              fontWeight: FontWeight.w900,
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              letterSpacing: isComic ? 2 : 3,
              shadows: isComic
                  ? [
                      Shadow(
                        color: C.comicTextOutline,
                        offset: const Offset(2, 2),
                        blurRadius: 0,
                      ),
                    ]
                  : [
                      Shadow(
                          color: C.primaryLo,
                          offset: const Offset(0, 1),
                          blurRadius: 1),
                      const Shadow(
                          color: Colors.black,
                          offset: Offset(0, 2),
                          blurRadius: 3),
                    ],
            ),
          ),
          if (!isComic) const SizedBox(width: 10),
          if (!isComic) _Led(color: C.accent, size: 6, blink: true),
        ],
      ),
      actions: [
        GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              _slideRoute(NotificationPage(
                sessionKey: sessionKey,
                username: username,
                role: role,
              )),
            );
          },
          child: Container(
            margin:
                const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              shape: isComic ? BoxShape.rectangle : BoxShape.circle,
              borderRadius: isComic ? BorderRadius.circular(8) : null,
              gradient: isComic
                  ? null
                  : LinearGradient(
                      colors: [C.textSub, C.bgDark],
                    ),
              color: isComic ? C.primaryHi : null,
              border: Border.all(
                color: isComic ? Colors.black : C.primaryLo,
                width: isComic ? 2.5 : 1,
              ),
              boxShadow: isComic
                  ? const [
                      BoxShadow(
                        color: Colors.black,
                        offset: Offset(2, 2),
                        blurRadius: 0,
                      ),
                    ]
                  : null,
            ),
            child: Icon(Icons.notifications_rounded,
                color: isComic
                    ? C.contrastTextOn(C.primaryHi)
                    : C.accent,
                size: 20),
          ),
        ),
        GestureDetector(
          onTap: () => Navigator.push(
            context,
            _slideRoute(ProfilePage(
              username: username,
              password: password,
              role: role,
              expiredDate: expiredDate,
              sessionKey: sessionKey,
            )),
          ),
          child: Container(
            margin:
                const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              gradient: isComic
                  ? null
                  : LinearGradient(
                      colors: [C.textSub, C.bgDark],
                    ),
              color: isComic ? C.accent : null,
              border: Border.all(
                color: isComic ? Colors.black : C.primaryLo,
                width: isComic ? 2.5 : 1,
              ),
              boxShadow: isComic
                  ? const [
                      BoxShadow(
                        color: Colors.black,
                        offset: Offset(2, 2),
                        blurRadius: 0,
                      ),
                    ]
                  : null,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (!isComic) ...[
                  _Led(color: C.primaryHi, size: 5, blink: true),
                  const SizedBox(width: 6),
                ],
                Text(
                  username.length > 8
                      ? '${username.substring(0, 8)}…'
                      : username,
                  style: TextStyle(
                    color: isComic
                        ? C.contrastTextOn(C.accent)
                        : C.text,
                    fontSize: isComic ? 13 : 11,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: isComic ? 1 : 0.5,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDrawer(AppPalette C, bool isComic) {
    return Drawer(
      width: MediaQuery.of(context).size.width * 0.85,
      backgroundColor: Colors.transparent,
      child: Container(
        decoration: BoxDecoration(
          gradient: isComic
              ? null
              : LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [C.bg, C.bgDark, C.bgDeep],
                ),
          color: isComic ? C.bg : null,
          border: Border(
            right: BorderSide(
              color: isComic ? Colors.black : C.primaryLo,
              width: isComic ? 4 : 2,
            ),
          ),
        ),
        child: Stack(
          children: [
            if (!isComic)
              Positioned.fill(
                child: RepaintBoundary(
                  child:
                      CustomPaint(painter: _LeatherWallPainter(C: C)),
                ),
              ),
            if (isComic)
              Positioned.fill(
                child: RepaintBoundary(
                  child: CustomPaint(
                    painter: _ComicHalftonePainter(
                        color: C.primaryLo.withOpacity(0.12)),
                  ),
                ),
              ),
            SafeArea(
              child: Column(
                children: [
                  Container(
                    height: 220,
                    margin: const EdgeInsets.all(16),
                    child: Container(
                      decoration: isComic
                          ? BoxDecoration(
                              color: C.bgDark,
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                  color: Colors.black, width: 4),
                              boxShadow: const [
                                BoxShadow(
                                  color: Colors.black,
                                  offset: Offset(6, 6),
                                  blurRadius: 0,
                                ),
                              ],
                            )
                          : null,
                      child: _MetalPlate(
                        C: C,
                        brass: !isComic,
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: 90,
                              height: 90,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: isComic
                                    ? null
                                    : RadialGradient(
                                        colors: [
                                          C.text,
                                          C.bg,
                                          C.bgDark
                                        ],
                                      ),
                                color: isComic ? C.primaryHi : null,
                                border: Border.all(
                                  color: isComic
                                      ? Colors.black
                                      : C.accent,
                                  width: isComic ? 4 : 3,
                                ),
                                boxShadow: isComic
                                    ? null
                                    : [
                                        BoxShadow(
                                          color: Colors.black
                                              .withOpacity(0.9),
                                          offset:
                                              const Offset(0, 6),
                                          blurRadius: 12,
                                        ),
                                        BoxShadow(
                                          color: C.accent
                                              .withOpacity(0.4),
                                          blurRadius: 15,
                                          spreadRadius: 3,
                                        ),
                                      ],
                              ),
                              child: Center(
                                child: ClipOval(
                                  child: Image.asset(
                                    'assets/images/logo.jpg',
                                    width: 78,
                                    height: 78,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => Icon(
                                      Icons.security_rounded,
                                      color: isComic
                                          ? C.contrastTextOn(
                                              C.primaryHi)
                                          : C.accent,
                                      size: 40,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 14),
                            Text(
                              'SYAX',
                              style: TextStyle(
                                fontSize: isComic ? 24 : 20,
                                fontWeight: FontWeight.w900,
                                fontFamily: isComic
                                    ? 'Bangers'
                                    : 'Orbitron',
                                letterSpacing: 2,
                                color: isComic
                                    ? C.comicText
                                    : C.accentHi,
                                shadows: isComic
                                    ? [
                                        Shadow(
                                          color: C.comicTextOutline,
                                          offset:
                                              const Offset(2, 2),
                                          blurRadius: 0,
                                        ),
                                      ]
                                    : const [
                                        Shadow(
                                            color: Colors.black,
                                            offset: Offset(0, 1),
                                            blurRadius: 2),
                                      ],
                              ),
                            ),
                            const SizedBox(height: 10),
                            Container(
                              height: isComic ? 3 : 1,
                              color: isComic ? Colors.black : null,
                              decoration: isComic
                                  ? null
                                  : BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: [
                                          Colors.transparent,
                                          C.accent.withOpacity(0.7),
                                          Colors.transparent,
                                        ],
                                      ),
                                    ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              username,
                              style: TextStyle(
                                color: isComic
                                    ? C.comicText
                                    : C.text,
                                fontSize: 14,
                                fontWeight: FontWeight.w900,
                                fontFamily: isComic
                                    ? 'Bangers'
                                    : 'Orbitron',
                                letterSpacing: 1,
                                shadows: isComic
                                    ? [
                                        Shadow(
                                          color: C.comicTextOutline,
                                          offset:
                                              const Offset(1, 1),
                                          blurRadius: 0,
                                        ),
                                      ]
                                    : null,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Row(
                              mainAxisAlignment:
                                  MainAxisAlignment.center,
                              children: [
                                _Led(
                                    color: C.primaryHi,
                                    size: 6,
                                    blink: !isComic),
                                const SizedBox(width: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 3),
                                  decoration: BoxDecoration(
                                    borderRadius:
                                        BorderRadius.circular(4),
                                    gradient: isComic
                                        ? null
                                        : LinearGradient(
                                            colors: [
                                              C.primary,
                                              C.primaryLo
                                            ],
                                          ),
                                    color:
                                        isComic ? C.accent : null,
                                    border: Border.all(
                                      color: isComic
                                          ? Colors.black
                                          : C.accentHi,
                                      width: isComic ? 2 : 1,
                                    ),
                                  ),
                                  child: Text(
                                    role.toUpperCase(),
                                    style: TextStyle(
                                      color: isComic
                                          ? C.contrastTextOn(C.accent)
                                          : C.accentShine,
                                      fontSize: isComic ? 11 : 10,
                                      fontWeight: FontWeight.w900,
                                      fontFamily: isComic
                                          ? 'Bangers'
                                          : 'Orbitron',
                                      letterSpacing: 1.5,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 5),
                            Text(
                              'EXP: $expiredDate',
                              style: TextStyle(
                                color: isComic
                                    ? C.comicTextSub
                                    : C.text.withOpacity(0.6),
                                fontSize: 10,
                                fontFamily: isComic
                                    ? 'ComicNeue'
                                    : 'ShareTechMono',
                                letterSpacing: 1,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: ListView(
                      padding: const EdgeInsets.symmetric(
                          vertical: 8, horizontal: 16),
                      children: [
                        if (role.toLowerCase().trim() == 'admin')
                          _buildDrawerItem(
                            C: C,
                            icon: Icons.admin_panel_settings,
                            title: 'Admin Dashboard',
                            color: C.primaryHi,
                            isComic: isComic,
                            onTap: () {
                              Navigator.pop(context);
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => OwnerPage(
                                      sessionKey: sessionKey,
                                      username: username),
                                ),
                              );
                            },
                          ),
                        if (role.toLowerCase().trim() == 'owner')
                          _buildDrawerItem(
                            C: C,
                            icon: Icons.workspace_premium_rounded,
                            title: 'Owner Dashboard',
                            color: C.accentHi,
                            isComic: isComic,
                            onTap: () {
                              Navigator.pop(context);
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => OwnerPage(
                                      sessionKey: sessionKey,
                                      username: username),
                                ),
                              );
                            },
                          ),
                        if (role.toLowerCase().trim() == 'high owner')
                          _buildDrawerItem(
                            C: C,
                            icon: Icons.diamond_rounded,
                            title: 'High Owner Dashboard',
                            color: C.accentShine,
                            isComic: isComic,
                            onTap: () {
                              Navigator.pop(context);
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => HighOwnerPage(
                                      sessionKey: sessionKey,
                                      username: username),
                                ),
                              );
                            },
                          ),
                        if (role.toLowerCase().trim() == 'developer')
                          _buildDrawerItem(
                            C: C,
                            icon: Icons.code_rounded,
                            title: 'Developer Dashboard',
                            color: C.primaryHi,
                            isComic: isComic,
                            onTap: () {
                              Navigator.pop(context);
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => DeveloperPage(
                                      sessionKey: sessionKey,
                                      username: username),
                                ),
                              );
                            },
                          ),
                        if (role.toLowerCase().trim() == 'moderator')
                          _buildDrawerItem(
                            C: C,
                            icon: Icons.shield_rounded,
                            title: 'Moderator Dashboard',
                            color: C.accent,
                            isComic: isComic,
                            onTap: () {
                              Navigator.pop(context);
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => ModeratorPage(
                                      sessionKey: sessionKey,
                                      username: username),
                                ),
                              );
                            },
                          ),
                        if (role.toLowerCase().trim() == 'partner')
                          _buildDrawerItem(
                            C: C,
                            icon: Icons.handshake_rounded,
                            title: 'Partner Dashboard',
                            color: C.accentHi,
                            isComic: isComic,
                            onTap: () {
                              Navigator.pop(context);
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => PartnerPage(
                                      sessionKey: sessionKey,
                                      username: username),
                                ),
                              );
                            },
                          ),
                        if (role.toLowerCase().trim() == 'vip')
                          _buildDrawerItem(
                            C: C,
                            icon: Icons.star_rounded,
                            title: 'Vip Dashboard',
                            color: C.accentShine,
                            isComic: isComic,
                            onTap: () {
                              Navigator.pop(context);
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => VipPage(
                                      sessionKey: sessionKey,
                                      username: username),
                                ),
                              );
                            },
                          ),
                        if (role.toLowerCase() == 'reseller')
                          _buildDrawerItem(
                            C: C,
                            icon: Icons.storefront,
                            title: 'Reseller Dashboard',
                            color: C.accent,
                            isComic: isComic,
                            onTap: () {
                              Navigator.pop(context);
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) =>
                                      SellerPage(keyToken: sessionKey),
                                ),
                              );
                            },
                          ),
                        _buildDrawerItem(
                          C: C,
                          icon: Icons.workspace_premium_rounded,
                          title: 'Upgrade Role',
                          color: C.accent,
                          isComic: isComic,
                          onTap: () {
                            Navigator.pop(context);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => UpgradeRolePage(
                                  username: username,
                                  sessionKey: sessionKey,
                                  currentRole: role,
                                ),
                              ),
                            );
                          },
                        ),
                        _buildDrawerItem(
                          C: C,
                          icon: Icons.account_balance_wallet_rounded,
                          title: 'Store Uang',
                          color: C.primaryHi,
                          isComic: isComic,
                          onTap: () {
                            Navigator.pop(context);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => StoreUangPage(
                                  username: username,
                                  sessionKey: sessionKey,
                                ),
                              ),
                            );
                          },
                        ),
                        _buildDrawerItem(
                          C: C,
                          icon: Icons.storefront_rounded,
                          title: 'Pasar Online',
                          color: C.accentHi,
                          isComic: isComic,
                          onTap: () {
                            Navigator.pop(context);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => MarketPage(
                                  username: username,
                                  sessionKey: sessionKey,
                                  role: role,
                                ),
                              ),
                            );
                          },
                        ),
                        _buildDrawerItem(
                          C: C,
                          icon: Icons.music_note_rounded,
                          title: 'Music Player',
                          color: C.accentHi,
                          isComic: isComic,
                          onTap: () {
                            Navigator.pop(context);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => const MusicPage()),
                            );
                          },
                        ),
                        _buildDrawerItem(
                          C: C,
                          icon: Icons.album_rounded,
                          title: 'Vinyl Player',
                          color: C.accentShine,
                          isComic: isComic,
                          onTap: () {
                            Navigator.pop(context);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) =>
                                      const VinylMusicPage()),
                            );
                          },
                        ),
                        _buildDrawerItem(
                          C: C,
                          icon: Icons.call_rounded,
                          title: 'Call Crylix',
                          color: C.primaryHi,
                          isComic: isComic,
                          onTap: () {
                            Navigator.pop(context);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => CallCrylixPage(
                                  username: username,
                                  sessionKey: sessionKey,
                                  baseUrl: 'http://panelku.fincloud.my.id:2772',
                                ),
                              ),
                            );
                          },
                        ),
                        _buildDrawerItem(
                          C: C,
                          icon: Icons.music_note_rounded,
                          title: 'TikTok',
                          color: const Color(0xFFEC407A),
                          isComic: isComic,
                          onTap: () {
                            Navigator.pop(context);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => const TiktokPage()),
                            );
                          },
                        ),
                        _buildDrawerItem(
                          C: C,
                          icon: Icons.cloud_upload_rounded,
                          title: 'Catbox',
                          color: C.accentHi,
                          isComic: isComic,
                          onTap: () {
                            Navigator.pop(context);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => const CatboxPage()),
                            );
                          },
                        ),
                        _buildDrawerItem(
                          C: C,
                          icon: Icons.palette_rounded,
                          title: 'Ganti Theme',
                          color: C.accent,
                          isComic: isComic,
                          onTap: () {
                            Navigator.pop(context);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => const ThemePage()),
                            );
                          },
                        ),
                        _buildDrawerItem(
                          C: C,
                          icon: Icons.lock_reset,
                          title: 'Change Password',
                          color: C.accent,
                          isComic: isComic,
                          onTap: () {
                            Navigator.pop(context);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ChangePasswordPage(
                                    username: username,
                                    sessionKey: sessionKey),
                              ),
                            );
                          },
                        ),
                        _buildDrawerItem(
                          C: C,
                          icon: Icons.system_update_alt,
                          title: 'Update App',
                          color: C.primaryHi,
                          isComic: isComic,
                          onTap: () {
                            Navigator.pop(context);
                            _showSkeuoSnack(
                                'Fitur Update App sedang dalam pengembangan');
                          },
                        ),
                        _buildDrawerItem(
                          C: C,
                          icon: Icons.favorite_rounded,
                          title: 'TQTO',
                          color: C.primaryHi,
                          isComic: isComic,
                          onTap: () {
                            Navigator.pop(context);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => const TqtoPage()),
                            );
                          },
                        ),
                        _buildDrawerItem(
                          C: C,
                          icon: Icons.chat_rounded,
                          title: 'Chat',
                          color: C.accentShine,
                          isComic: isComic,
                          onTap: () {
                            Navigator.pop(context);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ChatPage(
                                  username: username,
                                  sessionKey: sessionKey,
                                ),
                              ),
                            );
                          },
                        ),
                        _buildDrawerItem(
                          C: C,
                          icon: Icons.logout_rounded,
                          title: 'Logout',
                          color: C.primaryHi,
                          isComic: isComic,
                          onTap: () {
                            Navigator.pop(context);
                            Navigator.pushAndRemoveUntil(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => const LoginPage()),
                              (_) => false,
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.all(16),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: isComic
                          ? C.primaryHi
                          : Colors.black.withOpacity(0.5),
                      border: Border.all(
                        color: isComic ? Colors.black : C.bgDark,
                        width: isComic ? 3 : 1,
                      ),
                    ),
                    child: Center(
                      child: Text(
                        ' Developer • KAIZEN',
                        style: TextStyle(
                          color: isComic
                              ? C.contrastTextOn(C.primaryHi)
                              : C.accent.withOpacity(0.6),
                          fontSize: 10,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 3,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawerItem({
    required AppPalette C,
    required Object icon,
    required String title,
    required Color color,
    required VoidCallback onTap,
    required bool isComic,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: _IndustrialButton(
        C: C,
        color: C.bg,
        height: 56,
        onTap: onTap,
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: isComic
                    ? null
                    : LinearGradient(
                        colors: [
                          color.withOpacity(0.25),
                          color.withOpacity(0.05)
                        ],
                      ),
                color: isComic ? color : null,
                border: Border.all(
                  color:
                      isComic ? Colors.black : color.withOpacity(0.5),
                  width: isComic ? 2.5 : 1,
                ),
                boxShadow: isComic
                    ? null
                    : [
                        BoxShadow(
                          color: color.withOpacity(0.35),
                          blurRadius: 8,
                        ),
                      ],
              ),
              child: (icon is IconData ? Icon(icon,
                  color: isComic
                      ? (color.computeLuminance() > 0.5
                          ? Colors.black
                          : Colors.white)
                      : color,
                  size: 18) : FaIcon(icon as FaIconData, color: color, size: 18)),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                title,
                style: TextStyle(
                  color: isComic ? C.comicText : C.text,
                  fontSize: isComic ? 15 : 13,
                  fontWeight: FontWeight.w700,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: isComic ? 1 : 0.8,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
            ),
            Icon(Icons.arrow_forward_ios_rounded,
                color: C.accent, size: 12),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomNav(AppPalette C, bool isComic) {
    return RepaintBoundary(
      child: Container(
        decoration: BoxDecoration(
          gradient: isComic
              ? null
              : LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [C.bg, C.bgDark, C.bgDeep],
                ),
          color: isComic ? C.bgDark : null,
          border: Border(
            top: BorderSide(
              color: isComic ? Colors.black : C.primaryLo,
              width: isComic ? 4 : 2,
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.8),
              offset: const Offset(0, -4),
              blurRadius: isComic ? 0 : 12,
            ),
          ],
        ),
        child: SafeArea(
          top: false,
          child: SizedBox(
            height: 68,
            child: Row(
              children: [
                // 0. HOME
                _buildNavBtn(C,
                  icon: Icons.home_rounded,
                  label: 'Home',
                  index: 0,
                  isComic: isComic,
                ),
                // 1. INFO
                _buildNavBtn(C,
                  icon: Icons.warning_amber_rounded,
                  label: 'INFO',
                  index: 1,
                  isComic: isComic,
                ),
                // 2. WHATSAPP
                _buildNavBtn(C,
                  icon: FontAwesomeIcons.whatsapp,
                  label: 'Whatsapp',
                  index: 2,
                  accent: true,
                  isComic: isComic,
                ),
                // 3. NOTIF
                _buildNavBtn(C,
                  icon: Icons.notifications_active,
                  label: 'Notif',
                  index: 3,
                  isComic: isComic,
                ),
                // 4. TOOLS
                _buildNavBtn(C,
                  icon: Icons.build_rounded,
                  label: 'Tools',
                  index: 4,
                  isComic: isComic,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNavBtn(AppPalette C, {
    required Object icon,
    required String label,
    required int index,
    bool accent = false,
    required bool isComic,
  }) {
    final active = index == 4 ? false : (_navIndex == index);
    final color = accent
        ? C.primaryHi
        : (active
            ? (isComic ? C.primaryHi : C.accent)
            : (isComic ? C.comicTextSub : C.textSub));
    final activeTextColor =
        isComic && active ? C.contrastTextOn(C.primaryHi) : color;

    return Expanded(
      child: GestureDetector(
        onTap: () => _onNavTap(index),
        child: Container(
          margin:
              const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(isComic ? 10 : 8),
            gradient: !isComic && active
                ? LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [C.bgDark, C.bgDeep],
                  )
                : null,
            color: isComic && active ? C.primaryHi : null,
            border: Border.all(
              color: isComic
                  ? (active ? Colors.black : Colors.transparent)
                  : (active
                      ? color.withOpacity(0.6)
                      : Colors.transparent),
              width: isComic ? 3 : 1.5,
            ),
            boxShadow: isComic && active
                ? const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(3, 3),
                      blurRadius: 0,
                    ),
                  ]
                : (!isComic && active
                    ? [
                        BoxShadow(
                          color: color.withOpacity(0.4),
                          blurRadius: 12,
                        ),
                      ]
                    : null),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (active && !isComic) ...[
                _Led(color: color, size: 4, blink: accent),
                const SizedBox(height: 3),
              ],
              icon is IconData
                  ? Icon(icon, color: activeTextColor, size: 20)
                  : FaIcon(icon as FaIconData, color: activeTextColor, size: 20),
              const SizedBox(height: 2),
              Text(
                label,
                style: TextStyle(
                  color: activeTextColor,
                  fontSize: isComic ? 9 : 8,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: isComic ? 1 : 1.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SWIPEABLE INFO CARDS — Clock+Calendar ⇄ Device Info
// ═══════════════════════════════════════════════════════════
class _SwipeableInfoCards extends StatefulWidget {
  final AppPalette C;
  final bool isComic;
  final Widget page1;
  final Widget page2;
  final bool compact;

  const _SwipeableInfoCards({
    required this.C,
    required this.isComic,
    required this.page1,
    required this.page2,
    this.compact = false,
  });

  @override
  State<_SwipeableInfoCards> createState() => _SwipeableInfoCardsState();
}

class _SwipeableInfoCardsState extends State<_SwipeableInfoCards> {
  int _page = 0;
  double _dragDelta = 0;

  void _goToPage(int index) {
    if (index == _page) return;
    HapticFeedback.selectionClick();
    setState(() => _page = index);
  }

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final isComic = widget.isComic;
    final isCompact = widget.compact;

    final activeWidth = isCompact ? 14.0 : 26.0;
    final inactiveWidth = isCompact ? 5.0 : 9.0;
    final dotHeight = isCompact ? 5.0 : 9.0;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onHorizontalDragStart: (_) => _dragDelta = 0,
      onHorizontalDragUpdate: (details) {
        _dragDelta += details.delta.dx;
      },
      onHorizontalDragEnd: (_) {
        final threshold = isCompact ? 40 : 50;
        if (_dragDelta < -threshold && _page == 0) {
          _goToPage(1);
        } else if (_dragDelta > threshold && _page == 1) {
          _goToPage(0);
        }
        _dragDelta = 0;
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Stack(
            alignment: Alignment.topCenter,
            children: [
              Opacity(
                opacity: 0,
                child: IgnorePointer(
                  child: _page == 0 ? widget.page2 : widget.page1,
                ),
              ),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 320),
                switchInCurve: Curves.easeOutCubic,
                switchOutCurve: Curves.easeInCubic,
                layoutBuilder: (currentChild, previousChildren) {
                  return Stack(
                    alignment: Alignment.topCenter,
                    children: [
                      ...previousChildren,
                      if (currentChild != null) currentChild,
                    ],
                  );
                },
                transitionBuilder: (child, anim) {
                  return FadeTransition(
                    opacity: anim,
                    child: SlideTransition(
                      position: Tween<Offset>(
                        begin: const Offset(0.08, 0),
                        end: Offset.zero,
                      ).animate(anim),
                      child: child,
                    ),
                  );
                },
                child: KeyedSubtree(
                  key: ValueKey(_page),
                  child: _page == 0 ? widget.page1 : widget.page2,
                ),
              ),
            ],
          ),
          SizedBox(height: isCompact ? 4 : 12),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(2, (i) {
              final active = i == _page;
              final glowColor = isComic ? C.primaryHi : C.accent;

              return GestureDetector(
                onTap: () => _goToPage(i),
                behavior: HitTestBehavior.opaque,
                child: Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: isCompact ? 3 : 5,
                    vertical: isCompact ? 2 : 4,
                  ),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 280),
                    curve: Curves.easeOutCubic,
                    width: active ? activeWidth : inactiveWidth,
                    height: dotHeight,
                    decoration: BoxDecoration(
                      color: active
                          ? Colors.black
                          : C.textSub.withOpacity(0.35),
                      borderRadius: BorderRadius.circular(5),
                      border: isComic
                          ? Border.all(
                              color:
                                  active ? Colors.white : Colors.black,
                              width: active ? 1.5 : 1,
                            )
                          : (active
                              ? Border.all(
                                  color:
                                      C.textSub.withOpacity(0.4),
                                  width: 0.6,
                                )
                              : null),
                      boxShadow: active
                          ? [
                              BoxShadow(
                                color:
                                    glowColor.withOpacity(0.85),
                                blurRadius: isCompact ? 6 : 10,
                                spreadRadius: 0.5,
                              ),
                              BoxShadow(
                                color:
                                    glowColor.withOpacity(0.35),
                                blurRadius: isCompact ? 10 : 16,
                                spreadRadius: 2,
                              ),
                            ]
                          : null,
                    ),
                  ),
                ),
              );
            }),
          ),
          SizedBox(height: isCompact ? 2 : 6),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// ROUTE HELPER
// ═══════════════════════════════════════════════════════════
PageRoute _slideRoute(Widget page) => PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionDuration: const Duration(milliseconds: 350),
      transitionsBuilder: (_, anim, __, child) => SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(1, 0),
          end: Offset.zero,
        ).animate(
            CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
        child: FadeTransition(opacity: anim, child: child),
      ),
    );

class _LeatherWallPainter extends CustomPainter {
  final AppPalette C;
  const _LeatherWallPainter({required this.C});

  @override
  void paint(Canvas canvas, Size size) {
    final rand = Random(42);

    final dotPaint = Paint()..color = Colors.black.withOpacity(0.05);
    for (int i = 0; i < 300; i++) {
      canvas.drawCircle(
        Offset(rand.nextDouble() * size.width,
            rand.nextDouble() * size.height),
        rand.nextDouble() * 1.4,
        dotPaint,
      );
    }

    final linePaint = Paint()
      ..color = Colors.black.withOpacity(0.04)
      ..strokeWidth = 0.5;
    for (int i = 0; i < 100; i++) {
      final x = rand.nextDouble() * size.width;
      final y = rand.nextDouble() * size.height;
      final len = rand.nextDouble() * 15 + 3;
      final angle = rand.nextDouble() * pi;
      canvas.drawLine(
        Offset(x, y),
        Offset(x + cos(angle) * len, y + sin(angle) * len),
        linePaint,
      );
    }
  }

  @override
  bool shouldRepaint(_LeatherWallPainter old) => old.C != C;
}

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _ctrl;
  bool _isVideo(String url) =>
      url.endsWith('.mp4') ||
      url.endsWith('.webm') ||
      url.endsWith('.mov') ||
      url.endsWith('.mkv');

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) setState(() {});
          _ctrl?.setLooping(true);
          _ctrl?.setVolume(0.0);
          _ctrl?.play();
        });
    }
  }

  @override
  void dispose() {
    _ctrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        final isComic =
            AppTheme.currentStyle.value == ThemeStyle.comic3d;
        if (_isVideo(widget.url)) {
          if (_ctrl != null && _ctrl!.value.isInitialized) {
            return AspectRatio(
              aspectRatio: _ctrl!.value.aspectRatio,
              child: VideoPlayer(_ctrl!),
            );
          }
          return Center(
            child: CircularProgressIndicator(
                color: C.accent, strokeWidth: 2),
          );
        }
        return Image.network(
          widget.url,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => Container(
            color: C.bgDeep,
            child: Icon(Icons.error_rounded,
                color: isComic ? C.comicTextSub : C.textSub),
          ),
        );
      },
    );
  }
}