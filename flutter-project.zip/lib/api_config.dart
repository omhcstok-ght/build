import 'dart:convert';

final String baseUrl = _getBaseUrl();

String _getBaseUrl() {
  const n1 = 'aHR0cHM6Ly9s';
  const n2 = 'ZW9uaXgueWFrdXphLmJp';
  const n3 = 'ei5pZA==';
  
  final d1 = utf8.decode(base64Decode(n1));
  final d2 = utf8.decode(base64Decode(n2));
  final d3 = utf8.decode(base64Decode(n3));
  
  return '$d1$d2$d3';
}

final String databaseUrl = _getDbUrl();

String _getDbUrl() {
  const d1 = 'aHR0cHM6Ly92MTYubmV4';
  const d2 = 'dC5mb3JnZWpvLm9yZy9M';
  const d3 = 'ZW9uaXhfMTEvbmVuZW4v';
  const d4 = 'cmF3L2JyYW5jaC9tYWluL2RhdGFiYXNlLmpzb24=';
  
  final f1 = utf8.decode(base64Decode(d1));
  final f2 = utf8.decode(base64Decode(d2));
  final f3 = utf8.decode(base64Decode(d3));
  final f4 = utf8.decode(base64Decode(d4));
  
  return '$f1$f2$f3$f4';
}