// chat_ai_page.dart

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'dart:ui';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class ChatAIPage extends StatefulWidget {
  final String sessionKey;

  const ChatAIPage({super.key, required this.sessionKey});

  @override
  State<ChatAIPage> createState() => _ChatAIPageState();
}

class _ChatAIPageState extends State<ChatAIPage> with TickerProviderStateMixin {
  final TextEditingController _messageController = TextEditingController();
  final List<ChatMessage> _messages = [];
  bool _isLoading = false;
  String? _currentSessionId;
  List<ChatSession> _chatSessions = [];
  bool _showSessionList = false;

  // Premium Color Theme
  final Color _primaryColor = const Color(0xFF00E5FF); // Cyan Neon
  final Color _secondaryColor = const Color(0xFF7C4DFF); // Purple
  final Color _accentColor = const Color(0xFFFF3366); // Pink/Red
  final Color _cardColor = const Color(0xFF1A1A2E);

  // Animation Controllers
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  // Video Controller
  VideoPlayerController? _videoController;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initVideoBackground();
    _loadChatSessions();
  }

  void _initializeAnimations() {
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );
    _glowController.repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
  }

  Future<void> _initVideoBackground() async {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/banner.mp4')
        ..initialize().then((_) {
          _videoController?.setLooping(true);
          _videoController?.setVolume(0.0);
          _videoController?.play();
          if (mounted) setState(() {});
        }).catchError((e) {
          debugPrint("Gagal memuat video background: $e");
        });
    } catch (e) {
      debugPrint("Exception saat memuat video: $e");
    }
  }

  Widget _buildAnimatedBackground() {
    return Stack(
      children: [
        if (_videoController != null && _videoController!.value.isInitialized)
          SizedBox.expand(
            child: FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _videoController!.value.size.width,
                height: _videoController!.value.size.height,
                child: VideoPlayer(_videoController!),
              ),
            ),
          )
        else
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [const Color(0xFF0A0E27), const Color(0xFF1A1A3E), const Color(0xFF000000)],
              ),
            ),
          ),
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black.withOpacity(0.3),
                Colors.black.withOpacity(0.85),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildGlassCard({required Widget child}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.white.withOpacity(0.08),
                Colors.white.withOpacity(0.03),
              ],
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.white.withOpacity(0.1), width: 1),
          ),
          child: child,
        ),
      ),
    );
  }

  Future<void> _loadChatSessions() async {
    try {
      final response = await http.get(Uri.parse('http://jayspanell.ommdhangantenk.my.id:2140/api/tools/chat/list?key=${widget.sessionKey}'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _chatSessions = (data['chatHistoryList'] as List).map((session) => ChatSession.fromJson(session)).toList();
          });
        }
      }
    } catch (e) {
      _showSnackBar('Failed to load chat sessions', isError: true);
    }
  }

  Future<void> _createNewSession() async {
    try {
      final response = await http.get(Uri.parse('http://jayspanell.ommdhangantenk.my.id:2140/api/tools/chat/new-session?key=${widget.sessionKey}'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _currentSessionId = data['sessionId'];
            _messages.clear();
            _showSessionList = false;
          });
          _loadChatSessions();
          _showSnackBar('New session created');
        }
      }
    } catch (e) {
      _showSnackBar('Failed to create new session', isError: true);
    }
  }

  Future<void> _loadChatSession(String sessionId) async {
    try {
      final response = await http.get(Uri.parse('http://jayspanell.ommdhangantenk.my.id:2140/api/tools/chat/history?key=${widget.sessionKey}&session=$sessionId'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _currentSessionId = sessionId;
            _messages.clear();
            final chatHistory = data['chatHistory'] as List;
            for (var message in chatHistory) {
              _messages.add(ChatMessage(
                text: message['message'],
                isAI: message['isAI'] == true,
                timestamp: DateTime.parse(message['timestamp'])
              ));
            }
            _showSessionList = false;
          });
        }
      }
    } catch (e) {
      _showSnackBar('Failed to load chat session', isError: true);
    }
  }

  Future<void> _deleteChatSession(String sessionId) async {
    try {
      final response = await http.get(Uri.parse('http://jayspanell.ommdhangantenk.my.id:2140/api/tools/chat/delete?key=${widget.sessionKey}&session=$sessionId'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          _showSnackBar('Chat session deleted');
          _loadChatSessions();
          if (_currentSessionId == sessionId) {
            setState(() {
              _currentSessionId = null;
              _messages.clear();
            });
          }
        }
      }
    } catch (e) {
      _showSnackBar('Failed to delete chat session', isError: true);
    }
  }

  Future<void> _sendMessage() async {
    if (_messageController.text.isEmpty || _currentSessionId == null) return;
    final userMessage = _messageController.text;
    setState(() {
      _messages.add(ChatMessage(text: userMessage, isAI: false, timestamp: DateTime.now()));
      _isLoading = true;
    });
    _messageController.clear();
    try {
      final response = await http.get(Uri.parse('http://jayspanell.ommdhangantenk.my.id:2140/api/tools/chat/send?key=${widget.sessionKey}&session=$_currentSessionId&message=${Uri.encodeComponent(userMessage)}'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            _messages.add(ChatMessage(text: data['data']['message'], isAI: true, timestamp: DateTime.now()));
          });
        } else {
          _showSnackBar('Failed to get AI response', isError: true);
        }
      } else {
        _showSnackBar('Failed to connect to AI service', isError: true);
      }
    } catch (e) {
      _showSnackBar('Error: ${e.toString()}', isError: true);
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _showSnackBar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(message, style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono')),
      backgroundColor: isError ? _accentColor.withOpacity(0.9) : _primaryColor.withOpacity(0.9),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }

  Widget _buildNeonHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: AnimatedBuilder(
        animation: _glowAnimation,
        builder: (context, child) {
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: _primaryColor.withOpacity(0.4), width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: _primaryColor.withOpacity(0.2 * _glowAnimation.value),
                  blurRadius: 20,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: _buildGlassCard(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [_primaryColor, _secondaryColor]),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: const Icon(FontAwesomeIcons.robot, color: Colors.black, size: 24),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "AI ASSISTANT",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              fontFamily: "Orbitron",
                              letterSpacing: 2,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            _currentSessionId != null ? "Session Active" : "No Active Session",
                            style: TextStyle(
                              color: _primaryColor.withOpacity(0.8),
                              fontSize: 12,
                              fontFamily: "ShareTechMono",
                            ),
                          ),
                        ],
                      ),
                    ),
                    Row(
                      children: [
                        IconButton(
                          icon: Icon(_showSessionList ? Icons.chat : Icons.history, color: _primaryColor),
                          onPressed: () => setState(() => _showSessionList = !_showSessionList),
                        ),
                        IconButton(
                          icon: const Icon(Icons.add, color: Color(0xFF00E5FF)),
                          onPressed: _createNewSession,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildSessionList() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: _buildGlassCard(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Container(
                    width: 4,
                    height: 20,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [_primaryColor, _secondaryColor]),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    "CHAT SESSIONS",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Orbitron",
                      letterSpacing: 2,
                    ),
                  ),
                  const Spacer(),
                  TextButton.icon(
                    onPressed: _createNewSession,
                    icon: const Icon(Icons.add, size: 16),
                    label: const Text("NEW", style: TextStyle(fontWeight: FontWeight.bold)),
                    style: TextButton.styleFrom(
                      foregroundColor: _primaryColor,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        Expanded(
          child: _chatSessions.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(FontAwesomeIcons.comments, color: Colors.white24, size: 48),
                      const SizedBox(height: 16),
                      Text(
                        "No chat sessions found",
                        style: TextStyle(color: Colors.white.withOpacity(0.5), fontFamily: 'ShareTechMono'),
                      ),
                      const SizedBox(height: 8),
                      TextButton.icon(
                        onPressed: _createNewSession,
                        icon: const Icon(Icons.add),
                        label: const Text("Create New Session"),
                        style: TextButton.styleFrom(
                          foregroundColor: _primaryColor,
                        ),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: _chatSessions.length,
                  itemBuilder: (context, index) {
                    final session = _chatSessions[index];
                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: _buildGlassCard(
                        child: ListTile(
                          leading: Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [_primaryColor, _secondaryColor]),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: const Icon(Icons.chat_bubble, color: Colors.black, size: 18),
                          ),
                          title: Text(
                            session.sessionId.length > 30 
                                ? '${session.sessionId.substring(0, 30)}...' 
                                : session.sessionId,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'ShareTechMono',
                              fontSize: 13,
                            ),
                          ),
                          subtitle: Text(
                            '${session.messageCount} messages • ${session.preview}',
                            style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete_outline, color: Color(0xFFFF3366)),
                            onPressed: () => _deleteChatSession(session.sessionId),
                          ),
                          onTap: () => _loadChatSession(session.sessionId),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildChatInterface() {
    return Column(
      children: [
        Expanded(
          child: _currentSessionId == null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: _primaryColor.withOpacity(0.3), width: 2),
                        ),
                        child: Icon(FontAwesomeIcons.robot, size: 48, color: _primaryColor.withOpacity(0.5)),
                      ),
                      const SizedBox(height: 24),
                      Text(
                        'Start a new conversation',
                        style: TextStyle(color: _primaryColor.withOpacity(0.7), fontFamily: 'Orbitron', fontSize: 16, letterSpacing: 1),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Click the + button to create a session',
                        style: TextStyle(color: Colors.white.withOpacity(0.3), fontFamily: 'ShareTechMono', fontSize: 12),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _messages.length,
                  itemBuilder: (context, index) => _buildMessageBubble(_messages[index]),
                ),
        ),
        if (_isLoading)
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: Color(0xFF00E5FF), strokeWidth: 2)),
                const SizedBox(width: 12),
                Text('AI is thinking...', style: TextStyle(color: _primaryColor.withOpacity(0.7), fontFamily: 'ShareTechMono')),
              ],
            ),
          ),
        _buildMessageInput(),
      ],
    );
  }

  Widget _buildMessageBubble(ChatMessage message) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: Row(
        mainAxisAlignment: !message.isAI ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (message.isAI) ...[
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [_primaryColor, _secondaryColor]),
                shape: BoxShape.circle,
              ),
              child: const Icon(FontAwesomeIcons.robot, color: Colors.black, size: 16),
            ),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: !message.isAI
                    ? LinearGradient(colors: [_primaryColor, _secondaryColor])
                    : null,
                color: !message.isAI ? null : Colors.black.withOpacity(0.4),
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(20),
                  topRight: const Radius.circular(20),
                  bottomLeft: message.isAI ? const Radius.circular(20) : const Radius.circular(4),
                  bottomRight: message.isAI ? const Radius.circular(4) : const Radius.circular(20),
                ),
                border: message.isAI ? Border.all(color: _primaryColor.withOpacity(0.3), width: 1) : null,
              ),
              child: Text(
                message.text,
                style: TextStyle(
                  color: !message.isAI ? Colors.black : Colors.white,
                  fontWeight: !message.isAI ? FontWeight.w500 : FontWeight.normal,
                  fontFamily: 'ShareTechMono',
                  fontSize: 14,
                ),
              ),
            ),
          ),
          if (!message.isAI) ...[
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [_primaryColor, _secondaryColor]),
                shape: BoxShape.circle,
              ),
              child: const Icon(FontAwesomeIcons.user, color: Colors.black, size: 16),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildMessageInput() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.8),
        border: Border(top: BorderSide(color: _primaryColor.withOpacity(0.1), width: 1)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: _primaryColor.withOpacity(0.3), width: 1),
              ),
              child: TextField(
                controller: _messageController,
                style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono'),
                cursorColor: _primaryColor,
                decoration: InputDecoration(
                  hintText: 'Type your message...',
                  hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                    borderSide: BorderSide.none,
                  ),
                  filled: true,
                  fillColor: Colors.black.withOpacity(0.4),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          GestureDetector(
            onTap: _isLoading ? null : _sendMessage,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [_primaryColor, _secondaryColor]),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: _primaryColor.withOpacity(0.3),
                    blurRadius: 8,
                  ),
                ],
              ),
              child: const Icon(Icons.send, color: Colors.black, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 6,
                height: 6,
                decoration: BoxDecoration(
                  color: Colors.green,
                  shape: BoxShape.circle,
                  boxShadow: [BoxShadow(color: Colors.green, blurRadius: 5)],
                ),
              ),
              const SizedBox(width: 8),
              Text(
                "SECURE CONNECTION",
                style: TextStyle(
                  color: Colors.white.withOpacity(0.3),
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                  fontFamily: 'Orbitron',
                ),
              ),
              const SizedBox(width: 16),
              Icon(Icons.fingerprint, color: Colors.white.withOpacity(0.2), size: 14),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            "NØCURE SECURITY • ENCRYPTED",
            style: TextStyle(
              color: Colors.white.withOpacity(0.15),
              fontSize: 9,
              fontFamily: 'ShareTechMono',
              letterSpacing: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          _buildAnimatedBackground(),
          SafeArea(
            child: Column(
              children: [
                _buildNeonHeader(),
                Expanded(
                  child: _showSessionList ? _buildSessionList() : _buildChatInterface(),
                ),
                if (!_showSessionList && _currentSessionId != null) _buildFooter(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _glowController.dispose();
    _videoController?.dispose();
    _messageController.dispose();
    super.dispose();
  }
}

class ChatMessage {
  final String text;
  final bool isAI; 
  final DateTime timestamp;
  ChatMessage({required this.text, required this.isAI, required this.timestamp});
}

class ChatSession {
  final String sessionId;
  final String username;
  final DateTime lastModified;
  final int messageCount;
  final String preview;
  ChatSession({
    required this.sessionId, 
    required this.username, 
    required this.lastModified, 
    required this.messageCount, 
    required this.preview
  });
  factory ChatSession.fromJson(Map<String, dynamic> json) {
    return ChatSession(
      sessionId: json['sessionId'],
      username: json['username'],
      lastModified: DateTime.parse(json['lastModified']),
      messageCount: json['messageCount'],
      preview: json['preview'],
    );
  }
}