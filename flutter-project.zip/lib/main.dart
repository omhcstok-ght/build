import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const XSCTEAMZApp());
}

class XSCTEAMZApp extends StatelessWidget {
  const XSCTEAMZApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'XSCTEAMZ',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0D0F18),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFE94C9A),
          secondary: Color(0xFF6C63FF),
        ),
      ),
      home: const XSCTEAMZHome(),
    );
  }
}

class XSCTEAMZHome extends StatefulWidget {
  const XSCTEAMZHome({super.key});

  @override
  State<XSCTEAMZHome> createState() => _XSCTEAMZHomeState();
}

class _XSCTEAMZHomeState extends State<XSCTEAMZHome> {
  late final WebViewController _webViewController;
  bool _isLoading = true;
  bool _loadFailed = false;

  @override
  void initState() {
    super.initState();
    _webViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF0D0F18))
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (_) {
            if (mounted) {
              setState(() {
                _isLoading = false;
                _loadFailed = false;
              });
            }
          },
          onWebResourceError: (error) {
            if (error.isForMainFrame == true && mounted) {
              setState(() {
                _isLoading = false;
                _loadFailed = true;
              });
            }
          },
        ),
      )
      ..loadFlutterAsset('assets/index.html');
  }

  Future<void> _handleBack() async {
    if (await _webViewController.canGoBack()) {
      await _webViewController.goBack();
    } else if (mounted) {
      // On the home page, let Android handle the back action.
      SystemNavigator.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (!didPop) {
          await _handleBack();
        }
      },
      child: Scaffold(
        body: SafeArea(
          child: Stack(
            children: [
              WebViewWidget(controller: _webViewController),
              if (_isLoading)
                const ColoredBox(
                  color: Color(0xFF0D0F18),
                  child: Center(
                    child: CircularProgressIndicator(
                      color: Color(0xFFE94C9A),
                    ),
                  ),
                ),
              if (_loadFailed)
                Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text('Halaman XSCTEAMZ gagal dibuka.'),
                        const SizedBox(height: 12),
                        ElevatedButton(
                          onPressed: () {
                            setState(() {
                              _isLoading = true;
                              _loadFailed = false;
                            });
                            _webViewController.reload();
                          },
                          child: const Text('Coba lagi'),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
