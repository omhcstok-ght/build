import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

/* LICENCE TO RIZAL - RIZAL™ - DO NOT COPY - APP FREE */

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const DompetKuApp());
}

class DompetKuApp extends StatelessWidget {
  const DompetKuApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF6C63FF)),
        scaffoldBackgroundColor: const Color(0xFFF7F8FC),
      ),
      home: const RootPage(),
    );
  }
}

final fmt = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);
final dfmt = DateFormat('dd MMM yyyy • HH:mm', 'id_ID');
final dfmtShort = DateFormat('dd MMM', 'id_ID');
final monthFmt = DateFormat('MMMM yyyy', 'id_ID');
const cP = Color(0xFF6C63FF);
const cG = Color(0xFF22C55E);
const cR = Color(0xFFEF4444);
const cO = Color(0xFFF59E0B);

// MODELS
class Tx {
  String title;
  double amount;
  bool income;
  DateTime date;
  String? productId;
  String monthKey; // yyyy-MM
  Tx({required this.title, required this.amount, required this.income, required this.date, this.productId, required this.monthKey});
  Map<String, dynamic> toJson() => {'t': title, 'a': amount, 'i': income, 'd': date.toIso8601String(), 'p': productId, 'm': monthKey};
  static Tx fromJson(Map j) => Tx(
    title: j['t'], amount: (j['a'] as num).toDouble(), income: j['i'], date: DateTime.parse(j['d']),
    productId: j['p'], monthKey: j['m'] ?? DateFormat('yyyy-MM').format(DateTime.parse(j['d']))
  );
}

class Product {
  String id;
  String name;
  double modal;
  double jual;
  int stok;
  DateTime created;
  Product({required this.id, required this.name, required this.modal, required this.jual, required this.stok, required this.created});
  Map toJson() => {'id': id, 'n': name, 'mo': modal, 'ju': jual, 'st': stok, 'd': created.toIso8601String()};
  static Product fromJson(Map j) => Product(id: j['id'], name: j['n'], modal: (j['mo'] as num).toDouble(), jual: (j['ju'] as num).toDouble(), stok: j['st'], created: DateTime.parse(j['d']));
}

class RootPage extends StatefulWidget {
  const RootPage({super.key});
  @override
  State<RootPage> createState() => _RootState();
}

class _RootState extends State<RootPage> {
  List<Tx> tx = [];
  List<Product> products = [];
  int tab = 0;
  String selectedMonth = DateFormat('yyyy-MM').format(DateTime.now());
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final sp = await SharedPreferences.getInstance();
    final rTx = sp.getString('tx_v2');
    final rProd = sp.getString('prod_v2');
    if (rTx != null) {
      try { tx = (jsonDecode(rTx) as List).map((e) => Tx.fromJson(e)).toList(); } catch (_) {}
    } else {
      // migrasi dari versi lama
      final old = sp.getString('tx');
      if (old != null) {
        try {
          tx = (jsonDecode(old) as List).map((e) {
            final d = DateTime.parse(e['d']);
            return Tx(title: e['t'], amount: (e['a'] as num).toDouble(), income: e['i'], date: d, monthKey: DateFormat('yyyy-MM').format(d));
          }).toList();
        } catch (_) {}
      }
    }
    if (rProd != null) {
      try { products = (jsonDecode(rProd) as List).map((e) => Product.fromJson(e)).toList(); } catch (_) {}
    }
    setState(() => loading = false);
  }

  Future<void> _save() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString('tx_v2', jsonEncode(tx.map((e) => e.toJson()).toList()));
    await sp.setString('prod_v2', jsonEncode(products.map((e) => e.toJson()).toList()));
  }

  // Stats
  double get totalBal => tx.fold(0, (s, e) => s + (e.income ? e.amount : -e.amount));
  List<Tx> get txThisMonth => tx.where((e) => e.monthKey == selectedMonth).toList();
  double get incomeMonth => txThisMonth.where((e) => e.income).fold(0, (s, e) => s + e.amount);
  double get expenseMonth => txThisMonth.where((e) => !e.income).fold(0, (s, e) => s + e.amount);
  
  Map<String, double> get monthlyMap {
    final m = <String, double>{};
    for (var t in tx) {
      m[t.monthKey] = (m[t.monthKey] ?? 0) + (t.income ? t.amount : -t.amount);
    }
    return m;
  }

  List<String> get allMonths {
    final s = tx.map((e) => e.monthKey).toSet().toList()..sort();
    final cur = DateFormat('yyyy-MM').format(DateTime.now());
    if (!s.contains(cur)) s.add(cur);
    s.sort();
    return s.reversed.toList();
  }

  void _addTx({bool income = false}) async {
    final titleC = TextEditingController();
    final amountC = TextEditingController();
    String? selectedProdId;
    final result = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) {
        return StatefulBuilder(builder: (ctx, setM) {
          return Padding(
            padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom, left: 20, right: 20, top: 20),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(2))),
              const SizedBox(height: 16),
              Text(income ? 'Catat Pemasukan' : 'Catat Pengeluaran', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              TextField(controller: titleC, decoration: const InputDecoration(labelText: 'Judul / Nama Produk', border: OutlineInputBorder())),
              const SizedBox(height: 12),
              TextField(controller: amountC, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Nominal Rp', border: OutlineInputBorder())),
              if (products.isNotEmpty) ...[
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: selectedProdId,
                  decoration: const InputDecoration(labelText: 'Produk Khusus (opsional)', border: OutlineInputBorder()),
                  items: products.map((p) => DropdownMenuItem(value: p.id, child: Text('${p.name} - ${fmt.format(p.jual)}'))).toList(),
                  onChanged: (v) => setM(() {
                    selectedProdId = v;
                    if (v != null) {
                      final pr = products.firstWhere((e) => e.id == v);
                      if (!income) amountC.text = pr.modal.toStringAsFixed(0);
                      if (income) { titleC.text = 'Jual ${pr.name}'; amountC.text = pr.jual.toStringAsFixed(0); }
                    }
                  }),
                )
              ],
              const SizedBox(height: 20),
              SizedBox(width: double.infinity, child: FilledButton(
                style: FilledButton.styleFrom(backgroundColor: income ? cG : cP, padding: const EdgeInsets.all(14)),
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Simpan Catatan'),
              )),
              const SizedBox(height: 24),
            ]),
          );
        });
      },
    );
    if (result == true && titleC.text.isNotEmpty) {
      final amount = double.tryParse(amountC.text.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
      final now = DateTime.now();
      setState(() {
        tx.insert(0, Tx(title: titleC.text, amount: amount, income: income, date: now, productId: selectedProdId, monthKey: DateFormat('yyyy-MM').format(now)));
        // update stok
        if (income && selectedProdId != null) {
          final idx = products.indexWhere((p) => p.id == selectedProdId);
          if (idx != -1 && products[idx].stok > 0) products[idx].stok--;
        }
      });
      await _save();
    }
  }

  void _addProduct() async {
    final nC = TextEditingController(), moC = TextEditingController(), juC = TextEditingController(), stC = TextEditingController(text: '10');
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('Produk Khusus'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: nC, decoration: const InputDecoration(labelText: 'Nama Produk')),
        TextField(controller: moC, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Harga Modal')),
        TextField(controller: juC, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Harga Jual')),
        TextField(controller: stC, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Stok')),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(_, false), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(_, true), child: const Text('Simpan'))],
    ));
    if (ok == true && nC.text.isNotEmpty) {
      setState(() => products.add(Product(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: nC.text,
        modal: double.tryParse(moC.text) ?? 0,
        jual: double.tryParse(juC.text) ?? 0,
        stok: int.tryParse(stC.text) ?? 0,
        created: DateTime.now(),
      )));
      await _save();
    }
  }

  void _showStruk(Tx t) {
    showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => StrukSheet(tx: t, product: t.productId == null ? null : products.where((p) => p.id == t.productId).firstOrNull));
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      body: IndexedStack(index: tab, children: [
        DashboardTab(
          bal: totalBal, incomeMonth: incomeMonth, expenseMonth: expenseMonth,
          selectedMonth: selectedMonth, allMonths: allMonths, tx: txThisMonth,
          monthlyMap: monthlyMap, onMonthChange: (v) => setState(() => selectedMonth = v),
          onTapTx: _showStruk,
        ),
        ProductTab(products: products, onAdd: _addProduct, onDelete: (id) async { setState(() => products.removeWhere((p) => p.id == id)); await _save(); }),
        TransaksiTab(allTx: tx, onTap: _showStruk, onDelete: (i) async { setState(() => tx.removeAt(i)); await _save(); }),
        MonitoringTab(tx: tx, products: products, monthlyMap: monthlyMap),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.inventory_2), label: 'Produk'),
          NavigationDestination(icon: Icon(Icons.receipt_long), label: 'Catat'),
          NavigationDestination(icon: Icon(Icons.monitor_heart), label: 'Pantau'),
        ],
      ),
      floatingActionButton: tab == 1 ? FloatingActionButton(onPressed: _addProduct, backgroundColor: cP, child: const Icon(Icons.add, color: Colors.white))
        : tab == 2 ? Row(mainAxisSize: MainAxisSize.min, children: [
            FloatingActionButton.small(heroTag: 'in', backgroundColor: cG, onPressed: () => _addTx(income: true), child: const Icon(Icons.add, color: Colors.white)),
            const SizedBox(width: 8),
            FloatingActionButton.small(heroTag: 'out', backgroundColor: cR, onPressed: () => _addTx(), child: const Icon(Icons.remove, color: Colors.white)),
          ]) : null,
    );
  }
}

// DASHBOARD
class DashboardTab extends StatelessWidget {
  final double bal, incomeMonth, expenseMonth;
  final String selectedMonth;
  final List<String> allMonths;
  final List<Tx> tx;
  final Map<String, double> monthlyMap;
  final Function(String) onMonthChange;
  final Function(Tx) onTapTx;
  const DashboardTab({super.key, required this.bal, required this.incomeMonth, required this.expenseMonth, required this.selectedMonth, required this.allMonths, required this.tx, required this.monthlyMap, required this.onMonthChange, required this.onTapTx});
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('DompetKu Digital', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      Text('RIZAL™ • Catat Produk & Bulanan', style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
      const SizedBox(height: 16),
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: const LinearGradient(colors: [cP, Color(0xFF8B7FFF)]), borderRadius: BorderRadius.circular(20)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Total Saldo', style: TextStyle(color: Colors.white70, fontSize: 13)),
        Text(fmt.format(bal), style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: _miniCard('Masuk Bulan Ini', incomeMonth, cG)),
          const SizedBox(width: 12),
          Expanded(child: _miniCard('Keluar Bulan Ini', expenseMonth, cR)),
        ])
      ])),
      const SizedBox(height: 16),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('Per Bulan', style: TextStyle(fontWeight: FontWeight.bold)),
        DropdownButton<String>(value: selectedMonth, items: allMonths.map((m) {
          final dt = DateFormat('yyyy-MM').parse(m);
          return DropdownMenuItem(value: m, child: Text(monthFmt.format(dt), style: const TextStyle(fontSize: 12)));
        }).toList(), onChanged: (v) { if (v != null) onMonthChange(v); }),
      ]),
      const SizedBox(height: 8),
      Container(height: 160, padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)), child: MonthlyChart(data: monthlyMap)),
      const SizedBox(height: 16),
      const Text('Transaksi Bulan Ini', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      if (tx.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(20), child: Center(child: Text('Belum ada transaksi bulan ini'))))
      else ...tx.take(8).map((t) => _txTile(t, onTapTx)),
    ]));
  }
  Widget _miniCard(String label, double val, Color c) => Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.2), borderRadius: BorderRadius.circular(12)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(label, style: const TextStyle(color: Colors.white70, fontSize: 10)), Text(fmt.format(val), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14))
  ]));
}

Widget _txTile(Tx t, Function(Tx) onTap) {
  final col = t.income ? cG : cR;
  return Card(margin: const EdgeInsets.only(bottom: 8), child: ListTile(
    leading: CircleAvatar(backgroundColor: col.withValues(alpha: 0.15), child: Icon(t.income ? Icons.arrow_downward : Icons.arrow_upward, color: col, size: 18)),
    title: Text(t.title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
    subtitle: Text('${dfmtShort.format(t.date)} • ${t.monthKey}', style: const TextStyle(fontSize: 11)),
    trailing: Text('${t.income ? '+' : '-'}${fmt.format(t.amount)}', style: TextStyle(fontWeight: FontWeight.bold, color: col, fontSize: 12)),
    onTap: () => onTap(t),
  ));
}

class MonthlyChart extends StatelessWidget {
  final Map<String, double> data;
  const MonthlyChart({super.key, required this.data});
  @override
  Widget build(BuildContext context) {
    final keys = data.keys.toList()..sort();
    final last6 = keys.length > 6 ? keys.sublist(keys.length - 6) : keys;
    if (last6.isEmpty) return const Center(child: Text('Belum ada data'));
    double maxVal = last6.map((k) => data[k]!.abs()).fold(0.0, (a, b) => a > b ? a : b);
    if (maxVal == 0) maxVal = 1;
    return Row(crossAxisAlignment: CrossAxisAlignment.end, children: last6.map((k) {
      final v = data[k]!;
      final h = (v.abs() / maxVal) * 90 + 10;
      final isPos = v >= 0;
      return Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: Column(children: [
        Text(fmt.format(v).replaceAll('Rp ', ''), style: TextStyle(fontSize: 8, color: isPos ? cG : cR, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis),
        const SizedBox(height: 4),
        Container(height: h, decoration: BoxDecoration(color: isPos ? cG.withValues(alpha: 0.8) : cR.withValues(alpha: 0.8), borderRadius: BorderRadius.circular(6))),
        const SizedBox(height: 4),
        Text(k.substring(5), style: const TextStyle(fontSize: 10)),
      ])));
    }).toList());
  }
}

// PRODUK
class ProductTab extends StatelessWidget {
  final List<Product> products;
  final VoidCallback onAdd;
  final Function(String) onDelete;
  const ProductTab({super.key, required this.products, required this.onAdd, required this.onDelete});
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Produk Khusus', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const Text('Catat modal, jual, stok - untung otomatis kepantau', style: TextStyle(fontSize: 12, color: Colors.grey)),
      const SizedBox(height: 16),
      Expanded(child: products.isEmpty ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.inventory_2_outlined, size: 64, color: Colors.grey),
        const SizedBox(height: 8),
        const Text('Belum ada produk khusus'),
        const SizedBox(height: 12),
        FilledButton(onPressed: onAdd, child: const Text('Tambah Produk Pertama')),
      ])) : GridView.builder(gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 0.9, crossAxisSpacing: 12, mainAxisSpacing: 12),
        itemCount: products.length,
        itemBuilder: (_, i) {
          final p = products[i];
          final profit = p.jual - p.modal;
          final margin = p.modal == 0 ? 0 : (profit / p.modal * 100);
          return Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.grey.shade200)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Expanded(child: Text(p.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13), maxLines: 1, overflow: TextOverflow.ellipsis)),
              InkWell(onTap: () => onDelete(p.id), child: const Icon(Icons.close, size: 16, color: Colors.grey)),
            ]),
            const SizedBox(height: 8),
            Text('Modal: ${fmt.format(p.modal)}', style: const TextStyle(fontSize: 11)),
            Text('Jual: ${fmt.format(p.jual)}', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: profit >= 0 ? cG.withValues(alpha: 0.15) : cR.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(6)), child: Text('Untung ${fmt.format(profit)} (${margin.toStringAsFixed(0)}%)', 