import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'ws_client.dart';
import 'pages/devices_page.dart';

void main() {
  runApp(MyApp(ws: WsClient('wss://C2_HOST:8766')..connect()));
}

class MyApp extends StatelessWidget {
  final WsClient ws;
  const MyApp({super.key, required this.ws});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: ws,
      child: MaterialApp(
        title: 'Console',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF00E5A0),
            brightness: Brightness.dark,
          ),
          scaffoldBackgroundColor: const Color(0xFF0A0E12),
          fontFamily: 'SF Pro Display',
        ),
        home: const DevicesPage(),
      ),
    );
  }
}