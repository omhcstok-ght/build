
import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';
import 'screens/onboarding_screen.dart';
import 'screens/login_screen.dart';
void main(){
  WidgetsFlutterBinding.ensureInitialized();
  runApp(DompetkuApp());
}
class DompetkuApp extends StatelessWidget {
  const DompetkuApp({super.key});
  @override
  Widget build(BuildContext context){
    return MaterialApp(
      title: 'Dompetku Mobile FORCE',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.deepPurple, useMaterial3: true, scaffoldBackgroundColor: Color(0xFFF5F7FB)),
      home: SplashScreen(),
    );
  }
}
