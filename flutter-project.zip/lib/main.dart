import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_audio_capture/flutter_audio_capture.dart';
import 'package:flutter_pcm_sound/flutter_pcm_sound.dart';

void main() => runApp(const VoiceChangerApp());

enum VoiceEffect { normal, robot, echo, radio }

class VoiceChangerApp extends StatelessWidget {
  const VoiceChangerApp({super.key});

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFFB85CFF);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Voice Changer',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF101018),
        colorScheme: ColorScheme.fromSeed(seedColor: accent, brightness: Brightness.dark),
        useMaterial3: true,
      ),
      home: const VoiceChangerHome(),
    );
  }
}

class VoiceChangerHome extends StatefulWidget {
  const VoiceChangerHome({super.key});

  @override
  State<VoiceChangerHome> createState() => _VoiceChangerHomeState();
}

class _VoiceChangerHomeState extends State<VoiceChangerHome> {
  static const int sampleRate = 16000;
  final FlutterAudioCapture _capture = FlutterAudioCapture();
  VoiceEffect _effect = VoiceEffect.normal;
  bool _running = false;
  bool _busy = false;
  bool _ready = false;
  String? _error;
  double _level = 0;
  late final List<double> _echoBuffer = List<double>.filled((sampleRate * 0.22).round(), 0);
  int _echoIndex = 0;
  double _phase = 0;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    try {
      await _capture.init();
      await FlutterPcmSound.setup(sampleRate: sampleRate, channelCount: 1);
      await FlutterPcmSound.setFeedThreshold(1600);
      if (mounted) setState(() { _ready = true; _error = null; });
    } catch (e) {
      if (mounted) setState(() => _error = 'Audio belum siap: $e');
    }
  }

  Future<void> _toggle() async {
    if (_busy) return;
    setState(() { _busy = true; _error = null; });
    try {
      if (_running) {
        await _capture.stop();
        
        if (mounted) setState(() => _running = false);
      } else {
        if (!_ready) throw StateError('Audio belum selesai disiapkan.');
        FlutterPcmSound.start();
        if (mounted) setState(() => _running = true);
        await _capture.start(_onAudio, _onCaptureError, sampleRate: sampleRate, bufferSize: 3000);
      }
    } catch (e) {
      try { await _capture.stop();  } catch (_) {}
      if (mounted) setState(() { _running = false; _error = 'Tidak dapat memulai audio. Periksa izin mikrofon: $e'; });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _onCaptureError(Object error) {
    if (mounted) setState(() => _error = 'Kesalahan mikrofon: $error');
  }

  void _onAudio(dynamic data) {
    if (!_running && !_busy) return;
    try {
      final input = data is Float64List ? data : Float64List.fromList((data as List).cast<double>());
      if (input.isEmpty) return;
      final output = <int>[];
      double peak = 0;
      for (final raw in input) {
        final x = raw.clamp(-1.0, 1.0).toDouble();
        peak = math.max(peak, x.abs());
        final y = _applyEffect(x);
        output.add((y.clamp(-1.0, 1.0) * 32767).round());
      }
      if (mounted) setState(() => _level = (_level * 0.72) + (peak * 0.28));
      unawaited(FlutterPcmSound.feed(PcmArrayInt16.fromList(output)));
    } catch (e) { _onCaptureError(e); }
  }

  double _applyEffect(double input) {
    switch (_effect) {
      case VoiceEffect.normal:
        return input;
      case VoiceEffect.robot:
        _phase += 2 * math.pi * 42 / sampleRate;
        if (_phase >= 2 * math.pi) _phase -= 2 * math.pi;
        return input * math.sin(_phase) * 1.35;
      case VoiceEffect.echo:
        final delayed = _echoBuffer[_echoIndex];
        _echoBuffer[_echoIndex] = input + delayed * 0.28;
        _echoIndex = (_echoIndex + 1) % _echoBuffer.length;
        return input + delayed * 0.48;
      case VoiceEffect.radio:
        final clipped = (input * 2.2).clamp(-0.72, 0.72).toDouble();
        return (clipped * 18).round() / 18;
    }
  }

  void _chooseEffect(VoiceEffect effect) {
    setState(() {
      _effect = effect;
      _echoBuffer.fillRange(0, _echoBuffer.length, 0);
      _echoIndex = 0;
    });
  }

  @override
  void dispose() {
    unawaited(_capture.stop());
    unawaited(FlutterPcmSound.release());
    super.dispose();
  }

  String get _effectName => switch (_effect) {
    VoiceEffect.normal => 'Normal', VoiceEffect.robot => 'Robot',
    VoiceEffect.echo => 'Echo', VoiceEffect.radio => 'Radio',
  };

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFFB85CFF);
    return Scaffold(
      appBar: AppBar(title: const Text('VOICE CHANGER', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.4)), centerTitle: true, backgroundColor: Colors.transparent),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF302044), Color(0xFF191927)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                borderRadius: BorderRadius.circular(26), border: Border.all(color: accent.withOpacity(0.35)),
              ),
              child: Column(children: [
                const Icon(Icons.graphic_eq, size: 58, color: accent),
                const SizedBox(height: 12),
                const Text('Ubah suara secara langsung', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 7),
                Text(_running ? 'Mikrofon aktif • $_effectName' : 'Pilih efek lalu mulai', style: TextStyle(color: Colors.white.withOpacity(0.7))),
                const SizedBox(height: 22),
                ClipRRect(borderRadius: BorderRadius.circular(20), child: LinearProgressIndicator(minHeight: 9, value: _running ? _level.clamp(0.04, 1) : 0, backgroundColor: Colors.white12, color: accent)),
                const SizedBox(height: 22),
                SizedBox(width: double.infinity, height: 54, child: FilledButton.icon(
                  onPressed: (_busy || !_ready) ? null : _toggle,
                  icon: Icon(_running ? Icons.stop : Icons.mic),
                  label: Text(_busy ? 'MENYIAPKAN...' : !_ready ? 'MEMUAT AUDIO...' : _running ? 'HENTIKAN' : 'MULAI VOICE CHANGER', style: const TextStyle(fontWeight: FontWeight.bold)),
                  style: FilledButton.styleFrom(backgroundColor: _running ? const Color(0xFFDF496A) : accent, foregroundColor: Colors.white),
                )),
              ]),
            ),
            const SizedBox(height: 26),
            const Text('PILIH EFEK SUARA', style: TextStyle(fontSize: 13, letterSpacing: 1.2, fontWeight: FontWeight.bold, color: Colors.white70)),
            const SizedBox(height: 12),
            _effectTile(VoiceEffect.normal, Icons.record_voice_over, 'Normal', 'Suara asli'),
            _effectTile(VoiceEffect.robot, Icons.smart_toy, 'Robot', 'Efek robotik'),
            _effectTile(VoiceEffect.echo, Icons.waves, 'Echo', 'Suara bergema'),
            _effectTile(VoiceEffect.radio, Icons.radio, 'Radio', 'Efek radio lo-fi'),
            if (_error != null) ...[
              const SizedBox(height: 14),
              Text(_error!, style: const TextStyle(color: Colors.redAccent)),
            ],
            const SizedBox(height: 18),
            const Text('Tips: gunakan earphone agar suara dari speaker tidak masuk kembali ke mikrofon. Berikan izin mikrofon saat diminta.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.5)),
          ],
        ),
      ),
    );
  }

  Widget _effectTile(VoiceEffect effect, IconData icon, String title, String subtitle) {
    final selected = _effect == effect;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: selected ? const Color(0xFF342347) : const Color(0xFF1B1B27),
        borderRadius: BorderRadius.circular(17),
        child: InkWell(
          borderRadius: BorderRadius.circular(17), onTap: () => _chooseEffect(effect),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(17), border: Border.all(color: selected ? const Color(0xFFB85CFF) : Colors.white.withOpacity(0.07))),
            child: Row(children: [
              Icon(icon, color: const Color(0xFFCE91FF), size: 27), const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 3),
                Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 12)),
              ])),
              if (selected) const Icon(Icons.check_circle, color: Color(0xFFCE91FF)),
            ]),
          ),
        ),
      ),
    );
  }
}
