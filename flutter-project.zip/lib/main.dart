import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: Setup(),
    ));

class Setup extends StatefulWidget {
  const Setup({super.key});
  @override
  State<Setup> createState() => _SetupState();
}

class _SetupState extends State<Setup> {
  final s = TextEditingController(), n = TextEditingController();

  @override
  Widget build(BuildContext c) => Scaffold(
        backgroundColor: const Color(0xFF0F0F1A),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text('Hey, dompetku!',
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                ),
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text('Welcome back!',
                      style: TextStyle(color: Colors.white38, fontSize: 11)),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: n,
                  style: const TextStyle(fontSize: 13),
                  decoration: InputDecoration(
                    isDense: true,
                    labelText: 'Nama',
                    filled: true,
                    fillColor: const Color(0xFF1E1E2F),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none),
                  ),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: s,
                  keyboardType: TextInputType.number,
                  style: const TextStyle(fontSize: 13),
                  decoration: InputDecoration(
                    isDense: true,
                    labelText: 'Saldo Awal Real',
                    filled: true,
                    fillColor: const Color(0xFF1E1E2F),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none),
                  ),
                ),
                const Spacer(),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFF3B30)),
                    onPressed: () {
                      int v = int.tryParse(s.text) ?? 0;
                      if (v > 0) {
                        Navigator.pushReplacement(
                            c, MaterialPageRoute(builder: (_) => Dash(v, n.text)));
                      }
                    },
                    child: const Text('MULAI', style: TextStyle(fontWeight: FontWeight.w900)),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}

class Tx {
  String t;
  int v;
  Tx(this.t, this.v);
}

class Dash extends StatefulWidget {
  final int a;
  final String m;
  Dash(this.a, this.m, {super.key});
  @override
  State<Dash> createState() => _DashState();
}

class _DashState extends State<Dash> {
  final List<Tx> l = [];
  
  int get tot {
    int total = widget.a;
    for (var tx in l) {
      total += tx.v;
    }
    return total;
  }

  String rp(int v) {
    String a = v.abs().toString(), o = '';
    int c = 0;
    for (int i = a.length - 1; i >= 0; i--) {
      if (c == 3) { o = '.$o'; c = 0; }
      o = '${a[i]}$o';
      c++;
    }
    return (v < 0 ? '-Rp ' : 'Rp ') + o;
  }

  void add(bool p) {
    final t = TextEditingController(), u = TextEditingController();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E1E2F),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: t, decoration: const InputDecoration(labelText: 'Judul')),
            const SizedBox(height: 8),
            TextField(controller: u, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Rp')),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity, height: 44,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: p ? Colors.green : Colors.red),
                onPressed: () {
                  int v = int.tryParse(u.text) ?? 0;
                  if (v > 0) {
                    if (!p) v = -v;
                    setState(() => l.insert(0, Tx(t.text.isEmpty ? 'Transaksi' : t.text, v)));
                  }
                  Navigator.pop(context);
                },
                child: Text(p ? '+ SIMPAN' : '- SIMPAN'),
              ),
            )
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        backgroundColor: const Color(0xFF0F0F1A),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(12),
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Hey, ${widget.m}!', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                      const Text('Welcome back!', style: TextStyle(color: Colors.white38, fontSize: 10)),
                    ],
                  ),
                  Row(children: [
                    Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: const Color(0xFF1E1E2F), borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.bar_chart_rounded, size: 16)),
                    const SizedBox(width: 6),
                    Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: const Color(0xFF1E1E2F), borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.notifications_rounded, size: 16))
                  ])
                ],
              ),
              const SizedBox(height: 10),
              Container(
                height: 130, padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), color: const Color(0xFF1E1E2F), border: Border.all(color: Colors.white10)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Container(width: 3, height: 10, color: const Color(0xFFFF3B30)), const SizedBox(width: 6),
                    const Text('ACCOUNT STATUS', style: TextStyle(fontSize: 8, letterSpacing: 2, color: Colors.white38))
                  ]),
                  const SizedBox(height: 8),
                  Row(children: [
                    const Text('MEMBER', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)), const SizedBox(width: 8),
                    Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: Colors.red.withOpacity(0.2), borderRadius: BorderRadius.circular(6), border: Border.all(color: Colors.red, width: 0.5)), child: const Row(children: [Icon(Icons.circle, size: 6, color: Colors.red), SizedBox(width: 3), Text('Active', style: TextStyle(fontSize: 8, color: Colors.red))]))
                  ]),
                  const Spacer(), Text(rp(tot), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                  Text('Saldo awal ${rp(widget.a)} ditentukan pemilik', style: const TextStyle(fontSize: 9, color: Colors.white38))
                ]),
              ),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: GestureDetector(onTap: () => add(false), child: Container(height: 44, decoration: BoxDecoration(color: const Color(0xFF1E1E2F), borderRadius: BorderRadius.circular(12)), child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.remove_rounded, color: Colors.red, size: 18), SizedBox(width: 6), Text('MINUS', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold))])))),
                const SizedBox(width: 8),
                Expanded(child: GestureDetector(onTap: () => add(true), child: Container(height: 44, decoration: BoxDecoration(color: const Color(0xFFFF3B30), borderRadius: BorderRadius.circular(12)), child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.add_rounded, color: Colors.white, size: 18), SizedBox(width: 6), Text('PLUS', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold))]))))
              ]),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: const Color(0xFF1E1E2F).withOpacity(0.6), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white10)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Container(padding: const EdgeInsets.all(6), decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(8)), child: const Icon(Icons.code_rounded, size: 14)), const SizedBox(width: 8),
                    const Text('02', style: TextStyle(color: Colors.white12, fontSize: 20, fontWeight: FontWeight.w900)), const Spacer(),
                    Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(12)), child: const Text('REAL', style: TextStyle(fontSize: 8)))
                  ]),
                  const SizedBox(height: 8),
                  const Text('DOMPETKU REAL', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
                  const Text('Saldo awal ditentukan pemilik APK, catat uang beneran lebih powerful.', style: TextStyle(color: Colors.white38, fontSize: 10)),
                  const SizedBox(height: 10),
                  SizedBox(width: double.infinity, height: 40, child: ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), onPressed: () => add(true), child: const Text('OPEN HERE', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900))))
                ]),
              ),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFF1E1E2F), borderRadius: BorderRadius.circular(16)),
                child: Column(children: l.isEmpty ? [const Text('Belum ada transaksi', style: TextStyle(color: Colors.white38, fontSize: 11))] : l.map((e) => Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Row(children: [Container(height: 32, width: 32, decoration: BoxDecoration(color: (e.v < 0 ? Colors.red : Colors.green).withOpacity(0.2), borderRadius: BorderRadius.circular(8)), child: Icon(e.v < 0 ? Icons.arrow_upward_rounded : Icons.arrow_downward_rounded, size: 16, color: e.v < 0 ? Colors.red : Colors.green)), const SizedBox(width: 8), Expanded(child: Text(e.t, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold))), Text(rp(e.v), style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: e.v < 0 ? Colors.red : Colors.green))]))).toList()),
              )
            ],
          ),
        ),
      );
}