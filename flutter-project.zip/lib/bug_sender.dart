// lib/bug_sender.dart
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'app_theme.dart';
import 'api_config.dart';

// ═══════════════════════════════════════════════════════════
// REUSABLE COMPONENTS (AUTO-ADAPT STYLE)
// ═══════════════════════════════════════════════════════════

/// LED — auto-adapt
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  const _Led({required this.color, this.size = 7});

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18),
        ),
      );
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.6),
            blurRadius: size,
            spreadRadius: 0.5,
          ),
        ],
      ),
    );
  }
}

/// Rivet — cuma muncul di original
class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 6});
  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.accentHi, C.primaryLo],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            offset: const Offset(1, 1),
            blurRadius: 1,
          ),
        ],
      ),
    );
  }
}

/// Screw — cuma muncul di original
class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Screw({required this.C, this.size = 10});
  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.text, C.bgDark],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            offset: const Offset(1, 1),
            blurRadius: 2,
          ),
        ],
      ),
      child: Center(
        child: Container(
          width: size * 0.6,
          height: 1.2,
          color: Colors.black.withOpacity(0.7),
        ),
      ),
    );
  }
}

/// Soft metal panel — auto-adapt
class _SoftPanel extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  final Color? accent;
  const _SoftPanel({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.radius = 12,
    this.accent,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    final accentColor = accent ?? C.textSub;

    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(5, 5),
              blurRadius: 0,
            ),
          ],
        ),
        child: child,
      );
    }

    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.bg, C.bgDark],
        ),
        border: Border.all(color: accentColor, width: 1.2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            offset: const Offset(0, 4),
            blurRadius: 8,
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.06),
            offset: const Offset(-1, -1),
            blurRadius: 2,
          ),
        ],
      ),
      child: child,
    );
  }
}

/// Inset panel — auto-adapt
class _SoftInset extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  const _SoftInset({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.symmetric(horizontal: 12),
  });

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bg,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.black, width: 3),
        ),
        child: child,
      );
    }
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: C.bgDeep,
        border: Border.all(color: C.bgDark, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.8),
            offset: const Offset(0, 1),
            blurRadius: 2,
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.04),
            offset: const Offset(0, -1),
            blurRadius: 1,
          ),
        ],
      ),
      child: child,
    );
  }
}

// ═══════════════════════════════════════════════════════════
// BUG SENDER PAGE
// ═══════════════════════════════════════════════════════════
class BugSenderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const BugSenderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage> {
  List<dynamic> senderList = [];
  bool isLoading = false;
  bool isRefreshing = false;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    _fetchSenders();
  }

  // ─── API ───────────────────────────────────────────────────
  Future<void> _fetchSenders() async {
    if (!mounted) return;
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final res = await http.get(
        Uri.parse("$baseUrl/mySender?key=${widget.sessionKey}"),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data["valid"] == true) {
          if (mounted) {
            setState(() => senderList = data["connections"] ?? []);
          }
        } else {
          if (mounted) {
            setState(() =>
                errorMessage = data["message"] ?? "Failed to fetch");
          }
        }
      } else {
        if (mounted) {
          setState(() =>
              errorMessage = "Server error: ${res.statusCode}");
        }
      }
    } catch (e) {
      if (mounted) setState(() => errorMessage = "Connection failed");
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
          isRefreshing = false;
        });
      }
    }
  }

  Future<void> _refreshSenders() async {
    setState(() => isRefreshing = true);
    await _fetchSenders();
  }

  Future<void> _addSenderWithType(String number, String type) async {
    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        "$baseUrl/getPairing?key=${widget.sessionKey}&number=$number&type=$type"
      );
      final res = await http.get(url).timeout(const Duration(seconds: 20));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data["valid"] == true) {
          final C = AppTheme.current.value;
          _showPairingCodeDialog(C, number, data['pairingCode'], type);
        } else {
          _toast(
            data['error'] ?? data['message'] ?? "Gagal bikin pairing code",
            error: true,
          );
        }
      } else if (res.statusCode == 403) {
        _toast("Cuma role VIP ke atas yang bisa bikin Global Sender",
            error: true);
      } else {
        _toast("Server error: ${res.statusCode}", error: true);
      }
    } catch (_) {
      _toast("Connection failed", error: true);
    } finally {
      if (mounted) setState(() => isLoading = false);
      _fetchSenders();
    }
  }

  Future<void> _deleteSender(String senderId) async {
    setState(() => isLoading = true);
    try {
      final res = await http.delete(Uri.parse(
          "$baseUrl/deleteSender?key=${widget.sessionKey}&id=$senderId"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data["valid"] == true) {
          _toast("Sender deleted successfully");
          _fetchSenders();
        } else {
          _toast(data["message"] ?? "Failed", error: true);
        }
      } else {
        _toast("Server error: ${res.statusCode}", error: true);
      }
    } catch (_) {
      _toast("Connection failed", error: true);
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  void _toast(String msg, {bool error = false}) {
    final C = AppTheme.current.value;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    final color = error ? C.primaryHi : C.primaryHi;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: C.bgDark,
        content: Row(
          children: [
            _Led(color: color, size: 8),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                msg,
                style: TextStyle(
                  color: isComic ? C.comicText : C.text,
                  fontSize: 12,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(isComic ? 12 : 8),
          side: BorderSide(
              color: color.withOpacity(0.5),
              width: isComic ? 3 : 1.5),
        ),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // ─── DIALOGS ───────────────────────────────────────────────
  void _showAddSenderDialog() {
    final C = AppTheme.current.value;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.85),
      isScrollControlled: true,
      builder: (ctx) => _AddSenderSheet(
        C: C,
        username: widget.username,
        role: widget.role,
        onAdd: (number, type) {
          Navigator.pop(ctx);
          _addSenderWithType(number, type);
        },
      ),
    );
  }

  void _showPairingCodeDialog(
      AppPalette C, String number, String code, String type) {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 20),
        child: _PairingDialogContent(
          C: C,
          number: number,
          code: code,
          type: type,
          onClose: () {
            Navigator.pop(ctx);
            _fetchSenders();
          },
        ),
      ),
    );
  }

  Future<void> _showDeleteConfirm(Map<String, dynamic> sender) async {
    final C = AppTheme.current.value;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    final confirmed = await showDialog<bool>(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: _SoftPanel(
          C: C,
          padding: const EdgeInsets.all(20),
          accent: C.primaryHi,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: isComic
                    ? BoxDecoration(
                        shape: BoxShape.circle,
                        color: C.primaryHi,
                        border:
                            Border.all(color: Colors.black, width: 4),
                      )
                    : BoxDecoration(
                        shape: BoxShape.circle,
                        color: C.primaryHi.withOpacity(0.15),
                        border: Border.all(
                            color: C.primaryHi.withOpacity(0.5),
                            width: 1.5),
                      ),
                child: Icon(Icons.delete_forever_rounded,
                    color: isComic
                        ? C.contrastTextOn(C.primaryHi)
                        : C.primaryHi,
                    size: 26),
              ),
              const SizedBox(height: 14),
              Text(
                'HAPUS SENDER?',
                style: TextStyle(
                  color: isComic ? C.comicText : C.primaryHi,
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 1.5,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                "Sender '${sender['sessionName'] ?? sender['id']}' akan dihapus permanen.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isComic ? C.comicText : C.text,
                  fontSize: 11,
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono',
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: _MetalButton(
                      C: C,
                      label: 'BATAL',
                      color: C.textSub,
                      height: 44,
                      onTap: () => Navigator.pop(ctx, false),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _MetalButton(
                      C: C,
                      label: 'HAPUS',
                      color: C.primaryHi,
                      height: 44,
                      icon: Icons.delete_outline_rounded,
                      onTap: () => Navigator.pop(ctx, true),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
    if (confirmed == true) _deleteSender(sender['id']);
  }

  // ─── BUILD ─────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: isComic ? C.bg : C.bgDark,
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [C.bg, C.bgDark, C.bgDeep],
                        ),
                      ),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _HalftonePainter(
                                color: C.primaryLo.withOpacity(0.12)),
                          ),
                        ),
                      ),
                    SafeArea(
                      child: Column(
                        children: [
                          _buildTopBar(C, isComic),
                          Expanded(child: _buildBody(C, isComic)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              floatingActionButton: _buildFAB(C, isComic),
            );
          },
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // TOP BAR
  // ═══════════════════════════════════════════════════════════
  Widget _buildTopBar(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Container(
        height: 54,
        decoration: isComic
            ? BoxDecoration(
                color: C.bgDark,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(4, 4),
                    blurRadius: 0,
                  ),
                ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [C.bg, C.bgDark],
                ),
                border: Border.all(color: C.textSub, width: 1),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.6),
                    offset: const Offset(0, 3),
                    blurRadius: 6,
                  ),
                ],
              ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Row(
            children: [
              if (!isComic) _Screw(C: C, size: 12),
              if (!isComic) const SizedBox(width: 8),
              _MetalIconButton(
                C: C,
                icon: Icons.arrow_back_ios_new_rounded,
                onTap: () => Navigator.pop(context),
              ),
              const SizedBox(width: 10),
              _Led(color: C.primaryHi, size: 7),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'BUG SENDER',
                      style: TextStyle(
                        color: isComic ? C.comicText : C.accent,
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: isComic ? 15 : 13,
                        letterSpacing: 2,
                        shadows: isComic
                            ? [
                                Shadow(
                                  color: C.comicTextOutline,
                                  offset: const Offset(1, 1),
                                  blurRadius: 0,
                                ),
                              ]
                            : const [
                                Shadow(
                                  color: Colors.black,
                                  offset: Offset(0, 1),
                                  blurRadius: 2,
                                ),
                              ],
                      ),
                    ),
                    const SizedBox(height: 1),
                    Text(
                      '${senderList.length} sender terdaftar',
                      style: TextStyle(
                        color: isComic
                            ? C.comicTextSub
                            : C.text.withOpacity(0.55),
                        fontSize: 9,
                        fontFamily: isComic
                            ? 'ComicNeue'
                            : 'ShareTechMono',
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
              _MetalIconButton(
                C: C,
                icon: isRefreshing
                    ? Icons.hourglass_top_rounded
                    : Icons.refresh_rounded,
                onTap: isLoading ? null : _refreshSenders,
              ),
              if (!isComic) const SizedBox(width: 8),
              if (!isComic) _Screw(C: C, size: 12),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BODY
  // ═══════════════════════════════════════════════════════════
  Widget _buildBody(AppPalette C, bool isComic) {
    if (isLoading && senderList.isEmpty) {
      return Center(
        child: CircularProgressIndicator(color: C.accent, strokeWidth: 2),
      );
    }
    if (errorMessage != null && senderList.isEmpty) {
      return _buildErrorState(C, isComic);
    }
    if (senderList.isEmpty) {
      return _buildEmptyState(C, isComic);
    }

    return RefreshIndicator(
      color: C.accent,
      backgroundColor: C.bgDark,
      onRefresh: _refreshSenders,
      child: ListView.builder(
        physics: const BouncingScrollPhysics(
            parent: AlwaysScrollableScrollPhysics()),
        padding: const EdgeInsets.fromLTRB(14, 8, 14, 100),
        itemCount: senderList.length + 1,
        itemBuilder: (context, index) {
          if (index == 0) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: _buildStatStrip(C, isComic),
            );
          }
          return _buildSenderCard(
            C,
            Map<String, dynamic>.from(senderList[index - 1]),
            isComic,
          );
        },
      ),
    );
  }
  
  
  // ═══════════════════════════════════════════════════════════
  // STAT STRIP
  // ═══════════════════════════════════════════════════════════
  Widget _buildStatStrip(AppPalette C, bool isComic) {
    final total = senderList.length;
    final privateCount = senderList
        .where((s) => (s['type'] ?? 'private') == 'private')
        .length;
    final globalCount = senderList
        .where((s) => (s['type'] ?? 'private') == 'global')
        .length;

    return _SoftPanel(
      C: C,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Column(
        children: [
          Row(
            children: [
              _Led(color: C.primaryHi, size: 7),
              const SizedBox(width: 10),
              Icon(Icons.wifi_tethering_rounded,
                  color: C.accent, size: 16),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  '$total SENDER TERDAFTAR',
                  style: TextStyle(
                    color: isComic ? C.comicText : C.accent,
                    fontSize: isComic ? 13 : 11,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    letterSpacing: isComic ? 1.5 : 1.2,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.comicTextOutline,
                              offset: const Offset(1, 1),
                              blurRadius: 0,
                            ),
                          ]
                        : null,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(isComic ? 6 : 4),
                  color: isComic
                      ? C.primaryHi
                      : C.primaryHi.withOpacity(0.2),
                  border: Border.all(
                      color: isComic
                          ? Colors.black
                          : C.primaryHi.withOpacity(0.5),
                      width: isComic ? 2.5 : 1),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _Led(color: C.primaryHi, size: 5),
                    const SizedBox(width: 5),
                    Text(
                      'LIVE',
                      style: TextStyle(
                        color: isComic
                            ? C.contrastTextOn(C.primaryHi)
                            : C.primaryHi,
                        fontSize: isComic ? 9 : 8,
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _miniStat(
                  C: C,
                  icon: Icons.person_rounded,
                  label: 'PRIBADI',
                  count: privateCount,
                  color: C.primaryHi,
                  isComic: isComic,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _miniStat(
                  C: C,
                  icon: Icons.public_rounded,
                  label: 'GLOBAL',
                  count: globalCount,
                  color: C.accent,
                  isComic: isComic,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _miniStat({
    required AppPalette C,
    required IconData icon,
    required String label,
    required int count,
    required Color color,
    required bool isComic,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: isComic
          ? BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: C.bg,
              border: Border.all(color: Colors.black, width: 3),
            )
          : BoxDecoration(
              borderRadius: BorderRadius.circular(6),
              color: Colors.black.withOpacity(0.4),
              border:
                  Border.all(color: color.withOpacity(0.4), width: 1),
            ),
      child: Row(
        children: [
          Icon(icon,
              color: isComic ? C.comicText : color, size: 14),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: isComic
                        ? C.comicTextSub
                        : color.withOpacity(0.8),
                    fontSize: isComic ? 10 : 8,
                    fontFamily:
                        isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  '$count',
                  style: TextStyle(
                    color: isComic ? C.comicText : color,
                    fontSize: isComic ? 16 : 14,
                    fontFamily:
                        isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.comicTextOutline,
                              offset: const Offset(1, 1),
                              blurRadius: 0,
                            ),
                          ]
                        : [
                            Shadow(
                                color: color.withOpacity(0.5),
                                blurRadius: 4),
                          ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SENDER CARD
  // ═══════════════════════════════════════════════════════════
  Widget _buildSenderCard(
      AppPalette C, Map<String, dynamic> sender, bool isComic) {
    final name = sender['sessionName'] ?? 'WhatsApp Sender';
    final isGlobal =
        sender['type'] == 'global' || sender['source'] == 'global';
    final isVip = sender['type'] == 'vip' || sender['source'] == 'vip';
    final isMine = sender['isMine'] == true;
    final owner = sender['owner'] ?? 'Unknown';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: isComic
          ? BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: C.bgDark,
              border: Border.all(color: Colors.black, width: 4),
              boxShadow: const [
                BoxShadow(
                  color: Colors.black,
                  offset: Offset(5, 5),
                  blurRadius: 0,
                ),
              ],
            )
          : BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [C.bg, C.bgDark],
              ),
              border: Border.all(
                color: isGlobal ? C.accent.withOpacity(0.6) : C.textSub,
                width: isGlobal ? 1.5 : 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: isGlobal
                      ? C.accent.withOpacity(0.25)
                      : Colors.black.withOpacity(0.5),
                  offset: const Offset(0, 4),
                  blurRadius: 8,
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.06),
                  offset: const Offset(-1, -1),
                  blurRadius: 2,
                ),
              ],
            ),
      child: Stack(
        children: [
          if (!isComic)
            Positioned(top: 4, left: 4, child: _Rivet(C: C, size: 5)),
          if (!isComic)
            Positioned(top: 4, right: 4, child: _Rivet(C: C, size: 5)),
          if (!isComic)
            Positioned(bottom: 4, left: 4, child: _Rivet(C: C, size: 5)),
          if (!isComic)
            Positioned(bottom: 4, right: 4, child: _Rivet(C: C, size: 5)),

          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              children: [
                Row(
                  children: [
                    // Avatar
                    Stack(
                      alignment: Alignment.center,
                      children: [
                        Container(
                          width: 48,
                          height: 48,
                          decoration: isComic
                              ? BoxDecoration(
                                  borderRadius:
                                      BorderRadius.circular(14),
                                  color: isGlobal
                                      ? C.accent
                                      : C.primaryHi,
                                  border: Border.all(
                                      color: Colors.black, width: 3.5),
                                )
                              : BoxDecoration(
                                  borderRadius:
                                      BorderRadius.circular(12),
                                  color: isGlobal
                                      ? C.accent.withOpacity(0.15)
                                      : C.primaryHi.withOpacity(0.15),
                                  border: Border.all(
                                    color: isGlobal
                                        ? C.accent.withOpacity(0.6)
                                        : C.primaryHi.withOpacity(0.5),
                                    width: 1.5,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: (isGlobal
                                              ? C.accent
                                              : C.primaryHi)
                                          .withOpacity(0.2),
                                      blurRadius: 8,
                                    ),
                                  ],
                                ),
                          child: Center(
                            child: FaIcon(
                              FontAwesomeIcons.whatsapp,
                              color: isComic
                                  ? C.contrastTextOn(isGlobal
                                      ? C.accent
                                      : C.primaryHi)
                                  : (isGlobal ? C.accent : C.primaryHi),
                              size: 22,
                            ),
                          ),
                        ),
                        Positioned(
                          right: -2,
                          bottom: -2,
                          child: Container(
                            padding: const EdgeInsets.all(2),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: C.bgDark,
                              border: isComic
                                  ? Border.all(
                                      color: Colors.black, width: 2)
                                  : null,
                            ),
                            child: _Led(
                              color:
                                  isGlobal ? C.accent : C.primaryHi,
                              size: 8,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(width: 12),

                    // Info
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            name,
                            style: TextStyle(
                              color:
                                  isComic ? C.comicText : C.text,
                              fontSize: isComic ? 15 : 13,
                              fontWeight: FontWeight.w900,
                              fontFamily:
                                  isComic ? 'Bangers' : 'Orbitron',
                              letterSpacing: isComic ? 1 : 0.5,
                              shadows: isComic
                                  ? [
                                      Shadow(
                                        color: C.comicTextOutline,
                                        offset: const Offset(1, 1),
                                        blurRadius: 0,
                                      ),
                                    ]
                                  : const [
                                      Shadow(
                                        color: Colors.black,
                                        offset: Offset(0, 1),
                                        blurRadius: 2,
                                      ),
                                    ],
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 5),
                          Row(
                            children: [
                              // Type badge
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  borderRadius:
                                      BorderRadius.circular(
                                          isComic ? 5 : 3),
                                  color: isComic
                                      ? C.bg
                                      : (isGlobal
                                          ? C.accent.withOpacity(0.2)
                                          : C.primaryHi
                                              .withOpacity(0.15)),
                                  border: Border.all(
                                    color: isComic
                                        ? Colors.black
                                        : (isGlobal
                                            ? C.accent
                                            : C.primaryHi),
                                    width: isComic ? 2 : 0.8,
                                  ),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(
                                      isGlobal
                                          ? Icons.public_rounded
                                          : Icons.person_rounded,
                                      color: isComic
                                          ? C.comicText
                                          : (isGlobal
                                              ? C.accent
                                              : C.primaryHi),
                                      size: 8,
                                    ),
                                    const SizedBox(width: 3),
                                    Text(
                                      isGlobal
                                          ? 'GLOBAL'
                                          : (isVip
                                              ? 'VIP'
                                              : 'PRIVATE'),
                                      style: TextStyle(
                                        color: isComic
                                            ? C.comicText
                                            : (isGlobal
                                                ? C.accent
                                                : C.primaryHi),
                                        fontSize: isComic ? 9 : 7,
                                        fontWeight: FontWeight.w900,
                                        fontFamily: isComic
                                            ? 'Bangers'
                                            : 'Orbitron',
                                        letterSpacing: 0.8,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 6),
                              // Owner badge
                              if (!isMine)
                                Flexible(
                                  child: Container(
                                    padding:
                                        const EdgeInsets.symmetric(
                                            horizontal: 6,
                                            vertical: 2),
                                    decoration: BoxDecoration(
                                      borderRadius:
                                          BorderRadius.circular(
                                              isComic ? 5 : 3),
                                      color: isComic
                                          ? C.bg
                                          : Colors.black
                                              .withOpacity(0.4),
                                      border: Border.all(
                                        color: isComic
                                            ? Colors.black
                                            : C.textSub,
                                        width: isComic ? 2 : 0.8,
                                      ),
                                    ),
                                    child: Text(
                                      '@$owner',
                                      style: TextStyle(
                                        color: isComic
                                            ? C.comicText
                                            : C.text,
                                        fontSize: isComic ? 9 : 7,
                                        fontFamily: isComic
                                            ? 'ComicNeue'
                                            : 'ShareTechMono',
                                        fontWeight: FontWeight.w700,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    // Status
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        borderRadius:
                            BorderRadius.circular(isComic ? 6 : 4),
                        color: isComic
                            ? C.primaryHi
                            : C.primaryHi.withOpacity(0.2),
                        border: Border.all(
                          color: isComic
                              ? Colors.black
                              : C.primaryHi.withOpacity(0.5),
                          width: isComic ? 2 : 1,
                        ),
                      ),
                      child: Text(
                        'ACTIVE',
                        style: TextStyle(
                          color: isComic
                              ? C.contrastTextOn(C.primaryHi)
                              : C.primaryHi,
                          fontSize: isComic ? 9 : 7,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                Container(
                  height: isComic ? 2 : 1,
                  color: isComic ? Colors.black : null,
                  decoration: isComic
                      ? null
                      : BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.transparent,
                              (isGlobal ? C.accent : C.textSub)
                                  .withOpacity(0.3),
                              Colors.transparent,
                            ],
                          ),
                        ),
                ),

                const SizedBox(height: 10),

                Row(
                  children: [
                    Expanded(
                      child: _MetalButton(
                        C: C,
                        label: 'REFRESH',
                        color: C.accent,
                        height: 40,
                        icon: Icons.refresh_rounded,
                        onTap: _refreshSenders,
                      ),
                    ),
                    if (isMine) ...[
                      const SizedBox(width: 8),
                      Expanded(
                        child: _MetalButton(
                          C: C,
                          label: 'HAPUS',
                          color: C.primaryHi,
                          height: 40,
                          icon: Icons.delete_outline_rounded,
                          onTap: () => _showDeleteConfirm(sender),
                        ),
                      ),
                    ] else ...[
                      const SizedBox(width: 8),
                      Expanded(
                        child: Container(
                          height: 40,
                          decoration: isComic
                              ? BoxDecoration(
                                  borderRadius:
                                      BorderRadius.circular(10),
                                  color: C.bg,
                                  border: Border.all(
                                      color: Colors.black, width: 3),
                                )
                              : BoxDecoration(
                                  borderRadius:
                                      BorderRadius.circular(8),
                                  color: C.bgDark,
                                  border: Border.all(
                                    color: C.bg,
                                    width: 1.2,
                                  ),
                                ),
                          child: Center(
                            child: Row(
                              mainAxisAlignment:
                                  MainAxisAlignment.center,
                              children: [
                                Icon(Icons.lock_outline_rounded,
                                    color: isComic
                                        ? C.comicTextSub
                                        : C.text,
                                    size: 12),
                                const SizedBox(width: 6),
                                Text(
                                  'MILIK ORANG',
                                  style: TextStyle(
                                    color: isComic
                                        ? C.comicTextSub
                                        : C.text,
                                    fontSize: isComic ? 11 : 9,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: isComic
                                        ? 'Bangers'
                                        : 'Orbitron',
                                    letterSpacing: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // EMPTY STATE
  // ═══════════════════════════════════════════════════════════
  Widget _buildEmptyState(AppPalette C, bool isComic) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: _SoftPanel(
          C: C,
          padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: isComic
                        ? BoxDecoration(
                            shape: BoxShape.circle,
                            color: C.primaryHi,
                            border: Border.all(
                                color: Colors.black, width: 5),
                            boxShadow: const [
                              BoxShadow(
                                color: Colors.black,
                                offset: Offset(5, 5),
                                blurRadius: 0,
                              ),
                            ],
                          )
                        : BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              colors: [C.bg, C.bgDark],
                            ),
                            border: Border.all(
                                color:
                                    C.primaryHi.withOpacity(0.5),
                                width: 1.5),
                            boxShadow: [
                              BoxShadow(
                                color: C.primaryHi.withOpacity(0.2),
                                blurRadius: 15,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                    child: Center(
                      child: FaIcon(
                        FontAwesomeIcons.whatsapp,
                        color: isComic
                            ? C.contrastTextOn(C.primaryHi)
                            : C.primaryHi,
                        size: 34,
                      ),
                    ),
                  ),
                  Positioned(
                    top: 4,
                    right: 4,
                    child: _Led(color: C.primaryHi, size: 10),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Text(
                'BELUM ADA SENDER',
                style: TextStyle(
                  color: isComic ? C.comicText : C.accent,
                  fontSize: isComic ? 15 : 13,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 2,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : const [
                          Shadow(
                            color: Colors.black,
                            offset: Offset(0, 1),
                            blurRadius: 2,
                          ),
                        ],
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'Tambah WhatsApp sender pertama\nuntuk mulai mengirim pesan.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isComic
                      ? C.comicText.withOpacity(0.8)
                      : C.text.withOpacity(0.6),
                  fontSize: 11,
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono',
                  fontWeight: FontWeight.w700,
                  height: 1.6,
                ),
              ),
              const SizedBox(height: 24),
              _MetalButton(
                C: C,
                label: 'TAMBAH SENDER',
                color: C.primaryHi,
                height: 46,
                icon: Icons.add_rounded,
                onTap: _showAddSenderDialog,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // ERROR STATE
  // ═══════════════════════════════════════════════════════════
  Widget _buildErrorState(AppPalette C, bool isComic) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: _SoftPanel(
          C: C,
          padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 24),
          accent: C.primaryHi,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: isComic
                    ? BoxDecoration(
                        shape: BoxShape.circle,
                        color: C.primaryHi,
                        border:
                            Border.all(color: Colors.black, width: 4),
                      )
                    : BoxDecoration(
                        shape: BoxShape.circle,
                        color: C.primaryHi.withOpacity(0.15),
                        border: Border.all(
                            color: C.primaryHi.withOpacity(0.5),
                            width: 1.5),
                      ),
                child: Icon(Icons.wifi_off_rounded,
                    color: isComic
                        ? C.contrastTextOn(C.primaryHi)
                        : C.primaryHi,
                    size: 28),
              ),
              const SizedBox(height: 16),
              Text(
                'KONEKSI GAGAL',
                style: TextStyle(
                  color: isComic ? C.comicText : C.primaryHi,
                  fontSize: isComic ? 15 : 13,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 2,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                errorMessage ?? 'Unknown error',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isComic ? C.comicText : C.text,
                  fontSize: 11,
                  fontFamily:
                      isComic ? 'ComicNeue' : 'ShareTechMono',
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 20),
              _MetalButton(
                C: C,
                label: 'COBA LAGI',
                color: C.accent,
                height: 44,
                icon: Icons.refresh_rounded,
                onTap: _fetchSenders,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // FAB
  // ═══════════════════════════════════════════════════════════
  Widget _buildFAB(AppPalette C, bool isComic) {
    final fabColor = C.primaryHi;
    final iconColor =
        isComic ? C.contrastTextOn(fabColor) : Colors.white;

    return GestureDetector(
      onTap: _showAddSenderDialog,
      child: Container(
        width: 56,
        height: 56,
        decoration: isComic
            ? BoxDecoration(
                color: fabColor,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(4, 4),
                    blurRadius: 0,
                  ),
                ],
              )
            : BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    C.primaryHi,
                    C.primary,
                    C.primaryLo,
                    C.primaryLo
                  ],
                  stops: const [0.0, 0.3, 0.7, 1.0],
                ),
                border: Border.all(color: C.primaryLo, width: 2),
                boxShadow: [
                  BoxShadow(
                    color: C.primaryHi.withOpacity(0.4),
                    blurRadius: 16,
                    spreadRadius: -2,
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.6),
                    offset: const Offset(0, 4),
                    blurRadius: 8,
                  ),
                ],
              ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            if (!isComic)
              Positioned(
                top: 4,
                left: 10,
                right: 10,
                child: Container(
                  height: 10,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.white.withOpacity(0.4),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
            Icon(
              Icons.add_rounded,
              color: iconColor,
              size: 26,
              shadows: isComic
                  ? [
                      Shadow(
                        color: iconColor == Colors.white
                            ? Colors.black
                            : Colors.white,
                        offset: const Offset(1, 1),
                        blurRadius: 0,
                      ),
                    ]
                  : const [
                      Shadow(
                        color: Colors.black54,
                        offset: Offset(0, 1),
                        blurRadius: 2,
                      ),
                    ],
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// ADD SENDER SHEET — Pilih Pribadi / Global
// ═══════════════════════════════════════════════════════════
class _AddSenderSheet extends StatefulWidget {
  final AppPalette C;
  final String username;
  final String role;
  final Function(String number, String type) onAdd;

  const _AddSenderSheet({
    required this.C,
    required this.username,
    required this.role,
    required this.onAdd,
  });

  @override
  State<_AddSenderSheet> createState() => _AddSenderSheetState();
}

class _AddSenderSheetState extends State<_AddSenderSheet> {
  final TextEditingController _phoneCtrl = TextEditingController();
  String _selectedType = 'private';

  bool get _canUseGlobal {
    final r = widget.role.toLowerCase();
    return r == 'developer' ||
        r == 'high owner' ||
        r == 'owner' ||
        r == 'moderator' ||
        r == 'partner' ||
        r == 'admin' ||
        r == 'vip';
  }

  @override
  void dispose() {
    _phoneCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;

    return Container(
      decoration: isComic
          ? BoxDecoration(
              color: C.bgDark,
              borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(24)),
              border: Border.all(color: Colors.black, width: 4),
            )
          : BoxDecoration(
              color: C.bgDark,
              borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(20)),
            ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
          ),
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Center(
                    child: Container(
                      width: 50,
                      height: isComic ? 5 : 4,
                      margin: const EdgeInsets.only(bottom: 16),
                      decoration: BoxDecoration(
                        color: isComic ? Colors.black : C.textSub,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),

                  Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: isComic
                            ? BoxDecoration(
                                shape: BoxShape.circle,
                                color: C.primaryHi,
                                border: Border.all(
                                    color: Colors.black, width: 3.5),
                              )
                            : BoxDecoration(
                                shape: BoxShape.circle,
                                color: C.primaryHi.withOpacity(0.15),
                                border: Border.all(
                                  color:
                                      C.primaryHi.withOpacity(0.5),
                                  width: 1.5,
                                ),
                              ),
                        child: Icon(
                          Icons.add_link_rounded,
                          color: isComic
                              ? C.contrastTextOn(C.primaryHi)
                              : C.primaryHi,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'TAMBAH SENDER',
                              style: TextStyle(
                                color: isComic
                                    ? C.comicText
                                    : C.accent,
                                fontSize: isComic ? 15 : 13,
                                fontWeight: FontWeight.w900,
                                fontFamily: isComic
                                    ? 'Bangers'
                                    : 'Orbitron',
                                letterSpacing: 1.5,
                                shadows: isComic
                                    ? [
                                        Shadow(
                                          color:
                                              C.comicTextOutline,
                                          offset:
                                              const Offset(1, 1),
                                          blurRadius: 0,
                                        ),
                                      ]
                                    : null,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              'Pilih tipe sender',
                              style: TextStyle(
                                color: isComic
                                    ? C.comicTextSub
                                    : C.text,
                                fontSize: 10,
                                fontFamily: isComic
                                    ? 'ComicNeue'
                                    : 'ShareTechMono',
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (!isComic) _Screw(C: C, size: 10),
                    ],
                  ),

                  const SizedBox(height: 20),

                  Text(
                    'TIPE SENDER',
                    style: TextStyle(
                      color: isComic ? C.comicText : C.accent,
                      fontSize: isComic ? 13 : 10,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 1.5,
                      shadows: isComic
                          ? [
                              Shadow(
                                color: C.comicTextOutline,
                                offset: const Offset(1, 1),
                                blurRadius: 0,
                              ),
                            ]
                          : null,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: _TypeCard(
                          C: C,
                          icon: Icons.person_rounded,
                          title: 'PRIBADI',
                          desc: 'Cuma lu yang\nbisa pake',
                          color: C.primaryHi,
                          selected: _selectedType == 'private',
                          isComic: isComic,
                          onTap: () {
                            HapticFeedback.selectionClick();
                            setState(() => _selectedType = 'private');
                          },
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _TypeCard(
                          C: C,
                          icon: Icons.public_rounded,
                          title: 'GLOBAL',
                          desc: _canUseGlobal
                              ? 'Semua user\nbisa pake'
                              : '🔒 VIP ke atas',
                          color: C.accent,
                          selected: _selectedType == 'global',
                          locked: !_canUseGlobal,
                          isComic: isComic,
                          onTap: () {
                            if (!_canUseGlobal) {
                              HapticFeedback.heavyImpact();
                              ScaffoldMessenger.of(context)
                                  .showSnackBar(
                                SnackBar(
                                  content: Text(
                                    'Cuma role VIP ke atas yang bisa bikin Global Sender',
                                    style: TextStyle(
                                      color: isComic
                                          ? C.comicText
                                          : C.text,
                                      fontFamily: isComic
                                          ? 'ComicNeue'
                                          : 'ShareTechMono',
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  backgroundColor: C.bgDark,
                                  behavior:
                                      SnackBarBehavior.floating,
                                  shape: RoundedRectangleBorder(
                                    borderRadius:
                                        BorderRadius.circular(
                                            isComic ? 12 : 8),
                                    side: BorderSide(
                                      color: C.primaryHi,
                                      width: isComic ? 3 : 1.5,
                                    ),
                                  ),
                                  margin:
                                      const EdgeInsets.all(16),
                                ),
                              );
                              return;
                            }
                            HapticFeedback.selectionClick();
                            setState(() => _selectedType = 'global');
                          },
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),

                  Text(
                    'NOMOR WHATSAPP',
                    style: TextStyle(
                      color: isComic ? C.comicText : C.accent,
                      fontSize: isComic ? 13 : 10,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 1.5,
                      shadows: isComic
                          ? [
                              Shadow(
                                color: C.comicTextOutline,
                                offset: const Offset(1, 1),
                                blurRadius: 0,
                              ),
                            ]
                          : null,
                    ),
                  ),
                  const SizedBox(height: 8),
                  _SoftInset(
                    C: C,
                    child: TextField(
                      controller: _phoneCtrl,
                      keyboardType: TextInputType.phone,
                      style: TextStyle(
                        color: isComic ? C.comicText : C.text,
                        fontFamily: isComic
                            ? 'ComicNeue'
                            : 'ShareTechMono',
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1,
                      ),
                      cursorColor:
                          isComic ? C.comicText : C.accent,
                      cursorWidth: 2,
                      decoration: InputDecoration(
                        hintText: '62812XXXXXXXX',
                        hintStyle: TextStyle(
                          color: isComic
                              ? C.comicTextMuted
                              : C.text.withOpacity(0.3),
                          fontFamily: isComic
                              ? 'ComicNeue'
                              : 'ShareTechMono',
                          fontSize: 13,
                        ),
                        prefixIcon: Icon(
                          Icons.phone_outlined,
                          color: C.accent,
                          size: 16,
                        ),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                          vertical: 16,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  _MetalButton(
                    C: C,
                    label: 'GENERATE PAIRING',
                    color: C.primaryHi,
                    height: 48,
                    icon: Icons.link_rounded,
                    onTap: () {
                      final num = _phoneCtrl.text.trim();
                      if (num.isEmpty) {
                        ScaffoldMessenger.of(context)
                            .showSnackBar(
                          SnackBar(
                            content: Text(
                              'Masukkan nomor WhatsApp dulu',
                              style: TextStyle(
                                color: isComic
                                    ? C.comicText
                                    : C.text,
                                fontFamily: isComic
                                    ? 'ComicNeue'
                                    : 'ShareTechMono',
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            backgroundColor: C.bgDark,
                            behavior: SnackBarBehavior.floating,
                            shape: RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius.circular(
                                      isComic ? 12 : 8),
                              side: BorderSide(
                                color: C.primaryHi,
                                width: isComic ? 3 : 1.5,
                              ),
                            ),
                            margin: const EdgeInsets.all(16),
                          ),
                        );
                        return;
                      }
                      widget.onAdd(num, _selectedType);
                    },
                  ),

                  const SizedBox(height: 12),

                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: isComic
                        ? BoxDecoration(
                            borderRadius:
                                BorderRadius.circular(10),
                            color: C.bg,
                            border: Border.all(
                                color: Colors.black, width: 3),
                          )
                        : BoxDecoration(
                            borderRadius:
                                BorderRadius.circular(8),
                            color: C.bgDark.withOpacity(0.5),
                            border: Border.all(
                              color: C.bg,
                              width: 1,
                            ),
                          ),
                    child: Row(
                      children: [
                        Icon(
                          _selectedType == 'global'
                              ? Icons.info_outline_rounded
                              : Icons.lock_outline_rounded,
                          color: _selectedType == 'global'
                              ? C.accent
                              : C.primaryHi,
                          size: 14,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            _selectedType == 'global'
                                ? 'Global sender bisa diliat & dipake SEMUA user.'
                                : 'Private sender cuma bisa diliat & dipake LU sendiri.',
                            style: TextStyle(
                              color: isComic
                                  ? C.comicText
                                  : C.text.withOpacity(0.7),
                              fontSize: isComic ? 11 : 9,
                              fontFamily: isComic
                                  ? 'ComicNeue'
                                  : 'ShareTechMono',
                              fontWeight: FontWeight.w700,
                              height: 1.5,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// TYPE CARD
// ═══════════════════════════════════════════════════════════
class _TypeCard extends StatelessWidget {
  final AppPalette C;
  final IconData icon;
  final String title;
  final String desc;
  final Color color;
  final bool selected;
  final bool locked;
  final bool isComic;
  final VoidCallback onTap;

  const _TypeCard({
    required this.C,
    required this.icon,
    required this.title,
    required this.desc,
    required this.color,
    required this.selected,
    required this.isComic,
    this.locked = false,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final effectiveColor = locked ? C.textSub : color;
    final selectedTextColor = isComic && selected
        ? C.contrastTextOn(effectiveColor)
        : Colors.white;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.all(14),
        decoration: isComic
            ? BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                color: selected ? effectiveColor : C.bg,
                border: Border.all(
                  color: Colors.black,
                  width: selected ? 4 : 3,
                ),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(4, 4),
                    blurRadius: 0,
                  ),
                ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: selected
                      ? [
                          effectiveColor.withOpacity(0.35),
                          effectiveColor.withOpacity(0.15),
                          C.bgDark,
                        ]
                      : [C.bg, C.bgDark],
                ),
                border: Border.all(
                  color: selected ? effectiveColor : C.bg,
                  width: selected ? 2 : 1.2,
                ),
                boxShadow: selected
                    ? [
                        BoxShadow(
                          color:
                              effectiveColor.withOpacity(0.4),
                          blurRadius: 12,
                          spreadRadius: 0,
                        ),
                        BoxShadow(
                          color: Colors.black.withOpacity(0.5),
                          offset: const Offset(0, 3),
                          blurRadius: 6,
                        ),
                      ]
                    : [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.4),
                          offset: const Offset(0, 2),
                          blurRadius: 4,
                        ),
                      ],
              ),
        child: Column(
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: isComic
                      ? BoxDecoration(
                          shape: BoxShape.circle,
                          color: C.bg,
                          border: Border.all(
                              color: Colors.black, width: 3),
                        )
                      : BoxDecoration(
                          shape: BoxShape.circle,
                          color: effectiveColor.withOpacity(0.2),
                          border: Border.all(
                            color:
                                effectiveColor.withOpacity(0.6),
                            width: 1.5,
                          ),
                          boxShadow: selected
                              ? [
                                  BoxShadow(
                                    color: effectiveColor
                                        .withOpacity(0.5),
                                    blurRadius: 10,
                                    spreadRadius: 1,
                                  ),
                                ]
                              : null,
                        ),
                  child: Icon(icon,
                      color: isComic
                          ? C.comicText
                          : effectiveColor,
                      size: 20),
                ),
                if (selected)
                  Positioned(
                    top: 0,
                    right: 0,
                    child: Container(
                      width: 16,
                      height: 16,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isComic
                            ? C.contrastTextOn(effectiveColor)
                            : effectiveColor,
                        border: Border.all(
                          color: Colors.black,
                          width: isComic ? 2 : 1.5,
                        ),
                      ),
                      child: Icon(
                        Icons.check_rounded,
                        color: isComic
                            ? effectiveColor
                            : Colors.white,
                        size: 10,
                      ),
                    ),
                  ),
                if (locked)
                  Positioned(
                    top: 0,
                    left: 0,
                    child: Container(
                      width: 16,
                      height: 16,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: C.primaryHi,
                        border: Border.all(
                          color: Colors.black,
                          width: isComic ? 2 : 1.5,
                        ),
                      ),
                      child: const Icon(
                        Icons.lock_rounded,
                        color: Colors.white,
                        size: 9,
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              title,
              style: TextStyle(
                color: isComic
                    ? (selected ? selectedTextColor : C.comicText)
                    : (selected ? effectiveColor : C.text),
                fontSize: isComic ? 13 : 11,
                fontWeight: FontWeight.w900,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: 1,
                shadows: isComic && selected
                    ? [
                        Shadow(
                          color: selectedTextColor == Colors.white
                              ? Colors.black
                              : Colors.white,
                          offset: const Offset(1, 1),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              desc,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: isComic
                    ? (selected
                        ? selectedTextColor.withOpacity(0.85)
                        : C.comicTextSub)
                    : C.text.withOpacity(0.55),
                fontSize: isComic ? 10 : 8,
                fontFamily:
                    isComic ? 'ComicNeue' : 'ShareTechMono',
                fontWeight: FontWeight.w700,
                height: 1.3,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// PAIRING DIALOG CONTENT
// ═══════════════════════════════════════════════════════════
class _PairingDialogContent extends StatefulWidget {
  final AppPalette C;
  final String number;
  final String code;
  final String type;
  final VoidCallback onClose;

  const _PairingDialogContent({
    required this.C,
    required this.number,
    required this.code,
    required this.type,
    required this.onClose,
  });

  @override
  State<_PairingDialogContent> createState() => _PairingDialogContentState();
}

class _PairingDialogContentState extends State<_PairingDialogContent> {
  bool _copied = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    final codeTextColor = isComic ? C.comicText : C.accent;

    return _SoftPanel(
      C: C,
      padding: const EdgeInsets.all(20),
      accent: C.primaryHi,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Stack(
            alignment: Alignment.center,
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: isComic
                    ? BoxDecoration(
                        shape: BoxShape.circle,
                        color: C.primaryHi,
                        border: Border.all(
                            color: Colors.black, width: 4),
                      )
                    : BoxDecoration(
                        shape: BoxShape.circle,
                        color: C.primaryHi.withOpacity(0.15),
                        border: Border.all(
                            color: C.primaryHi.withOpacity(0.5),
                            width: 1.5),
                        boxShadow: [
                          BoxShadow(
                            color: C.primaryHi.withOpacity(0.3),
                            blurRadius: 12,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                child: Icon(Icons.phonelink_lock_rounded,
                    color: isComic
                        ? C.contrastTextOn(C.primaryHi)
                        : C.primaryHi,
                    size: 26),
              ),
              Positioned(
                top: 0,
                right: 0,
                child: _Led(color: C.primaryHi, size: 10),
              ),
            ],
          ),
          const SizedBox(height: 14),

          Text(
            'KODE PAIRING',
            style: TextStyle(
              color: isComic ? C.comicText : C.accent,
              fontSize: isComic ? 16 : 14,
              fontWeight: FontWeight.w900,
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              letterSpacing: 2,
              shadows: isComic
                  ? [
                      Shadow(
                        color: C.comicTextOutline,
                        offset: const Offset(1, 1),
                        blurRadius: 0,
                      ),
                    ]
                  : const [
                      Shadow(
                        color: Colors.black,
                        offset: Offset(0, 1),
                        blurRadius: 2,
                      ),
                    ],
            ),
          ),
          const SizedBox(height: 8),

          Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(isComic ? 6 : 4),
              color: isComic
                  ? C.bg
                  : (widget.type == 'global'
                      ? C.accent.withOpacity(0.2)
                      : C.primaryHi.withOpacity(0.15)),
              border: Border.all(
                color: isComic
                    ? Colors.black
                    : (widget.type == 'global'
                        ? C.accent
                        : C.primaryHi),
                width: isComic ? 2 : 1.2,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  widget.type == 'global'
                      ? Icons.public_rounded
                      : Icons.person_rounded,
                  color: isComic
                      ? C.comicText
                      : (widget.type == 'global'
                          ? C.accent
                          : C.primaryHi),
                  size: 12,
                ),
                const SizedBox(width: 5),
                Text(
                  widget.type == 'global'
                      ? 'GLOBAL SENDER'
                      : 'PRIVATE SENDER',
                  style: TextStyle(
                    color: isComic
                        ? C.comicText
                        : (widget.type == 'global'
                            ? C.accent
                            : C.primaryHi),
                    fontSize: isComic ? 11 : 9,
                    fontWeight: FontWeight.w900,
                    fontFamily:
                        isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 10),
          Text(
            'Nomor: ${widget.number}',
            style: TextStyle(
              color: isComic
                  ? C.comicTextSub
                  : C.text.withOpacity(0.6),
              fontSize: 10,
              fontFamily:
                  isComic ? 'ComicNeue' : 'ShareTechMono',
              fontWeight: FontWeight.w700,
            ),
          ),

          const SizedBox(height: 18),

          _SoftInset(
            C: C,
            padding:
                const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
            child: Text(
              widget.code,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: codeTextColor,
                fontSize: 32,
                fontWeight: FontWeight.w900,
                letterSpacing: 10,
                fontFamily: 'monospace',
                shadows: isComic
                    ? [
                        Shadow(
                          color: C.comicTextOutline,
                          offset: const Offset(2, 2),
                          blurRadius: 0,
                        ),
                      ]
                    : [
                        Shadow(
                          color: C.primaryHi,
                          offset: const Offset(0, 0),
                          blurRadius: 8,
                        ),
                      ],
              ),
            ),
          ),

          const SizedBox(height: 12),

          GestureDetector(
            onTap: _copied
                ? null
                : () async {
                    await Clipboard.setData(
                        ClipboardData(text: widget.code));
                    if (mounted) setState(() => _copied = true);
                  },
            child: Container(
              width: double.infinity,
              height: 44,
              decoration: isComic
                  ? BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: _copied ? C.primary : C.bg,
                      border: Border.all(
                          color: Colors.black, width: 3),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(3, 3),
                          blurRadius: 0,
                        ),
                      ],
                    )
                  : BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: _copied
                            ? [C.primaryHi, C.primary]
                            : [C.textSub, C.bg, C.bgDark],
                      ),
                      border: Border.all(
                        color: _copied ? C.primary : C.bgDark,
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.5),
                          offset: const Offset(0, 3),
                          blurRadius: 5,
                        ),
                      ],
                    ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    _copied
                        ? Icons.check_rounded
                        : Icons.copy_rounded,
                    color: isComic
                        ? (_copied
                            ? C.contrastTextOn(C.primary)
                            : C.comicText)
                        : (_copied ? Colors.white : C.accent),
                    size: 16,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    _copied ? 'DISALIN!' : 'SALIN KODE',
                    style: TextStyle(
                      color: isComic
                          ? (_copied
                              ? C.contrastTextOn(C.primary)
                              : C.comicText)
                          : (_copied ? Colors.white : C.accent),
                      fontSize: isComic ? 13 : 11,
                      fontWeight: FontWeight.w900,
                      fontFamily:
                          isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 1.5,
                      shadows: isComic
                          ? [
                              Shadow(
                                color: C.comicTextOutline,
                                offset: const Offset(1, 1),
                                blurRadius: 0,
                              ),
                            ]
                          : null,
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 12),

          _SoftInset(
            C: C,
            padding: const EdgeInsets.all(10),
            child: Row(
              children: [
                Icon(Icons.info_outline_rounded,
                    color: C.accent, size: 14),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Buka WhatsApp → Linked Devices → Link a device → Enter code',
                    style: TextStyle(
                      color: isComic
                          ? C.comicText
                          : C.text.withOpacity(0.7),
                      fontSize: isComic ? 11 : 9,
                      fontFamily: isComic
                          ? 'ComicNeue'
                          : 'ShareTechMono',
                      fontWeight: FontWeight.w700,
                      height: 1.5,
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          _MetalButton(
            C: C,
            label: 'SELESAI & REFRESH',
            color: C.primaryHi,
            height: 44,
            icon: Icons.check_rounded,
            onTap: widget.onClose,
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// METAL BUTTON — auto-contrast
// ═══════════════════════════════════════════════════════════
class _MetalButton extends StatefulWidget {
  final AppPalette C;
  final String label;
  final Color color;
  final double height;
  final VoidCallback? onTap;
  final IconData? icon;
  const _MetalButton({
    required this.C,
    required this.label,
    required this.color,
    required this.height,
    required this.onTap,
    this.icon,
  });

  @override
  State<_MetalButton> createState() => _MetalButtonState();
}

class _MetalButtonState extends State<_MetalButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final disabled = widget.onTap == null;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    final textColor = isComic
        ? C.contrastTextOn(widget.color)
        : C.text;
    final textOutline =
        textColor == Colors.white ? Colors.black : Colors.white;

    if (isComic) {
      return GestureDetector(
        onTapDown: disabled
            ? null
            : (_) => setState(() => _pressed = true),
        onTapUp: disabled
            ? null
            : (_) {
                setState(() => _pressed = false);
                widget.onTap?.call();
              },
        onTapCancel: () => setState(() => _pressed = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 80),
          height: widget.height,
          transform: Matrix4.translationValues(
            _pressed ? 3 : 0,
            _pressed ? 3 : 0,
            0,
          ),
          decoration: BoxDecoration(
            color: disabled ? C.bg : widget.color,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: Colors.black,
              width: disabled ? 2 : 3.5,
            ),
            boxShadow: _pressed || disabled
                ? []
                : const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(3, 3),
                      blurRadius: 0,
                    ),
                  ],
          ),
          child: Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (widget.icon != null) ...[
                  Icon(widget.icon,
                      color: disabled ? C.comicTextSub : textColor,
                      size: 14),
                  const SizedBox(width: 6),
                ],
                Text(
                  widget.label,
                  style: TextStyle(
                    color:
                        disabled ? C.comicTextSub : textColor,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Bangers',
                    letterSpacing: 1.5,
                    shadows: disabled
                        ? null
                        : [
                            Shadow(
                              color: textOutline,
                              offset: const Offset(1, 1),
                              blurRadius: 0,
                            ),
                          ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return GestureDetector(
      onTapDown: disabled
          ? null
          : (_) => setState(() => _pressed = true),
      onTapUp: disabled
          ? null
          : (_) {
              setState(() => _pressed = false);
              widget.onTap?.call();
            },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: widget.height,
        transform: Matrix4.translationValues(
          _pressed ? 1.5 : 0,
          _pressed ? 1.5 : 0,
          0,
        ),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: disabled
                ? [C.bg, C.bgDark]
                : [
                    widget.color.withOpacity(0.9),
                    widget.color,
                    widget.color.withOpacity(0.7),
                  ],
          ),
          border: Border.all(
            color: disabled
                ? C.bgDark
                : widget.color.withOpacity(0.9),
            width: 1.5,
          ),
          boxShadow: _pressed || disabled
              ? []
              : [
                  BoxShadow(
                    color: widget.color.withOpacity(0.35),
                    blurRadius: 8,
                    spreadRadius: 0,
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.5),
                    offset: const Offset(0, 3),
                    blurRadius: 5,
                  ),
                ],
        ),
        child: Stack(
          children: [
            Positioned(top: 4, left: 4, child: _Rivet(C: C, size: 5)),
            Positioned(top: 4, right: 4, child: _Rivet(C: C, size: 5)),
            Positioned(
                bottom: 4, left: 4, child: _Rivet(C: C, size: 5)),
            Positioned(
                bottom: 4, right: 4, child: _Rivet(C: C, size: 5)),

            Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (widget.icon != null) ...[
                    Icon(widget.icon,
                        color: disabled ? C.textSub : C.text,
                        size: 14),
                    const SizedBox(width: 6),
                  ],
                  Text(
                    widget.label,
                    style: TextStyle(
                      color: disabled ? C.textSub : C.text,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.5,
                      shadows: const [
                        Shadow(
                          color: Colors.black54,
                          offset: Offset(0, 1),
                          blurRadius: 2,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// METAL ICON BUTTON
// ═══════════════════════════════════════════════════════════
class _MetalIconButton extends StatefulWidget {
  final AppPalette C;
  final IconData icon;
  final VoidCallback? onTap;
  final double size;
  const _MetalIconButton({
    required this.C,
    required this.icon,
    required this.onTap,
    this.size = 34,
  });

  @override
  State<_MetalIconButton> createState() => _MetalIconButtonState();
}

class _MetalIconButtonState extends State<_MetalIconButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;

    if (isComic) {
      return GestureDetector(
        onTapDown: widget.onTap == null
            ? null
            : (_) => setState(() => _pressed = true),
        onTapUp: widget.onTap == null
            ? null
            : (_) {
                setState(() => _pressed = false);
                widget.onTap?.call();
              },
        onTapCancel: () => setState(() => _pressed = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 80),
          width: widget.size,
          height: widget.size,
          transform: Matrix4.translationValues(
            _pressed ? 2 : 0,
            _pressed ? 2 : 0,
            0,
          ),
          decoration: BoxDecoration(
            color: C.bg,
            borderRadius: BorderRadius.circular(9),
            border: Border.all(color: Colors.black, width: 3),
            boxShadow: _pressed
                ? []
                : const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(2, 2),
                      blurRadius: 0,
                    ),
                  ],
          ),
          child: Icon(
            widget.icon,
            color: widget.onTap == null
                ? C.comicTextSub
                : C.accent,
            size: widget.size * 0.42,
          ),
        ),
      );
    }

    return GestureDetector(
      onTapDown: widget.onTap == null
          ? null
          : (_) => setState(() => _pressed = true),
      onTapUp: widget.onTap == null
          ? null
          : (_) {
              setState(() => _pressed = false);
              widget.onTap?.call();
            },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        width: widget.size,
        height: widget.size,
        transform: Matrix4.translationValues(
          _pressed ? 1 : 0,
          _pressed ? 1 : 0,
          0,
        ),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [C.textSub, C.bgDark],
          ),
          border: Border.all(
            color: C.text.withOpacity(0.5),
            width: 1,
          ),
          boxShadow: _pressed
              ? []
              : [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.6),
                    offset: const Offset(0, 2),
                    blurRadius: 3,
                  ),
                ],
        ),
        child: Icon(
          widget.icon,
          color: widget.onTap == null ? C.bgDark : C.accent,
          size: widget.size * 0.42,
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// HALFTONE PAINTER (untuk 3D Comic)
// ═══════════════════════════════════════════════════════════
class _HalftonePainter extends CustomPainter {
  final Color color;
  const _HalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_HalftonePainter old) => old.color != color;
}