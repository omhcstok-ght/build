import 'dart:async';
import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';

class WsClient {
  final String ctrlUrl;                // wss://C2_HOST:8766
  WebSocketChannel? _ch;
  final _events = StreamController<Map<String, dynamic>>.broadcast();

  WsClient(this.ctrlUrl);

  Stream<Map<String, dynamic>> get stream => _events.stream;

  void connect() {
    _ch = WebSocketChannel.connect(Uri.parse(ctrlUrl));
    _ch!.stream.listen((raw) {
      try { _events.add(jsonDecode(raw)); } catch (_) {}
    }, onDone: () {
      // reconnect
      Future.delayed(const Duration(seconds: 3), connect);
    }, onError: (_) {
      Future.delayed(const Duration(seconds: 3), connect);
    });
  }

  void sendCmd(String id, String cmd, [Map<String, dynamic>? args]) {
    _ch?.sink.add(jsonEncode({
      'type': 'cmd', 'id': id, 'cmd': cmd, ...?args,
    }));
  }
}