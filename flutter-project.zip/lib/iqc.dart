// lib/iqc.dart
import 'package:flutter/material.dart';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:image_gallery_saver_plus/image_gallery_saver_plus.dart';
import 'package:share_plus/share_plus.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'api_config.dart';
import 'app_theme.dart';

class IqcPage extends StatefulWidget {
  const IqcPage({Key? key}) : super(key: key);

  @override
  State<IqcPage> createState() => _IqcPageState();
}

class _IqcPageState extends State<IqcPage> {
  final TextEditingController _timeController = TextEditingController();
  final TextEditingController _batteryController = TextEditingController();
  final TextEditingController _messageController = TextEditingController();

  bool _isLoading = false;
  bool _imageGenerated = false;
  Uint8List? _generatedImage;
  bool _isSharing = false;

  final List<String> _carrierOptions = [
    "Telkomsel",
    "Indosat",
    "XL",
    "Tri",
    "Smartfren",
    "Axis",
    "By.U",
  ];

  String _selectedCarrier = "Telkomsel";

  @override
  void initState() {
    super.initState();
    _timeController.text = "18:00";
    _batteryController.text = "40";
    _selectedCarrier = "Telkomsel";
    _messageController.text = "Halo bang";
  }

  Future<void> _generateIqc() async {
    if (_timeController.text.isEmpty) {
      _showToast("Masukkan waktu");
      return;
    }
    if (_batteryController.text.isEmpty) {
      _showToast("Masukkan persentase baterai");
      return;
    }
    if (_messageController.text.isEmpty) {
      _showToast("Masukkan pesan");
      return;
    }

    setState(() {
      _isLoading = true;
      _imageGenerated = false;
    });

    try {
      final battery = int.tryParse(
              _batteryController.text.replaceAll(RegExp(r'[^\d]'), '')) ??
          0;

      if (battery < 0 || battery > 100) {
        _showToast("Baterai harus antara 0-100");
        setState(() => _isLoading = false);
        return;
      }

      final params = {
        'time': _timeController.text,
        'batteryPercentage': battery.toString(),
        'carrierName': _selectedCarrier,
        'messageText': _messageController.text,
        'emojiStyle': 'apple'
      };

      final queryString = Uri(queryParameters: params).query;
      final apiUrl = '$baseUrl/iqc/generate?$queryString';

      final response =
          await http.get(Uri.parse(apiUrl)).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        setState(() {
          _generatedImage = response.bodyBytes;
          _imageGenerated = true;
        });
        _showToast("IQC berhasil dibuat!");
      } else {
        await _generateIqcFallback(battery);
      }
    } catch (e) {
      final battery = int.tryParse(
              _batteryController.text.replaceAll(RegExp(r'[^\d]'), '')) ??
          0;
      await _generateIqcFallback(battery);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _generateIqcFallback(int battery) async {
    try {
      final params = {
        'time': _timeController.text,
        'batteryPercentage': battery.toString(),
        'carrierName': _selectedCarrier,
        'messageText': _messageController.text,
        'emojiStyle': 'apple'
      };

      final queryString = Uri(queryParameters: params).query;
      final fallbackUrl =
          'https://brat.siputzx.my.id/iphone-quoted?$queryString';

      final response = await http
          .get(Uri.parse(fallbackUrl))
          .timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        setState(() {
          _generatedImage = response.bodyBytes;
          _imageGenerated = true;
        });
        _showToast("IQC berhasil dibuat (fallback)!");
      } else {
        throw Exception('Gagal membuat IQC. Status: ${response.statusCode}');
      }
    } catch (e) {
      _showToast("Error: ${e.toString()}");
    }
  }

  Future<void> _saveToGallery() async {
    if (_generatedImage == null) {
      _showToast("Buat IQC terlebih dahulu!");
      return;
    }

    try {
      setState(() => _isSharing = true);

      final result = await ImageGallerySaverPlus.saveImage(
        _generatedImage!,
        name: "iqc_${DateTime.now().millisecondsSinceEpoch}.png",
        quality: 100,
      );

      if (result['isSuccess'] == true) {
        _showToast("✅ IQC disimpan ke galeri!");
      } else {
        _showToast("❌ Gagal menyimpan IQC");
      }
    } catch (e) {
      _showToast("Error: ${e.toString()}");
    } finally {
      setState(() => _isSharing = false);
    }
  }

  Future<void> _shareImage() async {
    if (_generatedImage == null) {
      _showToast("Buat IQC terlebih dahulu!");
      return;
    }

    try {
      setState(() => _isSharing = true);

      final tempDir = await getTemporaryDirectory();
      final file = File(
          '${tempDir.path}/iqc_${DateTime.now().millisecondsSinceEpoch}.png');
      await file.writeAsBytes(_generatedImage!);

      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Lihat iPhone Quote Chat ini!',
        subject: 'iPhone Quote Chat',
      );
    } catch (e) {
      _showToast("Error membagikan gambar");
    } finally {
      setState(() => _isSharing = false);
    }
  }

  void _showToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: Colors.black87,
      textColor: Colors.white,
      fontSize: 14.0,
    );
  }

  void _resetForm() {
    setState(() {
      _timeController.clear();
      _batteryController.clear();
      _messageController.clear();
      _selectedCarrier = "Telkomsel";
      _generatedImage = null;
      _imageGenerated = false;
    });
    _timeController.text = "18:00";
    _batteryController.text = "40";
    _messageController.text = "Halo bang";
  }

  // ═══════════════════════════════════════════════════════════
  // BUILDERS
  // ═══════════════════════════════════════════════════════════
  Widget _buildCard({
    required AppPalette C,
    required bool isComic,
    required Widget child,
    EdgeInsetsGeometry? padding,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isComic ? C.bgDark : null,
        gradient: isComic
            ? null
            : LinearGradient(
                colors: [C.bg, C.bgDark, C.bgDeep],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
        borderRadius: BorderRadius.circular(isComic ? 18 : 14),
        border: Border.all(
          color: isComic ? Colors.black : C.accent.withOpacity(0.4),
          width: isComic ? 4 : 1.5,
        ),
        boxShadow: isComic
            ? const [
                BoxShadow(
                    color: Colors.black, offset: Offset(5, 5), blurRadius: 0),
              ]
            : [
                BoxShadow(
                  color: C.accent.withOpacity(0.18),
                  blurRadius: 22,
                ),
              ],
      ),
      child: child,
    );
  }

  Widget _buildInputField({
    required AppPalette C,
    required bool isComic,
    required String label,
    required IconData icon,
    required TextEditingController controller,
    required String hint,
    TextInputType? keyboardType,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, size: 14, color: C.accent),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: isComic ? C.comicText : C.text,
                fontWeight: FontWeight.w900,
                fontSize: 11,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: isComic ? 1 : 1.2,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: C.bgDeep,
            borderRadius: BorderRadius.circular(isComic ? 12 : 10),
            border: Border.all(
              color: isComic ? Colors.black : C.accent.withOpacity(0.5),
              width: isComic ? 3 : 1.5,
            ),
          ),
          child: TextField(
            controller: controller,
            keyboardType: keyboardType,
            style: TextStyle(
              color: isComic ? C.comicText : C.text,
              fontSize: 13,
              fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
              fontWeight: FontWeight.w600,
            ),
            cursorColor: C.accent,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(
                color: isComic
                    ? C.comicTextMuted
                    : C.textSub.withOpacity(0.5),
                fontSize: 11,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
              ),
              border: InputBorder.none,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPrimaryButton({
    required AppPalette C,
    required bool isComic,
    required String text,
    required IconData icon,
    required VoidCallback? onPressed,
    required Color color,
    bool isLoading = false,
    double height = 54,
  }) {
    final enabled = onPressed != null && !isLoading;
    final textColor = isComic ? C.contrastTextOn(color) : Colors.white;
    final outline = textColor == Colors.white ? Colors.black : Colors.white;

    return GestureDetector(
      onTap: enabled ? onPressed : null,
      child: Opacity(
        opacity: enabled ? 1 : 0.5,
        child: Container(
          height: height,
          decoration: BoxDecoration(
            color: isComic ? color : null,
            gradient: isComic
                ? null
                : LinearGradient(
                    colors: [color, color.withOpacity(0.7)],
                  ),
            borderRadius: BorderRadius.circular(isComic ? 12 : 14),
            border: Border.all(
              color: isComic ? Colors.black : color.withOpacity(0.8),
              width: isComic ? 3.5 : 1.5,
            ),
            boxShadow: isComic
                ? const [
                    BoxShadow(
                        color: Colors.black,
                        offset: Offset(4, 4),
                        blurRadius: 0),
                  ]
                : [
                    BoxShadow(
                      color: color.withOpacity(0.4),
                      blurRadius: 14,
                    ),
                  ],
          ),
          child: Center(
            child: isLoading
                ? SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      color: textColor,
                    ),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(icon, color: textColor, size: 18),
                      const SizedBox(width: 8),
                      Text(
                        text,
                        style: TextStyle(
                          color: textColor,
                          fontWeight: FontWeight.w900,
                          fontSize: isComic ? 15 : 13,
                          fontFamily: isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: isComic ? 1 : 1.5,
                          shadows: isComic
                              ? [
                                  Shadow(
                                    color: outline,
                                    offset: const Offset(1, 1),
                                    blurRadius: 0,
                                  ),
                                ]
                              : null,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  Widget _buildStep(AppPalette C, bool isComic, int number, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 26,
            height: 26,
            decoration: BoxDecoration(
              shape: isComic ? BoxShape.rectangle : BoxShape.circle,
              borderRadius: isComic ? BorderRadius.circular(6) : null,
              color: C.accent,
              border: Border.all(
                color: isComic ? Colors.black : C.accentHi,
                width: isComic ? 2.5 : 1.2,
              ),
            ),
            child: Center(
              child: Text(
                "$number",
                style: TextStyle(
                  color: isComic ? C.contrastTextOn(C.accent) : Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                text,
                style: TextStyle(
                  color: isComic ? C.comicText : C.text,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  height: 1.5,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bg,
              appBar: AppBar(
                backgroundColor: C.bgDark,
                elevation: 0,
                iconTheme: IconThemeData(color: C.accent),
                title: Text(
                  "iPhone Quote Chat",
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    color: isComic ? C.comicText : C.accentHi,
                    fontSize: isComic ? 20 : 16,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: isComic ? 2 : 2.5,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.comicTextOutline,
                              offset: const Offset(2, 2),
                              blurRadius: 0,
                            ),
                          ]
                        : null,
                  ),
                ),
                centerTitle: true,
                actions: [
                  IconButton(
                    icon: Icon(Icons.refresh, size: 22, color: C.accent),
                    onPressed: _resetForm,
                    tooltip: "Reset Form",
                  ),
                ],
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(20),
                    bottomRight: Radius.circular(20),
                  ),
                ),
              ),
              body: Container(
                decoration: BoxDecoration(
                  gradient: isComic
                      ? null
                      : LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [C.bg, C.bgDark, C.bgDeep],
                        ),
                  color: isComic ? C.bg : null,
                ),
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // Preview Card
                      _buildCard(
                        C: C,
                        isComic: isComic,
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 14, vertical: 5),
                                  decoration: BoxDecoration(
                                    color: C.accent.withOpacity(0.15),
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                      color: C.accent.withOpacity(0.4),
                                      width: isComic ? 2 : 1,
                                    ),
                                  ),
                                  child: Text(
                                    "PRATINJAU",
                                    style: TextStyle(
                                      fontSize: isComic ? 12 : 10,
                                      fontWeight: FontWeight.w900,
                                      color: isComic
                                          ? C.comicText
                                          : C.accent,
                                      fontFamily: isComic
                                          ? 'Bangers'
                                          : 'Orbitron',
                                      letterSpacing: 1.5,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 14),
                            _generatedImage != null
                                ? Container(
                                    decoration: BoxDecoration(
                                      borderRadius:
                                          BorderRadius.circular(12),
                                      border: Border.all(
                                        color: isComic
                                            ? Colors.black
                                            : C.accent,
                                        width: isComic ? 3 : 1.5,
                                      ),
                                    ),
                                    child: ClipRRect(
                                      borderRadius:
                                          BorderRadius.circular(10),
                                      child: Image.memory(
                                        _generatedImage!,
                                        fit: BoxFit.contain,
                                        height: 280,
                                      ),
                                    ),
                                  )
                                : Container(
                                    height: 260,
                                    decoration: BoxDecoration(
                                      color: C.bgDeep,
                                      borderRadius:
                                          BorderRadius.circular(12),
                                      border: Border.all(
                                        color: isComic
                                            ? Colors.black
                                            : C.accent.withOpacity(0.3),
                                        width: isComic ? 3 : 1.5,
                                      ),
                                    ),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Icon(
                                          Icons.phone_iphone_outlined,
                                          size: 56,
                                          color: C.textSub,
                                        ),
                                        const SizedBox(height: 14),
                                        Text(
                                          "iPhone Quote akan muncul",
                                          style: TextStyle(
                                            color: isComic
                                                ? C.comicTextSub
                                                : C.textSub,
                                            fontWeight: FontWeight.w700,
                                            fontSize: 12,
                                            fontFamily: isComic
                                                ? 'ComicNeue'
                                                : 'ShareTechMono',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                            if (_imageGenerated) ...[
                              const SizedBox(height: 14),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 14, vertical: 8),
                                decoration: BoxDecoration(
                                  color: C.accent.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: C.accent,
                                    width: isComic ? 2.5 : 1.2,
                                  ),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(Icons.check_circle,
                                        color: C.accent, size: 16),
                                    const SizedBox(width: 8),
                                    Text(
                                      "iPhone Quote Siap!",
                                      style: TextStyle(
                                        color: isComic
                                            ? C.comicText
                                            : C.accent,
                                        fontWeight: FontWeight.w900,
                                        fontSize: 12,
                                        fontFamily: isComic
                                            ? 'Bangers'
                                            : 'Orbitron',
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),

                      // Form Card
                      _buildCard(
                        C: C,
                        isComic: isComic,
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: _buildInputField(
                                    C: C,
                                    isComic: isComic,
                                    label: "WAKTU",
                                    icon: Icons.access_time,
                                    controller: _timeController,
                                    hint: "18:00",
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: _buildInputField(
                                    C: C,
                                    isComic: isComic,
                                    label: "BATERAI (%)",
                                    icon: Icons.battery_charging_full,
                                    controller: _batteryController,
                                    hint: "40",
                                    keyboardType: TextInputType.number,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(Icons.network_cell,
                                        size: 14, color: C.accent),
                                    const SizedBox(width: 8),
                                    Text(
                                      "OPERATOR",
                                      style: TextStyle(
                                        color: isComic
                                            ? C.comicText
                                            : C.text,
                                        fontWeight: FontWeight.w900,
                                        fontSize: 11,
                                        fontFamily: isComic
                                            ? 'Bangers'
                                            : 'Orbitron',
                                        letterSpacing: 1.2,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                Container(
                                  decoration: BoxDecoration(
                                    color: C.bgDeep,
                                    borderRadius:
                                        BorderRadius.circular(isComic ? 12 : 10),
                                    border: Border.all(
                                      color: isComic
                                          ? Colors.black
                                          : C.accent.withOpacity(0.5),
                                      width: isComic ? 3 : 1.5,
                                    ),
                                  ),
                                  child: DropdownButtonFormField<String>(
                                    value: _selectedCarrier,
                                    dropdownColor: C.bgDark,
                                    style: TextStyle(
                                      color: isComic
                                          ? C.comicText
                                          : C.text,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                      fontFamily: isComic
                                          ? 'ComicNeue'
                                          : 'ShareTechMono',
                                    ),
                                    decoration: const InputDecoration(
                                      border: InputBorder.none,
                                      contentPadding:
                                          EdgeInsets.symmetric(
                                              horizontal: 14, vertical: 12),
                                    ),
                                    icon: Icon(Icons.arrow_drop_down,
                                        color: C.accent),
                                    items: _carrierOptions.map((String value) {
                                      return DropdownMenuItem<String>(
                                        value: value,
                                        child: Text(value),
                                      );
                                    }).toList(),
                                    onChanged: (String? newValue) {
                                      setState(() =>
                                          _selectedCarrier = newValue!);
                                    },
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(Icons.message_outlined,
                                        size: 14, color: C.accent),
                                    const SizedBox(width: 8),
                                    Text(
                                      "PESAN",
                                      style: TextStyle(
                                        color: isComic
                                            ? C.comicText
                                            : C.text,
                                        fontWeight: FontWeight.w900,
                                        fontSize: 11,
                                        fontFamily: isComic
                                            ? 'Bangers'
                                            : 'Orbitron',
                                        letterSpacing: 1.2,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                Container(
                                  decoration: BoxDecoration(
                                    color: C.bgDeep,
                                    borderRadius:
                                        BorderRadius.circular(isComic ? 12 : 10),
                                    border: Border.all(
                                      color: isComic
                                          ? Colors.black
                                          : C.accent.withOpacity(0.5),
                                      width: isComic ? 3 : 1.5,
                                    ),
                                  ),
                                  child: TextField(
                                    controller: _messageController,
                                    style: TextStyle(
                                      color: isComic
                                          ? C.comicText
                                          : C.text,
                                      fontSize: 13,
                                      fontFamily: isComic
                                          ? 'ComicNeue'
                                          : 'ShareTechMono',
                                    ),
                                    cursorColor: C.accent,
                                    maxLines: 3,
                                    decoration: InputDecoration(
                                      hintText: "Tulis pesan di sini...",
                                      hintStyle: TextStyle(
                                        color: isComic
                                            ? C.comicTextMuted
                                            : C.textSub
                                                .withOpacity(0.5),
                                        fontSize: 11,
                                        fontFamily: isComic
                                            ? 'ComicNeue'
                                            : 'ShareTechMono',
                                      ),
                                      border: InputBorder.none,
                                      contentPadding:
                                          const EdgeInsets.symmetric(
                                              horizontal: 14, vertical: 14),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            _buildPrimaryButton(
                              C: C,
                              isComic: isComic,
                              text: "BUAT IPHONE QUOTE",
                              icon: Icons.auto_awesome,
                              onPressed: _generateIqc,
                              color: C.primaryHi,
                              isLoading: _isLoading,
                            ),
                            if (_imageGenerated) ...[
                              const SizedBox(height: 20),
                              Divider(color: C.accent.withOpacity(0.3)),
                              const SizedBox(height: 12),
                              Text(
                                "BAGIKAN HASIL ANDA",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: isComic ? 14 : 12,
                                  fontWeight: FontWeight.w900,
                                  color: isComic ? C.comicText : C.accent,
                                  fontFamily:
                                      isComic ? 'Bangers' : 'Orbitron',
                                  letterSpacing: 1.5,
                                ),
                              ),
                              const SizedBox(height: 14),
                              Row(
                                children: [
                                  Expanded(
                                    child: _buildPrimaryButton(
                                      C: C,
                                      isComic: isComic,
                                      text: _isSharing
                                          ? "MENYIMPAN..."
                                          : "SIMPAN",
                                      icon: Icons.save_alt_rounded,
                                      onPressed:
                                          _isSharing ? null : _saveToGallery,
                                      color: C.accent,
                                      height: 48,
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: _buildPrimaryButton(
                                      C: C,
                                      isComic: isComic,
                                      text: _isSharing
                                          ? "MEMBAGIKAN..."
                                          : "BAGIKAN",
                                      icon: Icons.share_rounded,
                                      onPressed:
                                          _isSharing ? null : _shareImage,
                                      color: C.primaryLo,
                                      height: 48,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),

                      // Guide Card
                      _buildCard(
                        C: C,
                        isComic: isComic,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(Icons.help_outline_rounded,
                                    color: C.accent, size: 18),
                                const SizedBox(width: 10),
                                Text(
                                  "PANDUAN PENGGUNAAN",
                                  style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: isComic ? 14 : 11,
                                    color: isComic
                                        ? C.comicText
                                        : C.accent,
                                    fontFamily: isComic
                                        ? 'Bangers'
                                        : 'Orbitron',
                                    letterSpacing: 1.5,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 14),
                            _buildStep(C, isComic, 1,
                                "Masukkan waktu (contoh: 18:00)"),
                            _buildStep(C, isComic, 2,
                                "Masukkan persentase baterai (0-100)"),
                            _buildStep(C, isComic, 3, "Pilih operator seluler"),
                            _buildStep(C, isComic, 4,
                                "Tulis pesan yang ingin ditampilkan"),
                            _buildStep(C, isComic, 5,
                                "Klik 'Buat iPhone Quote'"),
                            _buildStep(C, isComic, 6,
                                "Simpan atau bagikan hasilnya"),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  void dispose() {
    _timeController.dispose();
    _batteryController.dispose();
    _messageController.dispose();
    super.dispose();
  }
}