// pintu_page.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_theme.dart';
import 'verified_slides.dart';

class PintuPage extends StatefulWidget {
  const PintuPage({super.key});

  @override
  State<PintuPage> createState() => _PintuPageState();
}

class _PintuPageState extends State<PintuPage>
    with TickerProviderStateMixin {
  final Duration _holdDuration = const Duration(milliseconds: 1500);
  Timer? _progressTimer;
  double _progress = 0.0;
  bool _isPressing = false;
  bool _isSuccess = false;

  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;
  late AnimationController _scanCtrl;
  late Animation<double> _scanAnim;
  late AnimationController _glowCtrl;
  late Animation<double> _glowAnim;

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.4, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    _scanCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat();
    _scanAnim = Tween<double>(begin: -0.6, end: 1.2).animate(
      CurvedAnimation(parent: _scanCtrl, curve: Curves.linear),
    );

    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.35, end: 0.85).animate(
      CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _progressTimer?.cancel();
    _pulseCtrl.dispose();
    _scanCtrl.dispose();
    _glowCtrl.dispose();
    super.dispose();
  }

  // ══════════════════════════════════════════════════════════════
  //  PRESS HANDLERS
  // ══════════════════════════════════════════════════════════════
  void _startPress() {
    if (_isPressing || _isSuccess) return;

    setState(() {
      _isPressing = true;
      _progress = 0.0;
    });
    HapticFeedback.mediumImpact();

    const tick = Duration(milliseconds: 16);
    final totalTicks = _holdDuration.inMilliseconds / tick.inMilliseconds;
    double currentTick = 0;

    _progressTimer = Timer.periodic(tick, (timer) {
      currentTick++;
      setState(() {
        _progress = currentTick / totalTicks;
      });

      if (_progress >= 1.0) {
        timer.cancel();
        _onVerificationSuccess();
      }
    });
  }

  void _cancelPress() {
    if (!_isPressing) return;

    _progressTimer?.cancel();
    setState(() {
      _isPressing = false;
      _progress = 0.0;
    });
    HapticFeedback.lightImpact();
  }

  void _onVerificationSuccess() {
    HapticFeedback.heavyImpact();
    setState(() {
      _isPressing = false;
      _isSuccess = true;
    });

    Future.delayed(const Duration(milliseconds: 700), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        PageRouteBuilder(
          pageBuilder: (context, animation, secondaryAnimation) =>
              const VerifiedSlidesPage(
            username: '',
            password: '',
            role: '',
            sessionKey: '',
            expiredDate: '',
            listBug: [],
            listDoos: [],
            news: [],
          ),
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            return FadeTransition(
              opacity: CurvedAnimation(
                parent: animation,
                curve: Curves.easeInOut,
              ),
              child: child,
            );
          },
          transitionDuration: const Duration(milliseconds: 800),
        ),
      );
    });
  }

  void _exitApp() {
    HapticFeedback.heavyImpact();
    SystemNavigator.pop();
  }

  // ══════════════════════════════════════════════════════════════
  //  BUILD
  // ══════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return StyleBuilder(
      builder: (context, C, kit) {
        final isComic = kit.style == ThemeStyle.comic3d;
        final int percentage = (_progress * 100).toInt();

        // ✅ Pake extension AdaptiveStyle biar aman
        final txtMain = C.txtMain(isComic);
        final txtSub = C.txtSub2(isComic);
        final fontMain = C.font(isComic);
        final fontSub = C.fontSub(isComic);

        final scanColor = isComic ? C.primaryHi : C.accent;
        final idleColor = isComic ? C.primaryHi : C.accent;
        final pressColor = isComic ? C.primaryHi : C.accent;
        final successColor = C.primaryHi;

        final activeColor = _isSuccess
            ? successColor
            : (_isPressing ? pressColor : idleColor);

        return Scaffold(
          backgroundColor: C.bgDeep,
          body: Stack(
            children: [
              // ── Background ──
              Positioned.fill(
                child: isComic
                    ? CustomPaint(
                        painter: _PintuHalftonePainter(
                            color: C.primaryLo.withOpacity(0.12)),
                      )
                    : Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [C.bg, C.bgDark, C.bgDeep],
                          ),
                        ),
                      ),
              ),

              // ── Grid (non-comic) ──
              if (!isComic)
                Positioned.fill(
                  child: CustomPaint(
                    painter: _PintuGridPainter(color: C.accent),
                  ),
                ),

              // ── Glow orbs ──
              Positioned(
                top: -120,
                left: -80,
                child: _glowOrb(
                  280,
                  scanColor.withOpacity(0.14),
                ),
              ),
              Positioned(
                bottom: -150,
                right: -90,
                child: _glowOrb(
                  320,
                  pressColor.withOpacity(0.10),
                ),
              ),

              // ── Main content ──
              SafeArea(
                child: Column(
                  children: [
                    _buildHeader(C, isComic, txtMain, txtSub, fontMain),
                    Expanded(
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              isComic
                                  ? 'VERIFIKASI SISTEM'
                                  : 'SYSTEM VERIFICATION',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontFamily: fontMain,
                                fontSize: isComic ? 26 : 18,
                                fontWeight: FontWeight.w900,
                                color: txtMain,
                                letterSpacing: isComic ? 3 : 4,
                                shadows: isComic
                                    ? [
                                        Shadow(
                                          color: C.comicTextOutline,
                                          offset: const Offset(2, 2),
                                          blurRadius: 0,
                                        ),
                                      ]
                                    : [
                                        Shadow(
                                          color: C.accent
                                              .withOpacity(0.5),
                                          blurRadius: 12,
                                        ),
                                      ],
                              ),
                            ),
                            const SizedBox(height: 6),
                            Container(
                              width: 60,
                              height: 2,
                              decoration: BoxDecoration(
                                color: isComic
                                    ? txtMain
                                    : C.accent,
                                borderRadius: BorderRadius.circular(2),
                                boxShadow: [
                                  BoxShadow(
                                    color: scanColor.withOpacity(0.6),
                                    blurRadius: 8,
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              'Tekan & tahan sampai 100%',
                              style: TextStyle(
                                fontFamily: fontSub,
                                fontSize: isComic ? 13 : 12,
                                color: txtSub,
                                letterSpacing: 0.5,
                              ),
                            ),
                            const SizedBox(height: 50),
                            _buildFingerprintRing(
                                C, isComic, percentage, activeColor,
                                txtMain, fontMain),
                            const SizedBox(height: 40),
                            _buildStatusPill(C, isComic, txtMain, fontMain),
                          ],
                        ),
                      ),
                    ),
                    _buildCancelButton(C, isComic, txtMain, fontMain),
                    const SizedBox(height: 30),
                  ],
                ),
              ),

              // ── Scan line ──
              if (_isPressing)
                Positioned.fill(
                  child: IgnorePointer(
                    child: AnimatedBuilder(
                      animation: _scanAnim,
                      builder: (_, __) => Align(
                        alignment: Alignment(0, _scanAnim.value),
                        child: Container(
                          height: 2,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.transparent,
                                scanColor.withOpacity(0.7),
                                scanColor,
                                scanColor.withOpacity(0.7),
                                Colors.transparent,
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  // ══════════════════════════════════════════════════════════════
  //  HEADER
  // ══════════════════════════════════════════════════════════════
  Widget _buildHeader(
    AppPalette C,
    bool isComic,
    Color txtMain,
    Color txtSub,
    String fontMain,
  ) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      child: Row(
        children: [
          GestureDetector(
            onTap: _exitApp,
            child: Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: isComic ? C.bgDark : C.bgDark.withOpacity(0.7),
                borderRadius: BorderRadius.circular(isComic ? 10 : 12),
                border: Border.all(
                  color: isComic
                      ? Colors.black
                      : C.accent.withOpacity(0.4),
                  width: isComic ? 3 : 1.5,
                ),
                boxShadow: isComic
                    ? const [
                        BoxShadow(
                          color: Colors.black,
                          offset: Offset(3, 3),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
              child: Icon(
                Icons.arrow_back_ios_new,
                color: isComic ? txtMain : C.accent,
                size: 18,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isComic ? 'SYAX • GERBANG' : 'SYAX • GATEWAY',
                  style: TextStyle(
                    fontFamily: fontMain,
                    fontSize: isComic ? 15 : 13,
                    fontWeight: FontWeight.w900,
                    color: isComic ? txtMain : C.accent,
                    letterSpacing: 2,
                  ),
                ),
                Text(
                  'Bio-metric entry',
                  style: TextStyle(
                    fontFamily: fontMain,
                    fontSize: 10,
                    color: txtSub,
                  ),
                ),
              ],
            ),
          ),
          AnimatedBuilder(
            animation: _pulseAnim,
            builder: (_, __) => Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: isComic ? C.bgDark : C.bgDark.withOpacity(0.7),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: isComic
                      ? Colors.black
                      : C.accent.withOpacity(0.3),
                  width: isComic ? 2 : 1,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 7,
                    height: 7,
                    decoration: BoxDecoration(
                      color: isComic ? C.primaryHi : C.accent,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: (isComic ? C.primaryHi : C.accent)
                              .withOpacity(_pulseAnim.value * 0.7),
                          blurRadius: 8,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    'SECURE',
                    style: TextStyle(
                      fontFamily: fontMain,
                      fontSize: 9,
                      color: isComic ? txtMain : C.accent,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════
  //  FINGERPRINT RING
  // ══════════════════════════════════════════════════════════════
  Widget _buildFingerprintRing(
    AppPalette C,
    bool isComic,
    int percentage,
    Color activeColor,
    Color txtMain,
    String fontMain,
  ) {
    return GestureDetector(
      onTapDown: (_) => _startPress(),
      onTapUp: (_) => _cancelPress(),
      onTapCancel: () => _cancelPress(),
      child: AnimatedBuilder(
        animation: _glowAnim,
        builder: (_, __) {
          return Stack(
            alignment: Alignment.center,
            children: [
              Container(
                width: 260,
                height: 260,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      activeColor.withOpacity(0.15 * _glowAnim.value),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
              SizedBox(
                width: 240,
                height: 240,
                child: CustomPaint(
                  painter: _DashedCirclePainter(
                    color: activeColor.withOpacity(0.25),
                    strokeWidth: isComic ? 2 : 1.2,
                  ),
                ),
              ),
              Container(
                width: 210,
                height: 210,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isComic ? C.bgDark : C.bgDark.withOpacity(0.6),
                  border: Border.all(
                    color: isComic
                        ? Colors.black
                        : activeColor.withOpacity(0.25),
                    width: isComic ? 4 : 1.5,
                  ),
                  boxShadow: isComic
                      ? const [
                          BoxShadow(
                            color: Colors.black,
                            offset: Offset(6, 6),
                            blurRadius: 0,
                          ),
                        ]
                      : [
                          BoxShadow(
                            color: activeColor.withOpacity(0.18),
                            blurRadius: 25,
                            spreadRadius: 3,
                          ),
                        ],
                ),
              ),
              SizedBox(
                width: 210,
                height: 210,
                child: CircularProgressIndicator(
                  value: _isSuccess ? 1.0 : _progress,
                  strokeWidth: isComic ? 6 : 5,
                  backgroundColor: Colors.transparent,
                  valueColor: AlwaysStoppedAnimation<Color>(activeColor),
                ),
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedBuilder(
                    animation: _pulseAnim,
                    builder: (_, __) {
                      final iconOpacity = _isPressing || _isSuccess
                          ? 1.0
                          : 0.55 + (_pulseAnim.value * 0.35);
                      return Icon(
                        _isSuccess
                            ? Icons.check_circle_rounded
                            : Icons.fingerprint_rounded,
                        size: 92,
                        color: activeColor.withOpacity(iconOpacity),
                        shadows: isComic
                            ? [
                                Shadow(
                                  color: C.comicTextOutline,
                                  offset: const Offset(2, 2),
                                  blurRadius: 0,
                                ),
                              ]
                            : null,
                      );
                    },
                  ),
                  const SizedBox(height: 10),
                  Text(
                    _isSuccess ? 'OK' : '$percentage%',
                    style: TextStyle(
                      fontFamily: fontMain,
                      fontSize: isComic ? 24 : 20,
                      fontWeight: FontWeight.w900,
                      color: activeColor,
                      letterSpacing: 1.5,
                      shadows: isComic
                          ? [
                              Shadow(
                                color: C.comicTextOutline,
                                offset: const Offset(1, 1),
                                blurRadius: 0,
                              ),
                            ]
                          : [
                              Shadow(
                                color: activeColor.withOpacity(0.5),
                                blurRadius: 8,
                              ),
                            ],
                    ),
                  ),
                ],
              ),
            ],
          );
        },
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════
  //  STATUS PILL
  // ══════════════════════════════════════════════════════════════
  Widget _buildStatusPill(
    AppPalette C,
    bool isComic,
    Color txtMain,
    String fontMain,
  ) {
    final String label;
    final Color color;
    final IconData icon;

    if (_isSuccess) {
      label = isComic ? 'AKSES DIBERIKAN' : 'ACCESS GRANTED';
      color = C.primaryHi;
      icon = Icons.verified_rounded;
    } else if (_isPressing) {
      label = isComic ? 'MEMINDAI...' : 'SCANNING...';
      color = isComic ? C.primaryHi : C.accent;
      icon = Icons.fingerprint_rounded;
    } else {
      label = isComic ? 'TAHAN UNTUK PINDAI' : 'HOLD TO SCAN';
      color = isComic ? C.primaryHi : C.accent;
      icon = Icons.touch_app_rounded;
    }

    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
      decoration: BoxDecoration(
        color: isComic ? C.bgDark : C.bgDark.withOpacity(0.6),
        borderRadius: BorderRadius.circular(isComic ? 14 : 24),
        border: Border.all(
          color: isComic ? Colors.black : color.withOpacity(0.5),
          width: isComic ? 3 : 1.5,
        ),
        boxShadow: isComic
            ? const [
                BoxShadow(
                  color: Colors.black,
                  offset: Offset(4, 4),
                  blurRadius: 0,
                ),
              ]
            : [
                BoxShadow(
                  color: color.withOpacity(0.15),
                  blurRadius: 12,
                  spreadRadius: 1,
                ),
              ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(width: 8),
          Text(
            label,
            style: TextStyle(
              fontFamily: fontMain,
              fontSize: isComic ? 14 : 12,
              color: isComic ? txtMain : color,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.8,
            ),
          ),
        ],
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════
  //  CANCEL BUTTON
  // ══════════════════════════════════════════════════════════════
  Widget _buildCancelButton(
    AppPalette C,
    bool isComic,
    Color txtMain,
    String fontMain,
  ) {
    return Center(
      child: GestureDetector(
        onTap: _exitApp,
        child: Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 34, vertical: 13),
          decoration: BoxDecoration(
            color: isComic ? C.bgDark : C.bgDark.withOpacity(0.6),
            borderRadius: BorderRadius.circular(isComic ? 12 : 14),
            border: Border.all(
              color: isComic
                  ? Colors.black
                  : C.primary.withOpacity(0.55),
              width: isComic ? 3 : 1.5,
            ),
            boxShadow: isComic
                ? const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(4, 4),
                      blurRadius: 0,
                    ),
                  ]
                : [
                    BoxShadow(
                      color: C.primary.withOpacity(0.15),
                      blurRadius: 12,
                      spreadRadius: 1,
                    ),
                  ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.close_rounded,
                color: isComic ? txtMain : C.primary,
                size: 18,
              ),
              const SizedBox(width: 10),
              Text(
                'BATAL',
                style: TextStyle(
                  fontFamily: fontMain,
                  fontSize: isComic ? 15 : 13,
                  color: isComic ? txtMain : C.primary,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.8,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _glowOrb(double size, Color color) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [color, Colors.transparent],
          ),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
//  PAINTERS
// ══════════════════════════════════════════════════════════════
class _PintuGridPainter extends CustomPainter {
  final Color color;
  const _PintuGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(0.07)
      ..strokeWidth = 1.0;
    const double gridSize = 40.0;
    for (double x = 0; x < size.width; x += gridSize) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += gridSize) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _PintuGridPainter old) => old.color != color;
}

class _PintuHalftonePainter extends CustomPainter {
  final Color color;
  const _PintuHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _PintuHalftonePainter old) =>
      old.color != color;
}

class _DashedCirclePainter extends CustomPainter {
  final Color color;
  final double strokeWidth;
  final double dashSize;
  final double gapSize;

  const _DashedCirclePainter({
    required this.color,
    this.strokeWidth = 1.0,
    this.dashSize = 6.0,
    this.gapSize = 6.0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..style = PaintingStyle.stroke;

    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width - strokeWidth) / 2;
    final circumference = 2 * 3.141592653589793 * radius;
    final dashCount = (circumference / (dashSize + gapSize)).floor();
    final sweepAngle = (dashSize / circumference) * 2 * 3.141592653589793;

    for (int i = 0; i < dashCount; i++) {
      final startAngle = i * (2 * 3.141592653589793 / dashCount);
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweepAngle,
        false,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _DashedCirclePainter old) =>
      old.color != color;
}