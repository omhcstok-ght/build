// lib/smart_widgets.dart — Widget universal auto-adapt style
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'app_theme.dart';

// ═══════════════════════════════════════════════════════════
// SMART PLATE
// ═══════════════════════════════════════════════════════════
class SmartPlate extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double? radius;
  final Color? accent;
  final bool elevated;

  const SmartPlate({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius,
    this.accent,
    this.elevated = true,
  });

  @override
  Widget build(BuildContext context) {
    final C = AppThemeScope.paletteOf(context);
    final isComic = AppThemeScope.isComic(context);
    final r = radius ?? (isComic ? 18.0 : 16.0);

    if (isComic) {
      final baseColor = brass
          ? C.primaryHi
          : (accent != null
              ? Color.lerp(C.bgDark, accent!, 0.15)!
              : C.bgDark);
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: baseColor,
          borderRadius: BorderRadius.circular(r),
          border: Border.all(color: Colors.black, width: 3.5),
          boxShadow: elevated
              ? const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(6, 6),
                    blurRadius: 0,
                  ),
                ]
              : null,
        ),
        child: child,
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(r),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.75),
            offset: const Offset(0, 6),
            blurRadius: 12,
          ),
          const BoxShadow(
            color: Colors.white12,
            offset: Offset(-1, -1),
            blurRadius: 3,
          ),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(r - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SMART BUTTON — auto contrast teks ke button color
// ═══════════════════════════════════════════════════════════
class SmartButton extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final Color? color;
  final double height;
  final EdgeInsets padding;

  const SmartButton({
    super.key,
    required this.child,
    required this.onTap,
    this.color,
    this.height = 56,
    this.padding = const EdgeInsets.symmetric(horizontal: 20),
  });

  @override
  State<SmartButton> createState() => _SmartButtonState();
}

class _SmartButtonState extends State<SmartButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = AppThemeScope.paletteOf(context);
    final isComic = AppThemeScope.isComic(context);
    final color = widget.color ?? C.primaryHi;
    final enabled = widget.onTap != null;

    // AUTO CONTRAST — teks kontras ke warna button
    final textColor = isComic ? C.contrastTextOn(color) : C.text;
    final textOutline = textColor == Colors.white ? Colors.black : Colors.white;

    if (isComic) {
      return GestureDetector(
        onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
        onTapUp: enabled
            ? (_) {
                setState(() => _pressed = false);
                widget.onTap?.call();
              }
            : null,
        onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 80),
          height: widget.height,
          transform: Matrix4.translationValues(
            _pressed ? 4 : 0,
            _pressed ? 4 : 0,
            0,
          ),
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.black, width: 3.5),
            boxShadow: _pressed
                ? []
                : const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(4, 4),
                      blurRadius: 0,
                    ),
                  ],
          ),
          child: Padding(
            padding: widget.padding,
            child: Center(
              child: DefaultTextStyle(
                style: TextStyle(
                  fontFamily: 'Bangers',
                  fontSize: 16,
                  letterSpacing: 1.5,
                  color: textColor,
                  shadows: [
                    Shadow(
                      color: textOutline,
                      offset: const Offset(2, 2),
                      blurRadius: 0,
                    ),
                  ],
                ),
                child: IconTheme(
                  data: IconThemeData(color: textColor),
                  child: widget.child,
                ),
              ),
            ),
          ),
        ),
      );
    }

    return GestureDetector(
      onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
      onTapUp: enabled
          ? (_) {
              setState(() => _pressed = false);
              widget.onTap?.call();
            }
          : null,
      onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: widget.height,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: LinearGradient(
            begin:
                _pressed ? Alignment.bottomCenter : Alignment.topCenter,
            end: _pressed ? Alignment.topCenter : Alignment.bottomCenter,
            colors: [
              color.withOpacity(0.9),
              color,
              color.withOpacity(0.7),
            ],
          ),
          border:
              Border.all(color: color.withOpacity(0.9), width: 1.5),
          boxShadow: _pressed
              ? []
              : [
                  BoxShadow(
                    color: color.withOpacity(0.35),
                    blurRadius: 10,
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.6),
                    offset: const Offset(0, 4),
                    blurRadius: 6,
                  ),
                ],
        ),
        child: Padding(
          padding: widget.padding,
          child: Center(
            child: Opacity(
              opacity: enabled ? 1 : 0.5,
              child: widget.child,
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SMART LED
// ═══════════════════════════════════════════════════════════
class SmartLed extends StatelessWidget {
  final Color? color;
  final double size;
  final bool blink;

  const SmartLed({
    super.key,
    this.color,
    this.size = 8,
    this.blink = false,
  });

  @override
  Widget build(BuildContext context) {
    final C = AppThemeScope.paletteOf(context);
    final isComic = AppThemeScope.isComic(context);
    final c = color ?? C.primaryHi;

    if (isComic) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: c,
          border:
              Border.all(color: Colors.black, width: size * 0.15),
        ),
      );
    }

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [
            Colors.white.withOpacity(0.85),
            c,
            c.withOpacity(0.55),
          ],
          stops: const [0.0, 0.4, 1.0],
        ),
        border: Border.all(
          color: Colors.black.withOpacity(0.85),
          width: size * 0.1,
        ),
        boxShadow: [
          BoxShadow(
            color: c.withOpacity(0.75),
            blurRadius: size * 1.4,
            spreadRadius: size * 0.2,
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SMART SCREW
// ═══════════════════════════════════════════════════════════
class SmartScrew extends StatelessWidget {
  final double size;
  final double rotation;
  const SmartScrew({super.key, this.size = 12, this.rotation = 0.785});

  @override
  Widget build(BuildContext context) {
    if (AppThemeScope.isComic(context)) return const SizedBox.shrink();
    final C = AppThemeScope.paletteOf(context);
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.text, C.textSub, C.bg, C.bgDark],
          stops: const [0.0, 0.35, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.9),
            offset: const Offset(0.8, 1.5),
            blurRadius: 2.5,
          ),
        ],
      ),
      child: Center(
        child: Transform.rotate(
          angle: rotation,
          child: Container(
            width: size * 0.7,
            height: size * 0.11,
            color: Colors.black.withOpacity(0.9),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SMART RIVET
// ═══════════════════════════════════════════════════════════
class SmartRivet extends StatelessWidget {
  final double size;
  const SmartRivet({super.key, this.size = 10});

  @override
  Widget build(BuildContext context) {
    if (AppThemeScope.isComic(context)) return const SizedBox.shrink();
    final C = AppThemeScope.paletteOf(context);
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.accentShine, C.accentHi, C.accent, C.primaryLo],
          stops: const [0.0, 0.3, 0.65, 1.0],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SMART BACKGROUND
// ═══════════════════════════════════════════════════════════
class SmartBackground extends StatelessWidget {
  final Widget child;
  final bool halftone;
  const SmartBackground({
    super.key,
    required this.child,
    this.halftone = true,
  });

  @override
  Widget build(BuildContext context) {
    final C = AppThemeScope.paletteOf(context);
    final isComic = AppThemeScope.isComic(context);

    if (isComic) {
      return Container(
        color: C.bg,
        child: halftone
            ? CustomPaint(
                painter: _HalftonePainter(
                  color: C.primaryLo.withOpacity(0.12),
                ),
                child: child,
              )
            : child,
      );
    }

    return Container(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          center: const Alignment(-0.3, -0.3),
          radius: 1.2,
          colors: [C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.6, 1.0],
        ),
      ),
      child: child,
    );
  }
}

class _HalftonePainter extends CustomPainter {
  final Color color;
  _HalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_HalftonePainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// SMART TEXT — auto contrast
// ═══════════════════════════════════════════════════════════
class SmartText extends StatelessWidget {
  final String text;
  final double fontSize;
  final Color? color;
  final bool outline;
  final FontWeight fontWeight;
  final double? letterSpacing;
  final TextAlign? textAlign;
  final int? maxLines;
  final TextOverflow? overflow;

  const SmartText(
    this.text, {
    super.key,
    this.fontSize = 14,
    this.color,
    this.outline = false,
    this.fontWeight = FontWeight.w900,
    this.letterSpacing,
    this.textAlign,
    this.maxLines,
    this.overflow,
  });

  @override
  Widget build(BuildContext context) {
    final C = AppThemeScope.paletteOf(context);
    final isComic = AppThemeScope.isComic(context);

    final c = color ?? (isComic ? C.comicText : C.text);

    if (isComic) {
      return Text(
        text,
        textAlign: textAlign,
        maxLines: maxLines,
        overflow: overflow,
        style: TextStyle(
          color: c,
          fontFamily: 'Bangers',
          fontSize: fontSize + 1,
          fontWeight: FontWeight.w900,
          letterSpacing: letterSpacing ?? 1.0,
          shadows: [
            Shadow(
              color: C.comicTextOutline.withOpacity(0.7),
              offset: const Offset(1.5, 1.5),
              blurRadius: 0,
            ),
          ],
        ),
      );
    }

    return Text(
      text,
      textAlign: textAlign,
      maxLines: maxLines,
      overflow: overflow,
      style: TextStyle(
        color: c,
        fontFamily: 'Orbitron',
        fontSize: fontSize,
        fontWeight: fontWeight,
        letterSpacing: letterSpacing ?? 0.5,
        shadows: const [
          Shadow(
            color: Colors.black,
            offset: Offset(0, 1),
            blurRadius: 2,
          ),
        ],
      ),
    );
  }
}