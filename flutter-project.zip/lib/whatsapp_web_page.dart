// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:qr_flutter/qr_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ═══════════════════════════════════════════════════════════════════════════
// WHATSAPP WEB PAGE — "WA WEB BY OMHC" (iOS STYLE • LIQUID GLASS)
//
//  • Mesin Baileys via backend (wa_web_plugin.js) — protokol WhatsApp Web
//  • UI gaya WhatsApp iOS/iPhone: icon Cupertino, tab bar glass, bubble iOS
//  • Liquid glass + scaffold TRANSPARAN → video background terlihat jelas
//  • CENTANG BIRU (visual only, khusus owner):
//      panel owner untuk mencentang biru akun/nomor yang diregistrasi.
//      Badge hanya tampil di aplikasi ini — tidak tembus ke WhatsApp asli.
//
// NOTE dependency: qr_flutter ^4.1.0 (web_socket_channel & shared_preferences
// sudah dipakai project ini). Icon iOS memakai CupertinoIcons (bawaan Flutter).
// ═══════════════════════════════════════════════════════════════════════════

// ── ⚙️ KONFIGURASI — GANTI SESUAI SERVER KAMU ──
const String kWaWsUrl = 'wss://omhc-host-premium.yakuza.biz.id/ws-whatsapp';
const int kReconnectDelaySec = 5;
const Duration kHeartbeat = Duration(seconds: 30);

/// Token owner untuk panel centang biru (harus sama dengan
/// WA_OWNER_TOKEN / options.ownerToken di wa_web_plugin.js backend).
/// GANTI! Jangan pakai token default saat production.
const String kWaOwnerToken = 'omhc-owner';

// ── COLOR SCHEME (tema app + WhatsApp iOS) ──
class _W {
  static const bg        = Color(0xFF000000);
  static const surface   = Color(0xFF111111);
  static const accent    = Color(0xFFFF3B30);   // merah tema app
  static const text      = Color(0xFFE0E7FF);
  static const muted     = Color(0x73E0E7FF);
  static const muted2    = Color(0x38E0E7FF);
  static const border    = Color(0x1AFF3B30);
  // WhatsApp / iOS
  static const waGreen   = Color(0xFF25D366);
  static const waGreenDk = Color(0xFF128C7E);
  static const iosBlue   = Color(0xFF0A84FF);   // centang biru visual
  static const glass     = Color(0x14FFFFFF);   // tint liquid glass
  static const glassLine = Color(0x24FFFFFF);   // border glass
}

// ═══════════════════════════════════════════════════════════════════════════
// GLOBAL BADGE — total unread untuk tile WA WEB di halaman GRATISAN
// ═══════════════════════════════════════════════════════════════════════════
final ValueNotifier<int> waUnreadTotal = ValueNotifier<int>(0);

// ═══════════════════════════════════════════════════════════════════════════
// CENTANG BIRU (VISUAL ONLY) — registry akun, hanya di aplikasi ini
// ═══════════════════════════════════════════════════════════════════════════
class WaVerifiedStore {
  static const String _key = 'wa_verified_accounts_v1';
  static final ValueNotifier<Set<String>> accounts = ValueNotifier<Set<String>>({});
  static bool _loaded = false;

  static Future<void> load() async {
    if (_loaded) return;
    try {
      final prefs = await SharedPreferences.getInstance();
      accounts.value = (prefs.getStringList(_key) ?? []).toSet();
      _loaded = true;
    } catch (_) {}
  }

  static Future<void> _save() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(_key, accounts.value.toList());
    } catch (_) {}
  }

  static Future<void> add(String phone) async {
    final clean = phone.replaceAll(RegExp(r'[^0-9]'), '');
    if (clean.isEmpty) return;
    accounts.value = {...accounts.value, clean};
    await _save();
  }

  static Future<void> remove(String phone) async {
    accounts.value = {...accounts.value}..remove(phone);
    await _save();
  }

  /// Sinkron dari server (sumber kebenaran) — dipanggil saat
  /// pesan 'verified:update' datang dari wa_web_plugin.js.
  /// Cache lokal (SharedPreferences) dipakai saat offline.
  static Future<void> syncFromServer(List<dynamic> list) async {
    final serverSet = list
        .map((e) => e.toString().replaceAll(RegExp(r'[^0-9]'), ''))
        .where((e) => e.isNotEmpty)
        .toSet();
    if (serverSet.isEmpty && accounts.value.isNotEmpty) return; // jangan hapus cache saat offline
    accounts.value = serverSet;
    await _save();
  }

  /// Kirim perubahan badge ke server (hanya owner — butuh kWaOwnerToken)
  static void pushAddToServer(String phone) {
    final clean = phone.replaceAll(RegExp(r'[^0-9]'), '');
    if (clean.isEmpty) return;
    _sendRaw({'type': 'verified:add', 'phone': clean, 'token': kWaOwnerToken});
  }

  static void pushRemoveToServer(String phone) {
    final clean = phone.replaceAll(RegExp(r'[^0-9]'), '');
    if (clean.isEmpty) return;
    _sendRaw({'type': 'verified:remove', 'phone': clean, 'token': kWaOwnerToken});
  }

  static void _sendRaw(Map<String, dynamic> data) {
    // Diisi dari State via callback agar store tidak pegang WebSocket
    serverSender?.call(data);
  }

  /// Di-set oleh _WhatsAppWebPageState.initState: (msg) => _send(msg)
  static void Function(Map<String, dynamic> data)? serverSender;

  /// Cek apakah chatId punya centang biru (cocokkan nomor di dalam jid)
  static bool isVerified(String chatId) {
    final digits = chatId.replaceAll(RegExp(r'[^0-9]'), '');
    for (final acc in accounts.value) {
      if (acc.isNotEmpty && digits.startsWith(acc)) return true;
    }
    return false;
  }
}

// ── Badge centang biru (icon iOS verified) ──
Widget waBlueCheck({double size = 14}) {
  return Icon(
    CupertinoIcons.checkmark_seal_fill,
    color: _W.iosBlue,
    size: size,
  );
}

enum WaConn { idle, connecting, waitingQr, pairing, syncing, connected, error }

class WhatsAppWebPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final bool isOwner; // true → panel centang biru muncul

  const WhatsAppWebPage({
    super.key,
    this.sessionKey = '',
    this.username = 'User',
    this.isOwner = false,
  });

  @override
  State<WhatsAppWebPage> createState() => _WhatsAppWebPageState();
}

class _WhatsAppWebPageState extends State<WhatsAppWebPage>
    with TickerProviderStateMixin {

  // ── WebSocket ──
  WebSocketChannel? _ws;
  WaConn _conn = WaConn.idle;
  String _errorMsg = '';
  Timer? _reconnectTimer;
  Timer? _heartbeatTimer;

  // ── Login data ──
  String _qrData = '';
  final TextEditingController _phoneCtrl = TextEditingController();
  String _pairingCode = '';
  String _profileName = '';
  String _profilePhone = '';

  // ── Sync data ──
  List<Map<String, dynamic>> _chats = [];
  List<Map<String, dynamic>> _statuses = [];
  List<Map<String, dynamic>> _newsletters = [];
  final Map<String, List<Map<String, dynamic>>> _messages = {};
  String _openChatId = '';

  // ── UI ──
  int _selectedTab = 0; // 0 chat, 1 status, 2 channel, 3 grup
  int _loginSegment = 0; // 0 QR, 1 pairing
  late AnimationController _glowCtrl;
  final ScrollController _chatScrollCtrl = ScrollController();
  final TextEditingController _msgCtrl = TextEditingController();
  final TextEditingController _verifiedCtrl = TextEditingController();

  // ═════════════════════════════════════════════════════════════════════════
  // INIT / DISPOSE
  // ═════════════════════════════════════════════════════════════════════════
  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 3),
    )..repeat();
    WaVerifiedStore.load();
    WaVerifiedStore.serverSender = _send;
    _connectWs();
  }

  @override
  void dispose() {
    WaVerifiedStore.serverSender = null;
    _reconnectTimer?.cancel();
    _heartbeatTimer?.cancel();
    _ws?.sink.close(status.goingAway);
    _glowCtrl.dispose();
    _chatScrollCtrl.dispose();
    _phoneCtrl.dispose();
    _msgCtrl.dispose();
    _verifiedCtrl.dispose();
    waUnreadTotal.value = 0;
    super.dispose();
  }

  // ═════════════════════════════════════════════════════════════════════════
  // LIQUID GLASS HELPER
  // ═════════════════════════════════════════════════════════════════════════
  Widget _glass({
    Key? key,
    required Widget child,
    double blur = 18,
    double opacity = 0.06,
    double radius = 20,
    EdgeInsetsGeometry? padding,
  }) {
    return ClipRRect(
      key: key,
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(opacity),
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(color: _W.glassLine, width: 1),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.white.withOpacity(opacity + 0.03),
                Colors.white.withOpacity(opacity * 0.4),
              ],
            ),
          ),
          child: child,
        ),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // WEBSOCKET (logika sama, protokol wa_web_plugin.js)
  // ═════════════════════════════════════════════════════════════════════════
  void _connectWs() {
    if (!mounted) return;
    setState(() {
      _conn = WaConn.connecting;
      _errorMsg = '';
    });
    try {
      _ws = WebSocketChannel.connect(Uri.parse(kWaWsUrl));
      _ws!.stream.listen(
        _handleMessage,
        onDone: () => _scheduleReconnect('Koneksi terputus'),
        onError: (_) => _scheduleReconnect('Koneksi error'),
      );
      _startHeartbeat();
      _send({'type': 'connect', 'sessionKey': widget.sessionKey});
      _send({'type': 'verified:list'});
    } catch (e) {
      _scheduleReconnect('Gagal terhubung ke server');
    }
  }

  void _scheduleReconnect(String msg) {
    if (!mounted) return;
    setState(() {
      _conn = (_conn == WaConn.connected || _conn == WaConn.syncing)
          ? WaConn.connecting
          : WaConn.error;
      _errorMsg = msg;
    });
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(
      const Duration(seconds: kReconnectDelaySec), _connectWs,
    );
  }

  void _startHeartbeat() {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = Timer.periodic(kHeartbeat, (_) {
      _send({'type': 'sync'});
    });
  }

  void _send(Map<String, dynamic> data) {
    try {
      _ws?.sink.add(jsonEncode(data));
    } catch (_) {}
  }

  void _handleMessage(dynamic raw) {
    Map<String, dynamic> data;
    try {
      data = jsonDecode(raw.toString());
    } catch (_) {
      return;
    }
    if (!mounted) return;

    switch (data['type']) {
      case 'qr':
        setState(() {
          _conn = WaConn.waitingQr;
          _qrData = (data['qr'] ?? '').toString();
        });
        break;

      case 'pairingCode':
        setState(() {
          _conn = WaConn.pairing;
          _pairingCode = (data['code'] ?? '').toString();
        });
        break;

      case 'paired':
        setState(() {
          _conn = WaConn.syncing;
          _profileName = (data['name'] ?? widget.username).toString();
          _profilePhone = (data['phone'] ?? '').toString();
          _qrData = '';
          _pairingCode = '';
        });
        _send({'type': 'sync'});
        break;

      case 'chats':
        final list = (data['chats'] as List? ?? [])
            .map<Map<String, dynamic>>((c) => _normalizeChat(c))
            .toList();
        int unread = 0;
        for (final c in list) {
          unread += (c['unread'] is int) ? c['unread'] as int : 0;
        }
        waUnreadTotal.value = unread;
        setState(() {
          _chats = list;
          _conn = WaConn.connected;
        });
        break;

      case 'status':
        setState(() {
          _statuses = (data['status'] as List? ?? [])
              .map<Map<String, dynamic>>((s) => {
                    'id': (s['id'] ?? '').toString(),
                    'name': (s['name'] ?? s['pushName'] ?? 'Tanpa Nama').toString(),
                    'timestamp': s['timestamp'],
                  })
              .toList();
        });
        break;

      case 'newsletters':
        setState(() {
          _newsletters = (data['newsletters'] as List? ?? [])
              .map<Map<String, dynamic>>((n) => {
                    'id': (n['id'] ?? '').toString(),
                    'name': (n['name'] ?? 'Channel').toString(),
                  })
              .toList();
        });
        break;

      case 'messages':
        final chatId = (data['chatId'] ?? '').toString();
        final list = (data['messages'] as List? ?? [])
            .map<Map<String, dynamic>>((m) => _normalizeMessage(m))
            .toList();
        setState(() => _messages[chatId] = list);
        _scrollToBottom();
        break;

      case 'message:new':
        final chatId = (data['chatId'] ?? '').toString();
        final msg = _normalizeMessage(data['message'] ?? {});
        setState(() {
          final cur = _messages[chatId] ?? [];
          if (!cur.any((m) => m['key'] == msg['key'])) {
            cur.add(msg);
            _messages[chatId] = cur;
          }
          final idx = _chats.indexWhere((c) => c['id'] == chatId);
          if (idx >= 0) {
            final chat = Map<String, dynamic>.from(_chats[idx]);
            chat['lastMessage'] = msg['text'];
            chat['timestamp'] = msg['timestamp'];
            _chats[idx] = chat;
          }
        });
        _scrollToBottom();
        break;

      case 'error':
        setState(() {
          _errorMsg = (data['message'] ?? 'Terjadi kesalahan').toString();
        });
        break;

      case 'status-info':
        // Info status awal dari server — jika sudah paired langsung sync
        if (data['waStatus'] == 'connected') {
          _send({'type': 'sync'});
        }
        break;

      case 'verified:update':
        // Daftar centang biru dari server (visual only) → cache lokal
        WaVerifiedStore.syncFromServer(data['accounts'] as List? ?? []);
        setState(() {});
        break;
    }
  }

  Map<String, dynamic> _normalizeChat(dynamic c) {
    final id = (c['id'] ?? '').toString();
    final name = (c['name'] ?? c['pushName'] ?? '').toString();
    final last = c['lastMessage'];
    String lastText = '';
    int lastTs = 0;
    if (last is Map) {
      lastText = (last['text'] ?? last['caption'] ?? last['message'] ?? '').toString();
      lastTs = int.tryParse('${last['timestamp'] ?? 0}') ?? 0;
    }
    return {
      'id': id,
      'name': name.isNotEmpty ? name : id.replaceAll('@s.us', '').replaceAll('@g.us', ''),
      'isGroup': id.endsWith('@g.us'),
      'isChannel': id.endsWith('@newsletter'),
      'unread': int.tryParse('${c['unreadCount'] ?? 0}') ?? 0,
      'lastMessage': lastText,
      'timestamp': lastTs,
    };
  }

  Map<String, dynamic> _normalizeMessage(dynamic m) {
    final content = (m['message'] is Map) ? m['message'] as Map : m;
    final text = (content['text'] ??
            content['caption'] ??
            content['conversation'] ??
            content['extendedTextMessage']?['text'] ??
            '')
        .toString();
    return {
      'key': (m['key']?['id'] ?? m['id'] ?? DateTime.now().microsecondsSinceEpoch.toString()).toString(),
      'text': text,
      'fromMe': (m['key']?['fromMe'] ?? m['fromMe'] ?? false) == true,
      'timestamp': int.tryParse('${m['messageTimestamp'] ?? m['timestamp'] ?? 0}') ?? 0,
    };
  }

  // ── Actions ──
  void _requestPairingCode() {
    final phone = _phoneCtrl.text.trim().replaceAll(RegExp(r'[^0-9]'), '');
    if (phone.length < 8) {
      setState(() => _errorMsg = 'Masukkan nomor WhatsApp yang valid (contoh: 62812xxxxxxx)');
      return;
    }
    setState(() => _errorMsg = '');
    _send({'type': 'pairingCode', 'phone': phone});
  }

  void _openChat(Map<String, dynamic> chat) {
    setState(() => _openChatId = chat['id']);
    _send({'type': 'messages', 'chatId': chat['id']});
  }

  void _closeChat() {
    setState(() => _openChatId = '');
  }

  void _sendMessage() {
    final text = _msgCtrl.text.trim();
    if (text.isEmpty || _openChatId.isEmpty) return;
    _msgCtrl.clear();
    _send({'type': 'send', 'chatId': _openChatId, 'text': text});
  }

  void _logoutWa() {
    _send({'type': 'logout'});
    setState(() {
      _qrData = '';
      _pairingCode = '';
      _profileName = '';
      _profilePhone = '';
      _chats = [];
      _statuses = [];
      _newsletters = [];
      _messages.clear();
      _openChatId = '';
      _conn = WaConn.connecting;
    });
    _send({'type': 'connect', 'sessionKey': widget.sessionKey});
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_chatScrollCtrl.hasClients) {
        _chatScrollCtrl.jumpTo(_chatScrollCtrl.position.maxScrollExtent);
      }
    });
  }

  String _formatTime(int ts) {
    if (ts <= 0) return '';
    final d = DateTime.fromMillisecondsSinceEpoch(ts * 1000);
    final now = DateTime.now();
    if (d.day == now.day && d.month == now.month && d.year == now.year) {
      return '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    }
    return '${d.day}/${d.month}';
  }

  // ═════════════════════════════════════════════════════════════════════════
  // BUILD — scaffold transparan agar video background terlihat
  // ═════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          // ── Overlay gelap tipis (video tetap terlihat jelas) ──
          Container(color: Colors.black.withOpacity(0.42)),
          // ── Konten ──
          SafeArea(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 400),
              child: _openChatId.isNotEmpty
                  ? _buildChatView()
                  : (_conn == WaConn.connected || _conn == WaConn.syncing)
                      ? _buildMainView()
                      : _buildLoginView(),
            ),
          ),
        ],
      ),
    );
  }

  // ── Badge koneksi (pill glass) ──
  Widget _buildConnBadge() {
    final label = switch (_conn) {
      WaConn.idle        => 'IDLE',
      WaConn.connecting  => 'MENGHUBUNGKAN',
      WaConn.waitingQr   => 'MENUNGGU SCAN',
      WaConn.pairing     => 'PAIRING',
      WaConn.syncing     => 'SYNC',
      WaConn.connected   => 'TERHUBUNG',
      WaConn.error       => 'ERROR',
    };
    final color = _conn == WaConn.connected || _conn == WaConn.syncing
        ? _W.waGreen
        : _conn == WaConn.error
            ? _W.accent
            : _W.iosBlue;
    return AnimatedBuilder(
      animation: _glowCtrl,
      builder: (context, _) {
        final pulse =
            0.5 + (math.sin(_glowCtrl.value * 2 * math.pi) * 0.5).abs();
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
          decoration: BoxDecoration(
            color: color.withOpacity(0.10),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: color.withOpacity(0.35)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 6,
                height: 6,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color,
                  boxShadow: [
                    BoxShadow(
                      color: color.withOpacity(0.4 + pulse * 0.4),
                      blurRadius: 4 + pulse * 3,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 5),
              Text(
                label,
                style: TextStyle(
                  fontFamily: 'ShareTechMono',
                  fontSize: 8,
                  color: color,
                  letterSpacing: 0.8,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ── Header bar glass ala iOS (dipakai semua view) ──
  Widget _buildIosBar({
    required Widget leading,
    required String title,
    String? subtitle,
    required List<Widget> trailing,
  }) {
    return _glass(
      blur: 22,
      opacity: 0.08,
      radius: 22,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      child: Row(
        children: [
          leading,
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                    letterSpacing: -0.3,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                if (subtitle != null) ...[
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontFamily: 'ShareTechMono',
                      fontSize: 9.5,
                      color: _W.muted,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ],
            ),
          ),
          ...trailing,
        ],
      ),
    );
  }

  // ── Tombol bulat glass ala iOS ──
  Widget _glassCircleBtn(IconData icon, Color color, VoidCallback onTap,
      {double size = 36}) {
    return GestureDetector(
      onTap: onTap,
      child: ClipOval(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(0.12),
              border: Border.all(color: color.withOpacity(0.35)),
            ),
            child: Icon(icon, color: color, size: size * 0.5),
          ),
        ),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // VIEW 1 — LOGIN (iOS style: glass card + CupertinoSlidingSegmentedControl)
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildLoginView() {
    return Column(
      key: const ValueKey('login'),
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 4),
          child: _buildIosBar(
            leading: _glassCircleBtn(
              CupertinoIcons.back, Colors.white, () => Navigator.of(context).pop(),
            ),
            title: 'WA Web',
            subtitle: 'by OMHC • YakuzaXsilence',
            trailing: [_buildConnBadge()],
          ),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            children: [
              const SizedBox(height: 6),
              // ── Segmented control iOS ──
              _glass(
                blur: 20,
                opacity: 0.07,
                radius: 16,
                padding: const EdgeInsets.all(4),
                child: CupertinoSlidingSegmentedControl<int>(
                  groupValue: _loginSegment,
                  onValueChanged: (v) =>
                      setState(() => _loginSegment = v ?? 0),
                  thumbColor: _W.waGreen.withOpacity(0.25),
                  backgroundColor: Colors.transparent,
                  children: const {
                    0: Padding(
                      padding: EdgeInsets.symmetric(vertical: 7),
                      child: Text('QR Code',
                          style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: Colors.white)),
                    ),
                    1: Padding(
                      padding: EdgeInsets.symmetric(vertical: 7),
                      child: Text('Pairing Code',
                          style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: Colors.white)),
                    ),
                  },
                ),
              ),
              const SizedBox(height: 12),
              if (_errorMsg.isNotEmpty)
                Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _W.accent.withOpacity(0.10),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _W.accent.withOpacity(0.35)),
                  ),
                  child: Text(
                    _errorMsg,
                    style: TextStyle(
                      fontFamily: 'ShareTechMono',
                      fontSize: 11,
                      color: _W.accent,
                    ),
                  ),
                ),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 300),
                child: _loginSegment == 0
                    ? _buildQrCard()
                    : _buildPairingCard(),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ── Kartu QR (glass, icon iOS) ──
  Widget _buildQrCard() {
    return _glass(
      key: const ValueKey('qr'),
      blur: 20,
      opacity: 0.07,
      radius: 24,
      padding: const EdgeInsets.all(22),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _glassCircleBtn(CupertinoIcons.camera_viewfinder, _W.waGreen, () {},
                  size: 34),
              const SizedBox(width: 10),
              Text(
                'Tautkan Perangkat',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'WhatsApp HP → Perangkat Tertaut → Tautkan Perangkat',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'ShareTechMono',
              fontSize: 10,
              color: _W.muted,
              height: 1.6,
            ),
          ),
          const SizedBox(height: 18),
          Center(
            child: AnimatedBuilder(
              animation: _glowCtrl,
              builder: (context, _) {
                final pulse =
                    0.5 + (math.sin(_glowCtrl.value * 2 * math.pi) * 0.5).abs();
                return Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(
                      color: _W.waGreen.withOpacity(0.45 + pulse * 0.3),
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _W.waGreen.withOpacity(0.15 + pulse * 0.15),
                        blurRadius: 22 + pulse * 12,
                        spreadRadius: pulse * 2,
                      ),
                    ],
                  ),
                  child: _qrData.isEmpty
                      ? SizedBox(
                          width: 210,
                          height: 210,
                          child: Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                CupertinoActivityIndicator(color: _W.waGreen),
                                const SizedBox(height: 12),
                                Text(
                                  'Menunggu QR\ndari server...',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontFamily: 'ShareTechMono',
                                    fontSize: 10,
                                    color: Colors.black54,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        )
                      : QrImageView(
                          data: _qrData,
                          version: QrVersions.auto,
                          size: 210,
                          backgroundColor: Colors.white,
                        ),
                );
              },
            ),
          ),
          const SizedBox(height: 14),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(CupertinoIcons.lock_shield_fill,
                  color: _W.waGreen.withOpacity(0.8), size: 13),
              const SizedBox(width: 6),
              Text(
                'QR otomatis diperbarui server',
                style: TextStyle(
                  fontFamily: 'ShareTechMono',
                  fontSize: 9.5,
                  color: _W.muted2,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── Kartu Pairing Code (iOS style) ──
  Widget _buildPairingCard() {
    return _glass(
      key: const ValueKey('pair'),
      blur: 20,
      opacity: 0.07,
      radius: 24,
      padding: const EdgeInsets.all(22),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _glassCircleBtn(CupertinoIcons.phone_fill, _W.iosBlue, () {},
                  size: 34),
              const SizedBox(width: 10),
              Text(
                'Tautkan dengan Nomor',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'Format internasional tanpa + — contoh: 62812xxxxxxx',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'ShareTechMono',
              fontSize: 10,
              color: _W.muted,
            ),
          ),
          const SizedBox(height: 16),
          // Input nomor — CupertinoTextField (iOS)
          ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: CupertinoTextField(
                controller: _phoneCtrl,
                keyboardType: TextInputType.phone,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.white,
                  letterSpacing: 1.2,
                ),
                placeholder: '62812xxxxxxx',
                placeholderStyle: TextStyle(
                  fontSize: 14,
                  color: _W.muted2,
                ),
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _W.glassLine),
                ),
                prefix: Padding(
                  padding: const EdgeInsets.only(left: 14),
                  child: Icon(CupertinoIcons.phone_fill,
                      color: _W.waGreen, size: 17),
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          // Button iOS
          GestureDetector(
            onTap: _requestPairingCode,
            child: AnimatedBuilder(
              animation: _glowCtrl,
              builder: (context, _) {
                final pulse = 0.5 +
                    (math.sin(_glowCtrl.value * 2 * math.pi) * 0.5).abs();
                return Container(
                  width: double.infinity,
                  height: 48,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    color: _W.waGreen.withOpacity(0.22 + pulse * 0.08),
                    border: Border.all(
                        color: _W.waGreen.withOpacity(0.5), width: 1.2),
                    boxShadow: [
                      BoxShadow(
                        color: _W.waGreen.withOpacity(0.15 + pulse * 0.15),
                        blurRadius: 14 + pulse * 8,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      'Minta Pairing Code',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          // Kode pairing
          if (_pairingCode.isNotEmpty) ...[
            const SizedBox(height: 22),
            Text(
              'KODE PAIRING',
              style: TextStyle(
                fontFamily: 'ShareTechMono',
                fontSize: 9.5,
                color: _W.muted,
                letterSpacing: 3,
              ),
            ),
            const SizedBox(height: 12),
            GestureDetector(
              onTap: () {
                Clipboard.setData(ClipboardData(text: _pairingCode));
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text('Kode disalin!',
                      style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'ShareTechMono')),
                  backgroundColor: _W.waGreenDk,
                  behavior: SnackBarBehavior.floating,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ));
              },
              child: AnimatedBuilder(
                animation: _glowCtrl,
                builder: (context, _) {
                  final pulse = 0.5 +
                      (math.sin(_glowCtrl.value * 2 * math.pi) * 0.5).abs();
                  return Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 26, vertical: 16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                        color: _W.iosBlue.withOpacity(0.4 + pulse * 0.3),
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: _W.iosBlue.withOpacity(0.12 + pulse * 0.12),
                          blurRadius: 18 + pulse * 10,
                        ),
                      ],
                    ),
                    child: Text(
                      _formatPairing(_pairingCode),
                      style: TextStyle(
                        fontFamily: 'ShareTechMono',
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        letterSpacing: 6,
                        shadows: [
                          Shadow(
                            color: _W.iosBlue.withOpacity(0.5),
                            blurRadius: 14,
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'WhatsApp HP → Perangkat Tertaut →\nTautkan dengan Nomor Telepon → masukkan kode\n(tap kode untuk menyalin)',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'ShareTechMono',
                fontSize: 10,
                color: _W.muted2,
                height: 1.7,
              ),
            ),
          ],
        ],
      ),
    );
  }

  String _formatPairing(String code) {
    final clean = code.replaceAll(RegExp(r'[^A-Z0-9]'), '').toUpperCase();
    if (clean.length <= 4) return clean;
    return '${clean.substring(0, 4)}-${clean.substring(4, math.min(8, clean.length))}';
  }

  // ═════════════════════════════════════════════════════════════════════════
  // VIEW 2 — MAIN (iOS: large title, list glass, bottom bar glass)
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildMainView() {
    final groups = _chats.where((c) => c['isGroup'] == true).toList();
    final channels = _newsletters.isNotEmpty
        ? _newsletters
        : _chats.where((c) => c['isChannel'] == true).toList();

    return Column(
      key: const ValueKey('main'),
      children: [
        // ── Header bar glass ala WhatsApp iOS ──
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 6),
          child: _buildIosBar(
            leading: ClipOval(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [
                        _W.waGreen.withOpacity(0.85),
                        _W.waGreenDk.withOpacity(0.85),
                      ],
                    ),
                    border: Border.all(color: Colors.white.withOpacity(0.25)),
                  ),
                  child: Center(
                    child: Text(
                      _profileName.isNotEmpty
                          ? _profileName[0].toUpperCase()
                          : '?',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            title: _profileName.isNotEmpty ? _profileName : 'WA Web',
            subtitle: _profilePhone.isNotEmpty ? '+$_profilePhone' : 'terhubung',
            trailing: [
              _buildConnBadge(),
              const SizedBox(width: 8),
              // Panel centang biru (khusus OWNER)
              if (widget.isOwner)
                _glassCircleBtn(
                  CupertinoIcons.checkmark_seal_fill,
                  _W.iosBlue,
                  _showVerifiedPanel,
                ),
              if (widget.isOwner) const SizedBox(width: 8),
              _glassCircleBtn(
                CupertinoIcons.person_crop_circle_badge_xmark,
                _W.accent,
                _logoutWa,
              ),
            ],
          ),
        ),

        // ── Konten tab ──
        Expanded(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 250),
            child: KeyedSubtree(
              key: ValueKey('tab$_selectedTab'),
              child: switch (_selectedTab) {
                0 => _buildChatList(_chats, emptyText: 'Belum ada chat tersinkron.'),
                1 => _buildStatusList(),
                2 => _buildChannelList(channels),
                _ => _buildChatList(groups, emptyText: 'Belum ada grup tersinkron.'),
              },
            ),
          ),
        ),

        // ── Bottom tab bar glass ala iOS ──
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 4, 14, 10),
          child: _glass(
            blur: 24,
            opacity: 0.09,
            radius: 24,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            child: Row(
              children: List.generate(4, (i) {
                final icons = [
                  CupertinoIcons.chat_bubble_fill,
                  CupertinoIcons.circle_fill,
                  CupertinoIcons.speaker_2_fill,
                  CupertinoIcons.person_2_fill,
                ];
                final labels = ['Chat', 'Status', 'Channel', 'Grup'];
                final active = _selectedTab == i;
                return Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _selectedTab = i),
                    behavior: HitTestBehavior.opaque,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 220),
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        color: active
                            ? _W.waGreen.withOpacity(0.18)
                            : Colors.transparent,
                        border: Border.all(
                          color: active
                              ? _W.waGreen.withOpacity(0.4)
                              : Colors.transparent,
                        ),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            icons[i],
                            size: 20,
                            color: active ? _W.waGreen : _W.muted,
                          ),
                          const SizedBox(height: 3),
                          Text(
                            labels[i],
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight:
                                  active ? FontWeight.w700 : FontWeight.w500,
                              color: active ? Colors.white : _W.muted,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ],
    );
  }

  // ── Avatar bulat glass dengan initial ──
  Widget _buildAvatar(String name, {bool isGroup = false, double size = 50}) {
    return ClipOval(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: isGroup
                  ? [
                      _W.iosBlue.withOpacity(0.75),
                      _W.waGreenDk.withOpacity(0.75),
                    ]
                  : [
                      _W.waGreen.withOpacity(0.8),
                      _W.waGreenDk.withOpacity(0.8),
                    ],
            ),
            border: Border.all(color: Colors.white.withOpacity(0.22)),
          ),
          child: Center(
            child: Text(
              name.isNotEmpty ? name[0].toUpperCase() : '?',
              style: TextStyle(
                fontSize: size * 0.36,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ── List chat & grup (iOS WhatsApp style + centang biru) ──
  Widget _buildChatList(List<Map<String, dynamic>> items,
      {required String emptyText}) {
    if (items.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(CupertinoIcons.chat_bubble_2, color: _W.muted2, size: 42),
            const SizedBox(height: 12),
            Text(
              emptyText,
              style: TextStyle(
                  fontFamily: 'ShareTechMono', fontSize: 11, color: _W.muted),
            ),
          ],
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      itemCount: items.length,
      itemBuilder: (context, i) {
        final c = items[i];
        return _buildChatRow(c);
      },
    );
  }

  Widget _buildChatRow(Map<String, dynamic> c) {
    final name = (c['name'] ?? '').toString();
    final last = (c['lastMessage'] ?? '').toString();
    final ts = (c['timestamp'] is int) ? c['timestamp'] as int : 0;
    final unread = (c['unread'] is int) ? c['unread'] as int : 0;
    final isGroup = c['isGroup'] == true;
    final verified = WaVerifiedStore.isVerified((c['id'] ?? '').toString());

    return GestureDetector(
      onTap: () => _openChat(c),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        child: _glass(
          blur: 14,
          opacity: 0.055,
          radius: 18,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
          child: Row(
            children: [
              _buildAvatar(name, isGroup: isGroup),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Nama + centang biru (visual only)
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            name,
                            style: TextStyle(
                              fontSize: 14.5,
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                              letterSpacing: -0.2,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (verified) ...[
                          const SizedBox(width: 5),
                          waBlueCheck(size: 14),
                        ],
                        if (isGroup) ...[
                          const SizedBox(width: 5),
                          Icon(CupertinoIcons.person_2_fill,
                              color: _W.muted, size: 11),
                        ],
                      ],
                    ),
                    const SizedBox(height: 3),
                    Text(
                      last.isNotEmpty ? last : '—',
                      style: TextStyle(
                        fontSize: 12.5,
                        color: _W.muted,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    _formatTime(ts),
                    style: TextStyle(
                      fontSize: 11,
                      color: unread > 0 ? _W.waGreen : _W.muted2,
                      fontWeight: unread > 0 ? FontWeight.w600 : FontWeight.w400,
                    ),
                  ),
                  if (unread > 0) ...[
                    const SizedBox(height: 5),
                    // Pill unread hijau ala WhatsApp
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: _W.waGreen,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: _W.waGreen.withOpacity(0.4),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                      child: Text(
                        unread > 99 ? '99+' : '$unread',
                        style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── List status (ring ala WA) ──
  Widget _buildStatusList() {
    if (_statuses.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(CupertinoIcons.circle_fill, color: _W.muted2, size: 34),
            const SizedBox(height: 12),
            Text(
              'Belum ada status tersinkron.',
              style: TextStyle(
                  fontFamily: 'ShareTechMono', fontSize: 11, color: _W.muted),
            ),
          ],
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      itemCount: _statuses.length,
      itemBuilder: (context, i) {
        final s = _statuses[i];
        final name = (s['name'] ?? '').toString();
        final ts = (s['timestamp'] is int) ? s['timestamp'] as int : 0;
        final verified = WaVerifiedStore.isVerified((s['id'] ?? '').toString());
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          child: _glass(
            blur: 14,
            opacity: 0.055,
            radius: 18,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
            child: Row(
              children: [
                // Ring status hijau ala WA
                Container(
                  width: 52,
                  height: 52,
                  padding: const EdgeInsets.all(2.5),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [_W.waGreen, _W.waGreenDk],
                    ),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.black.withOpacity(0.55),
                    ),
                    child: Center(
                      child: Text(
                        name.isNotEmpty ? name[0].toUpperCase() : '?',
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              name,
                              style: TextStyle(
                                fontSize: 14.5,
                                fontWeight: FontWeight.w600,
                                color: Colors.white,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          if (verified) ...[
                            const SizedBox(width: 5),
                            waBlueCheck(size: 14),
                          ],
                        ],
                      ),
                      const SizedBox(height: 3),
                      Text(
                        _formatTime(ts).isEmpty ? 'baru saja' : _formatTime(ts),
                        style: TextStyle(fontSize: 11.5, color: _W.muted2),
                      ),
                    ],
                  ),
                ),
                Icon(CupertinoIcons.chevron_forward,
                    color: _W.muted2, size: 15),
              ],
            ),
          ),
        );
      },
    );
  }

  // ── List channel ──
  Widget _buildChannelList(List<Map<String, dynamic>> items) {
    if (items.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(CupertinoIcons.speaker_2_fill, color: _W.muted2, size: 36),
            const SizedBox(height: 12),
            Text(
              'Belum ada channel tersinkron.',
              style: TextStyle(
                  fontFamily: 'ShareTechMono', fontSize: 11, color: _W.muted),
            ),
          ],
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      itemCount: items.length,
      itemBuilder: (context, i) {
        final n = items[i];
        final name = (n['name'] ?? '').toString();
        final verified = WaVerifiedStore.isVerified((n['id'] ?? '').toString());
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          child: _glass(
            blur: 14,
            opacity: 0.055,
            radius: 18,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
            child: Row(
              children: [
                _buildAvatar(name, isGroup: true, size: 48),
                const SizedBox(width: 12),
                Expanded(
                  child: Row(
                    children: [
                      Flexible(
                        child: Text(
                          name,
                          style: TextStyle(
                            fontSize: 14.5,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (verified) ...[
                        const SizedBox(width: 5),
                        waBlueCheck(size: 14),
                      ],
                    ],
                  ),
                ),
                Icon(CupertinoIcons.chevron_forward,
                    color: _W.muted2, size: 15),
              ],
            ),
          ),
        );
      },
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // PANEL OWNER — CENTANG BIRU (VISUAL ONLY)
  // ═════════════════════════════════════════════════════════════════════════
  void _showVerifiedPanel() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      barrierColor: Colors.black54,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setSheetState) {
            Future<void> refresh() async => setSheetState(() {});
            return Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(ctx).viewInsets.bottom,
              ),
              child: Container(
                margin: const EdgeInsets.all(14),
                child: _glass(
                  blur: 26,
                  opacity: 0.10,
                  radius: 28,
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Handle + judul
                      Center(
                        child: Container(
                          width: 42,
                          height: 4.5,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.25),
                            borderRadius: BorderRadius.circular(3),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          waBlueCheck(size: 22),
                          const SizedBox(width: 8),
                          Text(
                            'Centang Biru (Visual)',
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Owner panel — badge hanya tampil di aplikasi kamu, tidak tembus ke WhatsApp asli.',
                        style: TextStyle(
                          fontFamily: 'ShareTechMono',
                          fontSize: 10,
                          color: _W.muted,
                          height: 1.5,
                        ),
                      ),
                      const SizedBox(height: 16),
                      // Input nomor
                      ClipRRect(
                        borderRadius: BorderRadius.circular(14),
                        child: BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                          child: CupertinoTextField(
                            controller: _verifiedCtrl,
                            keyboardType: TextInputType.phone,
                            style: TextStyle(fontSize: 15, color: Colors.white),
                            placeholder: 'Nomor akun (62812xxxxxxx)',
                            placeholderStyle:
                                TextStyle(fontSize: 13, color: _W.muted2),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 12),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.06),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: _W.glassLine),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      // Button tambah
                      GestureDetector(
                        onTap: () async {
                          if (_verifiedCtrl.text.trim().isEmpty) return;
                          await WaVerifiedStore.add(_verifiedCtrl.text);
                          // Fullstack: kirim juga ke server agar semua device ikut
                          WaVerifiedStore.pushAddToServer(_verifiedCtrl.text);
                          _verifiedCtrl.clear();
                          await refresh();
                        },
                        child: Container(
                          width: double.infinity,
                          height: 44,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(14),
                            color: _W.iosBlue.withOpacity(0.20),
                            border: Border.all(
                                color: _W.iosBlue.withOpacity(0.5)),
                          ),
                          child: Center(
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(CupertinoIcons.add_circled_solid,
                                    color: _W.iosBlue, size: 17),
                                const SizedBox(width: 7),
                                Text(
                                  'Registrasi Centang Biru',
                                  style: TextStyle(
                                    fontSize: 13.5,
                                    fontWeight: FontWeight.w700,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      // List akun terdaftar
                      ValueListenableBuilder<Set<String>>(
                        valueListenable: WaVerifiedStore.accounts,
                        builder: (context, accounts, _) {
                          if (accounts.isEmpty) {
                            return Padding(
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              child: Center(
                                child: Text(
                                  'Belum ada akun terdaftar',
                                  style: TextStyle(
                                    fontFamily: 'ShareTechMono',
                                    fontSize: 11,
                                    color: _W.muted2,
                                  ),
                                ),
                              ),
                            );
                          }
                          return ConstrainedBox(
                            constraints: const BoxConstraints(maxHeight: 240),
                            child: ListView.builder(
                              shrinkWrap: true,
                              itemCount: accounts.length,
                              itemBuilder: (ctx2, i) {
                                final acc = accounts.elementAt(i);
                                return Container(
                                  margin: const EdgeInsets.only(bottom: 8),
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 10),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.05),
                                    borderRadius: BorderRadius.circular(13),
                                    border:
                                        Border.all(color: _W.glassLine),
                                  ),
                                  child: Row(
                                    children: [
                                      waBlueCheck(size: 15),
                                      const SizedBox(width: 9),
                                      Expanded(
                                        child: Text(
                                          '+$acc',
                                          style: TextStyle(
                                            fontSize: 13.5,
                                            fontWeight: FontWeight.w600,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                      GestureDetector(
                                        onTap: () async {
                                          await WaVerifiedStore.remove(acc);
                                          // Fullstack: hapus juga di server
                                          WaVerifiedStore.pushRemoveToServer(acc);
                                          await refresh();
                                        },
                                        child: Icon(
                                          CupertinoIcons.minus_circle_fill,
                                          color:
                                              _W.accent.withOpacity(0.85),
                                          size: 20,
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 6),
                      // Catatan
                      Row(
                        children: [
                          Icon(CupertinoIcons.info_circle,
                              color: _W.muted2, size: 13),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              'Centang cocok otomatis dengan nomor di daftar chat, status, dan channel.',
                              style: TextStyle(
                                fontFamily: 'ShareTechMono',
                                fontSize: 9,
                                color: _W.muted2,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // VIEW 3 — CHAT VIEW (iOS bubble + double centang)
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildChatView() {
    final chat = _chats.firstWhere(
      (c) => c['id'] == _openChatId,
      orElse: () => {'id': _openChatId, 'name': _openChatId},
    );
    final name = (chat['name'] ?? '').toString();
    final isGroup = chat['isGroup'] == true;
    final verified = WaVerifiedStore.isVerified(_openChatId);
    final msgs = _messages[_openChatId] ?? [];

    return Column(
      key: const ValueKey('chat'),
      children: [
        // Header glass ala iOS
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 6),
          child: _buildIosBar(
            leading: Row(
              children: [
                _glassCircleBtn(
                  CupertinoIcons.back, Colors.white, _closeChat,
                ),
                const SizedBox(width: 8),
                _buildAvatar(name, isGroup: isGroup, size: 38),
              ],
            ),
            title: name,
            subtitle: isGroup ? 'grup' : 'online',
            trailing: [
              if (verified) waBlueCheck(size: 20),
              const SizedBox(width: 6),
              _buildConnBadge(),
            ],
          ),
        ),
        // Pesan
        Expanded(
          child: msgs.isEmpty
              ? Center(
                  child: Text(
                    'Belum ada pesan.\nSync otomatis berjalan...',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontFamily: 'ShareTechMono',
                        fontSize: 11,
                        color: _W.muted),
                  ),
                )
              : ListView.builder(
                  controller: _chatScrollCtrl,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 10),
                  itemCount: msgs.length,
                  itemBuilder: (context, i) {
                    return _buildMessageBubble(msgs[i]);
                  },
                ),
        ),
        // Input bar glass
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 4, 14, 10),
          child: _glass(
            blur: 22,
            opacity: 0.09,
            radius: 26,
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: CupertinoTextField(
                    controller: _msgCtrl,
                    style: TextStyle(fontSize: 14, color: Colors.white),
                    placeholder: 'Pesan',
                    placeholderStyle:
                        TextStyle(fontSize: 13.5, color: _W.muted2),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.07),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: _W.glassLine),
                    ),
                    onSubmitted: (_) => _sendMessage(),
                  ),
                ),
                const SizedBox(width: 8),
                // Tombol kirim hijau ala WA
                GestureDetector(
                  onTap: _sendMessage,
                  child: AnimatedBuilder(
                    animation: _glowCtrl,
                    builder: (context, _) {
                      final pulse = 0.5 +
                          (math.sin(_glowCtrl.value * 2 * math.pi) * 0.5)
                              .abs();
                      return Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: [_W.waGreen, _W.waGreenDk],
                          ),
                          border: Border.all(
                            color: Colors.white.withOpacity(
                                0.25 + pulse * 0.15),
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: _W.waGreen
                                  .withOpacity(0.3 + pulse * 0.2),
                              blurRadius: 10 + pulse * 6,
                            ),
                          ],
                        ),
                        child: Icon(
                          Icons.arrow_upward_rounded,
                          color: Colors.white,
                          size: 20,
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMessageBubble(Map<String, dynamic> m) {
    final fromMe = m['fromMe'] == true;
    final text = (m['text'] ?? '').toString();
    final ts = (m['timestamp'] is int) ? m['timestamp'] as int : 0;

    return Align(
      alignment: fromMe ? Alignment.centerRight : Alignment.centerLeft,
      child: ClipRRect(
        borderRadius: BorderRadius.only(
          topLeft: const Radius.circular(18),
          topRight: const Radius.circular(18),
          bottomLeft: Radius.circular(fromMe ? 18 : 5),
          bottomRight: Radius.circular(fromMe ? 5 : 18),
        ),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding:
                const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
            constraints: BoxConstraints(
              maxWidth: MediaQuery.of(context).size.width * 0.76,
            ),
            decoration: BoxDecoration(
              // iOS WA: incoming abu gelap, outgoing hijau gelap
              color: fromMe
                  ? _W.waGreenDk.withOpacity(0.45)
                  : Colors.white.withOpacity(0.08),
              borderRadius: BorderRadius.only(
                topLeft: const Radius.circular(18),
                topRight: const Radius.circular(18),
                bottomLeft: Radius.circular(fromMe ? 18 : 5),
                bottomRight: Radius.circular(fromMe ? 5 : 18),
              ),
              border: Border.all(
                color: fromMe
                    ? _W.waGreen.withOpacity(0.3)
                    : _W.glassLine,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  text,
                  style: TextStyle(fontSize: 13.5, color: Colors.white, height: 1.4),
                ),
                const SizedBox(height: 3),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      _formatTime(ts),
                      style: TextStyle(
                        fontSize: 9.5,
                        color: Colors.white.withOpacity(0.55),
                      ),
                    ),
                    if (fromMe) ...[
                      const SizedBox(width: 3),
                      // Double centang ala WhatsApp (visual)
                      Icon(
                        Icons.done_all_rounded,
                        size: 13,
                        color: _W.waGreen.withOpacity(0.9),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
