// lib/catbox_service.dart
// Upload file ke Catbox.moe → dapet URL permanent
import 'dart:io';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:path/path.dart' as path;

class CatboxResult {
  final bool success;
  final String? url;
  final String? error;
  final String? fileHash;

  CatboxResult({required this.success, this.url, this.error, this.fileHash});

  @override
  String toString() => success ? 'OK: $url' : 'FAIL: $error';
}

class CatboxService {
  // ══════════════════════════════════════════════════════
  // ENDPOINT:
  // - catbox.moe → file permanen (gambar, video, audio, doc)
  // - litterbox.catbox.moe → file temporary (auto hapus)
  // ══════════════════════════════════════════════════════
  static const String _catboxUrl = 'https://catbox.moe/user/api.php';
  static const String _litterboxUrl =
      'https://litterbox.catbox.moe/resources/internals/api.php';

  /// Upload ke CATBOX (permanent)
  /// Support: jpg, png, gif, webp, mp4, mp3, dll
  static Future<CatboxResult> uploadFile(File file) async {
    try {
      // Validasi file ada
      if (!await file.exists()) {
        return CatboxResult(success: false, error: 'File tidak ditemukan');
      }

      // Cek ukuran file (max 200MB di catbox)
      final fileSize = await file.length();
      const maxSize = 200 * 1024 * 1024; // 200 MB
      if (fileSize > maxSize) {
        return CatboxResult(
          success: false,
          error: 'File terlalu besar (max 200MB)',
        );
      }

      // Siapin request multipart
      final request = http.MultipartRequest('POST', Uri.parse(_catboxUrl));

      // Field yang dibutuhin catbox
      request.fields['reqtype'] = 'fileupload';

      // Kalo lu punya userhash (akun catbox), bisa ditambahin:
      // request.fields['userhash'] = 'userhash_lu_disini';

      // Detect mime type
      final ext = path.extension(file.path).toLowerCase();
      final mimeType = _getMimeType(ext);

      // Attach file
      request.files.add(
        await http.MultipartFile.fromPath(
          'fileToUpload',
          file.path,
          contentType: mimeType,
        ),
      );

      // Kirim
      final streamedResponse = await request.send().timeout(
        const Duration(seconds: 60),
      );

      final response = await http.Response.fromStream(streamedResponse);

      // Catbox balikin URL plain text kalo sukses
      if (response.statusCode == 200) {
        final body = response.body.trim();
        if (body.startsWith('https://')) {
          // Extract file hash dari URL
          final hash = body.split('/').last.replaceAll(RegExp(r'\.[^.]+$'), '');
          return CatboxResult(
            success: true,
            url: body,
            fileHash: hash,
          );
        }
        return CatboxResult(
          success: false,
          error: 'Response tidak valid: $body',
        );
      }

      return CatboxResult(
        success: false,
        error: 'HTTP ${response.statusCode}: ${response.body}',
      );
    } catch (e) {
      return CatboxResult(success: false, error: 'Error: $e');
    }
  }

  /// Upload ke LITTERBOX (temporary, auto-hapus)
  /// [expiry] = '1h', '12h', '24h', '72h'
  static Future<CatboxResult> uploadTemporary(
    File file, {
    String expiry = '24h',
  }) async {
    try {
      if (!await file.exists()) {
        return CatboxResult(success: false, error: 'File tidak ditemukan');
      }

      final fileSize = await file.length();
      const maxSize = 1 * 1024 * 1024 * 1024; // 1 GB litterbox
      if (fileSize > maxSize) {
        return CatboxResult(
          success: false,
          error: 'File terlalu besar (max 1GB)',
        );
      }

      final validExpiry = ['1h', '12h', '24h', '72h'];
      if (!validExpiry.contains(expiry)) {
        expiry = '24h';
      }

      final request = http.MultipartRequest('POST', Uri.parse(_litterboxUrl));
      request.fields['reqtype'] = 'fileupload';
      request.fields['time'] = expiry;

      final ext = path.extension(file.path).toLowerCase();
      final mimeType = _getMimeType(ext);

      request.files.add(
        await http.MultipartFile.fromPath(
          'fileToUpload',
          file.path,
          contentType: mimeType,
        ),
      );

      final streamedResponse = await request.send().timeout(
        const Duration(seconds: 120),
      );

      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        final body = response.body.trim();
        if (body.startsWith('https://')) {
          return CatboxResult(success: true, url: body);
        }
        return CatboxResult(
          success: false,
          error: 'Response tidak valid: $body',
        );
      }

      return CatboxResult(
        success: false,
        error: 'HTTP ${response.statusCode}: ${response.body}',
      );
    } catch (e) {
      return CatboxResult(success: false, error: 'Error: $e');
    }
  }

  /// Upload dari bytes (kalo lu udah punya Uint8List)
  static Future<CatboxResult> uploadBytes(
    List<int> bytes,
    String filename,
  ) async {
    try {
      if (bytes.isEmpty) {
        return CatboxResult(success: false, error: 'Bytes kosong');
      }

      final request = http.MultipartRequest('POST', Uri.parse(_catboxUrl));
      request.fields['reqtype'] = 'fileupload';

      final ext = path.extension(filename).toLowerCase();
      final mimeType = _getMimeType(ext);

      request.files.add(
        http.MultipartFile.fromBytes(
          'fileToUpload',
          bytes,
          filename: filename,
          contentType: mimeType,
        ),
      );

      final streamedResponse = await request.send().timeout(
        const Duration(seconds: 60),
      );
      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        final body = response.body.trim();
        if (body.startsWith('https://')) {
          return CatboxResult(success: true, url: body);
        }
        return CatboxResult(
          success: false,
          error: 'Response tidak valid: $body',
        );
      }

      return CatboxResult(
        success: false,
        error: 'HTTP ${response.statusCode}: ${response.body}',
      );
    } catch (e) {
      return CatboxResult(success: false, error: 'Error: $e');
    }
  }

  /// Delete file dari catbox (butuh userhash)
  /// Kalo lu upload tanpa akun, gak bisa delete
  static Future<bool> deleteFile(String filename, String userhash) async {
    try {
      final request = http.MultipartRequest('POST', Uri.parse(_catboxUrl));
      request.fields['reqtype'] = 'deletefiles';
      request.fields['userhash'] = userhash;
      request.fields['files'] = filename;

      final response = await request.send();
      final body = await http.Response.fromStream(response);

      return body.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  // ══════════════════════════════════════════════════════
  // MIME TYPE DETECTOR
  // ══════════════════════════════════════════════════════
  static MediaType _getMimeType(String ext) {
    switch (ext) {
      // Images
      case '.jpg':
      case '.jpeg':
        return MediaType('image', 'jpeg');
      case '.png':
        return MediaType('image', 'png');
      case '.gif':
        return MediaType('image', 'gif');
      case '.webp':
        return MediaType('image', 'webp');
      case '.bmp':
        return MediaType('image', 'bmp');
      case '.svg':
        return MediaType('image', 'svg+xml');
      case '.heic':
        return MediaType('image', 'heic');
      case '.heif':
        return MediaType('image', 'heif');

      // Video
      case '.mp4':
        return MediaType('video', 'mp4');
      case '.mkv':
        return MediaType('video', 'x-matroska');
      case '.webm':
        return MediaType('video', 'webm');
      case '.mov':
        return MediaType('video', 'quicktime');
      case '.avi':
        return MediaType('video', 'x-msvideo');

      // Audio
      case '.mp3':
        return MediaType('audio', 'mpeg');
      case '.wav':
        return MediaType('audio', 'wav');
      case '.ogg':
        return MediaType('audio', 'ogg');
      case '.m4a':
        return MediaType('audio', 'mp4');

      // Document
      case '.pdf':
        return MediaType('application', 'pdf');
      case '.zip':
        return MediaType('application', 'zip');
      case '.rar':
        return MediaType('application', 'x-rar-compressed');

      default:
        return MediaType('application', 'octet-stream');
    }
  }
}