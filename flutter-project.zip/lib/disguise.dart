import 'package:flutter/material.dart';

class DisguiseApp extends StatelessWidget {
  const DisguiseApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 32),
                const Icon(Icons.system_update, size: 48, color: Colors.blue),
                const SizedBox(height: 16),
                const Text('System Update',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text('Your device is up to date.',
                  style: TextStyle(fontSize: 14, color: Colors.black54)),
                const Spacer(),
                SizedBox(
                  width: double.infinity, height: 48,
                  child: FilledButton(
                    onPressed: () {},
                    child: const Text('Check for updates'),
                  ),
                ),
                const SizedBox(height: 8),
                const Center(
                  child: Text('Version 2.4.1 (build 8821)',
                      style: TextStyle(fontSize: 11, color: Colors.black38)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}