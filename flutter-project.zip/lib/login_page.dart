// lib/login_page.dart
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'app_theme.dart';
import 'smart_widgets.dart';
import 'video_splash_page.dart';
import 'buy_access_page.dart';
import 'api_config.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePass = true;
  String? androidId;

  late AnimationController _entryCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _shakeCtrl;
  late AnimationController _ledCtrl;
  late AnimationController _gaugeCtrl;

  late Animation<double> _logoFade;
  late Animation<double> _logoScale;
  late Animation<double> _formFade;
  late Animation<Offset> _formSlide;
  late Animation<double> _shake;
  late Animation<double> _ledBlink;
  late Animation<double> _gaugeSweep;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _initAutoLogin();
  }

  void _setupAnimations() {
    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..forward();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _shakeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
    )..repeat();

    _ledCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);

    _gaugeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2500),
    )..repeat();

    _logoFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _entryCtrl,
        curve: const Interval(0.0, 0.5, curve: Curves.easeOut),
      ),
    );
    _logoScale = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(
        parent: _entryCtrl,
        curve: const Interval(0.0, 0.7, curve: Curves.elasticOut),
      ),
    );
    _formFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _entryCtrl,
        curve: const Interval(0.4, 0.9, curve: Curves.easeOut),
      ),
    );
    _formSlide = Tween<Offset>(
      begin: const Offset(0, 0.1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _entryCtrl,
      curve: const Interval(0.35, 0.95, curve: Curves.easeOutBack),
    ));
    _shake = Tween<double>(begin: -1.0, end: 1.0).animate(
      CurvedAnimation(parent: _shakeCtrl, curve: Curves.linear),
    );
    _ledBlink = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _ledCtrl, curve: Curves.easeInOut),
    );
    _gaugeSweep = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _gaugeCtrl, curve: Curves.linear),
    );
  }

  Future<void> _initAutoLogin() async {
    androidId = await _getAndroidId();
    final prefs = await SharedPreferences.getInstance();
    final u = prefs.getString("username");
    final p = prefs.getString("password");
    final k = prefs.getString("key");

    if (u != null && p != null && k != null) {
      try {
        final res = await http.get(Uri.parse(
            "$baseUrl/myInfo?username=$u&password=$p&androidId=$androidId&key=$k"));
        final data = jsonDecode(res.body);
        if (data['valid'] == true) _goToSplash(_buildArgs(data, u, p));
      } catch (_) {}
    }
  }

  Future<String> _getAndroidId() async {
    final android = await DeviceInfoPlugin().androidInfo;
    return android.id ?? "unknown_device";
  }

  Map<String, dynamic> _buildArgs(dynamic data, String u, String p) => {
        "username": u,
        "password": p,
        "role": data['role'],
        "key": data['key'],
        "expiredDate": data['expiredDate'],
        "listBug": (data['listBug'] as List? ?? [])
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList(),
        "listDoos": (data['listDDoS'] as List? ?? [])
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList(),
        "news": (data['news'] as List? ?? [])
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList(),
      };

  void _goToSplash(Map<String, dynamic> args) {
    if (!mounted) return;
    Navigator.pushReplacement(context,
        MaterialPageRoute(builder: (_) => VideoSplashPage(dashboardArgs: args)));
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    final u = userController.text.trim();
    final p = passController.text.trim();
    setState(() => isLoading = true);

    try {
      final res = await http.post(
        Uri.parse("$baseUrl/validate"),
        body: {
          "username": u,
          "password": p,
          "androidId": androidId ?? "unknown"
        },
      );
      final data = jsonDecode(res.body);

      if (data['expired'] == true) {
        _showAlert(
            "ACCESS EXPIRED",
            "Masa akses Anda telah habis.\nSilakan perpanjang akses.",
            showContact: true);
      } else if (data['valid'] != true) {
        final msg = (data['message'] ?? "").toLowerCase();
        _showAlert(
          "LOGIN GAGAL",
          msg.contains("perangkat") || msg.contains("device")
              ? "Akun ini sedang login di perangkat lain."
              : "Username atau password salah.",
        );
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", u);
        prefs.setString("password", p);
        prefs.setString("key", data['key']);
        _goToSplash(_buildArgs(data, u, p));
      }
    } catch (_) {
      _showAlert("CONNECTION ERROR", "Gagal terhubung ke server.");
    }
    if (mounted) setState(() => isLoading = false);
  }

  void _showAlert(String title, String message,
      {bool showContact = false}) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => StyleBuilder(
        builder: (ctx, C, kit) {
          final isComic = kit.style == ThemeStyle.comic3d;

          return Dialog(
            backgroundColor: Colors.transparent,
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(isComic ? 24 : 20),
                gradient: isComic
                    ? null
                    : LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [C.bg, C.bgDark],
                      ),
                color: isComic ? C.bgDark : null,
                border: isComic
                    ? Border.all(color: Colors.black, width: 4)
                    : null,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.7),
                    offset: isComic ? const Offset(8, 8) : const Offset(0, 12),
                    blurRadius: isComic ? 0 : 30,
                  ),
                  if (!isComic)
                    BoxShadow(
                      color: Colors.white.withOpacity(0.08),
                      offset: const Offset(-2, -2),
                      blurRadius: 6,
                    ),
                ],
              ),
              child: Container(
                margin: EdgeInsets.all(isComic ? 0 : 4),
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(isComic ? 20 : 16),
                  gradient: isComic
                      ? null
                      : LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [C.bgDark, C.bgDeep],
                        ),
                  color: isComic ? C.bgDark : null,
                  border: Border.all(
                    color: isComic
                        ? Colors.black
                        : C.textSub.withOpacity(0.3),
                    width: isComic ? 3 : 1,
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(isComic ? 12 : 30),
                        gradient: isComic
                            ? null
                            : LinearGradient(
                                colors: [
                                  C.primaryHi,
                                  C.primary,
                                  C.primaryLo
                                ],
                              ),
                        color: isComic ? C.primaryHi : null,
                        border: isComic
                            ? Border.all(color: Colors.black, width: 3)
                            : null,
                        boxShadow: isComic
                            ? const [
                                BoxShadow(
                                  color: Colors.black,
                                  offset: Offset(3, 3),
                                  blurRadius: 0,
                                ),
                              ]
                            : [
                                BoxShadow(
                                  color: C.primary.withOpacity(0.6),
                                  blurRadius: 15,
                                  spreadRadius: 1,
                                ),
                              ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SmartLed(color: C.accent, size: 8),
                          const SizedBox(width: 8),
                          Text(
                            title,
                            style: TextStyle(
                              color: isComic
                                  ? C.contrastTextOn(C.primaryHi)
                                  : C.text,
                              fontFamily:
                                  isComic ? 'Bangers' : 'Orbitron',
                              fontWeight: FontWeight.w900,
                              fontSize: isComic ? 15 : 12,
                              letterSpacing: isComic ? 1 : 2,
                              shadows: isComic
                                  ? [
                                      Shadow(
                                        color: C.contrastTextOn(C.primaryHi) ==
                                                Colors.white
                                            ? Colors.black
                                            : Colors.white,
                                        offset: const Offset(1, 1),
                                        blurRadius: 0,
                                      ),
                                    ]
                                  : const [
                                      Shadow(
                                        color: Colors.black54,
                                        offset: Offset(0, 1),
                                        blurRadius: 2,
                                      ),
                                    ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      message,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: isComic ? C.comicText : C.text,
                        fontSize: 13,
                        height: 1.6,
                        fontFamily:
                            isComic ? 'ComicNeue' : 'ShareTechMono',
                        letterSpacing: 0.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 24),
                    Row(
                      children: [
                        if (showContact) ...[
                          Expanded(
                            child: SmartButton(
                              onTap: () => launchUrl(
                                Uri.parse("https://t.me/KaizennTzy"),
                                mode: LaunchMode.externalApplication,
                              ),
                              color: C.textSub,
                              height: 46,
                              child: Text(
                                'CONTACT',
                                style: TextStyle(
                                  color: C.comicText,
                                  fontFamily:
                                      isComic ? 'Bangers' : 'Orbitron',
                                  fontWeight: FontWeight.w900,
                                  fontSize: isComic ? 14 : 11,
                                  letterSpacing: isComic ? 1 : 2,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                        ],
                        Expanded(
                          child: SmartButton(
                            onTap: () => Navigator.pop(ctx),
                            color: C.primaryHi,
                            height: 46,
                            child: Text(
                              'TUTUP',
                              style: TextStyle(
                                color: C.comicText,
                                fontFamily:
                                    isComic ? 'Bangers' : 'Orbitron',
                                fontWeight: FontWeight.w900,
                                fontSize: isComic ? 14 : 11,
                                letterSpacing: isComic ? 1 : 2,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    _pulseCtrl.dispose();
    _shakeCtrl.dispose();
    _ledCtrl.dispose();
    _gaugeCtrl.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StyleBuilder(
      builder: (context, C, kit) {
        final isComic = kit.style == ThemeStyle.comic3d;
        final size = MediaQuery.of(context).size;
        final h = size.height;

        return Scaffold(
          backgroundColor: C.bg,
          resizeToAvoidBottomInset: true,
          body: Stack(
            children: [
              Positioned.fill(
                child: Image.asset(
                  'assets/images/login.png',
                  fit: BoxFit.cover,
                ),
              ),
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      center: Alignment.center,
                      radius: 1.0,
                      colors: isComic
                          ? [
                              Colors.black.withOpacity(0.3),
                              Colors.black.withOpacity(0.6),
                              Colors.black.withOpacity(0.85),
                            ]
                          : [
                              Colors.black.withOpacity(0.5),
                              Colors.black.withOpacity(0.85),
                              Colors.black.withOpacity(0.95),
                            ],
                    ),
                  ),
                ),
              ),
              if (!isComic)
                Positioned.fill(
                  child: IgnorePointer(
                    child: CustomPaint(
                      painter: _LeatherTexturePainter(),
                    ),
                  ),
                ),
              if (isComic)
                Positioned.fill(
                  child: IgnorePointer(
                    child: CustomPaint(
                      painter: _HalftonePainter(
                          color: C.primaryLo.withOpacity(0.08)),
                    ),
                  ),
                ),
              SafeArea(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Column(
                      children: [
                        SizedBox(height: h * 0.02),
                        FadeTransition(
                          opacity: _logoFade,
                          child: ScaleTransition(
                            scale: _logoScale,
                            child: _SkeuoLogoPlaque(
                              C: C,
                              isComic: isComic,
                            ),
                          ),
                        ),
                        SizedBox(height: h * 0.03),
                        FadeTransition(
                          opacity: _formFade,
                          child: SlideTransition(
                            position: _formSlide,
                            child: _SkeuoControlPanel(
                              C: C,
                              isComic: isComic,
                              formKey: _formKey,
                              userController: userController,
                              passController: passController,
                              obscurePass: _obscurePass,
                              onTogglePass: () => setState(
                                  () => _obscurePass = !_obscurePass),
                              isLoading: isLoading,
                              onLogin: _login,
                              shake: _shake,
                              ledBlink: _ledBlink,
                              gaugeSweep: _gaugeSweep,
                              onBuyAccount: () => Navigator.push(
                                context,
                                PageRouteBuilder(
                                  pageBuilder: (_, __, ___) =>
                                      const BuyAccessPage(),
                                  transitionDuration:
                                      const Duration(milliseconds: 350),
                                  transitionsBuilder:
                                      (_, anim, __, child) =>
                                          SlideTransition(
                                    position: Tween<Offset>(
                                      begin: const Offset(1, 0),
                                      end: Offset.zero,
                                    ).animate(CurvedAnimation(
                                      parent: anim,
                                      curve: Curves.easeOutCubic,
                                    )),
                                    child: FadeTransition(
                                        opacity: anim, child: child),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: h * 0.03),
                        FadeTransition(
                          opacity: _formFade,
                          child: _SkeuoFooter(C: C, isComic: isComic),
                        ),
                        const SizedBox(height: 50),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}


// ════════════════════════════════════════════════════════════
// LOGO PLAQUE
// ════════════════════════════════════════════════════════════
class _SkeuoLogoPlaque extends StatelessWidget {
  final AppPalette C;
  final bool isComic;
  const _SkeuoLogoPlaque({required this.C, required this.isComic});

  @override
  Widget build(BuildContext context) {
    if (isComic) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: C.primaryHi,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.black, width: 5),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(8, 8),
              blurRadius: 0,
            ),
          ],
        ),
        child: Column(
          children: [
            Stack(
              alignment: Alignment.center,
              clipBehavior: Clip.none,
              children: [
                Container(
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    border: Border.all(color: Colors.black, width: 5),
                  ),
                  child: ClipOval(
                    child: Image.asset(
                      'assets/images/logo.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                ..._buildComicDots(),
              ],
            ),
            const SizedBox(height: 20),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.black, width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(3, 3),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: Text(
                "SYAX",
                style: TextStyle(
                  fontFamily: 'Bangers',
                  fontWeight: FontWeight.w900,
                  fontSize: 26,
                  letterSpacing: 2,
                  color: C.bgDeep,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: C.accent,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.black, width: 3),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(3, 3),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SmartLed(color: C.bgDeep, size: 8),
                  const SizedBox(width: 8),
                  Text(
                    "SYSTEM ONLINE",
                    style: TextStyle(
                      color: Colors.white,
                      fontFamily: 'Bangers',
                      fontSize: 12,
                      letterSpacing: 2,
                      shadows: const [
                        Shadow(
                          color: Colors.black,
                          offset: Offset(1, 1),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  SmartLed(color: C.bgDeep, size: 8),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.text, C.bg, C.bgDark],
          stops: const [0.0, 0.5, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.8),
            offset: const Offset(0, 15),
            blurRadius: 30,
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.15),
            offset: const Offset(-2, -2),
            blurRadius: 6,
          ),
        ],
      ),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [C.primaryLo, C.primaryLo.withOpacity(0.7)],
          ),
          border: Border.all(
            color: C.bgDark.withOpacity(0.5),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.6),
              offset: const Offset(0, 4),
              blurRadius: 8,
              spreadRadius: -2,
            ),
          ],
        ),
        child: Column(
          children: [
            Stack(
              alignment: Alignment.center,
              clipBehavior: Clip.none,
              children: [
                Container(
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [C.text, C.textSub, C.bg, C.bgDark],
                      stops: const [0.0, 0.4, 0.7, 1.0],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.8),
                        offset: const Offset(0, 8),
                        blurRadius: 16,
                      ),
                      BoxShadow(
                        color: Colors.white.withOpacity(0.2),
                        offset: const Offset(-3, -3),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                  child: Container(
                    margin: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [C.bgDeep, C.bgDark],
                      ),
                      border: Border.all(
                        color: C.accent.withOpacity(0.6),
                        width: 2,
                      ),
                    ),
                    child: ClipOval(
                      child: Image.asset(
                        'assets/images/logo.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),
                ..._buildRivets(C, radius: 62),
              ],
            ),
            const SizedBox(height: 20),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [C.textSub, C.bg, C.bgDark],
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.7),
                    offset: const Offset(0, 3),
                    blurRadius: 6,
                  ),
                ],
              ),
              child: Stack(
                children: [
                  Transform.translate(
                    offset: const Offset(1, 1),
                    child: Text(
                      "SYAX",
                      style: TextStyle(
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 24,
                        letterSpacing: 3,
                        color: Colors.white.withOpacity(0.9),
                        height: 1,
                      ),
                    ),
                  ),
                  Text(
                    "SYAX",
                    style: TextStyle(
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: 24,
                      letterSpacing: 3,
                      color: C.bgDark,
                      height: 1,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: C.bgDeep,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.8),
                    offset: const Offset(0, 2),
                    blurRadius: 4,
                  ),
                ],
                border: Border.all(
                  color: C.bgDark,
                  width: 1,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SmartLed(color: C.primaryHi, size: 7),
                  const SizedBox(width: 8),
                  Text(
                    "SYSTEM ONLINE",
                    style: TextStyle(
                      color: C.accent.withOpacity(0.9),
                      fontFamily: 'ShareTechMono',
                      fontSize: 10,
                      letterSpacing: 2,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(width: 8),
                  SmartLed(color: C.accent, size: 7),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildComicDots() {
    return [
      Positioned(
        top: -8,
        left: -8,
        child: Container(
          width: 20,
          height: 20,
          decoration: BoxDecoration(
            color: C.accent,
            shape: BoxShape.circle,
            border: Border.all(color: Colors.black, width: 3),
          ),
        ),
      ),
      Positioned(
        top: -8,
        right: -8,
        child: Container(
          width: 16,
          height: 16,
          decoration: BoxDecoration(
            color: C.accentShine,
            shape: BoxShape.circle,
            border: Border.all(color: Colors.black, width: 3),
          ),
        ),
      ),
    ];
  }

  List<Widget> _buildRivets(AppPalette C, {required double radius}) {
    final rivets = <Widget>[];
    for (int i = 0; i < 8; i++) {
      final angle = (i * math.pi * 2 / 8) - math.pi / 2;
      final x = math.cos(angle) * radius;
      final y = math.sin(angle) * radius;
      rivets.add(
        Positioned(
          left: 55 + x - 6,
          top: 55 + y - 6,
          child: SmartRivet(size: 12),
        ),
      );
    }
    return rivets;
  }
}

// ════════════════════════════════════════════════════════════
// CONTROL PANEL
// ════════════════════════════════════════════════════════════
class _SkeuoControlPanel extends StatelessWidget {
  final AppPalette C;
  final bool isComic;
  final GlobalKey<FormState> formKey;
  final TextEditingController userController;
  final TextEditingController passController;
  final bool obscurePass;
  final VoidCallback onTogglePass;
  final bool isLoading;
  final VoidCallback onLogin;
  final Animation<double> shake;
  final Animation<double> ledBlink;
  final Animation<double> gaugeSweep;
  final VoidCallback onBuyAccount;

  const _SkeuoControlPanel({
    required this.C,
    required this.isComic,
    required this.formKey,
    required this.userController,
    required this.passController,
    required this.obscurePass,
    required this.onTogglePass,
    required this.isLoading,
    required this.onLogin,
    required this.shake,
    required this.ledBlink,
    required this.gaugeSweep,
    required this.onBuyAccount,
  });

  @override
  Widget build(BuildContext context) {
    if (isComic) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: C.bgDark,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.black, width: 5),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(8, 8),
              blurRadius: 0,
            ),
          ],
        ),
        child: Form(
          key: formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: C.primaryHi,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.black, width: 4),
                ),
                child: Text(
                  "AUTHENTICATION",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Bangers',
                    fontSize: 18,
                    letterSpacing: 2,
                    shadows: const [
                      Shadow(
                        color: Colors.black,
                        offset: Offset(1, 1),
                        blurRadius: 0,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              _ComicField(
                C: C,
                controller: userController,
                hint: "USERNAME",
                icon: Icons.person,
                validator: (v) =>
                    (v == null || v.trim().isEmpty)
                        ? "Username wajib diisi!"
                        : null,
              ),
              const SizedBox(height: 14),
              _ComicField(
                C: C,
                controller: passController,
                hint: "PASSWORD",
                icon: Icons.lock,
                obscure: obscurePass,
                validator: (v) =>
                    (v == null || v.trim().isEmpty)
                        ? "Password wajib diisi!"
                        : null,
                suffix: GestureDetector(
                  onTap: onTogglePass,
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: C.accent,
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.black, width: 2),
                    ),
                    child: Icon(
                      obscurePass
                          ? Icons.visibility_off
                          : Icons.visibility,
                      color: Colors.white,
                      size: 14,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              _ComicLoginButton(
                C: C,
                isLoading: isLoading,
                onTap: onLogin,
              ),
              const SizedBox(height: 18),
              _ComicBuyButton(C: C, onTap: onBuyAccount),
            ],
          ),
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.text, C.bg, C.bgDark],
          stops: const [0.0, 0.5, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.8),
            offset: const Offset(0, 15),
            blurRadius: 30,
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.15),
            offset: const Offset(-2, -2),
            blurRadius: 6,
          ),
        ],
      ),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark],
          ),
          border: Border.all(
            color: Colors.black.withOpacity(0.5),
            width: 1.5,
          ),
        ),
        child: Form(
          key: formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _PanelHeader(C: C, ledBlink: ledBlink),
              const SizedBox(height: 20),
              _SkeuoField(
                C: C,
                controller: userController,
                hint: "USERNAME",
                icon: Icons.person,
                validator: (v) =>
                    (v == null || v.trim().isEmpty)
                        ? "Username wajib diisi!"
                        : null,
              ),
              const SizedBox(height: 14),
              _SkeuoField(
                C: C,
                controller: passController,
                hint: "PASSWORD",
                icon: Icons.lock,
                obscure: obscurePass,
                validator: (v) =>
                    (v == null || v.trim().isEmpty)
                        ? "Password wajib diisi!"
                        : null,
                suffix: _SkeuoIconButton(
                  C: C,
                  icon: obscurePass
                      ? Icons.visibility_off
                      : Icons.visibility,
                  onTap: onTogglePass,
                ),
              ),
              const SizedBox(height: 20),
              _GaugeMeter(C: C, sweep: gaugeSweep),
              const SizedBox(height: 20),
              _SkeuoLoginButton(
                C: C,
                isLoading: isLoading,
                onTap: onLogin,
                shake: shake,
              ),
              const SizedBox(height: 18),
              _SkeuoBuyButton(C: C, onTap: onBuyAccount),
            ],
          ),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
// COMIC FIELD
// ════════════════════════════════════════════════════════════
class _ComicField extends StatelessWidget {
  final AppPalette C;
  final TextEditingController controller;
  final String hint;
  final IconData icon;
  final bool obscure;
  final Widget? suffix;
  final String? Function(String?)? validator;

  const _ComicField({
    required this.C,
    required this.controller,
    required this.hint,
    required this.icon,
    this.obscure = false,
    this.suffix,
    this.validator,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.black, width: 4),
      ),
      child: TextFormField(
        controller: controller,
        obscureText: obscure,
        validator: validator,
        style: TextStyle(
          color: C.bgDeep,
          fontSize: 15,
          fontFamily: 'ComicNeue',
          fontWeight: FontWeight.w700,
          letterSpacing: 1,
        ),
        cursorColor: C.bgDeep,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(
            color: C.bgDeep.withOpacity(0.5),
            fontSize: 13,
            fontFamily: 'Bangers',
            letterSpacing: 2,
          ),
          prefixIcon: Container(
            padding: const EdgeInsets.all(10),
            child: Icon(icon, color: C.bgDeep, size: 20),
          ),
          prefixIconConstraints:
              const BoxConstraints(minWidth: 46, minHeight: 46),
          suffixIcon: suffix != null
              ? Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: suffix,
                )
              : null,
          suffixIconConstraints: const BoxConstraints(),
          border: InputBorder.none,
          enabledBorder: InputBorder.none,
          focusedBorder: InputBorder.none,
          errorBorder: InputBorder.none,
          focusedErrorBorder: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 12, vertical: 18),
          errorStyle: TextStyle(
            color: C.accent,
            fontSize: 11,
            fontFamily: 'Bangers',
            fontWeight: FontWeight.w900,
            letterSpacing: 1,
          ),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
// SKEUO FIELD
// ════════════════════════════════════════════════════════════
class _SkeuoField extends StatefulWidget {
  final AppPalette C;
  final TextEditingController controller;
  final String hint;
  final IconData icon;
  final bool obscure;
  final Widget? suffix;
  final String? Function(String?)? validator;

  const _SkeuoField({
    required this.C,
    required this.controller,
    required this.hint,
    required this.icon,
    this.obscure = false,
    this.suffix,
    this.validator,
  });

  @override
  State<_SkeuoField> createState() => _SkeuoFieldState();
}

class _SkeuoFieldState extends State<_SkeuoField> {
  bool _focused = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors:
              _focused ? [C.bgDark, C.bg] : [C.bgDeep, C.bgDark],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.9),
            offset: const Offset(0, 2),
            blurRadius: 4,
          ),
          const BoxShadow(
            color: Colors.white10,
            offset: Offset(0, -1),
            blurRadius: 1,
          ),
          if (_focused)
            BoxShadow(
              color: C.primaryHi.withOpacity(0.5),
              blurRadius: 12,
            ),
        ],
        border: Border.all(
          color: _focused ? C.primary : C.bgDark,
          width: 1.5,
        ),
      ),
      child: Focus(
        onFocusChange: (v) => setState(() => _focused = v),
        child: TextFormField(
          controller: widget.controller,
          obscureText: widget.obscure,
          validator: widget.validator,
          style: TextStyle(
            color: C.text,
            fontSize: 14,
            fontFamily: 'ShareTechMono',
            fontWeight: FontWeight.w700,
            letterSpacing: 1.5,
          ),
          cursorColor: C.accent,
          decoration: InputDecoration(
            hintText: widget.hint,
            hintStyle: TextStyle(
              color: C.textSub.withOpacity(0.6),
              fontSize: 12,
              fontFamily: 'ShareTechMono',
              fontWeight: FontWeight.w700,
              letterSpacing: 3,
            ),
            prefixIcon: Container(
              margin: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: _focused
                      ? [C.primaryHi, C.primaryLo]
                      : [C.textSub, C.bgDark],
                ),
              ),
              child: Icon(
                widget.icon,
                color: _focused ? C.accent : C.text,
                size: 18,
              ),
            ),
            prefixIconConstraints:
                const BoxConstraints(minWidth: 46, minHeight: 46),
            suffixIcon: widget.suffix != null
                ? Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: widget.suffix,
                  )
                : null,
            suffixIconConstraints: const BoxConstraints(),
            border: InputBorder.none,
            enabledBorder: InputBorder.none,
            focusedBorder: InputBorder.none,
            errorBorder: InputBorder.none,
            focusedErrorBorder: InputBorder.none,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 18),
            errorStyle: TextStyle(
              color: C.primaryHi,
              fontSize: 10,
              fontFamily: 'ShareTechMono',
              fontWeight: FontWeight.w900,
              letterSpacing: 1,
            ),
          ),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
// PANEL HEADER
// ════════════════════════════════════════════════════════════
class _PanelHeader extends StatelessWidget {
  final AppPalette C;
  final Animation<double> ledBlink;
  const _PanelHeader({required this.C, required this.ledBlink});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [C.bg, C.bgDark],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            offset: const Offset(0, 3),
            blurRadius: 6,
          ),
          const BoxShadow(
            color: Colors.white24,
            offset: Offset(0, -1),
            blurRadius: 2,
          ),
        ],
      ),
      child: Row(
        children: [
          SmartScrew(size: 14),
          const SizedBox(width: 10),
          AnimatedBuilder(
            animation: ledBlink,
            builder: (_, __) => SmartLed(
              color: C.primaryHi,
              size: 10,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Center(
              child: Text(
                "AUTHENTICATION",
                style: TextStyle(
                  color: C.accent.withOpacity(0.85),
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  fontSize: 11,
                  letterSpacing: 3,
                  shadows: const [
                    Shadow(
                      color: Colors.black,
                      offset: Offset(0, 1),
                      blurRadius: 2,
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          AnimatedBuilder(
            animation: ledBlink,
            builder: (_, __) => SmartLed(
              color: C.accent,
              size: 10,
            ),
          ),
          const SizedBox(width: 10),
          SmartScrew(size: 14),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
// SKEUO ICON BUTTON
// ════════════════════════════════════════════════════════════
class _SkeuoIconButton extends StatefulWidget {
  final AppPalette C;
  final IconData icon;
  final VoidCallback onTap;
  const _SkeuoIconButton({
    required this.C,
    required this.icon,
    required this.onTap,
  });

  @override
  State<_SkeuoIconButton> createState() => _SkeuoIconButtonState();
}

class _SkeuoIconButtonState extends State<_SkeuoIconButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 100),
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          gradient: LinearGradient(
            begin: _pressed ? Alignment.bottomRight : Alignment.topLeft,
            end: _pressed ? Alignment.topLeft : Alignment.bottomRight,
            colors:
                _pressed ? [C.bgDark, C.bg] : [C.textSub, C.bgDark],
          ),
          boxShadow: _pressed
              ? [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.8),
                    offset: const Offset(0, 1),
                    blurRadius: 3,
                  ),
                ]
              : [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.7),
                    offset: const Offset(0, 3),
                    blurRadius: 5,
                  ),
                  const BoxShadow(
                    color: Colors.white24,
                    offset: Offset(0, -1),
                    blurRadius: 1,
                  ),
                ],
        ),
        child: Icon(
          widget.icon,
          color: C.accent,
          size: 16,
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
// GAUGE METER
// ════════════════════════════════════════════════════════════
class _GaugeMeter extends StatelessWidget {
  final AppPalette C;
  final Animation<double> sweep;
  const _GaugeMeter({required this.C, required this.sweep});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: C.bgDeep,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.9),
            offset: const Offset(0, 2),
            blurRadius: 4,
          ),
          const BoxShadow(
            color: Colors.white12,
            offset: Offset(0, -1),
            blurRadius: 1,
          ),
        ],
        border: Border.all(color: C.bgDark, width: 1),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Text(
                "SECURITY",
                style: TextStyle(
                  color: C.textSub.withOpacity(0.7),
                  fontFamily: 'ShareTechMono',
                  fontSize: 9,
                  letterSpacing: 2,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const Spacer(),
              Text(
                "ENCRYPTED",
                style: TextStyle(
                  color: C.accent.withOpacity(0.8),
                  fontFamily: 'ShareTechMono',
                  fontSize: 9,
                  letterSpacing: 2,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          AnimatedBuilder(
            animation: sweep,
            builder: (_, __) => CustomPaint(
              size: const Size(double.infinity, 8),
              painter: _GaugePainter(C: C, progress: sweep.value),
            ),
          ),
        ],
      ),
    );
  }
}

class _GaugePainter extends CustomPainter {
  final AppPalette C;
  final double progress;
  _GaugePainter({required this.C, required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final trackRect = Rect.fromLTWH(0, 0, size.width, size.height);
    final trackRRect = RRect.fromRectAndRadius(
      trackRect,
      const Radius.circular(4),
    );
    canvas.drawRRect(trackRRect, Paint()..color = Colors.black);

    final fillWidth = size.width * (0.3 + 0.7 * progress);
    final fillRect = Rect.fromLTWH(0, 0, fillWidth, size.height);
    final fillRRect = RRect.fromRectAndRadius(
      fillRect,
      const Radius.circular(4),
    );
    final fillPaint = Paint()
      ..shader = LinearGradient(
        colors: [C.primaryLo, C.primary, C.primaryHi, C.accent],
      ).createShader(fillRect);
    canvas.drawRRect(fillRRect, fillPaint);

    final shineRect = Rect.fromLTWH(0, 0, fillWidth, size.height * 0.4);
    canvas.drawRRect(
      RRect.fromRectAndRadius(shineRect, const Radius.circular(4)),
      Paint()..color = Colors.white.withOpacity(0.15),
    );
  }

  @override
  bool shouldRepaint(_GaugePainter old) =>
      old.progress != progress || old.C != C;
}


// ════════════════════════════════════════════════════════════
// COMIC LOGIN BUTTON
// ════════════════════════════════════════════════════════════
class _ComicLoginButton extends StatefulWidget {
  final AppPalette C;
  final bool isLoading;
  final VoidCallback onTap;
  const _ComicLoginButton({
    required this.C,
    required this.isLoading,
    required this.onTap,
  });

  @override
  State<_ComicLoginButton> createState() => _ComicLoginButtonState();
}

class _ComicLoginButtonState extends State<_ComicLoginButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        if (!widget.isLoading) widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 100),
        height: 62,
        transform: Matrix4.translationValues(
          _pressed ? 4 : 0,
          _pressed ? 4 : 0,
          0,
        ),
        decoration: BoxDecoration(
          color: widget.isLoading ? C.bgDark : C.primaryHi,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: _pressed
              ? []
              : const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(5, 5),
                    blurRadius: 0,
                  ),
                ],
        ),
        child: Center(
          child: widget.isLoading
              ? Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 3,
                        valueColor: AlwaysStoppedAnimation<Color>(
                            Colors.white),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Text(
                      "LOADING...",
                      style: TextStyle(
                        color: Colors.white,
                        fontFamily: 'Bangers',
                        fontWeight: FontWeight.w900,
                        fontSize: 18,
                        letterSpacing: 3,
                        shadows: const [
                          Shadow(
                            color: Colors.black,
                            offset: Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                    ),
                  ],
                )
              : Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.power_settings_new,
                      color: Colors.white,
                      size: 24,
                      shadows: const [
                        Shadow(
                          color: Colors.black,
                          offset: Offset(2, 2),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    const SizedBox(width: 14),
                    Text(
                      "LOGIN",
                      style: TextStyle(
                        color: Colors.white,
                        fontFamily: 'Bangers',
                        fontWeight: FontWeight.w900,
                        fontSize: 24,
                        letterSpacing: 6,
                        shadows: const [
                          Shadow(
                            color: Colors.black,
                            offset: Offset(2, 2),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 14),
                    Icon(
                      Icons.arrow_forward,
                      color: Colors.white,
                      size: 22,
                      shadows: const [
                        Shadow(
                          color: Colors.black,
                          offset: Offset(2, 2),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
// SKEUO LOGIN BUTTON
// ════════════════════════════════════════════════════════════
class _SkeuoLoginButton extends StatefulWidget {
  final AppPalette C;
  final bool isLoading;
  final VoidCallback onTap;
  final Animation<double> shake;
  const _SkeuoLoginButton({
    required this.C,
    required this.isLoading,
    required this.onTap,
    required this.shake,
  });

  @override
  State<_SkeuoLoginButton> createState() => _SkeuoLoginButtonState();
}

class _SkeuoLoginButtonState extends State<_SkeuoLoginButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    return AnimatedBuilder(
      animation: widget.shake,
      builder: (_, __) => Transform.translate(
        offset: Offset(
            widget.isLoading ? widget.shake.value * 2 : 0, 0),
        child: GestureDetector(
          onTapDown: (_) => setState(() => _pressed = true),
          onTapUp: (_) {
            setState(() => _pressed = false);
            if (!widget.isLoading) widget.onTap();
          },
          onTapCancel: () => setState(() => _pressed = false),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 100),
            height: 62,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: LinearGradient(
                begin: _pressed
                    ? Alignment.bottomCenter
                    : Alignment.topCenter,
                end: _pressed
                    ? Alignment.topCenter
                    : Alignment.bottomCenter,
                colors: widget.isLoading
                    ? [C.bg, C.bgDark]
                    : [
                        C.primaryHi,
                        C.primaryHi,
                        C.primary,
                        C.primaryLo,
                      ],
                stops: widget.isLoading
                    ? null
                    : const [0.0, 0.3, 0.6, 1.0],
              ),
              boxShadow: _pressed
                  ? [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.8),
                        offset: const Offset(0, 2),
                        blurRadius: 4,
                      ),
                    ]
                  : [
                      BoxShadow(
                        color: C.primaryHi.withOpacity(0.4),
                        offset: const Offset(0, 8),
                        blurRadius: 20,
                        spreadRadius: -2,
                      ),
                      BoxShadow(
                        color: Colors.black.withOpacity(0.8),
                        offset: const Offset(0, 6),
                        blurRadius: 10,
                      ),
                    ],
              border: Border.all(
                color: C.primaryLo,
                width: 2,
              ),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Positioned(
                  top: 4,
                  left: 12,
                  right: 12,
                  child: Container(
                    height: 14,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.white.withOpacity(0.4),
                          Colors.white.withOpacity(0.0),
                        ],
                      ),
                    ),
                  ),
                ),
                widget.isLoading
                    ? Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.5,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                  C.accent),
                            ),
                          ),
                          const SizedBox(width: 14),
                          Text(
                            "AUTHENTICATING...",
                            style: TextStyle(
                              color: C.text,
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.w900,
                              fontSize: 13,
                              letterSpacing: 3,
                              shadows: const [
                                Shadow(
                                  color: Colors.black,
                                  offset: Offset(0, 2),
                                  blurRadius: 4,
                                ),
                              ],
                            ),
                          ),
                        ],
                      )
                    : Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.power_settings_new,
                            color: C.text,
                            size: 22,
                            shadows: const [
                              Shadow(
                                color: Colors.black54,
                                offset: Offset(0, 1),
                                blurRadius: 2,
                              ),
                            ],
                          ),
                          const SizedBox(width: 14),
                          Text(
                            "LOGIN",
                            style: TextStyle(
                              color: C.text,
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.w900,
                              fontSize: 20,
                              letterSpacing: 8,
                              shadows: [
                                const Shadow(
                                  color: Colors.black87,
                                  offset: Offset(0, 2),
                                  blurRadius: 4,
                                ),
                                Shadow(
                                  color: C.accent,
                                  offset: const Offset(0, -1),
                                  blurRadius: 2,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 14),
                          Container(
                            padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.black.withOpacity(0.3),
                              border: Border.all(
                                color: C.accent.withOpacity(0.5),
                                width: 1,
                              ),
                            ),
                            child: Icon(
                              Icons.arrow_forward,
                              color: C.accent,
                              size: 14,
                            ),
                          ),
                        ],
                      ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
// COMIC BUY BUTTON  ← ← ← UDAH DIUBAH JADI "BUY ACCESS"
// ════════════════════════════════════════════════════════════
class _ComicBuyButton extends StatefulWidget {
  final AppPalette C;
  final VoidCallback onTap;
  const _ComicBuyButton({required this.C, required this.onTap});

  @override
  State<_ComicBuyButton> createState() => _ComicBuyButtonState();
}

class _ComicBuyButtonState extends State<_ComicBuyButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 100),
        height: 54,
        transform: Matrix4.translationValues(
          _pressed ? 4 : 0,
          _pressed ? 4 : 0,
          0,
        ),
        decoration: BoxDecoration(
          color: C.accent,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: _pressed
              ? []
              : const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(5, 5),
                    blurRadius: 0,
                  ),
                ],
        ),
        child: Center(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.shopping_cart_rounded,
                color: Colors.white,
                size: 22,
                shadows: const [
                  Shadow(
                    color: Colors.black,
                    offset: Offset(2, 2),
                    blurRadius: 0,
                  ),
                ],
              ),
              const SizedBox(width: 10),
              Text(
                "BUY ACCESS",
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Bangers',
                  fontSize: 16,
                  letterSpacing: 2,
                  shadows: const [
                    Shadow(
                      color: Colors.black,
                      offset: Offset(2, 2),
                      blurRadius: 0,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: C.primaryLo,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: Colors.black, width: 2),
                ),
                child: Text(
                  "AKUN",
                  style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Bangers',
                    fontSize: 11,
                    letterSpacing: 2,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
// SKEUO BUY BUTTON  ← ← ← UDAH DIUBAH JADI "BUY ACCESS"
// ════════════════════════════════════════════════════════════
class _SkeuoBuyButton extends StatefulWidget {
  final AppPalette C;
  final VoidCallback onTap;
  const _SkeuoBuyButton({required this.C, required this.onTap});

  @override
  State<_SkeuoBuyButton> createState() => _SkeuoBuyButtonState();
}

class _SkeuoBuyButtonState extends State<_SkeuoBuyButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 100),
        height: 52,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: LinearGradient(
            begin: _pressed
                ? Alignment.bottomCenter
                : Alignment.topCenter,
            end: _pressed
                ? Alignment.topCenter
                : Alignment.bottomCenter,
            colors: [C.accentHi, C.accent, C.primaryLo],
            stops: const [0.0, 0.5, 1.0],
          ),
          boxShadow: _pressed
              ? [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.8),
                    offset: const Offset(0, 2),
                    blurRadius: 4,
                  ),
                ]
              : [
                  BoxShadow(
                    color: C.accent.withOpacity(0.4),
                    offset: const Offset(0, 6),
                    blurRadius: 15,
                    spreadRadius: -2,
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.7),
                    offset: const Offset(0, 4),
                    blurRadius: 8,
                  ),
                ],
          border: Border.all(
            color: C.primaryLo,
            width: 1.5,
          ),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            Positioned(
              top: 3,
              left: 10,
              right: 10,
              child: Container(
                height: 10,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  gradient: LinearGradient(
                    colors: [
                      Colors.white.withOpacity(0.5),
                      Colors.white.withOpacity(0.0),
                    ],
                  ),
                ),
              ),
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.shopping_cart_rounded,
                  color: C.bgDeep,
                  size: 20,
                ),
                const SizedBox(width: 10),
                Text(
                  "BUY ACCESS",
                  style: TextStyle(
                    color: C.bgDeep,
                    fontSize: 10,
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                    gradient: LinearGradient(
                      colors: [C.primary, C.primaryLo],
                    ),
                  ),
                  child: const Text(
                    "AKUN",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
// FOOTER
// ════════════════════════════════════════════════════════════
class _SkeuoFooter extends StatelessWidget {
  final AppPalette C;
  final bool isComic;
  const _SkeuoFooter({required this.C, required this.isComic});

  @override
  Widget build(BuildContext context) {
    if (isComic) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(5, 5),
              blurRadius: 0,
            ),
          ],
        ),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SmartLed(color: C.primaryHi, size: 7),
                const SizedBox(width: 8),
                Text(
                  "SECURE • FAST • REBEL",
                  style: TextStyle(
                    color: C.bgDeep,
                    fontFamily: 'Bangers',
                    fontSize: 13,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(width: 8),
                SmartLed(color: C.accent, size: 7),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              "WhatsApp Crasher And Tools",
              style: TextStyle(
                color: C.bgDeep.withOpacity(0.7),
                fontSize: 11,
                fontWeight: FontWeight.w600,
                fontFamily: 'ComicNeue',
              ),
            ),
            const SizedBox(height: 10),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: C.primaryHi,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.black, width: 2),
              ),
              child: Text(
                "© LATEST 2025",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontFamily: 'Bangers',
                  letterSpacing: 3,
                  shadows: const [
                    Shadow(
                      color: Colors.black,
                      offset: Offset(1, 1),
                      blurRadius: 0,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [C.bg, C.bgDark],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.7),
            offset: const Offset(0, 6),
            blurRadius: 12,
          ),
        ],
        border: Border.all(
          color: C.textSub.withOpacity(0.4),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SmartLed(color: C.primaryHi, size: 6),
              const SizedBox(width: 8),
              Text(
                "SECURE • FAST • REBEL",
                style: TextStyle(
                  color: C.accent.withOpacity(0.8),
                  fontFamily: 'ShareTechMono',
                  fontSize: 10,
                  letterSpacing: 3,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(width: 8),
              SmartLed(color: C.accent, size: 6),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            "WhatsApp Crasher And Tools",
            style: TextStyle(
              color: C.text.withOpacity(0.6),
              fontSize: 11,
              fontStyle: FontStyle.italic,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 10),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6),
              gradient: LinearGradient(
                colors: [C.primaryHi, C.primaryLo],
              ),
            ),
            child: const Text(
              "© LATEST 2025",
              style: TextStyle(
                color: Colors.white,
                fontSize: 9,
                fontFamily: 'ShareTechMono',
                letterSpacing: 3,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
// PAINTERS
// ════════════════════════════════════════════════════════════
class _LeatherTexturePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final rand = math.Random(42);
    final paint = Paint()
      ..color = Colors.black.withOpacity(0.06)
      ..strokeWidth = 1;

    for (int i = 0; i < 800; i++) {
      final x = rand.nextDouble() * size.width;
      final y = rand.nextDouble() * size.height;
      final r = rand.nextDouble() * 1.5;
      canvas.drawCircle(Offset(x, y), r, paint);
    }

    final linePaint = Paint()
      ..color = Colors.black.withOpacity(0.04)
      ..strokeWidth = 0.5;
    for (int i = 0; i < 200; i++) {
      final x = rand.nextDouble() * size.width;
      final y = rand.nextDouble() * size.height;
      final len = rand.nextDouble() * 15 + 3;
      final angle = rand.nextDouble() * math.pi;
      canvas.drawLine(
        Offset(x, y),
        Offset(x + math.cos(angle) * len, y + math.sin(angle) * len),
        linePaint,
      );
    }
  }

  @override
  bool shouldRepaint(_LeatherTexturePainter old) => false;
}

class _HalftonePainter extends CustomPainter {
  final Color color;
  _HalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_HalftonePainter old) => old.color != color;
}