// youtube_page.dart — YouTube Mini Browser (WebView)
// Fitur: nonton YouTube, search, trending, buka di browser
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

// ── Neo Brutalism Colors (pengganti Neo.dart) ──
const Color _neoBg = Color(0xFFFDF6E3);
const Color _neoCream = Color(0xFFFFF8DC);
const Color _neoRed = Color(0xFFFF4D4D);
const Color _neoBlack = Color(0xFF000000);
const Color _neoWhite = Color(0xFFFFFFFF);
const Color _neoTextMuted = Color(0xFF666666);

// ── Helper Shadow Neo ──
List<BoxShadow> _neoShadow({double offset = 3}) => [
      BoxShadow(
        color: _neoBlack,
        offset: Offset(offset, offset),
        blurRadius: 0,
        spreadRadius: 0,
      ),
    ];

class YouTubePage extends StatefulWidget {
  const YouTubePage({super.key});

  @override
  State<YouTubePage> createState() => _YouTubePageState();
}

class _YouTubePageState extends State<YouTubePage> {
  late final WebViewController _controller;
  final TextEditingController _searchCtrl = TextEditingController();

  bool _loading = true;
  double _progress = 0;
  String _currentUrl = 'https://m.youtube.com';
  bool _showSearchBar = false;

  // User-Agent mobile biar tampilan YouTube versi HP
  static const String _userAgent =
      'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

  @override
  void initState() {
    super.initState();

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(_neoBg)
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            if (mounted) setState(() => _progress = progress / 100);
          },
          onPageStarted: (String url) {
            if (mounted) {
              setState(() {
                _loading = true;
                _currentUrl = url;
              });
            }
          },
          onPageFinished: (String url) {
            if (mounted) {
              setState(() {
                _loading = false;
                _currentUrl = url;
              });
            }
          },
          onWebResourceError: (WebResourceError error) {
            debugPrint('WebView error: ${error.description}');
          },
        ),
      )
      ..loadRequest(
        Uri.parse('https://m.youtube.com'),
        headers: {'User-Agent': _userAgent},
      );
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _searchYouTube(String query) async {
    if (query.trim().isEmpty) return;
    final url =
        'https://m.youtube.com/results?search_query=${Uri.encodeComponent(query)}';
    await _controller.loadRequest(
      Uri.parse(url),
      headers: {'User-Agent': _userAgent},
    );
    if (mounted) {
      setState(() {
        _showSearchBar = false;
        _searchCtrl.clear();
      });
    }
  }

  Future<void> _openInBrowser() async {
    final uri = Uri.parse(_currentUrl);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _neoBg,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          // Search bar (muncul pas di-tap tombol search)
          if (_showSearchBar) _buildSearchBar(),

          // Progress bar
          if (_loading)
            LinearProgressIndicator(
              value: _progress,
              backgroundColor: _neoCream,
              color: _neoRed,
              minHeight: 3,
            ),

          // WebView
          Expanded(
            child: WebViewWidget(controller: _controller),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: _neoBg,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      leading: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Container(
          margin: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: _neoWhite,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _neoBlack, width: 2.5),
            boxShadow: _neoShadow(offset: 3),
          ),
          child: const Icon(Icons.arrow_back_ios_new_rounded,
              color: _neoBlack, size: 16),
        ),
      ),
      title: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'YOUTUBE',
            style: TextStyle(
              color: _neoTextMuted,
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 1,
            ),
          ),
          Text(
            'Nonton & Cari Video',
            style: TextStyle(
              color: _neoBlack,
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
      actions: [
        // Tombol Home
        _appBarBtn(
          icon: Icons.home_rounded,
          onTap: () => _controller.loadRequest(
            Uri.parse('https://m.youtube.com'),
            headers: {'User-Agent': _userAgent},
          ),
        ),

        // Tombol Search
        _appBarBtn(
          icon: Icons.search_rounded,
          onTap: () {
            setState(() => _showSearchBar = !_showSearchBar);
          },
        ),

        // Tombol Refresh
        _appBarBtn(
          icon: Icons.refresh_rounded,
          onTap: () => _controller.reload(),
        ),

        // Tombol Buka di Browser
        _appBarBtn(
          icon: Icons.open_in_new_rounded,
          onTap: _openInBrowser,
        ),

        const SizedBox(width: 8),
      ],
    );
  }

  Widget _appBarBtn({required IconData icon, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 3, vertical: 10),
        width: 34,
        height: 34,
        decoration: BoxDecoration(
          color: _neoWhite,
          borderRadius: BorderRadius.circular(9),
          border: Border.all(color: _neoBlack, width: 2),
          boxShadow: _neoShadow(offset: 2),
        ),
        child: Icon(icon, color: _neoBlack, size: 16),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
        decoration: BoxDecoration(
          color: _neoWhite,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _neoBlack, width: 2.5),
          boxShadow: _neoShadow(offset: 4),
        ),
        child: Row(
          children: [
            const Icon(Icons.search_rounded, color: _neoBlack, size: 20),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _searchCtrl,
                autofocus: true,
                textInputAction: TextInputAction.search,
                onSubmitted: _searchYouTube,
                style: const TextStyle(
                  color: _neoBlack,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
                decoration: const InputDecoration(
                  hintText: 'Cari video di YouTube...',
                  hintStyle: TextStyle(
                    color: _neoTextMuted,
                    fontWeight: FontWeight.w500,
                    fontSize: 13,
                  ),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 14),
                ),
              ),
            ),
            if (_searchCtrl.text.isNotEmpty)
              GestureDetector(
                onTap: () => setState(() => _searchCtrl.clear()),
                child: const Icon(Icons.close_rounded,
                    color: _neoTextMuted, size: 18),
              ),
          ],
        ),
      ),
    );
  }
}