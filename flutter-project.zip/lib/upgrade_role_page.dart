// lib/upgrade_role_page.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'app_theme.dart';

const String _kBaseUrl = 'http://panelku.fincloud.my.id:2772';

// ══════════════════════════════════════════════════════════════
// GLOBAL PULSE
// ══════════════════════════════════════════════════════════════
class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;
  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }
  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

// ══════════════════════════════════════════════════════════════
// LED
// ══════════════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18),
        ),
      );
    }
    if (!blink) return _dot(1.0);
    return ValueListenableBuilder<double>(
      valueListenable: _Pulse.v,
      builder: (_, v, __) => _dot(0.45 + v * 0.55),
    );
  }

  Widget _dot(double opacity) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            center: const Alignment(-0.35, -0.35),
            colors: [
              Colors.white.withOpacity(0.85 * opacity),
              color.withOpacity(opacity),
              color.withOpacity(0.55 * opacity),
            ],
            stops: const [0.0, 0.4, 1.0],
          ),
          border: Border.all(
            color: Colors.black.withOpacity(0.85),
            width: size * 0.1,
          ),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.75 * opacity),
              blurRadius: size * 1.4,
              spreadRadius: size * 0.2,
            ),
          ],
        ),
      );
}

// ══════════════════════════════════════════════════════════════
// SCREW / RIVET
// ══════════════════════════════════════════════════════════════
class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Screw({required this.C, this.size = 14});
  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.text, C.textSub, C.bg, C.bgDark],
          stops: const [0.0, 0.35, 0.7, 1.0],
        ),
      ),
      child: Center(
        child: Transform.rotate(
          angle: 0.785,
          child: Container(
            width: size * 0.7, height: size * 0.11,
            color: Colors.black.withOpacity(0.9),
          ),
        ),
      ),
    );
  }
}

class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 10});
  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.accentShine, C.accentHi, C.accent, C.primaryLo],
          stops: const [0.0, 0.3, 0.65, 1.0],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
// METAL PLATE
// ══════════════════════════════════════════════════════════════
class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final bool brass;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.brass = false,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: brass ? C.primaryHi : C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(color: Colors.black, offset: Offset(6, 6),
                blurRadius: 0),
          ],
        ),
        child: child,
      );
    }
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: brass
              ? [C.accentHi, C.accent, C.primary, C.primaryLo]
              : [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.75),
              offset: const Offset(0, 6), blurRadius: 12),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
// INSET PANEL
// ══════════════════════════════════════════════════════════════
class _InsetPanel extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final Color glowColor;
  final bool glow;
  const _InsetPanel({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(12),
    this.glowColor = Colors.amber,
    this.glow = false,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.black, width: 3),
        ),
        child: child,
      );
    }
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        gradient: LinearGradient(
          begin: Alignment.topCenter, end: Alignment.bottomCenter,
          colors: [C.bgDeep, C.bgDark],
        ),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.95),
              offset: const Offset(0, 2), blurRadius: 4),
          if (glow) BoxShadow(color: glowColor.withOpacity(0.35),
              blurRadius: 10),
        ],
        border: Border.all(
          color: glow ? glowColor.withOpacity(0.7) : C.bgDark,
          width: 1.5,
        ),
      ),
      child: child,
    );
  }
}

// ══════════════════════════════════════════════════════════════
// INDUSTRIAL BUTTON
// ══════════════════════════════════════════════════════════════
class _IndustrialButton extends StatefulWidget {
  final AppPalette C;
  final Widget child;
  final VoidCallback? onTap;
  final Color color;
  final double height;
  const _IndustrialButton({
    required this.C,
    required this.child,
    required this.onTap,
    required this.color,
    this.height = 56,
  });

  @override
  State<_IndustrialButton> createState() => _IndustrialButtonState();
}

class _IndustrialButtonState extends State<_IndustrialButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final enabled = widget.onTap != null;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    final light = _lighten(widget.color);
    final dark = _darken(widget.color);
    final widgetDark = _widgetDark(widget.color);

    final textColor = isComic
        ? C.contrastTextOn(widget.color)
        : Colors.white;

    return GestureDetector(
      onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
      onTapUp: enabled ? (_) {
        setState(() => _pressed = false);
        widget.onTap?.call();
      } : null,
      onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: widget.height,
        transform: isComic
            ? Matrix4.translationValues(_pressed ? 4 : 0, _pressed ? 4 : 0, 0)
            : null,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: isComic ? null : LinearGradient(
            begin: _pressed ? Alignment.bottomCenter : Alignment.topCenter,
            end: _pressed ? Alignment.topCenter : Alignment.bottomCenter,
            colors: _pressed
                ? [widgetDark, widgetDark, widget.color]
                : [light, widget.color, dark],
            stops: const [0.0, 0.5, 1.0],
          ),
          color: isComic ? widget.color : null,
          boxShadow: isComic
              ? (_pressed ? [] : const [
                  BoxShadow(color: Colors.black, offset: Offset(4, 4),
                      blurRadius: 0),
                ])
              : (_pressed
                  ? [BoxShadow(color: Colors.black.withOpacity(0.9),
                      offset: const Offset(0, 1), blurRadius: 3)]
                  : [
                      BoxShadow(color: widget.color.withOpacity(0.45),
                          offset: const Offset(0, 5), blurRadius: 10,
                          spreadRadius: -2),
                      BoxShadow(color: Colors.black.withOpacity(0.75),
                          offset: const Offset(0, 4), blurRadius: 6),
                    ]),
          border: Border.all(
            color: isComic ? Colors.black : dark.withOpacity(0.9),
            width: isComic ? 3.5 : 1.5,
          ),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            if (!isComic) ...[
              Positioned(top: 5, left: 5, child: _Rivet(C: C, size: 6)),
              Positioned(top: 5, right: 5, child: _Rivet(C: C, size: 6)),
              Positioned(bottom: 5, left: 5, child: _Rivet(C: C, size: 6)),
              Positioned(bottom: 5, right: 5, child: _Rivet(C: C, size: 6)),
            ],
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Opacity(
                opacity: enabled ? 1 : 0.5,
                child: DefaultTextStyle(
                  style: TextStyle(
                    color: textColor,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                  ),
                  child: IconTheme(
                    data: IconThemeData(color: textColor),
                    child: widget.child,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  static Color _lighten(Color c) => Color.fromARGB(c.alpha,
      (c.red + 40).clamp(0, 255),
      (c.green + 40).clamp(0, 255),
      (c.blue + 30).clamp(0, 255));
  static Color _darken(Color c) => Color.fromARGB(c.alpha,
      (c.red - 60).clamp(0, 255),
      (c.green - 50).clamp(0, 255),
      (c.blue - 40).clamp(0, 255));
  static Color _widgetDark(Color c) => Color.fromARGB(c.alpha,
      (c.red - 30).clamp(0, 255),
      (c.green - 25).clamp(0, 255),
      (c.blue - 20).clamp(0, 255));
}

// ══════════════════════════════════════════════════════════════
// ROLE MODEL
// ══════════════════════════════════════════════════════════════
class RoleUpgrade {
  final String id;
  final String name;
  final String emoji;
  final int price;
  final Color color;
  final IconData icon;
  final List<String> benefits;

  const RoleUpgrade({
    required this.id,
    required this.name,
    required this.emoji,
    required this.price,
    required this.color,
    required this.icon,
    required this.benefits,
  });
}

List<RoleUpgrade> _allUpgrades(AppPalette C) => [
  RoleUpgrade(
    id: 'reseller', name: 'RESELLER', emoji: '🛒', price: 10000,
    color: C.accentHi, icon: Icons.storefront_rounded,
    benefits: ['Bisa buat akun member', 'Akses Seller Page',
        'Cooldown lebih cepat', 'Limit 30 akun/bulan'],
  ),
  RoleUpgrade(
    id: 'vip', name: 'VIP', emoji: '⭐', price: 15000,
    color: C.primaryHi, icon: Icons.star_rounded,
    benefits: ['Semua benefit Reseller', 'Cooldown 60 detik',
        'Akses global sender', 'Prioritas support'],
  ),
  RoleUpgrade(
    id: 'admin', name: 'ADMIN', emoji: '🛡️', price: 30000,
    color: C.primaryHi, icon: Icons.admin_panel_settings_rounded,
    benefits: ['Semua benefit VIP', 'Akses Admin Page',
        'Cooldown 30 detik', 'Bisa kelola user'],
  ),
  RoleUpgrade(
    id: 'partner', name: 'PARTNER', emoji: '🤝', price: 45000,
    color: C.primaryHi, icon: Icons.handshake_rounded,
    benefits: ['Semua benefit Admin', 'Akses Owner Page',
        'Cooldown 30 detik', 'Limit lebih besar'],
  ),
  RoleUpgrade(
    id: 'moderator', name: 'MODERATOR', emoji: '🔴', price: 60000,
    color: C.primaryHi, icon: Icons.shield_rounded,
    benefits: ['Semua benefit Partner', 'Akses Owner Page',
        'Cooldown 30 detik', 'Bisa kelola partner'],
  ),
  RoleUpgrade(
    id: 'owner', name: 'OWNER', emoji: '👑', price: 100000,
    color: C.accent, icon: Icons.workspace_premium_rounded,
    benefits: ['Semua benefit Moderator', 'Cooldown 1 detik',
        'Limit 50 akun/bulan', 'Akses penuh Owner Page'],
  ),
];

const List<String> _roleOrder = [
  'member', 'reseller', 'vip', 'admin',
  'partner', 'moderator', 'owner', 'high owner', 'developer',
];

int _roleLevel(String role) {
  final idx = _roleOrder.indexOf(role.toLowerCase());
  return idx == -1 ? 0 : idx;
}

List<RoleUpgrade> _getAvailableUpgrades(AppPalette C, String currentRole) {
  final currentLevel = _roleLevel(currentRole);
  return _allUpgrades(C).where((u) => _roleLevel(u.id) > currentLevel).toList();
}

// ══════════════════════════════════════════════════════════════
// UPGRADE ROLE PAGE
// ══════════════════════════════════════════════════════════════
class UpgradeRolePage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String currentRole;

  const UpgradeRolePage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.currentRole,
  });

  @override
  State<UpgradeRolePage> createState() => _UpgradeRolePageState();
}

class _UpgradeRolePageState extends State<UpgradeRolePage> {
  @override
  void initState() {
    super.initState();
    _Pulse.ensureStarted();
  }

  void _openUpgradeSheet(AppPalette C, bool isComic, RoleUpgrade role) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      barrierColor: Colors.black.withOpacity(0.88),
      builder: (ctx) => _UpgradeSheet(
        C: C,
        isComic: isComic,
        role: role,
        username: widget.username,
        sessionKey: widget.sessionKey,
        onApproved: (newRole) {
          // Refresh UI parent kalo perlu
          setState(() {});
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            final availableUpgrades =
                _getAvailableUpgrades(C, widget.currentRole);

            return Scaffold(
              backgroundColor: C.bgDeep,
              body: Stack(
                children: [
                  Positioned.fill(
                    child: isComic
                        ? Container(
                            color: C.bg,
                            child: CustomPaint(
                              painter: _ComicHalftonePainter(
                                  color: C.primaryLo.withOpacity(0.12)),
                            ),
                          )
                        : Container(
                            decoration: BoxDecoration(
                              gradient: RadialGradient(
                                center: const Alignment(-0.3, -0.3),
                                radius: 1.2,
                                colors: [C.bg, C.bgDark, C.bgDeep],
                                stops: const [0.0, 0.6, 1.0],
                              ),
                            ),
                          ),
                  ),
                  SafeArea(
                    child: Column(
                      children: [
                        _buildAppBar(C, isComic),
                        const SizedBox(height: 10),
                        Expanded(
                          child: availableUpgrades.isEmpty
                              ? _buildMaxRole(C, isComic)
                              : ListView(
                                  padding:
                                      const EdgeInsets.fromLTRB(14, 4, 14, 32),
                                  physics: const BouncingScrollPhysics(),
                                  children: [
                                    _buildHeaderInfo(C, isComic),
                                    const SizedBox(height: 14),
                                    _buildSectionTitle(C, isComic,
                                        '// 1. PILIH ROLE YANG MAU DI-UPGRADE'),
                                    const SizedBox(height: 10),
                                    ...availableUpgrades.map((u) => Padding(
                                      padding:
                                          const EdgeInsets.only(bottom: 12),
                                      child: _buildRoleCard(C, isComic, u),
                                    )),
                                  ],
                                ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildAppBar(AppPalette C, bool isComic) {
    final backIconColor =
        isComic ? C.contrastTextOn(C.accent) : C.accent;
    final badgeIconColor =
        isComic ? C.contrastTextOn(C.primaryHi) : C.accent;

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      child: _MetalPlate(
        C: C,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  gradient: isComic ? null
                      : LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [C.textSub, C.bg, C.bgDark]),
                  color: isComic ? C.accent : null,
                  border: Border.all(
                      color: isComic ? Colors.black
                          : Colors.black.withOpacity(0.7),
                      width: isComic ? 3 : 1.2),
                ),
                child: Icon(Icons.arrow_back_ios_new_rounded,
                    color: backIconColor, size: 16),
              ),
            ),
            const SizedBox(width: 12),
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: isComic ? null
                        : RadialGradient(colors: [C.text, C.bg, C.bgDark]),
                    color: isComic ? C.primaryHi : null,
                    border: Border.all(
                        color: isComic ? Colors.black : C.accent,
                        width: isComic ? 3 : 2),
                  ),
                  child: Icon(Icons.workspace_premium_rounded,
                      color: badgeIconColor, size: 20),
                ),
                if (!isComic)
                  Positioned(top: -2, right: -2,
                      child: _Led(color: C.primaryHi, size: 6, blink: true)),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('UPGRADE ROLE',
                      style: TextStyle(
                        color: isComic ? C.comicText : C.accentHi,
                        fontSize: isComic ? 18 : 13,
                        fontWeight: FontWeight.w900,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: 2,
                        height: 1,
                        shadows: isComic
                            ? [
                                Shadow(
                                  color: C.comicTextOutline,
                                  offset: const Offset(1, 1),
                                  blurRadius: 0,
                                ),
                              ]
                            : [
                                Shadow(color: C.primaryLo,
                                    offset: const Offset(0, 1), blurRadius: 1),
                                const Shadow(color: Colors.black,
                                    offset: Offset(0, 2), blurRadius: 3),
                              ],
                      )),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      _Led(color: C.accent, size: 4, blink: !isComic),
                      const SizedBox(width: 5),
                      Text('SAAT INI: ${widget.currentRole.toUpperCase()}',
                          style: TextStyle(
                            color: isComic
                                ? C.comicTextSub
                                : C.text.withOpacity(0.55),
                            fontSize: 8,
                            fontWeight: FontWeight.w700,
                            fontFamily:
                                isComic ? 'ComicNeue' : 'ShareTechMono',
                            letterSpacing: 1.2)),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMaxRole(AppPalette C, bool isComic) {
    final iconColor =
        isComic ? C.contrastTextOn(C.primaryHi) : C.accent;

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 90, height: 90,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: isComic ? null : RadialGradient(
                    colors: [C.accent, C.primary, C.primaryLo, Colors.black],
                    stops: const [0.0, 0.4, 0.7, 1.0]),
                  color: isComic ? C.primaryHi : null,
                  border: Border.all(
                      color: isComic ? Colors.black : C.accent,
                      width: isComic ? 5 : 3),
                ),
                child: Icon(Icons.emoji_events_rounded,
                    color: iconColor, size: 45),
              ),
              const SizedBox(height: 20),
              Text('ROLE TERTINGGI!',
                  style: TextStyle(
                    color: isComic ? C.comicText : C.accent,
                    fontSize: isComic ? 22 : 16,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 2,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.comicTextOutline,
                              offset: const Offset(1, 1),
                              blurRadius: 0,
                            ),
                          ]
                        : null,
                  )),
              const SizedBox(height: 10),
              Text('Lu udah di role paling tinggi\nyang bisa di-upgrade.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: isComic
                        ? C.comicTextSub
                        : C.text.withOpacity(0.6),
                    fontSize: isComic ? 13 : 11,
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                    height: 1.5)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionTitle(AppPalette C, bool isComic, String text) {
    return Text(
      text,
      style: TextStyle(
        color: isComic ? C.comicText : C.accent,
        fontSize: isComic ? 14 : 11,
        fontWeight: FontWeight.w900,
        fontFamily: isComic ? 'Bangers' : 'Orbitron',
        letterSpacing: 1.5,
        shadows: isComic
            ? [
                Shadow(
                  color: C.comicTextOutline,
                  offset: const Offset(1, 1),
                  blurRadius: 0,
                ),
              ]
            : null,
      ),
    );
  }

  Widget _buildHeaderInfo(AppPalette C, bool isComic) {
    final iconColor =
        isComic ? C.contrastTextOn(C.primaryHi) : C.accentHi;

    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          Container(
            width: 40, height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: isComic ? null
                  : RadialGradient(colors: [C.text, C.bg, C.bgDark]),
              color: isComic ? C.primaryHi : null,
              border: Border.all(
                  color: isComic ? Colors.black : C.accentHi,
                  width: isComic ? 3 : 2),
            ),
            child: Icon(Icons.info_outline_rounded,
                color: iconColor, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('CARA UPGRADE',
                    style: TextStyle(
                      color: isComic ? C.comicText : C.accentHi,
                      fontSize: isComic ? 15 : 12,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 1.5,
                      shadows: isComic
                          ? [
                              Shadow(
                                color: C.comicTextOutline,
                                offset: const Offset(1, 1),
                                blurRadius: 0,
                              ),
                            ]
                          : null)),
                const SizedBox(height: 4),
                Text(
                  '1. Pilih role\n'
                  '2. Pilih metode bayar (QRIS / DANA)\n'
                  '3. Transfer sesuai harga\n'
                  '4. Upload bukti transfer\n'
                  '5. Tunggu admin approve',
                  style: TextStyle(
                    color: isComic
                        ? C.comicText.withOpacity(0.85)
                        : C.text.withOpacity(0.75),
                    fontSize: isComic ? 12 : 10,
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                    height: 1.6,
                    fontWeight: isComic ? FontWeight.w700 : null),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRoleCard(AppPalette C, bool isComic, RoleUpgrade role) {
    final roleIconColor = isComic
        ? C.contrastTextOn(role.color)
        : Colors.white;

    return _MetalPlate(
      C: C,
      padding: EdgeInsets.zero,
      radius: 14,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Stack(
                  alignment: Alignment.center,
                  children: [
                    Container(
                      width: 52, height: 52,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: isComic ? null : RadialGradient(
                          colors: [
                            role.color.withOpacity(0.5),
                            role.color.withOpacity(0.2),
                            Colors.black],
                          stops: const [0.0, 0.5, 1.0]),
                        color: isComic ? role.color : null,
                        border: Border.all(
                            color: isComic ? Colors.black : role.color,
                            width: isComic ? 4 : 2),
                      ),
                      child: Icon(role.icon,
                          color: roleIconColor, size: 24),
                    ),
                    if (!isComic)
                      Positioned(top: -2, right: -2,
                          child: _Led(color: C.primaryHi, size: 6,
                              blink: true)),
                  ],
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(role.emoji,
                              style: const TextStyle(fontSize: 16)),
                          const SizedBox(width: 6),
                          Text(role.name,
                              style: TextStyle(
                                color: isComic ? C.comicText : C.text,
                                fontSize: isComic ? 18 : 15,
                                fontWeight: FontWeight.w900,
                                fontFamily:
                                    isComic ? 'Bangers' : 'Orbitron',
                                letterSpacing: 1,
                                shadows: isComic
                                    ? [
                                        Shadow(
                                          color: C.comicTextOutline,
                                          offset: const Offset(1, 1),
                                          blurRadius: 0,
                                        ),
                                      ]
                                    : null)),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text('Rp ${_formatPrice(role.price)}',
                          style: TextStyle(
                            color: isComic ? C.comicText : role.color,
                            fontSize: isComic ? 15 : 12,
                            fontWeight: FontWeight.w900,
                            fontFamily:
                                isComic ? 'Bangers' : 'Orbitron',
                            letterSpacing: 0.5)),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(isComic ? 6 : 4),
                    color: isComic ? role.color : role.color.withOpacity(0.2),
                    border: Border.all(
                        color: isComic ? Colors.black : role.color,
                        width: isComic ? 2.5 : 1),
                  ),
                  child: Text('UPGRADE',
                      style: TextStyle(
                        color: roleIconColor,
                        fontSize: isComic ? 11 : 8,
                        fontWeight: FontWeight.w900,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: 1.2)),
                ),
              ],
            ),
          ),
          Container(
            height: isComic ? 3 : 1,
            color: isComic ? Colors.black : C.accent.withOpacity(0.3)),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    if (!isComic) _Rivet(C: C, size: 6),
                    if (!isComic) const SizedBox(width: 8),
                    Text('BENEFIT:',
                        style: TextStyle(
                          color: isComic ? C.comicText : C.accent,
                          fontSize: isComic ? 13 : 9,
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 1.5,
                          shadows: isComic
                              ? [
                                  Shadow(
                                    color: C.comicTextOutline,
                                    offset: const Offset(1, 1),
                                    blurRadius: 0,
                                  ),
                                ]
                              : null)),
                  ],
                ),
                const SizedBox(height: 8),
                ...role.benefits.map((b) => Padding(
                      padding: const EdgeInsets.only(bottom: 5),
                      child: Row(
                        children: [
                          Icon(Icons.check_circle_rounded,
                              color: isComic ? C.comicText : C.primaryHi,
                              size: isComic ? 16 : 13),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(b,
                                style: TextStyle(
                                  color: isComic
                                      ? C.comicText.withOpacity(0.85)
                                      : C.text.withOpacity(0.8),
                                  fontSize: isComic ? 12 : 10.5,
                                  fontFamily: isComic
                                      ? 'ComicNeue'
                                      : 'ShareTechMono',
                                  fontWeight: FontWeight.w700)),
                          ),
                        ],
                      ),
                    )),
                const SizedBox(height: 14),
                _IndustrialButton(
                  C: C,
                  color: role.color,
                  height: 48,
                  onTap: () => _openUpgradeSheet(C, isComic, role),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.arrow_upward_rounded, size: 16),
                      SizedBox(width: 6),
                      Text('UPGRADE SEKARANG',
                          style: TextStyle(
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                            letterSpacing: 2,
                            fontSize: 11)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _formatPrice(int price) {
    final str = price.toString();
    final buffer = StringBuffer();
    for (int i = 0; i < str.length; i++) {
      if (i > 0 && (str.length - i) % 3 == 0) buffer.write('.');
      buffer.write(str[i]);
    }
    return buffer.toString();
  }
}

// ══════════════════════════════════════════════════════════════
// UPGRADE SHEET — STEP-BY-STEP
// ══════════════════════════════════════════════════════════════
class _UpgradeSheet extends StatefulWidget {
  final AppPalette C;
  final bool isComic;
  final RoleUpgrade role;
  final String username;
  final String sessionKey;
  final void Function(String newRole)? onApproved;

  const _UpgradeSheet({
    required this.C,
    required this.isComic,
    required this.role,
    required this.username,
    required this.sessionKey,
    this.onApproved,
  });

  @override
  State<_UpgradeSheet> createState() => _UpgradeSheetState();
}

class _UpgradeSheetState extends State<_UpgradeSheet> {
  // ── State ──
  String? _paymentMethod; // 'qris' | 'dana'
  File? _proofImage;
  bool _isUploading = false;

  // ── Detail DANA (ambil dari server atau hardcode fallback) ──
  static const String _danaNumber = '08382717110';
  static const String _danaName = 'Really xxxx';

  // ══════════════════════════════════════════════════════════════
  // PICK IMAGE
  // ══════════════════════════════════════════════════════════════
  Future<void> _pickImage(ImageSource source) async {
    try {
      final picker = ImagePicker();
      final picked = await picker.pickImage(
          source: source, imageQuality: 70, maxWidth: 1080);
      if (picked != null) setState(() => _proofImage = File(picked.path));
    } catch (e) {
      _showSnack('Gagal pilih gambar: $e', isError: true);
    }
  }

  void _showImageOptions() {
    final C = widget.C;
    final isComic = widget.isComic;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (ctx) => _MetalPlate(
        C: C,
        padding: const EdgeInsets.all(18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 50, height: isComic ? 5 : 4,
              margin: const EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(
                color: isComic ? Colors.black : C.textSub,
                borderRadius: BorderRadius.circular(2)),
            ),
            Text('PILIH SUMBER GAMBAR',
                style: TextStyle(
                  color: isComic ? C.comicText : C.accent,
                  fontSize: isComic ? 16 : 13,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: 2)),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: _IndustrialButton(
                    C: C,
                    color: C.accentHi, height: 52,
                    onTap: () {
                      Navigator.pop(ctx);
                      _pickImage(ImageSource.camera);
                    },
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.camera_alt_rounded, size: 16),
                        SizedBox(width: 6),
                        Text('KAMERA',
                            style: TextStyle(
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Orbitron',
                              letterSpacing: 2, fontSize: 11)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _IndustrialButton(
                    C: C,
                    color: C.accentHi, height: 52,
                    onTap: () {
                      Navigator.pop(ctx);
                      _pickImage(ImageSource.gallery);
                    },
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.photo_library_rounded, size: 16),
                        SizedBox(width: 6),
                        Text('GALERI',
                            style: TextStyle(
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Orbitron',
                              letterSpacing: 2, fontSize: 11)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════
  // SHOW QRIS
  // ══════════════════════════════════════════════════════════════
  void _showQrisDialog() {
    final C = widget.C;
    final isComic = widget.isComic;

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.9),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(20),
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('SCAN QRIS',
                  style: TextStyle(
                    color: isComic ? C.comicText : C.accent,
                    fontSize: isComic ? 20 : 15,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 2.5,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.comicTextOutline,
                              offset: const Offset(1, 1),
                              blurRadius: 0,
                            ),
                          ]
                        : null)),
              const SizedBox(height: 6),
              Text('Scan pake aplikasi apapun yang support QRIS',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: isComic ? C.comicTextSub : C.textSub,
                    fontSize: isComic ? 12 : 10,
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                    height: 1.5)),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: isComic ? Colors.black : C.accent,
                      width: isComic ? 4 : 2),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.asset(
                    'assets/images/qris.jpg',
                    width: 260, height: 260,
                    fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) => Container(
                      width: 260, height: 260,
                      color: C.bgDark,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.qr_code_2_rounded, size: 64,
                              color: isComic ? C.comicTextSub : C.textSub),
                          const SizedBox(height: 8),
                          Text('qris.jpg belum ada',
                              style: TextStyle(
                                color: isComic ? C.comicTextSub
                                    : C.text.withOpacity(0.5),
                                fontSize: 10,
                                fontFamily: isComic ? 'ComicNeue'
                                    : 'ShareTechMono')),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: isComic ? C.primaryHi : C.primaryLo,
                  borderRadius: BorderRadius.circular(isComic ? 12 : 8),
                  border: Border.all(
                      color: isComic ? Colors.black : C.primaryHi,
                      width: isComic ? 3 : 1.5),
                ),
                child: Text(
                  'Transfer: Rp ${_formatPrice(widget.role.price)}',
                  style: TextStyle(
                    color: isComic ? C.contrastTextOn(C.primaryHi) : Colors.white,
                    fontSize: isComic ? 14 : 12,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 0.5)),
              ),
              const SizedBox(height: 18),
              _IndustrialButton(
                C: C,
                color: C.primaryHi, height: 46,
                onTap: () => Navigator.pop(ctx),
                child: Text('OKE, SAYA BAYAR',
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 2.5,
                      fontSize: isComic ? 15 : 11)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════
  // SHOW DANA
  // ══════════════════════════════════════════════════════════════
  void _showDanaDialog() {
    final C = widget.C;
    final isComic = widget.isComic;

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.9),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(20),
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Container(
                    width: 42, height: 42,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: isComic ? null
                          : RadialGradient(colors: [
                              const Color(0xFF118EEA).withOpacity(0.6),
                              const Color(0xFF118EEA).withOpacity(0.2),
                              Colors.black]),
                      color: isComic ? const Color(0xFF118EEA) : null,
                      border: Border.all(
                          color: isComic ? Colors.black : const Color(0xFF118EEA),
                          width: isComic ? 3 : 2),
                    ),
                    child: Icon(Icons.account_balance_wallet_rounded,
                        color: isComic
                            ? C.contrastTextOn(const Color(0xFF118EEA))
                            : Colors.white,
                        size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text('TRANSFER KE DANA',
                        style: TextStyle(
                          color: isComic ? C.comicText : C.accent,
                          fontSize: isComic ? 18 : 14,
                          fontWeight: FontWeight.w900,
                          fontFamily: isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 2,
                          shadows: isComic
                              ? [
                                  Shadow(
                                    color: C.comicTextOutline,
                                    offset: const Offset(1, 1),
                                    blurRadius: 0,
                                  ),
                                ]
                              : null)),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: isComic ? C.bg : C.bgDeep,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: isComic ? Colors.black : const Color(0xFF118EEA),
                      width: isComic ? 3 : 1.5),
                ),
                child: Column(
                  children: [
                    Text('NOMOR DANA',
                        style: TextStyle(
                          color: isComic ? C.comicTextSub : C.textSub,
                          fontSize: isComic ? 11 : 9,
                          fontFamily:
                              isComic ? 'ComicNeue' : 'ShareTechMono',
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.5)),
                    const SizedBox(height: 6),
                    Text(_danaNumber,
                        style: TextStyle(
                          color: isComic ? C.comicText : C.text,
                          fontFamily:
                              isComic ? 'ComicNeue' : 'ShareTechMono',
                          fontSize: isComic ? 22 : 18,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1)),
                    const SizedBox(height: 4),
                    Text('a/n $_danaName',
                        style: TextStyle(
                          color: isComic ? C.comicTextSub : C.textSub,
                          fontSize: isComic ? 12 : 10,
                          fontFamily:
                              isComic ? 'ComicNeue' : 'ShareTechMono')),
                    const SizedBox(height: 12),
                    _IndustrialButton(
                      C: C,
                      color: const Color(0xFF118EEA),
                      height: 40,
                      onTap: () {
                        Clipboard.setData(
                            const ClipboardData(text: _danaNumber));
                        HapticFeedback.lightImpact();
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Nomor DANA disalin!'),
                            backgroundColor: Colors.green,
                            behavior: SnackBarBehavior.floating,
                            duration: Duration(seconds: 2),
                          ),
                        );
                      },
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.copy_rounded, size: 14),
                          SizedBox(width: 6),
                          Text('COPY NOMOR',
                              style: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1.5, fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: isComic ? C.primaryHi : C.primaryLo,
                  borderRadius: BorderRadius.circular(isComic ? 12 : 8),
                  border: Border.all(
                      color: isComic ? Colors.black : C.primaryHi,
                      width: isComic ? 3 : 1.5),
                ),
                child: Text(
                  'Transfer: Rp ${_formatPrice(widget.role.price)}',
                  style: TextStyle(
                    color: isComic ? C.contrastTextOn(C.primaryHi) : Colors.white,
                    fontSize: isComic ? 14 : 12,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 0.5)),
              ),
              const SizedBox(height: 18),
              _IndustrialButton(
                C: C,
                color: C.primaryHi, height: 46,
                onTap: () => Navigator.pop(ctx),
                child: Text('OKE, SAYA BAYAR',
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 2.5,
                      fontSize: isComic ? 15 : 11)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════
  // SUBMIT UPGRADE
  // ══════════════════════════════════════════════════════════════
  Future<void> _submitUpgrade() async {
    if (_paymentMethod == null) {
      _showSnack('Pilih metode pembayaran dulu bro!', isError: true);
      return;
    }
    if (_proofImage == null) {
      _showSnack('Upload bukti transfer dulu bro!', isError: true);
      return;
    }

    setState(() => _isUploading = true);

    try {
      final uri = Uri.parse('$_kBaseUrl/upgrade-role');
      final request = http.MultipartRequest('POST', uri);
      request.fields['username'] = widget.username;
      request.fields['sessionKey'] = widget.sessionKey;
      request.fields['targetRole'] = widget.role.id;
      request.fields['price'] = widget.role.price.toString();
      request.fields['paymentMethod'] = _paymentMethod!;
      request.files.add(await http.MultipartFile.fromPath(
          'proof', _proofImage!.path));

      final response = await request.send();
      final responseData = await response.stream.bytesToString();
      final json = jsonDecode(responseData);

      if (!mounted) return;

      if (json['valid'] == true) {
        Navigator.pop(context);
        _showSuccessDialog(json['requestId'] ?? '');
      } else {
        _showSnack(json['message'] ?? 'Gagal submit', isError: true);
      }
    } catch (e) {
      if (mounted) _showSnack('Error: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isUploading = false);
    }
  }

  void _showSuccessDialog(String requestId) {
    final C = widget.C;
    final isComic = widget.isComic;
    final successIconColor =
        isComic ? C.contrastTextOn(C.primaryHi) : C.primaryHi;

    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(24),
        child: _MetalPlate(
          C: C,
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 60, height: 60,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: isComic ? null : RadialGradient(
                          colors: [C.primaryHi, C.primary, Colors.black]),
                      color: isComic ? C.primaryHi : null,
                      border: Border.all(
                          color: isComic ? Colors.black : C.primaryHi,
                          width: isComic ? 4 : 2.5),
                    ),
                    child: Icon(Icons.check_rounded,
                        color: successIconColor,
                        size: 30),
                  ),
                  if (!isComic)
                    Positioned(top: -2, right: -2,
                        child: _Led(color: C.primaryHi, size: 8,
                            blink: true)),
                ],
              ),
              const SizedBox(height: 18),
              Text('TERKIRIM!',
                  style: TextStyle(
                    color: isComic ? C.comicText : C.accent,
                    fontSize: isComic ? 20 : 15,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 2.5,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.comicTextOutline,
                              offset: const Offset(1, 1),
                              blurRadius: 0,
                            ),
                          ]
                        : null)),
              const SizedBox(height: 10),
              Text('Bukti transfer lu udah diterima.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: isComic
                        ? C.comicText.withOpacity(0.85)
                        : C.text.withOpacity(0.75),
                    fontSize: isComic ? 13 : 11,
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                    height: 1.5)),
              const SizedBox(height: 6),
              Text(
                'Admin bakal verifikasi & approve.\n'
                'Setelah approve, role lu otomatis berubah.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isComic ? C.comicTextSub : C.text.withOpacity(0.55),
                  fontSize: isComic ? 12 : 10,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  height: 1.5)),
              const SizedBox(height: 16),
              _InsetPanel(
                C: C,
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    Icon(Icons.receipt_long_rounded,
                        color: isComic ? C.comicText : C.accent,
                        size: 16),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text('Request ID: $requestId',
                          style: TextStyle(
                            color: isComic ? C.comicText : C.text,
                            fontSize: isComic ? 13 : 11,
                            fontFamily:
                                isComic ? 'ComicNeue' : 'ShareTechMono',
                            fontWeight: FontWeight.w800)),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              _IndustrialButton(
                C: C,
                color: C.primaryHi, height: 46,
                onTap: () => Navigator.pop(ctx),
                child: Text('OKE',
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: 2.5, fontSize: isComic ? 16 : 12)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSnack(String msg, {bool isError = false}) {
    final C = widget.C;
    final isComic = widget.isComic;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg,
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
              color: isComic ? C.comicText : Colors.white)),
        backgroundColor: isError ? C.primaryHi : Colors.green[700],
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  String _formatPrice(int price) {
    final str = price.toString();
    final buffer = StringBuffer();
    for (int i = 0; i < str.length; i++) {
      if (i > 0 && (str.length - i) % 3 == 0) buffer.write('.');
      buffer.write(str[i]);
    }
    return buffer.toString();
  }

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final isComic = widget.isComic;
    final headerIconColor = isComic
        ? C.contrastTextOn(widget.role.color)
        : Colors.white;

    return Container(
      constraints:
          BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.92),
      decoration: BoxDecoration(
        color: C.bgDeep,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        border: isComic
            ? Border.all(color: Colors.black, width: 4)
            : null,
      ),
      child: Stack(
        children: [
          Positioned.fill(
            child: Container(
              decoration: isComic
                  ? BoxDecoration(
                      color: C.bg,
                      borderRadius:
                          const BorderRadius.vertical(top: Radius.circular(20)))
                  : BoxDecoration(
                      gradient: RadialGradient(
                        center: const Alignment(-0.3, -0.3),
                        radius: 1.2,
                        colors: [C.bg, C.bgDark, C.bgDeep],
                        stops: const [0.0, 0.6, 1.0]),
                      borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(20))),
            ),
          ),
          SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: Padding(
              padding: EdgeInsets.only(
                  bottom: MediaQuery.of(context).viewInsets.bottom + 20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    margin: const EdgeInsets.only(top: 12, bottom: 4),
                    width: 50, height: isComic ? 5 : 4,
                    decoration: BoxDecoration(
                      color: isComic ? Colors.black : C.textSub,
                      borderRadius: BorderRadius.circular(2)),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // ── HEADER ──
                        Row(
                          children: [
                            Container(
                              width: 48, height: 48,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: isComic ? null
                                    : RadialGradient(
                                        colors: [
                                          widget.role.color.withOpacity(0.5),
                                          widget.role.color.withOpacity(0.2),
                                          Colors.black]),
                                color: isComic ? widget.role.color : null,
                                border: Border.all(
                                    color: isComic ? Colors.black
                                        : widget.role.color,
                                    width: isComic ? 4 : 2),
                              ),
                              child: Icon(widget.role.icon,
                                  color: headerIconColor, size: 24),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('UPGRADE KE ${widget.role.name}',
                                      style: TextStyle(
                                        color: isComic ? C.comicText
                                            : C.accentHi,
                                        fontSize: isComic ? 17 : 13,
                                        fontWeight: FontWeight.w900,
                                        fontFamily: isComic
                                            ? 'Bangers' : 'Orbitron',
                                        letterSpacing: 1.5,
                                        shadows: isComic
                                            ? [
                                                Shadow(
                                                  color: C.comicTextOutline,
                                                  offset: const Offset(1, 1),
                                                  blurRadius: 0,
                                                ),
                                              ]
                                            : null)),
                                  const SizedBox(height: 4),
                                  Text('Rp ${_formatPrice(widget.role.price)}',
                                      style: TextStyle(
                                        color: isComic ? C.comicText
                                            : widget.role.color,
                                        fontSize: isComic ? 15 : 12,
                                        fontWeight: FontWeight.w900,
                                        fontFamily: isComic
                                            ? 'Bangers' : 'Orbitron',
                                        letterSpacing: 0.5)),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 22),

                        // ── STEP 1: PILIH METODE BAYAR ──
                        Row(
                          children: [
                            if (!isComic) _Screw(C: C, size: 12),
                            if (!isComic) const SizedBox(width: 10),
                            Text('1. PILIH METODE BAYAR',
                                style: TextStyle(
                                  color: isComic ? C.comicText : C.accent,
                                  fontSize: isComic ? 14 : 11,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: isComic
                                      ? 'Bangers' : 'Orbitron',
                                  letterSpacing: 2,
                                  shadows: isComic
                                      ? [
                                          Shadow(
                                            color: C.comicTextOutline,
                                            offset: const Offset(1, 1),
                                            blurRadius: 0,
                                          ),
                                        ]
                                      : null)),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: _PaymentMethodCard(
                                C: C,
                                isComic: isComic,
                                id: 'qris',
                                label: 'QRIS',
                                subtitle: 'Scan QR',
                                icon: Icons.qr_code_2_rounded,
                                color: C.accentHi,
                                isSelected: _paymentMethod == 'qris',
                                onTap: () {
                                  HapticFeedback.selectionClick();
                                  setState(() => _paymentMethod = 'qris');
                                },
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: _PaymentMethodCard(
                                C: C,
                                isComic: isComic,
                                id: 'dana',
                                label: 'DANA',
                                subtitle: 'Transfer manual',
                                icon: Icons.account_balance_wallet_rounded,
                                color: const Color(0xFF118EEA),
                                isSelected: _paymentMethod == 'dana',
                                onTap: () {
                                  HapticFeedback.selectionClick();
                                  setState(() => _paymentMethod = 'dana');
                                },
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),

                        // ── TOMBOL TAMPILKAN DETAIL BAYAR ──
                        if (_paymentMethod == 'qris')
                          _IndustrialButton(
                            C: C,
                            color: C.accentHi,
                            height: 48,
                            onTap: _showQrisDialog,
                            child: const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.qr_code_scanner_rounded, size: 16),
                                SizedBox(width: 8),
                                Text('TAMPILKAN QRIS',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      fontFamily: 'Orbitron',
                                      letterSpacing: 2,
                                      fontSize: 11)),
                              ],
                            ),
                          ),
                        if (_paymentMethod == 'dana')
                          _IndustrialButton(
                            C: C,
                            color: const Color(0xFF118EEA),
                            height: 48,
                            onTap: _showDanaDialog,
                            child: const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.account_balance_wallet_rounded,
                                    size: 16),
                                SizedBox(width: 8),
                                Text('TAMPILKAN NOMOR DANA',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      fontFamily: 'Orbitron',
                                      letterSpacing: 2,
                                      fontSize: 11)),
                              ],
                            ),
                          ),

                        const SizedBox(height: 22),

                        // ── STEP 2: UPLOAD BUKTI ──
                        Row(
                          children: [
                            if (!isComic) _Screw(C: C, size: 12),
                            if (!isComic) const SizedBox(width: 10),
                            Text('2. UPLOAD BUKTI TRANSFER',
                                style: TextStyle(
                                  color: isComic ? C.comicText : C.accent,
                                  fontSize: isComic ? 14 : 11,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: isComic
                                      ? 'Bangers' : 'Orbitron',
                                  letterSpacing: 2,
                                  shadows: isComic
                                      ? [
                                          Shadow(
                                            color: C.comicTextOutline,
                                            offset: const Offset(1, 1),
                                            blurRadius: 0,
                                          ),
                                        ]
                                      : null)),
                          ],
                        ),
                        const SizedBox(height: 12),
                        if (_proofImage != null)
                          _MetalPlate(
                            C: C,
                            padding: const EdgeInsets.all(12),
                            child: Column(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(10),
                                  child: Image.file(_proofImage!,
                                      width: double.infinity,
                                      height: 220,
                                      fit: BoxFit.cover),
                                ),
                                const SizedBox(height: 12),
                                Row(
                                  children: [
                                    Expanded(
                                      child: _IndustrialButton(
                                        C: C, color: C.accent, height: 44,
                                        onTap: _showImageOptions,
                                        child: const Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Icon(Icons.refresh_rounded,
                                                size: 14),
                                            SizedBox(width: 6),
                                            Text('GANTI',
                                                style: TextStyle(
                                                  fontWeight:
                                                      FontWeight.w900,
                                                  fontFamily: 'Orbitron',
                                                  letterSpacing: 2,
                                                  fontSize: 11)),
                                          ],
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: _IndustrialButton(
                                        C: C, color: C.primaryHi, height: 44,
                                        onTap: () => setState(
                                            () => _proofImage = null),
                                        child: const Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Icon(Icons.delete_rounded,
                                                size: 14),
                                            SizedBox(width: 6),
                                            Text('HAPUS',
                                                style: TextStyle(
                                                  fontWeight:
                                                      FontWeight.w900,
                                                  fontFamily: 'Orbitron',
                                                  letterSpacing: 2,
                                                  fontSize: 11)),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          )
                        else
                          GestureDetector(
                            onTap: _showImageOptions,
                            child: _InsetPanel(
                              C: C,
                              padding:
                                  const EdgeInsets.symmetric(vertical: 40),
                              child: Column(
                                children: [
                                  Container(
                                    width: 56, height: 56,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: isComic ? null
                                          : RadialGradient(colors: [
                                              C.text, C.bg, C.bgDark]),
                                      color: isComic ? C.primaryHi : null,
                                      border: Border.all(
                                          color: isComic
                                              ? Colors.black
                                              : C.accent,
                                          width: isComic ? 4 : 2),
                                    ),
                                    child: Icon(Icons.cloud_upload_rounded,
                                        color: isComic
                                            ? C.contrastTextOn(C.primaryHi)
                                            : C.accent,
                                        size: 26),
                                  ),
                                  const SizedBox(height: 12),
                                  Text('TAP UNTUK UPLOAD',
                                      style: TextStyle(
                                        color: isComic
                                            ? C.comicText
                                            : C.accent,
                                        fontSize: isComic ? 16 : 13,
                                        fontWeight: FontWeight.w900,
                                        fontFamily: isComic
                                            ? 'Bangers'
                                            : 'Orbitron',
                                        letterSpacing: 1.5,
                                        shadows: isComic
                                            ? [
                                                Shadow(
                                                  color: C
                                                      .comicTextOutline,
                                                  offset:
                                                      const Offset(1, 1),
                                                  blurRadius: 0,
                                                ),
                                              ]
                                            : null)),
                                  const SizedBox(height: 4),
                                  Text('Format: JPG / PNG',
                                      style: TextStyle(
                                        color: isComic
                                            ? C.comicTextSub
                                            : C.text.withOpacity(0.5),
                                        fontSize: isComic ? 12 : 10,
                                        fontFamily: isComic
                                            ? 'ComicNeue'
                                            : 'ShareTechMono',
                                        fontWeight: FontWeight.w600)),
                                ],
                              ),
                            ),
                          ),
                        const SizedBox(height: 22),

                        // ── STEP 3: KIRIM ──
                        _IndustrialButton(
                          C: C,
                          color: _isUploading ? C.bg : C.primaryHi,
                          height: 54,
                          onTap: _isUploading ? null : _submitUpgrade,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              if (_isUploading)
                                SizedBox(
                                  width: 18, height: 18,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2.5,
                                    valueColor:
                                        AlwaysStoppedAnimation<Color>(
                                            C.accent)),
                                )
                              else
                                const Icon(Icons.send_rounded, size: 16),
                              const SizedBox(width: 10),
                              Text(
                                _isUploading
                                    ? 'MENGIRIM...'
                                    : 'KIRIM BUKTI',
                                style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  fontFamily: isComic
                                      ? 'Bangers'
                                      : 'Orbitron',
                                  letterSpacing: 2,
                                  fontSize: isComic ? 15 : 12),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          'Setelah admin approve, role lu otomatis berubah.\n'
                          'Proses verifikasi biasanya 1x24 jam.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: isComic
                                ? C.comicTextSub
                                : C.text.withOpacity(0.5),
                            fontSize: isComic ? 12 : 10,
                            fontFamily:
                                isComic ? 'ComicNeue' : 'ShareTechMono',
                            height: 1.5),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
// PAYMENT METHOD CARD
// ══════════════════════════════════════════════════════════════
class _PaymentMethodCard extends StatelessWidget {
  final AppPalette C;
  final bool isComic;
  final String id;
  final String label;
  final String subtitle;
  final IconData icon;
  final Color color;
  final bool isSelected;
  final VoidCallback onTap;

  const _PaymentMethodCard({
    required this.C,
    required this.isComic,
    required this.id,
    required this.label,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 12),
        decoration: BoxDecoration(
          color: isComic
              ? (isSelected ? color : C.bgDark)
              : (isSelected ? color.withOpacity(0.15) : C.bgDark),
          borderRadius: BorderRadius.circular(isComic ? 14 : 12),
          border: Border.all(
            color: isComic
                ? Colors.black
                : (isSelected ? color : C.textSub.withOpacity(0.3)),
            width: isComic ? (isSelected ? 4 : 3) : (isSelected ? 2 : 1),
          ),
          boxShadow: isComic
              ? const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(4, 4),
                    blurRadius: 0,
                  ),
                ]
              : [
                  if (isSelected)
                    BoxShadow(color: color.withOpacity(0.4), blurRadius: 12),
                ],
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: isComic
                  ? (isSelected ? Colors.white : C.comicText)
                  : color,
              size: 32,
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                color: isComic
                    ? (isSelected ? Colors.white : C.comicText)
                    : (isSelected ? color : C.text),
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                fontSize: isComic ? 16 : 13,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              subtitle,
              style: TextStyle(
                color: isComic
                    ? (isSelected
                        ? Colors.white.withOpacity(0.85)
                        : C.comicTextSub)
                    : (isSelected ? color : C.textSub),
                fontSize: isComic ? 11 : 9,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                fontWeight: FontWeight.w600,
              ),
            ),
            if (isSelected) ...[
              const SizedBox(height: 6),
              Icon(
                Icons.check_circle_rounded,
                color: isComic ? Colors.white : color,
                size: 16,
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ══════════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}