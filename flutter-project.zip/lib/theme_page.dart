// lib/theme_page.dart
import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'smart_widgets.dart';
import 'theme_style_page.dart';

class ThemePage extends StatelessWidget {
  const ThemePage({super.key});

  @override
  Widget build(BuildContext context) {
    return StyleBuilder(
      builder: (context, C, kit) {
        final isComic = kit.style == ThemeStyle.comic3d;

        return Scaffold(
          backgroundColor: C.bg,
          appBar: AppBar(
            backgroundColor: C.bgDark,
            elevation: 0,
            iconTheme: IconThemeData(color: C.accent),
            title: Text(
              'PILIH THEME',
              style: TextStyle(
                color: isComic ? C.comicText : C.accentHi,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                fontWeight: FontWeight.w900,
                fontSize: isComic ? 20 : 16,
                letterSpacing: isComic ? 2 : 3,
                shadows: isComic
                    ? [
                        Shadow(
                          color: C.comicTextOutline,
                          offset: const Offset(2, 2),
                          blurRadius: 0,
                        ),
                      ]
                    : [
                        Shadow(color: C.accent, blurRadius: 8),
                      ],
              ),
            ),
            centerTitle: true,
          ),
          body: SmartBackground(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SmartText(
                    'PILIH WARNA APP',
                    fontSize: 12,
                    color: C.accent,
                    letterSpacing: 2,
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Warna bakal ke-apply ke SEMUA halaman & tersimpan otomatis',
                    style: TextStyle(
                      color: isComic ? C.comicTextSub : C.textSub,
                      fontSize: 11,
                      fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                    ),
                  ),
                  const SizedBox(height: 16),
                  _StyleButton(kit: kit),
                  Expanded(
                    child: GridView.builder(
                      physics: const BouncingScrollPhysics(),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        childAspectRatio: 0.95,
                      ),
                      itemCount: AppPalettes.all.length,
                      itemBuilder: (context, index) {
                        final p = AppPalettes.all[index];
                        final selected = p.id == C.id;
                        return _PaletteCard(
                          palette: p,
                          selected: selected,
                          isComic: isComic,
                          onTap: () async {
                            await AppTheme.setPalette(p);
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    'Theme diganti ke ${p.name}',
                                    style: TextStyle(
                                      fontFamily: isComic
                                          ? 'ComicNeue'
                                          : 'ShareTechMono',
                                      fontWeight: FontWeight.w700,
                                      color: p.text,
                                    ),
                                  ),
                                  backgroundColor: p.bgDark,
                                  duration: const Duration(seconds: 2),
                                  behavior: SnackBarBehavior.floating,
                                ),
                              );
                            }
                          },
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: C.bgDark,
                      borderRadius: BorderRadius.circular(isComic ? 14 : 10),
                      border: Border.all(
                        color: isComic
                            ? Colors.black
                            : C.primary.withOpacity(0.5),
                        width: isComic ? 3 : 1.5,
                      ),
                      boxShadow: isComic
                          ? const [
                              BoxShadow(
                                color: Colors.black,
                                offset: Offset(4, 4),
                                blurRadius: 0,
                              ),
                            ]
                          : null,
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.info_outline,
                            color: C.accent, size: 18),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Theme aktif: ${C.name}  ·  Style: ${kit.style == ThemeStyle.comic3d ? "3D COMIC" : "ORIGINAL"}',
                            style: TextStyle(
                              color: isComic ? C.comicText : C.text,
                              fontFamily: isComic
                                  ? 'ComicNeue'
                                  : 'ShareTechMono',
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════
// TOMBOL GANTI STYLE VISUAL
// ═══════════════════════════════════════════════════════════
class _StyleButton extends StatelessWidget {
  final StyleKit kit;
  const _StyleButton({required this.kit});

  @override
  Widget build(BuildContext context) {
    final C = kit.C;
    final isComic = kit.style == ThemeStyle.comic3d;

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const ThemeStylePage()),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(14),
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          color: C.bgDark,
          borderRadius: BorderRadius.circular(isComic ? 16 : 12),
          border: Border.all(
            color: isComic ? Colors.black : C.accent,
            width: isComic ? 3.5 : 2,
          ),
          boxShadow: isComic
              ? const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(5, 5),
                    blurRadius: 0,
                  ),
                ]
              : null,
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: C.accent.withOpacity(0.15),
                border: Border.all(
                  color: C.accent,
                  width: isComic ? 2.5 : 1.5,
                ),
              ),
              child: Icon(
                Icons.style_rounded,
                color: C.accent,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'GANTI STYLE VISUAL',
                    style: TextStyle(
                      color: isComic ? C.comicText : C.text,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: isComic ? 14 : 12,
                      letterSpacing: isComic ? 1 : 1.5,
                      shadows: isComic
                          ? [
                              Shadow(
                                color: C.comicTextOutline,
                                offset: const Offset(1, 1),
                                blurRadius: 0,
                              ),
                            ]
                          : null,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    isComic
                        ? '3D Comic aktif · tap untuk ganti'
                        : 'Original / 3D Comic',
                    style: TextStyle(
                      color: isComic
                          ? C.comicTextSub
                          : C.text.withOpacity(0.6),
                      fontSize: 10,
                      fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: C.accent,
              size: 14,
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// CARD PREVIEW PALETTE
// ═══════════════════════════════════════════════════════════
class _PaletteCard extends StatelessWidget {
  final AppPalette palette;
  final bool selected;
  final bool isComic;
  final VoidCallback onTap;

  const _PaletteCard({
    required this.palette,
    required this.selected,
    required this.isComic,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    // Preview card pake palette-nya SENDIRI
    final cardText = isComic
        ? palette.comicText
        : palette.text;
    final cardTextSub = isComic
        ? palette.comicTextSub
        : palette.textSub;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(isComic ? 16 : 14),
          color: palette.bgDark,
          border: Border.all(
            color: selected
                ? (isComic ? Colors.black : palette.accent)
                : palette.primary.withOpacity(0.3),
            width: selected ? (isComic ? 4 : 2.5) : (isComic ? 3 : 1.5),
          ),
          boxShadow: isComic
              ? const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(5, 5),
                    blurRadius: 0,
                  ),
                ]
              : [
                  if (selected)
                    BoxShadow(
                      color: palette.accent.withOpacity(0.5),
                      blurRadius: 16,
                      spreadRadius: 1,
                    ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.6),
                    offset: const Offset(0, 4),
                    blurRadius: 8,
                  ),
                ],
        ),
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  height: 50,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.vertical(
                        top: Radius.circular(isComic ? 12 : 12)),
                    gradient: LinearGradient(
                      colors: [palette.primary, palette.primaryLo],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: Center(
                    child: Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: palette.accent,
                        border: isComic
                            ? Border.all(color: Colors.black, width: 2.5)
                            : null,
                        boxShadow: isComic
                            ? null
                            : [
                                BoxShadow(
                                  color: palette.accent.withOpacity(0.8),
                                  blurRadius: 12,
                                  spreadRadius: 2,
                                ),
                              ],
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          height: 6,
                          width: 40,
                          decoration: BoxDecoration(
                            color: palette.accent,
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Container(
                          height: 4,
                          width: 60,
                          decoration: BoxDecoration(
                            color: palette.primaryLo,
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                        const Spacer(),
                        Text(
                          palette.name,
                          style: TextStyle(
                            color: cardText,
                            fontFamily:
                                isComic ? 'Bangers' : 'Orbitron',
                            fontWeight: FontWeight.w900,
                            fontSize: isComic ? 13 : 11,
                            letterSpacing: isComic ? 0.8 : 0.5,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 2),
                        Text(
                          selected ? '✓ AKTIF' : 'Tap untuk pilih',
                          style: TextStyle(
                            color: selected
                                ? palette.accent
                                : cardTextSub,
                            fontFamily:
                                isComic ? 'ComicNeue' : 'ShareTechMono',
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            if (selected)
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: palette.accent,
                    border: isComic
                        ? Border.all(color: Colors.black, width: 2)
                        : null,
                    boxShadow: isComic
                        ? null
                        : [
                            BoxShadow(
                              color: palette.accent.withOpacity(0.6),
                              blurRadius: 8,
                            ),
                          ],
                  ),
                  child: Icon(
                    Icons.check,
                    color: palette.bgDeep,
                    size: 14,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}