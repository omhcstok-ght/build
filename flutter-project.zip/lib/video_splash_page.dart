// lib/video_splash_page.dart
import 'dart:math' as math;
import 'dart:io'; // ✅ TAMBAHKAN IMPORT INI UNTUK CEK FILE
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'package:shared_preferences/shared_preferences.dart'; // ✅ TAMBAHKAN IMPORT INI
import 'app_theme.dart';
import 'dashboard_page.dart';
import 'welcome_intro_page.dart';

// ═══════════════════════════════════════════════════════
// GLOBAL PULSE
// ═══════════════════════════════════════════════════════
class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;
  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }
  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

// ═══════════════════════════════════════════════════════
// LED
// ═══════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18),
        ),
      );
    }
    if (!blink) return _dot(1.0);
    return ValueListenableBuilder<double>(
      valueListenable: _Pulse.v,
      builder: (_, v, __) => _dot(0.45 + v * 0.55),
    );
  }

  Widget _dot(double opacity) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            center: const Alignment(-0.35, -0.35),
            colors: [
              Colors.white.withOpacity(0.85 * opacity),
              color.withOpacity(opacity),
              color.withOpacity(0.55 * opacity),
            ],
            stops: const [0.0, 0.4, 1.0],
          ),
          border: Border.all(
            color: Colors.black.withOpacity(0.85),
            width: size * 0.1,
          ),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.75 * opacity),
              blurRadius: size * 1.4,
              spreadRadius: size * 0.2,
            ),
            BoxShadow(
              color: color.withOpacity(0.35 * opacity),
              blurRadius: size * 2.6,
              spreadRadius: size * 0.4,
            ),
          ],
        ),
      );
}

// ═══════════════════════════════════════════════════════
// VIDEO SPLASH PAGE
// ═══════════════════════════════════════════════════════
class VideoSplashPage extends StatefulWidget {
  final Map<String, dynamic> dashboardArgs;

  const VideoSplashPage({super.key, required this.dashboardArgs});

  @override
  State<VideoSplashPage> createState() => _VideoSplashPageState();
}

class _VideoSplashPageState extends State<VideoSplashPage>
    with TickerProviderStateMixin {
  VideoPlayerController? _controller; // ✅ Dibuat nullable agar aman
  bool _isInitialized = false;
  bool _navigated = false;

  late AnimationController _entryCtrl;
  late AnimationController _scanCtrl;
  late Animation<double> _logoFade;

  @override
  void initState() {
    super.initState();
    _Pulse.ensureStarted();
    _setupAnimations();
    _initVideo();
  }

  void _setupAnimations() {
    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..forward();

    _scanCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();

    _logoFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _entryCtrl,
        curve: const Interval(0.0, 0.5, curve: Curves.easeOut),
      ),
    );
  }

  // ✅ LOGIKA BARU UNTUK MEMBACA VIDEO KUSTOM
  Future<void> _initVideo() async {
    final prefs = await SharedPreferences.getInstance();
    final customPath = prefs.getString('custom_splash_video');

    bool useCustom = false;
    if (customPath != null) {
      try {
        // Cek apakah file video benar-benar ada di HP
        if (File(customPath).existsSync()) {
          useCustom = true;
        }
      } catch (_) {}
    }

    // Tentukan sumber video (File dari HP atau Asset bawaan)
    _controller = useCustom
        ? VideoPlayerController.file(File(customPath!))
        : VideoPlayerController.asset('assets/videos/splash.mp4');

    try {
      await _controller!.initialize();
      await _controller!.setVolume(1.0);
      await _controller!.setLooping(false);
      _controller!.addListener(_onVideoEnd);
      await _controller!.play();
      if (mounted) setState(() => _isInitialized = true);
    } catch (e) {
      // Jika video kustom rusak/gagal dimuat, otomatis kembali ke video default
      if (useCustom) {
        try { _controller?.dispose(); } catch (_) {}
        
        _controller = VideoPlayerController.asset('assets/videos/splash.mp4');
        try {
          await _controller!.initialize();
          await _controller!.setVolume(1.0);
          await _controller!.setLooping(false);
          _controller!.addListener(_onVideoEnd);
          await _controller!.play();
          if (mounted) setState(() => _isInitialized = true);
          return;
        } catch (_) {
          _goToWelcome();
        }
      } else {
        _goToWelcome();
      }
    }
  }

  void _onVideoEnd() {
    if (!_navigated &&
        _controller != null &&
        _controller!.value.isInitialized &&
        _controller!.value.position >= _controller!.value.duration &&
        _controller!.value.duration > Duration.zero) {
      _goToWelcome();
    }
  }

  void _goToWelcome() {
    if (_navigated) return;
    _navigated = true;
    HapticFeedback.mediumImpact();

    if (mounted) {
      Navigator.pushReplacement(
        context,
        PageRouteBuilder(
          pageBuilder: (_, __, ___) => WelcomeIntroPage(
            dashboardArgs: widget.dashboardArgs,
          ),
          transitionDuration: const Duration(milliseconds: 500),
          transitionsBuilder: (_, anim, __, child) =>
              FadeTransition(opacity: anim, child: child),
        ),
      );
    }
  }

  @override
  void dispose() {
    _controller?.removeListener(_onVideoEnd);
    _controller?.dispose();
    _entryCtrl.dispose();
    _scanCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: isComic ? C.bg : Colors.black,
              body: Stack(
                fit: StackFit.expand,
                children: [
                  if (_isInitialized && _controller != null)
                    FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _controller!.value.size.width,
                        height: _controller!.value.size.height,
                        child: VideoPlayer(_controller!),
                      ),
                    )
                  else
                    Container(
                      color: isComic ? C.bg : C.bgDeep,
                      child: Center(
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(C.accent),
                        ),
                      ),
                    ),

                  Positioned.fill(
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.black.withOpacity(0.4),
                            Colors.black.withOpacity(0.2),
                            Colors.black.withOpacity(0.5),
                            Colors.black.withOpacity(0.85),
                            Colors.black.withOpacity(0.95),
                          ],
                          stops: const [0.0, 0.25, 0.55, 0.8, 1.0],
                        ),
                      ),
                    ),
                  ),

                  AnimatedBuilder(
                    animation: _scanCtrl,
                    builder: (_, __) => Positioned(
                      top: _scanCtrl.value *
                          MediaQuery.of(context).size.height,
                      left: 0,
                      right: 0,
                      child: Container(
                        height: 2,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.transparent,
                              C.accent.withOpacity(0.4),
                              C.accent.withOpacity(0.8),
                              C.accent.withOpacity(0.4),
                              Colors.transparent,
                            ],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: C.accent.withOpacity(0.5),
                              blurRadius: 12,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  // ── HANYA TOMBOL SKIP ──
                  Positioned(
                    top: MediaQuery.of(context).padding.top + 12,
                    right: 12,
                    child: FadeTransition(
                      opacity: _logoFade,
                      child: _buildSkipButton(C, isComic),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════
  // SKIP BUTTON
  // ═══════════════════════════════════════════════════════
  Widget _buildSkipButton(AppPalette C, bool isComic) {
    return GestureDetector(
      onTap: _goToWelcome,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: isComic
            ? BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: C.bgDark,
                border: Border.all(color: Colors.black, width: 3),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(3, 3),
                    blurRadius: 0,
                  ),
                ],
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [C.bg, C.bgDark],
                ),
                border: Border.all(
                  color: C.textSub.withOpacity(0.5),
                  width: 1,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.75),
                    offset: const Offset(0, 3),
                    blurRadius: 6,
                  ),
                ],
              ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _Led(color: C.accent, size: 5, blink: true),
            const SizedBox(width: 8),
            Text(
              'SKIP',
              style: TextStyle(
                color: isComic ? C.comicText : C.text,
                fontSize: isComic ? 12 : 10,
                fontWeight: FontWeight.w900,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: 2,
                shadows: isComic
                    ? [
                        Shadow(
                          color: C.comicTextOutline,
                          offset: const Offset(1, 1),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
            ),
            const SizedBox(width: 6),
            Icon(
              Icons.skip_next_rounded,
              color: C.primaryHi,
              size: 14,
            ),
          ],
        ),
      ),
    );
  }
}