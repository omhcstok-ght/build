// lib/owner_page.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'app_theme.dart';
import 'api_config.dart';

class OwnerPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const OwnerPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<OwnerPage> createState() => _OwnerPageState();
}

class _OwnerPageState extends State<OwnerPage> {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = [
    'owner', 'admin', 'vip', 'reseller', 'member',
  ];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'member';
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _fetchUsers();
  }

  @override
  void dispose() {
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    deleteController.dispose();
    editUsernameController.dispose();
    editDayController.dispose();
    super.dispose();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/listUsers?key=$sessionKey'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList
          .where((u) => u['role'] == selectedRole)
          .toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(
      start,
      end > filteredList.length ? filteredList.length : end,
    );
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/deleteUser?key=$sessionKey&username=$username'),
      );
      final data = jsonDecode(res.body);

      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();

    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        '$baseUrl/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$newUserRole',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _alert("Sukses", "Akun berhasil dibuat sebagai ${newUserRole.toUpperCase()}.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        newUserRole = 'member';
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();

    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        '$baseUrl/editUser?key=$sessionKey&username=$u&addDays=$d',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    final C = AppTheme.current.value;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;

    showDialog(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: isComic
            ? Container(
                decoration: BoxDecoration(
                  color: C.bgDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.black, width: 4),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(6, 6),
                      blurRadius: 0,
                    ),
                  ],
                ),
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: C.primaryHi,
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.black, width: 3),
                          ),
                          child: Icon(Icons.info_outline,
                              color: C.contrastTextOn(C.primaryHi),
                              size: 18),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            title.toUpperCase(),
                            style: TextStyle(
                              color: C.comicText,
                              fontFamily: 'Bangers',
                              fontSize: 18,
                              letterSpacing: 2,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Text(
                      message,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: C.comicTextSub,
                        fontFamily: 'ComicNeue',
                        fontSize: 13,
                        height: 1.5,
                      ),
                    ),
                    const SizedBox(height: 20),
                    _ComicDialogButton(
                      C: C,
                      label: 'OK',
                      onTap: () => Navigator.pop(context),
                    ),
                  ],
                ),
              )
            : AlertDialog(
                backgroundColor: C.bgDark,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                  side: BorderSide(color: C.accent.withValues(alpha: 0.3)),
                ),
                title: Row(
                  children: [
                    Icon(Icons.info_outline, color: C.accent),
                    const SizedBox(width: 10),
                    Text(title,
                        style: TextStyle(
                            color: C.text, fontFamily: 'Orbitron')),
                  ],
                ),
                content: Text(message,
                    style: TextStyle(
                        color: C.textSub, fontFamily: 'ShareTechMono')),
                actions: [
                  Center(
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [C.accent, C.accentHi],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: Text(
                          "OK",
                          style: TextStyle(
                              color: C.bgDeep,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildInput({
    required AppPalette C,
    required bool isComic,
    required String label,
    required TextEditingController controller,
    required dynamic icon,
    TextInputType type = TextInputType.text,
  }) {
    if (isComic) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 4, bottom: 6),
              child: Text(
                label.toUpperCase(),
                style: const TextStyle(
                  color: Colors.black,
                  fontFamily: 'Bangers',
                  fontSize: 13,
                  letterSpacing: 1.5,
                ),
              ),
            ),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.black, width: 3),
              ),
              child: TextField(
                controller: controller,
                keyboardType: type,
                style: const TextStyle(
                  color: Colors.black,
                  fontFamily: 'ComicNeue',
                  fontWeight: FontWeight.w700,
                  fontSize: 14,
                ),
                cursorColor: Colors.black,
                decoration: InputDecoration(
                  prefixIcon: _DynamicIcon(icon, color: C.primaryHi),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 14),
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: TextStyle(color: C.text, fontFamily: 'ShareTechMono'),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: C.accent.withValues(alpha: 0.7)),
          prefixIcon: _DynamicIcon(icon, color: C.accent.withValues(alpha: 0.7)),
          filled: true,
          fillColor: C.bgDeep,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: C.bg),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: C.bg),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: C.accent, width: 2),
          ),
        ),
      ),
    );
  }

  Widget _buildGlassCard({
    required AppPalette C,
    required bool isComic,
    required String title,
    required dynamic icon,
    required List<Widget> children,
  }) {
    if (isComic) {
      return Container(
        margin: const EdgeInsets.only(bottom: 25),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: C.bgDark,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(6, 6),
              blurRadius: 0,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: C.primaryHi,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.black, width: 3),
                  ),
                  child: _DynamicIcon(icon,
                      color: C.contrastTextOn(C.primaryHi)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    title,
                    style: TextStyle(
                      color: C.comicText,
                      fontSize: 18,
                      fontFamily: 'Bangers',
                      letterSpacing: 2,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            ...children,
          ],
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 25),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: C.bgDark.withValues(alpha: 0.6),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: C.accent.withValues(alpha: 0.08)),
        boxShadow: [
          BoxShadow(
            color: C.accent.withValues(alpha: 0.03),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: C.accent.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: _DynamicIcon(icon, color: C.accent),
              ),
              const SizedBox(width: 12),
              Text(
                title,
                style: TextStyle(
                  color: C.text,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          ...children,
        ],
      ),
    );
  }

  Widget _buildUserItem(AppPalette C, bool isComic, Map user) {
    if (isComic) {
      return Container(
        margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.black, width: 3),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: C.primaryHi,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.black, width: 2.5),
              ),
              child: Icon(Icons.person,
                  color: C.contrastTextOn(C.primaryHi)),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    user['username'],
                    style: const TextStyle(
                      color: Colors.black,
                      fontFamily: 'Bangers',
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    "ROLE: ${user['role'].toString().toUpperCase()} | EXP: ${user['expiredDate']}",
                    style: TextStyle(
                      color: Colors.black.withValues(alpha: 0.6),
                      fontFamily: 'ComicNeue',
                      fontWeight: FontWeight.w700,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
            GestureDetector(
              onTap: () async {
                final confirm = await _confirmDelete(C, isComic);
                if (confirm == true) {
                  deleteController.text = user['username'];
                  _deleteUser();
                }
              },
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: C.accent,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.black, width: 2.5),
                ),
                child: Icon(Icons.delete_outline,
                    color: C.contrastTextOn(C.accent), size: 18),
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: C.bgDeep,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: C.accent.withValues(alpha: 0.08)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: C.accent.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.person, color: C.accent),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['username'],
                  style: TextStyle(
                    color: C.text,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "ROLE: ${user['role'].toString().toUpperCase()} | EXP: ${user['expiredDate']}",
                  style: TextStyle(color: C.textSub, fontSize: 13),
                ),
              ],
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: C.primaryHi.withValues(alpha: 0.1),
              shape: BoxShape.circle,
              border: Border.all(
                  color: C.primaryHi.withValues(alpha: 0.3)),
            ),
            child: IconButton(
              icon: Icon(Icons.delete_outline, color: C.primaryHi),
              onPressed: () async {
                final confirm = await _confirmDelete(C, isComic);
                if (confirm == true) {
                  deleteController.text = user['username'];
                  _deleteUser();
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  Future<bool?> _confirmDelete(AppPalette C, bool isComic) {
    return showDialog<bool>(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: isComic
            ? Container(
                decoration: BoxDecoration(
                  color: C.bgDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.black, width: 4),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black,
                      offset: Offset(6, 6),
                      blurRadius: 0,
                    ),
                  ],
                ),
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'HAPUS USER INI?',
                      style: TextStyle(
                        color: C.comicText,
                        fontFamily: 'Bangers',
                        fontSize: 20,
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: _ComicDialogButton(
                            C: C,
                            label: 'BATAL',
                            color: C.bgDark,
                            onTap: () => Navigator.pop(context, false),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _ComicDialogButton(
                            C: C,
                            label: 'HAPUS',
                            color: C.primaryHi,
                            onTap: () => Navigator.pop(context, true),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              )
            : AlertDialog(
                backgroundColor: C.bgDark,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                  side: BorderSide(color: C.accent.withValues(alpha: 0.3)),
                ),
                title: Text("Konfirmasi", style: TextStyle(color: C.text)),
                content: Text("Hapus user ini?",
                    style: TextStyle(color: C.textSub)),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: Text("Batal",
                        style:
                            TextStyle(color: C.text.withValues(alpha: 0.4))),
                  ),
                  TextButton(
                    onPressed: () => Navigator.pop(context, true),
                    child:
                        Text("Hapus", style: TextStyle(color: C.primaryHi)),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildPagination(AppPalette C, bool isComic) {
    if (isComic) {
      return Wrap(
        spacing: 8,
        runSpacing: 8,
        children: List.generate(totalPages, (index) {
          final page = index + 1;
          final isActive = currentPage == page;
          return GestureDetector(
            onTap: () => setState(() => currentPage = page),
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: isActive ? C.primaryHi : C.bgDark,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.black, width: 3),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(2, 2),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: Text(
                "$page",
                style: TextStyle(
                  color: isActive
                      ? C.contrastTextOn(C.primaryHi)
                      : C.comicText,
                  fontFamily: 'Bangers',
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
            ),
          );
        }),
      );
    }

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        return ElevatedButton(
          onPressed: () => setState(() => currentPage = page),
          style: ElevatedButton.styleFrom(
            backgroundColor:
                currentPage == page ? C.accent : Colors.transparent,
            foregroundColor:
                currentPage == page ? Colors.black : C.text.withValues(alpha: 0.4),
            padding: const EdgeInsets.symmetric(horizontal: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
              side: BorderSide(color: C.accent.withValues(alpha: 0.2)),
            ),
          ),
          child: Text("$page", style: const TextStyle(fontSize: 12)),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bgDeep,
              body: Container(
                decoration: isComic
                    ? BoxDecoration(color: C.bg)
                    : BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            C.bgDeep,
                            C.accent.withValues(alpha: 0.03),
                            C.bgDeep
                          ],
                        ),
                      ),
                child: Stack(
                  children: [
                    if (isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _ComicHalftonePainter(
                                color: C.primaryLo.withValues(alpha: 0.12)),
                          ),
                        ),
                      ),
                    SafeArea(
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                color: isComic
                                    ? C.primaryHi
                                    : C.accent.withValues(alpha: 0.1),
                                shape: BoxShape.circle,
                                border: isComic
                                    ? Border.all(
                                        color: Colors.black, width: 5)
                                    : Border.all(
                                        color:
                                            C.accent.withValues(alpha: 0.2)),
                                boxShadow: isComic
                                    ? const [
                                        BoxShadow(
                                          color: Colors.black,
                                          offset: Offset(6, 6),
                                          blurRadius: 0,
                                        ),
                                      ]
                                    : null,
                              ),
                              child: Icon(
                                Icons.workspace_premium,
                                color: isComic
                                    ? C.contrastTextOn(C.primaryHi)
                                    : C.accent,
                                size: 40,
                              ),
                            ),
                            const SizedBox(height: 10),
                            isComic
                                ? Text(
                                    "OWNER DASHBOARD",
                                    style: TextStyle(
                                      color: C.comicText,
                                      fontSize: 26,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Bangers',
                                      letterSpacing: 3,
                                      shadows: [
                                        Shadow(
                                          color: C.comicTextOutline
                                              .withValues(alpha: 0.6),
                                          offset: const Offset(2, 2),
                                          blurRadius: 0,
                                        ),
                                      ],
                                    ),
                                  )
                                : ShaderMask(
                                    shaderCallback: (bounds) =>
                                        LinearGradient(
                                      colors: [C.accent, C.accentHi],
                                    ).createShader(bounds),
                                    child: const Text(
                                      "OWNER DASHBOARD",
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 24,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'Orbitron',
                                        letterSpacing: 2,
                                      ),
                                    ),
                                  ),
                            const SizedBox(height: 40),

                            // DELETE USER CARD
                            _buildGlassCard(
                              C: C,
                              isComic: isComic,
                              title: "DELETE USER",
                              icon: FontAwesomeIcons.userSlash,
                              children: [
                                _buildInput(
                                  C: C,
                                  isComic: isComic,
                                  label: "Username Target",
                                  controller: deleteController,
                                  icon: FontAwesomeIcons.user,
                                ),
                                const SizedBox(height: 10),
                                _buildActionButton(
                                  C: C,
                                  isComic: isComic,
                                  color: C.primaryHi,
                                  icon: Icons.delete,
                                  label: "DELETE ACCOUNT",
                                  isLoading: isLoading,
                                  onTap: _deleteUser,
                                ),
                              ],
                            ),

                            // CREATE ACCOUNT CARD
                            _buildGlassCard(
                              C: C,
                              isComic: isComic,
                              title: "CREATE ACCOUNT",
                              icon: FontAwesomeIcons.userPlus,
                              children: [
                                _buildInput(
                                  C: C,
                                  isComic: isComic,
                                  label: "Username",
                                  controller: createUsernameController,
                                  icon: FontAwesomeIcons.user,
                                ),
                                _buildInput(
                                  C: C,
                                  isComic: isComic,
                                  label: "Password",
                                  controller: createPasswordController,
                                  icon: FontAwesomeIcons.lock,
                                ),
                                _buildInput(
                                  C: C,
                                  isComic: isComic,
                                  label: "Durasi (Hari)",
                                  controller: createDayController,
                                  icon: FontAwesomeIcons.calendarDay,
                                  type: TextInputType.number,
                                ),
                                _buildRoleDropdown(
                                  C: C,
                                  isComic: isComic,
                                  value: newUserRole,
                                  onChanged: (val) => setState(
                                      () => newUserRole = val ?? 'member'),
                                ),
                                const SizedBox(height: 20),
                                _buildActionButton(
                                  C: C,
                                  isComic: isComic,
                                  color: C.accent,
                                  icon: null,
                                  label: "CREATE ACCOUNT",
                                  isLoading: isLoading,
                                  onTap: _createAccount,
                                ),
                              ],
                            ),

                            // EXTEND DURATION CARD
                            _buildGlassCard(
                              C: C,
                              isComic: isComic,
                              title: "EXTEND DURATION",
                              icon: FontAwesomeIcons.clock,
                              children: [
                                _buildInput(
                                  C: C,
                                  isComic: isComic,
                                  label: "Username Target",
                                  controller: editUsernameController,
                                  icon: FontAwesomeIcons.userEdit,
                                ),
                                _buildInput(
                                  C: C,
                                  isComic: isComic,
                                  label: "Tambah Hari",
                                  controller: editDayController,
                                  icon: FontAwesomeIcons.calendarPlus,
                                  type: TextInputType.number,
                                ),
                                const SizedBox(height: 10),
                                _buildActionButton(
                                  C: C,
                                  isComic: isComic,
                                  color: C.accent,
                                  icon: null,
                                  label: "ADD DAYS",
                                  isLoading: isLoading,
                                  onTap: _editUser,
                                ),
                              ],
                            ),

                            // USER LIST CARD
                            _buildGlassCard(
                              C: C,
                              isComic: isComic,
                              title: "USER LIST",
                              icon: FontAwesomeIcons.users,
                              children: [
                                _buildRoleDropdown(
                                  C: C,
                                  isComic: isComic,
                                  value: selectedRole,
                                  onChanged: (val) {
                                    if (val != null) {
                                      selectedRole = val;
                                      _filterAndPaginate();
                                    }
                                  },
                                ),
                                const SizedBox(height: 20),
                                isLoading
                                    ? Center(
                                        child: CircularProgressIndicator(
                                          color: isComic
                                              ? Colors.black
                                              : C.accent,
                                        ),
                                      )
                                    : Column(
                                        children: [
                                          ..._getCurrentPageData()
                                              .map((u) => _buildUserItem(
                                                  C, isComic, u))
                                              .toList(),
                                          const SizedBox(height: 20),
                                          _buildPagination(C, isComic),
                                        ],
                                      ),
                              ],
                            ),

                            const SizedBox(height: 30),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 8),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color: isComic
                                      ? Colors.black
                                      : C.accent.withValues(alpha: 0.05),
                                  width: isComic ? 3 : 1,
                                ),
                              ),
                              child: Text(
                                'Syax Projeck',
                                style: TextStyle(
                                  color: isComic
                                      ? C.comicText
                                      : C.accent.withValues(alpha: 0.15),
                                  fontSize: 13,
                                  letterSpacing: 6,
                                  fontFamily: isComic
                                      ? 'Bangers'
                                      : 'Orbitron',
                                  fontWeight: isComic
                                      ? FontWeight.bold
                                      : null,
                                ),
                              ),
                            ),
                            const SizedBox(height: 20),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildActionButton({
    required AppPalette C,
    required bool isComic,
    required Color color,
    required IconData? icon,
    required String label,
    required bool isLoading,
    required VoidCallback onTap,
  }) {
    final fg = isComic ? C.contrastTextOn(color) : Colors.white;
    return GestureDetector(
      onTap: isLoading ? null : onTap,
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          color: isComic ? color : null,
          gradient: isComic
              ? null
              : LinearGradient(
                  colors: [
                    color,
                    color.withValues(alpha: 0.7),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
          borderRadius: BorderRadius.circular(isComic ? 12 : 12),
          border: isComic
              ? Border.all(color: Colors.black, width: 3.5)
              : null,
          boxShadow: isComic
              ? const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(4, 4),
                    blurRadius: 0,
                  ),
                ]
              : [
                  BoxShadow(
                    color: color.withValues(alpha: 0.3),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
        ),
        child: Center(
          child: isLoading
              ? SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: fg,
                  ),
                )
              : Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (icon != null) ...[
                      Icon(icon, size: 18, color: fg),
                      const SizedBox(width: 8),
                    ],
                    Text(
                      label,
                      style: TextStyle(
                        color: fg,
                        fontWeight: FontWeight.bold,
                        letterSpacing: isComic ? 2 : 1,
                        fontFamily:
                            isComic ? 'Bangers' : 'Orbitron',
                        fontSize: isComic ? 16 : 13,
                        shadows: isComic
                            ? const [
                                Shadow(
                                  color: Colors.black,
                                  offset: Offset(1, 1),
                                  blurRadius: 0,
                                ),
                              ]
                            : null,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _buildRoleDropdown({
    required AppPalette C,
    required bool isComic,
    required String value,
    required ValueChanged<String?> onChanged,
  }) {
    if (isComic) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.black, width: 3),
        ),
        child: DropdownButtonHideUnderline(
          child: DropdownButton<String>(
            value: value,
            isExpanded: true,
            dropdownColor: Colors.white,
            style: const TextStyle(
              color: Colors.black,
              fontFamily: 'ComicNeue',
              fontWeight: FontWeight.w700,
              fontSize: 14,
            ),
            items: roleOptions.map((role) {
              return DropdownMenuItem(
                value: role,
                child: Text(role.toUpperCase()),
              );
            }).toList(),
            onChanged: onChanged,
          ),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: C.bgDeep,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: C.accent.withValues(alpha: 0.15)),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          isExpanded: true,
          dropdownColor: C.bgDeep,
          style: TextStyle(color: C.text),
          items: roleOptions.map((role) {
            return DropdownMenuItem(
              value: role,
              child: Text(role.toUpperCase()),
            );
          }).toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// COMIC DIALOG BUTTON
// ═══════════════════════════════════════════════════════════
class _ComicDialogButton extends StatelessWidget {
  final AppPalette C;
  final String label;
  final Color? color;
  final Color? textColor;
  final VoidCallback onTap;

  const _ComicDialogButton({
    required this.C,
    required this.label,
    required this.onTap,
    this.color,
    this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    final bg = color ?? C.primaryHi;
    final fg = textColor ?? C.contrastTextOn(bg);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.black, width: 3.5),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(4, 4),
              blurRadius: 0,
            ),
          ],
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: fg,
              fontFamily: 'Bangers',
              fontSize: 16,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
              shadows: const [
                Shadow(
                  color: Colors.black,
                  offset: Offset(1, 1),
                  blurRadius: 0,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// COMIC HALFTONE PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicHalftonePainter extends CustomPainter {
  final Color color;
  const _ComicHalftonePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicHalftonePainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// DYNAMIC ICON (support FontAwesome & Material)
// ═══════════════════════════════════════════════════════════
class _DynamicIcon extends StatelessWidget {
  final dynamic icon;
  final double? size;
  final Color? color;
  final List<Shadow>? shadows;
  final String? semanticLabel;
  final dynamic textDirection;
  final double? fill;
  final double? weight;
  final double? grade;
  final double? opticalSize;
  final bool? applyTextScaling;

  const _DynamicIcon(
    this.icon, {
    Key? key,
    this.size,
    this.color,
    this.shadows,
    this.semanticLabel,
    this.textDirection,
    this.fill,
    this.weight,
    this.grade,
    this.opticalSize,
    this.applyTextScaling,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (icon == null) return const SizedBox(width: 0, height: 0);

    bool isFontAwesome = false;
    try {
      final str = icon.toString();
      final typeStr = icon.runtimeType.toString();
      if (typeStr.contains('FaIcon') ||
          str.contains('FaIcon') ||
          str.contains('font_awesome_flutter') ||
          (icon is IconData && icon.fontPackage == 'font_awesome_flutter')) {
        isFontAwesome = true;
      }
    } catch (_) {}

    if (isFontAwesome) {
      Widget child = FaIcon(
        icon is IconData ? icon : icon,
        size: size,
        color: color,
        semanticLabel: semanticLabel,
        textDirection: textDirection,
      );
      if (shadows != null && shadows!.isNotEmpty) {
        child = DecoratedBox(
          decoration: BoxDecoration(
            boxShadow: shadows!
                .map((s) =>
                    BoxShadow(color: s.color, blurRadius: s.blurRadius))
                .toList(),
          ),
          child: child,
        );
      }
      return Center(widthFactor: 1.0, heightFactor: 1.0, child: child);
    } else {
      return Center(
        widthFactor: 1.0,
        heightFactor: 1.0,
        child: Icon(
          icon is IconData ? icon : null,
          size: size,
          color: color,
          shadows: shadows,
          semanticLabel: semanticLabel,
          textDirection: textDirection,
          fill: fill,
          weight: weight,
          grade: grade,
          opticalSize: opticalSize,
          applyTextScaling: applyTextScaling,
        ),
      );
    }
  }
}