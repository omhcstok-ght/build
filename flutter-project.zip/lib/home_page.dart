import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:ui';
import 'package:video_player/video_player.dart';

// ── COLOR SCHEME (matching dashboard) ────────────────────────────────
class _AC {
  static const bg        = Color(0xFF000000);
  static const bg2       = Color(0xFF0a0a0a);
  static const surface   = Color(0xFF111111);
  static const card      = Color(0xFF111111);
  static const accent    = Color(0xFFFF3B30);
  static const accent2   = Color(0xFFFF6B6B);
  static const accent3   = Color(0xFFCC2E25);
  static const gold      = Color(0xFF333333);
  static const success   = Color(0xFFFF3B30);
  static const text      = Color(0xFFE0E7FF);
  static const muted     = Color(0x73E0E7FF);
  static const muted2    = Color(0x38E0E7FF);
  static const border    = Color(0x1AFF3B30);
  static const border2   = Color(0x0FFFFFFF);
}

// ── ATTACK PAGE (Contact Bug Launcher) ──────────────────────────────
class AttackPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  AttackPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<AttackPage> createState() => _AttackPageState();
}

class _AttackPageState extends State<AttackPage> with TickerProviderStateMixin {
  // ── Video Background ──
  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;
  static const _bgVideoUrl = 'assets/videos/bg_bug.mp4';

  final targetController = TextEditingController();
  static const String baseUrl = "https://omhc-host-premium.yakuza.biz.id";

  // ── Animation Controllers ──
  late AnimationController _pulseController;
  late AnimationController _staggerController;
  late AnimationController _btnPress;
  late AnimationController _headerShimmerController;

  // ── State ──
  String selectedBugId = "";
  bool _isSending = false;
  String _senderType = "private";
  int _globalSenderCount = 0;
  int _privateSenderCount = 0;
  bool _isLoadingSenders = false;
  int _activeStep = 0;
  bool _isTargetFocused = false;
  bool _hasNoSender = false;

  // ── Live role & expiredDate ──
  late String _currentRole;
  late String _currentExpired;

  bool get canUseGlobalSender {
    const allowed = ["founder", "vip", "owner", "high admin", "seles", "high owner", "dev"];
    return allowed.contains(_currentRole.toLowerCase());
  }

  @override
  void initState() {
    super.initState();
    _currentRole = widget.role;
    _currentExpired = widget.expiredDate;
    _initBgVideo();
    _pulseController = AnimationController(vsync: this, duration: Duration(seconds: 3))..repeat(reverse: true);
    _staggerController = AnimationController(vsync: this, duration: Duration(milliseconds: 900))..forward();
    _btnPress = AnimationController(vsync: this, duration: Duration(milliseconds: 100), lowerBound: 0.0, upperBound: 1.0);
    _headerShimmerController = AnimationController(vsync: this, duration: Duration(seconds: 3))..repeat();

    if (widget.listBug.isNotEmpty) selectedBugId = widget.listBug[0]['bug_id'];
    if (!canUseGlobalSender) _senderType = "private";
    _fetchSenderCounts();
    _refreshRoleFromServer();
  }

  @override
  void dispose() {
    _bgVideoController.dispose();
    _pulseController.dispose();
    _staggerController.dispose();
    _btnPress.dispose();
    _headerShimmerController.dispose();
    targetController.dispose();
    super.dispose();
  }

  // ── Video Background ──
  void _initBgVideo() {
    _bgVideoController = VideoPlayerController.asset(_bgVideoUrl)
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bgVideoReady = true);
          _bgVideoController.play();
          _bgVideoController.setLooping(true);
          _bgVideoController.setVolume(0.0);
        }
      }).catchError((e) {
        debugPrint('BG video error: $e');
      });
  }

  // ── Refresh role & expiredDate dari server ──
  Future<void> _refreshRoleFromServer() async {
    if (widget.sessionKey.isEmpty) return;
    try {
      final res = await http.get(Uri.parse(
        "$baseUrl/meByKey?key=${Uri.encodeComponent(widget.sessionKey)}",
      )).timeout(Duration(seconds: 8));
      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        final newRole = (data['role'] ?? _currentRole).toString();
        final newExpired = (data['expiredDate'] ?? _currentExpired).toString();
        if (newRole != _currentRole || newExpired != _currentExpired) {
          if (mounted) {
            setState(() {
              _currentRole = newRole;
              _currentExpired = newExpired;
            });
          }
        }
      }
    } catch (_) {}
  }

  // ── Stagger Animation Helper ──
  Animation<double> _anim(int i) {
    final s = (i * 0.07).clamp(0.0, 0.55);
    final e = (s + 0.38).clamp(0.0, 1.0);
    return CurvedAnimation(
      parent: _staggerController,
      curve: Interval(s, e, curve: Curves.easeOut),
    );
  }

  // ── API: fetch sender counts ──
  Future<void> _fetchSenderCounts() async {
    if (!mounted) return;
    setState(() => _isLoadingSenders = true);
    try {
      final res = await http.get(Uri.parse("$baseUrl/mySender?key=${widget.sessionKey}"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['connections'] != null) {
          int onlinePriv = 0;
          int onlineGlob = 0;
          final conns = data['connections'];
          if (conns is List) {
            onlinePriv = conns.where((s) => s is Map && (s['isActive'] ?? true) == true).length;
          } else if (conns is Map) {
            final priv = (conns['private'] as List?) ?? [];
            final glob = (conns['global'] as List?) ?? [];
            onlinePriv = priv.where((s) => s is Map && (s['isActive'] ?? true) == true).length;
            onlineGlob = glob.where((s) => s is Map && (s['isActive'] ?? true) == true).length;
          }
          if (mounted) {
            setState(() {
              _privateSenderCount = onlinePriv;
              _globalSenderCount = onlineGlob;
              _hasNoSender = (onlinePriv == 0 && onlineGlob == 0);
            });
          }
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _isLoadingSenders = false);
  }

  String? formatPhoneNumber(String input) {
    final c = input.replaceAll(RegExp(r'[^\d]'), '');
    if (c.startsWith('0') || c.length < 8) return null;
    return c;
  }

  // ── API: send bug (dipanggil di background, sebelum popup) ──
  Future<Map<String, dynamic>> _sendBugApiCall(String target, String bugId, String senderType) async {
    try {
      final res = await http.get(
        Uri.parse(
          "$baseUrl/sendBug?key=${Uri.encodeComponent(widget.sessionKey)}&target=${Uri.encodeComponent(target)}&bug=${Uri.encodeComponent(bugId)}&senderType=$senderType",
        ),
      ).timeout(Duration(seconds: 35));
      final data = jsonDecode(res.body);
      return {'success': true, 'data': data};
    } catch (e) {
      return {'success': false, 'error': e.toString()};
    }
  }

  // ═══════════════════════════════════════════════════════════════════════
  // LAUNCH — Paralel: API call di background + Popup Processing countdown
  // ═══════════════════════════════════════════════════════════════════════
  Future<void> _launchAttack() async {
    if (_isSending) return;
    _btnPress.forward().then((_) => _btnPress.reverse());

    final raw = targetController.text.trim();
    final target = formatPhoneNumber(raw);

    // ── Validasi ──
    if (target == null || widget.sessionKey.isEmpty) {
      _showAlert("Invalid Number", "Use international format (e.g., +62, 1, 44), not 08xxx.");
      return;
    }

    if (_hasNoSender) {
      _showAlert("No Sender", "Tidak ada sender aktif. Tambahkan sender dulu.");
      return;
    }

    setState(() {
      _isSending = true;
      _activeStep = 1;
    });

    // ══════════════════════════════════════════════════════════════════
    // STEP 1: Fire API call SEGERA (di background, non-blocking)
    // ══════════════════════════════════════════════════════════════════
    final apiFuture = _sendBugApiCall(target, selectedBugId, _senderType);

    // ══════════════════════════════════════════════════════════════════
    // STEP 2: Show popup PROCESSING (countdown + fake log)
    // User gak tahu kalau API udah jalan di background
    // ══════════════════════════════════════════════════════════════════
    if (mounted) {
      _showProcessingDialog(
        target: target,
        bugName: selectedBugId,
        senderType: _senderType,
        apiFuture: apiFuture,
      );
    }
  }

  // ═══════════════════════════════════════════════════════════════════════
  // Show PROCESSING Dialog + auto show SUCCESS/ERROR setelah countdown
  // ═══════════════════════════════════════════════════════════════════════
  void _showProcessingDialog({
    required String target,
    required String bugName,
    required String senderType,
    required Future<Map<String, dynamic>> apiFuture,
  }) {
    showDialog(
      context: context,
      barrierDismissible: false, // user tidak bisa close
      builder: (_) => _ProcessingDialog(
        target: target,
        bugName: bugName,
        senderType: senderType,
        apiFuture: apiFuture,
        onComplete: (result) {
          // Popup processing sudah close
          if (mounted) setState(() {
            _isSending = false;
            _activeStep = result['success'] == true ? 2 : 0;
          });

          // Tunggu sebentar biar transisi smooth, baru show result
          Future.delayed(Duration(milliseconds: 250), () {
            if (!mounted) return;
            if (result['success'] == true) {
              _handleApiResponse(result['data'], target, bugName, senderType);
            } else {
              _showAlert("Error", "Connection error. Please try again.");
            }
          });
        },
      ),
    );
  }

  // ── Process response dari API ──
  void _handleApiResponse(
    Map<String, dynamic> data,
    String target,
    String bugName,
    String senderType,
  ) {
    if (data["quotaExceeded"] == true) {
      _showAlert("VIP Quota Habis", data["message"] ?? "VIP quota habis. Tunggu reset.");
    } else if (data["cooldown"] == true) {
      _showAlert("Cooldown", "Cooldown ${data["wait"] ?? ""} detik. Tunggu sebentar.");
    } else if (data["valid"] == false) {
      _showAlert("Gagal", data["message"] ?? "Akses ditolak atau session key tidak valid.");
    } else if (data["sended"] == false) {
      _showAlert("Gagal", data["message"] ?? "Tidak ada sender yang aktif. Tambahkan sender dulu.");
    } else if (data["sended"] == true) {
      _showSuccessPopup(target, bugName, senderType);
    } else {
      _showAlert("Gagal", "Respons tidak dikenali dari server.");
    }
  }

  // ═══════════════════════════════════════════════════════════════════════
  // Alert (error) — Bottom Sheet style
  // ═══════════════════════════════════════════════════════════════════════
  void _showAlert(String title, String msg) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom + 16),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 20),
          decoration: BoxDecoration(
            color: _AC.card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _AC.border, width: 1),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 24, offset: Offset(0, 12)),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 40, height: 3,
                  decoration: BoxDecoration(
                    color: _AC.accent,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                SizedBox(height: 18),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 42, height: 42,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: _AC.accent.withOpacity(0.12),
                        border: Border.all(color: _AC.accent.withOpacity(0.2)),
                      ),
                      child: Center(child: Icon(FontAwesomeIcons.triangleExclamation, color: _AC.accent, size: 17)),
                    ),
                    SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 2),
                          Text(title, style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 15, fontWeight: FontWeight.w700, color: _AC.text)),
                          SizedBox(height: 4),
                          Container(width: 28, height: 2, decoration: BoxDecoration(color: _AC.accent.withOpacity(0.3), borderRadius: BorderRadius.circular(1))),
                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 16),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: _AC.surface,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(msg, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: _AC.muted, height: 1.6)),
                ),
                SizedBox(height: 20),
                Align(
                  alignment: Alignment.centerRight,
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
                      decoration: BoxDecoration(
                        color: _AC.accent,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [BoxShadow(color: _AC.accent.withOpacity(0.2), blurRadius: 12)],
                      ),
                      child: Text('OK', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 11, fontWeight: FontWeight.w700, color: _AC.text, letterSpacing: 2)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showSuccessPopup(String target, String bugName, String senderType) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _SuccessDialog(
        target: target,
        senderType: senderType,
        bugName: bugName,
        onDismiss: () {
          Navigator.of(context).pop();
          setState(() => _activeStep = 0);
        },
      ),
    );
  }

  Future<void> _pasteTarget() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    if (data?.text != null) targetController.text = data!.text!.replaceAll(RegExp(r'[^\d]'), '');
  }
  
  
  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _AC.bg,
      body: Stack(
        children: [
          // ── VIDEO BACKGROUND bg_bug.mp4 ──
          if (_bgVideoReady && _bgVideoController.value.isInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bgVideoController.value.size.width,
                  height: _bgVideoController.value.size.height,
                  child: VideoPlayer(_bgVideoController),
                ),
              ),
            )
          else
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [_AC.bg, _AC.bg2, _AC.bg],
                ),
              ),
            ),

          // ── Dark overlay ──
          Container(color: Colors.black.withOpacity(0.65)),

          // ── CONTENT ──
          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                Expanded(
                  child: SingleChildScrollView(
                    physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(maxWidth: 520),
                      child: Column(
                        children: [
                          SizedBox(height: 16),
                          _buildHeroBanner(),
                          SizedBox(height: 16),
                          _buildProfileCard(),
                          SizedBox(height: 16),
                          if (_hasNoSender) _buildNoSenderWarning(),
                          if (_hasNoSender) SizedBox(height: 12),
                          _buildTargetCard(),
                          SizedBox(height: 16),
                          _buildBugArsenalCard(),
                          SizedBox(height: 16),
                          _buildDeployCard(),
                          SizedBox(height: 24),
                          _buildLaunchButton(),
                          SizedBox(height: 16),
                          _buildStatusBar(),
                          SizedBox(height: 32),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // HEADER — glassmorphism + shimmer title
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildHeader() {
    return Container(
      height: 62,
      decoration: BoxDecoration(
        color: Color(0xEB0c0d15),
        border: Border(bottom: BorderSide(color: _AC.border)),
      ),
      child: ClipRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Row(
              children: [
                GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    width: 38, height: 38,
                    decoration: BoxDecoration(
                      color: _AC.surface,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _AC.border2),
                    ),
                    child: Icon(Icons.arrow_back, color: _AC.text, size: 16),
                  ),
                ),
                SizedBox(width: 10),
                Container(
                  width: 36, height: 36,
                  decoration: BoxDecoration(
                    color: _AC.accent.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _AC.accent.withOpacity(0.25)),
                  ),
                  child: Center(child: Icon(FontAwesomeIcons.crosshairs, color: _AC.accent, size: 14)),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AnimatedBuilder(
                        animation: _headerShimmerController,
                        builder: (context, child) {
                          final t = _headerShimmerController.value;
                          return ShaderMask(
                            shaderCallback: (bounds) => LinearGradient(
                              begin: Alignment(-1.0 + (t * 2), 0),
                              end: Alignment(0.0 + (t * 2), 0),
                              colors: [
                                _AC.text,
                                _AC.accent2,
                                _AC.text,
                              ],
                              stops: const [0.0, 0.5, 1.0],
                            ).createShader(bounds),
                            blendMode: BlendMode.srcIn,
                            child: const Text(
                              "CONTACT BUG",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                fontFamily: "MADEEvolveSansEVO",
                                letterSpacing: 1.5,
                              ),
                            ),
                          );
                        },
                      ),
                      SizedBox(height: 1),
                      Row(
                        children: [
                          Container(
                            width: 6, height: 6,
                            decoration: BoxDecoration(
                              color: _AC.accent,
                              shape: BoxShape.circle,
                              boxShadow: [BoxShadow(color: _AC.accent, blurRadius: 4)],
                            ),
                          ),
                          SizedBox(width: 5),
                          Text(
                            _isSending ? "INJECTING..." : "READY",
                            style: TextStyle(
                              color: _AC.muted,
                              fontSize: 10,
                              fontFamily: "ShareTechMono",
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                // Sender count badge
                AnimatedBuilder(
                  animation: _headerShimmerController,
                  builder: (context, _) {
                    final p = 0.5 + (math.sin(_headerShimmerController.value * 2 * math.pi) * 0.5).abs();
                    return Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: _AC.accent.withOpacity(0.1 + p * 0.05),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: _AC.accent.withOpacity(0.2 + p * 0.1)),
                        boxShadow: [
                          BoxShadow(color: _AC.accent.withOpacity(0.1 + p * 0.1), blurRadius: 8 + p * 4),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(FontAwesomeIcons.whatsapp, color: _AC.success, size: 12),
                          SizedBox(width: 6),
                          Text(
                            "${_privateSenderCount + _globalSenderCount}",
                            style: TextStyle(
                              color: _AC.text,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // SOLID CARD HELPER
  // ═══════════════════════════════════════════════════════════════════
  Widget _solidCard({required Widget child, int idx = -1}) {
    Widget cardChild = Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.4),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _AC.accent.withOpacity(0.15), width: 1),
      ),
      child: child,
    );

    if (idx >= 0) {
      final a = _anim(idx);
      return FadeTransition(
        opacity: a,
        child: SlideTransition(
          position: Tween(begin: Offset(0, 0.05), end: Offset.zero).animate(a),
          child: cardChild,
        ),
      );
    }
    return cardChild;
  }

  // ═══════════════════════════════════════════════════════════════════
  // HERO BANNER — step tracker
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildHeroBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 22),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.4),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _AC.accent.withOpacity(0.15), width: 1),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AnimatedBuilder(
                animation: _pulseController,
                builder: (ctx, _) {
                  final v = _pulseController.value;
                  return Container(
                    width: 40, height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _AC.accent.withOpacity(0.12 + v * 0.04),
                      border: Border.all(color: _AC.accent.withOpacity(0.3), width: 1.5),
                      boxShadow: [
                        BoxShadow(color: _AC.accent.withOpacity(0.15 + v * 0.1), blurRadius: 12 + v * 6),
                      ],
                    ),
                    child: Center(child: Icon(FontAwesomeIcons.crosshairs, color: _AC.accent, size: 16)),
                  );
                },
              ),
              SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('CONTACT INTRUSION', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 2.5, color: _AC.text)),
                  SizedBox(height: 4),
                  Container(width: 36, height: 2, decoration: BoxDecoration(color: _AC.accent.withOpacity(0.4), borderRadius: BorderRadius.circular(1))),
                ],
              ),
            ],
          ),
          SizedBox(height: 22),
          Row(
            children: [
              _buildHeroStep(0, FontAwesomeIcons.keyboard, 'INPUT', 'Enter target'),
              _buildHeroStepConnector(0),
              _buildHeroStep(1, FontAwesomeIcons.droplet, 'INJECT', 'Deploy bug'),
              _buildHeroStepConnector(1),
              _buildHeroStep(2, FontAwesomeIcons.circleCheck, 'DONE', 'Compromised'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHeroStep(int step, IconData icon, String title, String desc) {
    final isActive = _activeStep == step;
    final isDone = _activeStep > step;
    final color = isDone ? _AC.success : isActive ? _AC.accent : _AC.muted2;

    return Expanded(
      child: Column(
        children: [
          AnimatedBuilder(
            animation: _pulseController,
            builder: (ctx, _) {
              final p = _pulseController.value;
              return Container(
                width: 48, height: 48,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withOpacity(isActive ? 0.12 + p * 0.06 : 0.06),
                  border: Border.all(color: color.withOpacity(isActive ? 0.4 + p * 0.15 : 0.15), width: isActive ? 2.0 : 1.0),
                  boxShadow: isActive
                      ? [BoxShadow(color: color.withOpacity(0.1 + p * 0.08), blurRadius: 12)]
                      : null,
                ),
                child: Center(
                  child: isDone ? Icon(Icons.check, color: _AC.success, size: 22) : Icon(icon, color: color, size: 18),
                ),
              );
            },
          ),
          SizedBox(height: 10),
          Text(title, style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.5, color: color)),
          SizedBox(height: 4),
          Text(desc, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 8, color: _AC.muted2), textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }

  Widget _buildHeroStepConnector(int step) {
    final isDone = _activeStep > step;
    return Padding(
      padding: const EdgeInsets.only(top: 22),
      child: AnimatedContainer(
        duration: Duration(milliseconds: 400),
        curve: Curves.easeOutCubic,
        width: 28, height: 2.5,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(2),
          color: isDone ? _AC.success.withOpacity(0.4) : _AC.border2,
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // NO SENDER WARNING
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildNoSenderWarning() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (ctx, _) {
        final p = _pulseController.value;
        return Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            color: Color(0xFFFF3B30).withOpacity(0.08 + p * 0.03),
            border: Border.all(color: Color(0xFFFF3B30).withOpacity(0.25 + p * 0.1), width: 1),
          ),
          child: Row(
            children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Color(0xFFFF3B30).withOpacity(0.12),
                  border: Border.all(color: Color(0xFFFF3B30).withOpacity(0.2)),
                ),
                child: Center(child: Icon(FontAwesomeIcons.triangleExclamation, color: Color(0xFFFF3B30), size: 16)),
              ),
              SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('NO SENDER DETECTED', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 11, fontWeight: FontWeight.w700, color: Color(0xFFFF3B30), letterSpacing: 1.5)),
                    SizedBox(height: 4),
                    Text('Add a sender first from the Sender Manager before attacking.', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: _AC.muted, height: 1.4)),
                  ],
                ),
              ),
              GestureDetector(
                onTap: _isLoadingSenders ? null : _fetchSenderCounts,
                child: Container(
                  width: 36, height: 36,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: _AC.surface,
                    border: Border.all(color: _AC.border2),
                  ),
                  child: Center(
                    child: _isLoadingSenders
                        ? SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFFFF3B30).withOpacity(0.6)))
                        : Icon(FontAwesomeIcons.rotate, color: _AC.muted2, size: 13),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // PROFILE CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildProfileCard() {
    return _solidCard(
      idx: 0,
      child: Row(
        children: [
          Container(
            width: 54, height: 54,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              color: _AC.accent.withOpacity(0.1),
              border: Border.all(color: _AC.accent.withOpacity(0.25)),
            ),
            child: Center(
              child: Icon(
                _currentRole.toLowerCase() == "vip" ? FontAwesomeIcons.hatWizard : FontAwesomeIcons.mask,
                color: _AC.accent, size: 22,
              ),
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Operator', style: TextStyle(fontSize: 10, color: _AC.muted, letterSpacing: 1.8)),
                SizedBox(height: 3),
                Text(widget.username, style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 16, fontWeight: FontWeight.w700, letterSpacing: 1, color: _AC.text), maxLines: 1, overflow: TextOverflow.ellipsis),
                SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: _AC.accent.withOpacity(0.1),
                    border: Border.all(color: _AC.accent.withOpacity(0.2)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(FontAwesomeIcons.circleCheck, color: _AC.accent, size: 9),
                      SizedBox(width: 6),
                      Text(_currentRole.toUpperCase(), style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 2, color: _AC.accent)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: _AC.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _AC.border2),
            ),
            child: Column(
              children: [
                Icon(FontAwesomeIcons.calendarDays, color: _AC.gold, size: 14),
                SizedBox(height: 4),
                Text(_currentExpired, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, color: _AC.gold)),
                SizedBox(height: 2),
                Text('EXPIRY', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 8, color: _AC.muted2, letterSpacing: 1.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // TARGET CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildTargetCard() {
    return _solidCard(
      idx: 1,
      child: Column(
        children: [
          _buildSectionHeader(FontAwesomeIcons.crosshairs, 'TARGET'),
          SizedBox(height: 16),
          AnimatedContainer(
            duration: Duration(milliseconds: 250),
            curve: Curves.easeOutCubic,
            decoration: BoxDecoration(
              color: _AC.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: _isTargetFocused ? _AC.accent : _AC.border,
                width: _isTargetFocused ? 1.5 : 1.0,
              ),
              boxShadow: _isTargetFocused
                  ? [BoxShadow(color: _AC.accent.withOpacity(0.15), blurRadius: 12)]
                  : null,
            ),
            child: Focus(
              onFocusChange: (f) => setState(() => _isTargetFocused = f),
              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 16, 0, 16),
                    child: Container(
                      width: 40, height: 40,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: _AC.accent.withOpacity(_isTargetFocused ? 0.12 : 0.06),
                        border: Border.all(color: _AC.accent.withOpacity(0.15)),
                      ),
                      child: Center(child: Icon(FontAwesomeIcons.globe, color: _AC.accent, size: 17)),
                    ),
                  ),
                  Expanded(
                    child: TextField(
                      controller: targetController,
                      keyboardType: TextInputType.phone,
                      style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 16, color: _AC.text, letterSpacing: 0.5),
                      cursorColor: _AC.accent,
                      cursorWidth: 2,
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: '6283848446158',
                        hintStyle: TextStyle(fontFamily: 'ShareTechMono', fontSize: 14, color: _AC.muted2),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                      ),
                      onSubmitted: (_) => _launchAttack(),
                    ),
                  ),
                  GestureDetector(
                    onTap: _pasteTarget,
                    child: Container(
                      margin: const EdgeInsets.all(12),
                      width: 38, height: 38,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: _AC.surface,
                        border: Border.all(color: _AC.border2),
                      ),
                      child: Center(child: Icon(FontAwesomeIcons.paste, color: _AC.muted2, size: 14)),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(children: [
                  Icon(FontAwesomeIcons.circleInfo, color: _AC.muted2, size: 10),
                  SizedBox(width: 6),
                  Text('International format without +', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: _AC.muted2)),
                ]),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _AC.surface,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _AC.border),
                  ),
                  child: Text('62xxx', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _AC.accent)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUG ARSENAL CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildBugArsenalCard() {
    return _solidCard(
      idx: 2,
      child: Column(
        children: [
          _buildSectionHeader(FontAwesomeIcons.spider, 'YAKUZA MODE', tag: '${widget.listBug.length}'),
          SizedBox(height: 14),
          SizedBox(
            height: 158,
            child: widget.listBug.isEmpty
                ? Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: _AC.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _AC.border2),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(FontAwesomeIcons.spider, color: _AC.muted2, size: 28),
                        SizedBox(height: 10),
                        Text('No bugs available', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: _AC.muted2)),
                      ],
                    ),
                  )
                : ListView.builder(
                    scrollDirection: Axis.horizontal,
                    physics: BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    itemCount: widget.listBug.length,
                    itemBuilder: (ctx, i) {
                      final bug = widget.listBug[i];
                      final sel = selectedBugId == bug['bug_id'];
                      return GestureDetector(
                        onTap: () => setState(() => selectedBugId = bug['bug_id']),
                        child: AnimatedContainer(
                          duration: Duration(milliseconds: 250),
                          curve: Curves.easeOutCubic,
                          width: 164,
                          margin: const EdgeInsets.only(right: 14),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(16),
                            color: sel ? _AC.accent.withOpacity(0.08) : _AC.surface,
                            border: Border.all(color: sel ? _AC.accent : _AC.border, width: sel ? 1.5 : 1.0),
                            boxShadow: sel
                                ? [BoxShadow(color: _AC.accent.withOpacity(0.2), blurRadius: 16)]
                                : null,
                          ),
                          child: Stack(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(18),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      width: 44, height: 44,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(14),
                                        color: sel ? _AC.accent.withOpacity(0.15) : _AC.accent.withOpacity(0.06),
                                        border: Border.all(color: sel ? _AC.accent.withOpacity(0.25) : _AC.accent.withOpacity(0.1)),
                                      ),
                                      child: Center(child: Icon(FontAwesomeIcons.skull, color: _AC.accent, size: 20)),
                                    ),
                                    Spacer(),
                                    Text(
                                      (bug['bug_name'] ?? '').toString().toUpperCase(),
                                      style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 11, fontWeight: FontWeight.w700, color: _AC.text, letterSpacing: 0.5),
                                      maxLines: 1, overflow: TextOverflow.ellipsis,
                                    ),
                                    SizedBox(height: 5),
                                    Row(children: [
                                      Container(width: 5, height: 5, decoration: BoxDecoration(shape: BoxShape.circle, color: sel ? _AC.accent : _AC.muted2)),
                                      SizedBox(width: 5),
                                      Text('READY', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, fontWeight: FontWeight.w700, color: sel ? _AC.accent : _AC.muted2)),
                                    ]),
                                  ],
                                ),
                              ),
                              if (sel)
                                Positioned(
                                  top: 14, right: 14,
                                  child: Container(
                                    width: 24, height: 24,
                                    decoration: BoxDecoration(color: _AC.accent, shape: BoxShape.circle),
                                    child: Icon(Icons.check, color: _AC.text, size: 12),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
          SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              widget.listBug.isEmpty ? 1 : (widget.listBug.length > 5 ? 5 : widget.listBug.length),
              (index) {
                final si = widget.listBug.indexWhere((b) => b['bug_id'] == selectedBugId);
                final active = si == index || (si > 4 && index == 4);
                return AnimatedContainer(
                  duration: Duration(milliseconds: 300),
                  curve: Curves.easeOutCubic,
                  margin: const EdgeInsets.symmetric(horizontal: 2.5),
                  height: 4, width: active ? 24 : 7,
                  decoration: BoxDecoration(
                    color: active ? _AC.accent : _AC.border2,
                    borderRadius: BorderRadius.circular(4),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // DEPLOY CARD (Private / Global)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildDeployCard() {
    return _solidCard(
      idx: 3,
      child: Column(
        children: [
          Row(children: [
            _buildSecIco(FontAwesomeIcons.server),
            SizedBox(width: 12),
            Text('DEPLOY', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 3, color: _AC.text)),
            Spacer(),
            GestureDetector(
              onTap: _isLoadingSenders ? null : _fetchSenderCounts,
              child: Container(
                width: 36, height: 36,
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: _AC.surface, border: Border.all(color: _AC.border2)),
                child: Center(
                  child: _isLoadingSenders
                      ? SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: _AC.accent.withOpacity(0.6)))
                      : Icon(FontAwesomeIcons.rotate, color: _AC.muted2, size: 14),
                ),
              ),
            ),
          ]),
          SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: _buildDeployOpt(icon: FontAwesomeIcons.userShield, title: 'PRIVATE', subtitle: 'Your Session', type: 'private', selColor: _AC.accent)),
              SizedBox(width: 12),
              Expanded(child: _buildDeployOpt(icon: FontAwesomeIcons.globe, title: 'GLOBAL', subtitle: '$_globalSenderCount Active', type: 'global', selColor: _AC.success)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDeployOpt({required IconData icon, required String title, required String subtitle, required String type, required Color selColor}) {
    final sel = _senderType == type;
    final disabled = type == 'global' && !canUseGlobalSender;

    return GestureDetector(
      onTap: () {
        if (disabled) {
          _showAlert("Access Denied", "Global sender is only available for: Founder, VIP, Owner, High Owner, High Admin, Seles, Dev");
          return;
        }
        setState(() => _senderType = type);
      },
      child: AnimatedContainer(
        duration: Duration(milliseconds: 250),
        curve: Curves.easeOutCubic,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: sel ? selColor.withOpacity(0.08) : _AC.surface,
          border: Border.all(color: sel ? selColor : _AC.border, width: sel ? 1.5 : 1.0),
          boxShadow: sel
              ? [BoxShadow(color: selColor.withOpacity(0.15), blurRadius: 12)]
              : null,
        ),
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 14),
        child: Column(
          children: [
            Container(
              width: 48, height: 48,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: sel ? selColor.withOpacity(0.12) : _AC.card,
                border: Border.all(color: sel ? selColor.withOpacity(0.2) : _AC.border2),
              ),
              child: Center(child: Icon(icon, color: disabled ? Color(0xFFCC2E25).withOpacity(0.3) : sel ? selColor : _AC.muted, size: 22)),
            ),
            SizedBox(height: 12),
            Text(title, style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 2, color: disabled ? Color(0xFFCC2E25).withOpacity(0.4) : sel ? _AC.text : _AC.muted)),
            SizedBox(height: 5),
            Text(subtitle, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _AC.muted)),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // LAUNCH BUTTON — dengan shimmer + pulse
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildLaunchButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (ctx, child) {
        final pulse = _pulseController.value;
        return Container(
          width: double.infinity,
          height: 62,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(color: _AC.accent.withOpacity(0.18 + pulse * 0.08), blurRadius: 24),
            ],
          ),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: LinearGradient(colors: [_AC.accent, Color(0xFF991133)], begin: Alignment(-0.7, -0.4), end: Alignment(0.7, 0.4)),
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: _isSending ? null : _launchAttack,
                splashColor: Colors.white.withOpacity(0.08),
                highlightColor: Colors.white.withOpacity(0.04),
                child: Center(
                  child: _isSending
                      ? Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white.withOpacity(0.4))),
                          SizedBox(width: 16),
                          Text('INJECTING', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 15, fontWeight: FontWeight.w700, letterSpacing: 5, color: _AC.text)),
                        ])
                      : Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(_senderType == 'global' ? FontAwesomeIcons.rocket : FontAwesomeIcons.skull, color: _AC.text, size: 18),
                          SizedBox(width: 14),
                          Text(_senderType == 'global' ? 'GLOBAL STRIKE' : 'LAUNCH', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 15, fontWeight: FontWeight.w700, letterSpacing: 5, color: _AC.text)),
                          SizedBox(width: 14),
                          Container(padding: const EdgeInsets.all(5), decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.1)), child: Icon(Icons.arrow_forward, color: _AC.text, size: 14)),
                        ]),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // STATUS BAR
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildStatusBar() {
    return Row(
      children: [
        Expanded(
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
            decoration: BoxDecoration(
              color: _AC.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _AC.border2),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(width: 6, height: 6, decoration: BoxDecoration(shape: BoxShape.circle, color: _AC.success, boxShadow: [BoxShadow(color: _AC.success, blurRadius: 4)])),
                SizedBox(width: 8),
                Text('SYSTEM ONLINE', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, color: _AC.success, letterSpacing: 1.5)),
              ],
            ),
          ),
        ),
        SizedBox(width: 10),
        Expanded(
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
            decoration: BoxDecoration(
              color: _AC.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _AC.border2),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(FontAwesomeIcons.spider, color: _AC.accent, size: 10),
                SizedBox(width: 8),
                Text('${widget.listBug.length} BUGS', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, color: _AC.accent, letterSpacing: 1.5)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ── Shared Section Header + Icon Helper ──
  Widget _buildSectionHeader(IconData icon, String title, {String? tag}) {
    return Row(
      children: [
        _buildSecIco(icon),
        SizedBox(width: 14),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 3, color: _AC.text)),
          SizedBox(height: 4),
          Container(width: 30, height: 2, decoration: BoxDecoration(color: _AC.accent.withOpacity(0.4), borderRadius: BorderRadius.circular(1))),
        ]),
        if (tag != null) ...[
          Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              color: _AC.accent.withOpacity(0.1),
              border: Border.all(color: _AC.accent.withOpacity(0.2)),
            ),
            child: Text(tag, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, color: _AC.accent, letterSpacing: 1)),
          ),
        ],
      ],
    );
  }

  Widget _buildSecIco(IconData icon) {
    return Container(
      width: 42, height: 42,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(13),
        color: _AC.accent.withOpacity(0.1),
        border: Border.all(color: _AC.accent.withOpacity(0.18)),
      ),
      child: Center(child: Icon(icon, color: _AC.accent, size: 17)),
    );
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// PROCESSING DIALOG — Countdown 5 detik + Fake Log + Spinner
// Muncul saat user klik LAUNCH / GLOBAL STRIKE
// Popup ini di-lock (barrierDismissible: false) — user gak bisa close
// ═══════════════════════════════════════════════════════════════════════════
class _ProcessingDialog extends StatefulWidget {
  final String target;
  final String bugName;
  final String senderType;
  final Future<Map<String, dynamic>> apiFuture;
  final Function(Map<String, dynamic>) onComplete;

  const _ProcessingDialog({
    required this.target,
    required this.bugName,
    required this.senderType,
    required this.apiFuture,
    required this.onComplete,
  });

  @override
  State<_ProcessingDialog> createState() => _ProcessingDialogState();
}

class _ProcessingDialogState extends State<_ProcessingDialog>
    with TickerProviderStateMixin {
  late AnimationController _scaleController;
  late AnimationController _spinnerController;
  late AnimationController _glowController;
  late AnimationController _ringController;

  // ── Countdown state ──
  int _countdown = 5;
  Timer? _countdownTimer;
  bool _apiDone = false;
  bool _apiSuccess = false;
  Map<String, dynamic>? _apiResult;
  String _currentLog = "";
  int _logIndex = 0;

  // ── Fake techy log (English hacker style) ──
  final List<String> _fakeLogs = [
    "[System] Initializing socket connection...",
    "[System] Injecting payload...",
    "[System] Verifying handshake...",
    "[System] Routing through proxy node...",
    "[System] Deploying attack sequence...",
    "[System] Awaiting server response...",
    "[System] Encrypting packets...",
    "[System] Connection secured.",
  ];

  @override
  void initState() {
    super.initState();

    _scaleController = AnimationController(
      duration: Duration(milliseconds: 500),
      vsync: this,
    )..forward();

    _spinnerController = AnimationController(
      duration: Duration(seconds: 1),
      vsync: this,
    )..repeat();

    _glowController = AnimationController(
      duration: Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);

    _ringController = AnimationController(
      duration: Duration(seconds: 4),
      vsync: this,
    )..repeat();

    _currentLog = _fakeLogs[0];

    // ── Start countdown ──
    _startCountdown();

    // ── Listen API response (background) ──
    widget.apiFuture.then((result) {
      if (!mounted) return;
      _apiDone = true;
      _apiSuccess = result['success'] == true;
      _apiResult = result['data'] ?? result;
      _tryComplete();
    });
  }

  void _startCountdown() {
    _countdownTimer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      setState(() {
        if (_countdown > 0) {
          _countdown--;
          // Update fake log tiap detik (loop)
          _logIndex = (_logIndex + 1) % _fakeLogs.length;
          _currentLog = _fakeLogs[_logIndex];
        }
      });

      // ── Kalau countdown sudah 0 dan API sudah selesai → complete ──
      if (_countdown <= 0) {
        _tryComplete();
      }
    });
  }

  // ── Complete dialog (close + pass result ke parent) ──
  bool _isCompleting = false;
  void _tryComplete() {
    if (_isCompleting) return;
    if (_countdown > 0) return;  // countdown belum selesai
    if (!_apiDone) return;        // API belum selesai

    _isCompleting = true;
    _countdownTimer?.cancel();

    // Kalau API gagal → tetap complete dengan status failed
    final result = {
      'success': _apiSuccess,
      'data': _apiResult ?? {},
    };

    // Delay kecil biar animasi fade terlihat smooth
    Future.delayed(Duration(milliseconds: 400), () {
      if (!mounted) return;
      Navigator.of(context).pop();
      widget.onComplete(result);
    });
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    _scaleController.dispose();
    _spinnerController.dispose();
    _glowController.dispose();
    _ringController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final progress = (5 - _countdown) / 5.0; // 0.0 → 1.0

    return PopScope(
      canPop: false, // cegah back button nutup popup
      child: Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: EdgeInsets.zero,
        child: ScaleTransition(
          scale: CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
          child: Container(
            width: MediaQuery.of(context).size.width * 0.88,
            constraints: BoxConstraints(maxWidth: 400),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF1a1a1a), Color(0xFF0a0a0a)],
              ),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: _AC.accent.withOpacity(0.4), width: 1.5),
              boxShadow: [
                BoxShadow(color: _AC.accent.withOpacity(0.25), blurRadius: 40),
                BoxShadow(color: Colors.black.withOpacity(0.6), blurRadius: 30),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 32, 24, 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // ══════════════════════════════════════════════════
                  // SPINNER + ROTATING RING + GLOW
                  // ══════════════════════════════════════════════════
                  AnimatedBuilder(
                    animation: _glowController,
                    builder: (context, _) {
                      final glow = _glowController.value;
                      return SizedBox(
                        width: 120,
                        height: 120,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            // Outer rotating ring (dashed)
                            AnimatedBuilder(
                              animation: _ringController,
                              builder: (context, _) => Transform.rotate(
                                angle: _ringController.value * 2 * math.pi,
                                child: CustomPaint(
                                  size: Size(120, 120),
                                  painter: _DashedRingPainter(
                                    color: _AC.accent.withOpacity(0.35),
                                    dashCount: 24,
                                    ringRadius: 55,
                                    strokeWidth: 1.5,
                                  ),
                                ),
                              ),
                            ),

                            // Glow circle
                            Container(
                              width: 90, height: 90,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: _AC.accent.withOpacity(0.08 + glow * 0.06),
                                border: Border.all(
                                  color: _AC.accent.withOpacity(0.25 + glow * 0.2),
                                  width: 2,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: _AC.accent.withOpacity(0.2 + glow * 0.2),
                                    blurRadius: 20 + glow * 15,
                                    spreadRadius: 1,
                                  ),
                                ],
                              ),
                            ),

                            // Inner spinner (rotating arc)
                            SizedBox(
                              width: 60, height: 60,
                              child: CircularProgressIndicator(
                                strokeWidth: 3,
                                valueColor: AlwaysStoppedAnimation(_AC.accent),
                                backgroundColor: _AC.accent.withOpacity(0.1),
                              ),
                            ),

                            // Countdown number di tengah
                            AnimatedSwitcher(
                              duration: Duration(milliseconds: 400),
                              transitionBuilder: (child, anim) => ScaleTransition(
                                scale: Tween<double>(begin: 0.5, end: 1.0).animate(
                                  CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
                                ),
                                child: FadeTransition(opacity: anim, child: child),
                              ),
                              child: Text(
                                _countdown > 0 ? '$_countdown' : '0',
                                key: ValueKey('count-$_countdown'),
                                style: TextStyle(
                                  fontFamily: 'MADEEvolveSansEVO',
                                  fontSize: 32,
                                  fontWeight: FontWeight.w900,
                                  color: _AC.text,
                                  height: 1,
                                  shadows: [
                                    Shadow(color: _AC.accent, blurRadius: 12),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),

                  SizedBox(height: 24),

                  // ══════════════════════════════════════════════════
                  // TITLE
                  // ══════════════════════════════════════════════════
                  ShaderMask(
                    shaderCallback: (bounds) => LinearGradient(
                      colors: [_AC.accent, _AC.accent2, _AC.accent],
                    ).createShader(bounds),
                    blendMode: BlendMode.srcIn,
                    child: Text(
                      'PROCESSING',
                      style: TextStyle(
                        fontFamily: 'MADEEvolveSansEVO',
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 4,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  SizedBox(height: 6),
                  Text(
                    _countdown > 0 ? 'Verifying payload...' : 'Awaiting response...',
                    style: TextStyle(
                      fontFamily: 'ShareTechMono',
                      fontSize: 11,
                      color: _AC.muted,
                      letterSpacing: 1,
                    ),
                  ),

                  SizedBox(height: 20),

                  // ══════════════════════════════════════════════════
                  // PROGRESS BAR
                  // ══════════════════════════════════════════════════
                  Container(
                    height: 6,
                    decoration: BoxDecoration(
                      color: _AC.surface,
                      borderRadius: BorderRadius.circular(3),
                      border: Border.all(color: _AC.border2),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(3),
                      child: AnimatedContainer(
                        duration: Duration(milliseconds: 900),
                        curve: Curves.easeInOut,
                        alignment: Alignment.centerLeft,
                        width: double.infinity,
                        child: FractionallySizedBox(
                          widthFactor: progress,
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [_AC.accent, _AC.accent2],
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: _AC.accent.withOpacity(0.5),
                                  blurRadius: 8,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),

                  SizedBox(height: 20),

                  // ══════════════════════════════════════════════════
                  // INFO: Target + Bug + Mode
                  // ══════════════════════════════════════════════════
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: _AC.surface.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _AC.border2),
                    ),
                    child: Column(
                      children: [
                        _infoRow('Target', widget.target),
                        SizedBox(height: 6),
                        _infoRow('Bug', widget.bugName.toUpperCase()),
                        SizedBox(height: 6),
                        _infoRow('Mode', widget.senderType.toUpperCase()),
                      ],
                    ),
                  ),

                  SizedBox(height: 16),

                  // ══════════════════════════════════════════════════
                  // FAKE LOG (techy English)
                  // ══════════════════════════════════════════════════
                  Container(
                    width: double.infinity,
                    height: 60,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _AC.accent.withOpacity(0.15)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 5, height: 5,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: _AC.accent,
                                boxShadow: [
                                  BoxShadow(color: _AC.accent, blurRadius: 4),
                                ],
                              ),
                            ),
                            SizedBox(width: 6),
                            Text(
                              'LIVE FEED',
                              style: TextStyle(
                                fontFamily: 'ShareTechMono',
                                fontSize: 8,
                                color: _AC.muted2,
                                letterSpacing: 1.5,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 6),
                        AnimatedSwitcher(
                          duration: Duration(milliseconds: 400),
                          transitionBuilder: (child, anim) => FadeTransition(
                            opacity: anim,
                            child: SlideTransition(
                              position: Tween<Offset>(
                                begin: Offset(0, 0.3),
                                end: Offset.zero,
                              ).animate(anim),
                              child: child,
                            ),
                          ),
                          child: Text(
                            _countdown > 0 ? _currentLog : '[System] Finalizing injection...',
                            key: ValueKey('log-$_logIndex-$_countdown'),
                            style: TextStyle(
                              fontFamily: 'ShareTechMono',
                              fontSize: 10.5,
                              color: _AC.accent2,
                              height: 1.4,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(height: 20),

                  // ══════════════════════════════════════════════════
                  // FOOTER: WARNING + SPINNER
                  // ══════════════════════════════════════════════════
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: 12, height: 12,
                        child: CircularProgressIndicator(
                          strokeWidth: 1.5,
                          valueColor: AlwaysStoppedAnimation(
                            _AC.accent.withOpacity(0.5),
                          ),
                        ),
                      ),
                      SizedBox(width: 8),
                      Text(
                        'Please wait, do not close the app',
                        style: TextStyle(
                          fontFamily: 'ShareTechMono',
                          fontSize: 9,
                          color: _AC.muted2,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Row(
      children: [
        SizedBox(
          width: 60,
          child: Text(
            '[$label]',
            style: TextStyle(
              fontFamily: 'ShareTechMono',
              fontSize: 10,
              color: _AC.muted2,
            ),
          ),
        ),
        SizedBox(width: 6),
        Expanded(
          child: Text(
            value,
            style: TextStyle(
              fontFamily: 'ShareTechMono',
              fontSize: 11,
              color: _AC.text,
              fontWeight: FontWeight.w600,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// DASHED RING PAINTER — untuk rotating ring di sekitar spinner
// ═══════════════════════════════════════════════════════════════════════════
class _DashedRingPainter extends CustomPainter {
  final Color color;
  final int dashCount;
  final double ringRadius;
  final double strokeWidth;

  _DashedRingPainter({
    required this.color,
    required this.dashCount,
    required this.ringRadius,
    required this.strokeWidth,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final paint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final angleStep = (2 * math.pi) / dashCount;
    final dashLength = angleStep * 0.45;

    for (int i = 0; i < dashCount; i++) {
      final startAngle = i * angleStep;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: ringRadius),
        startAngle,
        dashLength,
        false,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_DashedRingPainter oldDelegate) {
    return oldDelegate.color != color ||
        oldDelegate.ringRadius != ringRadius ||
        oldDelegate.dashCount != dashCount;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SUCCESS DIALOG — Muncul setelah countdown + API selesai
// ═══════════════════════════════════════════════════════════════════════════
class _SuccessDialog extends StatefulWidget {
  final String target;
  final String senderType;
  final String bugName;
  final VoidCallback onDismiss;

  const _SuccessDialog({
    required this.target,
    required this.senderType,
    required this.bugName,
    required this.onDismiss,
  });

  @override
  State<_SuccessDialog> createState() => _SuccessDialogState();
}

class _SuccessDialogState extends State<_SuccessDialog>
    with TickerProviderStateMixin {
  late AnimationController _scaleController;
  late AnimationController _infoController;
  late AnimationController _glowController;
  late AnimationController _ringController;

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(vsync: this, duration: Duration(milliseconds: 500));
    _infoController = AnimationController(vsync: this, duration: Duration(milliseconds: 500));
    _glowController = AnimationController(vsync: this, duration: Duration(seconds: 2))..repeat(reverse: true);
    _ringController = AnimationController(vsync: this, duration: Duration(seconds: 6))..repeat();

    _scaleController.forward();
    Future.delayed(Duration(milliseconds: 400), () {
      if (mounted) _infoController.forward();
    });
  }

  @override
  void dispose() {
    _scaleController.dispose();
    _infoController.dispose();
    _glowController.dispose();
    _ringController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width * 0.88;

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: EdgeInsets.zero,
      child: ScaleTransition(
        scale: CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
        child: Container(
          width: w,
          constraints: BoxConstraints(maxWidth: 380),
          decoration: BoxDecoration(
            color: _AC.card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _AC.border, width: 1),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 36, offset: Offset(0, 14)),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(28, 30, 28, 28),
            child: FadeTransition(
              opacity: CurvedAnimation(parent: _infoController, curve: Curves.easeOut),
              child: ScaleTransition(
                scale: CurvedAnimation(parent: _infoController, curve: Curves.easeOut),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // ── Icon circle with glow + ring ──
                    SizedBox(
                      width: 100,
                      height: 100,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          // Rotating ring
                          AnimatedBuilder(
                            animation: _ringController,
                            builder: (ctx, _) => Transform.rotate(
                              angle: _ringController.value * 2 * math.pi,
                              child: CustomPaint(
                                size: Size(100, 100),
                                painter: _DashedRingPainter(
                                  color: (widget.senderType == 'global' ? _AC.success : _AC.accent).withOpacity(0.4),
                                  dashCount: 20,
                                  ringRadius: 46,
                                  strokeWidth: 1.5,
                                ),
                              ),
                            ),
                          ),
                          // Main circle
                          AnimatedBuilder(
                            animation: _glowController,
                            builder: (ctx, _) {
                              final glow = _glowController.value;
                              return Container(
                                width: 80, height: 80,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: widget.senderType == 'global'
                                        ? [_AC.success, Color(0xFF1A9E4A)]
                                        : [_AC.accent, Color(0xFF991133)],
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: (widget.senderType == 'global' ? _AC.success : _AC.accent)
                                          .withOpacity(0.4 + glow * 0.3),
                                      blurRadius: 20 + glow * 15,
                                    ),
                                  ],
                                ),
                                child: Center(
                                  child: Icon(
                                    widget.senderType == 'global' ? FontAwesomeIcons.rocket : FontAwesomeIcons.dragon,
                                    color: _AC.text,
                                    size: 32,
                                  ),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),

                    SizedBox(height: 22),

                    // ── Title ──
                    Text(
                      widget.senderType == 'global' ? 'GLOBAL STRIKE!' : 'ATTACK SUCCESS',
                      style: TextStyle(
                        fontFamily: 'MADEEvolveSansEVO',
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 3,
                        color: _AC.text,
                      ),
                    ),
                    SizedBox(height: 6),
                    Container(
                      width: 40, height: 2,
                      decoration: BoxDecoration(
                        color: _AC.accent.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(1),
                      ),
                    ),

                    SizedBox(height: 18),

                    // ── Info card ──
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: _AC.surface,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: _AC.border2),
                      ),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(FontAwesomeIcons.mobileScreen, color: _AC.muted, size: 16),
                              SizedBox(width: 10),
                              Text(
                                widget.target,
                                style: TextStyle(
                                  fontFamily: 'ShareTechMono',
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                  color: _AC.text,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 12),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  color: _AC.accent.withOpacity(0.1),
                                  border: Border.all(color: _AC.accent.withOpacity(0.2)),
                                ),
                                child: Text(
                                  'BUG: ${widget.bugName.toUpperCase()}',
                                  style: TextStyle(
                                    fontFamily: 'ShareTechMono',
                                    fontSize: 10,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 1.5,
                                    color: _AC.accent,
                                  ),
                                ),
                              ),
                              SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  color: (widget.senderType == 'global' ? _AC.success : _AC.accent)
                                      .withOpacity(0.1),
                                  border: Border.all(
                                    color: (widget.senderType == 'global' ? _AC.success : _AC.accent)
                                        .withOpacity(0.2),
                                  ),
                                ),
                                child: Text(
                                  widget.senderType.toUpperCase(),
                                  style: TextStyle(
                                    fontFamily: 'ShareTechMono',
                                    fontSize: 10,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 2,
                                    color: widget.senderType == 'global' ? _AC.success : _AC.accent,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    SizedBox(height: 24),

                    // ── Close button ──
                    GestureDetector(
                      onTap: widget.onDismiss,
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          color: _AC.text,
                          borderRadius: BorderRadius.circular(14),
                          boxShadow: [
                            BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 14),
                          ],
                        ),
                        child: Center(
                          child: Text(
                            'CLOSE',
                            style: TextStyle(
                              fontFamily: 'MADEEvolveSansEVO',
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 2.5,
                              color: _AC.bg,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}