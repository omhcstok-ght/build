import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// xvideos_page.dart — XVideos Search, Download & Watch
// REWRITTEN: Video player fetches API data, quality selector, loadHtmlString with baseUrl for Referer
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shimmer/shimmer.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

class _VC {
  static const bg = Color(0xFF0a0a14);
  static const bg2 = Color(0xFF0e0d1a);
  static const surface = Color(0xFF141222);
  static const card = Color(0xFF18162a);
  static const accent = Color(0xFF6366F1);
  static const accent2 = Color(0xFF4F46E5);
  static const accent3 = Color(0xFF818CF8);
  static const gold = Color(0xFFC4B5FD);
  static const success = Color(0xFF00E676);
  static const danger = Color(0xFFFF4D6D);
  static const text = Color(0xFFE0E7FF);
  static const muted = Color(0x73E0E7FF);
  static const muted2 = Color(0x38E0E7FF);
  static const border = Color(0x1A6366F1);
  static const border2 = Color(0x0FFFFFFF);
}

class _XvideosApi {
  static const String _baseUrl = 'https://api.deline.web.id';

  static Future<Map<String, dynamic>?> search(String query) async {
    try {
      final uri = Uri.parse('$_baseUrl/search/xvideos').replace(queryParameters: {'q': query});
      final res = await http.get(uri).timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) { final data = jsonDecode(res.body); return data is Map<String, dynamic> ? data : null; }
      return null;
    } catch (e) { return null; }
  }

  static Future<Map<String, dynamic>?> download(String url) async {
    try {
      final uri = Uri.parse('$_baseUrl/downloader/xvideos').replace(queryParameters: {'url': url});
      final res = await http.get(uri).timeout(const Duration(seconds: 20));
      if (res.statusCode == 200) { final data = jsonDecode(res.body); return data is Map<String, dynamic> ? data : null; }
      return null;
    } catch (e) { return null; }
  }

  static Map<String, String> extractLinks(Map<String, dynamic> data) {
    final links = <String, String>{};
    final dynamic result = data['result'] ?? data['data'];
    if (result is Map) {
      dynamic videosMap = result['videos'];
      if (videosMap is Map) { videosMap = videosMap['videos']; }
      if (videosMap is Map) {
        if (videosMap['low'] is String && videosMap['low'].toString().startsWith('http')) links['LOW (240p)'] = videosMap['low'].toString();
        if (videosMap['high'] is String && videosMap['high'].toString().startsWith('http')) links['HIGH (360p)'] = videosMap['high'].toString();
        if (videosMap['HLS'] is String && videosMap['HLS'].toString().startsWith('http')) links['HLS'] = videosMap['HLS'].toString();
      }
      if (links.isEmpty) {
        for (final k in ['url', 'link', 'download', 'download_url', 'video_url', 'dl', 'video']) {
          final v = result[k];
          if (v is String && v.isNotEmpty && v.startsWith('http')) { links[k.toUpperCase()] = v; }
        }
      }
    }
    return links;
  }
}

class XvideosPage extends StatefulWidget {
  const XvideosPage({super.key});
  @override
  State<XvideosPage> createState() => _XvideosPageState();
}

class _XvideosPageState extends State<XvideosPage> with TickerProviderStateMixin {
  List<Map<String, dynamic>> _results = [];
  bool _isSearching = false;
  bool _hasSearched = false;
  String? _errorMessage;
  int _totalCount = 0;
  String _lastQuery = '';
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  late AnimationController _glowController;
  late AnimationController _fadeController;

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(vsync: this, duration: const Duration(milliseconds: 2500))..repeat(reverse: true);
    _fadeController = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _focusNode.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _glowController.dispose(); _fadeController.dispose(); _searchController.dispose(); _focusNode.dispose(); super.dispose();
  }

  Future<void> _doSearch(String query) async {
    if (query.trim().isEmpty) return;
    setState(() { _isSearching = true; _hasSearched = true; _errorMessage = null; _results.clear(); _totalCount = 0; _lastQuery = query; });
    final data = await _XvideosApi.search(query);
    if (!mounted) return;
    if (data == null) { setState(() { _isSearching = false; _errorMessage = 'Gagal terhubung ke API. Cek koneksi internet kamu.'; }); return; }
    if (data['status'] == false) { setState(() { _isSearching = false; _errorMessage = data['message']?.toString() ?? 'API error'; }); return; }
    final dynamic result = data['result'];
    List<dynamic> rawItems = [];
    if (result is Map) { _totalCount = result['count'] ?? 0; rawItems = result['items'] ?? []; }
    else if (result is List) { rawItems = result; }
    final videos = <Map<String, dynamic>>[];
    for (final item in rawItems) {
      if (item is! Map) continue;
      final title = (item['title'] ?? '').toString();
      final url = (item['url'] ?? '').toString();
      final cover = (item['cover'] ?? '').toString();
      final duration = (item['duration'] ?? '').toString();
      final resolution = (item['resolution'] ?? '').toString();
      final artist = (item['artist'] ?? '').toString();
      if (title.isEmpty && url.isEmpty) continue;
      videos.add({'title': title, 'url': url, 'cover': cover, 'duration': duration, 'resolution': resolution, 'artist': artist});
    }
    _fadeController.forward(from: 0);
    setState(() { _results = videos; _isSearching = false; });
  }

  void _showVideoOptions(Map<String, dynamic> video) {
    final title = video['title'] ?? '';
    final url = video['url'] ?? '';
    final cover = video['cover'] ?? '';
    final duration = video['duration'] ?? '';
    final resolution = video['resolution'] ?? '';
    final artist = video['artist'] ?? '';
    showModalBottomSheet(context: context, backgroundColor: Colors.transparent, isScrollControlled: true,
      builder: (_) => Container(margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        decoration: BoxDecoration(color: _VC.card, borderRadius: BorderRadius.circular(20), border: Border.all(color: _VC.border, width: 1), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 24, offset: const Offset(0, 12))]),
        child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: Container(width: 40, height: 3, decoration: BoxDecoration(color: _VC.accent, borderRadius: BorderRadius.circular(2)))),
          const SizedBox(height: 16),
          if (cover.isNotEmpty) ...[ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.network(cover, width: double.infinity, height: 180, fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(width: double.infinity, height: 180, decoration: BoxDecoration(color: _VC.surface, borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.broken_image_rounded, color: _VC.muted, size: 40)))), const SizedBox(height: 14)],
          Text(title, style: const TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 14, fontWeight: FontWeight.w700, color: _VC.text, height: 1.3), maxLines: 3, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 10),
          Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: _VC.surface, borderRadius: BorderRadius.circular(12)),
            child: Wrap(spacing: 12, runSpacing: 6, children: [
              if (duration.isNotEmpty) Row(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.schedule_rounded, color: _VC.muted, size: 12), const SizedBox(width: 4), Text(duration, style: const TextStyle(color: _VC.muted, fontSize: 11, fontFamily: 'ShareTechMono'))]),
              if (resolution.isNotEmpty && resolution != '-') Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: _VC.accent.withOpacity(0.2), borderRadius: BorderRadius.circular(4)), child: Text(resolution.toUpperCase(), style: const TextStyle(color: _VC.accent, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'ShareTechMono'))),
              if (artist.isNotEmpty && artist != '-') Row(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.person_rounded, color: _VC.muted, size: 12), const SizedBox(width: 4), Text(artist, style: const TextStyle(color: _VC.muted, fontSize: 11, fontFamily: 'ShareTechMono'))]),
            ])),
          const SizedBox(height: 20),
          Row(children: [
            Expanded(child: GestureDetector(onTap: () { Navigator.pop(context); _watchVideo(url, title); },
              child: Container(padding: const EdgeInsets.symmetric(vertical: 14), decoration: BoxDecoration(gradient: LinearGradient(colors: [_VC.accent, _VC.accent2]), borderRadius: BorderRadius.circular(14), boxShadow: [BoxShadow(color: _VC.accent.withOpacity(0.3), blurRadius: 12, offset: const Offset(0, 4))]),
                child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.play_circle_filled_rounded, color: Colors.white, size: 18), SizedBox(width: 8), Text('WATCH', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 13, fontWeight: FontWeight.w700, color: Colors.white, letterSpacing: 1.5))])))),
            const SizedBox(width: 10),
            Expanded(child: GestureDetector(onTap: () { Navigator.pop(context); _handleDownload(url, title); },
              child: Container(padding: const EdgeInsets.symmetric(vertical: 14), decoration: BoxDecoration(color: _VC.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: _VC.border)),
                child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.download_rounded, color: _VC.success, size: 18), SizedBox(width: 8), Text('DOWNLOAD', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 13, fontWeight: FontWeight.w700, color: _VC.text, letterSpacing: 1.5))])))),
          ]),
          const SizedBox(height: 10),
          SizedBox(width: double.infinity, child: GestureDetector(onTap: () { Navigator.pop(context); _openInBrowser(url); },
            child: Container(padding: const EdgeInsets.symmetric(vertical: 12), decoration: BoxDecoration(color: _VC.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: _VC.border2)),
              child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.open_in_new_rounded, color: _VC.muted, size: 16), SizedBox(width: 8), Text('OPEN IN BROWSER', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: _VC.muted, letterSpacing: 1))])))),
          const SizedBox(height: 8),
        ]))));
  }

  Future<void> _watchVideo(String videoUrl, String title) async {
    if (videoUrl.isEmpty) return;
    Navigator.push(context, MaterialPageRoute(builder: (_) => _XvideosVideoPlayerPage(videoPageUrl: videoUrl, title: title)));
  }

  void _showActionError(String msg) {
    showModalBottomSheet(context: context, backgroundColor: Colors.transparent, isScrollControlled: true,
      builder: (_) => Container(margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        decoration: BoxDecoration(color: _VC.card, borderRadius: BorderRadius.circular(20), border: Border.all(color: _VC.border), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 24)]),
        child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
          Center(child: Container(width: 40, height: 3, decoration: BoxDecoration(color: _VC.danger, borderRadius: BorderRadius.circular(2)))),
          const SizedBox(height: 18), const Icon(Icons.warning_amber_rounded, color: _VC.danger, size: 40), const SizedBox(height: 14),
          const Text('ERROR', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 14, fontWeight: FontWeight.w700, color: _VC.danger)), const SizedBox(height: 8),
          Container(width: double.infinity, padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: _VC.surface, borderRadius: BorderRadius.circular(12)),
            child: Text(msg, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: _VC.muted, height: 1.5), textAlign: TextAlign.center)), const SizedBox(height: 16),
          GestureDetector(onTap: () => Navigator.pop(context), child: Container(padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12), decoration: BoxDecoration(color: _VC.accent, borderRadius: BorderRadius.circular(12)),
            child: const Text('OK', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.w700, color: Colors.white, letterSpacing: 2)))),
        ]))));
  }

  void _openInBrowser(String url) async {
    if (url.isEmpty) return;
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) { await launchUrl(uri, mode: LaunchMode.externalApplication); }
  }

  Future<void> _handleDownload(String videoUrl, String title) async {
    if (videoUrl.isEmpty) return;
    showDialog(context: context, barrierDismissible: false, builder: (_) => const _XvFetchLoadingDialog());
    final data = await _XvideosApi.download(videoUrl);
    if (!mounted) return;
    Navigator.pop(context);
    if (data == null) { _showActionError('Gagal terhubung ke server. Coba lagi nanti.'); return; }
    if (data['status'] == false) { _showActionError(data['error'] ?? data['message'] ?? 'Download gagal.'); return; }
    final links = _XvideosApi.extractLinks(data);
    if (links.isEmpty) { _showActionError('Tidak ditemukan link download. Coba buka di browser.'); return; }
    _showDownloadResult(links, title);
  }

  void _showDownloadResult(Map<String, String> links, String title) {
    showModalBottomSheet(context: context, backgroundColor: Colors.transparent, isScrollControlled: true,
      builder: (_) => Container(margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        decoration: BoxDecoration(color: _VC.card, borderRadius: BorderRadius.circular(20), border: Border.all(color: _VC.border), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 24)]),
        child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: Container(width: 40, height: 3, decoration: BoxDecoration(color: _VC.success, borderRadius: BorderRadius.circular(2)))),
          const SizedBox(height: 18), const Icon(Icons.check_circle_rounded, color: _VC.success, size: 40), const SizedBox(height: 10),
          const Text('DOWNLOAD READY', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 14, fontWeight: FontWeight.w700, color: _VC.success, letterSpacing: 1.5)),
          const SizedBox(height: 12),
          Container(width: double.infinity, padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: _VC.surface, borderRadius: BorderRadius.circular(12)),
            child: Text(title, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: _VC.muted, height: 1.4), maxLines: 3, overflow: TextOverflow.ellipsis)),
          const SizedBox(height: 16),
          ...links.entries.map((entry) {
            final isHLS = entry.key.toUpperCase().contains('HLS');
            return Padding(padding: const EdgeInsets.only(bottom: 8), child: SizedBox(width: double.infinity, child: GestureDetector(
              onTap: () { Navigator.pop(context); _openInBrowser(entry.value); },
              child: Container(padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 16), decoration: BoxDecoration(color: _VC.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: _VC.border)),
                child: Row(children: [const Icon(Icons.download_rounded, color: _VC.success, size: 18), const SizedBox(width: 10),
                  Expanded(child: Text(entry.key, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, fontWeight: FontWeight.bold, color: _VC.success, letterSpacing: 1))),
                  const Icon(Icons.arrow_forward_rounded, color: _VC.muted2, size: 16)])))));
          }), const SizedBox(height: 8),
        ]))));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: _VC.bg, body: SafeArea(child: Column(children: [_buildHeader(), const SizedBox(height: 8), _buildSearchBar(), const SizedBox(height: 8), Expanded(child: _buildBody())])));
  }

  Widget _buildHeader() {
    return ClipRect(child: BackdropFilter(filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16), child: Container(
      height: 58, padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(color: const Color(0xEB0A0A12), border: Border(bottom: BorderSide(color: _VC.border))),
      child: Row(children: [
        GestureDetector(onTap: () => Navigator.pop(context), child: Container(width: 38, height: 38, decoration: BoxDecoration(color: _VC.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: _VC.border2)), child: const Icon(Icons.arrow_back_rounded, color: _VC.muted, size: 15))),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
          ShaderMask(shaderCallback: (b) => const LinearGradient(colors: [_VC.accent, _VC.accent3]).createShader(b), child: const Text('XVIDEOS EXPLORER', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white, letterSpacing: 2))),
          const Text('SEARCH \u2022 DOWNLOAD \u2022 STREAM', style: TextStyle(fontSize: 9, color: _VC.muted, letterSpacing: 1, fontFamily: 'ShareTechMono')),
        ])),
        AnimatedBuilder(animation: _glowController, builder: (_, __) => Container(width: 38, height: 38, decoration: BoxDecoration(color: _VC.accent.withOpacity(0.08 + _glowController.value * 0.1), borderRadius: BorderRadius.circular(10), border: Border.all(color: _VC.accent.withOpacity(0.2 + _glowController.value * 0.2))), child: Icon(Icons.hd_rounded, color: _VC.accent.withOpacity(0.6 + _glowController.value * 0.4), size: 15))),
      ]))));
  }

  Widget _buildSearchBar() {
    return Padding(padding: const EdgeInsets.symmetric(horizontal: 14), child: AnimatedContainer(duration: const Duration(milliseconds: 200), height: 46,
      decoration: BoxDecoration(color: _VC.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: _focusNode.hasFocus ? _VC.accent.withOpacity(0.5) : _VC.border2), boxShadow: _focusNode.hasFocus ? [BoxShadow(color: _VC.accent.withOpacity(0.1), blurRadius: 10)] : []),
      child: Row(children: [
        const SizedBox(width: 14), Icon(Icons.search_rounded, color: _focusNode.hasFocus ? _VC.accent : _VC.muted2, size: 16), const SizedBox(width: 10),
        Expanded(child: TextField(controller: _searchController, focusNode: _focusNode, style: const TextStyle(color: _VC.text, fontSize: 13, fontFamily: 'ShareTechMono'), cursorColor: _VC.accent, textInputAction: TextInputAction.search, onSubmitted: (v) => _doSearch(v),
          decoration: InputDecoration(hintText: 'Cari video XVideos...', hintStyle: const TextStyle(color: _VC.muted2, fontSize: 13), border: InputBorder.none, isDense: true, contentPadding: const EdgeInsets.symmetric(vertical: 12)))),
        if (_isSearching) const Padding(padding: EdgeInsets.only(right: 12), child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, valueColor: AlwaysStoppedAnimation(_VC.accent))))
        else if (_searchController.text.isNotEmpty) GestureDetector(onTap: () { _searchController.clear(); setState(() { _results.clear(); _hasSearched = false; _errorMessage = null; _totalCount = 0; }); _focusNode.unfocus(); }, child: const Padding(padding: EdgeInsets.only(right: 10), child: Icon(Icons.close_rounded, color: _VC.muted, size: 16))),
        const SizedBox(width: 4),
        GestureDetector(onTap: () { if (_searchController.text.trim().isNotEmpty) { _doSearch(_searchController.text.trim()); _focusNode.unfocus(); } },
          child: Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9), decoration: BoxDecoration(gradient: const LinearGradient(colors: [_VC.accent, _VC.accent2]), borderRadius: BorderRadius.circular(10), boxShadow: [BoxShadow(color: _VC.accent.withOpacity(0.3), blurRadius: 8)]), child: const Icon(Icons.search_rounded, color: Colors.white, size: 16))),
        const SizedBox(width: 12),
      ])));
  }

  Widget _buildBody() {
    if (_isSearching) return _buildShimmerGrid();
    if (_errorMessage != null) return _buildErrorView();
    if (!_hasSearched) return _buildWelcomeView();
    if (_results.isEmpty) return _buildEmptyView();
    return FadeTransition(opacity: _fadeController, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_buildResultHeader(), Expanded(child: ListView.builder(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4), itemCount: _results.length, itemBuilder: (_, i) => _buildVideoCard(_results[i], i)))]));
  }

  Widget _buildResultHeader() {
    return Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6), child: Row(children: [
      Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: _VC.accent.withOpacity(0.1), borderRadius: BorderRadius.circular(6), border: Border.all(color: _VC.accent.withOpacity(0.2))), child: Text('${_results.length} VIDEO', style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _VC.accent, fontWeight: FontWeight.bold, letterSpacing: 1))),
      if (_totalCount > 0) ...[const SizedBox(width: 10), Text('Total: $_totalCount', style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _VC.muted))],
      const Spacer(), Text('"$_lastQuery"', style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _VC.muted2)),
    ]));
  }

  Widget _buildVideoCard(Map<String, dynamic> video, int index) {
    final title = video['title'] ?? '';
    final cover = video['cover'] ?? '';
    final duration = video['duration'] ?? '';
    final resolution = video['resolution'] ?? '';
    final artist = video['artist'] ?? '';
    return Padding(padding: const EdgeInsets.only(bottom: 10), child: GestureDetector(onTap: () => _showVideoOptions(video),
      child: Container(decoration: BoxDecoration(color: _VC.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: _VC.border)),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          ClipRRect(borderRadius: const BorderRadius.only(topLeft: Radius.circular(14), bottomLeft: Radius.circular(14)), child: Stack(children: [
            SizedBox(width: 140, height: 100, child: cover.isNotEmpty
              ? Image.network(cover, width: 140, height: 100, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(width: 140, height: 100, color: _VC.surface, child: const Icon(Icons.broken_image_rounded, color: _VC.muted2, size: 28)))
              : Container(width: 140, height: 100, color: _VC.surface, child: const Icon(Icons.video_library_rounded, color: _VC.muted2, size: 28))),
            if (duration.isNotEmpty) Positioned(bottom: 6, right: 6, child: Container(padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2), decoration: BoxDecoration(color: Colors.black.withOpacity(0.8), borderRadius: BorderRadius.circular(4)), child: Text(duration, style: const TextStyle(color: Colors.white, fontSize: 9, fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)))),
            if (resolution.isNotEmpty && resolution != '-') Positioned(top: 6, left: 6, child: Container(padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2), decoration: BoxDecoration(color: _VC.accent.withOpacity(0.9), borderRadius: BorderRadius.circular(4)), child: Text(resolution.toUpperCase(), style: const TextStyle(color: Colors.white, fontSize: 8, fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)))),
            Positioned.fill(child: Center(child: Container(width: 32, height: 32, decoration: BoxDecoration(color: Colors.black.withOpacity(0.5), shape: BoxShape.circle), child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 18)))),
          ])),
          Expanded(child: Padding(padding: const EdgeInsets.all(10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.w600, color: _VC.text, height: 1.3), maxLines: 3, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 8),
            if (artist.isNotEmpty && artist != '-') Row(children: [const Icon(Icons.person_rounded, color: _VC.muted, size: 11), const SizedBox(width: 4), Expanded(child: Text(artist, style: const TextStyle(color: _VC.accent, fontSize: 10, fontFamily: 'ShareTechMono'), maxLines: 1, overflow: TextOverflow.ellipsis))]),
            const Spacer(), const Row(children: [Icon(Icons.more_vert_rounded, color: _VC.muted2, size: 16)]),
          ]))),
        ]))));
  }

  Widget _buildShimmerGrid() {
    return ListView.builder(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4), itemCount: 6, itemBuilder: (_, __) => Padding(padding: const EdgeInsets.only(bottom: 10),
      child: Shimmer.fromColors(baseColor: _VC.surface, highlightColor: _VC.card, child: Container(height: 100, decoration: BoxDecoration(color: _VC.surface, borderRadius: BorderRadius.circular(14))))));
  }

  Widget _buildWelcomeView() {
    return Center(child: SingleChildScrollView(padding: const EdgeInsets.all(30), child: Column(children: [
      AnimatedBuilder(animation: _glowController, builder: (_, __) => Container(width: 110, height: 110, decoration: BoxDecoration(color: _VC.accent.withOpacity(0.06 + _glowController.value * 0.08), shape: BoxShape.circle, border: Border.all(color: _VC.accent.withOpacity(0.15 + _glowController.value * 0.15), width: 2)), child: Icon(Icons.play_circle_filled_rounded, color: _VC.accent.withOpacity(0.5 + _glowController.value * 0.5), size: 44))),
      const SizedBox(height: 24),
      ShaderMask(shaderCallback: (b) => const LinearGradient(colors: [_VC.accent, _VC.accent3]).createShader(b), child: const Text('XVIDEOS', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 26, fontWeight: FontWeight.bold, color: Colors.white, letterSpacing: 4))),
      const SizedBox(height: 8), const Text('Search, Download & Watch', style: TextStyle(color: _VC.muted, fontSize: 13, fontFamily: 'ShareTechMono')),
      const SizedBox(height: 4), Text('api.deline.web.id', style: TextStyle(color: _VC.accent.withOpacity(0.6), fontSize: 11, fontFamily: 'ShareTechMono')),
      const SizedBox(height: 28),
      _buildFeatureCard(Icons.search_rounded, 'SEARCH', 'Cari video berdasarkan keyword'), const SizedBox(height: 10),
      _buildFeatureCard(Icons.download_rounded, 'DOWNLOAD', 'Download video multi kualitas (Low/High/HLS)'), const SizedBox(height: 10),
      _buildFeatureCard(Icons.play_circle_filled_rounded, 'STREAM', 'Tonton langsung di dalam app'), const SizedBox(height: 10),
      _buildFeatureCard(Icons.image_rounded, 'THUMBNAIL', 'Preview thumbnail sebelum nonton'), const SizedBox(height: 28),
      const Align(alignment: Alignment.centerLeft, child: Text('QUICK SEARCH', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 11, fontWeight: FontWeight.w700, color: _VC.muted, letterSpacing: 2))),
      const SizedBox(height: 10),
      Wrap(spacing: 8, runSpacing: 8, children: [_buildQuickChip('Japanese'), _buildQuickChip('Korean'), _buildQuickChip('Indo'), _buildQuickChip('Thai'), _buildQuickChip('Massage'), _buildQuickChip('Asian')]),
    ])));
  }

  Widget _buildFeatureCard(dynamic icon, String title, String desc) {
    return Container(width: double.infinity, padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: _VC.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: _VC.border)),
      child: Row(children: [Container(width: 42, height: 42, decoration: BoxDecoration(color: _VC.accent.withOpacity(0.1), borderRadius: BorderRadius.circular(12), border: Border.all(color: _VC.accent.withOpacity(0.2))), child: _DynamicIcon(icon, color: _VC.accent, size: 18)),
        const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.w700, color: _VC.text, letterSpacing: 1.5)), const SizedBox(height: 3), Text(desc, style: const TextStyle(color: _VC.muted, fontSize: 11, fontFamily: 'ShareTechMono'))]))]));
  }

  Widget _buildQuickChip(String query) {
    return GestureDetector(onTap: () { _searchController.text = query; _doSearch(query); },
      child: Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10), decoration: BoxDecoration(color: _VC.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: _VC.border)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.search_rounded, color: _VC.accent, size: 13), const SizedBox(width: 8), Text(query, style: const TextStyle(color: _VC.text, fontSize: 13))])));
  }

  Widget _buildErrorView() {
    return Center(child: SingleChildScrollView(padding: const EdgeInsets.all(30), child: Column(children: [
      const Icon(Icons.warning_amber_rounded, color: _VC.danger, size: 44), const SizedBox(height: 16),
      const Text('Oops!', style: TextStyle(color: _VC.text, fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 8),
      Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: _VC.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: _VC.border)),
        child: Text(_errorMessage ?? 'Terjadi kesalahan', style: const TextStyle(color: _VC.muted, fontSize: 12, height: 1.5, fontFamily: 'ShareTechMono'), textAlign: TextAlign.center)),
      const SizedBox(height: 20), GestureDetector(onTap: () => _doSearch(_lastQuery), child: Container(padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12), decoration: BoxDecoration(color: _VC.accent, borderRadius: BorderRadius.circular(12)),
        child: const Text('RETRY', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.w700, color: Colors.white, letterSpacing: 2)))),
    ])));
  }

  Widget _buildEmptyView() {
    return Center(child: SingleChildScrollView(padding: const EdgeInsets.all(30), child: Column(children: [
      const Icon(Icons.search_off_rounded, color: _VC.muted2, size: 48), const SizedBox(height: 16),
      const Text('Tidak ditemukan', style: TextStyle(color: _VC.text, fontSize: 16, fontWeight: FontWeight.bold)), const SizedBox(height: 8),
      const Text('Coba keyword lain ya...', style: TextStyle(color: _VC.muted, fontSize: 13)),
    ])));
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// LOADING DIALOG
// ═══════════════════════════════════════════════════════════════════════════════
class _XvFetchLoadingDialog extends StatefulWidget {
  const _XvFetchLoadingDialog();
  @override
  State<_XvFetchLoadingDialog> createState() => _XvFetchLoadingDialogState();
}

class _XvFetchLoadingDialogState extends State<_XvFetchLoadingDialog> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  @override
  void initState() { super.initState(); _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat(); }
  @override
  void dispose() { _controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    return Dialog(backgroundColor: Colors.transparent, child: Container(padding: const EdgeInsets.all(24), decoration: BoxDecoration(color: _VC.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _VC.border)),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        AnimatedBuilder(animation: _controller, builder: (_, __) => Container(width: 48, height: 48, decoration: BoxDecoration(color: _VC.accent.withOpacity(0.1 + _controller.value * 0.15), shape: BoxShape.circle, border: Border.all(color: _VC.accent.withOpacity(0.2 + _controller.value * 0.3))),
          child: const Center(child: SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, valueColor: AlwaysStoppedAnimation(_VC.accent)))))),
        const SizedBox(height: 16), const Text('LOADING...', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.w700, color: _VC.text, letterSpacing: 1.5)),
      ])));
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// VIDEO PLAYER PAGE — Fetches API data, quality selector, HTML player + HLS.js
// Uses loadHtmlString with baseUrl for Referer header on CDN requests
// ═══════════════════════════════════════════════════════════════════════════════
class _XvideosVideoPlayerPage extends StatefulWidget {
  final String videoPageUrl;
  final String title;
  const _XvideosVideoPlayerPage({required this.videoPageUrl, this.title = ''});
  @override
  State<_XvideosVideoPlayerPage> createState() => _XvideosVideoPlayerPageState();
}

class _XvideosVideoPlayerPageState extends State<_XvideosVideoPlayerPage> with WidgetsBindingObserver {
  bool _isLoading = true;
  bool _isError = false;
  String? _errorMessage;
  bool _isWebViewLoading = true;
  bool _isFullScreen = false;

  // Quality
  List<Map<String, String>> _qualities = []; // [{title, url}]
  int _selectedQualityIndex = 0;
  bool _showQualitySelector = true;

  String? _streamUrl;
  late WebViewController _webViewController;

  // Ad domains
  static const List<String> _adDomains = [
    'doubleclick.net', 'googlesyndication.com', 'googleadservices.com', 'google-analytics.com',
    'adnxs.com', 'adsrvr.org', 'taboola.com', 'outbrain.com', 'popads.net', 'popcash.net',
    'propellerads.com', 'juicyads.com', 'exoclick.com', 'trafficjunky.com', 'adsterra.com',
    'hilltopads.net', 'clickadu.com', 'richpush.com', 'adform.net', 'criteo.com',
    'amazon-adsystem.com', 'moatads.com', 'scorecardresearch.com', 'quantserve.com',
    'rubiconproject.com', 'openx.net', 'casalemedia.com', 'indexexchange.com', 'pubmatic.com',
    'smartadserver.com', 'advertising.com', 'adsymptotic.com', 'bidswitch.com', 'lijit.com',
    'media.net', 'mookie1.com', 'nativex.com', 'serving-sys.com', 'sharethis.com', 'simpli.fi',
    'sitescout.com', 'sonobi.com', 'spotxchange.com', 'tapad.com', 'tidaltv.com', 'towerdata.com',
    'turn.com', 'yldbt.com', 'zergnet.com', 'mgid.com', 'revcontent.com', 'contentabc.com',
    'bidvertiser.com', 'yllix.com', 'evadav.com', 'monetag.com', 'profitablecpmrate.com',
    'popunder.net', 'clicksor.com', 'infolinks.com', 'chitika.com', 'buysellads.com',
  ];

  bool _isAdUrl(String url) {
    final uri = Uri.tryParse(url);
    if (uri == null) return false;
    final host = uri.host.toLowerCase();
    for (final adDomain in _adDomains) {
      if (host.contains(adDomain)) return true;
    }
    return false;
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _fetchVideoData();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  void didChangeMetrics() {
    super.didChangeMetrics();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final size = MediaQuery.of(context).size;
      final isNowFullScreen = size.width > size.height;
      if (isNowFullScreen != _isFullScreen) {
        setState(() { _isFullScreen = isNowFullScreen; });
        if (_isFullScreen) {
          SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
          SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
        } else {
          SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
          SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
        }
      }
    });
  }

  Future<void> _fetchVideoData() async {
    try {
      final data = await _XvideosApi.download(widget.videoPageUrl);
      if (!mounted) return;
      if (data == null) {
        setState(() { _isLoading = false; _isError = true; _errorMessage = 'Gagal terhubung ke server. Coba lagi nanti.'; });
        return;
      }
      if (data['status'] == false) {
        setState(() { _isLoading = false; _isError = true; _errorMessage = data['error'] ?? data['message'] ?? 'Gagal mengambil video.'; });
        return;
      }
      final links = _XvideosApi.extractLinks(data);
      if (links.isEmpty) {
        setState(() { _isLoading = false; _isError = true; _errorMessage = 'Tidak ditemukan link video. Coba buka di browser.'; });
        return;
      }
      // Convert to quality list
      setState(() {
        _qualities = links.entries.map((e) => {'title': e.key, 'url': e.value}).toList();
        // Default: prefer HIGH > LOW > HLS > first
        _selectedQualityIndex = 0;
        for (int i = 0; i < _qualities.length; i++) {
          if (_qualities[i]['title']!.toUpperCase().contains('HIGH')) {
            _selectedQualityIndex = i;
            break;
          }
        }
        _streamUrl = _qualities[_selectedQualityIndex]['url'];
        _isLoading = false;
      });
      _initializeWebView();
    } catch (e) {
      debugPrint('Error fetching video data: $e');
      if (mounted) setState(() { _isLoading = false; _isError = true; _errorMessage = 'Terjadi kesalahan. Coba lagi.'; });
    }
  }

  void _changeQuality(int index) {
    if (index < 0 || index >= _qualities.length) return;
    setState(() {
      _selectedQualityIndex = index;
      _streamUrl = _qualities[index]['url'];
      _isWebViewLoading = true;
      _showQualitySelector = false;
    });
    _initializeWebView();
  }

  void _initializeWebView() {
    if (_streamUrl == null) return;
    final html = _generatePlayerHtml(_streamUrl!);
    _webViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..addJavaScriptChannel('FullScreen', onMessageReceived: (JavaScriptMessage message) {
        if (message.message == 'enter') {
          _enterFullScreen();
        } else if (message.message == 'exit') {
          _exitFullScreen();
        }
      })
      ..setNavigationDelegate(NavigationDelegate(
        onProgress: (int progress) {
          if (progress == 100) {
            setState(() { _isWebViewLoading = false; });
            _injectAdBlocker();
          }
        },
        onPageStarted: (_) => setState(() { _isWebViewLoading = true; }),
        onPageFinished: (_) {
          setState(() { _isWebViewLoading = false; });
          _injectAdBlocker();
        },
        onWebResourceError: (_) => setState(() { _isWebViewLoading = false; }),
        onNavigationRequest: (NavigationRequest request) {
          if (_isAdUrl(request.url)) return NavigationDecision.prevent;
          if (!request.url.startsWith('http://') && !request.url.startsWith('https://')) return NavigationDecision.prevent;
          return NavigationDecision.navigate;
        },
      ))
      // KEY: Use loadHtmlString with baseUrl to set Referer header
      ..loadHtmlString(html, baseUrl: 'https://www.xvideos.com/');
  }

  void _injectAdBlocker() {
    _webViewController.runJavaScript('''
      (function() {
        try {
          var style = document.createElement('style');
          style.textContent = 'iframe, [id*="ad"], [class*="ad"], [class*="popup"], div[id^="ads"], div[id^="pop"] { display: none !important; }';
          document.head.appendChild(style);
        } catch(e) {}
      })();
    ''');
  }

  void _enterFullScreen() {
    if (_isFullScreen) return;
    setState(() { _isFullScreen = true; });
    SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  void _exitFullScreen() {
    if (!_isFullScreen) return;
    setState(() { _isFullScreen = false; });
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  }

  void _toggleFullScreen() {
    if (_isFullScreen) {
      _exitFullScreen();
    } else {
      _enterFullScreen();
    }
  }

  void _refreshPlayer() {
    setState(() { _isWebViewLoading = true; });
    _initializeWebView();
  }

  void _openInExternalBrowser() async {
    if (widget.videoPageUrl.isNotEmpty) {
      final uri = Uri.parse(widget.videoPageUrl);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
    }
  }

  static String _generatePlayerHtml(String videoUrl) {
    final isHls = videoUrl.toLowerCase().contains('.m3u8');
    if (isHls) {
      return '''<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<script src="https://cdn.jsdelivr.net/npm/hls.js@1.5.7/dist/hls.min.js"></script>
<style>*{margin:0;padding:0;box-sizing:border-box}body{background:#000;display:flex;align-items:center;justify-content:center;min-height:100vh;overflow:hidden}
video{width:100%;height:100vh;object-fit:contain;background:#000}</style></head><body>
<video id="v" controls autoplay playsinline></video>
<script>
var video=document.getElementById('v');
if(Hls.isSupported()){var hls=Hls({xhrSetup:function(xhr,url){xhr.setRequestHeader('Referer','https://www.xvideos.com/');}});hls.loadSource('$videoUrl');hls.attachMedia(video);
hls.on(Hls.Events.MANIFEST_PARSED,function(){video.play().catch(function(){});});
hls.on(Hls.Events.ERROR,function(e,d){if(d.fatal){console.error('HLS Error',d);document.body.innerHTML='<div style="color:#ff4d6d;text-align:center;padding:40px;font-family:sans-serif"><h3>Error Loading Video</h3><p>Stream failed to load</p></div>';}});}
else if(video.canPlayType('application/vnd.apple.mpegurl')){video.src='$videoUrl';video.addEventListener('loadedmetadata',function(){video.play().catch(function(){});});}
video.addEventListener('error',function(){document.body.innerHTML='<div style="color:#ff4d6d;text-align:center;padding:40px;font-family:sans-serif"><h3>Error Loading Video</h3><p>Could not load video from server</p><p style="font-size:12px;color:#888;margin-top:10px">The video URL may have expired. Try again.</p></div>';});
</script></body></html>''';
    } else {
      return '''<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>*{margin:0;padding:0;box-sizing:border-box}body{background:#000;display:flex;align-items:center;justify-content:center;min-height:100vh;overflow:hidden}
video{width:100%;height:100vh;object-fit:contain;background:#000}</style></head><body>
<video id="v" src="$videoUrl" controls autoplay playsinline></video>
<script>
document.getElementById('v').addEventListener('error',function(){document.body.innerHTML='<div style="color:#ff4d6d;text-align:center;padding:40px;font-family:sans-serif"><h3>Error Loading Video</h3><p>Could not load video from server</p><p style="font-size:12px;color:#888;margin-top:10px">The video URL may have expired. Try again.</p></div>';});
</script></body></html>''';
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isFullScreen) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: Stack(children: [
          _buildWebView(),
          // Exit fullscreen button (top left)
          Positioned(
            top: 12,
            left: 12,
            child: GestureDetector(
              onTap: _exitFullScreen,
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: Colors.black.withOpacity(0.6), borderRadius: BorderRadius.circular(8)),
                child: const Icon(Icons.fullscreen_exit_rounded, color: Colors.white, size: 22),
              ),
            ),
          ),
          // Loading overlay
          if (_isWebViewLoading)
            Positioned.fill(
              child: Container(
                color: Colors.black.withOpacity(0.7),
                child: const Center(
                  child: CircularProgressIndicator(color: _VC.accent, strokeWidth: 2.5),
                ),
              ),
            ),
        ]),
      );
    }

    return Scaffold(
      backgroundColor: _VC.bg,
      appBar: _buildAppBar(),
      body: _buildBody(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: _VC.bg2,
      elevation: 0,
      leading: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Container(
          margin: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: _VC.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: _VC.border2)),
          child: const Icon(Icons.arrow_back_rounded, color: _VC.muted, size: 18),
        ),
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('NOW PLAYING', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 11, fontWeight: FontWeight.w700, color: _VC.accent, letterSpacing: 1.5)),
          if (widget.title.isNotEmpty)
            Text(widget.title, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _VC.muted), maxLines: 1, overflow: TextOverflow.ellipsis),
        ],
      ),
      actions: [
        if (!_isLoading && !_isError && _qualities.length > 1)
          GestureDetector(
            onTap: _refreshPlayer,
            child: Container(
              margin: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: _VC.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: _VC.border2)),
              child: const Icon(Icons.refresh_rounded, color: _VC.muted, size: 18),
            ),
          ),
        GestureDetector(
          onTap: _openInExternalBrowser,
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(color: _VC.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: _VC.border2)),
            child: Row(children: [
              const Icon(Icons.open_in_new_rounded, color: _VC.muted, size: 14),
              const SizedBox(width: 4),
              const Text('BROWSER', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: _VC.muted, letterSpacing: 1)),
            ]),
          ),
        ),
      ],
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          SizedBox(
            width: 64, height: 64,
            child: CircularProgressIndicator(strokeWidth: 3, valueColor: const AlwaysStoppedAnimation(_VC.accent)),
          ),
          const SizedBox(height: 20),
          const Text('LOADING VIDEO DATA...', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 13, fontWeight: FontWeight.w700, color: _VC.text, letterSpacing: 1.5)),
          const SizedBox(height: 8),
          const Text('Fetching stream links from server', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: _VC.muted)),
        ]),
      );
    }

    if (_isError) {
      return Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(30),
          child: Column(children: [
            const Icon(Icons.warning_amber_rounded, color: _VC.danger, size: 48),
            const SizedBox(height: 18),
            const Text('ERROR', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 16, fontWeight: FontWeight.w700, color: _VC.danger)),
            const SizedBox(height: 10),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: _VC.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: _VC.border)),
              child: Text(_errorMessage ?? 'Unknown error', style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: _VC.muted, height: 1.5), textAlign: TextAlign.center),
            ),
            const SizedBox(height: 20),
            Row(children: [
              Expanded(child: GestureDetector(
                onTap: _fetchVideoData,
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(gradient: const LinearGradient(colors: [_VC.accent, _VC.accent2]), borderRadius: BorderRadius.circular(14)),
                  child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(Icons.refresh_rounded, color: Colors.white, size: 18),
                    SizedBox(width: 8),
                    Text('RETRY', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 13, fontWeight: FontWeight.w700, color: Colors.white, letterSpacing: 1.5)),
                  ]),
                ),
              )),
              const SizedBox(width: 10),
              Expanded(child: GestureDetector(
                onTap: _openInExternalBrowser,
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(color: _VC.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: _VC.border)),
                  child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(Icons.open_in_new_rounded, color: _VC.muted, size: 18),
                    SizedBox(width: 8),
                    Text('BROWSER', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 13, fontWeight: FontWeight.w700, color: _VC.text, letterSpacing: 1.5)),
                  ]),
                ),
              )),
            ]),
          ]),
        ),
      );
    }

    return Column(children: [
      // Video container
      _buildVideoContainer(),
      // Quality selector panel
      if (_showQualitySelector && _qualities.length > 1)
        _buildQualityPanel(),
      // Video info
      if (!_isFullScreen && _showQualitySelector && _qualities.length > 1)
        _buildVideoInfo(),
    ]);
  }

  Widget _buildVideoContainer() {
    return Container(
      color: Colors.black,
      child: AspectRatio(
        aspectRatio: 16 / 9,
        child: Stack(children: [
          _buildWebView(),
          // Loading overlay
          if (_isWebViewLoading)
            Container(
              color: Colors.black.withOpacity(0.8),
              child: const Center(
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  SizedBox(width: 40, height: 40, child: CircularProgressIndicator(strokeWidth: 2.5, valueColor: AlwaysStoppedAnimation(_VC.accent))),
                  SizedBox(height: 12),
                  Text('Loading stream...', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: Colors.white54)),
                ]),
              ),
            ),
          // Quality settings button (top right)
          if (_qualities.length > 1)
            Positioned(
              top: 8,
              right: 8,
              child: GestureDetector(
                onTap: () => setState(() { _showQualitySelector = !_showQualitySelector; }),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(color: Colors.black.withOpacity(0.6), borderRadius: BorderRadius.circular(8)),
                  child: Row(children: [
                    const Icon(Icons.settings_rounded, color: Colors.white, size: 16),
                    const SizedBox(width: 4),
                    Text(
                      _qualities[_selectedQualityIndex]['title'] ?? '',
                      style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ]),
                ),
              ),
            ),
          // Fullscreen toggle (bottom right)
          Positioned(
            bottom: 8,
            right: 8,
            child: GestureDetector(
              onTap: _toggleFullScreen,
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: Colors.black.withOpacity(0.6), borderRadius: BorderRadius.circular(8)),
                child: const Icon(Icons.fullscreen_rounded, color: Colors.white, size: 22),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _buildWebView() {
    return WebViewWidget(controller: _webViewController);
  }

  Widget _buildQualityPanel() {
    return Container(
      decoration: const BoxDecoration(
        color: _VC.bg2,
        border: Border(top: BorderSide(color: _VC.border, width: 1)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Header
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(children: [
            const Icon(Icons.high_quality_rounded, color: _VC.accent, size: 18),
            const SizedBox(width: 8),
            const Text('QUALITY SETTINGS', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.w700, color: _VC.accent, letterSpacing: 1.5)),
            const Spacer(),
            GestureDetector(
              onTap: () => setState(() => _showQualitySelector = false),
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(color: _VC.surface, borderRadius: BorderRadius.circular(6)),
                child: const Icon(Icons.close_rounded, color: _VC.muted, size: 14),
              ),
            ),
          ]),
        ),
        const Divider(height: 1, color: _VC.border),
        // Quality options
        ...List.generate(_qualities.length, (index) {
          final quality = _qualities[index];
          final isSelected = index == _selectedQualityIndex;
          final isHls = quality['title']!.toUpperCase().contains('HLS');
          return GestureDetector(
            onTap: () => _changeQuality(index),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: isSelected ? _VC.accent.withOpacity(0.1) : Colors.transparent,
                border: Border(bottom: BorderSide(color: _VC.border2.withOpacity(0.3), width: 0.5)),
              ),
              child: Row(children: [
                // Radio indicator
                Container(
                  width: 20, height: 20,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: isSelected ? _VC.accent : Colors.transparent,
                    border: Border.all(color: isSelected ? _VC.accent : _VC.muted2, width: 2),
                  ),
                  child: isSelected
                      ? const Icon(Icons.check_rounded, color: Colors.white, size: 14)
                      : null,
                ),
                const SizedBox(width: 14),
                // Quality icon
                Container(
                  width: 36, height: 36,
                  decoration: BoxDecoration(
                    color: isHls ? _VC.gold.withOpacity(0.1) : _VC.surface,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: isHls ? _VC.gold.withOpacity(0.2) : _VC.border),
                  ),
                  child: Icon(
                    isHls ? Icons.stream_rounded : Icons.play_circle_filled_rounded,
                    color: isHls ? _VC.gold : _VC.accent,
                    size: 18,
                  ),
                ),
                const SizedBox(width: 12),
                // Quality label
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(quality['title'] ?? 'Unknown', style: TextStyle(
                    fontFamily: 'ShareTechMono',
                    fontSize: 13,
                    fontWeight: isSelected ? FontWeight.bold : FontWeight.w600,
                    color: isSelected ? _VC.accent : _VC.text,
                    letterSpacing: 1,
                  )),
                  const SizedBox(height: 2),
                  Text(
                    isHls ? 'HLS Adaptive Stream' : 'Direct MP4 Download',
                    style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _VC.muted),
                  ),
                ])),
                // Selected badge
                if (isSelected)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(color: _VC.accent, borderRadius: BorderRadius.circular(4)),
                    child: const Text('ACTIVE', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 8, fontWeight: FontWeight.bold, color: Colors.white, letterSpacing: 1)),
                  ),
                const SizedBox(width: 8),
                const Icon(Icons.chevron_right_rounded, color: _VC.muted2, size: 16),
              ]),
            ),
          );
        }),
        const SizedBox(height: 8),
      ]),
    );
  }

  Widget _buildVideoInfo() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (widget.title.isNotEmpty)
          Text(widget.title, style: const TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 13, fontWeight: FontWeight.w600, color: _VC.text, height: 1.3), maxLines: 3, overflow: TextOverflow.ellipsis),
        const SizedBox(height: 6),
        Row(children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(color: _VC.accent.withOpacity(0.1), borderRadius: BorderRadius.circular(4), border: Border.all(color: _VC.accent.withOpacity(0.2))),
            child: Text('${_qualities.length} QUALITIES', style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: _VC.accent, fontWeight: FontWeight.bold, letterSpacing: 1)),
          ),
          const SizedBox(width: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(color: _VC.success.withOpacity(0.1), borderRadius: BorderRadius.circular(4), border: Border.all(color: _VC.success.withOpacity(0.2))),
            child: Text(_qualities[_selectedQualityIndex]['title'] ?? '', style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: _VC.success, fontWeight: FontWeight.bold, letterSpacing: 1)),
          ),
          const SizedBox(width: 10),
          const Icon(Icons.hd_rounded, color: _VC.muted2, size: 12),
        ]),
      ]),
    );
  }
}

// WEBA2APK_DYNAMIC_ICON_START
class _DynamicIcon extends StatelessWidget {
  final dynamic icon;
  final double? size;
  final Color? color;
  final List<Shadow>? shadows;
  final String? semanticLabel;
  final dynamic textDirection;
  final double? fill;
  final double? weight;
  final double? grade;
  final double? opticalSize;
  final bool? applyTextScaling;

  const _DynamicIcon(
    this.icon, {
    Key? key,
    this.size,
    this.color,
    this.shadows,
    this.semanticLabel,
    this.textDirection,
    this.fill,
    this.weight,
    this.grade,
    this.opticalSize,
    this.applyTextScaling,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (icon == null) return const SizedBox(width: 0, height: 0);

    bool isFontAwesome = false;
    try {
      final str = icon.toString();
      final typeStr = icon.runtimeType.toString();
      if (typeStr.contains('FaIcon') ||
          str.contains('FaIcon') ||
          str.contains('font_awesome_flutter') ||
          (icon is IconData && icon.fontPackage == 'font_awesome_flutter')) {
        isFontAwesome = true;
      }
    } catch (_) {}

    if (isFontAwesome) {
      Widget child = FaIcon(
        icon is IconData ? icon : icon,
        size: size,
        color: color,
        semanticLabel: semanticLabel,
        textDirection: textDirection,
      );
      if (shadows != null && shadows!.isNotEmpty) {
        child = DecoratedBox(
          decoration: BoxDecoration(
            boxShadow: shadows!.map((s) => BoxShadow(color: s.color, blurRadius: s.blurRadius)).toList(),
          ),
          child: child,
        );
      }
      return Center(widthFactor: 1.0, heightFactor: 1.0, child: child);
    } else {
      return Center(
        widthFactor: 1.0,
        heightFactor: 1.0,
        child: Icon(
          icon is IconData ? icon : null,
          size: size,
          color: color,
          shadows: shadows,
          semanticLabel: semanticLabel,
          textDirection: textDirection,
          fill: fill,
          weight: weight,
          grade: grade,
          opticalSize: opticalSize,
          applyTextScaling: applyTextScaling,
        ),
      );
    }
  }
}
// WEBA2APK_DYNAMIC_ICON_END
