// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

// ═══════════════════════════════════════════════════════════════════════════
// GRATISAN PAGE — GRATISAN BY OMHC
// Intro 5 detik: YakuzaXsilence (2s) → developer (1s) → OmhcSilence (2s)
// Lalu masuk otomatis ke list button (Telegram) dengan animasi glow.
// NOTE: butuh dependency `url_launcher` di pubspec.yaml:
//   url_launcher: ^6.2.0
// ═══════════════════════════════════════════════════════════════════════════

// ── COLOR SCHEME (senada dengan tema aplikasi) ──────────────────────────────
class _GC {
  static const bg      = Color(0xFF000000);
  static const surface = Color(0xFF111111);
  static const card    = Color(0xFF0D0D0D);
  static const accent  = Color(0xFFFF3B30);
  static const text    = Color(0xFFE0E7FF);
  static const muted   = Color(0x73E0E7FF);
  static const muted2  = Color(0x38E0E7FF);
  static const silver  = Color(0xFFC0C0C0);
  // Telegram blue
  static const tg1     = Color(0xFF2AABEE);
  static const tg2     = Color(0xFF229ED9);
  static const tg3     = Color(0xFF0077B6);
}

class GratisanPage extends StatefulWidget {
  const GratisanPage({super.key});

  @override
  State<GratisanPage> createState() => _GratisanPageState();
}

class _GratisanPageState extends State<GratisanPage>
    with TickerProviderStateMixin {

  // ── Controllers ───────────────────────────────────────────────────────────
  late AnimationController _introController;     // intro total 5 detik
  late AnimationController _entranceController;  // entrance tombol setelah intro
  late AnimationController _glowController;      // glow pulse tombol (loop)
  Timer? _introTimer;

  bool _introDone = false;

  // ── Data list button ──────────────────────────────────────────────────────
  final List<Map<String, String>> _items = [
    {
      'title': 'NOKOS GRATIS',
      'desc': 'nokos wa dan telegram gratis',
      'url': 'https://t.me/TribunalCoreOtpBot?start=_tgr_6bMSZgAzNzk1',
    },
    {
      'title': 'USERBOT GRATIS',
      'desc': 'Userbot Gratis Bot Md Orcamod',
      'url': 'https://t.me/ORCA77_BOT?start=_tgr_YMJhnk04Njg1',
    },
    {
      'title': 'BUILD FLUTTER GRATIS',
      'desc': 'build project web/flutter anda secara gratis dan aman',
      'url': 'https://t.me/QQSSILENCE_Ai_BOT?start=_tgr_X5bgQd0yMTg1',
    },
  ];

  // ── Init ──────────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();

    // Intro: total 5 detik (YakuzaXsilence 2s → developer 1s → OmhcSilence 2s)
    _introController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    )..forward();

    // Glow pulse tombol (realtime, loop)
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();

    // Entrance tombol setelah intro selesai
    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    // Setelah 5 detik → otomatis masuk halaman utama
    _introTimer = Timer(const Duration(seconds: 5), () {
      if (mounted) {
        setState(() => _introDone = true);
        _entranceController.forward();
      }
    });
  }

  @override
  void dispose() {
    _introTimer?.cancel();
    _introController.dispose();
    _entranceController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  // ── Open Telegram link ────────────────────────────────────────────────────
  Future<void> _openLink(String url) async {
    final uri = Uri.parse(url);
    try {
      final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!ok) _showError();
    } catch (_) {
      _showError();
    }
  }

  void _showError() {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Gagal membuka Telegram. Coba lagi.',
          style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 12)),
      backgroundColor: _GC.surface,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      duration: const Duration(seconds: 2),
    ));
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _GC.bg,
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 600),
        switchInCurve: Curves.easeOut,
        switchOutCurve: Curves.easeIn,
        child: _introDone ? _buildContent() : _buildIntro(),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // INTRO — total 5 detik
  // YakuzaXsilence : 0.0s – 2.0s  (fraction 0.00 – 0.40)
  // developer      : 2.0s – 3.0s  (fraction 0.40 – 0.60)
  // OmhcSilence    : 3.0s – 5.0s  (fraction 0.60 – 1.00)
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _buildIntro() {
    return Container(
      key: const ValueKey('intro'),
      width: double.infinity,
      height: double.infinity,
      color: _GC.bg,
      child: Stack(
        children: [
          // ── Glow radial di tengah ──
          Center(
            child: AnimatedBuilder(
              animation: _introController,
              builder: (context, child) {
                final t = _introController.value;
                return Container(
                  width: 260,
                  height: 260,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: _GC.accent.withOpacity(0.10 + (math.sin(t * 2 * math.pi).abs()) * 0.08),
                        blurRadius: 90,
                        spreadRadius: 20,
                      ),
                    ],
                  ),
                );
              },
            ),
          ),

          // ── Teks intro berurutan ──
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // 1) YakuzaXsilence — 2 detik
                _introText(
                  'YakuzaXsilence',
                  fadeInStart: 0.00, fadeInEnd: 0.10,
                  fadeOutStart: 0.34, fadeOutEnd: 0.40,
                  style: TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    color: _GC.accent,
                    letterSpacing: 2,
                    shadows: [
                      Shadow(color: _GC.accent.withOpacity(0.6), blurRadius: 24),
                    ],
                  ),
                ),
                // 2) developer — 1 detik
                _introText(
                  'D E V E L O P E R',
                  fadeInStart: 0.42, fadeInEnd: 0.50,
                  fadeOutStart: 0.56, fadeOutEnd: 0.60,
                  style: TextStyle(
                    fontFamily: 'ShareTechMono',
                    fontSize: 13,
                    color: _GC.muted,
                    letterSpacing: 4,
                  ),
                ),
                // 3) OmhcSilence — 2 detik
                _introText(
                  'OmhcSilence',
                  fadeInStart: 0.62, fadeInEnd: 0.72,
                  fadeOutStart: 1.00, fadeOutEnd: 1.00, // tetap tampil sampai intro selesai
                  style: TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    color: _GC.silver,
                    letterSpacing: 2,
                    shadows: [
                      Shadow(color: _GC.silver.withOpacity(0.5), blurRadius: 24),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ── Progress line di bawah (0 → 100% dalam 5 detik) ──
          Positioned(
            left: 40,
            right: 40,
            bottom: 60,
            child: AnimatedBuilder(
              animation: _introController,
              builder: (context, _) {
                return Column(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(3),
                      child: SizedBox(
                        height: 3,
                        child: Stack(
                          children: [
                            Container(color: _GC.muted2),
                            FractionallySizedBox(
                              widthFactor: _introController.value,
                              child: Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [_GC.accent, _GC.silver],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'GRATISAN BY OMHC',
                      style: TextStyle(
                        fontFamily: 'ShareTechMono',
                        fontSize: 10,
                        color: _GC.muted2,
                        letterSpacing: 3,
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ── Helper teks intro (fade in + slide + fade out sesuai interval) ──
  Widget _introText(
    String text, {
    required double fadeInStart,
    required double fadeInEnd,
    required double fadeOutStart,
    required double fadeOutEnd,
    required TextStyle style,
  }) {
    final fadeIn = CurvedAnimation(
      parent: _introController,
      curve: Interval(fadeInStart, fadeInEnd, curve: Curves.easeOut),
    );
    final fadeOut = CurvedAnimation(
      parent: _introController,
      curve: Interval(fadeOutStart, fadeOutEnd, curve: Curves.easeIn),
    );

    return AnimatedBuilder(
      animation: _introController,
      builder: (context, child) {
        final opacity = fadeIn.value * (1 - fadeOut.value);
        if (opacity <= 0.001) return const SizedBox(height: 44, width: double.infinity);
        return Opacity(
          opacity: opacity,
          child: Transform.translate(
            offset: Offset(0, 18 * (1 - fadeIn.value)),
            child: SizedBox(
              height: 44,
              width: double.infinity,
              child: Center(child: Text(text, style: style, maxLines: 1)),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // CONTENT — halaman utama setelah intro
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _buildContent() {
    return Container(
      key: const ValueKey('content'),
      color: _GC.bg,
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          children: [
            // ── HEADER ──
            Row(
              children: [
                GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: _GC.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _GC.muted2),
                    ),
                    child: Icon(Icons.arrow_back_rounded,
                        color: _GC.text, size: 20),
                  ),
                ),
                const Spacer(),
                // Icon gift header
                AnimatedBuilder(
                  animation: _glowController,
                  builder: (context, _) {
                    final pulse =
                        0.5 + (math.sin(_glowController.value * 2 * math.pi) * 0.5).abs();
                    return Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: _GC.silver.withOpacity(0.10 + pulse * 0.08),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: _GC.silver.withOpacity(0.35 + pulse * 0.3),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: _GC.silver.withOpacity(0.2 + pulse * 0.2),
                            blurRadius: 12 + pulse * 8,
                          ),
                        ],
                      ),
                      child: Icon(Icons.card_giftcard_rounded,
                          color: _GC.silver, size: 22),
                    );
                  },
                ),
              ],
            ),

            const SizedBox(height: 24),

            // ── JUDUL (shimmer silver) ──
            AnimatedBuilder(
              animation: _glowController,
              builder: (context, _) {
                final t = _glowController.value;
                return ShaderMask(
                  shaderCallback: (bounds) {
                    return LinearGradient(
                      begin: Alignment(-1.0 + (t * 2), 0),
                      end: Alignment(0.0 + (t * 2), 0),
                      colors: [
                        _GC.silver,
                        Colors.white,
                        _GC.silver,
                      ],
                      stops: const [0.0, 0.5, 1.0],
                    ).createShader(bounds);
                  },
                  blendMode: BlendMode.srcIn,
                  child: Text(
                    'GRATISAN BY OMHC',
                    style: TextStyle(
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2,
                      color: Colors.white,
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 6),
            Text(
              'Pilih tools gratisan di bawah — langsung terhubung ke Telegram.',
              style: TextStyle(
                fontFamily: 'ShareTechMono',
                fontSize: 11,
                color: _GC.muted,
                letterSpacing: 0.5,
              ),
            ),

            const SizedBox(height: 28),

            // ── LIST BUTTON ──
            ...List.generate(_items.length, (i) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: _buildGratisanTile(_items[i], i),
              );
            }),

            const SizedBox(height: 16),

            // ── FOOTER ──
            Center(
              child: Text(
                'POWERED BY OMHC • YAKUZAXSILENCE',
                style: TextStyle(
                  fontFamily: 'ShareTechMono',
                  fontSize: 9,
                  color: _GC.muted2,
                  letterSpacing: 2,
                ),
              ),
            ),

            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // TILE BUTTON GRATISAN (Telegram blue + glow, tema hitam)
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _buildGratisanTile(Map<String, String> item, int index) {
    // Entrance stagger: tiap tombol muncul bergantian
    final entrance = CurvedAnimation(
      parent: _entranceController,
      curve: Interval(
        (index * 0.22).clamp(0.0, 0.5),
        ((index * 0.22) + 0.78).clamp(0.5, 1.0),
        curve: Curves.easeOutCubic,
      ),
    );

    return AnimatedBuilder(
      animation: _entranceController,
      builder: (context, child) {
        return Opacity(
          opacity: entrance.value,
          child: Transform.translate(
            offset: Offset(0, 24 * (1 - entrance.value)),
            child: child,
          ),
        );
      },
      child: GestureDetector(
        onTap: () => _openLink(item['url']!),
        child: AnimatedBuilder(
          animation: _glowController,
          builder: (context, _) {
            final t = _glowController.value;
            final pulse =
                0.5 + (math.sin(t * 2 * math.pi) * 0.5).abs();
            final borderOpacity = 0.35 + pulse * 0.35;

            return Container(
              height: 84,
              decoration: BoxDecoration(
                color: _GC.card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: _GC.tg2.withOpacity(borderOpacity),
                  width: 1.5,
                ),
                boxShadow: [
                  // Glow biru telegram (berdenyut)
                  BoxShadow(
                    color: _GC.tg2.withOpacity(0.15 + pulse * 0.15),
                    blurRadius: 16 + pulse * 10,
                    spreadRadius: 0 + pulse * 2,
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.4),
                    blurRadius: 10,
                    offset: const Offset(0, 5),
                  ),
                ],
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF1a1a1a), Color(0xFF0a0a0a)],
                ),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Stack(
                  children: [
                    // ── Shimmer sweep ──
                    Positioned.fill(
                      child: AnimatedBuilder(
                        animation: _glowController,
                        builder: (context, _) {
                          return Transform.translate(
                            offset: Offset(-200 + (t * 500), 0),
                            child: Transform.rotate(
                              angle: 0.4,
                              child: Container(
                                width: 60,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      Colors.white.withOpacity(0.0),
                                      Colors.white.withOpacity(0.07),
                                      Colors.white.withOpacity(0.0),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    // ── Color gradient biru ──
                    Positioned.fill(
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                            colors: [
                              _GC.tg2.withOpacity(0.06 + pulse * 0.06),
                              Colors.transparent,
                              _GC.tg2.withOpacity(0.06 + pulse * 0.06),
                            ],
                          ),
                        ),
                      ),
                    ),
                    // ── Content ──
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      child: Row(
                        children: [
                          // Logo Telegram (glow biru)
                          Container(
                            width: 46,
                            height: 46,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(13),
                              gradient: const LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [_GC.tg1, _GC.tg2],
                              ),
                              border: Border.all(
                                color: _GC.tg1
                                    .withOpacity(0.4 + pulse * 0.3),
                                width: 1,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: _GC.tg2
                                      .withOpacity(0.35 + pulse * 0.35),
                                  blurRadius: 10 + pulse * 8,
                                ),
                              ],
                            ),
                            child: const Icon(
                              FontAwesomeIcons.telegram,
                              color: Colors.white,
                              size: 22,
                            ),
                          ),
                          const SizedBox(width: 12),
                          // Text
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                // Judul dengan shimmer
                                ShaderMask(
                                  shaderCallback: (bounds) {
                                    return LinearGradient(
                                      begin: Alignment(-1.0 + (t * 2), 0),
                                      end: Alignment(0.0 + (t * 2), 0),
                                      colors: [
                                        Colors.white,
                                        Colors.white.withOpacity(0.5),
                                        Colors.white,
                                      ],
                                      stops: const [0.0, 0.5, 1.0],
                                    ).createShader(bounds);
                                  },
                                  blendMode: BlendMode.srcIn,
                                  child: Text(
                                    item['title']!,
                                    style: TextStyle(
                                      fontFamily: 'MADEEvolveSansEVO',
                                      fontSize: 13,
                                      fontWeight: FontWeight.w900,
                                      color: Colors.white,
                                      letterSpacing: 1.2,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Row(
                                  children: [
                                    Container(
                                      width: 4,
                                      height: 4,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: _GC.tg1
                                            .withOpacity(0.6 + pulse * 0.4),
                                        boxShadow: [
                                          BoxShadow(
                                            color: _GC.tg1
                                                .withOpacity(0.5 * pulse),
                                            blurRadius: 3,
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 5),
                                    Expanded(
                                      child: Text(
                                        item['desc']!,
                                        style: TextStyle(
                                          fontSize: 9.5,
                                          color: Colors.white.withOpacity(0.55),
                                          fontFamily: 'ShareTechMono',
                                          letterSpacing: 0.3,
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          // Arrow
                          Icon(
                            Icons.arrow_forward_rounded,
                            color: Colors.white.withOpacity(0.85),
                            size: 18,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
