// lib/tiktok_video_page.dart
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'app_theme.dart';

class TiktokPage extends StatefulWidget {
  const TiktokPage({super.key});

  @override
  State<TiktokPage> createState() => _TiktokPageState();
}

class _TiktokPageState extends State<TiktokPage>
    with TickerProviderStateMixin {
  late final WebViewController _controller;
  bool _isLoading = true;
  bool _hasInternet = true;
  bool _showError = false;

  late AnimationController _bounceController;
  late Animation<double> _bounceAnimation;

  final List<String> _loadingTexts = [
    'Menghubungkan ke TikTok...',
    'Mempersiapkan feed video...',
    'Hampir selesai, sabar ya...',
  ];
  int _currentTextIndex = 0;

  @override
  void initState() {
    super.initState();

    _bounceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);

    _bounceAnimation = Tween<double>(begin: 0, end: -15).animate(
      CurvedAnimation(parent: _bounceController, curve: Curves.easeInOut),
    );

    _cycleLoadingText();
    _checkInternet();
  }

  void _cycleLoadingText() {
    Future.delayed(const Duration(seconds: 3), () {
      if (_isLoading && mounted) {
        setState(() {
          _currentTextIndex = (_currentTextIndex + 1) % _loadingTexts.length;
        });
        _cycleLoadingText();
      }
    });
  }

  Future<void> _checkInternet() async {
    final result = await Connectivity().checkConnectivity();
    if (!mounted) return;
    if (result == ConnectivityResult.none) {
      setState(() {
        _hasInternet = false;
        _isLoading = false;
      });
    } else {
      _initWebView();
    }
  }

  void _initWebView() {
    _controller = WebViewController()
      ..setUserAgent(
          'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36')
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onNavigationRequest: (NavigationRequest request) {
            final uri = Uri.parse(request.url);
            if (uri.scheme == 'http' || uri.scheme == 'https') {
              return NavigationDecision.navigate;
            }
            return NavigationDecision.prevent;
          },
          onPageFinished: (_) {
            Future.delayed(const Duration(seconds: 2), () {
              if (mounted) setState(() => _isLoading = false);
            });
          },
          onWebResourceError: (error) {
            Future.delayed(const Duration(seconds: 5), () {
              if (_isLoading && mounted) {
                setState(() {
                  _isLoading = false;
                  _showError = true;
                });
              }
            });
          },
        ),
      )
      ..loadRequest(Uri.parse('https://m.tiktok.com'));
  }

  Future<void> _refresh() async {
    setState(() {
      _isLoading = true;
      _hasInternet = true;
      _showError = false;
      _currentTextIndex = 0;
    });
    _cycleLoadingText();
    await _checkInternet();
  }

  @override
  void dispose() {
    _bounceController.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bg,
              body: Container(
                decoration: BoxDecoration(
                  gradient: isComic
                      ? null
                      : LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [C.bg, C.bgDark, C.bgDeep],
                        ),
                  color: isComic ? C.bg : null,
                ),
                child: SafeArea(
                  child: Stack(
                    children: [
                      if (_hasInternet && !_showError)
                        WebViewWidget(controller: _controller),

                      if (_isLoading)
                        _buildLoadingScreen(C, isComic),

                      if (!_hasInternet || _showError)
                        _buildErrorScreen(C, isComic),

                      if (!_isLoading)
                        Positioned(
                          top: 8,
                          left: 8,
                          child: _buildBackButton(C, isComic),
                        ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // LOADING SCREEN
  // ═══════════════════════════════════════════════════════════
  Widget _buildLoadingScreen(AppPalette C, bool isComic) {
    return Container(
      color: isComic ? C.bg : C.bg.withOpacity(0.95),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedBuilder(
              animation: _bounceAnimation,
              builder: (context, child) {
                return Transform.translate(
                  offset: Offset(0, _bounceAnimation.value),
                  child: child,
                );
              },
              child: Container(
                width: 90,
                height: 90,
                decoration: isComic
                    ? BoxDecoration(
                        color: C.primaryHi,
                        shape: BoxShape.rectangle,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.black, width: 4),
                        boxShadow: const [
                          BoxShadow(
                            color: Colors.black,
                            offset: Offset(5, 5),
                            blurRadius: 0,
                          ),
                        ],
                      )
                    : BoxDecoration(
                        color: C.accent.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                child: Icon(
                  Icons.music_note_rounded,
                  size: 50,
                  color: isComic ? C.contrastTextOn(C.primaryHi) : C.accent,
                ),
              ),
            ),
            const SizedBox(height: 30),
            Text(
              'TIKTOK',
              style: TextStyle(
                color: isComic ? C.comicText : C.text,
                fontSize: isComic ? 28 : 24,
                fontWeight: FontWeight.w900,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: isComic ? 3 : 4,
                shadows: isComic
                    ? [
                        Shadow(
                          color: C.comicTextOutline,
                          offset: const Offset(2, 2),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
            ),
            const SizedBox(height: 15),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 500),
              child: Text(
                _loadingTexts[_currentTextIndex],
                key: ValueKey(_currentTextIndex),
                style: TextStyle(
                  color: isComic ? C.comicTextSub : C.textSub,
                  fontSize: 13,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                ),
              ),
            ),
            const SizedBox(height: 40),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(3, (index) {
                return _BouncingDot(delay: index * 200, color: C.accent);
              }),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // ERROR SCREEN
  // ═══════════════════════════════════════════════════════════
  Widget _buildErrorScreen(AppPalette C, bool isComic) {
    return Container(
      color: isComic ? C.bg : C.bg.withOpacity(0.95),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 90,
                height: 90,
                decoration: isComic
                    ? BoxDecoration(
                        color: C.primaryHi,
                        shape: BoxShape.rectangle,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.black, width: 4),
                        boxShadow: const [
                          BoxShadow(
                            color: Colors.black,
                            offset: Offset(5, 5),
                            blurRadius: 0,
                          ),
                        ],
                      )
                    : BoxDecoration(
                        color: C.textSub.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                child: Icon(
                  Icons.wifi_off_rounded,
                  size: 44,
                  color: isComic
                      ? C.contrastTextOn(C.primaryHi)
                      : C.textSub,
                ),
              ),
              const SizedBox(height: 24),
              Text(
                'Koneksi Terputus',
                style: TextStyle(
                  color: isComic ? C.comicText : C.text,
                  fontSize: isComic ? 22 : 20,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: isComic ? 1.5 : 1,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'TikTok tidak bisa dimuat. Coba klik tombol di bawah untuk menyegarkan halaman.',
                style: TextStyle(
                  color: isComic ? C.comicTextSub : C.textSub,
                  fontSize: 13,
                  height: 1.5,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 35),
              GestureDetector(
                onTap: _refresh,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 36, vertical: 16),
                  decoration: BoxDecoration(
                    color: isComic ? C.primaryHi : null,
                    gradient: isComic
                        ? null
                        : LinearGradient(
                            colors: [C.primaryHi, C.primaryLo],
                          ),
                    borderRadius: BorderRadius.circular(isComic ? 12 : 14),
                    border: Border.all(
                      color: isComic ? Colors.black : C.primaryHi,
                      width: isComic ? 3.5 : 1.5,
                    ),
                    boxShadow: isComic
                        ? const [
                            BoxShadow(
                              color: Colors.black,
                              offset: Offset(4, 4),
                              blurRadius: 0,
                            ),
                          ]
                        : [
                            BoxShadow(
                              color: C.primaryHi.withOpacity(0.4),
                              blurRadius: 15,
                            ),
                          ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.refresh_rounded,
                        size: 20,
                        color: isComic
                            ? C.contrastTextOn(C.primaryHi)
                            : Colors.white,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Coba Lagi',
                        style: TextStyle(
                          color: isComic
                              ? C.contrastTextOn(C.primaryHi)
                              : Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 15,
                          fontFamily: isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: isComic ? 1 : 1.2,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BACK BUTTON
  // ═══════════════════════════════════════════════════════════
  Widget _buildBackButton(AppPalette C, bool isComic) {
    return GestureDetector(
      onTap: () async {
        if (await _controller.canGoBack()) {
          _controller.goBack();
        } else {
          if (!mounted) return;
          Navigator.pop(context);
        }
      },
      child: Container(
        width: 44,
        height: 44,
        decoration: isComic
            ? BoxDecoration(
                color: C.primaryHi,
                shape: BoxShape.rectangle,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.black, width: 3.5),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(3, 3),
                    blurRadius: 0,
                  ),
                ],
              )
            : BoxDecoration(
                color: C.bgDark.withOpacity(0.85),
                shape: BoxShape.circle,
                border: Border.all(
                  color: C.accent.withOpacity(0.6),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.5),
                    blurRadius: 8,
                  ),
                ],
              ),
        child: Icon(
          Icons.arrow_back_ios_new,
          color: isComic ? C.contrastTextOn(C.primaryHi) : C.accent,
          size: 20,
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// BOUNCING DOT
// ═══════════════════════════════════════════════════════════
class _BouncingDot extends StatefulWidget {
  final int delay;
  final Color color;
  const _BouncingDot({required this.delay, required this.color});

  @override
  State<_BouncingDot> createState() => _BouncingDotState();
}

class _BouncingDotState extends State<_BouncingDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    _animation = Tween<double>(begin: 0, end: -8).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    Future.delayed(Duration(milliseconds: widget.delay), () {
      if (mounted) _controller.repeat(reverse: true);
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, child) {
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 4),
          child: Transform.translate(
            offset: Offset(0, _animation.value),
            child: child,
          ),
        );
      },
      child: Container(
        width: 8,
        height: 8,
        decoration: BoxDecoration(
          color: widget.color,
          shape: BoxShape.circle,
        ),
      ),
    );
  }
}