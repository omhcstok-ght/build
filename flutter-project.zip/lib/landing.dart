// lib/landing.dart
import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'app_theme.dart';
import 'login_page.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  late AnimationController _entryController;
  late Animation<double> _fadeAnimation;
  late AnimationController _loopController;
  late Animation<double> _floatingAnimation;

  String _typedText = "";
  final String _fullText = "SYAX NEW ERA"; // Bisa diganti jadi SYAX CRASHER
  Timer? _typingTimer;
  bool _isCursorVisible = true;
  Timer? _cursorTimer;

  @override
  void initState() {
    super.initState();

    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    );

    _fadeAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _entryController, curve: Curves.easeOut),
    );

    _loopController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);

    _floatingAnimation = Tween<double>(begin: -10.0, end: 10.0).animate(
      CurvedAnimation(parent: _loopController, curve: Curves.easeInOut),
    );

    _entryController.forward();

    _startTypewriter();
    _startCursorBlink();
  }

  void _startTypewriter() {
    _typedText = "";
    int charIndex = 0;
    _typingTimer = Timer.periodic(const Duration(milliseconds: 150), (timer) {
      if (charIndex < _fullText.length) {
        setState(() {
          _typedText += _fullText[charIndex];
        });
        charIndex++;
      } else {
        timer.cancel();
      }
    });
  }

  void _startCursorBlink() {
    _cursorTimer = Timer.periodic(const Duration(milliseconds: 500), (timer) {
      if (mounted) {
        setState(() {
          _isCursorVisible = !_isCursorVisible;
        });
      }
    });
  }

  @override
  void dispose() {
    _typingTimer?.cancel();
    _cursorTimer?.cancel();
    _entryController.dispose();
    _loopController.dispose();
    super.dispose();
  }

  Animation<double> _stagger(double start, double end) {
    return Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _entryController,
        curve: Interval(start, end, curve: Curves.easeOutCubic),
      ),
    );
  }

  Widget _fadeSlide({
    required Animation<double> anim,
    double offsetY = 22,
    required Widget child,
  }) {
    return AnimatedBuilder(
      animation: anim,
      builder: (_, __) => Opacity(
        opacity: anim.value,
        child: Transform.translate(
          offset: Offset(0, offsetY * (1.0 - anim.value)),
          child: child,
        ),
      ),
    );
  }

  Widget _buildLongButton({
    required AppPalette C,
    required bool isComic,
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    final textColor = isComic ? C.comicText : C.text;
    final accentColor = isComic ? C.primaryHi : C.accent;

    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 18),
        decoration: BoxDecoration(
          color: isComic ? C.bgDark : Colors.transparent,
          border: isComic
              ? Border.all(color: Colors.black, width: 4)
              : Border(
                  top: BorderSide(color: C.textSub.withOpacity(0.2), width: 1),
                  bottom: BorderSide(color: C.textSub.withOpacity(0.2), width: 1),
                ),
        ),
        child: Row(
          children: [
            Container(
              width: 3,
              height: 26,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [C.primary, C.accent, C.primaryHi],
                ),
              ),
            ),
            const SizedBox(width: 14),
            Icon(icon, color: textColor, size: 21),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                label,
                style: TextStyle(
                  color: textColor,
                  fontSize: isComic ? 16 : 14,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: isComic ? 2 : 1.5,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
            ),
            Row(
              children: [
                Container(width: 6, height: 2, color: C.primary),
                const SizedBox(width: 2),
                Container(width: 6, height: 2, color: C.accent),
                const SizedBox(width: 2),
                Container(width: 6, height: 2, color: C.primaryHi),
                const SizedBox(width: 8),
                Icon(Icons.arrow_forward_ios_rounded, color: accentColor, size: 13),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHalfButton({
    required AppPalette C,
    required bool isComic,
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    final textColor = isComic ? C.comicText : C.text;
    final accentColor = isComic ? C.primaryHi : C.accent;

    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 16),
          decoration: BoxDecoration(
            color: isComic ? C.bgDark : Colors.transparent,
            border: isComic
                ? Border.all(color: Colors.black, width: 3)
                : Border(
                    bottom: BorderSide(
                        color: C.textSub.withOpacity(0.3), width: 2),
                  ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              FaIcon(icon, color: accentColor, size: 17),
              const SizedBox(width: 9),
              Flexible(
                child: Text(
                  label,
                  style: TextStyle(
                    color: textColor,
                    fontSize: isComic ? 13 : 11,
                    fontWeight: FontWeight.w700,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: isComic ? 1 : 0.5,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bgDeep,
              body: Stack(
                children: [
                  // Background
                  Positioned.fill(
                    child: isComic
                        ? CustomPaint(
                            painter: _ComicBgPainter(
                                color: C.primaryLo.withOpacity(0.12)),
                          )
                        : Container(
                            decoration: BoxDecoration(
                              gradient: RadialGradient(
                                center: const Alignment(-0.4, -0.4),
                                radius: 1.5,
                                colors: [C.bg, C.bgDark, C.bgDeep],
                                stops: const [0.0, 0.6, 1.0],
                              ),
                            ),
                          ),
                  ),

                  // Splatter Overlay
                  Positioned.fill(
                    child: IgnorePointer(
                      child: CustomPaint(
                        painter: _MSplatterPainter(
                          C: C,
                          isComic: isComic,
                          seed: 121,
                          density: 1.1,
                          maxOpacity: isComic ? 0.08 : 0.14,
                        ),
                      ),
                    ),
                  ),

                  SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Banner Image
                        _fadeSlide(
                          anim: _stagger(0.0, 0.22),
                          offsetY: 0,
                          child: SizedBox(
                            width: double.infinity,
                            height: 260,
                            child: Stack(
                              fit: StackFit.expand,
                              children: [
                                Image.asset("assets/images/banner.jpg",
                                    fit: BoxFit.cover),
                                Container(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      begin: Alignment.topCenter,
                                      end: Alignment.bottomCenter,
                                      colors: [
                                        Colors.black.withOpacity(0.45),
                                        Colors.black.withOpacity(0.15),
                                        C.bgDeep.withOpacity(0.90),
                                        C.bgDeep,
                                      ],
                                      stops: const [0.0, 0.35, 0.82, 1.0],
                                    ),
                                  ),
                                ),
                                Positioned(
                                  top: 0,
                                  right: 0,
                                  child: IgnorePointer(
                                    child: Opacity(
                                      opacity: 0.55,
                                      child: Row(
                                        children: [
                                          Container(
                                              width: 8,
                                              height: 62,
                                              color: C.primary),
                                          Container(
                                              width: 8,
                                              height: 62,
                                              color: C.accent),
                                          Container(
                                              width: 8,
                                              height: 62,
                                              color: C.primaryHi),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  top: 24,
                                  left: 23,
                                  child: Row(
                                    children: [
                                      Row(
                                        children: [
                                          Container(
                                              width: 10,
                                              height: 3,
                                              color: C.primary),
                                          const SizedBox(width: 2),
                                          Container(
                                              width: 10,
                                              height: 3,
                                              color: C.accent),
                                          const SizedBox(width: 2),
                                          Container(
                                              width: 10,
                                              height: 3,
                                              color: C.primaryHi),
                                        ],
                                      ),
                                      const SizedBox(width: 10),
                                      Text(
                                        "SYAX SYSTEM  /  2026",
                                        style: TextStyle(
                                          color: C.text,
                                          fontSize: 9,
                                          fontWeight: FontWeight.w600,
                                          letterSpacing: 2,
                                          fontFamily: isComic
                                              ? 'ComicNeue'
                                              : 'ShareTechMono',
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Positioned(
                                  bottom: 23,
                                  left: 23,
                                  right: 23,
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.end,
                                    children: [
                                      SizedBox(
                                        width: 4,
                                        height: 45,
                                        child: Column(
                                          children: [
                                            Expanded(
                                                child: Container(
                                                    color: C.primary)),
                                            const SizedBox(height: 2),
                                            Expanded(
                                                child:
                                                    Container(color: C.accent)),
                                            const SizedBox(height: 2),
                                            Expanded(
                                                child: Container(
                                                    color: C.primaryHi)),
                                          ],
                                        ),
                                      ),
                                      const SizedBox(width: 13),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "ENGINEERED FOR PERFORMANCE",
                                              style: TextStyle(
                                                color: C.text.withOpacity(0.7),
                                                fontSize: 8,
                                                letterSpacing: 2,
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                            const SizedBox(height: 6),
                                            Text(
                                              "SYAX NEW ERA",
                                              style: TextStyle(
                                                color: C.text,
                                                fontSize: isComic ? 22 : 19,
                                                fontWeight: FontWeight.w900,
                                                letterSpacing: 2.5,
                                                fontFamily: isComic
                                                    ? 'Bangers'
                                                    : 'Orbitron',
                                                shadows: isComic
                                                    ? [
                                                        Shadow(
                                                          color: C
                                                              .comicTextOutline,
                                                          offset:
                                                              const Offset(1, 1),
                                                          blurRadius: 0,
                                                        ),
                                                      ]
                                                    : null,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Text(
                                        "01 / 26",
                                        style: TextStyle(
                                          color: C.text.withOpacity(0.6),
                                          fontSize: 9,
                                          letterSpacing: 1,
                                          fontFamily: isComic
                                              ? 'ComicNeue'
                                              : 'ShareTechMono',
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 24),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(height: 12),

                              // Typewriter Text
                              _fadeSlide(
                                anim: _stagger(0.10, 0.32),
                                child: Row(
                                  children: [
                                    Text(
                                      _typedText,
                                      style: TextStyle(
                                        fontSize: isComic ? 36 : 32,
                                        fontWeight: FontWeight.w900,
                                        fontFamily: isComic
                                            ? 'Bangers'
                                            : 'Orbitron',
                                        letterSpacing: isComic ? 2 : 1.5,
                                        color: isComic
                                            ? C.comicText
                                            : C.text,
                                        shadows: isComic
                                            ? [
                                                Shadow(
                                                  color: C.comicTextOutline,
                                                  offset:
                                                      const Offset(2, 2),
                                                  blurRadius: 0,
                                                ),
                                              ]
                                            : null,
                                      ),
                                    ),
                                    AnimatedOpacity(
                                      opacity:
                                          _isCursorVisible ? 1.0 : 0.0,
                                      duration: const Duration(
                                          milliseconds: 100),
                                      child: Container(
                                        width: 3,
                                        height: isComic ? 36 : 32,
                                        margin:
                                            const EdgeInsets.only(left: 4),
                                        color: isComic
                                            ? C.primaryHi
                                            : C.accent,
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              const SizedBox(height: 8),

                              // Tri-color Line
                              _fadeSlide(
                                anim: _stagger(0.12, 0.34),
                                child: Row(
                                  children: [
                                    Container(
                                        width: 20,
                                        height: 3,
                                        color: C.primary),
                                    const SizedBox(width: 2),
                                    Container(
                                        width: 20,
                                        height: 3,
                                        color: C.accent),
                                    const SizedBox(width: 2),
                                    Container(
                                        width: 20,
                                        height: 3,
                                        color: C.primaryHi),
                                  ],
                                ),
                              ),

                              const SizedBox(height: 12),

                              _fadeSlide(
                                anim: _stagger(0.16, 0.38),
                                child: Text(
                                  "Aplikasi Yang Dikembangkan SYAX Team",
                                  style: TextStyle(
                                    color: isComic
                                        ? C.comicTextSub
                                        : C.textSub,
                                    fontSize: isComic ? 13 : 11,
                                    fontFamily: isComic
                                        ? 'ComicNeue'
                                        : 'Orbitron',
                                    letterSpacing: isComic ? 1 : 0.4,
                                    height: 1.7,
                                  ),
                                ),
                              ),

                              const SizedBox(height: 24),

                              // Tentang SYAX
                              _fadeSlide(
                                anim: _stagger(0.22, 0.44),
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Container(
                                            width: 3,
                                            height: 16,
                                            color: C.primary),
                                        const SizedBox(width: 10),
                                        Icon(Icons.info_outline_rounded,
                                            color: isComic
                                                ? C.comicText
                                                : C.text,
                                            size: 17),
                                        const SizedBox(width: 8),
                                        Text(
                                          "TENTANG SYAX",
                                          style: TextStyle(
                                            color: isComic
                                                ? C.comicText
                                                : C.text,
                                            fontSize: isComic ? 15 : 12,
                                            fontWeight: FontWeight.w800,
                                            fontFamily: isComic
                                                ? 'Bangers'
                                                : 'Orbitron',
                                            letterSpacing: isComic ? 2 : 1.5,
                                            shadows: isComic
                                                ? [
                                                    Shadow(
                                                      color: C
                                                          .comicTextOutline,
                                                      offset:
                                                          const Offset(1, 1),
                                                      blurRadius: 0,
                                                    ),
                                                  ]
                                                : null,
                                          ),
                                        ),
                                        const Spacer(),
                                        Text(
                                          "01",
                                          style: TextStyle(
                                            color: C.text.withOpacity(0.35),
                                            fontSize: 11,
                                            fontFamily: isComic
                                                ? 'ComicNeue'
                                                : 'ShareTechMono',
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 14),
                                    Container(
                                      height: isComic ? 3 : 0.7,
                                      decoration: isComic
                                          ? null
                                          : BoxDecoration(
                                              gradient: LinearGradient(
                                                colors: [
                                                  C.primary.withOpacity(0.0),
                                                  C.primary.withOpacity(0.4),
                                                  C.primaryHi
                                                      .withOpacity(0.4),
                                                  C.primaryHi.withOpacity(0.0),
                                                ],
                                              ),
                                            ),
                                      color: isComic ? Colors.black : null,
                                    ),
                                    const SizedBox(height: 15),
                                    Text(
                                      "SYAX adalah platform tools canggih yang dirancang untuk memberikan performa terbaik. Dikembangkan secara profesional oleh tim SYAX dengan teknologi mutakhir dan sistem keamanan tinggi.",
                                      style: TextStyle(
                                        color: isComic
                                            ? C.comicTextSub
                                            : C.textSub,
                                        fontSize: isComic ? 13 : 11,
                                        fontFamily: isComic
                                            ? 'ComicNeue'
                                            : 'Orbitron',
                                        height: 1.9,
                                      ),
                                    ),
                                    const SizedBox(height: 17),
                                    Row(
                                      children: [
                                        Icon(Icons.bolt,
                                            color: isComic
                                                ? C.comicText
                                                : C.text,
                                            size: 15),
                                        const SizedBox(width: 8),
                                        Text(
                                          "PRECISION",
                                          style: TextStyle(
                                            color: isComic
                                                ? C.comicText
                                                : C.text.withOpacity(0.7),
                                            fontSize: isComic ? 11 : 9,
                                            letterSpacing: 1.5,
                                            fontWeight: FontWeight.w600,
                                            fontFamily: isComic
                                                ? 'ComicNeue'
                                                : 'ShareTechMono',
                                          ),
                                        ),
                                        const SizedBox(width: 18),
                                        Icon(Icons.shield_outlined,
                                            color: isComic
                                                ? C.comicText
                                                : C.text,
                                            size: 15),
                                        const SizedBox(width: 8),
                                        Text(
                                          "SECURITY",
                                          style: TextStyle(
                                            color: isComic
                                                ? C.comicText
                                                : C.text.withOpacity(0.7),
                                            fontSize: isComic ? 11 : 9,
                                            letterSpacing: 1.5,
                                            fontWeight: FontWeight.w600,
                                            fontFamily: isComic
                                                ? 'ComicNeue'
                                                : 'ShareTechMono',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),

                              const SizedBox(height: 30),

                              // SIGN IN Button
                              _fadeSlide(
                                anim: _stagger(0.28, 0.50),
                                child: _buildLongButton(
                                  C: C,
                                  isComic: isComic,
                                  icon: Icons.login_rounded,
                                  label: "SIGN  IN  TO  SYAX",
                                  onTap: () => Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (_) => const LoginPage()),
                                  ),
                                ),
                              ),

                              const SizedBox(height: 27),

                              // Connect With Us
                              _fadeSlide(
                                anim: _stagger(0.34, 0.56),
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "C O N N E C T   W I T H   U S",
                                      style: TextStyle(
                                        color: isComic
                                            ? C.comicTextSub
                                            : C.text.withOpacity(0.54),
                                        fontSize: isComic ? 11 : 9,
                                        fontWeight: FontWeight.w600,
                                        fontFamily: isComic
                                            ? 'ComicNeue'
                                            : 'Orbitron',
                                        letterSpacing: 2,
                                      ),
                                    ),
                                    const SizedBox(height: 12),
                                    Row(
                                      children: [
                                        _buildHalfButton(
                                          C: C,
                                          isComic: isComic,
                                          icon: FontAwesomeIcons.telegram,
                                          label: "Developer",
                                          onTap: () async {
                                            final uri = Uri.parse(
                                                "https://t.me/KaizennTzyy");
                                            if (await canLaunchUrl(uri)) {
                                              launchUrl(uri,
                                                  mode: LaunchMode
                                                      .externalApplication);
                                            }
                                          },
                                        ),
                                        const SizedBox(width: 22),
                                        _buildHalfButton(
                                          C: C,
                                          isComic: isComic,
                                          icon: FontAwesomeIcons.telegram,
                                          label: "Owner",
                                          onTap: () async {
                                            final uri = Uri.parse(
                                                "https://t.me/KaizennTzyy");
                                            if (await canLaunchUrl(uri)) {
                                              launchUrl(uri,
                                                  mode: LaunchMode
                                                      .externalApplication);
                                            }
                                          },
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),

                              const SizedBox(height: 36),

                              // Footer
                              _fadeSlide(
                                anim: _stagger(0.42, 0.64),
                                child: Column(
                                  children: [
                                    Container(
                                      height: isComic ? 3 : 0.7,
                                      decoration: isComic
                                          ? null
                                          : BoxDecoration(
                                              gradient: LinearGradient(
                                                colors: [
                                                  C.primary.withOpacity(0.0),
                                                  C.primary.withOpacity(0.4),
                                                  C.primaryHi
                                                      .withOpacity(0.4),
                                                  C.primaryHi.withOpacity(0.0),
                                                ],
                                              ),
                                            ),
                                      color: isComic ? Colors.black : null,
                                    ),
                                    const SizedBox(height: 23),
                                    Text(
                                      "SYAX",
                                      style: TextStyle(
                                        color: isComic ? C.comicText : C.text,
                                        fontSize: isComic ? 26 : 22,
                                        fontWeight: FontWeight.w900,
                                        fontFamily: isComic
                                            ? 'Bangers'
                                            : 'Orbitron',
                                        letterSpacing: 5,
                                        shadows: isComic
                                            ? [
                                                Shadow(
                                                  color: C.comicTextOutline,
                                                  offset:
                                                      const Offset(2, 2),
                                                  blurRadius: 0,
                                                ),
                                              ]
                                            : null,
                                      ),
                                    ),
                                    const SizedBox(height: 12),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Container(
                                            width: 30,
                                            height: 3,
                                            color: C.primary),
                                        const SizedBox(width: 2),
                                        Container(
                                            width: 30,
                                            height: 3,
                                            color: C.accent),
                                        const SizedBox(width: 2),
                                        Container(
                                            width: 30,
                                            height: 3,
                                            color: C.primaryHi),
                                      ],
                                    ),
                                    const SizedBox(height: 12),
                                    Text(
                                      "BY : LEXZY",
                                      style: TextStyle(
                                        color: isComic
                                            ? C.comicText
                                            : C.text.withOpacity(0.7),
                                        fontSize: isComic ? 12 : 10,
                                        fontWeight: FontWeight.w800,
                                        fontFamily: isComic
                                            ? 'Bangers'
                                            : 'Orbitron',
                                        letterSpacing: 2,
                                      ),
                                    ),
                                    const SizedBox(height: 10),
                                    Text(
                                      "© 2026 SYAX Team — All Rights Reserved",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: isComic
                                            ? C.comicTextMuted
                                            : C.text.withOpacity(0.38),
                                        fontSize: isComic ? 10 : 9,
                                        fontFamily: isComic
                                            ? 'ComicNeue'
                                            : 'Orbitron',
                                        letterSpacing: 0.5,
                                      ),
                                    ),
                                    const SizedBox(height: 12),
                                    Text(
                                      "M  MOTORSPORT  /  LIGHTBLUE  •  DARKBLUE  •  RED",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: isComic
                                            ? C.comicTextMuted
                                            : C.text.withOpacity(0.24),
                                        fontSize: isComic ? 9 : 8,
                                        fontFamily: isComic
                                            ? 'ComicNeue'
                                            : 'ShareTechMono',
                                        letterSpacing: 2,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 36),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SPLATTER PAINTER (THEME AWARE)
// ═══════════════════════════════════════════════════════════
class _MSplatterPainter extends CustomPainter {
  final AppPalette C;
  final bool isComic;
  final int seed;
  final double density;
  final double maxOpacity;

  const _MSplatterPainter({
    required this.C,
    required this.isComic,
    this.seed = 7,
    this.density = 1.0,
    this.maxOpacity = 0.20,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final rnd = math.Random(seed);
    final colors = <Color>[
      C.primary,
      C.accent,
      C.primaryHi,
      isComic ? Colors.black : Colors.white,
    ];
    final count = (55 * density).toInt();

    for (int i = 0; i < count; i++) {
      final color = colors[rnd.nextInt(colors.length)];
      final opacity = 0.04 + rnd.nextDouble() * maxOpacity;
      final cx = rnd.nextDouble() * size.width;
      final cy = rnd.nextDouble() * size.height;

      final paint = Paint()
        ..color = color.withOpacity(opacity)
        ..style = PaintingStyle.fill;

      final r = 1.5 + rnd.nextDouble() * 5.0;
      canvas.drawCircle(Offset(cx, cy), r, paint);

      final drops = 3 + rnd.nextInt(5);
      for (int j = 0; j < drops; j++) {
        final angle = rnd.nextDouble() * math.pi * 2;
        final dist = r + rnd.nextDouble() * (r * 3.2);
        final dx = cx + math.cos(angle) * dist;
        final dy = cy + math.sin(angle) * dist;
        final dr = 0.4 + rnd.nextDouble() * (r * 0.5);
        canvas.drawCircle(Offset(dx, dy), dr, paint);
      }

      if (rnd.nextDouble() < 0.2) {
        final dripLen = r * (2 + rnd.nextDouble() * 2.5);
        final dripPaint = Paint()
          ..color = color.withOpacity(opacity * 0.65)
          ..strokeWidth = r * 0.5
          ..strokeCap = StrokeCap.round;
        canvas.drawLine(
          Offset(cx, cy + r),
          Offset(cx, cy + r + dripLen),
          dripPaint,
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant _MSplatterPainter old) =>
      old.seed != seed ||
      old.density != density ||
      old.maxOpacity != maxOpacity ||
      old.C != C ||
      old.isComic != isComic;
}

// ═══════════════════════════════════════════════════════════
// COMIC BG PAINTER
// ═══════════════════════════════════════════════════════════
class _ComicBgPainter extends CustomPainter {
  final Color color;
  const _ComicBgPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 22.0;
    final paint = Paint()..color = color;
    for (double x = 0; x < size.width + spacing; x += spacing) {
      for (double y = 0; y < size.height + spacing; y += spacing) {
        canvas.drawCircle(Offset(x, y), 2.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_ComicBgPainter old) => old.color != color;
}