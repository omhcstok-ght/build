// market_api.dart — API Helper buat Pasar Online
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class MarketApi {
  static const String baseUrl = 'http://panelku.fincloud.my.id:2772';

  /// Ambil semua produk
  static Future<List<MarketProduct>> getProducts({
    required String sessionKey,
    String? kategori,
    String? search,
  }) async {
    try {
      final params = <String, String>{'key': sessionKey};
      if (kategori != null && kategori.isNotEmpty && kategori != 'Semua') {
        params['kategori'] = kategori;
      }
      if (search != null && search.isNotEmpty) {
        params['q'] = search;
      }

      final uri = Uri.parse('$baseUrl/market/products')
          .replace(queryParameters: params);

      final res = await http.get(uri).timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['products'] != null) {
          return (data['products'] as List)
              .map((e) => MarketProduct.fromJson(e))
              .toList();
        }
      }
      return [];
    } catch (e) {
      print('[MARKET API] getProducts error: $e');
      return [];
    }
  }

  /// Ambil detail 1 produk
  static Future<MarketProduct?> getProductDetail({
    required String sessionKey,
    required String productId,
  }) async {
    try {
      final uri = Uri.parse('$baseUrl/market/products/$productId')
          .replace(queryParameters: {'key': sessionKey});

      final res = await http.get(uri).timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['product'] != null) {
          return MarketProduct.fromJson(data['product']);
        }
      }
      return null;
    } catch (e) {
      print('[MARKET API] getProductDetail error: $e');
      return null;
    }
  }

  /// Tambah produk baru
  static Future<Map<String, dynamic>> addProduct({
    required String sessionKey,
    required String nama,
    required int harga,
    required String deskripsi,
    required String kategori,
    required String wa,
    required String telegram,
    required File foto,
  }) async {
    try {
      final uri = Uri.parse('$baseUrl/market/products');
      final request = http.MultipartRequest('POST', uri);

      request.fields['sessionKey'] = sessionKey;
      request.fields['nama'] = nama;
      request.fields['harga'] = harga.toString();
      request.fields['deskripsi'] = deskripsi;
      request.fields['kategori'] = kategori;
      request.fields['wa'] = wa;
      request.fields['telegram'] = telegram;

      request.files
          .add(await http.MultipartFile.fromPath('foto', foto.path));

      final streamedRes =
          await request.send().timeout(const Duration(seconds: 30));
      final res = await http.Response.fromStream(streamedRes);
      final data = jsonDecode(res.body);

      return data;
    } catch (e) {
      print('[MARKET API] addProduct error: $e');
      return {'valid': false, 'message': 'Error: $e'};
    }
  }

  /// Hapus produk
  static Future<Map<String, dynamic>> deleteProduct({
    required String sessionKey,
    required String productId,
  }) async {
    try {
      final uri = Uri.parse('$baseUrl/market/products/$productId')
          .replace(queryParameters: {'key': sessionKey});

      final res = await http
          .delete(uri)
          .timeout(const Duration(seconds: 15));
      return jsonDecode(res.body);
    } catch (e) {
      return {'valid': false, 'message': 'Error: $e'};
    }
  }

  /// Ambil produk sendiri
  static Future<List<MarketProduct>> getMyProducts({
    required String sessionKey,
  }) async {
    try {
      final uri = Uri.parse('$baseUrl/market/my-products')
          .replace(queryParameters: {'key': sessionKey});

      final res = await http.get(uri).timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['products'] != null) {
          return (data['products'] as List)
              .map((e) => MarketProduct.fromJson(e))
              .toList();
        }
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  /// Get full URL foto
  static String getFotoUrl(String fotoUrl) {
    if (fotoUrl.isEmpty) return '';
    if (fotoUrl.startsWith('http')) return fotoUrl;
    return '$baseUrl$fotoUrl';
  }
}

// ─── MODEL: Produk ───────────────────────────────────────
class MarketProduct {
  final String id;
  final String nama;
  final int harga;
  final String deskripsi;
  final String kategori;
  final String penjual;
  final String wa;
  final String telegram;
  final String foto;
  final String fotoUrl;
  final String createdAt;
  final bool isMine;

  MarketProduct({
    required this.id,
    required this.nama,
    required this.harga,
    required this.deskripsi,
    required this.kategori,
    required this.penjual,
    required this.wa,
    required this.telegram,
    required this.foto,
    required this.fotoUrl,
    required this.createdAt,
    required this.isMine,
  });

  factory MarketProduct.fromJson(Map<String, dynamic> json) {
    return MarketProduct(
      id: json['id'] ?? '',
      nama: json['nama'] ?? '',
      harga: json['harga'] ?? 0,
      deskripsi: json['deskripsi'] ?? '',
      kategori: json['kategori'] ?? 'Lainnya',
      penjual: json['penjual'] ?? '',
      wa: json['wa'] ?? '',
      telegram: json['telegram'] ?? '',
      foto: json['foto'] ?? '',
      fotoUrl: json['fotoUrl'] ?? '',
      createdAt: json['createdAt'] ?? '',
      isMine: json['isMine'] ?? false,
    );
  }

  /// Format harga jadi Rp X.XXX
  String get hargaFormatted {
    final str = harga.toString();
    final buffer = StringBuffer();
    for (int i = 0; i < str.length; i++) {
      if (i > 0 && (str.length - i) % 3 == 0) buffer.write('.');
      buffer.write(str[i]);
    }
    return 'Rp $buffer';
  }
}