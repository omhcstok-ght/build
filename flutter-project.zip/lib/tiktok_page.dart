// lib/tiktok_page.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'api_config.dart';
import 'app_theme.dart';

// ═══════════════════════════════════════════════════════
// GLOBAL PULSE
// ═══════════════════════════════════════════════════════
class _Pulse {
  static final ValueNotifier<double> v = ValueNotifier<double>(0);
  static bool _started = false;
  static void ensureStarted() {
    if (_started) return;
    _started = true;
    _run();
  }

  static Future<void> _run() async {
    final sw = Stopwatch()..start();
    while (true) {
      await Future<void>.delayed(const Duration(milliseconds: 80));
      final t = (sw.elapsedMilliseconds % 1600) / 1600.0;
      v.value = t < 0.5 ? t * 2 : (1 - t) * 2;
    }
  }
}

// ═══════════════════════════════════════════════════════
// LED
// ═══════════════════════════════════════════════════════
class _Led extends StatelessWidget {
  final Color color;
  final double size;
  final bool blink;
  const _Led({required this.color, this.size = 8, this.blink = false});

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          border: Border.all(color: Colors.black, width: size * 0.18),
        ),
      );
    }
    if (!blink) return _dot(1.0);
    return ValueListenableBuilder<double>(
      valueListenable: _Pulse.v,
      builder: (_, v, __) => _dot(0.45 + v * 0.55),
    );
  }

  Widget _dot(double opacity) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            center: const Alignment(-0.35, -0.35),
            colors: [
              Colors.white.withOpacity(0.85 * opacity),
              color.withOpacity(opacity),
              color.withOpacity(0.55 * opacity),
            ],
            stops: const [0.0, 0.4, 1.0],
          ),
          border: Border.all(
              color: Colors.black.withOpacity(0.85), width: size * 0.1),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.75 * opacity),
              blurRadius: size * 1.4,
              spreadRadius: size * 0.2,
            ),
            BoxShadow(
              color: color.withOpacity(0.35 * opacity),
              blurRadius: size * 2.6,
              spreadRadius: size * 0.4,
            ),
          ],
        ),
      );
}

// ═══════════════════════════════════════════════════════
// SCREW
// ═══════════════════════════════════════════════════════
class _Screw extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Screw({required this.C, this.size = 14});

  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.text, C.textSub, C.bg, C.bgDark],
          stops: const [0.0, 0.35, 0.7, 1.0],
        ),
      ),
      child: Center(
        child: Transform.rotate(
          angle: 0.785,
          child: Container(
            width: size * 0.7,
            height: size * 0.11,
            color: Colors.black.withOpacity(0.9),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════
// RIVET
// ═══════════════════════════════════════════════════════
class _Rivet extends StatelessWidget {
  final AppPalette C;
  final double size;
  const _Rivet({required this.C, this.size = 10});

  @override
  Widget build(BuildContext context) {
    if (AppTheme.currentStyle.value == ThemeStyle.comic3d) {
      return const SizedBox.shrink();
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.35, -0.35),
          colors: [C.accentShine, C.accentHi, C.accent, C.primaryLo],
          stops: const [0.0, 0.3, 0.65, 1.0],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════
// METAL PLATE
// ═══════════════════════════════════════════════════════
class _MetalPlate extends StatelessWidget {
  final AppPalette C;
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  const _MetalPlate({
    required this.C,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
                color: Colors.black, offset: Offset(5, 5), blurRadius: 0),
          ],
        ),
        child: child,
      );
    }
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.75),
            offset: const Offset(0, 6),
            blurRadius: 12,
          ),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════
// INDUSTRIAL BUTTON
// ═══════════════════════════════════════════════════════
class _IndustrialButton extends StatefulWidget {
  final AppPalette C;
  final Widget child;
  final VoidCallback? onTap;
  final Color color;
  final double height;
  const _IndustrialButton({
    required this.C,
    required this.child,
    required this.onTap,
    this.color = const Color(0xFFC9A961),
    this.height = 56,
  });

  @override
  State<_IndustrialButton> createState() => _IndustrialButtonState();
}

class _IndustrialButtonState extends State<_IndustrialButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final C = widget.C;
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    final enabled = widget.onTap != null;
    final light = _lighten(widget.color);
    final dark = _darken(widget.color);
    final textColor =
        isComic ? C.contrastTextOn(widget.color) : Colors.white;

    return GestureDetector(
      onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
      onTapUp: enabled
          ? (_) {
              setState(() => _pressed = false);
              HapticFeedback.mediumImpact();
              widget.onTap?.call();
            }
          : null,
      onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: widget.height,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: isComic
              ? null
              : LinearGradient(
                  begin: _pressed
                      ? Alignment.bottomCenter
                      : Alignment.topCenter,
                  end: _pressed
                      ? Alignment.topCenter
                      : Alignment.bottomCenter,
                  colors: _pressed
                      ? [dark, dark, widget.color]
                      : [light, widget.color, dark],
                  stops: const [0.0, 0.5, 1.0],
                ),
          color: isComic ? widget.color : null,
          boxShadow: isComic
              ? (_pressed
                  ? []
                  : const [
                      BoxShadow(
                        color: Colors.black,
                        offset: Offset(4, 4),
                        blurRadius: 0,
                      ),
                    ])
              : (_pressed
                  ? [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.9),
                        offset: const Offset(0, 1),
                        blurRadius: 3,
                      ),
                    ]
                  : [
                      BoxShadow(
                        color: widget.color.withOpacity(0.45),
                        offset: const Offset(0, 5),
                        blurRadius: 10,
                        spreadRadius: -2,
                      ),
                      BoxShadow(
                        color: Colors.black.withOpacity(0.75),
                        offset: const Offset(0, 4),
                        blurRadius: 6,
                      ),
                    ]),
          border: Border.all(
            color: isComic ? Colors.black : dark.withOpacity(0.9),
            width: isComic ? 3.5 : 1.5,
          ),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            if (!isComic) ...[
              Positioned(top: 5, left: 5, child: _Rivet(C: C, size: 6)),
              Positioned(top: 5, right: 5, child: _Rivet(C: C, size: 6)),
              Positioned(bottom: 5, left: 5, child: _Rivet(C: C, size: 6)),
              Positioned(
                  bottom: 5, right: 5, child: _Rivet(C: C, size: 6)),
            ],
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Opacity(
                opacity: enabled ? 1 : 0.5,
                child: DefaultTextStyle(
                  style: TextStyle(
                    color: textColor,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                  ),
                  child: IconTheme(
                    data: IconThemeData(color: textColor),
                    child: widget.child,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  static Color _lighten(Color c) => Color.fromARGB(
        c.alpha,
        (c.red + 40).clamp(0, 255),
        (c.green + 40).clamp(0, 255),
        (c.blue + 30).clamp(0, 255),
      );
  static Color _darken(Color c) => Color.fromARGB(
        c.alpha,
        (c.red - 60).clamp(0, 255),
        (c.green - 50).clamp(0, 255),
        (c.blue - 40).clamp(0, 255),
      );
}

// ═══════════════════════════════════════════════════════
// TIKTOK DOWNLOADER PAGE
// ═══════════════════════════════════════════════════════
class TiktokDownloaderPage extends StatefulWidget {
  const TiktokDownloaderPage({super.key});

  @override
  State<TiktokDownloaderPage> createState() => _TiktokDownloaderPageState();
}

class _TiktokDownloaderPageState extends State<TiktokDownloaderPage> {
  final TextEditingController _urlController = TextEditingController();
  bool _isLoading = false;
  bool _isSharing = false;
  bool _hd = false;
  String? _errorMessage;
  Map<String, dynamic>? _videoData;
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;

  @override
  void initState() {
    super.initState();
    _Pulse.ensureStarted();
  }

  @override
  void dispose() {
    _urlController.dispose();
    _videoController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  Future<void> _downloadTiktok() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      setState(() {
        _errorMessage = 'URL TikTok tidak boleh kosong.';
        _videoData = null;
      });
      return;
    }

    if (!url.contains('tiktok.com') &&
        !url.contains('vt.tiktok') &&
        !url.contains('vm.tiktok') &&
        !url.contains('douyin')) {
      setState(() {
        _errorMessage = 'Link harus dari TikTok (vt.tiktok.com / tiktok.com)';
        _videoData = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _videoData = null;
      _videoController?.dispose();
      _chewieController?.dispose();
      _videoController = null;
      _chewieController = null;
    });

    try {
      final apiUrl =
          '$baseUrl/tiktok/download?url=${Uri.encodeComponent(url)}&hd=${_hd ? '1' : '0'}';

      final res = await http.get(
        Uri.parse(apiUrl),
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 13)',
          'Accept': 'application/json',
        },
      ).timeout(const Duration(seconds: 45));

      if (res.statusCode != 200) {
        setState(() {
          _errorMessage = 'Server error (${res.statusCode}). Coba lagi nanti.';
        });
        return;
      }

      final json = jsonDecode(res.body) as Map<String, dynamic>;

      if (json['valid'] != true) {
        setState(() {
          _errorMessage = json['message'] ?? 'Gagal ambil data video';
        });
        return;
      }

      final videos = json['videos'] as Map<String, dynamic>? ?? {};
      final author = json['author'] as Map<String, dynamic>? ?? {};
      final audio = json['audio'] as Map<String, dynamic>? ?? {};

      final parsed = {
        'title': json['title'] ?? 'TikTok Video',
        'videoUrl': videos['noWatermark'] ??
            videos['hd'] ??
            videos['withWatermark'] ??
            '',
        'videoWm': videos['withWatermark'] ?? '',
        'videoHd': videos['hd'] ?? '',
        'audioUrl': audio['url'] ?? '',
        'thumbnail': json['cover'] ?? '',
        'creator': author['nickname'] ?? author['uniqueId'] ?? 'Unknown',
        'duration': json['duration'] ?? 0,
        'source': json['source'] ?? 'unknown',
      };

      setState(() => _videoData = parsed);
      _initializeVideoPlayer();
    } catch (e) {
      setState(() {
        _errorMessage = 'Terjadi kesalahan: $e';
      });
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _initializeVideoPlayer() {
    final url = _videoData?['videoUrl'] as String?;
    if (url == null || url.isEmpty) {
      setState(() {
        _errorMessage = 'URL video kosong.';
      });
      return;
    }

    _videoController = VideoPlayerController.networkUrl(
      Uri.parse(url),
      httpHeaders: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 13)',
        'Accept': '*/*',
      },
    );

    Future.delayed(const Duration(seconds: 20), () {
      if (!mounted) return;
      if (_videoController?.value.isInitialized != true) {
        setState(() {
          _errorMessage =
              'Video loading timeout. Koneksi lambat / URL ga valid.';
        });
        _videoController?.dispose();
      }
    });

    _videoController!.initialize().then((_) {
      if (!mounted) return;
      final C = AppTheme.current.value;
      setState(() {
        _chewieController = ChewieController(
          videoPlayerController: _videoController!,
          autoPlay: true,
          looping: false,
          showControls: true,
          materialProgressColors: ChewieProgressColors(
            playedColor: C.accent,
            handleColor: C.accentShine,
            backgroundColor: C.bgDark,
            bufferedColor: C.bg,
          ),
        );
      });
    }).catchError((e) {
      if (mounted) {
        setState(() {
          _errorMessage = 'Gagal load video player: $e';
        });
      }
    });
  }

  Future<void> _shareVideo(AppPalette C) async {
    if (_videoData == null) return;
    setState(() => _isSharing = true);

    try {
      final videoUrl = _videoData!['videoUrl'] as String?;
      if (videoUrl == null || videoUrl.isEmpty) {
        _showSnack('URL video tidak tersedia', isError: true, C: C);
        return;
      }

      final response = await http.get(
        Uri.parse(videoUrl),
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 13)',
          'Accept': '*/*',
        },
      ).timeout(const Duration(seconds: 60));

      if (response.statusCode != 200) {
        _showSnack('Gagal download video: ${response.statusCode}',
            isError: true, C: C);
        return;
      }

      final tempDir = await getTemporaryDirectory();
      final fileName = 'tiktok_${DateTime.now().millisecondsSinceEpoch}.mp4';
      final file = File('${tempDir.path}/$fileName');
      await file.writeAsBytes(response.bodyBytes);

      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Video TikTok dari: ${_videoData!['creator']}',
      );
    } catch (e) {
      _showSnack('Error sharing: $e', isError: true, C: C);
    } finally {
      if (mounted) setState(() => _isSharing = false);
    }
  }

  void _showSnack(String msg, {bool isError = false, required AppPalette C}) {
    final c = isError ? C.primaryHi : C.accent;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            _Led(color: c, size: 8, blink: true),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                msg,
                style: TextStyle(
                  color: C.text,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  fontFamily: AppTheme.currentStyle.value == ThemeStyle.comic3d
                      ? 'ComicNeue'
                      : 'ShareTechMono',
                ),
              ),
            ),
          ],
        ),
        backgroundColor: C.bgDark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
          side: BorderSide(color: c, width: 1.5),
        ),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  void _pasteFromClipboard() async {
    final data = await Clipboard.getData('text/plain');
    if (data != null && data.text != null && data.text!.isNotEmpty) {
      setState(() {
        _urlController.text = data.text!.trim();
      });
      HapticFeedback.lightImpact();
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;
            return Scaffold(
              backgroundColor: C.bgDeep,
              body: Stack(
                children: [
                  Positioned.fill(
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: isComic
                            ? null
                            : RadialGradient(
                                center: const Alignment(-0.3, -0.3),
                                radius: 1.2,
                                colors: [C.bg, C.bgDark, C.bgDeep],
                                stops: const [0.0, 0.6, 1.0],
                              ),
                        color: isComic ? C.bg : null,
                      ),
                    ),
                  ),
                  SafeArea(
                    child: Column(
                      children: [
                        const SizedBox(height: 8),
                        _buildAppBar(C, isComic),
                        const SizedBox(height: 12),
                        Expanded(
                          child: SingleChildScrollView(
                            physics: const BouncingScrollPhysics(),
                            padding: const EdgeInsets.symmetric(horizontal: 14),
                            child: Column(
                              children: [
                                _buildInputPlate(C, isComic),
                                const SizedBox(height: 14),
                                if (_errorMessage != null)
                                  _buildErrorPlate(C, isComic),
                                if (_videoData != null)
                                  _buildVideoPlate(C, isComic),
                                const SizedBox(height: 30),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildAppBar(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: _MetalPlate(
        C: C,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            GestureDetector(
              onTap: () {
                HapticFeedback.lightImpact();
                Navigator.pop(context);
              },
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: isComic ? C.primaryHi : null,
                  gradient: isComic
                      ? null
                      : LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [C.textSub, C.bgDark],
                        ),
                  border: Border.all(
                    color: isComic ? Colors.black : C.primaryLo,
                    width: isComic ? 3 : 1.2,
                  ),
                  boxShadow: isComic
                      ? const [
                          BoxShadow(
                              color: Colors.black,
                              offset: Offset(3, 3),
                              blurRadius: 0),
                        ]
                      : null,
                ),
                child: Icon(
                  Icons.arrow_back_ios_new_rounded,
                  color: isComic ? C.contrastTextOn(C.primaryHi) : C.accent,
                  size: 16,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: isComic ? BoxShape.rectangle : BoxShape.circle,
                    borderRadius: isComic ? BorderRadius.circular(10) : null,
                    gradient: isComic
                        ? null
                        : RadialGradient(
                            colors: [C.text, C.bg, C.bgDark],
                          ),
                    color: isComic ? C.accent : null,
                    border: Border.all(
                      color: isComic ? Colors.black : C.accent,
                      width: isComic ? 3 : 2,
                    ),
                  ),
                  child: Icon(
                    Icons.music_note_rounded,
                    color: isComic ? C.contrastTextOn(C.accent) : C.accent,
                    size: 20,
                  ),
                ),
                Positioned(
                  top: -2,
                  right: -2,
                  child: _Led(color: C.primaryHi, size: 6, blink: !isComic),
                ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'TIKTOK DL',
                    style: TextStyle(
                      color: isComic ? C.comicText : C.accentHi,
                      fontSize: isComic ? 15 : 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: isComic ? 2 : 3,
                      height: 1,
                      shadows: isComic
                          ? [
                              Shadow(
                                color: C.comicTextOutline,
                                offset: const Offset(1, 1),
                                blurRadius: 0,
                              ),
                            ]
                          : null,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      _Led(
                          color: C.primaryHi, size: 4, blink: !isComic),
                      const SizedBox(width: 5),
                      Text(
                        'NO WATERMARK',
                        style: TextStyle(
                          color: isComic
                              ? C.comicTextSub
                              : C.textSub.withOpacity(0.7),
                          fontSize: 8,
                          fontWeight: FontWeight.w700,
                          fontFamily: isComic
                              ? 'ComicNeue'
                              : 'ShareTechMono',
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            _Led(color: C.accent, size: 7, blink: !isComic),
          ],
        ),
      ),
    );
  }

  Widget _buildInputPlate(AppPalette C, bool isComic) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _Screw(C: C, size: 12),
              const SizedBox(width: 10),
              Expanded(
                child: Center(
                  child: Text(
                    'PASTE URL TIKTOK',
                    style: TextStyle(
                      color: isComic ? C.comicText : C.accent,
                      fontSize: isComic ? 14 : 11,
                      fontWeight: FontWeight.w900,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: isComic ? 1.5 : 2,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              _Screw(C: C, size: 12),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _Rivet(C: C, size: 6),
              const SizedBox(width: 6),
              Icon(Icons.link_rounded, color: C.accent, size: 14),
              const SizedBox(width: 6),
              Text(
                'TIKTOK LINK',
                style: TextStyle(
                  color: isComic ? C.comicText : C.accent,
                  fontSize: isComic ? 11 : 9,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: isComic ? 1 : 1.5,
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: () {
                  HapticFeedback.selectionClick();
                  setState(() => _hd = !_hd);
                },
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: _hd
                        ? C.accent.withOpacity(0.2)
                        : C.bgDeep,
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(
                      color: _hd ? C.accent : C.textSub.withOpacity(0.5),
                      width: 1.2,
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        _hd ? Icons.hd_rounded : Icons.hd_outlined,
                        color: _hd
                            ? C.accent
                            : C.textSub.withOpacity(0.5),
                        size: 12,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        'HD',
                        style: TextStyle(
                          color: _hd
                              ? C.accent
                              : C.textSub.withOpacity(0.5),
                          fontSize: 8,
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: C.bgDeep,
              border: Border.all(
                color: isComic ? Colors.black : C.bgDark,
                width: isComic ? 3 : 1.5,
              ),
            ),
            child: TextField(
              controller: _urlController,
              style: TextStyle(
                color: isComic ? C.comicText : C.text,
                fontSize: 12,
                fontWeight: FontWeight.w600,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                letterSpacing: 0.3,
              ),
              cursorColor: C.accent,
              maxLines: 2,
              minLines: 1,
              decoration: InputDecoration(
                hintText: 'https://vt.tiktok.com/xxx/',
                hintStyle: TextStyle(
                  color: isComic
                      ? C.comicTextMuted
                      : C.textSub.withOpacity(0.4),
                  fontSize: 11,
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                ),
                prefixIcon: Padding(
                  padding: const EdgeInsets.only(
                      left: 10, right: 6, top: 2, bottom: 2),
                  child: Icon(
                    Icons.download_rounded,
                    color: C.accent,
                    size: 18,
                  ),
                ),
                suffixIcon: GestureDetector(
                  onTap: _pasteFromClipboard,
                  child: Container(
                    margin: const EdgeInsets.all(8),
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    decoration: BoxDecoration(
                      color: C.bgDark,
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: C.bg, width: 1),
                    ),
                    child: Center(
                      widthFactor: 1,
                      child: Text(
                        'PASTE',
                        style: TextStyle(
                          color: isComic ? C.comicText : C.accentHi,
                          fontSize: 8,
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ),
                ),
                prefixIconConstraints:
                    const BoxConstraints(minWidth: 32, minHeight: 32),
                border: InputBorder.none,
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 14),
              ),
            ),
          ),
          const SizedBox(height: 14),
          _IndustrialButton(
            C: C,
            color: _isLoading ? C.textSub : C.accent,
            height: 54,
            onTap: _isLoading ? null : _downloadTiktok,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (_isLoading)
                  const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  )
                else
                  const Icon(Icons.download_rounded,
                      color: Colors.white, size: 18),
                const SizedBox(width: 10),
                Text(
                  _isLoading ? 'MEMPROSES...' : 'DOWNLOAD',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: isComic ? 14 : 12,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: isComic ? 1.5 : 2,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorPlate(AppPalette C, bool isComic) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: C.primaryHi,
              border: Border.all(
                color: isComic ? Colors.black : C.primaryLo,
                width: isComic ? 3 : 1.5,
              ),
            ),
            child: Icon(
              Icons.error_outline_rounded,
              color: isComic ? C.contrastTextOn(C.primaryHi) : Colors.white,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _errorMessage!,
              style: TextStyle(
                color: isComic ? C.comicText : C.primaryHi,
                fontSize: 11,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                fontWeight: FontWeight.w600,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoPlate(AppPalette C, bool isComic) {
    return _MetalPlate(
      C: C,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _Led(color: C.accent, size: 7, blink: !isComic),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'VIDEO READY',
                  style: TextStyle(
                    color: isComic ? C.comicText : C.accent,
                    fontSize: isComic ? 14 : 11,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: isComic ? 1.5 : 2,
                  ),
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: C.bgDeep,
                  borderRadius: BorderRadius.circular(3),
                  border: Border.all(color: C.bg, width: 1),
                ),
                child: Text(
                  (_videoData!['source'] ?? 'N/A')
                      .toString()
                      .toUpperCase(),
                  style: TextStyle(
                    color: C.accent,
                    fontSize: 7,
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
              const SizedBox(width: 6),
              _Screw(C: C, size: 10),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _Rivet(C: C, size: 6),
              const SizedBox(width: 6),
              Icon(Icons.person_rounded, color: C.accent, size: 12),
              const SizedBox(width: 5),
              Expanded(
                child: Text(
                  '${_videoData!['creator']}',
                  style: TextStyle(
                    color: isComic ? C.comicText : C.accent,
                    fontSize: isComic ? 12 : 10,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.5,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            '${_videoData!['title']}',
            style: TextStyle(
              color: isComic ? C.comicTextSub : C.text.withOpacity(0.7),
              fontSize: 10,
              fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
              height: 1.4,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 12),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: isComic ? Colors.black : C.bgDark,
                width: isComic ? 3 : 1.5,
              ),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(isComic ? 7 : 9),
              child: AspectRatio(
                aspectRatio: _videoController?.value.isInitialized == true
                    ? _videoController!.value.aspectRatio
                    : 9 / 16,
                child: _chewieController != null
                    ? Chewie(controller: _chewieController!)
                    : Container(
                        color: Colors.black,
                        child: Center(
                          child: CircularProgressIndicator(
                            color: C.accent,
                            strokeWidth: 2,
                          ),
                        ),
                      ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                flex: 2,
                child: _IndustrialButton(
                  C: C,
                  color: _isSharing ? C.textSub : C.accent,
                  height: 48,
                  onTap: _isSharing ? null : () => _shareVideo(C),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (_isSharing)
                        const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor:
                                AlwaysStoppedAnimation<Color>(Colors.white),
                          ),
                        )
                      else
                        const Icon(Icons.share_rounded,
                            color: Colors.white, size: 16),
                      const SizedBox(width: 8),
                      Text(
                        _isSharing ? 'SHARING...' : 'SHARE',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: isComic ? 13 : 11,
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _IndustrialButton(
                  C: C,
                  color: C.primaryHi,
                  height: 48,
                  onTap: () {
                    if (_videoData!['audioUrl'] != null &&
                        (_videoData!['audioUrl'] as String).isNotEmpty) {
                      Clipboard.setData(
                          ClipboardData(text: _videoData!['audioUrl']));
                      _showSnack('Link audio disalin', C: C);
                    } else {
                      _showSnack('Audio ga tersedia',
                          isError: true, C: C);
                    }
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.music_note_rounded,
                          color: Colors.white, size: 16),
                      const SizedBox(width: 6),
                      Text(
                        'AUDIO',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: isComic ? 12 : 10,
                          fontWeight: FontWeight.w900,
                          fontFamily:
                              isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}