// lib/spam_ngl.dart
import 'dart:convert';
import 'dart:math';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'app_theme.dart';

class NglPage extends StatefulWidget {
  const NglPage({super.key});

  @override
  State<NglPage> createState() => _NglPageState();
}

class _NglPageState extends State<NglPage> {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController messageController = TextEditingController();

  bool isRunning = false;
  int counter = 0;
  String statusLog = "";
  Timer? timer;

  String generateDeviceId(int length) {
    final random = Random.secure();
    return List.generate(length, (_) => random.nextInt(16).toRadixString(16))
        .join();
  }

  Future<void> sendMessage(String username, String message) async {
    final deviceId = generateDeviceId(42);
    final url = Uri.parse("https://ngl.link/api/submit");

    final headers = {
      "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0",
      "Accept": "*/*",
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
      "X-Requested-With": "XMLHttpRequest",
      "Referer": "https://ngl.link/$username",
      "Origin": "https://ngl.link"
    };

    final body =
        "username=$username&question=$message&deviceId=$deviceId&gameSlug=&referrer=";

    try {
      final response = await http.post(url, headers: headers, body: body);

      if (response.statusCode == 200) {
        setState(() {
          counter++;
          statusLog = "✅ [$counter] Pesan terkirim";
        });
      } else {
        setState(() {
          statusLog =
              "❌ Ratelimit (${response.statusCode}), tunggu 5 detik...";
        });
        await Future.delayed(const Duration(seconds: 5));
      }
    } catch (e) {
      setState(() {
        statusLog = "⚠️ Error: $e";
      });
      await Future.delayed(const Duration(seconds: 2));
    }
  }

  void startLoop() {
    final username = usernameController.text.trim();
    final message = messageController.text.trim();

    if (username.isEmpty || message.isEmpty) {
      setState(() {
        statusLog = "⚠️ Harap isi username & pesan!";
      });
      return;
    }

    setState(() {
      isRunning = true;
      counter = 0;
      statusLog = "▶️ Mulai mengirim...";
    });

    timer = Timer.periodic(const Duration(seconds: 2), (_) {
      if (isRunning) {
        sendMessage(username, message);
      }
    });
  }

  void stopLoop() {
    setState(() {
      isRunning = false;
      statusLog = "⏹️ Dihentikan.";
    });
    timer?.cancel();
  }

  @override
  void dispose() {
    timer?.cancel();
    usernameController.dispose();
    messageController.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════
  // BUILDERS
  // ═══════════════════════════════════════════════════════════
  Widget _buildCard({
    required AppPalette C,
    required bool isComic,
    required Widget child,
    EdgeInsetsGeometry? padding,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isComic ? C.bgDark : null,
        gradient: isComic
            ? null
            : LinearGradient(
                colors: [C.bg, C.bgDark, C.bgDeep],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
        borderRadius: BorderRadius.circular(isComic ? 18 : 14),
        border: Border.all(
          color: isComic ? Colors.black : C.accent.withOpacity(0.4),
          width: isComic ? 4 : 1.5,
        ),
        boxShadow: isComic
            ? const [
                BoxShadow(
                    color: Colors.black, offset: Offset(5, 5), blurRadius: 0),
              ]
            : [
                BoxShadow(
                  color: C.accent.withOpacity(0.18),
                  blurRadius: 20,
                ),
              ],
      ),
      child: child,
    );
  }

  Widget _buildTextField({
    required AppPalette C,
    required bool isComic,
    required TextEditingController controller,
    required String label,
    int maxLines = 1,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: C.bgDeep,
        borderRadius: BorderRadius.circular(isComic ? 12 : 10),
        border: Border.all(
          color: isComic ? Colors.black : C.accent.withOpacity(0.5),
          width: isComic ? 3 : 1.5,
        ),
      ),
      child: TextField(
        controller: controller,
        maxLines: maxLines,
        style: TextStyle(
          color: isComic ? C.comicText : C.text,
          fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
        cursorColor: C.accent,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(
            color: isComic ? C.comicTextSub : C.textSub,
            fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
            fontSize: 12,
          ),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        ),
      ),
    );
  }

  Widget _buildButton({
    required AppPalette C,
    required bool isComic,
    required String text,
    required IconData icon,
    required VoidCallback? onPressed,
    required Color color,
  }) {
    final enabled = onPressed != null;
    final textColor = isComic ? C.contrastTextOn(color) : Colors.white;
    final outline = textColor == Colors.white ? Colors.black : Colors.white;

    return GestureDetector(
      onTap: onPressed,
      child: Opacity(
        opacity: enabled ? 1.0 : 0.4,
        child: Container(
          height: 52,
          decoration: BoxDecoration(
            color: isComic ? color : null,
            gradient: isComic
                ? null
                : LinearGradient(
                    colors: [color, color.withOpacity(0.7)],
                  ),
            borderRadius: BorderRadius.circular(isComic ? 12 : 14),
            border: Border.all(
              color: isComic ? Colors.black : color.withOpacity(0.8),
              width: isComic ? 3.5 : 1.5,
            ),
            boxShadow: isComic
                ? const [
                    BoxShadow(
                        color: Colors.black,
                        offset: Offset(4, 4),
                        blurRadius: 0),
                  ]
                : [
                    BoxShadow(
                      color: color.withOpacity(0.4),
                      blurRadius: 12,
                    ),
                  ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: textColor, size: 18),
              const SizedBox(width: 8),
              Text(
                text,
                style: TextStyle(
                  color: textColor,
                  fontWeight: FontWeight.w900,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  fontSize: isComic ? 15 : 13,
                  letterSpacing: isComic ? 1 : 1.5,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: outline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bgDeep,
              appBar: AppBar(
                backgroundColor: C.bgDark,
                iconTheme: IconThemeData(color: C.accent),
                title: Text(
                  "NGL Auto Sender",
                  style: TextStyle(
                    color: isComic ? C.comicText : C.accentHi,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: isComic ? 20 : 16,
                    letterSpacing: isComic ? 2 : 3,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.comicTextOutline,
                              offset: const Offset(2, 2),
                              blurRadius: 0,
                            ),
                          ]
                        : null,
                  ),
                ),
              ),
              body: Container(
                decoration: BoxDecoration(
                  gradient: isComic
                      ? null
                      : RadialGradient(
                          center: const Alignment(-0.3, -0.3),
                          radius: 1.2,
                          colors: [C.bg, C.bgDark, C.bgDeep],
                        ),
                  color: isComic ? C.bg : null,
                ),
                child: SafeArea(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        _buildCard(
                          C: C,
                          isComic: isComic,
                          child: _buildTextField(
                            C: C,
                            isComic: isComic,
                            controller: usernameController,
                            label: "Username NGL",
                          ),
                        ),
                        _buildCard(
                          C: C,
                          isComic: isComic,
                          child: _buildTextField(
                            C: C,
                            isComic: isComic,
                            controller: messageController,
                            label: "Pesan",
                            maxLines: 3,
                          ),
                        ),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            Expanded(
                              child: _buildButton(
                                C: C,
                                isComic: isComic,
                                text: "START",
                                icon: Icons.play_arrow,
                                onPressed: isRunning ? null : startLoop,
                                color: C.primaryHi,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _buildButton(
                                C: C,
                                isComic: isComic,
                                text: "STOP",
                                icon: Icons.stop,
                                onPressed: isRunning ? stopLoop : null,
                                color: C.primaryLo,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),
                        _buildCard(
                          C: C,
                          isComic: isComic,
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    isRunning
                                        ? Icons.radio_button_checked
                                        : Icons.radio_button_unchecked,
                                    color: isRunning ? C.accent : C.textSub,
                                    size: 16,
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      statusLog,
                                      style: TextStyle(
                                        fontSize: isComic ? 13 : 12,
                                        color: isComic
                                            ? C.comicText
                                            : C.text,
                                        fontFamily: isComic
                                            ? 'ComicNeue'
                                            : 'ShareTechMono',
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              if (counter > 0) ...[
                                const SizedBox(height: 8),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 14, vertical: 6),
                                  decoration: BoxDecoration(
                                    color: C.bgDeep,
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(
                                      color: isComic
                                          ? Colors.black
                                          : C.accent.withOpacity(0.5),
                                      width: isComic ? 2.5 : 1,
                                    ),
                                  ),
                                  child: Text(
                                    "TOTAL TERKIRIM: $counter",
                                    style: TextStyle(
                                      color: isComic
                                          ? C.comicText
                                          : C.accent,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w900,
                                      fontFamily: isComic
                                          ? 'Bangers'
                                          : 'Orbitron',
                                      letterSpacing: 1.5,
                                    ),
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }
}