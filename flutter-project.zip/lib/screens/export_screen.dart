
import 'package:flutter/material.dart';
class ExportScreen extends StatelessWidget {
  const ExportScreen({super.key});
  @override
  Widget build(BuildContext context){
    return Scaffold(appBar: AppBar(title: Text('Export Laporan')), body: Padding(padding: EdgeInsets.all(20), child: Column(children: [
      ListTile(title: Text('Rentang Tanggal'), subtitle: Text('01 Jan - 31 Jan 2026'), leading: Icon(Icons.date_range)),
      SizedBox(height: 12),
      Row(children: [
        Expanded(child: ElevatedButton.icon(onPressed: (){
          showDialog(context: context, builder: (_)=>AlertDialog(title: Text('PDF Berhasil'), content: Text('Laporan PDF tersimpan'), actions: [TextButton(onPressed: ()=>Navigator.pop(context), child: Text('OK'))]));
        }, icon: Icon(Icons.picture_as_pdf), label: Text('Export PDF'))),
        SizedBox(width: 12),
        Expanded(child: ElevatedButton.icon(onPressed: (){
          showDialog(context: context, builder: (_)=>AlertDialog(title: Text('Excel Berhasil'), content: Text('Laporan Excel tersimpan'), actions: [TextButton(onPressed: ()=>Navigator.pop(context), child: Text('OK'))]));
        }, icon: Icon(Icons.table_chart), label: Text('Export Excel'))),
      ]),
      SizedBox(height: 20),
      Container(padding: EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.purple.withOpacity(0.1), borderRadius: BorderRadius.circular(12)), child: Row(children: [Icon(Icons.info, color: Colors.purple), SizedBox(width: 10), Expanded(child: Text('Fitur export lengkap dengan chart dan summary'))]))
    ])));
  }
}
