
import 'package:flutter/material.dart';
import '../widgets/popup_widget.dart';
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context){
    return SafeArea(child: SingleChildScrollView(padding: EdgeInsets.all(16), child: Column(children: [
      SizedBox(height: 20),
      CircleAvatar(radius: 50, backgroundColor: Color(0xFF6A11CB), child: Icon(Icons.person, size: 50, color: Colors.white)),
      SizedBox(height: 12),
      Text('Rizal Dev', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      Text('rizal_d8v | Premium User', style: TextStyle(color: Colors.grey)),
      SizedBox(height: 20),
      Container(padding: EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)), child: Column(children: [
        ListTile(leading: Icon(Icons.verified_user), title: Text('LICENSE : RIZAL'), subtitle: Text('Original License')),
        Divider(),
        ListTile(leading: Icon(Icons.camera_alt), title: Text('IG : rizal_d8v'), onTap: (){AppPopup.showBottomInfo(context, 'Instagram', 'Buka instagram.com/rizal_d8v');}),
        ListTile(leading: Icon(Icons.video_library), title: Text('YT : MrRall_2jt'), subtitle: Text('youtube.com/@MrRall_2jt'), onTap: (){AppPopup.showBottomInfo(context, 'YouTube', 'Subscribe youtube.com/@MrRall_2jt');}),
        ListTile(leading: Icon(Icons.favorite), title: Text('Saweria : saweria.co/rizald8vid'), onTap: (){AppPopup.showSuccess(context, 'Terima kasih support di saweria.co/rizald8vid!');}),
      ])),
      SizedBox(height: 16),
      Container(padding: EdgeInsets.all(16), decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF6A11CB), Color(0xFF2575FC)]), borderRadius: BorderRadius.circular(16)), child: Row(children: [Icon(Icons.star, color: Colors.white), SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Upgrade Premium', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)), Text('Buka semua fitur super lengkap', style: TextStyle(color: Colors.white70, fontSize: 12))])), ElevatedButton(onPressed: (){AppPopup.showSuccess(context, 'Kamu sudah Premium!');}, child: Text('Premium'))])),
      SizedBox(height: 20),
      SizedBox(width: double.infinity, child: OutlinedButton(onPressed: (){AppPopup.showConfirm(context, 'Logout?', 'Yakin mau keluar?', (){AppPopup.showSuccess(context, 'Logout berhasil');});}, child: Text('Logout')))
    ])));
  }
}
