
import 'package:flutter/material.dart';
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}
class _SettingsScreenState extends State<SettingsScreen> {
  bool dark=false;
  bool bio=true;
  @override
  Widget build(BuildContext context){
    return Scaffold(appBar: AppBar(title: Text('Pengaturan')), body: ListView(padding: EdgeInsets.all(16), children: [
      SwitchListTile(value: dark, title: Text('Dark Mode'), onChanged: (v)=>setState(()=>dark=v)),
      SwitchListTile(value: bio, title: Text('Biometrik'), onChanged: (v)=>setState(()=>bio=v)),
      ListTile(title: Text('Bahasa'), subtitle: Text('Indonesia'), onTap: (){}),
      ListTile(title: Text('Mata Uang'), subtitle: Text('IDR - Rupiah'), onTap: (){}),
      ListTile(title: Text('Export Data'), onTap: (){
        showDialog(context: context, builder: (_)=>AlertDialog(title: Text('Export'), content: Text('Export CSV PDF Excel siap!'), actions: [TextButton(onPressed: ()=>Navigator.pop(context), child: Text('OK'))]));
      }),
      Divider(),
      ListTile(title: Text('LICENSE : RIZAL'), subtitle: Text('IG rizal_d8v | YT youtube.com/@MrRall_2jt | saweria.co/rizald8vid')),
      ListTile(title: Text('Versi'), subtitle: Text('1.0.0+1 Super Lengkap FORCE')),
    ]));
  }
}
