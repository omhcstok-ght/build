
import 'package:flutter/material.dart';
class NotificationScreen extends StatelessWidget {
  const NotificationScreen({super.key});
  @override
  Widget build(BuildContext context){
    List<Map<String,String>> notifs = [
      {'title':'Transfer Berhasil','msg':'Rp 500.000 ke BCA'},
      {'title':'Tagihan Listrik','msg':'Jatuh tempo 3 hari lagi'},
      {'title':'Budget Warning','msg':'Makanan sudah 80% limit'},
      {'title':'Promo','msg':'Cashback 20% Top Up'},
    ];
    return Scaffold(appBar: AppBar(title: Text('Notifikasi')), body: ListView.builder(itemCount: notifs.length, itemBuilder: (_,i){
      var n = notifs[i];
      return ListTile(leading: CircleAvatar(child: Icon(Icons.notifications)), title: Text(n['title']!), subtitle: Text(n['msg']!), trailing: IconButton(icon: Icon(Icons.delete), onPressed: (){
        showDialog(context: context, builder: (_)=>AlertDialog(title: Text('Hapus?'), content: Text('Hapus notifikasi ini?'), actions: [TextButton(onPressed: ()=>Navigator.pop(context), child: Text('Batal')), TextButton(onPressed: (){Navigator.pop(context); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Dihapus')));}, child: Text('Ya'))]));
      }));
    }));
  }
}
