
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'home_screen.dart';
class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}
class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController pc = PageController();
  int idx = 0;
  VideoPlayerController? vc;
  @override
  void initState(){
    super.initState();
    try{
      vc = VideoPlayerController.asset('flutter_assets/intro.mp4');
      vc!.initialize().then((_)=>setState((){}));
      vc!.setLooping(true);
      vc!.play();
    }catch(e){vc=null;}
  }
  @override
  Widget build(BuildContext context){
    return Scaffold(
      body: PageView(
        controller: pc,
        onPageChanged: (i)=>setState(()=>idx=i),
        children: [
          _page('Dompetku\nMobile', 'Dompet digital super lengkap, ringan, premium', Icons.wallet, Color(0xFF6A11CB)),
          _page('Smart Analytics', 'Pie chart, bar chart, AI insight, budget', Icons.pie_chart, Color(0xFF2575FC)),
          _page('Siap Jadi APK', 'Intro video 0B bisa diganti, popup banyak, LICENSE RIZAL', Icons.rocket_launch, Color(0xFF00B894)),
        ],
      ),
    );
  }
  Widget _page(String title, String desc, IconData ic, Color col){
    return Container(
      decoration: BoxDecoration(gradient: LinearGradient(colors: [col, Color(0xFF6A11CB)])),
      padding: EdgeInsets.all(24),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(ic, size: 80, color: Colors.white),
        SizedBox(height: 20),
        if(vc!=null && vc!.value.isInitialized) AspectRatio(aspectRatio: vc!.value.aspectRatio, child: VideoPlayer(vc!)) else SizedBox(height: 10),
        SizedBox(height: 20),
        Text(title, textAlign: TextAlign.center, style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.white)),
        SizedBox(height: 12),
        Text(desc, textAlign: TextAlign.center, style: TextStyle(color: Colors.white70)),
        SizedBox(height: 40),
        ElevatedButton(onPressed: (){
          if(idx<2) pc.nextPage(duration: Duration(milliseconds: 300), curve: Curves.ease);
          else Navigator.pushReplacement(context, MaterialPageRoute(builder: (_)=>HomeScreen()));
        }, child: Text(idx<2?'Next':'Mulai Sekarang'))
      ]),
    );
  }
}
