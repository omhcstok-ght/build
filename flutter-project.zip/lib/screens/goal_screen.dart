
import 'package:flutter/material.dart';
class GoalScreen extends StatelessWidget {
  const GoalScreen({super.key});
  @override
  Widget build(BuildContext context){
    return Scaffold(appBar: AppBar(title: Text('Financial Goals')), body: ListView(padding: EdgeInsets.all(16), children: [
      _goal('Beli Laptop Gaming', 15000000, 9000000, Icons.laptop),
      _goal('Liburan Bali', 5000000, 3500000, Icons.beach_access),
      _goal('Beli Motor', 25000000, 5000000, Icons.motorcycle),
      _goal('Dana Darurat', 20000000, 18000000, Icons.security),
    ]));
  }
  Widget _goal(String title, double target, double current, IconData ic){
    double pct = current/target;
    return Container(margin: EdgeInsets.only(bottom: 16), padding: EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 8)]), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [CircleAvatar(child: Icon(ic)), SizedBox(width: 12), Expanded(child: Text(title, style: TextStyle(fontWeight: FontWeight.bold)))]),
      SizedBox(height: 12),
      LinearProgressIndicator(value: pct, minHeight: 10, borderRadius: BorderRadius.circular(10)),
      SizedBox(height: 8),
      Text('Rp $current / Rp $target  (${(pct*100).toInt()}%)', style: TextStyle(fontSize: 12, color: Colors.grey))
    ]));
  }
}
