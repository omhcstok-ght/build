
import 'package:flutter/material.dart';
import '../widgets/popup_widget.dart';
class AddTransactionScreen extends StatefulWidget {
  final String type;
  const AddTransactionScreen({super.key, required this.type});
  @override
  State<AddTransactionScreen> createState() => _AddTransactionScreenState();
}
class _AddTransactionScreenState extends State<AddTransactionScreen> {
  final _title = TextEditingController();
  final _amount = TextEditingController();
  final _note = TextEditingController();
  String category = 'Makanan';
  List<String> cats = ['Makanan','Transport','Belanja','Tagihan','Hiburan','Kesehatan','Pekerjaan','Freelance','Investasi'];
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text(widget.type=='income'?'Tambah Pemasukan':'Tambah Pengeluaran'), backgroundColor: widget.type=='income'?Colors.green:Colors.red, foregroundColor: Colors.white),
      body: SingleChildScrollView(padding: EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        TextField(controller: _title, decoration: InputDecoration(labelText: 'Judul Transaksi', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)), prefixIcon: Icon(Icons.title))),
        SizedBox(height: 16),
        TextField(controller: _amount, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: 'Jumlah (Rp)', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)), prefixIcon: Icon(Icons.money))),
        SizedBox(height: 16),
        DropdownButtonFormField(value: category, items: cats.map((e)=>DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v)=>setState(()=>category=v.toString()), decoration: InputDecoration(labelText: 'Kategori', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
        SizedBox(height: 16),
        TextField(controller: _note, maxLines: 3, decoration: InputDecoration(labelText: 'Catatan', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
        SizedBox(height: 24),
        SizedBox(width: double.infinity, height: 50, child: ElevatedButton(onPressed: (){
          if(_title.text.isEmpty || _amount.text.isEmpty){AppPopup.showError(context, 'Lengkapi semua field dulu!'); return;}
          AppPopup.showSuccess(context, 'Transaksi ${widget.type} Rp ${_amount.text} berhasil disimpan!');
          Future.delayed(Duration(seconds: 1), (){if(mounted) Navigator.pop(context);});
        }, style: ElevatedButton.styleFrom(backgroundColor: widget.type=='income'?Colors.green:Colors.red, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: Text('Simpan Transaksi', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))))
      ])),
    );
  }
}
