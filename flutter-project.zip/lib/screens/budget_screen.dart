
import 'package:flutter/material.dart';
import '../widgets/popup_widget.dart';
class BudgetScreen extends StatefulWidget {
  const BudgetScreen({super.key});
  @override
  State<BudgetScreen> createState() => _BudgetScreenState();
}
class _BudgetScreenState extends State<BudgetScreen> {
  List<Map<String,dynamic>> budgets = [
    {'cat':'Makanan','limit':2000000,'spent':1450000},
    {'cat':'Transport','limit':1000000,'spent':600000},
    {'cat':'Hiburan','limit':800000,'spent':750000},
    {'cat':'Belanja','limit':1500000,'spent':500000},
  ];
  @override
  Widget build(BuildContext context){
    return SafeArea(child: Padding(padding: EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Budget Planner', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      SizedBox(height: 16),
      Expanded(child: ListView.builder(itemCount: budgets.length, itemBuilder: (_,i){
        var b = budgets[i];
        double pct = b['spent']/b['limit'];
        return Container(margin: EdgeInsets.only(bottom: 12), padding: EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(b['cat'], style: TextStyle(fontWeight: FontWeight.bold)), Text('${(pct*100).toInt()}%')]),
          SizedBox(height: 8),
          LinearProgressIndicator(value: pct, backgroundColor: Colors.grey[200], color: pct>0.8?Colors.red:Colors.green, minHeight: 8),
          SizedBox(height: 8),
          Text('Rp ${b['spent']} / Rp ${b['limit']}', style: TextStyle(fontSize: 12, color: Colors.grey))
        ]));
      })),
      SizedBox(width: double.infinity, child: ElevatedButton(onPressed: (){AppPopup.showSuccess(context, 'Budget baru berhasil ditambahkan!');}, style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF6A11CB)), child: Text('Tambah Budget', style: TextStyle(color: Colors.white))))
    ])));
  }
}
