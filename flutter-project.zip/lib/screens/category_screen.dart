
import 'package:flutter/material.dart';
class CategoryScreen extends StatelessWidget {
  const CategoryScreen({super.key});
  @override
  Widget build(BuildContext context){
    List<Map<String,dynamic>> cats = [
      {'name':'Makanan','icon':Icons.fastfood,'color':Colors.orange},
      {'name':'Transport','icon':Icons.directions_car,'color':Colors.blue},
      {'name':'Belanja','icon':Icons.shopping_bag,'color':Colors.pink},
      {'name':'Tagihan','icon':Icons.receipt,'color':Colors.red},
      {'name':'Hiburan','icon':Icons.movie,'color':Colors.purple},
      {'name':'Kesehatan','icon':Icons.health_and_safety,'color':Colors.green},
      {'name':'Pekerjaan','icon':Icons.work,'color':Colors.indigo},
      {'name':'Investasi','icon':Icons.trending_up,'color':Colors.teal},
    ];
    return Scaffold(appBar: AppBar(title: Text('Kategori')), body: GridView.builder(padding: EdgeInsets.all(16), gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 12, mainAxisSpacing: 12), itemCount: cats.length, itemBuilder: (_,i){
      var c = cats[i];
      return Container(decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [CircleAvatar(backgroundColor: c['color'].withOpacity(0.15), child: Icon(c['icon'], color: c['color'])), SizedBox(height: 8), Text(c['name'], style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600))]));
    }));
  }
}
