
import 'package:flutter/material.dart';
class WalletScreen extends StatelessWidget {
  const WalletScreen({super.key});
  @override
  Widget build(BuildContext context){
    List<Map<String,dynamic>> wallets = [
      {'name':'Dompet Utama','balance':12500000,'color':Colors.blue},
      {'name':'E-Wallet DANA','balance':1500000,'color':Colors.lightBlue},
      {'name':'Bank BCA','balance':25000000,'color':Colors.indigo},
      {'name':'Tabungan Haji','balance':15000000,'color':Colors.green},
    ];
    return SafeArea(child: Padding(padding: EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Dompet Saya', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      SizedBox(height: 16),
      Expanded(child: GridView.builder(gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.4), itemCount: wallets.length, itemBuilder: (_,i){
        var w = wallets[i];
        return Container(padding: EdgeInsets.all(16), decoration: BoxDecoration(color: w['color'], borderRadius: BorderRadius.circular(20)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.wallet, color: Colors.white), Spacer(), Text(w['name'], style: TextStyle(color: Colors.white70, fontSize: 12)), Text('Rp ${w['balance']}', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))]));
      }))
    ])));
  }
}
