
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/transaction_model.dart';
class StatsScreen extends StatelessWidget {
  final List<TransactionModel> transactions;
  const StatsScreen({super.key, required this.transactions});
  @override
  Widget build(BuildContext context){
    return SafeArea(child: SingleChildScrollView(padding: EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Statistik Keuangan', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      SizedBox(height: 20),
      Container(height: 220, padding: EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)), child: PieChart(PieChartData(sections: [PieChartSectionData(value: 40, color: Colors.green, title: 'Income 40%'), PieChartSectionData(value: 25, color: Colors.red, title: 'Expense'), PieChartSectionData(value: 20, color: Colors.blue, title: 'Invest'), PieChartSectionData(value: 15, color: Colors.orange, title: 'Saving')]))),
      SizedBox(height: 20),
      Container(height: 200, padding: EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)), child: BarChart(BarChartData(barGroups: [BarChartGroupData(x: 0, barRods: [BarChartRodData(toY: 8, color: Colors.green)]), BarChartGroupData(x: 1, barRods: [BarChartRodData(toY: 5, color: Colors.red)]), BarChartGroupData(x: 2, barRods: [BarChartRodData(toY: 6, color: Colors.blue)]), BarChartGroupData(x: 3, barRods: [BarChartRodData(toY: 3, color: Colors.orange)])]))),
      SizedBox(height: 20),
      Text('Analisis AI', style: TextStyle(fontWeight: FontWeight.bold)),
      SizedBox(height: 10),
      Container(padding: EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.purple.withOpacity(0.08), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.purple.withOpacity(0.2))), child: Row(children: [Icon(Icons.auto_awesome, color: Colors.purple), SizedBox(width: 12), Expanded(child: Text('Pengeluaran bulan ini naik 12%. Kurangi kategori Makanan dan Hiburan untuk capai target tabungan.'))]))
    ])));
  }
}
