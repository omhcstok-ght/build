
import 'package:flutter/material.dart';
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _pass = TextEditingController();
  bool obscure = true;
  @override
  Widget build(BuildContext context){
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF6A11CB), Color(0xFF2575FC)])),
        child: SafeArea(child: Padding(padding: EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(Icons.account_balance_wallet, size: 80, color: Colors.white),
          SizedBox(height: 16),
          Text('Dompetku Login', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white)),
          SizedBox(height: 30),
          TextField(controller: _email, decoration: InputDecoration(hintText: 'Email', filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)), prefixIcon: Icon(Icons.email))),
          SizedBox(height: 16),
          TextField(controller: _pass, obscureText: obscure, decoration: InputDecoration(hintText: 'Password', filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)), prefixIcon: Icon(Icons.lock), suffixIcon: IconButton(icon: Icon(obscure?Icons.visibility:Icons.visibility_off), onPressed: ()=>setState(()=>obscure=!obscure)))),
          SizedBox(height: 20),
          SizedBox(width: double.infinity, height: 50, child: ElevatedButton(onPressed: (){
            showDialog(context: context, builder: (_)=>AlertDialog(title: Text('Login Berhasil'), content: Text('Welcome ${_email.text}'), actions: [TextButton(onPressed: ()=>Navigator.pop(context), child: Text('OK'))]));
          }, style: ElevatedButton.styleFrom(backgroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))), child: Text('LOGIN', style: TextStyle(color: Color(0xFF6A11CB), fontWeight: FontWeight.bold)))),
          SizedBox(height: 12),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            IconButton(onPressed: (){}, icon: Icon(Icons.fingerprint, color: Colors.white, size: 32)),
            SizedBox(width: 20),
            IconButton(onPressed: (){}, icon: Icon(Icons.face, color: Colors.white, size: 32)),
          ]),
          SizedBox(height: 10),
          Text('LICENSE : RIZAL | IG : rizal_d8v', style: TextStyle(color: Colors.white70, fontSize: 11))
        ]))),
      ),
    );
  }
}
