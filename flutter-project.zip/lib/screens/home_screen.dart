
import 'package:flutter/material.dart';
import '../widgets/money_card.dart';
import '../widgets/popup_widget.dart';
import '../models/transaction_model.dart';
import '../widgets/transaction_tile.dart';
import 'add_transaction_screen.dart';
import 'stats_screen.dart';
import 'budget_screen.dart';
import 'wallet_screen.dart';
import 'profile_screen.dart';
import 'goal_screen.dart';
import 'category_screen.dart';
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  double balance = 12500000;
  double income = 8000000;
  double expense = 3200000;
  List<TransactionModel> trx = [];
  int _nav = 0;
  @override
  void initState(){
    super.initState();
    trx = [
      TransactionModel(title: 'Gaji Bulanan', category: 'Pekerjaan', amount: 8000000, type: 'income', date: DateTime.now().subtract(Duration(days: 1))),
      TransactionModel(title: 'Belanja Bulanan', category: 'Belanja', amount: 1200000, type: 'expense', date: DateTime.now().subtract(Duration(days: 2))),
      TransactionModel(title: 'Top Up E-Wallet', category: 'Transport', amount: 200000, type: 'expense', date: DateTime.now()),
      TransactionModel(title: 'Freelance Project', category: 'Freelance', amount: 1500000, type: 'income', date: DateTime.now().subtract(Duration(days: 3))),
    ];
  }
  void _showQuickAdd(){
    showModalBottomSheet(context: context, isScrollControlled: true, shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(25))), builder: (_) => Padding(padding: EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, children: [
      Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2))),
      SizedBox(height: 20),
      Text('Quick Action', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      SizedBox(height: 20),
      Row(children: [
        Expanded(child: _actionBtn(Icons.add, 'Pemasukan', Colors.green, (){Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_)=>AddTransactionScreen(type: 'income')));})),
        SizedBox(width: 12),
        Expanded(child: _actionBtn(Icons.remove, 'Pengeluaran', Colors.red, (){Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_)=>AddTransactionScreen(type: 'expense')));})),
      ]),
      SizedBox(height: 12),
      Row(children: [
        Expanded(child: _actionBtn(Icons.swap_horiz, 'Transfer', Colors.blue, (){Navigator.pop(context); AppPopup.showSuccess(context, 'Fitur transfer antar dompet coming soon!');})),
        SizedBox(width: 12),
        Expanded(child: _actionBtn(Icons.qr_code_scanner, 'Scan', Colors.purple, (){Navigator.pop(context); AppPopup.showBottomInfo(context, 'Scan QR', 'Scan QR untuk bayar dan terima uang otomatis tercatat di dompetku.');})),
      ]),
      SizedBox(height: 30)
    ])));
  }
  Widget _actionBtn(IconData ic, String label, Color col, VoidCallback tap){
    return InkWell(onTap: tap, child: Container(padding: EdgeInsets.symmetric(vertical: 16), decoration: BoxDecoration(color: col.withOpacity(0.12), borderRadius: BorderRadius.circular(16), border: Border.all(color: col.withOpacity(0.3))), child: Column(children: [Icon(ic, color: col), SizedBox(height: 6), Text(label, style: TextStyle(fontWeight: FontWeight.w600, color: col))]))); 
  }
  @override
  Widget build(BuildContext context){
    List<Widget> pages = [
      _buildDashboard(),
      StatsScreen(transactions: trx),
      WalletScreen(),
      BudgetScreen(),
      ProfileScreen()
    ];
    return Scaffold(
      backgroundColor: Color(0xFFF5F7FB),
      body: pages[_nav],
      floatingActionButton: _nav==0?FloatingActionButton.extended(onPressed: _showQuickAdd, backgroundColor: Color(0xFF6A11CB), icon: Icon(Icons.bolt, color: Colors.white), label: Text('Aksi Cepat', style: TextStyle(color: Colors.white))):null,
      bottomNavigationBar: BottomNavigationBar(currentIndex: _nav, onTap: (i)=>setState(()=>_nav=i), type: BottomNavigationBarType.fixed, selectedItemColor: Color(0xFF6A11CB), items: [BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'), BottomNavigationBarItem(icon: Icon(Icons.bar_chart), label: 'Statistik'), BottomNavigationBarItem(icon: Icon(Icons.wallet), label: 'Dompet'), BottomNavigationBarItem(icon: Icon(Icons.pie_chart), label: 'Budget'), BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profil')]),
    );
  }
  Widget _buildDashboard(){
    return SafeArea(child: SingleChildScrollView(padding: EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Halo, Rizal!', style: TextStyle(fontSize: 14, color: Colors.grey)), Text('Dompetku Mobile', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))]), InkWell(onTap: (){AppPopup.showBottomInfo(context, 'Notifikasi', 'Kamu punya 3 tagihan jatuh tempo minggu ini. Cek budget untuk detail.');}, child: Stack(children: [Icon(Icons.notifications_none, size: 28), Positioned(right: 0, top: 0, child: Container(width: 10, height: 10, decoration: BoxDecoration(color: Colors.red, shape: BoxShape.circle)))]))]),
      SizedBox(height: 20),
      Container(padding: EdgeInsets.all(20), decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF6A11CB), Color(0xFF2575FC)]), borderRadius: BorderRadius.circular(24), boxShadow: [BoxShadow(color: Color(0xFF6A11CB).withOpacity(0.4), blurRadius: 20, offset: Offset(0,10))]), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Total Saldo', style: TextStyle(color: Colors.white70)), SizedBox(height: 6), Text('Rp 12.500.000', style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)), SizedBox(height: 16), Row(children: [Icon(Icons.trending_up, color: Colors.white70, size: 16), SizedBox(width: 4), Text('+12% dari bulan lalu', style: TextStyle(color: Colors.white70, fontSize: 12))])])),
      SizedBox(height: 16),
      Row(children: [Expanded(child: MoneyCard(title: 'Pemasukan', amount: income, icon: Icons.arrow_downward, color: Color(0xFF00B894))), SizedBox(width: 12), Expanded(child: MoneyCard(title: 'Pengeluaran', amount: expense, icon: Icons.arrow_upward, color: Color(0xFFD63031)))]),
      SizedBox(height: 20),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Transaksi Terbaru', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), TextButton(onPressed: (){Navigator.push(context, MaterialPageRoute(builder: (_)=>CategoryScreen()));}, child: Text('Lihat Semua'))]),
      Container(decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)), child: Column(children: trx.map((e)=>TransactionTile(trx: e, onTap: (){AppPopup.showConfirm(context, 'Hapus Transaksi?', 'Yakin hapus ${e.title}?', (){setState(()=>trx.remove(e)); AppPopup.showSuccess(context, 'Transaksi dihapus');});})).toList())),
      SizedBox(height: 20),
      Text('Fitur Super Lengkap', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
      SizedBox(height: 12),
      GridView.count(crossAxisCount: 4, shrinkWrap: true, physics: NeverScrollableScrollPhysics(), children: [
        _menu(Icons.flag, 'Goals', (){Navigator.push(context, MaterialPageRoute(builder: (_)=>GoalScreen()));}),
        _menu(Icons.category, 'Kategori', (){Navigator.push(context, MaterialPageRoute(builder: (_)=>CategoryScreen()));}),
        _menu(Icons.credit_card, 'Kartu', (){AppPopup.showSuccess(context, 'Fitur kartu virtual aktif!');}),
        _menu(Icons.receipt, 'Tagihan', (){AppPopup.showBottomInfo(context, 'Tagihan', '3 tagihan belum dibayar: Listrik, Internet, Air');}),
        _menu(Icons.savings, 'Tabungan', (){AppPopup.showSuccess(context, 'Tabungan target 80% tercapai!');}),
        _menu(Icons.security, 'Keamanan', (){AppPopup.showBottomInfo(context, 'Keamanan', 'PIN, Biometrik, dan 2FA aktif. Dompet aman.');}),
        _menu(Icons.help, 'Bantuan', (){AppPopup.showBottomInfo(context, 'Bantuan', 'IG: rizal_d8v | YT: youtube.com/@MrRall_2jt | saweria.co/rizald8vid');}),
        _menu(Icons.info, 'Tentang', (){Navigator.push(context, MaterialPageRoute(builder: (_)=>ProfileScreen()));}),
      ])
    ])));
  }
  Widget _menu(IconData ic, String label, VoidCallback tap){
    return InkWell(onTap: tap, child: Column(children: [Container(padding: EdgeInsets.all(12), decoration: BoxDecoration(color: Color(0xFF6A11CB).withOpacity(0.1), borderRadius: BorderRadius.circular(14)), child: Icon(ic, color: Color(0xFF6A11CB))), SizedBox(height: 6), Text(label, style: TextStyle(fontSize: 11))]));
  }
}
