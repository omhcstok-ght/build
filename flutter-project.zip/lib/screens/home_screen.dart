import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Dompetku V3 FORCE'), backgroundColor: const Color(0xFF6A11CB), foregroundColor: Colors.white),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(height: 140, decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF6A11CB), Color(0xFF2575FC)]), borderRadius: BorderRadius.circular(20)), child: const Padding(padding: EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Total Saldo', style: TextStyle(color: Colors.white70)), SizedBox(height: 8), Text('Rp 12.500.000', style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold))]))),
        const SizedBox(height: 20),
        GridView.count(crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), children: [
          _card(Icons.pie_chart, 'Statistik'), _card(Icons.wallet, 'Dompet'), _card(Icons.flag, 'Goals'), _card(Icons.settings, 'Pengaturan'),
        ]),
        const SizedBox(height: 20),
        const Text('LICENSE : RIZAL\nIG : rizal_d8v\nYT : youtube.com/@MrRall_2jt\nSaweria : saweria.co/rizald8vid', style: TextStyle(fontSize: 12, color: Colors.grey)),
      ]),
    );
  }
  static Widget _card(IconData ic, String t){
    return Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(ic, size: 32, color: Color(0xFF6A11CB)), SizedBox(height: 8), Text(t, style: TextStyle(fontWeight: FontWeight.bold))]))); 
  }
}