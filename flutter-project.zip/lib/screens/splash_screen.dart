
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'dart:async';
import 'home_screen.dart';
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}
class _SplashScreenState extends State<SplashScreen> {
  VideoPlayerController? _controller;
  @override
  void initState(){
    super.initState();
    _initVideo();
    Timer(Duration(seconds: 3), (){
      if(mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_)=>HomeScreen()));
    });
  }
  Future<void> _initVideo() async {
    try {
      _controller = VideoPlayerController.asset('flutter_assets/intro.mp4');
      await _controller!.initialize();
      _controller!.setLooping(true);
      _controller!.play();
      if(mounted) setState((){});
    } catch(e){
      _controller = null;
    }
  }
  @override
  void dispose(){
    _controller?.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context){
    return Scaffold(
      body: Stack(
        children: [
          Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF6A11CB), Color(0xFF2575FC)], begin: Alignment.topLeft, end: Alignment.bottomRight)), child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.account_balance_wallet, size: 80, color: Colors.white), SizedBox(height: 20), Text('Dompetku', style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold, color: Colors.white)), Text('Mobile - Super Lengkap', style: TextStyle(color: Colors.white70)), SizedBox(height: 40), if(_controller!=null && _controller!.value.isInitialized) AspectRatio(aspectRatio: _controller!.value.aspectRatio, child: VideoPlayer(_controller!)) else CircularProgressIndicator(color: Colors.white)]))),
          Positioned(bottom: 30, left: 0, right: 0, child: Column(children: [Text('LICENSE : RIZAL', style: TextStyle(color: Colors.white70, fontSize: 12)), Text('IG : rizal_d8v', style: TextStyle(color: Colors.white70, fontSize: 12)), Text('YT : youtube.com/@MrRall_2jt', style: TextStyle(color: Colors.white70, fontSize: 12))]))
        ],
      ),
    );
  }
}
