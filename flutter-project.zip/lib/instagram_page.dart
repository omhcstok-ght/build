// lib/instagram_page.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'api_config.dart';
import 'app_theme.dart';

class InstagramDownloaderPage extends StatefulWidget {
  const InstagramDownloaderPage({super.key});

  @override
  State<InstagramDownloaderPage> createState() =>
      _InstagramDownloaderPageState();
}

class _InstagramDownloaderPageState extends State<InstagramDownloaderPage> {
  final TextEditingController _urlController = TextEditingController();
  bool _isLoading = false;
  bool _isSharing = false;
  int _sharingIndex = -1;
  String? _errorMessage;
  Map<String, dynamic>? _mediaData;
  List<Map<String, dynamic>> _medias = [];

  VideoPlayerController? _videoController;
  ChewieController? _chewieController;

  @override
  void dispose() {
    _urlController.dispose();
    _videoController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  Future<void> _downloadInstagram() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      setState(() {
        _errorMessage = "URL Instagram tidak boleh kosong.";
        _mediaData = null;
        _medias = [];
      });
      return;
    }

    if (!url.contains('instagram.com') && !url.contains('instagr.am')) {
      setState(() {
        _errorMessage = "Link harus dari Instagram (instagram.com / instagr.am)";
        _mediaData = null;
        _medias = [];
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _mediaData = null;
      _medias = [];
      _videoController?.dispose();
      _chewieController?.dispose();
      _videoController = null;
      _chewieController = null;
    });

    try {
      final apiUrl =
          '$baseUrl/instagram/download?url=${Uri.encodeComponent(url)}';

      final res = await http.get(
        Uri.parse(apiUrl),
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 13)',
          'Accept': 'application/json',
        },
      ).timeout(const Duration(seconds: 45));

      if (res.statusCode != 200) {
        setState(() {
          _errorMessage = 'Server error (${res.statusCode}). Coba lagi nanti.';
        });
        return;
      }

      final json = jsonDecode(res.body) as Map<String, dynamic>;

      if (json['valid'] != true) {
        setState(() {
          _errorMessage = json['message'] ?? 'Gagal ambil data Instagram';
        });
        return;
      }

      final medias = List<Map<String, dynamic>>.from(json['medias'] ?? []);

      if (medias.isEmpty) {
        setState(() {
          _errorMessage = 'Media Instagram kosong / tidak valid';
        });
        return;
      }

      setState(() {
        _mediaData = {
          'source': json['source'] ?? 'unknown',
          'title': json['title'] ?? 'Instagram Post',
          'author': json['author'] ?? 'Unknown',
          'thumbnail': json['thumbnail'] ?? '',
          'total': json['total'] ?? medias.length,
        };
        _medias = medias;
      });

      final firstVideo = medias.firstWhere(
        (m) => m['type'] == 'video',
        orElse: () => {},
      );
      if (firstVideo.isNotEmpty && (firstVideo['url'] as String).isNotEmpty) {
        _initializeVideoPlayer(videoUrl: firstVideo['url']);
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Terjadi kesalahan: $e';
      });
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _initializeVideoPlayer({required String videoUrl}) {
    _videoController = VideoPlayerController.networkUrl(
      Uri.parse(videoUrl),
      httpHeaders: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 13)',
        'Accept': '*/*',
      },
    );

    Future.delayed(const Duration(seconds: 20), () {
      if (!mounted) return;
      if (_videoController?.value.isInitialized != true) {
        setState(() {
          _errorMessage =
              'Video loading timeout. Koneksi lambat / URL ga valid.';
        });
        _videoController?.dispose();
      }
    });

    _videoController!.initialize().then((_) {
      if (!mounted) return;
      final C = AppTheme.current.value;
      setState(() {
        _chewieController = ChewieController(
          videoPlayerController: _videoController!,
          autoPlay: true,
          looping: false,
          showControls: true,
          materialProgressColors: ChewieProgressColors(
            playedColor: C.accent,
            handleColor: C.accentHi,
            backgroundColor: C.bgDark,
            bufferedColor: C.bg,
          ),
        );
      });
    }).catchError((e) {
      if (mounted) {
        setState(() {
          _errorMessage = 'Gagal load video player: $e';
        });
      }
    });
  }

  Future<void> _shareMedia(int index, AppPalette C) async {
    if (index < 0 || index >= _medias.length) return;

    setState(() {
      _isSharing = true;
      _sharingIndex = index;
    });

    try {
      final media = _medias[index];
      final mediaUrl = media['url'] as String?;
      final type = media['type'] as String? ?? 'video';

      if (mediaUrl == null || mediaUrl.isEmpty) {
        _showSnack('URL media tidak tersedia', isError: true, C: C);
        return;
      }

      final res = await http.get(
        Uri.parse(mediaUrl),
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 13)',
          'Accept': '*/*',
        },
      ).timeout(const Duration(seconds: 60));

      if (res.statusCode != 200) {
        _showSnack('Gagal download media: ${res.statusCode}',
            isError: true, C: C);
        return;
      }

      final tempDir = await getTemporaryDirectory();
      final ext = type == 'video' ? 'mp4' : 'jpg';
      final fileName =
          'instagram_${DateTime.now().millisecondsSinceEpoch}.$ext';
      final file = File('${tempDir.path}/$fileName');
      await file.writeAsBytes(res.bodyBytes);

      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Media Instagram dari: ${_mediaData?['author'] ?? 'Unknown'}',
      );
    } catch (e) {
      _showSnack('Error sharing: $e', isError: true, C: C);
    } finally {
      if (mounted) {
        setState(() {
          _isSharing = false;
          _sharingIndex = -1;
        });
      }
    }
  }

  void _pasteFromClipboard() async {
    final data = await Clipboard.getData('text/plain');
    if (data != null && data.text != null && data.text!.isNotEmpty) {
      setState(() {
        _urlController.text = data.text!.trim();
      });
      HapticFeedback.lightImpact();
    }
  }

  void _showSnack(String msg, {bool isError = false, required AppPalette C}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
        backgroundColor: isError ? C.primaryLo : C.primary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: C.accent.withOpacity(0.3)),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BUILDERS
  // ═══════════════════════════════════════════════════════════
  Widget _buildGlassCard({
    required AppPalette C,
    required bool isComic,
    required Widget child,
    EdgeInsetsGeometry? padding,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: padding ?? const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: isComic ? C.bgDark : null,
        gradient: isComic
            ? null
            : LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [C.bg, C.bgDark, C.bgDeep],
              ),
        borderRadius: BorderRadius.circular(isComic ? 20 : 16),
        border: Border.all(
          color: isComic ? Colors.black : C.accent.withOpacity(0.4),
          width: isComic ? 4 : 1.5,
        ),
        boxShadow: isComic
            ? const [
                BoxShadow(
                    color: Colors.black, offset: Offset(5, 5), blurRadius: 0),
              ]
            : [
                BoxShadow(
                  color: C.accent.withOpacity(0.18),
                  blurRadius: 22,
                  spreadRadius: 2,
                ),
              ],
      ),
      child: child,
    );
  }

  Widget _buildGlassInputField(AppPalette C, bool isComic) {
    return Container(
      decoration: BoxDecoration(
        color: C.bgDeep,
        borderRadius: BorderRadius.circular(isComic ? 14 : 12),
        border: Border.all(
          color: isComic ? Colors.black : C.accent.withOpacity(0.5),
          width: isComic ? 3 : 1.5,
        ),
      ),
      child: TextField(
        controller: _urlController,
        style: TextStyle(
          color: isComic ? C.comicText : C.text,
          fontSize: 14,
          fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
          fontWeight: FontWeight.w600,
        ),
        cursorColor: C.accent,
        decoration: InputDecoration(
          labelText: 'Masukkan URL Instagram',
          labelStyle: TextStyle(
            color: isComic ? C.comicTextSub : C.textSub,
            fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
            fontSize: 12,
          ),
          hintText: 'Contoh: https://www.instagram.com/reel/xxx/',
          hintStyle: TextStyle(
            color: isComic ? C.comicTextMuted : C.textSub.withOpacity(0.5),
            fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
            fontSize: 11,
          ),
          prefixIcon: Icon(Icons.link, color: C.accent, size: 18),
          suffixIcon: GestureDetector(
            onTap: _pasteFromClipboard,
            child: Container(
              margin: const EdgeInsets.all(8),
              padding: const EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                color: C.accent.withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: C.accent.withOpacity(0.4)),
              ),
              child: Center(
                widthFactor: 1,
                child: Text(
                  'PASTE',
                  style: TextStyle(
                    color: C.accentHi,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
              ),
            ),
          ),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required AppPalette C,
    required bool isComic,
    required String text,
    required IconData icon,
    required VoidCallback onPressed,
    required Color color,
    bool isLoading = false,
  }) {
    final textColor = isComic ? C.contrastTextOn(color) : Colors.white;
    final outline = textColor == Colors.white ? Colors.black : Colors.white;

    return GestureDetector(
      onTap: isLoading ? null : onPressed,
      child: Container(
        height: 54,
        decoration: BoxDecoration(
          color: isComic ? color : null,
          gradient: isComic
              ? null
              : LinearGradient(
                  colors: [color.withOpacity(0.9), color.withOpacity(0.65)],
                ),
          borderRadius: BorderRadius.circular(isComic ? 12 : 16),
          border: Border.all(
            color: isComic ? Colors.black : color.withOpacity(0.8),
            width: isComic ? 3.5 : 1.5,
          ),
          boxShadow: isComic
              ? const [
                  BoxShadow(
                      color: Colors.black,
                      offset: Offset(4, 4),
                      blurRadius: 0),
                ]
              : [
                  BoxShadow(
                    color: color.withOpacity(0.35),
                    blurRadius: 15,
                    spreadRadius: 1,
                  ),
                ],
        ),
        child: Center(
          child: isLoading
              ? SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: textColor,
                  ),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(icon, color: textColor, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      text,
                      style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w900,
                        fontSize: isComic ? 15 : 13,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: isComic ? 1 : 1.5,
                        shadows: isComic
                            ? [
                                Shadow(
                                  color: outline,
                                  offset: const Offset(1, 1),
                                  blurRadius: 0,
                                ),
                              ]
                            : null,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bgDeep,
              body: Container(
                decoration: BoxDecoration(
                  gradient: isComic
                      ? null
                      : RadialGradient(
                          center: const Alignment(-0.3, -0.3),
                          radius: 1.2,
                          colors: [C.bg, C.bgDark, C.bgDeep],
                        ),
                  color: isComic ? C.bg : null,
                ),
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        _buildGlassCard(
                          C: C,
                          isComic: isComic,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.camera_alt,
                                  color: C.accent, size: 28),
                              const SizedBox(width: 12),
                              Text(
                                "INSTAGRAM DL",
                                style: TextStyle(
                                  fontSize: isComic ? 20 : 18,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: isComic ? 2 : 3,
                                  color: isComic ? C.comicText : C.text,
                                  fontFamily:
                                      isComic ? 'Bangers' : 'Orbitron',
                                  shadows: isComic
                                      ? [
                                          Shadow(
                                            color: C.comicTextOutline,
                                            offset: const Offset(2, 2),
                                            blurRadius: 0,
                                          ),
                                        ]
                                      : null,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        _buildGlassCard(
                          C: C,
                          isComic: isComic,
                          child: Column(
                            children: [
                              _buildGlassInputField(C, isComic),
                              const SizedBox(height: 14),
                              _buildActionButton(
                                C: C,
                                isComic: isComic,
                                text: "DOWNLOAD",
                                icon: Icons.download,
                                onPressed: _downloadInstagram,
                                color: C.primaryHi,
                                isLoading: _isLoading,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),
                        if (_errorMessage != null)
                          _buildGlassCard(
                            C: C,
                            isComic: isComic,
                            child: Row(
                              children: [
                                Icon(Icons.error_outline,
                                    color: C.primaryHi, size: 20),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Text(
                                    _errorMessage!,
                                    style: TextStyle(
                                      color: isComic
                                          ? C.comicText
                                          : C.text.withOpacity(0.8),
                                      fontSize: 12,
                                      fontFamily: isComic
                                          ? 'ComicNeue'
                                          : 'ShareTechMono',
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        if (_mediaData != null)
                          Expanded(
                            child: SingleChildScrollView(
                              child: Column(
                                children: [
                                  _buildGlassCard(
                                    C: C,
                                    isComic: isComic,
                                    padding: const EdgeInsets.all(14),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            Icon(Icons.person,
                                                color: C.accent, size: 16),
                                            const SizedBox(width: 8),
                                            Expanded(
                                              child: Text(
                                                _mediaData!['author'] ??
                                                    'Unknown',
                                                style: TextStyle(
                                                  color: isComic
                                                      ? C.comicText
                                                      : C.text,
                                                  fontWeight: FontWeight.w900,
                                                  fontSize: 13,
                                                  fontFamily: isComic
                                                      ? 'Bangers'
                                                      : 'Orbitron',
                                                ),
                                              ),
                                            ),
                                            Container(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 8,
                                                      vertical: 2),
                                              decoration: BoxDecoration(
                                                color: C.accent
                                                    .withOpacity(0.15),
                                                borderRadius:
                                                    BorderRadius.circular(6),
                                                border: Border.all(
                                                    color: C.accent
                                                        .withOpacity(0.4)),
                                              ),
                                              child: Text(
                                                (_mediaData!['source'] ??
                                                        'N/A')
                                                    .toString()
                                                    .toUpperCase(),
                                                style: TextStyle(
                                                  color: C.accentHi,
                                                  fontSize: 9,
                                                  fontWeight: FontWeight.w900,
                                                  fontFamily: isComic
                                                      ? 'Bangers'
                                                      : 'Orbitron',
                                                  letterSpacing: 1,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 6),
                                        Text(
                                          _mediaData!['title'] ?? '',
                                          style: TextStyle(
                                            color: isComic
                                                ? C.comicTextSub
                                                : C.text
                                                    .withOpacity(0.75),
                                            fontSize: 11,
                                            height: 1.4,
                                            fontFamily: isComic
                                                ? 'ComicNeue'
                                                : 'ShareTechMono',
                                          ),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        const SizedBox(height: 6),
                                        Row(
                                          children: [
                                            Icon(Icons.collections,
                                                color: C.textSub, size: 14),
                                            const SizedBox(width: 6),
                                            Text(
                                              '${_mediaData!['total']} media ditemukan',
                                              style: TextStyle(
                                                color: isComic
                                                    ? C.comicTextSub
                                                    : C.textSub,
                                                fontSize: 10,
                                                fontFamily: isComic
                                                    ? 'ComicNeue'
                                                    : 'ShareTechMono',
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  if (_chewieController != null)
                                    _buildGlassCard(
                                      C: C,
                                      isComic: isComic,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(14),
                                          border: Border.all(
                                            color: isComic
                                                ? Colors.black
                                                : C.accent
                                                    .withOpacity(0.4),
                                            width: isComic ? 3 : 1.5,
                                          ),
                                        ),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(12),
                                          child: AspectRatio(
                                            aspectRatio:
                                                _videoController!.value
                                                        .isInitialized ==
                                                    true
                                                    ? _videoController!
                                                        .value.aspectRatio
                                                    : 9 / 16,
                                            child: Chewie(
                                                controller:
                                                    _chewieController!),
                                          ),
                                        ),
                                      ),
                                    ),
                                  const SizedBox(height: 10),
                                  ...List.generate(_medias.length, (i) {
                                    final media = _medias[i];
                                    final isVideo =
                                        media['type'] == 'video';
                                    final isSharingThis =
                                        _isSharing && _sharingIndex == i;

                                    return _buildGlassCard(
                                      C: C,
                                      isComic: isComic,
                                      padding: const EdgeInsets.all(12),
                                      child: Row(
                                        children: [
                                          Container(
                                            width: 56,
                                            height: 56,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              border: Border.all(
                                                color: C.accent
                                                    .withOpacity(0.4),
                                                width: isComic ? 2.5 : 1.5,
                                              ),
                                              image: (media['thumbnail'] ??
                                                          '')
                                                      .toString()
                                                      .isNotEmpty
                                                  ? DecorationImage(
                                                      image: NetworkImage(
                                                          media['thumbnail']),
                                                      fit: BoxFit.cover,
                                                    )
                                                  : null,
                                              color: C.bgDeep,
                                            ),
                                            child: (media['thumbnail'] ?? '')
                                                    .toString()
                                                    .isEmpty
                                                ? Icon(
                                                    isVideo
                                                        ? Icons.videocam
                                                        : Icons.image,
                                                    color: C.accent,
                                                    size: 22,
                                                  )
                                                : null,
                                          ),
                                          const SizedBox(width: 12),
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  isVideo
                                                      ? 'VIDEO ${i + 1}'
                                                      : 'FOTO ${i + 1}',
                                                  style: TextStyle(
                                                    color: isComic
                                                        ? C.comicText
                                                        : C.text,
                                                    fontWeight: FontWeight.w900,
                                                    fontSize: 12,
                                                    fontFamily: isComic
                                                        ? 'Bangers'
                                                        : 'Orbitron',
                                                    letterSpacing: 1,
                                                  ),
                                                ),
                                                const SizedBox(height: 2),
                                                Text(
                                                  isVideo
                                                      ? 'Video MP4'
                                                      : 'Gambar JPG',
                                                  style: TextStyle(
                                                    color: isComic
                                                        ? C.comicTextSub
                                                        : C.textSub,
                                                    fontSize: 10,
                                                    fontFamily: isComic
                                                        ? 'ComicNeue'
                                                        : 'ShareTechMono',
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          GestureDetector(
                                            onTap: isSharingThis
                                                ? null
                                                : () => _shareMedia(i, C),
                                            child: Container(
                                              width: 42,
                                              height: 42,
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                color: isSharingThis
                                                    ? C.textSub
                                                    : C.primaryHi,
                                                border: Border.all(
                                                  color: isComic
                                                      ? Colors.black
                                                      : C.primaryLo,
                                                  width: isComic ? 2.5 : 1.5,
                                                ),
                                                boxShadow: isComic
                                                    ? const [
                                                        BoxShadow(
                                                          color: Colors.black,
                                                          offset:
                                                              Offset(2, 2),
                                                          blurRadius: 0,
                                                        ),
                                                      ]
                                                    : null,
                                              ),
                                              child: isSharingThis
                                                  ? const Padding(
                                                      padding:
                                                          EdgeInsets.all(11),
                                                      child:
                                                          CircularProgressIndicator(
                                                        strokeWidth: 2,
                                                        color: Colors.white,
                                                      ),
                                                    )
                                                  : Icon(
                                                      Icons.download,
                                                      color: isComic
                                                          ? C.contrastTextOn(
                                                              C.primaryHi)
                                                          : Colors.white,
                                                      size: 20,
                                                    ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  }),
                                  const SizedBox(height: 12),
                                  _buildGlassCard(
                                    C: C,
                                    isComic: isComic,
                                    padding: const EdgeInsets.all(14),
                                    child: Row(
                                      children: [
                                        Icon(Icons.info,
                                            color: C.accent, size: 16),
                                        const SizedBox(width: 10),
                                        Expanded(
                                          child: Text(
                                            "Tiap media bisa di-share / save terpisah. Tap tombol download di tiap item.",
                                            style: TextStyle(
                                              color: isComic
                                                  ? C.comicTextSub
                                                  : C.textSub,
                                              fontSize: 11,
                                              height: 1.5,
                                              fontFamily: isComic
                                                  ? 'ComicNeue'
                                                  : 'ShareTechMono',
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }
}