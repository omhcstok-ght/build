
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/transaction_model.dart';
class TransactionTile extends StatelessWidget {
  final TransactionModel trx;
  final VoidCallback? onTap;
  const TransactionTile({super.key, required this.trx, this.onTap});
  @override
  Widget build(BuildContext context){
    bool isIncome = trx.type=='income';
    return ListTile(
      onTap: onTap,
      leading: CircleAvatar(backgroundColor: isIncome?Colors.green.withOpacity(0.15):Colors.red.withOpacity(0.15), child: Icon(isIncome?Icons.arrow_downward:Icons.arrow_upward, color: isIncome?Colors.green:Colors.red)),
      title: Text(trx.title, style: TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text('${trx.category} - ${DateFormat('dd MMM yyyy').format(trx.date)}'),
      trailing: Text('${isIncome?'+':''-'} ${NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0).format(trx.amount)}', style: TextStyle(color: isIncome?Colors.green:Colors.red, fontWeight: FontWeight.bold)),
    );
  }
}
