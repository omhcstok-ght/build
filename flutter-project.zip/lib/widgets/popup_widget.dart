
import 'package:flutter/material.dart';
class AppPopup {
  static void showSuccess(BuildContext c, String msg){
    showDialog(context: c, builder: (_) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Row(children: [Icon(Icons.check_circle, color: Colors.green), SizedBox(width: 10), Text('Berhasil')]),
      content: Text(msg),
      actions: [TextButton(onPressed: ()=>Navigator.pop(c), child: Text('OK'))],
    ));
  }
  static void showError(BuildContext c, String msg){
    showDialog(context: c, builder: (_) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Row(children: [Icon(Icons.error, color: Colors.red), SizedBox(width: 10), Text('Oops')]),
      content: Text(msg),
      actions: [TextButton(onPressed: ()=>Navigator.pop(c), child: Text('Tutup'))],
    ));
  }
  static void showConfirm(BuildContext c, String title, String msg, VoidCallback onYes){
    showDialog(context: c, builder: (_) => AlertDialog(
      title: Text(title),
      content: Text(msg),
      actions: [
        TextButton(onPressed: ()=>Navigator.pop(c), child: Text('Batal')),
        ElevatedButton(onPressed: (){Navigator.pop(c); onYes();}, child: Text('Ya'))
      ],
    ));
  }
  static void showBottomInfo(BuildContext c, String title, String desc){
    showModalBottomSheet(context: c, shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(25))), builder: (_) => Padding(padding: EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), SizedBox(height: 10), Text(desc), SizedBox(height: 20), SizedBox(width: double.infinity, child: ElevatedButton(onPressed: ()=>Navigator.pop(c), child: Text('Mengerti')))])));
  }
}
