
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
class MoneyCard extends StatelessWidget {
  final String title;
  final double amount;
  final IconData icon;
  final Color color;
  const MoneyCard({super.key, required this.title, required this.amount, required this.icon, required this.color});
  @override
  Widget build(BuildContext context){
    final f = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(20), boxShadow: [BoxShadow(color: color.withOpacity(0.3), blurRadius: 10, offset: Offset(0,5))]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: Colors.white, size: 28),
        SizedBox(height: 12),
        Text(title, style: TextStyle(color: Colors.white70)),
        SizedBox(height: 4),
        Text(f.format(amount), style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18))
      ]),
    );
  }
}
