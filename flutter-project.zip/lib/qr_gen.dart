// lib/qr_gen.dart
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'app_theme.dart';

class QrGeneratorPage extends StatefulWidget {
  const QrGeneratorPage({super.key});

  @override
  State<QrGeneratorPage> createState() => _QrGeneratorPageState();
}

class _QrGeneratorPageState extends State<QrGeneratorPage> {
  final TextEditingController _textController = TextEditingController();
  bool _isLoading = false;
  Uint8List? _qrImage;
  String? _errorMessage;

  Future<void> _generateQR() async {
    final text = _textController.text.trim();
    if (text.isEmpty) {
      setState(() {
        _errorMessage = "Text tidak boleh kosong.";
        _qrImage = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _qrImage = null;
    });

    final encodedText = Uri.encodeComponent(text);
    final url = Uri.parse(
        "https://api.siputzx.my.id/api/tools/text2qr?text=$encodedText");

    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        setState(() {
          _qrImage = response.bodyBytes;
          _errorMessage = null;
        });
      } else {
        setState(() {
          _errorMessage = "Gagal generate QR Code.";
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = "Terjadi kesalahan: $e";
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _shareQR(AppPalette C) async {
    if (_qrImage == null) return;

    try {
      final tempDir = await getTemporaryDirectory();
      final file = File(
          '${tempDir.path}/qr_code_${DateTime.now().millisecondsSinceEpoch}.png');
      await file.writeAsBytes(_qrImage!);

      await Share.shareXFiles([XFile(file.path)],
          text: 'QR Code dari: ${_textController.text}');
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error sharing: $e'),
          backgroundColor: C.bgDark,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: C.accent.withOpacity(0.3)),
          ),
        ),
      );
    }
  }

  // ═══════════════════════════════════════════════════════════
  // GLASS CARD
  // ═══════════════════════════════════════════════════════════
  Widget _buildGlassCard({
    required AppPalette C,
    required bool isComic,
    required Widget child,
    EdgeInsetsGeometry? padding,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: padding ?? const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: isComic ? C.bgDark : null,
        gradient: isComic
            ? null
            : LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [C.bg, C.bgDark, C.bgDeep],
                stops: const [0.0, 0.5, 1.0],
              ),
        borderRadius: BorderRadius.circular(isComic ? 20 : 16),
        border: Border.all(
          color: isComic ? Colors.black : C.accent.withOpacity(0.4),
          width: isComic ? 4 : 1.5,
        ),
        boxShadow: isComic
            ? const [
                BoxShadow(
                    color: Colors.black, offset: Offset(5, 5), blurRadius: 0),
              ]
            : [
                BoxShadow(
                  color: C.accent.withOpacity(0.18),
                  blurRadius: 22,
                  spreadRadius: 2,
                ),
              ],
      ),
      child: child,
    );
  }

  // ═══════════════════════════════════════════════════════════
  // INPUT FIELD
  // ═══════════════════════════════════════════════════════════
  Widget _buildGlassInputField(AppPalette C, bool isComic) {
    return Container(
      decoration: BoxDecoration(
        color: C.bgDeep,
        borderRadius: BorderRadius.circular(isComic ? 14 : 12),
        border: Border.all(
          color: isComic ? Colors.black : C.accent.withOpacity(0.5),
          width: isComic ? 3 : 1.5,
        ),
      ),
      child: TextField(
        controller: _textController,
        style: TextStyle(
          color: isComic ? C.comicText : C.text,
          fontSize: 14,
          fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
          fontWeight: FontWeight.w600,
        ),
        cursorColor: C.accent,
        decoration: InputDecoration(
          labelText: 'Masukkan Text/URL',
          labelStyle: TextStyle(
            color: isComic ? C.comicTextSub : C.textSub,
            fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
            fontSize: 12,
          ),
          hintText: 'Contoh: https://google.com',
          hintStyle: TextStyle(
            color: isComic ? C.comicTextMuted : C.textSub.withOpacity(0.5),
            fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
            fontSize: 12,
          ),
          prefixIcon: Icon(Icons.text_fields, color: C.accent, size: 18),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
        onSubmitted: (_) => _generateQR(),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // ACTION BUTTON
  // ═══════════════════════════════════════════════════════════
  Widget _buildActionButton({
    required AppPalette C,
    required bool isComic,
    required String text,
    required IconData icon,
    required VoidCallback onPressed,
    required Color color,
    bool isLoading = false,
  }) {
    final textColor = isComic ? C.contrastTextOn(color) : Colors.white;
    final outlineColor =
        textColor == Colors.white ? Colors.black : Colors.white;

    return GestureDetector(
      onTap: isLoading ? null : onPressed,
      child: Container(
        height: 54,
        decoration: BoxDecoration(
          color: isComic ? color : null,
          gradient: isComic
              ? null
              : LinearGradient(
                  colors: [color.withOpacity(0.9), color.withOpacity(0.65)],
                ),
          borderRadius: BorderRadius.circular(isComic ? 12 : 16),
          border: Border.all(
            color: isComic
                ? Colors.black
                : color.withOpacity(0.8),
            width: isComic ? 3.5 : 1.5,
          ),
          boxShadow: isComic
              ? const [
                  BoxShadow(
                      color: Colors.black, offset: Offset(4, 4), blurRadius: 0),
                ]
              : [
                  BoxShadow(
                    color: color.withOpacity(0.35),
                    blurRadius: 15,
                    spreadRadius: 1,
                  ),
                ],
        ),
        child: Center(
          child: isLoading
              ? SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: textColor,
                  ),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(icon, color: textColor, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      text,
                      style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w900,
                        fontSize: isComic ? 15 : 13,
                        fontFamily: isComic ? 'Bangers' : 'Orbitron',
                        letterSpacing: isComic ? 1 : 1.5,
                        shadows: isComic
                            ? [
                                Shadow(
                                  color: outlineColor,
                                  offset: const Offset(1, 1),
                                  blurRadius: 0,
                                ),
                              ]
                            : null,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bgDeep,
              body: Stack(
                children: [
                  if (!isComic) ...[
                    Positioned(
                      top: -100,
                      right: -100,
                      child: Container(
                        width: 300,
                        height: 300,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(
                            colors: [
                              C.accent.withOpacity(0.1),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: -150,
                      left: -100,
                      child: Container(
                        width: 400,
                        height: 400,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(
                            colors: [
                              C.primaryLo.withOpacity(0.08),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                  Container(
                    decoration: BoxDecoration(
                      gradient: isComic
                          ? null
                          : LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [C.bg, C.bgDark, C.bgDeep],
                            ),
                      color: isComic ? C.bg : null,
                    ),
                  ),
                  SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          _buildGlassCard(
                            C: C,
                            isComic: isComic,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.qr_code, color: C.accent, size: 28),
                                const SizedBox(width: 12),
                                Text(
                                  "QR GENERATOR",
                                  style: TextStyle(
                                    fontSize: isComic ? 22 : 18,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: isComic ? 2 : 3,
                                    color: isComic ? C.comicText : C.text,
                                    fontFamily:
                                        isComic ? 'Bangers' : 'Orbitron',
                                    shadows: isComic
                                        ? [
                                            Shadow(
                                              color: C.comicTextOutline,
                                              offset: const Offset(2, 2),
                                              blurRadius: 0,
                                            ),
                                          ]
                                        : null,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 20),
                          _buildGlassCard(
                            C: C,
                            isComic: isComic,
                            child: Column(
                              children: [
                                _buildGlassInputField(C, isComic),
                                const SizedBox(height: 16),
                                _buildActionButton(
                                  C: C,
                                  isComic: isComic,
                                  text: "GENERATE QR",
                                  icon: Icons.qr_code,
                                  onPressed: _generateQR,
                                  color: C.primaryHi,
                                  isLoading: _isLoading,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 16),
                          if (_errorMessage != null)
                            _buildGlassCard(
                              C: C,
                              isComic: isComic,
                              child: Row(
                                children: [
                                  Icon(Icons.error_outline,
                                      color: C.primaryHi, size: 20),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Text(
                                      _errorMessage!,
                                      style: TextStyle(
                                        color: isComic
                                            ? C.comicText
                                            : C.text.withOpacity(0.8),
                                        fontSize: 12,
                                        fontFamily: isComic
                                            ? 'ComicNeue'
                                            : 'ShareTechMono',
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          const SizedBox(height: 16),
                          if (_qrImage != null)
                            Expanded(
                              child: SingleChildScrollView(
                                child: Column(
                                  children: [
                                    _buildGlassCard(
                                      C: C,
                                      isComic: isComic,
                                      child: Column(
                                        children: [
                                          Container(
                                            padding: const EdgeInsets.all(16),
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                              border: Border.all(
                                                color: isComic
                                                    ? Colors.black
                                                    : C.accent,
                                                width: isComic ? 3 : 1.5,
                                              ),
                                            ),
                                            child: Image.memory(_qrImage!),
                                          ),
                                          const SizedBox(height: 16),
                                          Container(
                                            padding: const EdgeInsets.all(10),
                                            decoration: BoxDecoration(
                                              color: C.bgDeep,
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              border: Border.all(
                                                color: isComic
                                                    ? Colors.black
                                                    : C.accent
                                                        .withOpacity(0.3),
                                                width: isComic ? 2.5 : 1,
                                              ),
                                            ),
                                            child: Row(
                                              children: [
                                                Icon(
                                                    Icons.text_snippet,
                                                    color: C.accent,
                                                    size: 14),
                                                const SizedBox(width: 8),
                                                Expanded(
                                                  child: Text(
                                                    _textController.text,
                                                    style: TextStyle(
                                                      color: isComic
                                                          ? C.comicTextSub
                                                          : C.textSub,
                                                      fontSize: 11,
                                                      fontFamily: isComic
                                                          ? 'ComicNeue'
                                                          : 'ShareTechMono',
                                                    ),
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          const SizedBox(height: 16),
                                          _buildActionButton(
                                            C: C,
                                            isComic: isComic,
                                            text: "SHARE QR CODE",
                                            icon: Icons.share,
                                            onPressed: () => _shareQR(C),
                                            color: C.primaryLo,
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(height: 12),
                                    _buildGlassCard(
                                      C: C,
                                      isComic: isComic,
                                      padding: const EdgeInsets.all(14),
                                      child: Row(
                                        children: [
                                          Icon(Icons.info,
                                              color: C.accent, size: 16),
                                          const SizedBox(width: 10),
                                          Expanded(
                                            child: Text(
                                              "QR Code berhasil digenerate dari teks/URL",
                                              style: TextStyle(
                                                color: isComic
                                                    ? C.comicTextSub
                                                    : C.textSub,
                                                fontSize: 11,
                                                fontFamily: isComic
                                                    ? 'ComicNeue'
                                                    : 'ShareTechMono',
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}