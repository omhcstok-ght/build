
class BudgetModel {
  String category;
  double limit;
  double spent;
  BudgetModel({required this.category, required this.limit, required this.spent});
  double get percent => limit==0?0:spent/limit;
}
