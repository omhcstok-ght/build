
class WalletModel {
  String id;
  String name;
  double balance;
  String icon;
  String color;
  WalletModel({required this.id, required this.name, required this.balance, required this.icon, required this.color});
}
