
import 'package:uuid/uuid.dart';
class TransactionModel {
  String id;
  String title;
  String category;
  double amount;
  String type;
  DateTime date;
  String note;
  String walletId;
  TransactionModel({required this.title, required this.category, required this.amount, required this.type, required this.date, this.note = '', this.walletId = 'main', String? id}) : id = id ?? Uuid().v4();
  Map<String, dynamic> toMap() => {'id': id, 'title': title, 'category': category, 'amount': amount, 'type': type, 'date': date.toIso8601String(), 'note': note, 'walletId': walletId};
  factory TransactionModel.fromMap(Map<String, dynamic> m) => TransactionModel(id: m['id'], title: m['title'], category: m['category'], amount: m['amount']+0.0, type: m['type'], date: DateTime.parse(m['date']), note: m['note'] ?? '', walletId: m['walletId'] ?? 'main');
}
