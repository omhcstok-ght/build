// ignore_for_file: use_build_context_synchronously
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'dart:ui';
// TAMBAHAN IMPORT UNTUK AUDIO PLAYER
import 'package:audioplayers/audioplayers.dart';

import 'telegram.dart';
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'ddos_page.dart';
import 'chat_page.dart';
import 'login_page.dart';
import 'custom_bug.dart';
import 'bug_group.dart';
import 'ddos_panel.dart';
import 'sender_page.dart';
import 'spams_page.dart';
import 'public_page.dart';
import 'device_dashboard.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;
  final List<Map<String, dynamic>> listDDoS;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listPayload,
    required this.listDDoS,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  VideoPlayerController? _videoController;
  VideoPlayerController? _statsVideoController; 
  VideoPlayerController? _otaxVideoController;

  // MUSIC PLAYER SETUP
  final AudioPlayer _audioPlayer = AudioPlayer();
  final String _backgroundMusicUrl = "https://k.top4top.io/m_375871wig1.m4a";

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listPayload;
  late List<Map<String, dynamic>> listDDoS;
  late List<dynamic> newsList;
  String androidId = "unknown";

  int _selectedIndex = 0;
  Widget _selectedPage = const Placeholder();

  final GlobalKey _bugButtonKey = GlobalKey();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  final PageController _pageController = PageController(viewportFraction: 0.85);
  int _currentNewsIndex = 0;

  final PageController _actionPageController = PageController(viewportFraction: 0.90);
  int _currentActionIndex = 0;

  List<Map<String, dynamic>> _activityLogs = [];
  bool _isLoadingActivityLogs = false;
  bool _hasActivityLogsError = false;

  Offset _assistiveTouchPosition = const Offset(20, 150);
  bool _isAssistiveMenuOpen = false;
  
  bool _isBugToolsExpanded = false;
  String _activePage = 'home';

  // SETTINGS STATE VARIABLES
  bool _showBottomNav = true;
  bool _showAssistiveTouch = true;
  bool _isMusicOn = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listPayload = widget.listPayload;
    listDDoS = widget.listDDoS;
    newsList = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _selectedPage = _buildNewsPage();

    _initAndroidIdAndConnect();
    _fetchActivityLogs();
    _initVideoBackground();
    _initAudioPlayer();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _videoController?.play();
      _statsVideoController?.play();
      _otaxVideoController?.play();
    }
  }

  void _initAudioPlayer() {
    _audioPlayer.setReleaseMode(ReleaseMode.loop);
  }

  void _toggleBackgroundMusic(bool isPlaying) async {
    setState(() {
      _isMusicOn = isPlaying;
    });

    if (isPlaying) {
      await _audioPlayer.play(UrlSource(_backgroundMusicUrl), volume: 0.5);
      _videoController?.setVolume(0.0);
      _statsVideoController?.setVolume(0.0);
      _otaxVideoController?.setVolume(0.0);
    } else {
      await _audioPlayer.pause();
    }
  }

  Future<void> _initVideoBackground() async {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/heder.mp4');
      await _videoController!.initialize();
      _videoController!.setLooping(true);
      _videoController!.setVolume(0.0);
      await _videoController!.play();

      _statsVideoController = VideoPlayerController.asset('assets/videos/bnb.mp4');
      await _statsVideoController!.initialize();
      _statsVideoController!.setLooping(true);
      _statsVideoController!.setVolume(0.0);
      await _statsVideoController!.play();

      _otaxVideoController = VideoPlayerController.asset('assets/videos/animek.mp4');
      await _otaxVideoController!.initialize();
      _otaxVideoController!.setLooping(true);
      _otaxVideoController!.setVolume(0.0); 
      await _otaxVideoController!.play(); 

      if (mounted) {
        setState(() {});
      }
    } catch (e) {
      debugPrint("Gagal memuat video background: $e");
    }
  }

  void _toggleStatsVideo() {
    setState(() {
      if (_statsVideoController != null) {
        if (_statsVideoController!.value.isPlaying) {
          _statsVideoController!.pause();
        } else {
          _statsVideoController!.play();
        }
      }
    });
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    if(mounted) {
      setState(() {
        androidId = deviceInfo.id;
      });
    }
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('http://jayspanell.ommdhangantenk.my.id:2140'));
    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));

    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);

      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      }
    });
  }

  Future<void> _fetchActivityLogs() async {
    if(!mounted) return;
    setState(() {
      _isLoadingActivityLogs = true;
      _hasActivityLogsError = false;
    });

    try {
      final response = await http.get(
        Uri.parse('http://jayspanell.ommdhangantenk.my.id:2140/api/user/getActivityLogs?key=$sessionKey'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && data['logs'] != null) {
          if(mounted) {
             setState(() {
              _activityLogs = List<Map<String, dynamic>>.from(data['logs']);
              _isLoadingActivityLogs = false;
            });
          }
        } else {
          if(mounted) {
             setState(() {
              _isLoadingActivityLogs = false;
              _hasActivityLogsError = true;
            });
          }
        }
      } else {
         if(mounted) {
            setState(() {
              _isLoadingActivityLogs = false;
              _hasActivityLogsError = true;
            });
         }
      }
    } catch (e) {
      print('Error fetching activity logs: $e');
      if(mounted) {
        setState(() {
          _isLoadingActivityLogs = false;
          _hasActivityLogsError = true;
        });
      }
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.95),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(28),
          side: BorderSide(color: const Color(0xFF00E5FF).withOpacity(0.5), width: 1.5),
        ),
        title: Row(
          children: const [
            Icon(Icons.warning_amber_rounded, color: Color(0xFFE91E63), size: 28),
            SizedBox(width: 12),
            Text("Session Expired", style: TextStyle(color: Colors.white, fontFamily: "Orbitron", fontWeight: FontWeight.bold)),
          ],
        ),
        content: Text(message, style: const TextStyle(color: Colors.white70, fontFamily: "ShareTechMono")),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
              );
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFFE91E63), Color(0xFFC2185B)]),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Text("OK", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  void _openSettingsPage() {
    setState(() {
      _activePage = 'settings';
      _selectedPage = _buildSettingsPage();
      _controller.reset();
      _controller.forward();
    });
  }

  void _selectFromDrawer(String page) {
    if (page == 'account') {
      setState(() {
        _isAssistiveMenuOpen = false;
        _isBugToolsExpanded = false;
      });
      _showAccountMenu();
      return;
    }

    if (page == 'rat') {
      setState(() {
        _isAssistiveMenuOpen = false;
        _isBugToolsExpanded = false;
        _activePage = 'rat';
        _selectedPage = DeviceDashboardPage(username: username);
      });
      _controller.reset();
      _controller.forward();
      return;
    }

    setState(() {
      _isAssistiveMenuOpen = false;
      _activePage = page;
    });

    Widget nextWidget = _buildNewsPage();
    
    if (page == 'home') {
      _selectedIndex = 0;
      nextWidget = _buildNewsPage();
    } else if (page == 'settings') {
      nextWidget = _buildSettingsPage();
    } else if (page == 'bug') {
      nextWidget = AttackPage(
        username: username,
        password: password,
        listBug: listBug,
        role: role,
        expiredDate: expiredDate,
        sessionKey: sessionKey,
      );
    } else if (page == 'custom_bug') {
      nextWidget = CustomAttackPage(
        username: username,
        password: password,
        listPayload: listPayload,
        role: role,
        expiredDate: expiredDate,
        sessionKey: sessionKey,
      );
    } else if (page == 'group_bug') {
      nextWidget = GroupBugPage(
        username: username,
        password: password,
        role: role,
        expiredDate: expiredDate,
        sessionKey: sessionKey,
      );
    } else if (page == 'telegram') {
      nextWidget = TelegramSpamPage(sessionKey: sessionKey);
    } else if (page == 'ddos') {
      nextWidget = AttackPanel(sessionKey: sessionKey, listDDoS: listDDoS);
    } else if (page == 'tools') {
      nextWidget = ToolsPage(sessionKey: sessionKey, userRole: role);
    } else if (page == 'reseller') {
      nextWidget = SellerPage(keyToken: sessionKey);
    } else if (page == 'admin') {
      nextWidget = AdminPage(sessionKey: sessionKey);
    } else if (page == 'sender') {
      nextWidget = SenderPage(sessionKey: sessionKey);
    }

    setState(() {
      _selectedPage = nextWidget;
      _controller.reset();
      _controller.forward();
    });
  }

  // ==================== MODERN SETTINGS PAGE ====================
  Widget _buildSettingsPage() {
    const neonCyan = Color(0xFF00E5FF);
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.black,
            const Color(0xFF0A0E27),
            const Color(0xFF1A1A3E),
          ],
        ),
      ),
      child: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverAppBar(
              expandedHeight: 120,
              floating: true,
              backgroundColor: Colors.transparent,
              elevation: 0,
              flexibleSpace: FlexibleSpaceBar(
                title: const Text(
                  "Interface Settings",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontFamily: "Orbitron",
                    letterSpacing: 2,
                  ),
                ),
                centerTitle: true,
                background: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black.withOpacity(0.8),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    _buildModernSettingCard(
                      icon: Icons.navigation_outlined,
                      title: "Bottom Navigation",
                      subtitle: "Show/Hide navigation bar",
                      value: _showBottomNav,
                      onChanged: (val) {
                        setState(() { _showBottomNav = val; });
                        _openSettingsPage();
                      },
                      gradient: const [Color(0xFF667eea), Color(0xFF764ba2)],
                    ),
                    const SizedBox(height: 16),
                    _buildModernSettingCard(
                      icon: Icons.ads_click,
                      title: "Assistive Touch",
                      subtitle: "Floating logo shortcut",
                      value: _showAssistiveTouch,
                      onChanged: (val) {
                        setState(() { 
                          _showAssistiveTouch = val;
                          if(!val) _isAssistiveMenuOpen = false;
                        });
                        _openSettingsPage();
                      },
                      gradient: const [Color(0xFFf093fb), Color(0xFFf5576c)],
                    ),
                    const SizedBox(height: 16),
                    _buildModernSettingCard(
                      icon: _isMusicOn ? Icons.music_note : Icons.music_off,
                      title: "Background Music",
                      subtitle: "Play online MP3",
                      value: _isMusicOn,
                      onChanged: (val) {
                        _toggleBackgroundMusic(val);
                        _openSettingsPage();
                      },
                      gradient: const [Color(0xFF4facfe), Color(0xFF00f2fe)],
                    ),
                    const SizedBox(height: 40),
                    Center(
                      child: GestureDetector(
                        onTap: () => _selectFromDrawer('home'),
                        child: Container(
                          width: 200,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Color(0xFF00E5FF), Color(0xFF007BFF)],
                            ),
                            borderRadius: BorderRadius.circular(40),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFF00E5FF).withOpacity(0.4),
                                blurRadius: 20,
                                offset: const Offset(0, 5),
                              ),
                            ],
                          ),
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.arrow_back, color: Colors.white),
                              SizedBox(width: 8),
                              Text(
                                "Apply Changes",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 40),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildModernSettingCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required Function(bool) onChanged,
    required List<Color> gradient,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          colors: [gradient[0].withOpacity(0.15), gradient[1].withOpacity(0.05)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(color: Colors.white.withOpacity(0.1), width: 1),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: gradient),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Icon(icon, color: Colors.white, size: 24),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      Text(subtitle, style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 12)),
                    ],
                  ),
                ),
                Switch(
                  value: value,
                  activeColor: Colors.white,
                  activeTrackColor: gradient[0],
                  inactiveThumbColor: Colors.grey.shade400,
                  inactiveTrackColor: Colors.white.withOpacity(0.1),
                  onChanged: onChanged,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ==================== MODERN HEADER ====================
  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 12, 
        bottom: 12, 
        left: 20, 
        right: 20
      ),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Colors.black.withOpacity(0.9),
            Colors.transparent,
          ],
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _buildGlassIconButton(
            icon: Icons.segment,
            onTap: () {
              setState(() {
                _isAssistiveMenuOpen = !_isAssistiveMenuOpen;
                if (_isAssistiveMenuOpen) {
                  _assistiveTouchPosition = Offset(16, MediaQuery.of(context).padding.top + 60);
                }
              });
            },
            color: const Color(0xFF00E5FF),
          ),
          Expanded(
            child: Container(
              height: 50,
              margin: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.3), width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF00E5FF).withOpacity(0.2),
                    blurRadius: 15,
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(25),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    if (_videoController != null && _videoController!.value.isInitialized)
                      FittedBox(
                        fit: BoxFit.cover,
                        child: SizedBox(
                          width: _videoController!.value.size.width,
                          height: _videoController!.value.size.height,
                          child: VideoPlayer(_videoController!),
                        ),
                      ),
                    Container(color: Colors.black.withOpacity(0.5)),
                    const Center(
                      child: Text(
                        "NOCURE",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          fontFamily: "Orbitron",
                          letterSpacing: 3,
                          shadows: [
                            Shadow(color: Color(0xFF00E5FF), blurRadius: 10, offset: Offset(0, 0))
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Row(
            children: [
              _buildGlassIconButton(
                icon: Icons.tune,
                onTap: _showAccountMenu,
                color: Colors.white,
              ),
              const SizedBox(width: 12),
              _buildGlassIconButton(
                icon: Icons.apps,
                onTap: _openSettingsPage,
                color: _activePage == 'settings' ? const Color(0xFF00E5FF) : Colors.white,
                isActive: _activePage == 'settings',
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildGlassIconButton({required IconData icon, required VoidCallback onTap, required Color color, bool isActive = false}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 48,
        height: 48,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isActive ? const Color(0xFF00E5FF) : Colors.white.withOpacity(0.2),
            width: 1.5,
          ),
          gradient: LinearGradient(
            colors: [Colors.white.withOpacity(0.1), Colors.white.withOpacity(0.05)],
          ),
        ),
        child: Icon(icon, color: color, size: 24),
      ),
    );
  }

  // ==================== OTAX APPS VIDEO BANNER ====================
  Widget _buildOtaxAppsVideo() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      height: 160,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 20,
            spreadRadius: 2,
          )
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_otaxVideoController != null && _otaxVideoController!.value.isInitialized)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _otaxVideoController!.value.size.width,
                  height: _otaxVideoController!.value.size.height,
                  child: VideoPlayer(_otaxVideoController!),
                ),
              )
            else
              Container(color: const Color(0xFF1A1A3E)),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.black.withOpacity(0.6),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== MODERN API NEWS LIST ====================
  Widget _buildApiNewsList() {
    if (newsList.isEmpty) {
      return Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: const Center(child: Text("No updates available", style: TextStyle(color: Colors.white54))),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF00E5FF), Color(0xFF007BFF)]),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.campaign_outlined, color: Colors.white, size: 18),
              ),
              const SizedBox(width: 12),
              const Text(
                "SYSTEM UPDATES",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: "Orbitron",
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          height: 150,
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: newsList.length,
            itemBuilder: (context, index) {
              final item = newsList[index];
              return Container(
                width: 280,
                margin: const EdgeInsets.only(right: 12),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      if (item['image'] != null && item['image'].toString().isNotEmpty)
                        NewsMedia(url: item['image'])
                      else
                        Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [const Color(0xFF1A1A3E), const Color(0xFF0A0E27)],
                            ),
                          ),
                        ),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              Colors.black.withOpacity(0.9),
                            ],
                            stops: const [0.4, 1.0],
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 16,
                        left: 16,
                        right: 16,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              item['title'] ?? 'System Info',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                fontFamily: "Orbitron",
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              item['desc'] ?? 'No description',
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.8),
                                fontSize: 11,
                                fontFamily: "ShareTechMono",
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                      Positioned(
                        top: 12,
                        right: 12,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(colors: [Color(0xFF00E5FF), Color(0xFF007BFF)]),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Text(
                            "NEW",
                            style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  // ==================== MODERN ACCOUNT STATS CARD ====================
  Widget _buildAccountStatsCard() {
    String displayUid = androidId != "unknown" ? androidId : "f4424219-4faf-4417-9dc5-57a862d202ba";
    String shortUid = displayUid.length > 12 ? "${displayUid.substring(0, 12)}..." : displayUid;
    bool isVideoPlaying = _statsVideoController != null && _statsVideoController!.value.isPlaying;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: Stack(
          children: [
            if (_statsVideoController != null && _statsVideoController!.value.isInitialized)
              Positioned.fill(
                child: Opacity(
                  opacity: 0.4,
                  child: FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _statsVideoController!.value.size.width,
                      height: _statsVideoController!.value.size.height,
                      child: VideoPlayer(_statsVideoController!),
                    ),
                  ),
                ),
              ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.black.withOpacity(0.7),
                    const Color(0xFF1A1A3E).withOpacity(0.8),
                  ],
                ),
                border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.3), width: 1.5),
              ),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 60,
                          height: 60,
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(colors: [Color(0xFFE91E63), Color(0xFFC2185B)]),
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFFE91E63).withOpacity(0.5),
                                blurRadius: 15,
                              ),
                            ],
                          ),
                          child: const Center(
                            child: Icon(Icons.security, color: Colors.white, size: 30),
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Welcome back,",
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.7),
                                  fontSize: 12,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                username,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: "Orbitron",
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                decoration: BoxDecoration(
                                  border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.5)),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  role.toUpperCase(),
                                  style: const TextStyle(
                                    color: Color(0xFF00E5FF),
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.2)),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.hexagon, color: const Color(0xFF00E5FF).withOpacity(0.5), size: 14),
                          const SizedBox(width: 8),
                          const Text(
                            "NOCURE V2.0",
                            style: TextStyle(
                              color: Color(0xFF00E5FF),
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              fontFamily: "Orbitron",
                              letterSpacing: 2,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Icon(Icons.hexagon, color: const Color(0xFF00E5FF).withOpacity(0.5), size: 14),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildStatItem("0", "Online Users", const Color(0xFF00E676)),
                        _buildStatItem("0", "Connections", const Color(0xFF2196F3)),
                        _buildStatItem(expiredDate, "Expiration", const Color(0xFFFF9800)),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Divider(color: Colors.white.withOpacity(0.1)),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Text("UID: $shortUid", style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11)),
                            const SizedBox(width: 8),
                            GestureDetector(
                              onTap: () {
                                Clipboard.setData(ClipboardData(text: displayUid));
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('UID Copied!', style: TextStyle(fontFamily: "ShareTechMono")),
                                    backgroundColor: Color(0xFF00E5FF),
                                    duration: Duration(seconds: 1),
                                  ),
                                );
                              },
                              child: Icon(Icons.copy, color: Colors.white.withOpacity(0.6), size: 14),
                            ),
                          ],
                        ),
                        GestureDetector(
                          onTap: _toggleStatsVideo,
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Icon(
                              isVideoPlaying ? Icons.pause : Icons.play_arrow,
                              color: Colors.white54,
                              size: 16,
                            ),
                          ),
                        ),
                        Row(
                          children: [
                            Icon(Icons.wb_sunny, color: Colors.white.withOpacity(0.5), size: 14),
                            const SizedBox(width: 4),
                            Text("28°C", style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11)),
                            const SizedBox(width: 12),
                            Icon(Icons.battery_charging_full, color: Colors.white.withOpacity(0.5), size: 14),
                            const SizedBox(width: 4),
                            Text("100%", style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11)),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String value, String label, Color color) {
    return Column(
      children: [
        Container(
          width: 55,
          height: 55,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: color.withOpacity(0.5), width: 2),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.3),
                blurRadius: 12,
              ),
            ],
          ),
          child: Center(
            child: Text(
              value.length > 10 ? value.substring(0, 8) : value,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.bold,
                fontFamily: "ShareTechMono",
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
            color: Colors.white.withOpacity(0.6),
            fontSize: 10,
          ),
        ),
      ],
    );
  }

  // ==================== WHATSAPP CRASH BANNER ====================
  Widget _buildWhatsAppCrashBanner() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF25D366), Color(0xFF128C7E)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF25D366).withOpacity(0.4),
                blurRadius: 15,
              ),
            ],
          ),
          child: Stack(
            children: [
              Positioned(
                right: -20,
                top: -30,
                child: Icon(
                  FontAwesomeIcons.whatsapp,
                  size: 120,
                  color: Colors.white.withOpacity(0.15),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                child: Row(
                  children: [
                    const Icon(FontAwesomeIcons.whatsapp, color: Colors.white, size: 32),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            "WhatsApp Crash Tool",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              fontFamily: "Orbitron",
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            "Send custom payloads to crash target",
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.chevron_right, color: Colors.white, size: 28),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ==================== MODERN QUICK ACTIONS ====================
  Widget _buildActionSliderCard(Map<String, dynamic> action) {
    return GestureDetector(
      onTap: action['onTap'],
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: LinearGradient(
            colors: [action['color1'], action['color2']],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: action['color2'].withOpacity(0.4),
              blurRadius: 15,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -20,
              bottom: -20,
              child: Icon(
                action['icon'],
                size: 100,
                color: Colors.white.withOpacity(0.1),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(action['icon'], color: Colors.white, size: 22),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Text(
                          "OPEN →",
                          style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  Text(
                    action['title'],
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Orbitron",
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    action['subtitle'],
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.9),
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActions() {
    final List<Map<String, dynamic>> quickActions = [
      {
        "title": "Sender Manager",
        "subtitle": "Pairing & Config",
        "icon": FontAwesomeIcons.whatsapp,
        "color1": const Color(0xFFE91E63),
        "color2": const Color(0xFFC2185B),
        "onTap": () => _selectFromDrawer('sender'),
      },
      {
        "title": "Join Channel",
        "subtitle": "Get updates",
        "icon": FontAwesomeIcons.telegramPlane,
        "color1": const Color(0xFF0088CC),
        "color2": const Color(0xFF005580),
        "onTap": () async {
          final url = Uri.parse('https://t.me/nocurech');
          if (await canLaunchUrl(url)) {
            await launchUrl(url, mode: LaunchMode.externalApplication);
          }
        },
      },
      {
        "title": "Telegram Spam",
        "subtitle": "Mass sender",
        "icon": FontAwesomeIcons.paperPlane,
        "color1": const Color(0xFF4CAF50),
        "color2": const Color(0xFF388E3C),
        "onTap": () => _selectFromDrawer('telegram'),
      },
      {
        "title": "Security",
        "subtitle": "Change password",
        "icon": Icons.lock_reset,
        "color1": const Color(0xFFFF9800),
        "color2": const Color(0xFFF57C00),
        "onTap": () {
          setState(() {
            _activePage = 'change_password';
            _selectedPage = ChangePasswordPage(
              username: username,
              sessionKey: sessionKey,
            );
            _controller.reset();
            _controller.forward();
          });
        },
      },
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [Color(0xFFFFD700), Color(0xFFFFA500)]),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.bolt, color: Colors.white, size: 18),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    "QUICK ACCESS",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Orbitron",
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  border: Border.all(color: const Color(0xFFFFD700).withOpacity(0.5)),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: const [
                    Icon(Icons.circle, color: Color(0xFFFFD700), size: 8),
                    SizedBox(width: 6),
                    Text("ACTIVE", style: TextStyle(color: Color(0xFFFFD700), fontSize: 10, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        SizedBox(
          height: 170,
          child: PageView.builder(
            controller: _actionPageController,
            itemCount: quickActions.length,
            onPageChanged: (index) {
              setState(() {
                _currentActionIndex = index;
              });
            },
            itemBuilder: (context, index) {
              return _buildActionSliderCard(quickActions[index]);
            },
          ),
        ),
        const SizedBox(height: 15),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(
            quickActions.length,
            (index) => AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              height: 6,
              width: _currentActionIndex == index ? 24 : 8,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: _currentActionIndex == index ? const Color(0xFFFFD700) : Colors.white.withOpacity(0.2),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ==================== MODERN NEWS PAGE ====================
  Widget _buildNewsPage() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF0A0E27), Color(0xFF000000)],
        ),
      ),
      child: RefreshIndicator(
        color: const Color(0xFF00E5FF),
        backgroundColor: Colors.black.withOpacity(0.8),
        onRefresh: () async {
          await _fetchActivityLogs();
          await Future.delayed(const Duration(seconds: 1));
          setState(() {});
        },
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(
              child: SizedBox(height: MediaQuery.of(context).padding.top + 80),
            ),
            SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 10),
                  _buildWhatsAppCrashBanner(),
                  const SizedBox(height: 20),
                  _buildApiNewsList(),
                  const SizedBox(height: 20),
                  _buildAccountStatsCard(),
                  const SizedBox(height: 30),
                  _buildQuickActions(),
                  const SizedBox(height: 30),
                  _buildModernNewsCarousel(),
                  const SizedBox(height: 20),
                  _buildRecentActivity(),
                  const SizedBox(height: 120),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== MODERN NEWS CAROUSEL ====================
  Widget _buildModernNewsCarousel() {
    final List<Map<String, dynamic>> dummyNews = [
      {
        "title": "NOCURE V2.0",
        "date": "2026-04-21",
        "image": "assets/images/news1.jpg", 
        "isNew": true,
      },
      {
        "title": "NEW FITUR RAT",
        "date": "2026-05-08",
        "image": "assets/images/news2.jpg",
        "isNew": true,
      },
      {
        "title": "FUNCTION UPDATED",
        "date": "2026-05-05",
        "image": "assets/images/news3.jpg",
        "isNew": true,
      },
      {
        "title": "GLOBAL SENDER",
        "date": "2026-05-02",
        "image": "assets/images/news4.jpg",
        "isNew": true,
      },
      {
        "title": "NEW UPDATES",
        "date": "2026-04-28",
        "image": "assets/images/news5.jpg",
        "isNew": true,
      },
    ];

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [Color(0xFFE91E63), Color(0xFFFF5722)]),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.newspaper, color: Colors.white, size: 18),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    "LATEST NEWS",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Orbitron",
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFFE91E63), Color(0xFFFF5722)]),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text("${dummyNews.length} Updates", style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          height: 240,
          child: PageView.builder(
            controller: _pageController,
            itemCount: dummyNews.length,
            onPageChanged: (index) {
              setState(() {
                _currentNewsIndex = index;
              });
            },
            itemBuilder: (context, index) {
              final item = dummyNews[index];
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.4),
                      blurRadius: 15,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(24),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.asset(
                        item['image'], 
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [const Color(0xFF1A1A3E), const Color(0xFF0A0E27)],
                            ),
                          ),
                          child: const Center(child: Icon(Icons.image, color: Colors.white24, size: 50)),
                        ),
                      ),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              Colors.black.withOpacity(0.8),
                            ],
                            stops: const [0.5, 1.0],
                          ),
                        ),
                      ),
                      if (item['isNew'])
                        Positioned(
                          top: 16,
                          right: 16,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(colors: [Color(0xFFE91E63), Color(0xFFFF5722)]),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: const Text("NEW", style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                          ),
                        ),
                      Positioned(
                        bottom: 20,
                        left: 20,
                        right: 20,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              item['title'],
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                fontFamily: "Orbitron",
                              ),
                              maxLines: 1,
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                const Icon(Icons.access_time, color: Colors.white70, size: 14),
                                const SizedBox(width: 6),
                                Text(
                                  item['date'],
                                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                                ),
                                const Spacer(),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                  decoration: BoxDecoration(
                                    border: Border.all(color: Colors.white.withOpacity(0.5)),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: const Text("READ MORE", style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        if (dummyNews.length > 1)
          Padding(
            padding: const EdgeInsets.only(top: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                dummyNews.length,
                (index) => AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  height: 6,
                  width: _currentNewsIndex == index ? 24 : 8,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: _currentNewsIndex == index ? const Color(0xFFE91E63) : Colors.white.withOpacity(0.2),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  // ==================== MODERN RECENT ACTIVITY ====================
  Widget _buildRecentActivity() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF00E5FF), Color(0xFF007BFF)]),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.history, color: Colors.white, size: 18),
              ),
              const SizedBox(width: 12),
              const Text(
                "RECENT ACTIVITY",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: "Orbitron",
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          if (_isLoadingActivityLogs)
            _buildGlassPlaceholder(child: const CircularProgressIndicator(color: Color(0xFF00E5FF)))
          else if (_hasActivityLogsError)
            _buildGlassPlaceholder(child: const Text("Failed to load logs", style: TextStyle(color: Colors.white70)))
          else if (_activityLogs.isEmpty)
            _buildGlassPlaceholder(child: const Text("No activity logs", style: TextStyle(color: Colors.white54)))
          else
            ..._activityLogs.take(5).map((log) {
              final timestamp = DateTime.tryParse(log['timestamp'] ?? '') ?? DateTime.now();
              final formattedTime = _formatDateTime(timestamp);
              String activityText = log['activity'] ?? 'Unknown Activity';

              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                  gradient: LinearGradient(
                    colors: [Colors.white.withOpacity(0.05), Colors.transparent],
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [Color(0xFF00E5FF), Color(0xFF007BFF)]),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.notifications, color: Colors.white, size: 18),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            activityText,
                            style: const TextStyle(
                              color: Colors.white,
                              fontFamily: "ShareTechMono",
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            formattedTime,
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.5),
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.chevron_right, color: Colors.white54, size: 20),
                  ],
                ),
              );
            }).toList(),
        ],
      ),
    );
  }

  Widget _buildGlassPlaceholder({required Widget child}) {
    return Container(
      height: 120,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
        gradient: LinearGradient(
          colors: [Colors.white.withOpacity(0.05), Colors.transparent],
        ),
      ),
      child: Center(child: child),
    );
  }

  String _formatDateTime(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);
    if (difference.inDays > 0) return '${difference.inDays}d ago';
    if (difference.inHours > 0) return '${difference.inHours}h ago';
    if (difference.inMinutes > 0) return '${difference.inMinutes}m ago';
    return 'Just now';
  }

  // ==================== ACCOUNT MENU ====================
  void _showAccountMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        margin: const EdgeInsets.all(20),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.9),
                border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.3), width: 1.5),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 50,
                    height: 5,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Icon(Icons.account_circle, size: 60, color: Color(0xFF00E5FF)),
                  const SizedBox(height: 16),
                  const Text("Account Info", style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold, fontFamily: "Orbitron")),
                  const SizedBox(height: 24),
                  _buildInfoRow(Icons.person, "Username", username),
                  const SizedBox(height: 12),
                  _buildInfoRow(Icons.calendar_today, "Expired", expiredDate),
                  const SizedBox(height: 12),
                  _buildInfoRow(Icons.security, "Role", role),
                  const SizedBox(height: 24),
                  Row(
                    children: [
                      Expanded(
                        child: _buildMenuButton(
                          icon: Icons.lock_reset,
                          label: "Change Password",
                          onTap: () {
                            Navigator.pop(context);
                            setState(() {
                              _activePage = 'change_password';
                              _selectedPage = ChangePasswordPage(
                                username: username,
                                sessionKey: sessionKey,
                              );
                              _controller.reset();
                              _controller.forward();
                            });
                          },
                          color: const Color(0xFFFF9800),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _buildMenuButton(
                          icon: Icons.logout,
                          label: "Logout",
                          onTap: () async {
                            final prefs = await SharedPreferences.getInstance();
                            await prefs.clear();
                            if (!mounted) return;
                            Navigator.of(context).pushAndRemoveUntil(
                              MaterialPageRoute(builder: (_) => const LoginPage()),
                                  (route) => false,
                            );
                          },
                          color: const Color(0xFFE91E63),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF00E5FF), size: 20),
          const SizedBox(width: 12),
          Text(label, style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w500)),
          const Spacer(),
          Text(value, style: const TextStyle(color: Colors.white, fontFamily: "ShareTechMono")),
        ],
      ),
    );
  }

  Widget _buildMenuButton({required IconData icon, required String label, required VoidCallback onTap, required Color color}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [color, color.withOpacity(0.7)]),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 18),
            const SizedBox(width: 8),
            Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  // ==================== ASSISTIVE MENU ====================
  Widget _buildAssistiveMenu() {
    final String currentRole = role.toLowerCase();
    
    final bool canAccessAdmin = ['founder', 'moderator', 'high admin', 'owner'].contains(currentRole);
    final bool canAccessSeller = ['founder', 'moderator', 'high admin', 'owner', 'reseller'].contains(currentRole);
    final bool canAccessAllBugs = ['founder', 'moderator', 'high admin', 'owner'].contains(currentRole);
    final bool canAccessResellerBugs = ['reseller'].contains(currentRole);
    final bool isMember = !canAccessAllBugs && !canAccessResellerBugs;

    return Container(
      width: 260,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.3), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 20,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            color: Colors.black.withOpacity(0.9),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 12),
                  _buildMenuItem(Icons.home, "Home", 'home'),
                  Theme(
                    data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
                    child: ExpansionTile(
                      tilePadding: const EdgeInsets.symmetric(horizontal: 16),
                      leading: const Icon(FontAwesomeIcons.whatsapp, color: Color(0xFF00E5FF), size: 18),
                      title: const Text("Bug Tools", style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                      trailing: Icon(
                        _isBugToolsExpanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down, 
                        color: Colors.white70, 
                        size: 20
                      ),
                      onExpansionChanged: (bool expanded) {
                        setState(() {
                          _isBugToolsExpanded = expanded;
                        });
                        if (isMember && expanded) {
                           setState(() {
                              _isBugToolsExpanded = false;
                           });
                           _selectFromDrawer('bug');
                        }
                      },
                      children: [
                        if (!isMember)
                          Padding(
                            padding: const EdgeInsets.only(left: 32, bottom: 8),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                if (canAccessAllBugs || canAccessResellerBugs) ...[
                                  _buildSubMenuItem(FontAwesomeIcons.usersSlash, "Group Bug", 'group_bug'),
                                  const SizedBox(height: 4),
                                ],
                                if (canAccessAllBugs) ...[
                                  _buildSubMenuItem(Icons.terminal, "Custom Bug", 'custom_bug'),
                                  const SizedBox(height: 4),
                                ],
                                _buildSubMenuItem(Icons.bolt, "Basic Bug", 'bug'),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                  _buildMenuItem(FontAwesomeIcons.paperPlane, "Spam", 'telegram'),
                  _buildMenuItem(Icons.phone_android, "RAT", 'rat'),
                  _buildMenuItem(FontAwesomeIcons.screwdriverWrench, "Tools", 'tools'),
                  _buildMenuItem(Icons.security, "DDoS Attack", 'ddos'),
                  const Divider(color: Colors.white24, height: 20, thickness: 1),
                  _buildMenuItem(Icons.person, "Account Info", 'account'),
                  if (canAccessSeller)
                    _buildMenuItem(Icons.store, "Seller Panel", 'reseller'),
                  if (canAccessAdmin)
                    _buildMenuItem(Icons.admin_panel_settings, "Admin Panel", 'admin'),
                  _buildMenuItem(FontAwesomeIcons.whatsapp, "Sender Manager", 'sender'),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMenuItem(IconData icon, String title, String page) {
    bool isActive = _activePage == page;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        splashColor: Colors.white.withOpacity(0.1),
        onTap: () => _selectFromDrawer(page),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
          decoration: isActive ? BoxDecoration(
            color: const Color(0xFF00E5FF).withOpacity(0.1),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.3)),
          ) : null,
          child: Row(
            children: [
              Icon(icon, color: isActive ? const Color(0xFF00E5FF) : Colors.white70, size: 18),
              const SizedBox(width: 16),
              Expanded(
                child: Text(
                  title, 
                  style: TextStyle(
                    color: isActive ? const Color(0xFF00E5FF) : Colors.white, 
                    fontSize: 14, 
                    fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
              ),
              if (isActive)
                Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                    color: Color(0xFF00E5FF),
                    shape: BoxShape.circle,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSubMenuItem(IconData icon, String title, String page) {
    bool isActive = _activePage == page;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        splashColor: Colors.white.withOpacity(0.1),
        onTap: () => _selectFromDrawer(page),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
          child: Row(
            children: [
              Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  color: isActive ? const Color(0xFF00E5FF).withOpacity(0.2) : Colors.white.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: isActive ? const Color(0xFF00E5FF) : Colors.white70, size: 12),
              ),
              const SizedBox(width: 12),
              Text(
                title,
                style: TextStyle(
                  color: isActive ? const Color(0xFF00E5FF) : Colors.white70,
                  fontSize: 12,
                  fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ==================== BOTTOM NAVIGATION BAR ====================
  Widget _buildBottomNavBar() {
    return Positioned(
      bottom: 16,
      left: 16,
      right: 16,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.3), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 20,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(40),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              color: Colors.black.withOpacity(0.8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildNavItem(Icons.home_filled, "Home", 'home'),
                  _buildNavItem(FontAwesomeIcons.whatsapp, "Bug", 'bug'),
                  _buildNavItem(FontAwesomeIcons.paperPlane, "Spam", 'telegram'),
                  _buildNavItem(Icons.android, "RAT", 'rat'),
                  _buildNavItem(Icons.tune, "More", 'more'),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, String page) {
    bool isActive = _activePage == page || (page == 'bug' && (_activePage == 'group_bug' || _activePage == 'custom_bug'));

    return GestureDetector(
      onTap: () {
        if (page == 'more') {
          setState(() {
            _isAssistiveMenuOpen = !_isAssistiveMenuOpen;
          });
        } else if (page == 'bug') {
          _showBugOptionsSheet();
        } else {
          _selectFromDrawer(page);
        }
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: isActive ? BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF00E5FF), Color(0xFF007BFF)]),
          borderRadius: BorderRadius.circular(30),
        ) : null,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isActive ? Colors.white : Colors.white54,
              size: 22,
            ),
            if (isActive) ...[
              const SizedBox(height: 4),
              Text(
                label,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ]
          ],
        ),
      ),
    );
  }

  void _showBugOptionsSheet() {
    final String currentRole = role.toLowerCase();
    final List<String> allowedGroupRoles = ['founder', 'moderator', 'high admin', 'owner', 'reseller', 'vip'];
    final bool canAccessGroup = allowedGroupRoles.contains(currentRole);

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        margin: const EdgeInsets.all(20),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.95),
                border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.3), width: 1.5),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 50,
                    height: 5,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text("Select Bug Type", style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold, fontFamily: "Orbitron")),
                  const SizedBox(height: 24),
                  _buildBugOption(Icons.person_outline, "Bug Contact", () {
                    Navigator.pop(context);
                    _selectFromDrawer('bug');
                  }),
                  if (canAccessGroup) ...[
                    const SizedBox(height: 12),
                    _buildBugOption(FontAwesomeIcons.usersSlash, "Bug Group", () {
                      Navigator.pop(context);
                      _selectFromDrawer('group_bug');
                    }),
                  ],
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBugOption(IconData icon, String title, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.3)),
          gradient: LinearGradient(
            colors: [const Color(0xFF00E5FF).withOpacity(0.1), Colors.transparent],
          ),
        ),
        child: Row(
          children: [
            Icon(icon, color: const Color(0xFF00E5FF), size: 24),
            const SizedBox(width: 16),
            Text(title, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w500)),
            const Spacer(),
            const Icon(Icons.chevron_right, color: Color(0xFF00E5FF)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final bool isRightSide = _assistiveTouchPosition.dx > (screenSize.width / 2);
    final bool isBottomSide = _assistiveTouchPosition.dy > (screenSize.height / 2);

    return WillPopScope(
      onWillPop: () async {
        if (_activePage != 'home') {
          _selectFromDrawer('home');
          return false;
        }
        return true;
      },
      child: Scaffold(
        key: _scaffoldKey,
        extendBodyBehindAppBar: true,
        backgroundColor: Colors.black,
        body: Stack(
          children: [
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF0A0E27), Color(0xFF000000)],
                ),
              ),
            ),
            
            SafeArea(
              top: false,
              bottom: false,
              child: FadeTransition(
                opacity: _animation,
                child: _selectedPage,
              ),
            ),
            
            if (_activePage == 'home' || _activePage == 'settings')
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: _buildHeader(),
              ),

            if (_showAssistiveTouch) ...[
              if (_isAssistiveMenuOpen)
                Positioned.fill(
                  child: GestureDetector(
                    onTap: () {
                      setState(() {
                        _isAssistiveMenuOpen = false;
                        _isBugToolsExpanded = false;
                      });
                    },
                    child: Container(color: Colors.transparent),
                  ),
                ),
              AnimatedPositioned(
                duration: const Duration(milliseconds: 150),
                left: isRightSide ? _assistiveTouchPosition.dx - 280 : _assistiveTouchPosition.dx + 70,
                top: isBottomSide ? _assistiveTouchPosition.dy - 400 : _assistiveTouchPosition.dy,
                child: AnimatedScale(
                  scale: _isAssistiveMenuOpen ? 1.0 : 0.0,
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeOutBack,
                  alignment: isRightSide 
                      ? (isBottomSide ? Alignment.bottomRight : Alignment.topRight)
                      : (isBottomSide ? Alignment.bottomLeft : Alignment.topLeft),
                  child: _buildAssistiveMenu(),
                ),
              ),
              Positioned(
                left: _assistiveTouchPosition.dx,
                top: _assistiveTouchPosition.dy,
                child: GestureDetector(
                  onPanUpdate: (details) {
                    setState(() {
                      if (_isAssistiveMenuOpen) {
                         _isAssistiveMenuOpen = false;
                         _isBugToolsExpanded = false;
                      }

                      double newX = _assistiveTouchPosition.dx + details.delta.dx;
                      double newY = _assistiveTouchPosition.dy + details.delta.dy;
                      
                      newX = newX.clamp(0.0, screenSize.width - 60.0);
                      newY = newY.clamp(0.0, screenSize.height - 120.0);
                      
                      _assistiveTouchPosition = Offset(newX, newY);
                    });
                  },
                  onTap: () {
                    setState(() {
                      _isAssistiveMenuOpen = !_isAssistiveMenuOpen;
                      if(!_isAssistiveMenuOpen) _isBugToolsExpanded = false;
                    });
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.4),
                          blurRadius: 15,
                        ),
                        BoxShadow(
                          color: const Color(0xFF00E5FF).withOpacity(_isAssistiveMenuOpen ? 0.5 : 0),
                          blurRadius: 20,
                        ),
                      ],
                    ),
                    child: ClipOval(
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: _isAssistiveMenuOpen 
                                ? [const Color(0xFF00E5FF), const Color(0xFF007BFF)]
                                : [Colors.white.withOpacity(0.1), Colors.white.withOpacity(0.05)],
                          ),
                          border: Border.all(
                            color: _isAssistiveMenuOpen ? Colors.white : const Color(0xFF00E5FF).withOpacity(0.5),
                            width: 2,
                          ),
                        ),
                        padding: const EdgeInsets.all(12),
                        child: Image.asset(
                          'assets/images/logo.png', 
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],

            if (_showBottomNav) _buildBottomNavBar(),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _pageController.dispose();
    _actionPageController.dispose();
    _videoController?.dispose();
    _statsVideoController?.dispose(); 
    _otaxVideoController?.dispose();
    _audioPlayer.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }
}

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (!mounted) return;
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) {
    return url.endsWith(".mp4") ||
        url.endsWith(".webm") ||
        url.endsWith(".mov") ||
        url.endsWith(".mkv");
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      } else {
        return const Center(child: CircularProgressIndicator(color: Color(0xFF00E5FF)));
      }
    } else {
      return Image.network(
        widget.url,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          color: Colors.black26,
          child: const Center(child: Icon(Icons.broken_image, color: Colors.white24)),
        ),
      );
    }
  }
}