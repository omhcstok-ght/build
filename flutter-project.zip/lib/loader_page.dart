// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:http/http.dart' as http;
import 'package:battery_plus/battery_plus.dart';
import 'dart:math' as math;
import 'dart:ui';
import 'package:audioplayers/audioplayers.dart';
import 'package:video_player/video_player.dart';

import 'pair_spam_page.dart';
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'ddos_page.dart';
import 'chat_page.dart';
import 'login_page.dart';
import 'custom_bug.dart';
import 'bug_group.dart';
import 'ddos_panel.dart';
import 'sender_page.dart';
import 'spams_page.dart';
import 'public_page.dart';
import 'device_dashboard.dart';
import 'vip_upgrade_page.dart';
import 'leaderboard_page.dart';
import 'anime.dart';
import 'dox_qr.dart';

// ── COLOR SCHEME ──────────────────────────────────────────────────────────────
class _C {
  static const bg        = Color(0xFF000000);
  static const bg2       = Color(0xFF0a0a0a);
  static const surface   = Color(0xFF111111);
  static const card      = Color(0xFF111111);
  static const accent    = Color(0xFFFF3B30);
  static const accent2   = Color(0xFFFF6B6B);
  static const accent3   = Color(0xFFCC2E25);
  static const gold      = Color(0xFFFFB800);
  static const danger    = Color(0xFFFF3B30);
  static const text      = Color(0xFFE0E7FF);
  static const muted     = Color(0x73E0E7FF);
  static const muted2    = Color(0x38E0E7FF);
  static const border    = Color(0x1AFF3B30);
  static const border2   = Color(0x0FFFFFFF);
  static const greenG1   = Color(0xFFFF3B30);
  static const greenG2   = Color(0xFFCC2E25);
  static const blueG1    = Color(0xFFFF3B30);
  static const blueG2    = Color(0xFFCC2E25);
  static const purpleG1  = Color(0xFFFF3B30);
  static const purpleG2  = Color(0xFFCC2E25);
  static const orangeG1  = Color(0xFFFF3B30);
  static const orangeG2  = Color(0xFFCC2E25);
  static const redG1     = Color(0xFFFF3B30);
  static const redG2     = Color(0xFFD70015);
  static const fanGreen1 = Color(0xFFFF3B30);
  static const fanBlue1  = Color(0xFFFF3B30);
  static const fanPurple1= Color(0xFF333333);
  static const qaGreen1  = Color(0xFFE8FBF4);
  static const qaGreen2  = Color(0xFFC7F0DD);
  static const qaOrange1 = Color(0xFF222222);
  static const qaOrange2 = Color(0xFFFFE5A8);
  static const qaBlue1   = Color(0xFF333333);
  static const qaBlue2   = Color(0xFFD4B8E5);
  static const qaRed1    = Color(0xFFFFE5E5);
  static const qaRed2    = Color(0xFFFFC7C7);
}

// ── DASHBOARD PAGE ────────────────────────────────────────────────────────────
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;
  final List<Map<String, dynamic>> listDDoS;
  final List<dynamic> news;

  DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listPayload,
    required this.listDDoS,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {

  // ── State ─────────────────────────────────────────────────────────────────
  late String _username;
  late String _password;
  late String _role;
  late String _sessionKey;
  late String _expiredDate;
  late List<Map<String, dynamic>> _listBug;
  late List<Map<String, dynamic>> _listPayload;
  late List<Map<String, dynamic>> _listDDoS;
  late List<dynamic> _newsList;
  String _uid = '';
  int _activeCount = 0;
  int _totalCount = 0;
  bool _isLoadingSenders = false;
  List<dynamic> _dashboardSenders = [];

  // ── Statistik User (untuk kotak kanan) ──
  int _totalMembers = 0;
  int _totalVips = 0;
  bool _isLoadingStats = false;

  // Real-time device info
  String _deviceTemp = '--°C';
  String _batteryLevel = '--%';
  BatteryState _batteryState = BatteryState.unknown;
  final Battery _battery = Battery();
  static const _deviceChannel = MethodChannel('com.yakuzaxsilence/device');
  Timer? _tempTimer;

  // Prayer schedule
  Map<String, String> _prayerTimes = {};
  String _nextPrayerKey = '';
  String _prayerCountdown = '--:--:--';
  DateTime _now = DateTime.now();
  Timer? _clockTimer;
  bool _prayerLoading = true;
  String _prayerError = '';
  static const _prayerKeys = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
  static const _prayerLabels = {
    'Fajr':    'SUBUH',
    'Dhuhr':   'DZUHUR',
    'Asr':     'ASHAR',
    'Maghrib': 'MAGHRIB',
    'Isha':    'ISYA',
  };
  static final _prayerIcons = {
    'Fajr':    FontAwesomeIcons.moon,
    'Dhuhr':   FontAwesomeIcons.sun,
    'Asr':     FontAwesomeIcons.cloudSun,
    'Maghrib': FontAwesomeIcons.sunPlantWilt,
    'Isha':    FontAwesomeIcons.solidMoon,
  };

  // Anime latest
  List<dynamic> _latestAnime = [];
  bool _animeLoading = true;
  final ScrollController _animeScrollController = ScrollController();

  bool _isSidebarOpen = false;
  bool _isFanMenuOpen = false;
  int _currentNavIndex = 0;
  int _currentNewsIndex = 0;
  bool _isMusicPlaying = false;
  String _currentPage = 'home';

  // Audio
  final AudioPlayer _audioPlayer = AudioPlayer();

  // WebSocket
  WebSocketChannel? _wsChannel;
  bool _wsConnected = false;

  // Video background (main)
  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;
  static const _bgVideoUrl = 'assets/videos/bg_video.mp4';

  // Video background (account status card)
  late VideoPlayerController _titleVideoController;
  bool _titleVideoReady = false;
  static const _titleVideoUrl = 'assets/videos/bg_title.mp4';

  // Animation controllers
  late AnimationController _pulseRingController;
  late AnimationController _dashRingController;
  late AnimationController _fanMenuController;
  late AnimationController _fanStaggerController;
  late AnimationController _sidebarController;
  late AnimationController _toolsBtnController; // ← animasi tools button (reuse untuk dox qr)

  // News
  final PageController _newsController = PageController();
  final ScrollController _quickAccessController = ScrollController();

  // ── Futuristic Quick Access Carousel ──
  late PageController _quickAccessPageController;
  int _quickAccessCurrentPage = 1;
  List<Map<String, dynamic>> _quickAccessFeatures = [];

  // Settings
  bool _settingsNotif = true;
  bool _settingsSound = true;
  bool _settingsAutoConnect = false;
  bool _settingsDarkMode = true;

  // ── Init ──────────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();

    _pulseRingController = AnimationController(
      vsync: this, duration: Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _dashRingController = AnimationController(
      vsync: this, duration: Duration(seconds: 8),
    )..repeat();

    _fanMenuController = AnimationController(
      vsync: this, duration: Duration(milliseconds: 300),
    )..addListener(() { if (mounted) setState(() {}); });

    _fanStaggerController = AnimationController(
      vsync: this, duration: Duration(milliseconds: 400),
    )..addListener(() { if (mounted) setState(() {}); });

    _sidebarController = AnimationController(
      vsync: this, duration: Duration(milliseconds: 260),
    );

    // Animasi untuk button "TOOLS YAKUZA" (realtime shimmer + pulse)
    _toolsBtnController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();

    _username    = widget.username;
    _password    = widget.password;
    _role        = widget.role;
    _sessionKey  = widget.sessionKey;
    _expiredDate = widget.expiredDate;
    _listBug     = widget.listBug;
    _listPayload = widget.listPayload;
    _listDDoS    = widget.listDDoS;
    _newsList    = widget.news;

    _loadUserData();
    _connectWebSocket();
    _initBattery();
    _initTempMonitor();
    _fetchPrayerTimes();
    _startClockTimer();
    _initAudio();
    _fetchLatestAnime();
    _initBgVideo();
    _initTitleVideo();
    _initQuickAccessCarousel();
    _fetchBroadcasts();
    _fetchDashboardSenders();
    _fetchUserStats(); // ← Fetch total member & VIP
  }

  @override
  void dispose() {
    _bgVideoController.dispose();
    _titleVideoController.dispose();
    _pulseRingController.dispose();
    _dashRingController.dispose();
    _fanMenuController.dispose();
    _fanStaggerController.dispose();
    _sidebarController.dispose();
    _toolsBtnController.dispose();
    _newsController.dispose();
    _quickAccessController.dispose();
    _quickAccessPageController.dispose();
    _animeScrollController.dispose();
    _audioPlayer.dispose();
    _wsChannel?.sink.close(status.goingAway);
    _tempTimer?.cancel();
    _clockTimer?.cancel();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // VIDEO BACKGROUND (main)
  // ═══════════════════════════════════════════════════════════════════════════
  void _initBgVideo() {
    _bgVideoController = VideoPlayerController.asset(_bgVideoUrl)
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bgVideoReady = true);
          _bgVideoController.play();
          _bgVideoController.setLooping(true);
          _bgVideoController.setVolume(0.0);
        }
      }).catchError((e) {
        debugPrint('BG video error: $e');
      });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // VIDEO BACKGROUND (Account Status Card)
  // ═══════════════════════════════════════════════════════════════════════════
  void _initTitleVideo() {
    _titleVideoController = VideoPlayerController.asset(_titleVideoUrl)
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _titleVideoReady = true);
          _titleVideoController.play();
          _titleVideoController.setLooping(true);
          _titleVideoController.setVolume(0.0);
        }
      }).catchError((e) {
        debugPrint('Title video error: $e');
      });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // QUICK ACCESS CAROUSEL — Inisialisasi data & PageController
  // ═══════════════════════════════════════════════════════════════════════════
  void _initQuickAccessCarousel() {
    _quickAccessFeatures = [
      {
        'title': 'BUG',
        'subtitle': 'Contact Bug',
        'description': 'Kirim bug ke kontak WhatsApp target dengan berbagai opsi.',
        'icon': FontAwesomeIcons.bug,
        'number': '01',
        'tags': ['BUG', 'CONTACT', 'WA'],
        'button': 'OPEN HERE',
        'color': _C.accent,
        'onTap': () => _showBugTypeModal(),
      },
      {
        'title': 'YAKUZAXSILENCE',
        'subtitle': 'Advanced Bug',
        'description': 'YakuzaXsilence Bug dengan konfigurasi advanced dan lebih powerful.',
        'icon': FontAwesomeIcons.terminal,
        'number': '02',
        'tags': ['YAKUZAXSILENCE', 'ADVANCED', 'TOOLS'],
        'button': 'OPEN HERE',
        'color': Color(0xFFFF6B6B),
        'onTap': () => _navigateTo('custom_bug'),
      },
      {
        'title': 'GROUP',
        'subtitle': 'Group Bug',
        'description': 'Kirim bug ke WhatsApp grup target dengan stealth mode.',
        'icon': FontAwesomeIcons.users,
        'number': '03',
        'tags': ['GROUP', 'WA', 'MASS'],
        'button': 'OPEN HERE',
        'color': Color(0xFFCC2E25),
        'onTap': () => _navigateTo('group_bug'),
      },
      {
        'title': 'VIP',
        'subtitle': 'Premium Access',
        'description': 'Upgrade ke VIP untuk akses fitur premium dan unlimited.',
        'icon': FontAwesomeIcons.crown,
        'number': '04',
        'tags': ['VIP', 'PREMIUM', 'UPGRADE'],
        'button': 'OPEN HERE',
        'color': Color(0xFFFFB800),
        'onTap': () => _navigateTo('vip'),
      },
      {
        'title': 'PAIR',
        'subtitle': 'Pair Spam',
        'description': 'Spam pairing code ke WhatsApp target via Baileys engine.',
        'icon': FontAwesomeIcons.link,
        'number': '05',
        'tags': ['PAIR', 'SPAM', 'BAILEYS'],
        'button': 'OPEN HERE',
        'color': Color(0xFF9333EA),
        'onTap': () => _navigateTo('pair_spam'),
      },
      {
        'title': 'ADMIN',
        'subtitle': 'Panel Management',
        'description': 'Akses panel admin untuk manajemen user dan sistem.',
        'icon': FontAwesomeIcons.userShield,
        'number': '06',
        'tags': ['ADMIN', 'USER', 'PANEL'],
        'button': 'OPEN HERE',
        'color': Color(0xFF00BFFF),
        'onTap': () => _navigateTo('admin'),
      },
    ];

    _quickAccessPageController = PageController(
      initialPage: _quickAccessCurrentPage,
      viewportFraction: 0.72,
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // FETCH USER STATS (Total Member & Total VIP)
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> _fetchUserStats() async {
    if (_sessionKey.isEmpty) return;
    setState(() => _isLoadingStats = true);
    try {
      final res = await http.get(Uri.parse(
        "https://omhc-host-premium.yakuza.biz.id/api/user/listUsers?key=${Uri.encodeComponent(_sessionKey)}",
      )).timeout(Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['authorized'] == true) {
          final users = data['users'] as List? ?? [];
          int memberCount = 0;
          int vipCount = 0;
          for (final u in users) {
            if (u is Map) {
              final role = (u['role'] ?? 'member').toString().toLowerCase();
              if (role == 'vip') {
                vipCount++;
              } else if (role == 'member') {
                memberCount++;
              }
            }
          }
          if (mounted) {
            setState(() {
              _totalMembers = memberCount;
              _totalVips = vipCount;
              _isLoadingStats = false;
            });
          }
        } else {
          if (mounted) setState(() => _isLoadingStats = false);
        }
      } else {
        if (mounted) setState(() => _isLoadingStats = false);
      }
    } catch (_) {
      if (mounted) setState(() => _isLoadingStats = false);
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // FETCH LATEST ANIME
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> _fetchLatestAnime() async {
    setState(() => _animeLoading = true);
    try {
      final response = await http.get(
        Uri.parse('https://www.sankavollerei.com/anime/home'),
      ).timeout(Duration(seconds: 10));
      if (response.statusCode == 200) {
        final jsonData = jsonDecode(response.body);
        final ongoingList = jsonData['data']?['ongoing']?['animeList'] ?? [];
        final completedList = jsonData['data']?['completed']?['animeList'] ?? [];
        final List<dynamic> combined = [];
        combined.addAll(ongoingList.take(10));
        combined.addAll(completedList.take(5));
        if (mounted) {
          setState(() {
            _latestAnime = combined;
            _animeLoading = false;
          });
        }
      } else {
        throw Exception('status ${response.statusCode}');
      }
    } catch (e) {
      if (mounted) {
        setState(() => _animeLoading = false);
      }
    }
  }

  // ── Real-time Battery ─────────────────────────────────────────────────────
  Future<void> _initBattery() async {
    try {
      final level = await _battery.batteryLevel;
      final state = await _battery.batteryState;
      if (mounted) {
        setState(() {
          _batteryLevel = '$level%';
          _batteryState = state;
        });
      }
      _battery.onBatteryStateChanged.listen((s) async {
        final lvl = await _battery.batteryLevel;
        if (mounted) {
          setState(() {
            _batteryLevel = '$lvl%';
            _batteryState = s;
          });
        }
      });
    } catch (_) {
      if (mounted) setState(() => _batteryLevel = '--');
    }
  }

  // ── Real-time Temperature ─────────────────────────────────────────────────
  void _initTempMonitor() {
    _fetchDeviceTemp();
    _tempTimer = Timer.periodic(Duration(seconds: 30), (_) => _fetchDeviceTemp());
  }

  Future<void> _fetchDeviceTemp() async {
    try {
      final temp = await _deviceChannel.invokeMethod<double>('getBatteryTemp');
      if (temp != null && mounted) {
        setState(() => _deviceTemp = '${temp.toStringAsFixed(1)}°C');
      }
    } catch (_) {
      if (mounted && _deviceTemp == '--°C') setState(() => _deviceTemp = 'N/A');
    }
  }

  // ── Prayer Schedule ───────────────────────────────────────────────────────
  void _startClockTimer() {
    _clockTimer = Timer.periodic(Duration(seconds: 1), (_) {
      if (mounted) {
        setState(() {
          _now = DateTime.now();
          _updateNextPrayer();
        });
      }
    });
  }

  Future<void> _fetchPrayerTimes() async {
    setState(() { _prayerLoading = true; _prayerError = ''; });
    try {
      final now = DateTime.now();
      final ts = now.millisecondsSinceEpoch ~/ 1000;
      final url = 'https://api.aladhan.com/v1/timings/$ts?latitude=-6.2088&longitude=106.8456&method=11';
      final res = await http.get(Uri.parse(url))
          .timeout(Duration(seconds: 10));
      if (res.statusCode == 200) {
        final body = jsonDecode(res.body);
        final timings = body['data']['timings'] as Map<String, dynamic>;
        final Map<String, String> times = {};
        for (final k in _prayerKeys) {
          final raw = timings[k]?.toString() ?? '';
          times[k] = raw.contains(' ') ? raw.split(' ').first : raw;
        }
        if (mounted) {
          setState(() {
            _prayerTimes = times;
            _prayerLoading = false;
            _updateNextPrayer();
          });
        }
      } else {
        throw Exception('status ${res.statusCode}');
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _prayerLoading = false;
          _prayerError = 'Gagal memuat jadwal';
        });
      }
    }
  }

  void _updateNextPrayer() {
    if (_prayerTimes.isEmpty) return;
    final now = _now;
    String? nextKey;
    Duration? minDiff;

    for (final k in _prayerKeys) {
      final t = _prayerTimes[k];
      if (t == null) continue;
      final parts = t.split(':');
      if (parts.length < 2) continue;
      final h = int.tryParse(parts[0]) ?? 0;
      final m = int.tryParse(parts[1]) ?? 0;
      var prayerDt = DateTime(now.year, now.month, now.day, h, m);
      if (prayerDt.isBefore(now)) {
        prayerDt = prayerDt.add(Duration(days: 1));
      }
      final diff = prayerDt.difference(now);
      if (minDiff == null || diff < minDiff) {
        minDiff = diff;
        nextKey = k;
      }
    }

    _nextPrayerKey = nextKey ?? '';
    if (minDiff != null) {
      final h = minDiff.inHours.toString().padLeft(2, '0');
      final m = (minDiff.inMinutes % 60).toString().padLeft(2, '0');
      final s = (minDiff.inSeconds % 60).toString().padLeft(2, '0');
      _prayerCountdown = '$h:$m:$s';
    }
  }

  bool _isPrayerPassed(String key) {
    final t = _prayerTimes[key];
    if (t == null) return false;
    final parts = t.split(':');
    if (parts.length < 2) return false;
    final h = int.tryParse(parts[0]) ?? 0;
    final m = int.tryParse(parts[1]) ?? 0;
    final prayerDt = DateTime(_now.year, _now.month, _now.day, h, m);
    return prayerDt.isBefore(_now);
  }

  // ── Data Loading ──────────────────────────────────────────────────────────
  Future<void> _loadUserData() async {
    try {
      final deviceInfo = DeviceInfoPlugin();
      final androidInfo = await deviceInfo.androidInfo;
      _uid = androidInfo.id;
    } catch (_) { _uid = 'unknown'; }
    if (mounted) setState(() {});
    _refreshRoleFromServer();
  }

  Future<void> _refreshRoleFromServer() async {
    if (_sessionKey.isEmpty) return;
    try {
      final res = await http.get(Uri.parse(
        "https://omhc-host-premium.yakuza.biz.id/meByKey?key=${Uri.encodeComponent(_sessionKey)}",
      )).timeout(Duration(seconds: 8));
      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        final newRole = (data['role'] ?? 'member').toString();
        final newExpired = (data['expiredDate'] ?? _expiredDate).toString();
        if (newRole != _role || newExpired != _expiredDate) {
          if (mounted) {
            setState(() {
              _role = newRole;
              _expiredDate = newExpired;
            });
          }
        }
      }
    } catch (_) {}
  }

  // ── WebSocket ─────────────────────────────────────────────────────────────
  void _connectWebSocket() {
    try {
      _wsChannel = WebSocketChannel.connect(Uri.parse('https://omhc-host-premium.yakuza.biz.id'));
      _wsChannel!.sink.add(jsonEncode({'type': 'validate', 'key': _sessionKey, 'androidId': _uid}));
      _wsChannel!.sink.add(jsonEncode({'type': 'stats'}));
      _wsChannel!.stream.listen(
        (msg) => _handleWsMessage(jsonDecode(msg)),
        onDone: () { setState(() => _wsConnected = false); Future.delayed(Duration(seconds: 5), _connectWebSocket); },
        onError: (_) { setState(() => _wsConnected = false); Future.delayed(Duration(seconds: 5), _connectWebSocket); },
      );
      setState(() => _wsConnected = true);
    } catch (_) { setState(() => _wsConnected = false); }
  }

  void _handleWsMessage(Map<String, dynamic> data) {
    if (data['type'] == 'myInfo' && data['valid'] == false) {
      String msg = 'Session invalid. Please login again.';
      if (data['reason'] == 'androidIdMismatch') msg = 'Your account has logged on another device.';
      else if (data['reason'] == 'keyInvalid') msg = 'Key is not valid. Please login again.';
      _handleInvalidSession(msg);
    }
  }

  Future<void> _handleInvalidSession(String message) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context, barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: _C.surface.withOpacity(0.98),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: _C.accent.withOpacity(0.5), width: 1),
        ),
        title: Row(children: [
          Icon(Icons.warning_amber_rounded, color: _C.accent),
          SizedBox(width: 10),
          Text('Session Expired', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 16)),
        ]),
        content: Text(message, style: TextStyle(fontSize: 14)),
        actions: [TextButton(
          onPressed: () => Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => LoginPage()), (r) => false),
          child: Text('OK'),
        )],
      ),
    );
  }

  // ── Senders ───────────────────────────────────────────────────────────────
  Future<void> _fetchDashboardSenders() async {
    if (_isLoadingSenders) return;
    setState(() => _isLoadingSenders = true);
    try {
      final res = await http.get(Uri.parse(
        "https://omhc-host-premium.yakuza.biz.id/mySender?key=${_sessionKey}",
      )).timeout(Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['connections'] != null) {
          final conns = data['connections'];
          List<dynamic> allSenders = [];
          if (conns is Map) {
            allSenders = [...(conns['private'] ?? []), ...(conns['global'] ?? [])];
          } else if (conns is List) {
            allSenders = conns;
          }
          if (mounted) {
            setState(() {
              _dashboardSenders = allSenders;
              _totalCount = allSenders.length;
              _activeCount = allSenders.where((s) => s is Map && (s['isActive'] ?? true) == true).length;
            });
          }
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _isLoadingSenders = false);
  }

  Future<void> _fetchBroadcasts() async {
    if (_sessionKey.isEmpty) return;
    try {
      final res = await http.get(Uri.parse(
        "https://omhc-host-premium.yakuza.biz.id/getBroadcasts?key=${Uri.encodeComponent(_sessionKey)}",
      )).timeout(Duration(seconds: 8));
      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        final broadcasts = data['broadcasts'] as List? ?? [];
        if (broadcasts.isNotEmpty && mounted) {
          Future.delayed(Duration(milliseconds: 1500), () {
            if (mounted) _showBroadcastPopup(broadcasts);
          });
        }
      }
    } catch (_) {}
  }

  void _showBroadcastPopup(List<dynamic> broadcasts) {
    if (broadcasts.isEmpty) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _BroadcastDialog(
        broadcasts: broadcasts,
        sessionKey: _sessionKey,
        onDismiss: () {
          Navigator.of(context).pop();
        },
      ),
    );
  }

  // ── Audio ─────────────────────────────────────────────────────────────────
  Future<void> _initAudio() async {
    try {
      await _audioPlayer.setSourceUrl('https://files.catbox.moe/yfd2b4.mp3');
      await _audioPlayer.setReleaseMode(ReleaseMode.loop);
      await _audioPlayer.setVolume(0.3);
    } catch (_) {}
  }

  Future<void> _toggleMusic() async {
    if (_isMusicPlaying) await _audioPlayer.pause();
    else await _audioPlayer.resume();
    setState(() => _isMusicPlaying = !_isMusicPlaying);
  }

  // ── Sidebar ───────────────────────────────────────────────────────────────
  void _openSidebar() {
    setState(() => _isSidebarOpen = true);
    _sidebarController.forward();
  }

  void _closeSidebar() {
    _sidebarController.reverse().then((_) {
      if (mounted) setState(() => _isSidebarOpen = false);
    });
  }

  void _selectFromDrawer(String page) {
    _closeSidebar();
    _navigateTo(page);
  }

  // ── Navigation ────────────────────────────────────────────────────────────
  void _navigateTo(String page) {
    setState(() => _currentPage = page);
    switch (page) {
      case 'home': setState(() => _currentNavIndex = 0); break;
      case 'bug': Navigator.of(context).push(MaterialPageRoute(builder: (_) => AttackPage(username: _username, password: _password, listBug: _listBug, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))); break;
      case 'custom_bug': Navigator.of(context).push(MaterialPageRoute(builder: (_) => CustomAttackPage(username: _username, password: _password, listPayload: _listPayload, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))); break;
      case 'group_bug': Navigator.of(context).push(MaterialPageRoute(builder: (_) => GroupBugPage(username: _username, password: _password, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))); break;
      case 'pair_spam': Navigator.of(context).push(MaterialPageRoute(builder: (_) => PairSpamPage(sessionKey: _sessionKey, username: _username))); break;
      case 'rat':
        if (_role.toLowerCase() != 'owner' && _role.toLowerCase() != 'vip') {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('RAT hanya untuk VIP & Owner', style: TextStyle(fontFamily: 'ShareTechMono')),
            backgroundColor: Color(0xFFFF3B30),
          ));
          return;
        }
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => DeviceDashboardPage(username: _username, sessionKey: _sessionKey)));
        break;
      case 'vip': Navigator.of(context).push(MaterialPageRoute(builder: (_) => VipUpgradePage(username: _username, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))).then((_) => _refreshRoleFromServer()); break;
      case 'ddos': Navigator.of(context).push(MaterialPageRoute(builder: (_) => AttackPanel(sessionKey: _sessionKey, listDDoS: _listDDoS))); break;
      case 'tools': Navigator.of(context).push(MaterialPageRoute(builder: (_) => ToolsPage(sessionKey: _sessionKey, userRole: _role, username: _username, listDDoS: _listDDoS))); break;
      case 'seller': Navigator.of(context).push(MaterialPageRoute(builder: (_) => SellerPage(keyToken: _sessionKey))); break;
      case 'admin': Navigator.of(context).push(MaterialPageRoute(builder: (_) => AdminPage(sessionKey: _sessionKey))); break;
      case 'sender': Navigator.of(context).push(MaterialPageRoute(builder: (_) => SenderPage(sessionKey: _sessionKey))); break;
      case 'change_password': Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChangePasswordPage(username: _username, sessionKey: _sessionKey))); break;
      case 'leaderboard': Navigator.of(context).push(MaterialPageRoute(builder: (_) => LeaderboardPage(sessionKey: _sessionKey, username: _username))); break;
      case 'settings': _showSettingsPage(); break;
    }
  }

  void _onNavTap(int index) {
    switch (index) {
      case 0: setState(() { _currentNavIndex = 0; _currentPage = 'home'; }); break;
      case 1: setState(() => _currentNavIndex = 1); Navigator.of(context).push(MaterialPageRoute(builder: (_) => ToolsPage(sessionKey: _sessionKey, userRole: _role, username: _username, listDDoS: _listDDoS))); break;
      case 2: break;
      case 3: setState(() => _currentNavIndex = 3); Navigator.of(context).push(MaterialPageRoute(builder: (_) => VipUpgradePage(username: _username, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))).then((_) => _refreshRoleFromServer()); break;
      case 4: _showSettingsPage(); break;
    }
  }

  void _toggleFanMenu() {
    setState(() => _isFanMenuOpen = !_isFanMenuOpen);
    if (_isFanMenuOpen) { _fanMenuController.forward(); _fanStaggerController.forward(); }
    else { _fanMenuController.reverse(); _fanStaggerController.reverse(); }
  }

  void _closeFanMenu() {
    if (_isFanMenuOpen) {
      setState(() => _isFanMenuOpen = false);
      _fanMenuController.reverse();
      _fanStaggerController.reverse();
    }
  }

  void _copyUid() {
    Clipboard.setData(ClipboardData(text: _uid));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('UID copied!', style: TextStyle(color: _C.text)),
      backgroundColor: _C.card, behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      duration: Duration(seconds: 2),
    ));
  }

  Future<void> _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    _wsChannel?.sink.close(status.goingAway);
    await _audioPlayer.stop();
    if (mounted) Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => LoginPage()), (r) => false);
  }

  IconData _batteryIcon() {
    final lvl = int.tryParse(_batteryLevel.replaceAll('%', '')) ?? 100;
    if (_batteryState == BatteryState.charging) return Icons.battery_charging_full;
    if (lvl >= 80) return Icons.battery_full;
    if (lvl >= 50) return Icons.battery_4_bar;
    if (lvl >= 20) return Icons.battery_2_bar;
    return Icons.battery_alert;
  }

  Color _batteryColor() {
    final lvl = int.tryParse(_batteryLevel.replaceAll('%', '')) ?? 100;
    if (_batteryState == BatteryState.charging) return Color(0xFF00D2FF);
    if (lvl >= 50) return Color(0xFFFF3B30);
    if (lvl >= 20) return _C.gold;
    return _C.danger;
  }

  // ── MODALS ────────────────────────────────────────────────────────────────
  void _showBugTypeModal() {
    showModalBottomSheet(
      context: context,
      backgroundColor: _C.card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => Container(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 40, height: 4, decoration: BoxDecoration(color: _C.muted2, borderRadius: BorderRadius.circular(2))),
            SizedBox(height: 16),
            Text('SELECT BUG TYPE', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 14, fontWeight: FontWeight.bold, color: _C.text)),
            SizedBox(height: 20),
            _bugTypeOption(FontAwesomeIcons.user, 'Contact Bug', () { Navigator.of(ctx).pop(); Navigator.of(context).push(MaterialPageRoute(builder: (_) => AttackPage(username: _username, password: _password, listBug: _listBug, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))); }),
            SizedBox(height: 10),
            _bugTypeOption(FontAwesomeIcons.usersSlash, 'Group Bug', () { Navigator.of(ctx).pop(); Navigator.of(context).push(MaterialPageRoute(builder: (_) => GroupBugPage(username: _username, password: _password, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))); }),
            SizedBox(height: 10),
            _bugTypeOption(FontAwesomeIcons.terminal, 'YakuzaXsilence Bug', () { Navigator.of(ctx).pop(); Navigator.of(context).push(MaterialPageRoute(builder: (_) => CustomAttackPage(username: _username, password: _password, listPayload: _listPayload, role: _role, expiredDate: _expiredDate, sessionKey: _sessionKey))); }),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _bugTypeOption(IconData icon, String label, VoidCallback onTap) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap, borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(color: _C.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.border)),
          child: Row(children: [
            Container(width: 38, height: 38, decoration: BoxDecoration(color: _C.accent.withOpacity(0.12), borderRadius: BorderRadius.circular(10)), child: Icon(icon, color: _C.accent, size: 16)),
            SizedBox(width: 14),
            Expanded(child: Text(label, style: TextStyle(color: _C.text, fontSize: 15, fontWeight: FontWeight.w600))),
            Icon(Icons.chevron_right, color: _C.muted, size: 20),
          ]),
        ),
      ),
    );
  }

  void _showAccountModal() {
    showModalBottomSheet(
      context: context, backgroundColor: _C.card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => Container(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(color: _C.muted2, borderRadius: BorderRadius.circular(2))),
          SizedBox(height: 20),
          Container(width: 64, height: 64, decoration: BoxDecoration(color: _C.accent.withOpacity(0.15), shape: BoxShape.circle), child: Icon(FontAwesomeIcons.user, color: _C.accent, size: 24)),
          SizedBox(height: 12),
          Text(_username.toUpperCase(), style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 16, fontWeight: FontWeight.bold, color: _C.text)),
          SizedBox(height: 4),
          Text(_role.toUpperCase(), style: TextStyle(fontSize: 11, color: _C.muted)),
          SizedBox(height: 20),
          SizedBox(width: double.infinity, height: 48, child: ElevatedButton(
            onPressed: () { Navigator.of(ctx).pop(); Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChangePasswordPage(username: _username, sessionKey: _sessionKey))); },
            style: ElevatedButton.styleFrom(backgroundColor: _C.gold, foregroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            child: Text('CHANGE PASSWORD', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.bold)),
          )),
          SizedBox(height: 10),
          SizedBox(width: double.infinity, height: 48, child: ElevatedButton(
            onPressed: () { Navigator.of(ctx).pop(); _logout(); },
            style: ElevatedButton.styleFrom(backgroundColor: _C.accent, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            child: Text('LOGOUT', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.bold)),
          )),
          SizedBox(height: 20),
        ]),
      ),
    );
  }

  void _showSettingsPage() {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => _SettingsPage(
      username: _username, sessionKey: _sessionKey,
      notif: _settingsNotif, sound: _settingsSound,
      autoConnect: _settingsAutoConnect, darkMode: _settingsDarkMode,
      onToggleNotif: (v) => setState(() => _settingsNotif = v),
      onToggleSound: (v) => setState(() => _settingsSound = v),
      onToggleAutoConnect: (v) => setState(() => _settingsAutoConnect = v),
      onToggleDarkMode: (v) => setState(() => _settingsDarkMode = v),
      onToggleMusic: _toggleMusic, isMusicPlaying: _isMusicPlaying,
    )));
  }

  // ═════════════════════════════════════════════════════════════════════════
  // BUILD
  // ═════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          // ── Video Background ──
          if (_bgVideoReady && _bgVideoController.value.isInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bgVideoController.value.size.width,
                  height: _bgVideoController.value.size.height,
                  child: VideoPlayer(_bgVideoController),
                ),
              ),
            )
          else
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF000000), Color(0xFF000000), Color(0xFF0a0a0a)],
                ),
              ),
            ),
          // ── Dark overlay ──
          Container(color: Colors.black.withOpacity(0.55)),

          // ── Main scrollable content ──
          SafeArea(
            top: true,
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                // ── 1. HEADER ──
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  child: Row(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Hey, $_username!',
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: _C.text,
                              fontFamily: 'MADEEvolveSansEVO',
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            'Welcome back! 👋',
                            style: TextStyle(fontSize: 13, color: _C.muted),
                          ),
                        ],
                      ),
                      Spacer(),
                      // Leaderboard button
                      GestureDetector(
                        onTap: () => _navigateTo('leaderboard'),
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: _C.accent.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: _C.accent.withOpacity(0.35)),
                            boxShadow: [
                              BoxShadow(
                                color: _C.accent.withOpacity(0.2),
                                blurRadius: 8,
                                spreadRadius: 0,
                                offset: Offset(0, 0),
                              ),
                            ],
                          ),
                          child: Icon(Icons.leaderboard_rounded,
                              color: _C.accent, size: 20),
                        ),
                      ),
                      SizedBox(width: 10),
                      // Notification bell
                      GestureDetector(
                        onTap: () => _navigateTo('settings'),
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: _C.surface,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: _C.border),
                          ),
                          child: Icon(Icons.notifications_none_rounded,
                              color: _C.text, size: 20),
                        ),
                      ),
                      SizedBox(width: 10),
                      // Avatar circle
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _C.accent,
                          border: Border.all(color: _C.text, width: 2),
                        ),
                        child: Center(
                          child: Text(
                            _username.isNotEmpty ? _username[0].toUpperCase() : '?',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: _C.text,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // ── 2. ACCOUNT STATUS CARD (with VIDEO bg) ──
                _buildAccountStatusCard(),

                // ── 3. ACTION BUTTONS ROW ──
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  child: Row(
                    children: [
                      Expanded(
                        child: GestureDetector(
                          onTap: _showBugTypeModal,
                          child: Container(
                            height: 48,
                            decoration: BoxDecoration(
                              color: Color(0xFF1a1a1a),
                              borderRadius: BorderRadius.circular(24),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.bug_report, color: Colors.white, size: 18),
                                SizedBox(width: 8),
                                Text(
                                  'LAUNCH BUG',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'MADEEvolveSansEVO',
                                    letterSpacing: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: GestureDetector(
                          onTap: () => _navigateTo('sender'),
                          child: Container(
                            height: 48,
                            decoration: BoxDecoration(
                              color: _C.accent,
                              borderRadius: BorderRadius.circular(24),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.send, color: Colors.white, size: 18),
                                SizedBox(width: 8),
                                Text(
                                  'SENDER',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'MADEEvolveSansEVO',
                                    letterSpacing: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // ── 4. FUTURISTIC QUICK ACCESS CAROUSEL ──
                _buildFuturisticQuickAccess(),

                // ── 5. DUA KOTAK STATISTIK ──
                _buildStatsBoxes(),

                SizedBox(height: 32),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // DUA KOTAK STATISTIK — Senders + Members/VIPs
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildStatsBoxes() {
    final offlineCount = _totalCount - _activeCount;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── KOTAK KIRI: SENDERS (Online + Offline) ──
          Expanded(
            child: _buildStatCard(
              title: 'SENDERS',
              icon: Icons.phonelink_ring_rounded,
              accentColor: _C.accent,
              onTap: () => _navigateTo('sender'),
              rows: [
                {
                  'label': 'Online',
                  'value': '$_activeCount',
                  'color': Color(0xFF34D399),
                  'dotGlow': true,
                },
                {
                  'label': 'Offline',
                  'value': '$offlineCount',
                  'color': Color(0xFF6B7280),
                  'dotGlow': false,
                },
              ],
            ),
          ),

          SizedBox(width: 12),

          // ── KOTAK KANAN: USERS (Member + VIP) ──
          Expanded(
            child: _buildStatCard(
              title: 'USERS',
              icon: Icons.people_alt_rounded,
              accentColor: Color(0xFFFFB800),
              onTap: () => _navigateTo('admin'),
              rows: [
                {
                  'label': 'Member',
                  'value': '$_totalMembers',
                  'color': Color(0xFF00BFFF),
                  'dotGlow': false,
                },
                {
                  'label': 'VIP',
                  'value': '$_totalVips',
                  'color': Color(0xFFFFB800),
                  'dotGlow': true,
                },
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Stat Card Builder ──
  Widget _buildStatCard({
    required String title,
    required IconData icon,
    required Color accentColor,
    required VoidCallback onTap,
    required List<Map<String, dynamic>> rows,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedBuilder(
        animation: _pulseRingController,
        builder: (context, child) {
          final pulse = _pulseRingController.value;
          return Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: accentColor.withOpacity(0.2),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: accentColor.withOpacity(0.08 + pulse * 0.04),
                  blurRadius: 16,
                  spreadRadius: 0,
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── Header (icon + title + arrow) ──
                Row(
                  children: [
                    Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        color: accentColor.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(9),
                        border: Border.all(
                          color: accentColor.withOpacity(0.25),
                          width: 1,
                        ),
                      ),
                      child: Icon(icon, color: accentColor, size: 16),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        title,
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: Colors.white.withOpacity(0.6),
                          fontFamily: 'ShareTechMono',
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: Colors.white.withOpacity(0.2),
                      size: 10,
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // ── Rows ──
                ...rows.asMap().entries.map((entry) {
                  final i = entry.key;
                  final row = entry.value;
                  final isLast = i == rows.length - 1;
                  return Padding(
                    padding: EdgeInsets.only(bottom: isLast ? 0 : 12),
                    child: _buildStatRow(
                      label: row['label'] as String,
                      value: row['value'] as String,
                      color: row['color'] as Color,
                      dotGlow: row['dotGlow'] as bool,
                    ),
                  );
                }),
              ],
            ),
          );
        },
      ),
    );
  }

  // ── Stat Row (dot + label + value) ──
  Widget _buildStatRow({
    required String label,
    required String value,
    required Color color,
    required bool dotGlow,
  }) {
    return Row(
      children: [
        // Dot dengan optional glow animation
        dotGlow
            ? AnimatedBuilder(
                animation: _pulseRingController,
                builder: (context, child) {
                  final p = _pulseRingController.value;
                  return Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: color,
                      boxShadow: [
                        BoxShadow(
                          color: color.withOpacity(0.5 + p * 0.3),
                          blurRadius: 6 + p * 4,
                          spreadRadius: 0.5,
                        ),
                      ],
                    ),
                  );
                },
              )
            : Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withOpacity(0.7),
                ),
              ),
        const SizedBox(width: 10),
        // Label
        Expanded(
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: Colors.white.withOpacity(0.7),
              fontFamily: 'ShareTechMono',
              letterSpacing: 0.5,
            ),
          ),
        ),
        // Value
        Text(
          value,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w900,
            color: color,
            fontFamily: 'MADEEvolveSansEVO',
            height: 1,
            letterSpacing: 0.5,
          ),
        ),
      ],
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // ACCOUNT STATUS CARD (dengan video background)
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildAccountStatusCard() {
    final isVideoReady = _titleVideoReady &&
        _titleVideoController.value.isInitialized;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Container(
          height: 160,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF1a1a1a), Color(0xFF0a0a0a)],
            ),
          ),
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (isVideoReady)
                FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _titleVideoController.value.size.width,
                    height: _titleVideoController.value.size.height,
                    child: VideoPlayer(_titleVideoController),
                  ),
                ),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Colors.black.withOpacity(0.55),
                      Colors.black.withOpacity(0.75),
                    ],
                  ),
                ),
              ),
              Positioned(
                top: -40,
                right: -40,
                child: Container(
                  width: 140,
                  height: 140,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        _C.accent.withOpacity(0.25),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 3,
                          height: 12,
                          decoration: BoxDecoration(
                            color: _C.accent,
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'ACCOUNT STATUS',
                          style: TextStyle(
                            fontSize: 10,
                            color: Colors.white.withOpacity(0.6),
                            fontFamily: 'ShareTechMono',
                            letterSpacing: 2,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Flexible(
                          child: Text(
                            _role.toUpperCase(),
                            style: TextStyle(
                              fontSize: 32,
                              fontWeight: FontWeight.w900,
                              color: Colors.white,
                              fontFamily: 'MADEEvolveSansEVO',
                              letterSpacing: 1,
                              height: 1,
                              shadows: [
                                Shadow(
                                  color: _C.accent.withOpacity(0.5),
                                  blurRadius: 12,
                                ),
                              ],
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: _C.accent.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(
                              color: _C.accent.withOpacity(0.4),
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: 5,
                                height: 5,
                                decoration: BoxDecoration(
                                  color: _C.accent,
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: _C.accent,
                                      blurRadius: 4,
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 5),
                              Text(
                                'Active',
                                style: TextStyle(
                                  fontSize: 10,
                                  color: _C.accent,
                                  fontFamily: 'ShareTechMono',
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const Spacer(),
                    Row(
                      children: [
                        Icon(
                          Icons.calendar_today_rounded,
                          color: Colors.white.withOpacity(0.55),
                          size: 12,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          'Exp: $_expiredDate',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.white.withOpacity(0.75),
                            fontFamily: 'ShareTechMono',
                            letterSpacing: 0.5,
                          ),
                        ),
                        const Spacer(),
                        Text(
                          '$_activeCount/$_totalCount',
                          style: TextStyle(
                            fontSize: 14,
                            color: _C.accent,
                            fontFamily: 'ShareTechMono',
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.5,
                          ),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          'senders',
                          style: TextStyle(
                            fontSize: 11,
                            color: Colors.white.withOpacity(0.55),
                            fontFamily: 'ShareTechMono',
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // FUTURISTIC QUICK ACCESS — 3D Carousel + TOOLS button panjang
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _buildFuturisticQuickAccess() {
    final screenWidth = MediaQuery.of(context).size.width;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // ── Carousel 3D (dots dihapus) ──
        SizedBox(
          height: 340,
          child: PageView.builder(
            controller: _quickAccessPageController,
            physics: const BouncingScrollPhysics(),
            onPageChanged: (i) => setState(() => _quickAccessCurrentPage = i),
            itemCount: _quickAccessFeatures.length,
            itemBuilder: (context, index) {
              return AnimatedBuilder(
                animation: _quickAccessPageController,
                builder: (context, child) {
                  double pageOffset = 0.0;
                  if (_quickAccessPageController.position.haveDimensions) {
                    pageOffset = (_quickAccessPageController.page ?? 0) - index;
                  } else {
                    pageOffset = (_quickAccessCurrentPage - index).toDouble();
                  }

                  final scale = (1 - (pageOffset.abs() * 0.15)).clamp(0.75, 1.0);
                  final rotationY = pageOffset * 0.4;
                  final translateY = pageOffset.abs() * 12.0;
                  final opacity = (1 - (pageOffset.abs() * 0.35)).clamp(0.4, 1.0);

                  return Transform(
                    alignment: Alignment.center,
                    transform: Matrix4.identity()
                      ..setEntry(3, 2, 0.0015)
                      ..rotateY(rotationY)
                      ..translate(0.0, translateY)
                      ..scale(scale),
                    child: Opacity(
                      opacity: opacity,
                      child: _buildFeatureCard(
                        _quickAccessFeatures[index],
                        index,
                        screenWidth,
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),

        const SizedBox(height: 24),

        // ── ACTION BUTTONS — TOOLS + DOX QR (bersampingan) ──
        _buildActionButtonsRow(),

        const SizedBox(height: 10),

        // ── BUTTON GRATISAN BY OMHC (full width — hitam silver) ──
        _buildGratisanBtn(),

        const SizedBox(height: 8),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  // ACTION BUTTONS — TOOLS YAKUZA + DOX QR (bersampingan)
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildActionButtonsRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          Expanded(
            child: _buildAnimatedBtn(
              controller: _toolsBtnController,
              title: 'TOOLS YAKUZA',
              subtitle: 'All Features',
              icon: Icons.rocket_launch_rounded,
              color: _C.accent,
              colorDark: const Color(0xFF991133),
              isLocked: false,
              onTap: () => _navigateTo('tools'),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: _buildAnimatedBtn(
              controller: _toolsBtnController, // reuse controller agar tetap beranimasi
              title: 'DOXING QRIS',
              subtitle: 'QR Generator',
              icon: Icons.qr_code_2_rounded,
              color: const Color(0xFF00BFFF),
              colorDark: const Color(0xFF0077B6),
              isLocked: false,
              onTap: _handleDoxQrTap,
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  // BUTTON GRATISAN BY OMHC (full width — hitam silver)
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildGratisanBtn() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: _buildAnimatedBtn(
        controller: _toolsBtnController, // reuse controller agar tetap beranimasi
        title: 'GRATISAN BY OMHC',
        subtitle: 'Free Tools',
        icon: Icons.card_giftcard_rounded,
        color: const Color(0xFFC0C0C0), // silver
        colorDark: const Color(0xFF808080), // silver gelap
        isLocked: false,
        onTap: _showGratisanModal,
      ),
    );
  }

  // ── Handle tap GRATISAN BY OMHC ──
  void _showGratisanModal() {
    showModalBottomSheet(
      context: context,
      backgroundColor: _C.card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => Container(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: _C.muted2,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 16),
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: const Color(0xFFC0C0C0).withOpacity(0.12),
                shape: BoxShape.circle,
                border: Border.all(
                  color: const Color(0xFFC0C0C0).withOpacity(0.4),
                ),
              ),
              child: const Icon(
                Icons.card_giftcard_rounded,
                color: Color(0xFFC0C0C0),
                size: 28,
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'GRATISAN BY OMHC',
              style: TextStyle(
                fontFamily: 'MADEEvolveSansEVO',
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: _C.text,
                letterSpacing: 1,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'Semua tools gratisan dari OMHC.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, color: _C.muted),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  // ── Generic animated button (dipakai 2x) ──
  Widget _buildAnimatedBtn({
    required AnimationController controller,
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required Color colorDark,
    required bool isLocked,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedBuilder(
        animation: controller,
        builder: (context, child) {
          final t = controller.value;
          final shimmerPos = t;
          final pulse = 0.5 + (math.sin(t * 2 * math.pi) * 0.5).abs();
          final borderOpacity = 0.35 + pulse * 0.35;

          return Container(
            height: 72,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: color.withOpacity(borderOpacity),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.15 + pulse * 0.15),
                  blurRadius: 16 + pulse * 10,
                  spreadRadius: 0 + pulse * 2,
                ),
                BoxShadow(
                  color: Colors.black.withOpacity(0.4),
                  blurRadius: 10,
                  offset: const Offset(0, 5),
                ),
              ],
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: const [Color(0xFF1a1a1a), Color(0xFF0a0a0a)],
              ),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Stack(
                children: [
                  // Shimmer sweep
                  Positioned.fill(
                    child: AnimatedBuilder(
                      animation: controller,
                      builder: (context, _) {
                        return Transform.translate(
                          offset: Offset(-200 + (shimmerPos * 500), 0),
                          child: Transform.rotate(
                            angle: 0.4,
                            child: Container(
                              width: 60,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [
                                    Colors.white.withOpacity(0.0),
                                    Colors.white.withOpacity(0.08),
                                    Colors.white.withOpacity(0.0),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  // Color gradient
                  Positioned.fill(
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                          colors: [
                            color.withOpacity(0.05 + pulse * 0.05),
                            Colors.transparent,
                            color.withOpacity(0.05 + pulse * 0.05),
                          ],
                        ),
                      ),
                    ),
                  ),
                  // Content
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Row(
                      children: [
                        // Icon box
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: color.withOpacity(0.15 + pulse * 0.1),
                            borderRadius: BorderRadius.circular(11),
                            border: Border.all(
                              color: color.withOpacity(0.4 + pulse * 0.3),
                              width: 1,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: color.withOpacity(0.3 + pulse * 0.3),
                                blurRadius: 8 + pulse * 6,
                              ),
                            ],
                          ),
                          child: Icon(icon, color: Colors.white, size: 18),
                        ),
                        const SizedBox(width: 10),
                        // Text
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ShaderMask(
                                shaderCallback: (bounds) {
                                  return LinearGradient(
                                    begin: Alignment(-1.0 + (shimmerPos * 2), 0),
                                    end: Alignment(0.0 + (shimmerPos * 2), 0),
                                    colors: [
                                      Colors.white,
                                      Colors.white.withOpacity(0.5),
                                      Colors.white,
                                    ],
                                    stops: const [0.0, 0.5, 1.0],
                                  ).createShader(bounds);
                                },
                                blendMode: BlendMode.srcIn,
                                child: Text(
                                  title,
                                  style: TextStyle(
                                    fontFamily: 'MADEEvolveSansEVO',
                                    fontSize: 11,
                                    fontWeight: FontWeight.w900,
                                    color: Colors.white,
                                    letterSpacing: 1.2,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Row(
                                children: [
                                  Container(
                                    width: 4,
                                    height: 4,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: color.withOpacity(0.6 + pulse * 0.4),
                                      boxShadow: [
                                        BoxShadow(
                                          color: color.withOpacity(0.5 * pulse),
                                          blurRadius: 3,
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 4),
                                  Expanded(
                                    child: Text(
                                      subtitle,
                                      style: TextStyle(
                                        fontSize: 8,
                                        color: Colors.white.withOpacity(0.5),
                                        fontFamily: 'ShareTechMono',
                                        letterSpacing: 0.3,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        // Lock icon or arrow
                        Icon(
                          isLocked
                              ? Icons.lock_rounded
                              : Icons.arrow_forward_rounded,
                          color: isLocked
                              ? color.withOpacity(0.7)
                              : Colors.white.withOpacity(0.85),
                          size: 16,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ── Handle tap DOX QR ──
  void _handleDoxQrTap() {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => DoxQrPage(
        sessionKey: _sessionKey,
        username: _username,
        role: _role,
      ),
    ));
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // FEATURE CARD — Glassmorphism 3D card
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _buildFeatureCard(
      Map<String, dynamic> feature, int index, double screenWidth) {
    final color = feature['color'] as Color;
    final icon = feature['icon'] as IconData;
    final title = feature['title'] as String;
    final subtitle = feature['subtitle'] as String;
    final description = feature['description'] as String;
    final number = feature['number'] as String;
    final tags = feature['tags'] as List<String>;
    final buttonText = feature['button'] as String;
    final onTap = feature['onTap'] as VoidCallback;
    final isActive = index == _quickAccessCurrentPage;

    return Center(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 350),
          curve: Curves.easeOutCubic,
          width: screenWidth * 0.68,
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(isActive ? 0.06 : 0.03),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: Colors.white.withOpacity(isActive ? 0.15 : 0.08),
              width: 1,
            ),
            boxShadow: isActive
                ? [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.35),
                      blurRadius: 30,
                      offset: const Offset(0, 12),
                    ),
                    BoxShadow(
                      color: color.withOpacity(0.1),
                      blurRadius: 40,
                      spreadRadius: 2,
                    ),
                  ]
                : [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ],
          ),
          child: Stack(
            children: [
              Positioned(
                top: -8,
                right: 0,
                child: Text(
                  number,
                  style: TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 64,
                    fontWeight: FontWeight.w900,
                    color: Colors.white.withOpacity(0.06),
                    height: 1,
                    letterSpacing: -2,
                  ),
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.04),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.08),
                        width: 1,
                      ),
                    ),
                    child: Icon(
                      icon,
                      color: Colors.white.withOpacity(0.9),
                      size: 24,
                    ),
                  ),
                  const SizedBox(height: 24),
                  Text(
                    title,
                    style: const TextStyle(
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      letterSpacing: 1.2,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    description,
                    style: TextStyle(
                      fontFamily: 'ShareTechMono',
                      fontSize: 11,
                      color: Colors.white.withOpacity(0.55),
                      height: 1.5,
                    ),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 18),
                  if (tags.isNotEmpty)
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: tags.map((tag) {
                        return Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.04),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.08),
                              width: 0.8,
                            ),
                          ),
                          child: Text(
                            tag,
                            style: TextStyle(
                              fontFamily: 'ShareTechMono',
                              fontSize: 9,
                              fontWeight: FontWeight.w600,
                              color: Colors.white.withOpacity(0.7),
                              letterSpacing: 1,
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  const SizedBox(height: 22),
                  Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 32, vertical: 12),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(28),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.white.withOpacity(0.15),
                            blurRadius: 16,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Text(
                        buttonText,
                        style: const TextStyle(
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF0a0a0a),
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // SIDEBAR (legacy)
  // ═════════════════════════════════════════════════════════════════════════
  Widget _buildSidebar() {
    return Positioned(
      top: 0, bottom: 0, left: 0,
      child: SlideTransition(
        position: Tween<Offset>(begin: Offset(-1.0, 0.0), end: Offset.zero).animate(
          CurvedAnimation(parent: _sidebarController, curve: Curves.easeOutCubic, reverseCurve: Curves.easeInCubic)),
        child: Container(
          width: 260,
          decoration: BoxDecoration(
            color: _C.bg2, border: Border(right: BorderSide(color: _C.border)),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 24, offset: Offset(4, 0))],
          ),
          child: Column(children: [
            Container(
              padding: const EdgeInsets.fromLTRB(16, 48, 16, 16),
              child: Row(children: [
                Text('NAVIGATE', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 11, fontWeight: FontWeight.bold, color: _C.accent, letterSpacing: 2)),
                Spacer(),
                GestureDetector(onTap: _closeSidebar, child: Container(width: 32, height: 32, decoration: BoxDecoration(color: _C.surface, borderRadius: BorderRadius.circular(8)), child: Icon(Icons.close, color: _C.muted, size: 16))),
              ]),
            ),
            Divider(color: _C.border, height: 1),
            Expanded(child: ListView(padding: const EdgeInsets.symmetric(vertical: 8), children: [
              _sidebarItem(FontAwesomeIcons.store,      'Seller Panel', 'seller'),
              _sidebarItem(FontAwesomeIcons.hatWizard,  'Admin',        'admin'),
              _sidebarItem(FontAwesomeIcons.paperPlane, 'Sender Hub',   'sender'),
              _sidebarItem(FontAwesomeIcons.toolbox,    'Tools',        'tools'),
            ])),
            Container(padding: const EdgeInsets.all(16), child: Text('YakuzaXsilence · OmhcSilence', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 9, color: _C.muted2))),
          ]),
        ),
      ),
    );
  }

  Widget _sidebarItem(IconData icon, String label, String page) {
    return Material(color: Colors.transparent, child: InkWell(
      onTap: () => _selectFromDrawer(page),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(children: [
          Icon(icon, color: _C.muted, size: 16),
          SizedBox(width: 14),
          Text(label, style: TextStyle(fontSize: 14, color: _C.text)),
        ]),
      ),
    ));
  }
}
// ═════════════════════════════════════════════════════════════════════════════
// SETTINGS PAGE
// ═════════════════════════════════════════════════════════════════════════════
class _SettingsPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final bool notif, sound, autoConnect, darkMode;
  final ValueChanged<bool> onToggleNotif, onToggleSound, onToggleAutoConnect, onToggleDarkMode;
  final VoidCallback onToggleMusic;
  final bool isMusicPlaying;

  const _SettingsPage({
    required this.username,
    required this.sessionKey,
    required this.notif,
    required this.sound,
    required this.autoConnect,
    required this.darkMode,
    required this.onToggleNotif,
    required this.onToggleSound,
    required this.onToggleAutoConnect,
    required this.onToggleDarkMode,
    required this.onToggleMusic,
    required this.isMusicPlaying,
  });

  @override
  State<_SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<_SettingsPage> {
  late bool _n, _s, _a, _d, _m;

  @override
  void initState() {
    super.initState();
    _n = widget.notif;
    _s = widget.sound;
    _a = widget.autoConnect;
    _d = widget.darkMode;
    _m = widget.isMusicPlaying;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        backgroundColor: _C.bg2,
        elevation: 0,
        title: Text('SETTINGS', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 14, fontWeight: FontWeight.bold, color: _C.text)),
        iconTheme: IconThemeData(color: _C.text),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(height: 1, color: _C.border)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _sl('GENERAL'),
          SizedBox(height: 8),
          _tt('Notifications', _n, (v) { setState(() => _n = v); widget.onToggleNotif(v); }, Icons.notifications),
          _tt('Sound Effects', _s, (v) { setState(() => _s = v); widget.onToggleSound(v); }, Icons.volume_up),
          _tt('Auto Connect', _a, (v) { setState(() => _a = v); widget.onToggleAutoConnect(v); }, Icons.sync),
          _tt('Dark Mode', _d, (v) { setState(() => _d = v); widget.onToggleDarkMode(v); }, Icons.dark_mode),
          SizedBox(height: 16),
          _sl('AUDIO'),
          SizedBox(height: 8),
          _tt('Background Music', _m, (_) { setState(() => _m = !_m); widget.onToggleMusic(); }, Icons.music_note),
          SizedBox(height: 16),
          _sl('ACCOUNT'),
          SizedBox(height: 8),
          _at('Change Password', Icons.lock, () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChangePasswordPage(username: widget.username, sessionKey: widget.sessionKey)))),
          _at('Logout', Icons.logout, () async {
            final prefs = await SharedPreferences.getInstance();
            await prefs.clear();
            if (context.mounted) {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => LoginPage()),
                (r) => false,
              );
            }
          }),
        ]),
      ),
    );
  }

  Widget _sl(String l) => Text(l, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: _C.muted, letterSpacing: 2));

  Widget _tt(String label, bool value, ValueChanged<bool> onChanged, IconData icon) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(color: _C.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.border)),
      child: Row(children: [
        Icon(icon, color: _C.muted, size: 18),
        SizedBox(width: 12),
        Expanded(child: Text(label, style: TextStyle(fontSize: 14, color: _C.text))),
        GestureDetector(
          onTap: () => onChanged(!value),
          child: AnimatedContainer(
            duration: Duration(milliseconds: 200),
            width: 44,
            height: 24,
            decoration: BoxDecoration(
              color: value ? _C.accent : _C.surface,
              borderRadius: BorderRadius.circular(12),
            ),
            child: AnimatedAlign(
              duration: Duration(milliseconds: 200),
              alignment: value ? Alignment.centerRight : Alignment.centerLeft,
              child: Container(
                width: 20, height: 20,
                margin: const EdgeInsets.symmetric(horizontal: 2),
                decoration: BoxDecoration(
                  color: value ? _C.accent : _C.muted2,
                  shape: BoxShape.circle,
                  boxShadow: value
                      ? [BoxShadow(color: _C.accent.withOpacity(0.4), blurRadius: 6)]
                      : [],
                ),
                child: Container(
                  margin: const EdgeInsets.all(3),
                  decoration: BoxDecoration(
                    color: value ? Colors.white : _C.muted2,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _at(String label, IconData icon, VoidCallback onTap) {
    return GestureDetector(onTap: onTap, child: Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(color: _C.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.border)),
      child: Row(children: [
        Icon(icon, color: _C.muted, size: 18),
        SizedBox(width: 12),
        Expanded(child: Text(label, style: TextStyle(fontSize: 14, color: _C.text))),
        Icon(Icons.chevron_right, color: _C.muted, size: 18),
      ]),
    ));
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// BROADCAST DIALOG
// ═══════════════════════════════════════════════════════════════════════════
class _BroadcastDialog extends StatefulWidget {
  final List<dynamic> broadcasts;
  final String sessionKey;
  final VoidCallback onDismiss;

  const _BroadcastDialog({
    required this.broadcasts,
    required this.sessionKey,
    required this.onDismiss,
  });

  @override
  State<_BroadcastDialog> createState() => _BroadcastDialogState();
}

class _BroadcastDialogState extends State<_BroadcastDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _scaleController;
  late AnimationController _glowController;
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(
      duration: Duration(milliseconds: 500),
      vsync: this,
    )..forward();
    _glowController = AnimationController(
      duration: Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _scaleController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  Map<String, dynamic> _getTypeStyle(String type) {
    switch ((type ?? 'info').toLowerCase()) {
      case 'maintenance':
        return {'color': Color(0xFF222222), 'icon': FontAwesomeIcons.screwdriverWrench, 'label': 'MAINTENANCE'};
      case 'update':
        return {'color': Color(0xFFFF3B30), 'icon': FontAwesomeIcons.arrowsRotate, 'label': 'UPDATE'};
      case 'warning':
        return {'color': Color(0xFFFF3B30), 'icon': FontAwesomeIcons.triangleExclamation, 'label': 'WARNING'};
      case 'info':
      default:
        return {'color': Color(0xFFFF3B30), 'icon': FontAwesomeIcons.circleInfo, 'label': 'INFO'};
    }
  }

  Future<void> _dismissCurrent() async {
    final broadcasts = widget.broadcasts;
    if (_currentIndex >= broadcasts.length) {
      widget.onDismiss();
      return;
    }
    final current = broadcasts[_currentIndex] as Map<String, dynamic>;
    final id = current['id'] as String?;

    if (id != null) {
      try {
        await http.post(
          Uri.parse("https://omhc-host-premium.yakuza.biz.id/dismissBroadcast"),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'key': widget.sessionKey, 'broadcastId': id}),
        ).timeout(Duration(seconds: 5));
      } catch (_) {}
    }

    if (_currentIndex + 1 < broadcasts.length) {
      setState(() {
        _currentIndex++;
        _scaleController.reset();
        _scaleController.forward();
      });
    } else {
      widget.onDismiss();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_currentIndex >= widget.broadcasts.length) {
      return const SizedBox.shrink();
    }
    final broadcast = widget.broadcasts[_currentIndex] as Map<String, dynamic>;
    final typeStyle = _getTypeStyle(broadcast['type'] as String? ?? 'info');
    final primary = typeStyle['color'] as Color;
    final typeIcon = typeStyle['icon'];
    final typeLabel = typeStyle['label'] as String;
    final primaryDark = Color.lerp(primary, Colors.black, 0.4)!;

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24),
      child: ScaleTransition(
        scale: Tween<double>(begin: 0.7, end: 1.0).animate(
          CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
        ),
        child: Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.topCenter,
          children: [
            Positioned(
              top: -20,
              child: AnimatedBuilder(
                animation: _glowController,
                builder: (_, __) => Container(
                  width: 80, height: 80,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: primary.withOpacity(0.4 + _glowController.value * 0.3),
                        blurRadius: 30 + _glowController.value * 20,
                        spreadRadius: 4,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.only(top: 40),
              padding: const EdgeInsets.fromLTRB(22, 36, 22, 22),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xFF222222),
                    Color(0xFF111111),
                  ],
                ),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: primary.withOpacity(0.4), width: 1.5),
                boxShadow: [
                  BoxShadow(color: primary.withOpacity(0.2), blurRadius: 40),
                  BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 30),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 72, height: 72,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [primary, primaryDark],
                      ),
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(color: primary.withOpacity(0.5), blurRadius: 20),
                      ],
                    ),
                    child: Icon(typeIcon, color: _C.text, size: 32),
                  ),
                  SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: primary.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: primary.withOpacity(0.3)),
                    ),
                    child: Text(typeLabel,
                        style: TextStyle(
                          color: primary,
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                        )),
                  ),
                  SizedBox(height: 14),
                  Text(
                    broadcast['title'] as String? ?? 'Notification',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xFF000000),
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    ),
                  ),
                  SizedBox(height: 6),
                  Container(width: 40, height: 2, color: primary.withOpacity(0.5)),
                  SizedBox(height: 14),
                  Text(
                    broadcast['message'] as String? ?? '',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0x73E0E7FF),
                      fontFamily: 'ShareTechMono',
                      fontSize: 12,
                      height: 1.6,
                    ),
                  ),
                  SizedBox(height: 18),
                  if (widget.broadcasts.length > 1)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 14),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(
                          widget.broadcasts.length,
                          (i) => Container(
                            width: 6, height: 6,
                            margin: const EdgeInsets.symmetric(horizontal: 3),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: i == _currentIndex
                                  ? primary
                                  : primary.withOpacity(0.2),
                            ),
                          ),
                        ),
                      ),
                    ),
                  SizedBox(
                    width: double.infinity,
                    height: 46,
                    child: ElevatedButton(
                      onPressed: _dismissCurrent,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: primary,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        elevation: 0,
                      ),
                      child: Text(
                        _currentIndex + 1 < widget.broadcasts.length
                            ? 'NEXT (${_currentIndex + 2}/${widget.broadcasts.length})'
                            : 'GOT IT',
                        style: TextStyle(
                          fontFamily: 'MADEEvolveSansEVO',
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}