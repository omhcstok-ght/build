// bug_group.dart — GROUP BUG ATTACK PAGE
//
// Fitur:
//   • Target: WhatsApp group (invite link ATAU pilih dari MY GROUPS)
//   • Bug type: 3D carousel (dynamic dari API /bugGroupSystems)
//   • Join group otomatis (/joinGroup) + kirim bug (/sendBugGroup)
//   • Popup PROCESSING countdown 5 detik (paralel dengan API)
//   • Success popup enhanced
//   • Video background: banner.mp4

import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:ui';
import 'package:video_player/video_player.dart';
import 'package:shimmer/shimmer.dart';

// ── COLOR SCHEME (matching dashboard) ──
class _GC {
  static const bg           = Color(0xFF000000);
  static const bg2          = Color(0xFF0a0a0a);
  static const surface      = Color(0xFF111111);
  static const card         = Color(0xFF111111);
  static const accent       = Color(0xFFFF3B30);
  static const accent2      = Color(0xFFFF6B6B);
  static const accent3      = Color(0xFFCC2E25);
  static const gold         = Color(0xFF333333);
  static const success      = Color(0xFFFF3B30);
  static const whatsapp     = Color(0xFFFF3B30);
  static const whatsappDark = Color(0xFFCC2E25);
  static const text         = Color(0xFFE0E7FF);
  static const muted        = Color(0x73E0E7FF);
  static const muted2       = Color(0x38E0E7FF);
  static const border       = Color(0x1AFF3B30);
  static const border2      = Color(0x0FFFFFFF);
}

// ── GROUP BUG PAGE ──
class GroupBugPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final String role;
  final String expiredDate;

  GroupBugPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<GroupBugPage> createState() => _GroupBugPageState();
}

class _GroupBugPageState extends State<GroupBugPage> with TickerProviderStateMixin {
  // ── Video Background ──
  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;
  static const _bgVideoUrl = 'assets/videos/banner.mp4';

  final linkGroupController = TextEditingController();
  static const String baseUrl = "https://omhc-host-premium.yakuza.biz.id";

  // ── Animation Controllers ──
  late AnimationController _pulseController;
  late AnimationController _staggerController;
  late AnimationController _btnPress;
  late AnimationController _shimmerController;
  late AnimationController _headerShimmerController;

  // ── State ──
  bool _isSending = false;
  int _activeStep = 0;
  bool _isLinkFocused = false;

  // ── Bug type selector (dynamic dari API) ──
  List<Map<String, dynamic>> _bugTypes = [];
  String _selectedBugId = '';
  bool _loadingBugs = true;
  late PageController _bugCarouselController;
  int _bugCarouselIndex = 0;

  // ── My groups ──
  List<Map<String, dynamic>> _myGroups = [];
  bool _loadingGroups = true;
  String? _selectedGroupId;

  // ── Input mode ──
  bool _useMyGroups = false;

  // ── Live role ──
  late String _currentRole;
  late String _currentExpired;

  // ── Refresh role dari server ──
  Future<void> _refreshRoleFromServer() async {
    if (widget.sessionKey.isEmpty) return;
    try {
      final res = await http.get(Uri.parse(
        "$baseUrl/meByKey?key=${Uri.encodeComponent(widget.sessionKey)}",
      )).timeout(Duration(seconds: 8));
      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        final newRole = (data['role'] ?? _currentRole).toString();
        final newExpired = (data['expiredDate'] ?? _currentExpired).toString();
        if (newRole != _currentRole || newExpired != _currentExpired) {
          if (mounted) {
            setState(() {
              _currentRole = newRole;
              _currentExpired = newExpired;
            });
          }
        }
      }
    } catch (_) {}
  }

  @override
  void initState() {
    super.initState();
    _currentRole = widget.role;
    _currentExpired = widget.expiredDate;
    _initBgVideo();

    _pulseController = AnimationController(vsync: this, duration: Duration(seconds: 3))..repeat(reverse: true);
    _staggerController = AnimationController(vsync: this, duration: Duration(milliseconds: 900))..forward();
    _btnPress = AnimationController(vsync: this, duration: Duration(milliseconds: 100), lowerBound: 0.0, upperBound: 1.0);
    _shimmerController = AnimationController(vsync: this, duration: Duration(seconds: 4))..repeat(reverse: true);
    _headerShimmerController = AnimationController(vsync: this, duration: Duration(seconds: 3))..repeat();

    _bugCarouselController = PageController(
      initialPage: 0,
      viewportFraction: 0.42,
    );

    _refreshRoleFromServer();
    _fetchBugSystems();
    _fetchMyGroups();
  }

  // ── Video Background ──
  void _initBgVideo() {
    _bgVideoController = VideoPlayerController.asset(_bgVideoUrl)
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bgVideoReady = true);
          _bgVideoController.play();
          _bgVideoController.setLooping(true);
          _bgVideoController.setVolume(0.0);
        }
      }).catchError((e) {
        debugPrint('BG video error: $e');
      });
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _staggerController.dispose();
    _btnPress.dispose();
    _shimmerController.dispose();
    _headerShimmerController.dispose();
    _bugCarouselController.dispose();
    linkGroupController.dispose();
    _bgVideoController.dispose();
    super.dispose();
  }

  // ── Stagger Animation Helper ──
  Animation<double> _anim(int i) {
    final s = (i * 0.07).clamp(0.0, 0.55);
    final e = (s + 0.38).clamp(0.0, 1.0);
    return CurvedAnimation(
      parent: _staggerController,
      curve: Interval(s, e, curve: Curves.easeOut),
    );
  }

  // ── Validation ──
  bool _isValidGroupLink(String input) {
    final regex = RegExp(r'https://chat\.whatsapp\.com/[a-zA-Z0-9]{22}');
    return regex.hasMatch(input);
  }

  // ═══════════════════════════════════════════════════════════════════════
  // FETCH BUG SYSTEMS dari /bugGroupSystems
  // ═══════════════════════════════════════════════════════════════════════
  Future<void> _fetchBugSystems() async {
    if (widget.sessionKey.isEmpty) {
      if (mounted) setState(() => _loadingBugs = false);
      return;
    }
    try {
      final res = await http.get(Uri.parse(
        "$baseUrl/bugGroupSystems?key=${Uri.encodeComponent(widget.sessionKey)}",
      )).timeout(Duration(seconds: 10));
      if (res.statusCode != 200) {
        if (mounted) setState(() => _loadingBugs = false);
        return;
      }
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['bugSystems'] is List) {
        final list = (data['bugSystems'] as List)
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList();
        if (mounted) {
          setState(() {
            _bugTypes = list;
            if (_selectedBugId.isEmpty && list.isNotEmpty) {
              _selectedBugId = list.first['id']?.toString() ?? '';
            }
            _loadingBugs = false;
          });
        }
      } else {
        if (mounted) setState(() => _loadingBugs = false);
      }
    } catch (_) {
      if (mounted) setState(() => _loadingBugs = false);
    }
  }

  // ═══════════════════════════════════════════════════════════════════════
  // FETCH MY GROUPS dari /myGroup
  // ═══════════════════════════════════════════════════════════════════════
  Future<void> _fetchMyGroups() async {
    if (widget.sessionKey.isEmpty) {
      if (mounted) setState(() => _loadingGroups = false);
      return;
    }
    try {
      final res = await http.get(Uri.parse(
        "$baseUrl/myGroup?key=${Uri.encodeComponent(widget.sessionKey)}",
      )).timeout(Duration(seconds: 10));
      if (res.statusCode != 200) {
        if (mounted) setState(() => _loadingGroups = false);
        return;
      }
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['groups'] is List) {
        final list = (data['groups'] as List)
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList();
        if (mounted) {
          setState(() {
            _myGroups = list;
            _loadingGroups = false;
          });
        }
      } else {
        if (mounted) setState(() => _loadingGroups = false);
      }
    } catch (_) {
      if (mounted) setState(() => _loadingGroups = false);
    }
  }

  // ── Join group via invite link (background) ──
  Future<void> _joinGroup(String inviteLink) async {
    try {
      await http.post(
        Uri.parse("$baseUrl/joinGroup"),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'groupInput': inviteLink,
        }),
      ).timeout(Duration(seconds: 30));
    } catch (_) {}
  }

  // ═══════════════════════════════════════════════════════════════════════
  // API: send bug group (dipanggil background, sebelum popup)
  // ═══════════════════════════════════════════════════════════════════════
  Future<Map<String, dynamic>> _sendGroupBugApiCall(String group) async {
    try {
      final res = await http.get(Uri.parse(
        "$baseUrl/sendBugGroup?key=${Uri.encodeComponent(widget.sessionKey)}"
        "&group=${Uri.encodeComponent(group)}"
        "&bugType=${Uri.encodeComponent(_selectedBugId)}"
      )).timeout(Duration(seconds: 60));
      final data = jsonDecode(res.body);
      return {'success': true, 'data': data};
    } catch (e) {
      return {'success': false, 'error': e.toString()};
    }
  }

  // ═══════════════════════════════════════════════════════════════════════
  // LAUNCH GROUP STRIKE — Paralel: API background + popup countdown
  // ═══════════════════════════════════════════════════════════════════════
  Future<void> _sendGroupBug() async {
    if (_isSending) return;
    _btnPress.forward().then((_) => _btnPress.reverse());

    final key = widget.sessionKey;

    // ── Tentuin target group ──
    String linkGroup;
    if (_useMyGroups) {
      if (_selectedGroupId == null || _selectedGroupId!.isEmpty) {
        _showAlert("No Group", "Pick a group dari list MY GROUPS dulu.");
        return;
      }
      linkGroup = _selectedGroupId!;
    } else {
      linkGroup = linkGroupController.text.trim();
      if (linkGroup.isEmpty) {
        _showAlert("Empty Target", "Paste WhatsApp group invite link atau pilih dari MY GROUPS.");
        return;
      }
      if (!_isValidGroupLink(linkGroup)) {
        _showAlert("Invalid Link", "Please enter a valid WhatsApp group invite link.\nFormat: https://chat.whatsapp.com/xxxxxxxxxx");
        return;
      }
    }

    // Bug wajib dipilih
    if (_selectedBugId.isEmpty) {
      _showAlert("No Bug Type", "Pilih jenis bug dulu sebelum launch.");
      return;
    }

    setState(() {
      _isSending = true;
      _activeStep = 1;
    });

    // ══════════════════════════════════════════════════════════════════
    // STEP 1: Fire API call SEGERA (background)
    // Kalau pakai invite link → join group dulu, baru kirim bug.
    // Kalau pakai My Groups → langsung kirim bug (udah join).
    // ══════════════════════════════════════════════════════════════════
    final apiFuture = () async {
      if (!_useMyGroups) {
        await _joinGroup(linkGroup);
      }
      return _sendGroupBugApiCall(linkGroup);
    }();

    // ══════════════════════════════════════════════════════════════════
    // STEP 2: Show popup PROCESSING (countdown + fake log)
    // ══════════════════════════════════════════════════════════════════
    if (mounted) {
      _showProcessingDialog(
        target: linkGroup,
        bugName: _selectedBugId,
        apiFuture: apiFuture,
      );
    }
  }

  // ═══════════════════════════════════════════════════════════════════════
  // Show PROCESSING Dialog
  // ═══════════════════════════════════════════════════════════════════════
  void _showProcessingDialog({
    required String target,
    required String bugName,
    required Future<Map<String, dynamic>> apiFuture,
  }) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _ProcessingDialog(
        target: target,
        bugName: bugName,
        apiFuture: apiFuture,
        onComplete: (result) {
          if (mounted) {
            setState(() {
              _isSending = false;
              _activeStep = result['success'] == true ? 2 : 0;
            });
          }

          Future.delayed(Duration(milliseconds: 250), () {
            if (!mounted) return;
            if (result['success'] == true) {
              _handleApiResponse(result['data'], target);
            } else {
              _showAlert("Error", "Connection error. Please try again.");
            }
          });
        },
      ),
    );
  }

  // ── Process response dari API ──
  void _handleApiResponse(Map<String, dynamic> data, String linkGroup) {
    if (data["cooldown"] == true) {
      _showAlert("Cooldown", "Cooldown group bug ${data["wait"] ?? ""} detik. Tunggu sebentar.");
    } else if (data["valid"] == false) {
      _showAlert("Failed", data["message"] ?? "Failed to send group bug.");
    } else if (data["sended"] == false) {
      _showAlert("Gagal", data["message"] ?? "Gagal mengirim bug ke grup.");
    } else {
      _showSuccessPopup(linkGroup, data);
    }
  }

  // ── Paste ──
  Future<void> _pasteLink() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    if (data?.text != null) {
      linkGroupController.text = data!.text!;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════
  // Alert (bottom sheet)
  // ═══════════════════════════════════════════════════════════════════════
  void _showAlert(String title, String msg) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom + 16),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 20),
          decoration: BoxDecoration(
            color: _GC.card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _GC.border, width: 1),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 24, offset: Offset(0, 12)),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 40, height: 3,
                  decoration: BoxDecoration(
                    color: _GC.accent,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                SizedBox(height: 18),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 42, height: 42,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: _GC.accent.withOpacity(0.12),
                        border: Border.all(color: _GC.accent.withOpacity(0.2)),
                      ),
                      child: Center(child: Icon(FontAwesomeIcons.triangleExclamation, color: _GC.accent, size: 17)),
                    ),
                    SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 2),
                          Text(title, style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 15, fontWeight: FontWeight.w700, color: _GC.text)),
                          SizedBox(height: 4),
                          Container(width: 28, height: 2, decoration: BoxDecoration(color: _GC.accent.withOpacity(0.3), borderRadius: BorderRadius.circular(1))),
                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 16),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: _GC.surface,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(msg, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: _GC.muted, height: 1.6)),
                ),
                SizedBox(height: 20),
                Align(
                  alignment: Alignment.centerRight,
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
                      decoration: BoxDecoration(
                        color: _GC.accent,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [BoxShadow(color: _GC.accent.withOpacity(0.2), blurRadius: 12)],
                      ),
                      child: Text('OK', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 11, fontWeight: FontWeight.w700, color: _GC.text, letterSpacing: 2)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── Success popup ──
  void _showSuccessPopup(String linkGroup, Map<String, dynamic> data) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _GroupSuccessDialog(
        linkGroup: linkGroup,
        bugType: _selectedBugId,
        data: data,
        onDismiss: () {
          Navigator.of(context).pop();
          setState(() => _activeStep = 0);
        },
      ),
    );
  }
  
  
  // ═══════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    // Role-based access
    if (!["vip", "owner", "high admin", "reseller", "founder", "seles"].contains(_currentRole.toLowerCase())) {
      return Stack(
        children: [
          if (_bgVideoReady && _bgVideoController.value.isInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bgVideoController.value.size.width,
                  height: _bgVideoController.value.size.height,
                  child: VideoPlayer(_bgVideoController),
                ),
              ),
            )
          else
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF000000), Color(0xFF0a0a0a), Color(0xFF111111)],
                ),
              ),
            ),
          Container(color: Colors.black.withOpacity(0.65)),
          Scaffold(
            backgroundColor: Colors.transparent,
            body: Center(child: _buildAccessDenied()),
          ),
        ],
      );
    }

    return Scaffold(
      backgroundColor: _GC.bg,
      body: Stack(
        children: [
          // ── VIDEO BACKGROUND banner.mp4 ──
          if (_bgVideoReady && _bgVideoController.value.isInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bgVideoController.value.size.width,
                  height: _bgVideoController.value.size.height,
                  child: VideoPlayer(_bgVideoController),
                ),
              ),
            )
          else
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [_GC.bg, _GC.bg2, _GC.bg],
                ),
              ),
            ),

          Container(color: Colors.black.withOpacity(0.65)),

          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                Expanded(
                  child: SingleChildScrollView(
                    physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(maxWidth: 520),
                      child: Column(
                        children: [
                          SizedBox(height: 16),
                          _buildGroupHero(),
                          SizedBox(height: 16),
                          _buildProfileCard(),
                          SizedBox(height: 16),
                          _buildGroupLinkCard(),
                          SizedBox(height: 16),
                          _buildBugSelector(),
                          SizedBox(height: 16),
                          _buildFeatureStrip(),
                          SizedBox(height: 24),
                          _buildLaunchButton(),
                          SizedBox(height: 16),
                          _buildStatusBar(),
                          SizedBox(height: 32),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // ACCESS DENIED
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildAccessDenied() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        AnimatedBuilder(
          animation: _pulseController,
          builder: (ctx, _) {
            final p = _pulseController.value;
            return Container(
              width: 80, height: 80,
              decoration: BoxDecoration(
                color: _GC.accent.withOpacity(0.08 + p * 0.05),
                shape: BoxShape.circle,
                border: Border.all(color: _GC.accent.withOpacity(0.25 + p * 0.1), width: 2),
                boxShadow: [
                  BoxShadow(color: _GC.accent.withOpacity(0.15 + p * 0.1), blurRadius: 24),
                ],
              ),
              child: Icon(FontAwesomeIcons.lock, color: _GC.accent, size: 32),
            );
          },
        ),
        SizedBox(height: 24),
        Text('ACCESS DENIED',
            style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 20, fontWeight: FontWeight.w700, color: _GC.text, letterSpacing: 3)),
        SizedBox(height: 10),
        Container(width: 36, height: 2, decoration: BoxDecoration(color: _GC.accent.withOpacity(0.3), borderRadius: BorderRadius.circular(1))),
        SizedBox(height: 14),
        Text('This feature is only available for\nVIP and authorized roles.',
            style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: _GC.muted, height: 1.6),
            textAlign: TextAlign.center),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // HEADER — glass + shimmer title
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildHeader() {
    return Container(
      height: 62,
      decoration: BoxDecoration(
        color: Color(0xEB0c0d15),
        border: Border(bottom: BorderSide(color: _GC.border)),
      ),
      child: ClipRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    width: 38, height: 38,
                    decoration: BoxDecoration(
                      color: _GC.surface,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _GC.border2),
                    ),
                    child: Icon(Icons.arrow_back, color: _GC.text, size: 16),
                  ),
                ),
                SizedBox(width: 10),
                Container(
                  width: 36, height: 36,
                  decoration: BoxDecoration(
                    color: _GC.whatsapp.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _GC.whatsapp.withOpacity(0.25)),
                  ),
                  child: Center(child: Icon(FontAwesomeIcons.whatsapp, color: _GC.whatsapp, size: 14)),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AnimatedBuilder(
                        animation: _headerShimmerController,
                        builder: (context, child) {
                          final t = _headerShimmerController.value;
                          return ShaderMask(
                            shaderCallback: (bounds) => LinearGradient(
                              begin: Alignment(-1.0 + (t * 2), 0),
                              end: Alignment(0.0 + (t * 2), 0),
                              colors: [_GC.text, _GC.accent2, _GC.text],
                              stops: const [0.0, 0.5, 1.0],
                            ).createShader(bounds),
                            blendMode: BlendMode.srcIn,
                            child: const Text(
                              "GROUP BUG",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                fontFamily: "MADEEvolveSansEVO",
                                letterSpacing: 1.5,
                              ),
                            ),
                          );
                        },
                      ),
                      SizedBox(height: 1),
                      Row(
                        children: [
                          Container(
                            width: 6, height: 6,
                            decoration: BoxDecoration(
                              color: _GC.whatsapp,
                              shape: BoxShape.circle,
                              boxShadow: [BoxShadow(color: _GC.whatsapp, blurRadius: 4)],
                            ),
                          ),
                          SizedBox(width: 5),
                          Text(
                            _isSending ? "INJECTING..." : "READY",
                            style: TextStyle(color: _GC.muted, fontSize: 10, fontFamily: "ShareTechMono"),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                // LIVE badge
                AnimatedBuilder(
                  animation: _headerShimmerController,
                  builder: (context, _) {
                    final p = 0.5 + (math.sin(_headerShimmerController.value * 2 * math.pi) * 0.5).abs();
                    return Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: _GC.whatsapp.withOpacity(0.1 + p * 0.05),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: _GC.whatsapp.withOpacity(0.2 + p * 0.1)),
                        boxShadow: [
                          BoxShadow(color: _GC.whatsapp.withOpacity(0.1 + p * 0.1), blurRadius: 8 + p * 4),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 6, height: 6,
                            decoration: BoxDecoration(
                              color: _GC.whatsapp,
                              shape: BoxShape.circle,
                              boxShadow: [BoxShadow(color: _GC.whatsapp, blurRadius: 4)],
                            ),
                          ),
                          SizedBox(width: 6),
                          Text('LIVE',
                              style: TextStyle(
                                color: _GC.whatsapp,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'ShareTechMono',
                                letterSpacing: 1,
                              )),
                        ],
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // SOLID CARD HELPER
  // ═══════════════════════════════════════════════════════════════════
  Widget _solidCard({required Widget child, int idx = -1}) {
    Widget cardChild = Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.4),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _GC.accent.withOpacity(0.15), width: 1),
      ),
      child: child,
    );

    if (idx >= 0) {
      final a = _anim(idx);
      return FadeTransition(
        opacity: a,
        child: SlideTransition(
          position: Tween(begin: Offset(0, 0.05), end: Offset.zero).animate(a),
          child: cardChild,
        ),
      );
    }
    return cardChild;
  }

  // ═══════════════════════════════════════════════════════════════════
  // GROUP HERO BANNER — Step tracker
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildGroupHero() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 22),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.4),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _GC.accent.withOpacity(0.15), width: 1),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AnimatedBuilder(
                animation: _pulseController,
                builder: (ctx, _) {
                  final v = _pulseController.value;
                  return Container(
                    width: 40, height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _GC.whatsapp.withOpacity(0.12 + v * 0.04),
                      border: Border.all(color: _GC.whatsapp.withOpacity(0.3), width: 1.5),
                      boxShadow: [
                        BoxShadow(color: _GC.whatsapp.withOpacity(0.15 + v * 0.1), blurRadius: 12 + v * 6),
                      ],
                    ),
                    child: Center(child: Icon(FontAwesomeIcons.users, color: _GC.whatsapp, size: 16)),
                  );
                },
              ),
              SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('GROUP INFILTRATION',
                      style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 2.5, color: _GC.text)),
                  SizedBox(height: 4),
                  Container(width: 36, height: 2, decoration: BoxDecoration(color: _GC.whatsapp.withOpacity(0.4), borderRadius: BorderRadius.circular(1))),
                ],
              ),
            ],
          ),
          SizedBox(height: 22),
          Row(
            children: [
              _buildHeroStep(0, FontAwesomeIcons.link, 'LINK', 'Paste group invite'),
              _buildHeroStepConnector(0),
              _buildHeroStep(1, FontAwesomeIcons.droplet, 'INJECT', 'Deploy bug into group'),
              _buildHeroStepConnector(1),
              _buildHeroStep(2, FontAwesomeIcons.circleCheck, 'DONE', 'Group compromised'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHeroStep(int step, IconData icon, String title, String desc) {
    final isActive = _activeStep == step;
    final isDone = _activeStep > step;
    final color = isDone ? _GC.success : isActive ? _GC.accent : _GC.muted2;

    return Expanded(
      child: Column(
        children: [
          AnimatedBuilder(
            animation: _pulseController,
            builder: (ctx, _) {
              final p = _pulseController.value;
              return Container(
                width: 48, height: 48,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withOpacity(isActive ? 0.12 + p * 0.06 : 0.06),
                  border: Border.all(color: color.withOpacity(isActive ? 0.4 + p * 0.15 : 0.15), width: isActive ? 2.0 : 1.0),
                  boxShadow: isActive
                      ? [BoxShadow(color: color.withOpacity(0.1 + p * 0.08), blurRadius: 12)]
                      : null,
                ),
                child: Center(
                  child: isDone ? Icon(Icons.check, color: _GC.success, size: 22) : Icon(icon, color: color, size: 18),
                ),
              );
            },
          ),
          SizedBox(height: 10),
          Text(title, style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.5, color: color)),
          SizedBox(height: 4),
          Text(desc, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 8, color: _GC.muted2), textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }

  Widget _buildHeroStepConnector(int step) {
    final isDone = _activeStep > step;
    return Padding(
      padding: const EdgeInsets.only(top: 22),
      child: AnimatedContainer(
        duration: Duration(milliseconds: 400),
        curve: Curves.easeOutCubic,
        width: 28, height: 2.5,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(2),
          color: isDone ? _GC.success.withOpacity(0.4) : _GC.border2,
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // PROFILE CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildProfileCard() {
    return _solidCard(
      idx: 0,
      child: Row(
        children: [
          Container(
            width: 54, height: 54,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              color: _GC.whatsapp.withOpacity(0.1),
              border: Border.all(color: _GC.whatsapp.withOpacity(0.25)),
            ),
            child: Center(
              child: Icon(
                _currentRole.toLowerCase() == "vip" ? FontAwesomeIcons.hatWizard : FontAwesomeIcons.mask,
                color: _GC.whatsapp, size: 22,
              ),
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Operator', style: TextStyle(fontSize: 10, color: _GC.muted, letterSpacing: 1.8)),
                SizedBox(height: 3),
                Text(widget.username, style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 16, fontWeight: FontWeight.w700, letterSpacing: 1, color: _GC.text), maxLines: 1, overflow: TextOverflow.ellipsis),
                SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: _GC.whatsapp.withOpacity(0.1),
                    border: Border.all(color: _GC.whatsapp.withOpacity(0.2)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(FontAwesomeIcons.circleCheck, color: _GC.whatsapp, size: 9),
                      SizedBox(width: 6),
                      Text(_currentRole.toUpperCase(), style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 2, color: _GC.whatsapp)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: _GC.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _GC.border2),
            ),
            child: Column(
              children: [
                Icon(FontAwesomeIcons.calendarDays, color: _GC.gold, size: 14),
                SizedBox(height: 4),
                Text(_currentExpired, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, color: _GC.gold)),
                SizedBox(height: 2),
                Text('EXPIRY', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 8, color: _GC.muted2, letterSpacing: 1.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // GROUP LINK CARD — Toggle INVITE LINK / MY GROUPS
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildGroupLinkCard() {
    return _solidCard(
      idx: 1,
      child: Column(
        children: [
          _buildSectionHeader(FontAwesomeIcons.link, 'GROUP TARGET'),
          SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _buildToggleTab(
                  'INVITE LINK',
                  FontAwesomeIcons.link,
                  !_useMyGroups,
                  () => setState(() {
                    _useMyGroups = false;
                    _selectedGroupId = null;
                  }),
                ),
              ),
              SizedBox(width: 8),
              Expanded(
                child: _buildToggleTab(
                  'MY GROUPS',
                  FontAwesomeIcons.users,
                  _useMyGroups,
                  () => setState(() => _useMyGroups = true),
                ),
              ),
            ],
          ),
          SizedBox(height: 14),
          if (_useMyGroups)
            _buildMyGroupsList()
          else
            _buildInviteLinkInput(),
        ],
      ),
    );
  }

  Widget _buildToggleTab(String label, IconData icon, bool active, VoidCallback onTap) {
    return GestureDetector(
      onTap: _isSending ? null : onTap,
      child: AnimatedContainer(
        duration: Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: active ? _GC.whatsapp.withOpacity(0.12) : _GC.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: active ? _GC.whatsapp : _GC.border2,
            width: active ? 1.5 : 1,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: active ? _GC.whatsapp : _GC.muted2, size: 11),
            SizedBox(width: 7),
            Text(
              label,
              style: TextStyle(
                fontFamily: 'MADEEvolveSansEVO',
                fontSize: 10,
                fontWeight: FontWeight.w700,
                letterSpacing: 1,
                color: active ? _GC.whatsapp : _GC.muted,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInviteLinkInput() {
    return Column(
      children: [
        AnimatedContainer(
          duration: Duration(milliseconds: 250),
          curve: Curves.easeOutCubic,
          decoration: BoxDecoration(
            color: _GC.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: _isLinkFocused ? _GC.whatsapp : _GC.border,
              width: _isLinkFocused ? 1.5 : 1.0,
            ),
            boxShadow: _isLinkFocused
                ? [BoxShadow(color: _GC.whatsapp.withOpacity(0.15), blurRadius: 12)]
                : null,
          ),
          child: Focus(
            onFocusChange: (f) => setState(() => _isLinkFocused = f),
            child: Row(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 0, 16),
                  child: Container(
                    width: 40, height: 40,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: _GC.whatsapp.withOpacity(_isLinkFocused ? 0.12 : 0.06),
                      border: Border.all(color: _GC.whatsapp.withOpacity(0.15)),
                    ),
                    child: Center(child: Icon(FontAwesomeIcons.whatsapp, color: _GC.whatsapp, size: 17)),
                  ),
                ),
                Expanded(
                  child: TextField(
                    controller: linkGroupController,
                    keyboardType: TextInputType.url,
                    style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 14, color: _GC.text, letterSpacing: 0.3),
                    cursorColor: _GC.whatsapp,
                    cursorWidth: 2,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: 'https://chat.whatsapp.com/...',
                      hintStyle: TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: _GC.muted2),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                    ),
                    onSubmitted: (_) => _sendGroupBug(),
                  ),
                ),
                GestureDetector(
                  onTap: _pasteLink,
                  child: Container(
                    margin: const EdgeInsets.all(12),
                    width: 38, height: 38,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: _GC.surface,
                      border: Border.all(color: _GC.border2),
                    ),
                    child: Center(child: Icon(FontAwesomeIcons.paste, color: _GC.muted2, size: 14)),
                  ),
                ),
              ],
            ),
          ),
        ),
        SizedBox(height: 10),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(children: [
                Icon(FontAwesomeIcons.circleInfo, color: _GC.muted2, size: 10),
                SizedBox(width: 6),
                Text('WhatsApp group invite link', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: _GC.muted2)),
              ]),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _GC.surface,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _GC.border),
                ),
                child: Text('chat.whatsapp.com', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _GC.whatsapp)),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildMyGroupsList() {
    if (_loadingGroups) {
      return _buildGroupsShimmer();
    }
    if (_myGroups.isEmpty) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 16),
        decoration: BoxDecoration(
          color: _GC.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _GC.border2),
        ),
        child: Column(
          children: [
            Icon(FontAwesomeIcons.usersSlash, color: _GC.muted2, size: 22),
            SizedBox(height: 10),
            Text('No groups yet', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.w700, color: _GC.text, letterSpacing: 1)),
            SizedBox(height: 4),
            Text('Bot belum join grup apapun.\nSwitch ke INVITE LINK & paste link baru.', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _GC.muted2, height: 1.5), textAlign: TextAlign.center),
          ],
        ),
      );
    }

    return Column(
      children: [
        for (int i = 0; i < _myGroups.length; i++) ...[
          _buildGroupRow(_myGroups[i]),
          if (i < _myGroups.length - 1) SizedBox(height: 8),
        ],
      ],
    );
  }

  Widget _buildGroupRow(Map<String, dynamic> g) {
    final id = (g['id'] ?? '').toString();
    final name = (g['name'] ?? 'Unknown Group').toString();
    final memberCount = g['memberCount']?.toString() ?? '0';
    final joined = g['joined'] == true;
    final selected = _selectedGroupId == id;

    return GestureDetector(
      onTap: _isSending ? null : () => setState(() => _selectedGroupId = id),
      child: AnimatedContainer(
        duration: Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(
          color: selected ? _GC.whatsapp.withOpacity(0.12) : _GC.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? _GC.whatsapp : _GC.border2,
            width: selected ? 1.5 : 1,
          ),
          boxShadow: selected
              ? [BoxShadow(color: _GC.whatsapp.withOpacity(0.15), blurRadius: 10)]
              : null,
        ),
        child: Row(
          children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: selected ? _GC.whatsapp : _GC.whatsapp.withOpacity(0.12),
                border: Border.all(color: _GC.whatsapp.withOpacity(0.3)),
              ),
              child: Center(
                child: Text(
                  name.isNotEmpty ? name[0].toUpperCase() : '?',
                  style: TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: selected ? _GC.text : _GC.whatsapp,
                  ),
                ),
              ),
            ),
            SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: selected ? _GC.whatsapp : _GC.text,
                    ),
                  ),
                  SizedBox(height: 2),
                  Row(
                    children: [
                      Icon(FontAwesomeIcons.users, size: 9, color: _GC.muted2),
                      SizedBox(width: 4),
                      Text('$memberCount members', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: _GC.muted2)),
                      SizedBox(width: 8),
                      Container(
                        width: 4, height: 4,
                        decoration: BoxDecoration(shape: BoxShape.circle, color: joined ? _GC.whatsapp : _GC.muted2),
                      ),
                      SizedBox(width: 4),
                      Text(joined ? 'joined' : 'pending', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: joined ? _GC.whatsapp : _GC.muted2)),
                    ],
                  ),
                ],
              ),
            ),
            if (selected)
              Container(
                width: 22, height: 22,
                decoration: BoxDecoration(shape: BoxShape.circle, color: _GC.whatsapp),
                child: Center(child: Icon(Icons.check, color: _GC.text, size: 14)),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildGroupsShimmer() {
    return Shimmer.fromColors(
      baseColor: _GC.surface,
      highlightColor: _GC.border,
      child: Column(
        children: List.generate(3, (_) => Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          decoration: BoxDecoration(
            color: _GC.surface,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Container(width: 36, height: 36, decoration: BoxDecoration(shape: BoxShape.circle, color: _GC.surface)),
              SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(height: 10, width: 120, decoration: BoxDecoration(color: _GC.surface, borderRadius: BorderRadius.circular(4))),
                    SizedBox(height: 6),
                    Container(height: 8, width: 80, decoration: BoxDecoration(color: _GC.surface, borderRadius: BorderRadius.circular(4))),
                  ],
                ),
              ),
            ],
          ),
        )),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // BUG SELECTOR — 3D Carousel
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildBugSelector() {
    final screenWidth = MediaQuery.of(context).size.width;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 20),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.4),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _GC.accent.withOpacity(0.15), width: 1),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Container(
                  width: 42, height: 42,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(13),
                    color: _GC.whatsapp.withOpacity(0.1),
                    border: Border.all(color: _GC.whatsapp.withOpacity(0.18)),
                  ),
                  child: Center(child: Icon(FontAwesomeIcons.bug, color: _GC.whatsapp, size: 17)),
                ),
                SizedBox(width: 14),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('BUG TYPE',
                        style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 3, color: _GC.text)),
                    SizedBox(height: 4),
                    Container(width: 30, height: 2, decoration: BoxDecoration(color: _GC.whatsapp.withOpacity(0.4), borderRadius: BorderRadius.circular(1))),
                  ],
                ),
                Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: _GC.whatsapp.withOpacity(0.1),
                    border: Border.all(color: _GC.whatsapp.withOpacity(0.2)),
                  ),
                  child: Text(
                    _selectedBugId.isEmpty ? '--' : _selectedBugId.toUpperCase(),
                    style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, color: _GC.whatsapp, letterSpacing: 1),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 16),
          if (_loadingBugs)
            _buildBugShimmer()
          else if (_bugTypes.isEmpty)
            _buildBugEmpty()
          else
            SizedBox(
              height: 160,
              child: PageView.builder(
                controller: _bugCarouselController,
                physics: const BouncingScrollPhysics(),
                onPageChanged: (i) {
                  setState(() {
                    _bugCarouselIndex = i;
                    _selectedBugId = (_bugTypes[i]['id'] ?? '').toString();
                  });
                },
                itemCount: _bugTypes.length,
                itemBuilder: (context, index) {
                  return AnimatedBuilder(
                    animation: _bugCarouselController,
                    builder: (context, child) {
                      double pageOffset = 0.0;
                      if (_bugCarouselController.position.haveDimensions) {
                        pageOffset = (_bugCarouselController.page ?? 0) - index;
                      } else {
                        pageOffset = (_bugCarouselIndex - index).toDouble();
                      }

                      final scale = (1 - (pageOffset.abs() * 0.15)).clamp(0.75, 1.0);
                      final rotationY = pageOffset * 0.4;
                      final translateY = pageOffset.abs() * 12.0;
                      final opacity = (1 - (pageOffset.abs() * 0.35)).clamp(0.4, 1.0);

                      return Transform(
                        alignment: Alignment.center,
                        transform: Matrix4.identity()
                          ..setEntry(3, 2, 0.0015)
                          ..rotateY(rotationY)
                          ..translate(0.0, translateY)
                          ..scale(scale),
                        child: Opacity(
                          opacity: opacity,
                          child: _buildBugCard(_bugTypes[index], index, screenWidth),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          SizedBox(height: 14),
          // Dots indicator
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              _bugTypes.isEmpty ? 1 : _bugTypes.length,
              (i) {
                final active = i == _bugCarouselIndex;
                return AnimatedContainer(
                  duration: Duration(milliseconds: 300),
                  curve: Curves.easeOutCubic,
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  height: 4,
                  width: active ? 24 : 7,
                  decoration: BoxDecoration(
                    color: active ? _GC.whatsapp : _GC.border2,
                    borderRadius: BorderRadius.circular(4),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBugCard(Map<String, dynamic> bug, int index, double screenWidth) {
    final selected = index == _bugCarouselIndex;
    final bugId = (bug['id'] ?? '').toString();
    final bugName = (bug['name'] ?? bugId).toString();
    final bugDesc = (bug['description'] ?? '').toString();

    return Center(
      child: GestureDetector(
        onTap: () {
          setState(() {
            _selectedBugId = bugId;
            _bugCarouselIndex = index;
            _bugCarouselController.animateToPage(
              index,
              duration: const Duration(milliseconds: 450),
              curve: Curves.easeOutCubic,
            );
          });
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 350),
          curve: Curves.easeOutCubic,
          width: screenWidth * 0.55,
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(selected ? 0.06 : 0.03),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: Colors.white.withOpacity(selected ? 0.15 : 0.08),
              width: 1,
            ),
            boxShadow: selected
                ? [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.35),
                      blurRadius: 30,
                      offset: const Offset(0, 12),
                    ),
                    BoxShadow(
                      color: _GC.whatsapp.withOpacity(0.1),
                      blurRadius: 40,
                      spreadRadius: 2,
                    ),
                  ]
                : [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ],
          ),
          child: Stack(
            children: [
              Positioned(
                top: -8,
                right: 0,
                child: Text(
                  '${(index + 1).toString().padLeft(2, '0')}',
                  style: TextStyle(
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 64,
                    fontWeight: FontWeight.w900,
                    color: Colors.white.withOpacity(0.06),
                    height: 1,
                    letterSpacing: -2,
                  ),
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.04),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.08),
                        width: 1,
                      ),
                    ),
                    child: Icon(
                      selected ? FontAwesomeIcons.fire : FontAwesomeIcons.bug,
                      color: Colors.white.withOpacity(0.9),
                      size: 20,
                    ),
                  ),
                  const SizedBox(height: 18),
                  Text(
                    bugName,
                    style: const TextStyle(
                      fontFamily: 'MADEEvolveSansEVO',
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      letterSpacing: 1,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 5),
                  Text(
                    bugDesc,
                    style: TextStyle(
                      fontFamily: 'ShareTechMono',
                      fontSize: 9,
                      color: Colors.white.withOpacity(0.55),
                      height: 1.4,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: selected
                          ? _GC.whatsapp.withOpacity(0.15)
                          : Colors.white.withOpacity(0.04),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: selected
                            ? _GC.whatsapp.withOpacity(0.4)
                            : Colors.white.withOpacity(0.08),
                        width: 0.8,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 5,
                          height: 5,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: selected ? _GC.whatsapp : _GC.muted2,
                          ),
                        ),
                        SizedBox(width: 5),
                        Text(
                          selected ? 'SELECTED' : 'READY',
                          style: TextStyle(
                            fontFamily: 'ShareTechMono',
                            fontSize: 8,
                            fontWeight: FontWeight.w700,
                            color: selected ? _GC.whatsapp : _GC.muted2,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBugShimmer() {
    return Shimmer.fromColors(
      baseColor: _GC.surface,
      highlightColor: _GC.border,
      child: SizedBox(
        height: 160,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 20),
          itemCount: 3,
          itemBuilder: (_, __) => Container(
            width: 150,
            margin: const EdgeInsets.only(right: 12),
            decoration: BoxDecoration(
              color: _GC.surface,
              borderRadius: BorderRadius.circular(20),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBugEmpty() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 16),
      decoration: BoxDecoration(
        color: _GC.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _GC.border2),
      ),
      child: Column(
        children: [
          Icon(FontAwesomeIcons.bugSlash, color: _GC.muted2, size: 22),
          SizedBox(height: 10),
          Text('No bug systems available', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 11, fontWeight: FontWeight.w700, color: _GC.muted, letterSpacing: 1)),
          SizedBox(height: 6),
          GestureDetector(
            onTap: _fetchBugSystems,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
              decoration: BoxDecoration(
                color: _GC.whatsapp.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _GC.whatsapp.withOpacity(0.25)),
              ),
              child: Text('Retry', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: _GC.whatsapp, fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // FEATURE STRIP
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildFeatureStrip() {
    return Row(
      children: [
        Expanded(child: _buildFeatureCard(FontAwesomeIcons.droplet, 'INSTANT', 'Fast deploy', _GC.accent)),
        SizedBox(width: 10),
        Expanded(child: _buildFeatureCard(FontAwesomeIcons.shieldHalved, 'STEALTH', 'Undetected', _GC.whatsapp)),
        SizedBox(width: 10),
        Expanded(child: _buildFeatureCard(FontAwesomeIcons.users, 'MASS', 'All members', _GC.gold)),
      ],
    );
  }

  Widget _buildFeatureCard(IconData icon, String title, String subtitle, Color color) {
    return AnimatedBuilder(
      animation: _shimmerController,
      builder: (ctx, _) {
        return Container(
          padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 12),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.4),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withOpacity(0.12 + _shimmerController.value * 0.08), width: 1),
          ),
          child: Column(
            children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withOpacity(0.1),
                  border: Border.all(color: color.withOpacity(0.2)),
                ),
                child: Center(child: Icon(icon, color: color, size: 16)),
              ),
              SizedBox(height: 10),
              Text(title, style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.5, color: color)),
              SizedBox(height: 3),
              Text(subtitle, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: _GC.muted2)),
            ],
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // LAUNCH BUTTON
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildLaunchButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (ctx, child) {
        final pulse = _pulseController.value;
        return Container(
          width: double.infinity,
          height: 62,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(color: _GC.whatsapp.withOpacity(0.18 + pulse * 0.08), blurRadius: 24),
            ],
          ),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: LinearGradient(
                colors: [_GC.whatsapp, _GC.whatsappDark],
                begin: Alignment(-0.7, -0.4),
                end: Alignment(0.7, 0.4),
              ),
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: _isSending ? null : _sendGroupBug,
                splashColor: Colors.white.withOpacity(0.08),
                highlightColor: Colors.white.withOpacity(0.04),
                child: Center(
                  child: _isSending
                      ? Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white.withOpacity(0.4))),
                          SizedBox(width: 16),
                          Text('INJECTING', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 15, fontWeight: FontWeight.w700, letterSpacing: 5, color: _GC.text)),
                        ])
                      : Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(FontAwesomeIcons.dragon, color: _GC.text, size: 18),
                          SizedBox(width: 14),
                          Text('LAUNCH GROUP STRIKE', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 3, color: _GC.text)),
                          SizedBox(width: 14),
                          Container(padding: const EdgeInsets.all(5), decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.1)), child: Icon(Icons.arrow_forward, color: _GC.text, size: 14)),
                        ]),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // STATUS BAR
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildStatusBar() {
    return Row(
      children: [
        Expanded(
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
            decoration: BoxDecoration(
              color: _GC.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _GC.border2),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(width: 6, height: 6, decoration: BoxDecoration(shape: BoxShape.circle, color: _GC.whatsapp, boxShadow: [BoxShadow(color: _GC.whatsapp, blurRadius: 4)])),
                SizedBox(width: 8),
                Text('SYSTEM ONLINE', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, color: _GC.whatsapp, letterSpacing: 1.5)),
              ],
            ),
          ),
        ),
        SizedBox(width: 10),
        Expanded(
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
            decoration: BoxDecoration(
              color: _GC.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _GC.border2),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(FontAwesomeIcons.users, color: _GC.accent, size: 10),
                SizedBox(width: 8),
                Text('MASS MODE', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, color: _GC.accent, letterSpacing: 1.5)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ── Section header + icon ──
  Widget _buildSectionHeader(IconData icon, String title) {
    return Row(
      children: [
        _buildSecIco(icon),
        SizedBox(width: 14),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 3, color: _GC.text)),
          SizedBox(height: 4),
          Container(width: 30, height: 2, decoration: BoxDecoration(color: _GC.whatsapp.withOpacity(0.4), borderRadius: BorderRadius.circular(1))),
        ]),
      ],
    );
  }

  Widget _buildSecIco(IconData icon) {
    return Container(
      width: 42, height: 42,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(13),
        color: _GC.whatsapp.withOpacity(0.1),
        border: Border.all(color: _GC.whatsapp.withOpacity(0.18)),
      ),
      child: Center(child: Icon(icon, color: _GC.whatsapp, size: 17)),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// PROCESSING DIALOG — Countdown 5 detik + Fake Log
// ═══════════════════════════════════════════════════════════════════════════
class _ProcessingDialog extends StatefulWidget {
  final String target;
  final String bugName;
  final Future<Map<String, dynamic>> apiFuture;
  final Function(Map<String, dynamic>) onComplete;

  const _ProcessingDialog({
    required this.target,
    required this.bugName,
    required this.apiFuture,
    required this.onComplete,
  });

  @override
  State<_ProcessingDialog> createState() => _ProcessingDialogState();
}

class _ProcessingDialogState extends State<_ProcessingDialog>
    with TickerProviderStateMixin {
  late AnimationController _scaleController;
  late AnimationController _ringController;
  late AnimationController _glowController;

  int _countdown = 5;
  Timer? _countdownTimer;
  bool _apiDone = false;
  bool _apiSuccess = false;
  Map<String, dynamic>? _apiResult;
  String _currentLog = "";
  int _logIndex = 0;

  final List<String> _fakeLogs = [
    "[System] Initializing socket connection...",
    "[System] Injecting payload into group...",
    "[System] Verifying handshake...",
    "[System] Routing through proxy node...",
    "[System] Deploying attack sequence...",
    "[System] Awaiting server response...",
    "[System] Encrypting packets...",
    "[System] Connection secured.",
  ];

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(vsync: this, duration: Duration(milliseconds: 500))..forward();
    _ringController = AnimationController(vsync: this, duration: Duration(seconds: 4))..repeat();
    _glowController = AnimationController(vsync: this, duration: Duration(milliseconds: 1500))..repeat(reverse: true);

    _currentLog = _fakeLogs[0];
    _startCountdown();

    widget.apiFuture.then((result) {
      if (!mounted) return;
      _apiDone = true;
      _apiSuccess = result['success'] == true;
      _apiResult = result['data'] ?? result;
      _tryComplete();
    });
  }

  void _startCountdown() {
    _countdownTimer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      setState(() {
        if (_countdown > 0) {
          _countdown--;
          _logIndex = (_logIndex + 1) % _fakeLogs.length;
          _currentLog = _fakeLogs[_logIndex];
        }
      });
      if (_countdown <= 0) _tryComplete();
    });
  }

  bool _isCompleting = false;
  void _tryComplete() {
    if (_isCompleting) return;
    if (_countdown > 0) return;
    if (!_apiDone) return;

    _isCompleting = true;
    _countdownTimer?.cancel();

    final result = {
      'success': _apiSuccess,
      'data': _apiResult ?? {},
    };

    Future.delayed(Duration(milliseconds: 400), () {
      if (!mounted) return;
      Navigator.of(context).pop();
      widget.onComplete(result);
    });
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    _scaleController.dispose();
    _ringController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final progress = (5 - _countdown) / 5.0;

    return PopScope(
      canPop: false,
      child: Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: EdgeInsets.zero,
        child: ScaleTransition(
          scale: CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
          child: Container(
            width: MediaQuery.of(context).size.width * 0.88,
            constraints: BoxConstraints(maxWidth: 400),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF1a1a1a), Color(0xFF0a0a0a)],
              ),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: _GC.whatsapp.withOpacity(0.4), width: 1.5),
              boxShadow: [
                BoxShadow(color: _GC.whatsapp.withOpacity(0.25), blurRadius: 40),
                BoxShadow(color: Colors.black.withOpacity(0.6), blurRadius: 30),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 32, 24, 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Spinner + rotating ring + countdown
                  AnimatedBuilder(
                    animation: _glowController,
                    builder: (context, _) {
                      final glow = _glowController.value;
                      return SizedBox(
                        width: 120,
                        height: 120,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            AnimatedBuilder(
                              animation: _ringController,
                              builder: (context, _) => Transform.rotate(
                                angle: _ringController.value * 2 * math.pi,
                                child: CustomPaint(
                                  size: Size(120, 120),
                                  painter: _DashedRingPainter(
                                    color: _GC.whatsapp.withOpacity(0.35),
                                    dashCount: 24,
                                    ringRadius: 55,
                                    strokeWidth: 1.5,
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              width: 90, height: 90,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: _GC.whatsapp.withOpacity(0.08 + glow * 0.06),
                                border: Border.all(color: _GC.whatsapp.withOpacity(0.25 + glow * 0.2), width: 2),
                                boxShadow: [
                                  BoxShadow(color: _GC.whatsapp.withOpacity(0.2 + glow * 0.2), blurRadius: 20 + glow * 15, spreadRadius: 1),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 60, height: 60,
                              child: CircularProgressIndicator(
                                strokeWidth: 3,
                                valueColor: AlwaysStoppedAnimation(_GC.whatsapp),
                                backgroundColor: _GC.whatsapp.withOpacity(0.1),
                              ),
                            ),
                            AnimatedSwitcher(
                              duration: Duration(milliseconds: 400),
                              transitionBuilder: (child, anim) => ScaleTransition(
                                scale: Tween<double>(begin: 0.5, end: 1.0).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutBack)),
                                child: FadeTransition(opacity: anim, child: child),
                              ),
                              child: Text(
                                _countdown > 0 ? '$_countdown' : '0',
                                key: ValueKey('count-$_countdown'),
                                style: TextStyle(
                                  fontFamily: 'MADEEvolveSansEVO',
                                  fontSize: 32,
                                  fontWeight: FontWeight.w900,
                                  color: _GC.text,
                                  height: 1,
                                  shadows: [Shadow(color: _GC.whatsapp, blurRadius: 12)],
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                  SizedBox(height: 24),
                  ShaderMask(
                    shaderCallback: (bounds) => LinearGradient(colors: [_GC.whatsapp, _GC.accent2, _GC.whatsapp]).createShader(bounds),
                    blendMode: BlendMode.srcIn,
                    child: Text(
                      'PROCESSING',
                      style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 4, color: Colors.white),
                    ),
                  ),
                  SizedBox(height: 6),
                  Text(
                    _countdown > 0 ? 'Verifying payload...' : 'Awaiting response...',
                    style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: _GC.muted, letterSpacing: 1),
                  ),
                  SizedBox(height: 20),
                  Container(
                    height: 6,
                    decoration: BoxDecoration(
                      color: _GC.surface,
                      borderRadius: BorderRadius.circular(3),
                      border: Border.all(color: _GC.border2),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(3),
                      child: AnimatedContainer(
                        duration: Duration(milliseconds: 900),
                        curve: Curves.easeInOut,
                        alignment: Alignment.centerLeft,
                        width: double.infinity,
                        child: FractionallySizedBox(
                          widthFactor: progress,
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [_GC.whatsapp, _GC.accent2]),
                              boxShadow: [BoxShadow(color: _GC.whatsapp.withOpacity(0.5), blurRadius: 8)],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: _GC.surface.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _GC.border2),
                    ),
                    child: Column(
                      children: [
                        _infoRow('Target', _truncate(widget.target)),
                        SizedBox(height: 6),
                        _infoRow('Bug', widget.bugName.toUpperCase()),
                      ],
                    ),
                  ),
                  SizedBox(height: 16),
                  Container(
                    width: double.infinity,
                    height: 60,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _GC.whatsapp.withOpacity(0.15)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 5, height: 5,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: _GC.whatsapp,
                                boxShadow: [BoxShadow(color: _GC.whatsapp, blurRadius: 4)],
                              ),
                            ),
                            SizedBox(width: 6),
                            Text('LIVE FEED', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 8, color: _GC.muted2, letterSpacing: 1.5)),
                          ],
                        ),
                        SizedBox(height: 6),
                        AnimatedSwitcher(
                          duration: Duration(milliseconds: 400),
                          transitionBuilder: (child, anim) => FadeTransition(
                            opacity: anim,
                            child: SlideTransition(
                              position: Tween<Offset>(begin: Offset(0, 0.3), end: Offset.zero).animate(anim),
                              child: child,
                            ),
                          ),
                          child: Text(
                            _countdown > 0 ? _currentLog : '[System] Finalizing injection...',
                            key: ValueKey('log-$_logIndex-$_countdown'),
                            style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10.5, color: _GC.accent2, height: 1.4),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: 12, height: 12,
                        child: CircularProgressIndicator(
                          strokeWidth: 1.5,
                          valueColor: AlwaysStoppedAnimation(_GC.whatsapp.withOpacity(0.5)),
                        ),
                      ),
                      SizedBox(width: 8),
                      Text(
                        'Please wait, do not close the app',
                        style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: _GC.muted2, letterSpacing: 0.5),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Row(
      children: [
        SizedBox(
          width: 60,
          child: Text('[$label]', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _GC.muted2)),
        ),
        SizedBox(width: 6),
        Expanded(
          child: Text(value,
              style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: _GC.text, fontWeight: FontWeight.w600),
              maxLines: 1,
              overflow: TextOverflow.ellipsis),
        ),
      ],
    );
  }

  String _truncate(String s) {
    if (s.length <= 32) return s;
    return '${s.substring(0, 29)}...';
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// DASHED RING PAINTER
// ═══════════════════════════════════════════════════════════════════════════
class _DashedRingPainter extends CustomPainter {
  final Color color;
  final int dashCount;
  final double ringRadius;
  final double strokeWidth;

  _DashedRingPainter({
    required this.color,
    required this.dashCount,
    required this.ringRadius,
    required this.strokeWidth,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final paint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final angleStep = (2 * math.pi) / dashCount;
    final dashLength = angleStep * 0.45;

    for (int i = 0; i < dashCount; i++) {
      final startAngle = i * angleStep;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: ringRadius),
        startAngle,
        dashLength,
        false,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_DashedRingPainter oldDelegate) {
    return oldDelegate.color != color || oldDelegate.ringRadius != ringRadius || oldDelegate.dashCount != dashCount;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GROUP SUCCESS DIALOG — Enhanced
// ═══════════════════════════════════════════════════════════════════════════
class _GroupSuccessDialog extends StatefulWidget {
  final String linkGroup;
  final String bugType;
  final Map<String, dynamic> data;
  final VoidCallback onDismiss;

  const _GroupSuccessDialog({
    required this.linkGroup,
    required this.bugType,
    required this.data,
    required this.onDismiss,
  });

  @override
  State<_GroupSuccessDialog> createState() => _GroupSuccessDialogState();
}

class _GroupSuccessDialogState extends State<_GroupSuccessDialog>
    with TickerProviderStateMixin {
  late AnimationController _scaleController;
  late AnimationController _infoController;
  late AnimationController _glowController;
  late AnimationController _ringController;

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(vsync: this, duration: Duration(milliseconds: 500));
    _infoController = AnimationController(vsync: this, duration: Duration(milliseconds: 400));
    _glowController = AnimationController(vsync: this, duration: Duration(seconds: 2))..repeat(reverse: true);
    _ringController = AnimationController(vsync: this, duration: Duration(seconds: 6))..repeat();

    _scaleController.forward();
    Future.delayed(Duration(milliseconds: 600), () {
      if (mounted) _revealInfo();
    });
  }

  void _revealInfo() {
    if (mounted) _infoController.forward();
  }

  @override
  void dispose() {
    _scaleController.dispose();
    _infoController.dispose();
    _glowController.dispose();
    _ringController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width * 0.88;

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: EdgeInsets.zero,
      child: ScaleTransition(
        scale: CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
        child: Container(
          width: w,
          constraints: BoxConstraints(maxWidth: 400),
          decoration: BoxDecoration(
            color: _GC.card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _GC.border, width: 1),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 36, offset: Offset(0, 14)),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(28, 30, 28, 28),
            child: FadeTransition(
              opacity: CurvedAnimation(parent: _infoController, curve: Curves.easeOut),
              child: ScaleTransition(
                scale: CurvedAnimation(parent: _infoController, curve: Curves.easeOut),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Icon with glow + ring
                    SizedBox(
                      width: 100,
                      height: 100,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          AnimatedBuilder(
                            animation: _ringController,
                            builder: (ctx, _) => Transform.rotate(
                              angle: _ringController.value * 2 * math.pi,
                              child: CustomPaint(
                                size: Size(100, 100),
                                painter: _DashedRingPainter(
                                  color: _GC.whatsapp.withOpacity(0.4),
                                  dashCount: 20,
                                  ringRadius: 46,
                                  strokeWidth: 1.5,
                                ),
                              ),
                            ),
                          ),
                          AnimatedBuilder(
                            animation: _glowController,
                            builder: (ctx, _) {
                              final glow = _glowController.value;
                              return Container(
                                width: 80, height: 80,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(
                                    colors: [_GC.whatsapp, _GC.whatsappDark],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  boxShadow: [
                                    BoxShadow(color: _GC.whatsapp.withOpacity(0.4 + glow * 0.3), blurRadius: 20 + glow * 15),
                                  ],
                                ),
                                child: Center(
                                  child: Icon(FontAwesomeIcons.dragon, color: _GC.text, size: 32),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 24),
                    Text('GROUP OBLITERATED', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 18, fontWeight: FontWeight.w700, letterSpacing: 3, color: _GC.text)),
                    SizedBox(height: 6),
                    Container(width: 40, height: 2, decoration: BoxDecoration(color: _GC.whatsapp.withOpacity(0.3), borderRadius: BorderRadius.circular(1))),
                    SizedBox(height: 18),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: _GC.surface,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: _GC.border2),
                      ),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(FontAwesomeIcons.whatsapp, color: _GC.whatsapp, size: 16),
                              SizedBox(width: 10),
                              Flexible(
                                child: Text(
                                  _truncateLink(widget.linkGroup),
                                  style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, fontWeight: FontWeight.w700, color: _GC.text),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 10),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              color: _GC.success.withOpacity(0.1),
                              border: Border.all(color: _GC.success.withOpacity(0.2)),
                            ),
                            child: Text(
                              widget.data["sended"] == true ? 'INJECTED' : (widget.data["success"] == true ? 'INJECTED' : 'FAILED'),
                              style: TextStyle(
                                fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 2,
                                color: (widget.data["sended"] == true || widget.data["success"] == true) ? _GC.success : _GC.accent,
                              ),
                            ),
                          ),
                          SizedBox(height: 10),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              color: _GC.whatsapp.withOpacity(0.1),
                              border: Border.all(color: _GC.whatsapp.withOpacity(0.2)),
                            ),
                            child: Text(
                              'BUG: ${widget.bugType.toUpperCase()}',
                              style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 2, color: _GC.whatsapp),
                            ),
                          ),
                          if (widget.data["groupInfo"] != null) ...[
                            SizedBox(height: 12),
                            Container(height: 1, color: _GC.border2),
                            SizedBox(height: 10),
                            _buildDetailRow('Group', widget.data["groupInfo"]["subject"] ?? "Unknown"),
                            SizedBox(height: 6),
                            _buildDetailRow('Members', widget.data["groupInfo"]["participants"]?.toString() ?? "Unknown"),
                          ],
                          if (widget.data["canSendMessage"] != null) ...[
                            SizedBox(height: 6),
                            _buildDetailRow('Injection', widget.data["canSendMessage"] ? "SUCCESS" : "BLOCKED",
                                color: widget.data["canSendMessage"] ? _GC.success : _GC.accent),
                          ],
                        ],
                      ),
                    ),
                    SizedBox(height: 24),
                    GestureDetector(
                      onTap: widget.onDismiss,
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          color: _GC.text,
                          borderRadius: BorderRadius.circular(14),
                          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 14)],
                        ),
                        child: Center(child: Text('CLOSE', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 2.5, color: _GC.bg))),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value, {Color? color}) {
    return Row(
      children: [
        SizedBox(
          width: 80,
          child: Text('[$label]', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: _GC.muted)),
        ),
        Expanded(
          child: Text(value, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, fontWeight: FontWeight.w700, color: color ?? _GC.text)),
        ),
      ],
    );
  }

  String _truncateLink(String link) {
    if (link.length > 40) {
      return '${link.substring(0, 37)}...';
    }
    return link;
  }
}