import 'package:flutter/cupertino.dart';
import 'settings_page.dart';
import 'widgets_page.dart';

class GalleryHome extends StatelessWidget {
  const GalleryHome({
    super.key,
    required this.onThemeChange,
    required this.isDarkMode,
    required this.onTextSizeChange,
    required this.textSize,
  });

  final ValueChanged<bool> onThemeChange;
  final bool isDarkMode;
  final ValueChanged<double> onTextSizeChange;
  final double textSize;

  @override
  Widget build(BuildContext context) {
    return CupertinoTabScaffold(
      tabBar: CupertinoTabBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(CupertinoIcons.list_bullet),
            label: 'Widgets',
          ),
          BottomNavigationBarItem(
            icon: Icon(CupertinoIcons.settings),
            label: 'Settings',
          ),
        ],
      ),
      tabBuilder: (context, index) {
        return CupertinoTabView(
          builder: (context) {
            return switch (index) {
              0 => const WidgetsPage(),
              1 => SettingsPage(
                onThemeChange: onThemeChange,
                isDarkMode: isDarkMode,
                onTextSizeChange: onTextSizeChange,
                textSize: textSize,
              ),
              _ => const Center(child: Text('Widgets')),
            };
          },
        );
      },
    );
  }
}
