import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui'; // Buat ImageFilter (Glassmorphism)
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'api_config.dart';

// ─── Palette ──────────────────────────────────────────────────────────────────
class _C {
  static const bg        = Color(0xFF060B14);
  static const surface   = Color(0xFF0C1424);
  static const card      = Color(0xFF101A2E);
  static const border    = Color(0xFF1A2D4A);
  static const borderLit = Color(0xFF1E3A5F);

  static const blue      = Color(0xFF1B6FBD);
  static const blueMid   = Color(0xFF2D8FE8);
  static const blueLight = Color(0xFF56AEF5);

  static const green     = Color(0xFF22C55E);
  static const amber     = Color(0xFFF59E0B);
  static const red       = Color(0xFFEF4444);
  static const purple    = Color(0xFFA78BFA);

  static const text      = Color(0xFFE2EDF9);
  static const textSub   = Color(0xFF7A9BBF);
  static const textDim   = Color(0xFF3A5470);

  static const LinearGradient btnGrad = LinearGradient(
    colors: [blueMid, blueLight],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

// ─── Rules data ───────────────────────────────────────────────────────────────
const _rules = [
  _Rule(
    title: 'Larangan Barter Akun',
    desc:  'Akun tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun.',
    icon:  Icons.swap_horiz_rounded,
    color: Color(0xFFF59E0B),
  ),
  _Rule(
    title: 'Larangan Membagikan Akun',
    desc:  'Setiap akun bersifat pribadi dan hanya boleh digunakan oleh pemilik akun yang terdaftar.',
    icon:  Icons.share_rounded,
    color: Color(0xFF60A5FA),
  ),
  _Rule(
    title: 'Larangan Menjual Akun',
    desc:  'Member TIDAK diperbolehkan menjual akun. Penjualan hanya boleh dilakukan oleh role yang diizinkan secara resmi.',
    icon:  Icons.sell_rounded,
    color: Color(0xFFEF4444),
  ),
  _Rule(
    title: 'Larangan Jual Durasi Ilegal',
    desc:  'Dilarang menjual akses harian, mingguan, trial, atau sejenisnya di luar ketentuan yang telah ditetapkan.',
    icon:  Icons.timer_off_rounded,
    color: Color(0xFFA78BFA),
  ),
  _Rule(
    title: 'Larangan Banting Harga',
    desc:  'Dilarang merusak atau menurunkan harga yang telah ditentukan di bawah ketentuan Knight-Forest.',
    icon:  Icons.trending_down_rounded,
    color: Color(0xFF34D399),
  ),
];

class _Rule {
  final String title;
  final String desc;
  final IconData icon;
  final Color color;
  const _Rule({required this.title, required this.desc,
      required this.icon, required this.color});
}

// ─── Page ─────────────────────────────────────────────────────────────────────
class InfoPage extends StatefulWidget {
  final String sessionKey;
  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> with TickerProviderStateMixin {
  // Animations
  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _sanctionCtrl;

  late Animation<double> _entrance;
  late Animation<double> _sanctionGlow;

  int? _expandedRule;

  @override
  void initState() {
    super.initState();

    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 18))
      ..repeat();

    _entranceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600));
    _entrance = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic);

    _sanctionCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2000))
      ..repeat(reverse: true);
    _sanctionGlow = Tween<double>(begin: 0.2, end: 0.6)
        .animate(CurvedAnimation(parent: _sanctionCtrl, curve: Curves.easeInOut));

    _entranceCtrl.forward();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _sanctionCtrl.dispose();
    super.dispose();
  }

  // ─── Build ────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          Positioned.fill(child: _AnimatedBg(controller: _bgCtrl)),
          SafeArea(
            child: FadeTransition(
              opacity: _entrance,
              child: ListView(
                physics: const BouncingScrollPhysics(),
                // Padding 0 biar banner nempel mentok ke pinggir layar
                padding: const EdgeInsets.only(top: 16, bottom: 48),
                children: [
                  // Banner NTED CRASHER (Nempel kiri-kanan)
                  const NtedCrasherBanner(),
                  const SizedBox(height: 24),

                  // Rules Section Header
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: _buildModernSectionHeader(),
                  ),
                  const SizedBox(height: 16),

                  // Rules List (Accordion Style)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Column(
                      children: _rules.asMap().entries.map((e) =>
                        Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: _ModernRuleCard(
                            rule: e.value,
                            number: e.key + 1,
                            isExpanded: _expandedRule == e.key,
                            onTap: () => setState(() {
                              _expandedRule = _expandedRule == e.key ? null : e.key;
                            }),
                          ),
                        ),
                      ).toList(),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Sanction Card
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: _buildSanctionCardModern(),
                  ),
                  const SizedBox(height: 24),

                  // Footer note
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: _buildFooter(),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Modern Section Header ─────────────────────────────────────────────────
  Widget _buildModernSectionHeader() {
    return Row(
      children: [
        Container(
          width: 4, height: 28,
          decoration: BoxDecoration(
            gradient: _C.btnGrad,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 12),
        const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('PERATURAN',
                style: TextStyle(color: _C.text, fontSize: 18,
                    fontWeight: FontWeight.w800, letterSpacing: -0.3)),
            Text('Tap untuk melihat detail',
                style: TextStyle(color: _C.textSub, fontSize: 11)),
          ],
        ),
        const Spacer(),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: _C.blue.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text('${_rules.length} ATURAN',
              style: const TextStyle(color: _C.blueLight, fontSize: 10,
                  fontWeight: FontWeight.w700)),
        ),
      ],
    );
  }

  // ─── Sanction Card Modern ──────────────────────────────────────────────────
  Widget _buildSanctionCardModern() {
    return AnimatedBuilder(
      animation: _sanctionCtrl,
      builder: (_, __) => Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_C.card.withValues(alpha: 0.5), _C.surface],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: _C.red.withValues(alpha: 0.3 + _sanctionGlow.value * 0.2),
            width: 1.5,
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Stack(
            children: [
              Positioned(
                right: -20, top: -20,
                child: Icon(Icons.gavel_rounded,
                    size: 100, color: _C.red.withValues(alpha: 0.05)),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: _C.red.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Icon(Icons.warning_rounded,
                              color: _C.red.withValues(alpha: 0.8 + _sanctionGlow.value * 0.2),
                              size: 22),
                        ),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Text('SANKSI TEGAS',
                              style: TextStyle(color: _C.red, fontSize: 16,
                                  fontWeight: FontWeight.w800, letterSpacing: 1)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: _C.red.withValues(alpha: 0.05),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: _C.red.withValues(alpha: 0.15)),
                      ),
                      child: const Row(
                        children: [
                          Icon(Icons.block_rounded, color: _C.red, size: 20),
                          SizedBox(width: 12),
                          Expanded(
                            child: Text('Akun akan DIHAPUS secara permanen',
                                style: TextStyle(color: _C.text, fontSize: 13,
                                    fontWeight: FontWeight.w600)),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 8,
                      children: [
                        _sanctionChip(Icons.account_balance_wallet_rounded, 'Tanpa refund'),
                        _sanctionChip(Icons.sync_disabled_rounded, 'Tanpa kompensasi'),
                        _sanctionChip(Icons.person_off_rounded, 'Permanent ban'),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sanctionChip(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: _C.red.withValues(alpha: 0.08),
        border: Border.all(color: _C.red.withValues(alpha: 0.2)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: _C.red, size: 12),
          const SizedBox(width: 4),
          Text(label,
              style: const TextStyle(color: _C.textSub, fontSize: 10,
                  fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  Widget _buildFooter() {
    return Column(children: [
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.border),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.shield_moon_rounded, color: _C.blueLight, size: 18),
            const SizedBox(width: 12),
            const Expanded(
              child: Text(
                'Dengan menggunakan aplikasi ini, pengguna dianggap telah '
                'menyetujui seluruh peraturan yang berlaku.',
                style: TextStyle(color: _C.textSub, fontSize: 11, height: 1.5),
              ),
            ),
          ],
        ),
      ),
      const SizedBox(height: 16),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(
          height: 2, width: 30,
          decoration: BoxDecoration(
            gradient: _C.btnGrad,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 10),
        const Text('Knight-Forest',
            style: TextStyle(color: _C.textDim, fontSize: 10,
                fontWeight: FontWeight.w600, letterSpacing: 0.5)),
        const SizedBox(width: 10),
        Container(
          height: 2, width: 30,
          decoration: BoxDecoration(
            gradient: _C.btnGrad,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      ]),
    ]);
  }
}

// ─── Modern Rule Card (Accordion) ────────────────────────────────────────────
class _ModernRuleCard extends StatelessWidget {
  final _Rule rule;
  final int number;
  final bool isExpanded;
  final VoidCallback onTap;

  const _ModernRuleCard({
    required this.rule,
    required this.number,
    required this.isExpanded,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = rule.color;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
        decoration: BoxDecoration(
          color: isExpanded ? color.withValues(alpha: 0.06) : _C.card,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isExpanded ? color.withValues(alpha: 0.4) : _C.border,
            width: isExpanded ? 1.5 : 1,
          ),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  Container(
                    width: 34, height: 34,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [color.withValues(alpha: 0.2), color.withValues(alpha: 0.05)],
                      ),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: color.withValues(alpha: 0.3)),
                    ),
                    child: Center(
                      child: Text('$number',
                          style: TextStyle(color: color, fontSize: 14,
                              fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                      color: color.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(rule.icon, color: color, size: 18),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(rule.title,
                        style: const TextStyle(
                          color: _C.text,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        )),
                  ),
                  AnimatedRotation(
                    turns: isExpanded ? 0.5 : 0,
                    duration: const Duration(milliseconds: 300),
                    child: Icon(Icons.keyboard_arrow_down_rounded,
                        color: isExpanded ? color : _C.textDim, size: 20),
                  ),
                ],
              ),
            ),
            AnimatedCrossFade(
              firstChild: const SizedBox(width: double.infinity),
              secondChild: Padding(
                padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _C.surface,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _C.border),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 3, height: 30,
                        decoration: BoxDecoration(
                          color: color,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(rule.desc,
                            style: const TextStyle(color: _C.textSub, fontSize: 12,
                                height: 1.5)),
                      ),
                    ],
                  ),
                ),
              ),
              crossFadeState: isExpanded
                  ? CrossFadeState.showSecond
                  : CrossFadeState.showFirst,
              duration: const Duration(milliseconds: 300),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Banner NTED CRASHER ─────────────────────────────────────────────────────
class NtedCrasherBanner extends StatelessWidget {
  const NtedCrasherBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 180,
      child: Stack(
        children: [
          // Background Grid & Sirkuit
          Positioned.fill(
            child: CustomPaint(
              painter: _CircuitPainter(),
            ),
          ),
          
          // Glassmorphism
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFF0F172A).withValues(alpha: 0.4),
                border: Border(
                  top: BorderSide(color: const Color(0xFF00E5FF).withValues(alpha: 0.3), width: 1),
                  bottom: BorderSide(color: const Color(0xFF00E5FF).withValues(alpha: 0.3), width: 1),
                ),
              ),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Teks Utama Glow Merah Darah
                    Stack(
                      children: [
                        // Layer Glow
                        Text(
                          'NTED CRASHER',
                          style: TextStyle(
                            fontFamily: 'Nted',
                            fontSize: 46,
                            color: const Color(0xFFFF0000).withValues(alpha: 0.5),
                            shadows: [
                              Shadow(
                                color: const Color(0xFFFF0000).withValues(alpha: 0.8),
                                blurRadius: 24,
                              ),
                            ],
                          ),
                        ),
                        // Layer Solid
                        const Text(
                          'NTED CRASHER',
                          style: TextStyle(
                            fontFamily: 'Nted',
                            fontSize: 46,
                            color: Color(0xFF8B0000), // Merah Darah
                            letterSpacing: 2.0,
                          ),
                        ),
                      ],
                    ),
                    
                    const SizedBox(height: 8),
                    
                    // Teks Jepang
                    const Text(
                      'ー nted クラッシャー アプリへようこ ー',
                      style: TextStyle(
                        fontFamily: 'Nted',
                        fontSize: 14,
                        color: Colors.white70,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── CustomPainter untuk Grid & Sirkuit ───
class _CircuitPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // Base color
    final bgPaint = Paint()..color = const Color(0xFF040812);
    canvas.drawRect(Offset.zero & size, bgPaint);

    // Grid Tipis
    final gridPaint = Paint()
      ..color = const Color(0xFF00E5FF).withValues(alpha: 0.1)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;

    const step = 30.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    // Sirkuit
    final random = math.Random(42);
    final circuitPaint = Paint()
      ..color = const Color(0xFF00E5FF).withValues(alpha: 0.2)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    for (int i = 0; i < 15; i++) {
      final startX = random.nextDouble() * size.width;
      final startY = random.nextDouble() * size.height;
      final path = Path()..moveTo(startX, startY);
      
      path.lineTo(startX + (random.nextBool() ? 40 : -40), startY);
      path.lineTo(startX + (random.nextBool() ? 40 : -40), startY + (random.nextBool() ? 30 : -30));
      
      canvas.drawPath(path, circuitPaint);
      
      canvas.drawCircle(
        Offset(startX + (random.nextBool() ? 40 : -40), startY + (random.nextBool() ? 30 : -30)), 
        2, 
        Paint()..color = const Color(0xFF00E5FF).withValues(alpha: 0.5)
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ─── Animated Background ──────────────────────────────────────────────────────
class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) =>
          CustomPaint(painter: _BgPainter(controller.value)),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = _C.border.withValues(alpha: 0.2)
      ..strokeWidth = 0.5;
    const step = 40.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    final glow = Paint()
      ..shader = RadialGradient(colors: [
        _C.blueMid.withValues(alpha: 0.06 + math.sin(t * math.pi * 2) * 0.02),
        Colors.transparent,
      ], radius: 0.9).createShader(Rect.fromCircle(
          center: Offset(size.width / 2, size.height * 0.15),
          radius: size.width * 0.7));
    canvas.drawCircle(
        Offset(size.width / 2, size.height * 0.15), size.width * 0.7, glow);
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}