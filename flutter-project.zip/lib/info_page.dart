// lib/info_page.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'api_config.dart';
import 'app_theme.dart';

class InfoPage extends StatefulWidget {
  final String sessionKey;

  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> with TickerProviderStateMixin {
  bool isLoading = true;

  bool isApiOnline = false;
  int apiPingMs = 0;
  Color apiStatusColor = Colors.black54;
  String apiStatusText = "Checking...";
  Timer? _pingTimer;

  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  final List<Map<String, dynamic>> featuresList = [
    {
      "title": "WhatsApp Crash",
      "icon": Icons.bug_report_rounded,
      "color": const Color(0xFFD32F2F),
      "desc":
          "Kemampuan mengirimkan payload secara masif ke target Private (Nomor) maupun Global (Grup) dengan hit rate tinggi dan efisiensi waktu.",
    },
    {
      "title": "Bug Sender",
      "icon": Icons.devices_rounded,
      "color": const Color(0xFF388E3C),
      "desc":
          "Pairing & konfigurasi perangkat sender untuk manajemen sesi pengiriman payload yang lebih terstruktur dan efisien.",
    },
    {
      "title": "Riwayat Aktivitas",
      "icon": Icons.history_rounded,
      "color": const Color(0xFF1565C0),
      "desc":
          "Rekam dan pantau seluruh histori aktivitas akun kamu secara real-time, lengkap dengan log pengiriman dan status operasi.",
    },
    {
      "title": "Profile & Akun",
      "icon": Icons.person_rounded,
      "color": const Color(0xFF7B1FA2),
      "desc":
          "Kelola data profil, ubah password, dan pantau status akun serta masa aktif langganan kamu dengan mudah.",
    },
    {
      "title": "Global Chat",
      "icon": Icons.groups_2_rounded,
      "color": const Color(0xFFF57C00),
      "desc":
          "Ruang komunitas eksklusif untuk berdiskusi, berbagi pengalaman, dan berinteraksi langsung dengan seluruh pengguna SYAX.",
    },
  ];

  final List<Map<String, dynamic>> rulesList = [
    {
      "title": "NO ACCOUNT BARTERING",
      "icon": Icons.swap_horizontal_circle_outlined,
      "desc":
          "Akun eksklusif SYAX tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun. Pelanggaran log akan terpantau.",
    },
    {
      "title": "STRICTLY PERSONAL USE",
      "icon": Icons.person_off_outlined,
      "desc":
          "Setiap akun terenkripsi untuk satu pengguna dan hanya boleh diakses oleh pemilik perangkat yang mendaftar (terikat Device ID).",
    },
    {
      "title": "RESELLING PROHIBITED",
      "icon": Icons.money_off_csred_outlined,
      "desc":
          "Member reguler dilarang memperjualbelikan akun. Akses penjualan eksklusif milik role berwenang (Partner, Owner, atau Reseller).",
    },
    {
      "title": "ILLEGAL DURATION SALES",
      "icon": Icons.timer_off_outlined,
      "desc":
          "Sangat dilarang membagi atau menjual akses eceran (harian, mingguan, trial) yang mengelabui skema periode resmi.",
    },
    {
      "title": "PRICE DUMPING BAN",
      "icon": Icons.trending_down_rounded,
      "desc":
          "Dilarang keras merusak standar harga pasar (banting harga) di bawah kesepakatan jaminan keamanan platform kami.",
    },
  ];

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
        vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.2, end: 1.0).animate(
        CurvedAnimation(parent: _glowController, curve: Curves.easeInOut));
    _fetchServerInfo();
    _startApiPingLoop();
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    _glowController.dispose();
    super.dispose();
  }

  Future<void> _fetchServerInfo() async {
    try {
      await http.get(Uri.parse('$baseUrl/getServerInfo?key=${widget.sessionKey}'));
      if (mounted) setState(() => isLoading = false);
    } catch (_) {
      if (mounted) setState(() => isLoading = false);
    }
  }

  void _startApiPingLoop() {
    _checkApiPing();
    _pingTimer =
        Timer.periodic(const Duration(seconds: 5), (_) => _checkApiPing());
  }

  Future<void> _checkApiPing() async {
    final start = DateTime.now();
    try {
      final res = await http
          .get(Uri.parse('$baseUrl/ping?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 3));
      final duration = DateTime.now().difference(start).inMilliseconds;
      if (res.statusCode == 200 && mounted) {
        setState(() {
          isApiOnline = true;
          apiPingMs   = duration;
          if (duration < 200) {
            apiStatusColor = const Color(0xFF00E676);
          } else if (duration < 500) {
            apiStatusColor = const Color(0xFFFFD54F);
          } else {
            apiStatusColor = const Color(0xFFFF8A65);
          }
          apiStatusText = "Sys.Online :: ${duration}ms";
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          isApiOnline    = false;
          apiPingMs      = 0;
          apiStatusColor = const Color(0xFFD32F2F);
          apiStatusText  = "Sys.Offline :: DEST";
        });
      }
    }
  }

  // ═══════════════════════════════════════════════════════════
  // REUSABLE WIDGET: METAL PLATE (SAMA SEPERTI DASHBOARD)
  // ═══════════════════════════════════════════════════════════
  Widget _metalPlate({
    required AppPalette C,
    required bool isComic,
    required Widget child,
    EdgeInsets padding = const EdgeInsets.all(16),
    double radius = 16,
  }) {
    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bgDark,
          borderRadius: BorderRadius.circular(radius + 4),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(6, 6),
              blurRadius: 0,
            ),
          ],
        ),
        child: child,
      );
    }
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [C.text, C.bg, C.bgDark, C.bgDeep],
          stops: const [0.0, 0.4, 0.7, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.75),
            offset: const Offset(0, 6),
            blurRadius: 12,
          ),
          const BoxShadow(
            color: Colors.white12,
            offset: Offset(-1, -1),
            blurRadius: 3,
          ),
        ],
      ),
      padding: const EdgeInsets.all(3),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius - 3),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.bg, C.bgDark, C.bgDeep],
          ),
          border: Border.all(color: Colors.black.withOpacity(0.5)),
        ),
        child: child,
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // REUSABLE WIDGET: INSET PANEL (SAMA SEPERTI DASHBOARD)
  // ═══════════════════════════════════════════════════════════
  Widget _insetPanel({
    required AppPalette C,
    required bool isComic,
    required Widget child,
    EdgeInsets padding = const EdgeInsets.all(12),
    Color glowColor = Colors.amber,
    bool glow = false,
  }) {
    if (isComic) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          color: C.bg,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.black, width: 3),
        ),
        child: child,
      );
    }
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [C.bgDeep, C.bgDark],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.95),
            offset: const Offset(0, 2),
            blurRadius: 4,
          ),
          const BoxShadow(
            color: Colors.white10,
            offset: Offset(0, -1),
            blurRadius: 1,
          ),
          if (glow)
            BoxShadow(
              color: glowColor.withOpacity(0.35),
              blurRadius: 10,
            ),
        ],
        border: Border.all(
          color: glow ? glowColor.withOpacity(0.7) : C.bgDark,
          width: 1.5,
        ),
      ),
      child: child,
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SECTION HEADER
  // ═══════════════════════════════════════════════════════════
  Widget _buildSectionHeader(AppPalette C, bool isComic, String title, IconData icon) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.only(left: 10),
          decoration: BoxDecoration(
            border: Border(
              left: BorderSide(
                color: isComic ? Colors.black : C.accent,
                width: isComic ? 4 : 3.5,
              ),
            ),
          ),
          child: Row(
            children: [
              Icon(icon, color: isComic ? C.comicText : C.accent, size: 20),
              const SizedBox(width: 8),
              Text(
                "!! $title",
                style: TextStyle(
                  color: isComic ? C.comicText : C.text,
                  fontWeight: FontWeight.bold,
                  fontSize: isComic ? 17 : 16,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: isComic ? 2 : 1.2,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Container(
          width: 60,
          height: 4,
          decoration: BoxDecoration(
            color: isComic ? Colors.black : C.accent,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // TENTANG
  // ═══════════════════════════════════════════════════════════
  Widget _buildTentangSection(AppPalette C, bool isComic) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader(C, isComic, "Tentang SYAX", Icons.info_outline_rounded),
        const SizedBox(height: 14),
        _metalPlate(
          C: C,
          isComic: isComic,
          padding: const EdgeInsets.all(20),
          child: Text(
            "SYAX Project adalah sebuah sistem utilitas tingkat lanjut yang dirancang khusus untuk memfasilitasi pengujian stabilitas dan pengiriman payload (Bug Testing). Dibangun dengan arsitektur berkinerja tinggi, sistem ini menjamin kecepatan eksekusi, keamanan enkripsi sesi, dan presisi dalam pengiriman data baik secara personal maupun publik. Kami menyediakan infrastruktur server yang kuat untuk kelancaran tugas Anda.",
            style: TextStyle(
              color: isComic ? C.comicText : C.text,
              fontSize: isComic ? 14 : 13,
              height: 1.75,
              fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
            ),
            textAlign: TextAlign.justify,
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // FEATURE CARD
  // ═══════════════════════════════════════════════════════════
  Widget _buildFeatureCard(AppPalette C, bool isComic, Map<String, dynamic> feature) {
    final Color c = feature['color'] as Color;
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: _metalPlate(
        C: C,
        isComic: isComic,
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isComic ? c.withOpacity(0.9) : c.withOpacity(0.1),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: isComic ? Colors.black : c.withOpacity(0.22),
                  width: isComic ? 3 : 1,
                ),
              ),
              child: Icon(
                feature['icon'] as IconData,
                color: isComic
                    ? (c.computeLuminance() > 0.5 ? Colors.black : Colors.white)
                    : c,
                size: 24,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    feature['title'] as String,
                    style: TextStyle(
                      color: isComic ? C.comicText : C.text,
                      fontWeight: FontWeight.w800,
                      fontSize: isComic ? 15 : 14,
                      fontFamily: isComic ? 'Bangers' : 'Orbitron',
                      letterSpacing: isComic ? 1 : 0.5,
                      shadows: isComic
                          ? [
                              Shadow(
                                color: C.comicTextOutline,
                                offset: const Offset(1, 1),
                                blurRadius: 0,
                              ),
                            ]
                          : null,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    feature['desc'] as String,
                    style: TextStyle(
                      color: isComic ? C.comicText.withOpacity(0.8) : C.textSub,
                      fontSize: isComic ? 13 : 12,
                      height: 1.55,
                      fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // RULE CARD
  // ═══════════════════════════════════════════════════════════
  Widget _buildRuleCard(AppPalette C, bool isComic, int index, Map<String, dynamic> rule) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: _metalPlate(
        C: C,
        isComic: isComic,
        padding: EdgeInsets.zero,
        child: Theme(
          data: ThemeData(dividerColor: Colors.transparent),
          child: ExpansionTile(
            iconColor: isComic ? C.comicText : C.accent,
            collapsedIconColor: isComic
                ? C.comicText.withOpacity(0.5)
                : C.accent.withOpacity(0.5),
            tilePadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            leading: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: isComic
                    ? C.primaryHi
                    : C.accent.withOpacity(0.08),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isComic
                      ? Colors.black
                      : C.accent.withOpacity(0.2),
                  width: isComic ? 3 : 1,
                ),
              ),
              child: Icon(
                rule['icon'] as IconData,
                color: isComic ? C.contrastTextOn(C.primaryHi) : C.accent,
                size: 22,
              ),
            ),
            title: Text(
              rule['title'] as String,
              style: TextStyle(
                color: isComic ? C.comicText : C.text,
                fontWeight: FontWeight.bold,
                fontSize: isComic ? 14 : 13,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                letterSpacing: isComic ? 1.2 : 0.8,
                shadows: isComic
                    ? [
                        Shadow(
                          color: C.comicTextOutline,
                          offset: const Offset(1, 1),
                          blurRadius: 0,
                        ),
                      ]
                    : null,
              ),
            ),
            children: [
              Container(
                padding: const EdgeInsets.only(
                    left: 20, right: 20, bottom: 18, top: 2),
                width: double.infinity,
                child: Text(
                  rule['desc'] as String,
                  style: TextStyle(
                    color: isComic ? C.comicText.withOpacity(0.8) : C.textSub,
                    fontSize: isComic ? 13 : 12,
                    height: 1.55,
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // PENALTY BOX
  // ═══════════════════════════════════════════════════════════
  Widget _buildPenaltyBox(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 28),
      child: _metalPlate(
        C: C,
        isComic: isComic,
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.warning_amber_rounded,
                    color: const Color(0xFFEF5350),
                    size: isComic ? 28 : 26),
                const SizedBox(width: 10),
                Text(
                  "VIOLATION PENALTY",
                  style: TextStyle(
                    color: const Color(0xFFEF5350),
                    fontSize: isComic ? 17 : 16,
                    fontWeight: FontWeight.w900,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: isComic ? 2 : 1.5,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.comicTextOutline,
                              offset: const Offset(1, 1),
                              blurRadius: 0,
                            ),
                          ]
                        : null,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Text(
              "Jika pengguna terdeteksi melanggar salah satu protokol kerahasiaan & aturan di atas secara sengaja:",
              style: TextStyle(
                color: isComic ? C.comicText : C.text,
                fontSize: isComic ? 13 : 12,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                height: 1.5,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0xFFD32F2F).withOpacity(isComic ? 0.9 : 0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: isComic
                      ? Colors.black
                      : const Color(0xFFEF5350).withOpacity(0.5),
                  width: isComic ? 3 : 1,
                ),
              ),
              child: Text(
                "AKUN AKAN DIHAPUS PERMANEN",
                style: TextStyle(
                  color: isComic ? Colors.white : C.text,
                  fontSize: isComic ? 14 : 13,
                  fontWeight: FontWeight.bold,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  letterSpacing: isComic ? 1.5 : 1,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "TIDAK ADA PENGEMBALIAN SALDO ATAU KOMPENSASI.",
              style: TextStyle(
                color: const Color(0xFFEF5350),
                fontSize: 11,
                fontWeight: FontWeight.bold,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // STATUS HEADER
  // ═══════════════════════════════════════════════════════════
  Widget _buildStatusHeader(AppPalette C, bool isComic) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 24),
      child: _insetPanel(
        C: C,
        isComic: isComic,
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        glow: !isComic,
        glowColor: apiStatusColor,
        child: Row(
          children: [
            AnimatedBuilder(
              animation: _glowAnimation,
              builder: (_, __) => Container(
                width: isComic ? 14 : 12,
                height: isComic ? 14 : 12,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: apiStatusColor,
                  border: isComic
                      ? Border.all(color: Colors.black, width: 2)
                      : null,
                  boxShadow: isComic
                      ? null
                      : [
                          BoxShadow(
                            color: apiStatusColor.withOpacity(
                                _glowAnimation.value * 0.6),
                            blurRadius: 10,
                            spreadRadius: 2,
                          ),
                        ],
                ),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                apiStatusText.toUpperCase(),
                style: TextStyle(
                  color: apiStatusColor == Colors.black54
                      ? (isComic ? C.comicText : C.text)
                      : apiStatusColor,
                  fontFamily: isComic ? 'Bangers' : 'ShareTechMono',
                  fontWeight: FontWeight.w800,
                  fontSize: isComic ? 15 : 13,
                  letterSpacing: isComic ? 1.8 : 1.5,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
            ),
            Icon(Icons.memory,
                color: (isComic ? C.comicText : C.textSub).withOpacity(0.4),
                size: 20),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            if (isLoading) {
              return Scaffold(
                backgroundColor: C.bg,
                body: Center(
                  child: CircularProgressIndicator(
                    color: isComic ? C.primaryHi : C.accent,
                    strokeWidth: isComic ? 4 : 2,
                  ),
                ),
              );
            }

            return Scaffold(
              backgroundColor: C.bg,
              appBar: AppBar(
                backgroundColor: C.bgDark,
                elevation: 0,
                iconTheme: IconThemeData(
                  color: isComic ? C.contrastTextOn(C.bgDark) : C.accent,
                ),
                title: Text(
                  'INFO & KEBIJAKAN',
                  style: TextStyle(
                    color: isComic ? C.comicText : C.text,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.bold,
                    fontSize: isComic ? 20 : 16,
                    letterSpacing: isComic ? 2 : 1.5,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.comicTextOutline,
                              offset: const Offset(2, 2),
                              blurRadius: 0,
                            ),
                          ]
                        : null,
                  ),
                ),
                flexibleSpace: Container(
                  decoration: BoxDecoration(
                    color: isComic ? C.bgDark : null,
                    gradient: isComic
                        ? null
                        : LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [C.bg, C.bgDark, C.bgDeep],
                          ),
                    border: Border(
                      bottom: BorderSide(
                        color: isComic ? Colors.black : C.primaryLo,
                        width: isComic ? 4 : 1.5,
                      ),
                    ),
                  ),
                ),
              ),
              body: SafeArea(
                child: CustomScrollView(
                  physics: const BouncingScrollPhysics(),
                  slivers: [
                    SliverPadding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 20),
                      sliver: SliverList(
                        delegate: SliverChildListDelegate([
                          // Status Server
                          _buildStatusHeader(C, isComic),

                          // Tentang SYAX
                          _buildTentangSection(C, isComic),
                          const SizedBox(height: 28),

                          // Fitur-fitur Utama
                          _buildSectionHeader(
                            C,
                            isComic,
                            "Fitur-fitur Utama",
                            Icons.rocket_launch_rounded,
                          ),
                          const SizedBox(height: 14),
                          ...featuresList
                              .map((f) => _buildFeatureCard(C, isComic, f))
                              .toList(),
                          const SizedBox(height: 28),

                          // Kebijakan Pengguna
                          _buildSectionHeader(
                            C,
                            isComic,
                            "Kebijakan Pengguna",
                            Icons.shield_outlined,
                          ),
                          const SizedBox(height: 14),
                          ...rulesList
                              .asMap()
                              .entries
                              .map((e) => _buildRuleCard(
                                  C, isComic, e.key, e.value))
                              .toList(),

                          // Penalty
                          _buildPenaltyBox(C, isComic),

                          // Footer
                          Center(
                            child: Column(
                              children: [
                                Icon(
                                  Icons.shield_moon_rounded,
                                  color: (isComic ? C.comicText : C.textSub)
                                      .withOpacity(0.5),
                                  size: 28,
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  "Peraturan ini dibuat semata-mata untuk menjaga keamanan, kenyamanan, dan kestabilan ekosistem server SYAX. Dengan mengakses aplikasi, Anda secara otomatis menyetujui seluruh protokol di atas.",
                                  style: TextStyle(
                                    color: (isComic ? C.comicText : C.textSub)
                                        .withOpacity(0.5),
                                    fontSize: 11,
                                    fontStyle: FontStyle.italic,
                                    fontFamily: isComic
                                        ? 'ComicNeue'
                                        : 'ShareTechMono',
                                    height: 1.55,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                                const SizedBox(height: 16),
                                Container(
                                  height: 3,
                                  width: 40,
                                  decoration: BoxDecoration(
                                    color: (isComic ? C.comicText : C.textSub)
                                        .withOpacity(0.5),
                                    borderRadius: BorderRadius.circular(2),
                                  ),
                                ),
                                const SizedBox(height: 100),
                              ],
                            ),
                          ),
                        ]),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}