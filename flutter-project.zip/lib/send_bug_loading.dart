// lib/send_bug_loading.dart
import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_theme.dart';

/// Overlay dialog countdown 5 detik pas send bug
class SendBugLoading extends StatefulWidget {
  final int countdownSeconds;
  final String targetLabel;
  final Future<bool> Function() onProcess;
  final VoidCallback? onComplete;

  const SendBugLoading({
    super.key,
    this.countdownSeconds = 5,
    required this.targetLabel,
    required this.onProcess,
    this.onComplete,
  });

  static Future<bool> show(
    BuildContext context, {
    required String targetLabel,
    required Future<bool> Function() onProcess,
    int countdownSeconds = 5,
  }) async {
    bool success = false;
    await showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.9),
      useRootNavigator: true,
      builder: (_) => SendBugLoading(
        countdownSeconds: countdownSeconds,
        targetLabel: targetLabel,
        onProcess: onProcess,
        onComplete: () {
          Navigator.of(context, rootNavigator: true).pop();
        },
      ),
    ).then((_) {
      success = true;
    });
    return success;
  }

  @override
  State<SendBugLoading> createState() => _SendBugLoadingState();
}

class _SendBugLoadingState extends State<SendBugLoading>
    with TickerProviderStateMixin {
  late AnimationController _rotateCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _ringCtrl;

  int _countdown = 0;
  Timer? _timer;
  bool _isProcessing = false;
  bool _isDone = false;
  bool _isSuccess = false;

  @override
  void initState() {
    super.initState();
    _countdown = widget.countdownSeconds;

    _rotateCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    )..repeat(reverse: true);

    _ringCtrl = AnimationController(
      vsync: this,
      duration: Duration(seconds: widget.countdownSeconds),
    )..forward();

    _startCountdown();
  }

  void _startCountdown() {
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (_countdown > 1) {
        setState(() => _countdown--);
        HapticFeedback.selectionClick();
      } else {
        t.cancel();
        setState(() => _countdown = 0);
        _runProcess();
      }
    });
  }

  Future<void> _runProcess() async {
    if (_isProcessing) return;
    setState(() => _isProcessing = true);
    HapticFeedback.mediumImpact();

    try {
      final result = await widget.onProcess();
      if (!mounted) return;
      setState(() {
        _isSuccess = result;
        _isDone = true;
      });

      if (result) {
        HapticFeedback.heavyImpact();
      } else {
        HapticFeedback.vibrate();
      }

      await Future.delayed(const Duration(milliseconds: 1400));

      if (!mounted) return;
      widget.onComplete?.call();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isSuccess = false;
        _isDone = true;
      });
      await Future.delayed(const Duration(milliseconds: 1400));
      if (!mounted) return;
      widget.onComplete?.call();
    }
  }

  @override
  void dispose() {
    _rotateCtrl.dispose();
    _pulseCtrl.dispose();
    _ringCtrl.dispose();
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return PopScope(
              canPop: false,
              child: Dialog(
                backgroundColor: Colors.transparent,
                insetPadding:
                    const EdgeInsets.symmetric(horizontal: 30, vertical: 40),
                child: Container(
                  padding: const EdgeInsets.all(28),
                  decoration: isComic
                      ? BoxDecoration(
                          color: C.bgDark,
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(color: Colors.black, width: 4),
                          boxShadow: const [
                            BoxShadow(
                              color: Colors.black,
                              offset: Offset(8, 8),
                              blurRadius: 0,
                            ),
                          ],
                        )
                      : BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [C.bg, C.bgDark, C.bgDeep],
                          ),
                          border: Border.all(color: C.accent, width: 2),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.9),
                              offset: const Offset(0, 10),
                              blurRadius: 20,
                            ),
                            BoxShadow(
                              color: C.accent.withOpacity(0.4),
                              blurRadius: 30,
                              spreadRadius: 2,
                            ),
                          ],
                        ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _buildHeader(C, isComic),
                      const SizedBox(height: 24),
                      _buildCountdownRing(C, isComic),
                      const SizedBox(height: 24),
                      _buildTargetInfo(C, isComic),
                      const SizedBox(height: 20),
                      _buildStatusText(C, isComic),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildHeader(AppPalette C, bool isComic) {
    final color = _isDone
        ? (_isSuccess ? C.primaryHi : C.primaryHi)
        : (isComic ? Colors.black : C.accent);

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _PulseLed2(
            color: _isDone
                ? (_isSuccess ? C.primaryHi : C.primaryHi)
                : C.accent,
            isComic: isComic),
        const SizedBox(width: 10),
        Text(
          _isDone
              ? (_isSuccess ? 'SEND BERHASIL' : 'SEND GAGAL')
              : 'MENGIRIM BUG...',
          style: TextStyle(
            color: color,
            fontSize: isComic ? 18 : 13,
            fontWeight: FontWeight.w900,
            fontFamily: isComic ? 'Bangers' : 'Orbitron',
            letterSpacing: isComic ? 2 : 2.5,
            shadows: isComic
                ? const [
                    Shadow(
                      color: Colors.black,
                      offset: Offset(2, 2),
                      blurRadius: 0,
                    ),
                  ]
                : [
                    Shadow(
                      color: (_isDone
                              ? (_isSuccess ? C.primaryHi : C.primaryHi)
                              : C.accent)
                          .withOpacity(0.6),
                      blurRadius: 12,
                    ),
                    const Shadow(
                      color: Colors.black,
                      offset: Offset(0, 1),
                      blurRadius: 2,
                    ),
                  ],
          ),
        ),
        const SizedBox(width: 10),
        _PulseLed2(
            color: _isDone
                ? (_isSuccess ? C.primaryHi : C.primaryHi)
                : C.accent,
            isComic: isComic),
      ],
    );
  }

  Widget _buildCountdownRing(AppPalette C, bool isComic) {
    return SizedBox(
      width: 160,
      height: 160,
      child: Stack(
        alignment: Alignment.center,
        children: [
          if (!isComic)
            AnimatedBuilder(
              animation: _rotateCtrl,
              builder: (_, __) => Transform.rotate(
                angle: _rotateCtrl.value * 2 * math.pi,
                child: CustomPaint(
                  size: const Size(160, 160),
                  painter: _DashedRingPainter(color: C.accent),
                ),
              ),
            ),
          AnimatedBuilder(
            animation: _ringCtrl,
            builder: (_, __) => SizedBox(
              width: 140,
              height: 140,
              child: CircularProgressIndicator(
                value: _isDone ? 1.0 : (1 - _ringCtrl.value),
                strokeWidth: isComic ? 6 : 5,
                backgroundColor: isComic ? Colors.white : C.bgDeep,
                valueColor: AlwaysStoppedAnimation(
                  _isDone
                      ? (_isSuccess ? C.primaryHi : C.primaryHi)
                      : (isComic ? C.primaryHi : C.accent),
                ),
              ),
            ),
          ),
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) {
              final scale = 0.95 + _pulseCtrl.value * 0.08;
              final glowColor = _isDone
                  ? (_isSuccess ? C.primaryHi : C.primaryHi)
                  : (isComic ? C.primaryHi : C.accent);

              return Transform.scale(
                scale: _isDone ? 1.0 : scale,
                child: Container(
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: isComic
                        ? null
                        : RadialGradient(
                            center: const Alignment(-0.3, -0.3),
                            colors: [C.bg, C.bgDark, C.bgDeep],
                          ),
                    color: isComic ? glowColor : null,
                    border: Border.all(
                      color: isComic ? Colors.black : glowColor,
                      width: isComic ? 4 : 2.5,
                    ),
                    boxShadow: isComic
                        ? null
                        : [
                            BoxShadow(
                              color: glowColor.withOpacity(0.6),
                              blurRadius: 20,
                              spreadRadius: 2,
                            ),
                          ],
                  ),
                  child: Center(
                    child: _isDone
                        ? Icon(
                            _isSuccess
                                ? Icons.check_circle_rounded
                                : Icons.cancel_rounded,
                            color: Colors.white,
                            size: 50,
                            shadows: isComic
                                ? const [
                                    Shadow(
                                      color: Colors.black,
                                      offset: Offset(2, 2),
                                      blurRadius: 0,
                                    ),
                                  ]
                                : [
                                    Shadow(
                                      color: (_isSuccess
                                              ? C.primaryHi
                                              : C.primaryHi)
                                          .withOpacity(0.8),
                                      blurRadius: 15,
                                    ),
                                  ],
                          )
                        : Text(
                            '$_countdown',
                            style: TextStyle(
                              color: isComic ? Colors.white : C.accent,
                              fontSize: isComic ? 60 : 56,
                              fontWeight: FontWeight.w900,
                              fontFamily:
                                  isComic ? 'Bangers' : 'Orbitron',
                              height: 1,
                              shadows: isComic
                                  ? const [
                                      Shadow(
                                        color: Colors.black,
                                        offset: Offset(3, 3),
                                        blurRadius: 0,
                                      ),
                                    ]
                                  : [
                                      Shadow(
                                        color:
                                            C.accent.withOpacity(0.9),
                                        blurRadius: 20,
                                      ),
                                      const Shadow(
                                        color: Colors.black,
                                        offset: Offset(0, 2),
                                        blurRadius: 4,
                                      ),
                                    ],
                            ),
                          ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildTargetInfo(AppPalette C, bool isComic) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(isComic ? 12 : 8),
        color: isComic ? Colors.white : Colors.black.withOpacity(0.4),
        border: Border.all(
          color: isComic ? Colors.black : C.accent.withOpacity(0.4),
          width: isComic ? 3 : 1,
        ),
      ),
      child: Column(
        children: [
          Text(
            'TARGET',
            style: TextStyle(
              color: isComic
                  ? Colors.black.withOpacity(0.6)
                  : C.text.withOpacity(0.5),
              fontSize: isComic ? 12 : 8,
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              letterSpacing: 2,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            widget.targetLabel,
            style: TextStyle(
              color: isComic ? Colors.black : C.text,
              fontSize: isComic ? 14 : 12,
              fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  Widget _buildStatusText(AppPalette C, bool isComic) {
    String text;
    Color color;

    if (_isDone) {
      if (_isSuccess) {
        text = 'Bug berhasil dikirim!';
        color = isComic ? Colors.black : C.primaryHi;
      } else {
        text = 'Gagal mengirim bug';
        color = isComic ? Colors.black : C.primaryHi;
      }
    } else if (_isProcessing) {
      text = 'Mengirim ke server...';
      color = isComic ? Colors.black : C.accent;
    } else {
      text = 'Menunggu countdown...';
      color = isComic
          ? Colors.black.withOpacity(0.6)
          : C.text.withOpacity(0.6);
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (!_isDone)
          SizedBox(
            width: 12,
            height: 12,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              color: color,
            ),
          ),
        if (!_isDone) const SizedBox(width: 10),
        Flexible(
          child: Text(
            text,
            style: TextStyle(
              color: color,
              fontSize: isComic ? 13 : 10,
              fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════
// DASHED RING PAINTER
// ═══════════════════════════════════════════════════════════
class _DashedRingPainter extends CustomPainter {
  final Color color;
  _DashedRingPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(0.5)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 2;
    const segments = 24;
    const gap = 0.6;

    for (int i = 0; i < segments; i++) {
      final startAngle = (i / segments) * 2 * math.pi;
      final sweep = (1 / segments) * 2 * math.pi - gap / segments;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweep,
        false,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_DashedRingPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// PULSE LED
// ═══════════════════════════════════════════════════════════
class _PulseLed2 extends StatefulWidget {
  final Color color;
  final double size;
  final bool isComic;
  const _PulseLed2({required this.color, this.size = 8, this.isComic = false});

  @override
  State<_PulseLed2> createState() => _PulseLed2State();
}

class _PulseLed2State extends State<_PulseLed2>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.isComic) {
      return Container(
        width: widget.size,
        height: widget.size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: widget.color,
          border: Border.all(
              color: Colors.black, width: widget.size * 0.18),
        ),
      );
    }
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final o = 0.4 + _c.value * 0.6;
        return Container(
          width: widget.size,
          height: widget.size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(
              center: const Alignment(-0.35, -0.35),
              colors: [
                Colors.white.withOpacity(o),
                widget.color.withOpacity(o),
                widget.color.withOpacity(0.5 * o),
              ],
              stops: const [0.0, 0.4, 1.0],
            ),
            boxShadow: [
              BoxShadow(
                color: widget.color.withOpacity(0.8 * o),
                blurRadius: widget.size * 1.5,
                spreadRadius: widget.size * 0.3,
              ),
            ],
          ),
        );
      },
    );
  }
}