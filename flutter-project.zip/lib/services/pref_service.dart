
import 'package:shared_preferences/shared_preferences.dart';
class PrefService {
  Future<double> getBalance() async {
    final p = await SharedPreferences.getInstance();
    return p.getDouble('balance') ?? 5000000;
  }
  Future<void> setBalance(double v) async {
    final p = await SharedPreferences.getInstance();
    await p.setDouble('balance', v);
  }
}
