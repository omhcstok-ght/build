
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
class DBService {
  static Database? _db;
  Future<Database> get db async {
    if (_db != null) return _db!;
    String path = join(await getDatabasesPath(), 'dompetku.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, v) async {
      await db.execute('CREATE TABLE transactions(id TEXT PRIMARY KEY, title TEXT, category TEXT, amount REAL, type TEXT, date TEXT, note TEXT, walletId TEXT)');
    });
    return _db!;
  }
  Future<List<Map<String,dynamic>>> getAll() async {
    final d = await db;
    return d.query('transactions', orderBy: 'date DESC');
  }
  Future<void> insert(Map<String,dynamic> m) async {
    final d = await db;
    await d.insert('transactions', m, conflictAlgorithm: ConflictAlgorithm.replace);
  }
  Future<void> delete(String id) async {
    final d = await db;
    await d.delete('transactions', where: 'id = ?', whereArgs: [id]);
  }
}
