import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../ws_client.dart';
import 'device_page.dart';

class DevicesPage extends StatefulWidget {
  const DevicesPage({super.key});
  @override
  State<DevicesPage> createState() => _DevicesPageState();
}

class _DevicesPageState extends State<DevicesPage> {
  Map<String, Map<String, dynamic>> agents = {};

  @override
  void initState() {
    super.initState();
    final ws = context.read<WsClient>();
    ws.stream.listen((ev) {
      switch (ev['type']) {
        case 'agent_list':
          agents = {for (var id in ev['agents']) id: {}};
          setState(() {});
          break;
        case 'agent_online':
          agents[ev['id']] = ev['info'] ?? {};
          setState(() {});
          break;
        case 'agent_offline':
          agents.remove(ev['id']);
          setState(() {});
          break;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Devices',
            style: TextStyle(fontWeight: FontWeight.w700, letterSpacing: -.5)),
        backgroundColor: Colors.transparent,
      ),
      body: agents.isEmpty
          ? const Center(child: Text('No agents connected',
              style: TextStyle(color: Colors.white38)))
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: agents.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (_, i) {
                final id = agents.keys.elementAt(i);
                final info = agents[id]!;
                return _AgentCard(
                  id: id,
                  model: info['model'] ?? 'unknown',
                  sdk: info['sdk'] ?? '?',
                  onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => DevicePage(agentId: id))),
                );
              },
            ),
    );
  }
}

class _AgentCard extends StatelessWidget {
  final String id, model, sdk;
  final VoidCallback onTap;
  const _AgentCard({required this.id, required this.model,
                    required this.sdk, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFF131A21),
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                    colors: [Color(0xFF00E5A0), Color(0xFF00A8E8)]),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.smartphone, color: Colors.black87),
            ),
            const SizedBox(width: 14),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(model, style: const TextStyle(
                    fontSize: 16, fontWeight: FontWeight.w600)),
                const SizedBox(height: 2),
                Text('$id  ·  SDK $sdk',
                    style: const TextStyle(fontSize: 12, color: Colors.white38)),
              ],
            )),
            const Icon(Icons.chevron_right, color: Colors.white24),
          ]),
        ),
      ),
    );
  }
}