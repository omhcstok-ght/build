// lib/music_downloader_page.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'app_theme.dart';
import 'api_config.dart';

class MusicDownloaderPage extends StatefulWidget {
  const MusicDownloaderPage({super.key});

  @override
  State<MusicDownloaderPage> createState() => _MusicDownloaderPageState();
}

class _MusicDownloaderPageState extends State<MusicDownloaderPage> {
  final TextEditingController _urlCtrl = TextEditingController();
  bool _isLoading = false;
  bool _isDownloading = false;
  Map<String, dynamic>? _result;
  String? _errorMsg;

  @override
  void dispose() {
    _urlCtrl.dispose();
    super.dispose();
  }

  Future<void> _download() async {
    final url = _urlCtrl.text.trim();
    if (url.isEmpty) {
      _toast('URL kosong bro');
      return;
    }

    final isTikTok = url.contains('tiktok.com');
    final isYouTube = url.contains('youtube.com') || url.contains('youtu.be');

    if (!isTikTok && !isYouTube) {
      setState(() => _errorMsg = 'URL harus dari TikTok atau YouTube');
      _toast('URL harus dari TikTok atau YouTube');
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMsg = null;
      _result = null;
    });

    try {
      final res = await http.get(
        Uri.parse('$baseUrl/music/download?url=${Uri.encodeComponent(url)}'),
      ).timeout(const Duration(seconds: 90));

      if (res.statusCode != 200) {
        setState(() => _errorMsg = 'Server error ${res.statusCode}');
        return;
      }

      final data = jsonDecode(res.body);
      if (data['valid'] != true) {
        setState(() => _errorMsg = data['message'] ?? 'Gagal download');
        return;
      }

      setState(() {
        _result = data;
      });
      _toast('Berhasil! 🎵');
    } catch (e) {
      setState(() => _errorMsg = 'Error: $e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _saveAndShare() async {
    if (_result == null) return;
    setState(() => _isDownloading = true);

    try {
      final url = _result!['url'] as String;
      final res = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 60));

      if (res.statusCode != 200) {
        _toast('Gagal download file: ${res.statusCode}');
        return;
      }

      final tempDir = await getTemporaryDirectory();
      final filename = 'music_${DateTime.now().millisecondsSinceEpoch}.mp3';
      final file = File('${tempDir.path}/$filename');
      await file.writeAsBytes(res.bodyBytes);

      await Share.shareXFiles([XFile(file.path)], text: 'Music dari Crylix 🎵');
      _toast('Berhasil di-share!');
    } catch (e) {
      _toast('Error: $e');
    } finally {
      if (mounted) setState(() => _isDownloading = false);
    }
  }

  void _pasteFromClipboard() async {
    final data = await Clipboard.getData('text/plain');
    if (data != null && data.text != null && data.text!.isNotEmpty) {
      setState(() {
        _urlCtrl.text = data.text!.trim();
      });
      HapticFeedback.lightImpact();
    }
  }

  void _clear() {
    setState(() {
      _urlCtrl.clear();
      _result = null;
      _errorMsg = null;
    });
  }

  void _toast(String msg) {
    Fluttertoast.showToast(
      msg: msg,
      backgroundColor: Colors.black87,
      textColor: Colors.white,
      fontSize: 13,
      toastLength: Toast.LENGTH_SHORT,
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bgDeep,
              appBar: AppBar(
                backgroundColor: C.bgDark,
                elevation: 0,
                iconTheme: IconThemeData(color: C.accent),
                title: Text(
                  'MUSIC DOWNLOADER',
                  style: TextStyle(
                    color: isComic ? C.comicText : C.accentHi,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: isComic ? 20 : 15,
                    letterSpacing: isComic ? 2 : 3,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.comicTextOutline,
                              offset: const Offset(2, 2),
                              blurRadius: 0,
                            ),
                          ]
                        : null,
                  ),
                ),
                actions: [
                  if (_urlCtrl.text.isNotEmpty || _result != null)
                    IconButton(
                      icon: Icon(Icons.refresh_rounded, color: C.accent),
                      onPressed: _clear,
                      tooltip: 'Reset',
                    ),
                ],
              ),
              body: Container(
                decoration: BoxDecoration(
                  gradient: isComic
                      ? null
                      : LinearGradient(
                          colors: [C.bg, C.bgDark, C.bgDeep],
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                        ),
                  color: isComic ? C.bg : null,
                ),
                child: SafeArea(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        _buildInputCard(C, isComic),
                        const SizedBox(height: 16),
                        if (_errorMsg != null) _buildErrorCard(C, isComic),
                        if (_errorMsg != null) const SizedBox(height: 16),
                        if (_result != null) _buildResultCard(C, isComic),
                        if (_result != null) const SizedBox(height: 16),
                        _buildInfoCard(C, isComic),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // INPUT CARD
  // ═══════════════════════════════════════════════════════════
  Widget _buildInputCard(AppPalette C, bool isComic) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isComic ? C.bgDark : null,
        gradient: isComic ? null : LinearGradient(colors: [C.bg, C.bgDark]),
        borderRadius: BorderRadius.circular(isComic ? 20 : 16),
        border: Border.all(
          color: isComic ? Colors.black : C.accent.withOpacity(0.5),
          width: isComic ? 4 : 1.5,
        ),
        boxShadow: isComic
            ? const [
                BoxShadow(color: Colors.black, offset: Offset(5, 5), blurRadius: 0),
              ]
            : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.music_note_rounded, color: C.accent, size: 20),
              const SizedBox(width: 8),
              Text(
                'PASTE URL TIKTOK / YOUTUBE',
                style: TextStyle(
                  color: isComic ? C.comicText : C.accent,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  fontWeight: FontWeight.w900,
                  fontSize: isComic ? 14 : 11,
                  letterSpacing: isComic ? 1.5 : 2,
                  shadows: isComic
                      ? [
                          Shadow(
                            color: C.comicTextOutline,
                            offset: const Offset(1, 1),
                            blurRadius: 0,
                          ),
                        ]
                      : null,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            decoration: BoxDecoration(
              color: C.bgDeep,
              borderRadius: BorderRadius.circular(isComic ? 12 : 10),
              border: Border.all(
                color: isComic ? Colors.black : C.accent.withOpacity(0.5),
                width: isComic ? 3 : 1.5,
              ),
            ),
            child: TextField(
              controller: _urlCtrl,
              maxLines: 3,
              minLines: 1,
              style: TextStyle(
                color: isComic ? C.comicText : C.text,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                fontSize: 13,
              ),
              cursorColor: C.accent,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: 'https://vt.tiktok.com/... atau https://youtu.be/...',
                hintStyle: TextStyle(
                  color: isComic ? C.comicTextMuted : C.textSub.withOpacity(0.5),
                  fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                  fontSize: 11,
                ),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.all(14),
                prefixIcon: Icon(Icons.link, color: C.accent, size: 18),
                suffixIcon: GestureDetector(
                  onTap: _pasteFromClipboard,
                  child: Container(
                    margin: const EdgeInsets.all(8),
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    decoration: BoxDecoration(
                      color: C.accent.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: C.accent.withOpacity(0.4)),
                    ),
                    child: Center(
                      widthFactor: 1,
                      child: Text(
                        'PASTE',
                        style: TextStyle(
                          color: isComic ? C.comicText : C.accent,
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          fontFamily: isComic ? 'Bangers' : 'Orbitron',
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          GestureDetector(
            onTap: _isLoading ? null : _download,
            child: Container(
              height: 52,
              decoration: BoxDecoration(
                color: isComic ? C.primaryHi : null,
                gradient: isComic
                    ? null
                    : LinearGradient(colors: [C.primaryHi, C.primaryLo]),
                borderRadius: BorderRadius.circular(isComic ? 12 : 14),
                border: Border.all(
                  color: isComic ? Colors.black : C.primaryHi,
                  width: isComic ? 3.5 : 1.5,
                ),
                boxShadow: isComic
                    ? const [
                        BoxShadow(color: Colors.black, offset: Offset(4, 4), blurRadius: 0),
                      ]
                    : [BoxShadow(color: C.primaryHi.withOpacity(0.4), blurRadius: 15)],
              ),
              child: Center(
                child: _isLoading
                    ? SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(
                          color: isComic ? C.contrastTextOn(C.primaryHi) : Colors.white,
                          strokeWidth: 2.5,
                        ),
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.download_rounded,
                              color: isComic ? C.contrastTextOn(C.primaryHi) : Colors.white,
                              size: 20),
                          const SizedBox(width: 8),
                          Text(
                            'DOWNLOAD MP3',
                            style: TextStyle(
                              color: isComic ? C.contrastTextOn(C.primaryHi) : Colors.white,
                              fontFamily: isComic ? 'Bangers' : 'Orbitron',
                              fontWeight: FontWeight.w900,
                              fontSize: isComic ? 15 : 13,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // ERROR CARD
  // ═══════════════════════════════════════════════════════════
  Widget _buildErrorCard(AppPalette C, bool isComic) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isComic ? C.bgDark : C.primaryLo.withOpacity(0.15),
        borderRadius: BorderRadius.circular(isComic ? 14 : 12),
        border: Border.all(
          color: C.primaryHi,
          width: isComic ? 3 : 1.5,
        ),
      ),
      child: Row(
        children: [
          Icon(Icons.error_outline, color: C.primaryHi, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _errorMsg!,
              style: TextStyle(
                color: isComic ? C.comicText : C.text,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // RESULT CARD
  // ═══════════════════════════════════════════════════════════
  Widget _buildResultCard(AppPalette C, bool isComic) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isComic ? C.bgDark : null,
        gradient: isComic ? null : LinearGradient(colors: [C.bg, C.bgDark]),
        borderRadius: BorderRadius.circular(isComic ? 20 : 16),
        border: Border.all(color: C.accent, width: isComic ? 4 : 1.5),
        boxShadow: isComic
            ? const [
                BoxShadow(color: Colors.black, offset: Offset(5, 5), blurRadius: 0),
              ]
            : [BoxShadow(color: C.accent.withOpacity(0.3), blurRadius: 20)],
      ),
      child: Column(
        children: [
          Icon(Icons.check_circle_rounded, color: C.accent, size: 48),
          const SizedBox(height: 10),
          Text(
            'MUSIC READY! 🎵',
            style: TextStyle(
              color: isComic ? C.comicText : C.accent,
              fontFamily: isComic ? 'Bangers' : 'Orbitron',
              fontWeight: FontWeight.w900,
              fontSize: isComic ? 18 : 14,
              letterSpacing: 2,
              shadows: isComic
                  ? [
                      Shadow(
                        color: C.comicTextOutline,
                        offset: const Offset(1, 1),
                        blurRadius: 0,
                      ),
                    ]
                  : null,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Size: ${_result!['sizeKB']} KB',
            style: TextStyle(
              color: isComic ? C.comicTextSub : C.textSub,
              fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
              fontSize: 11,
            ),
          ),
          const SizedBox(height: 16),
          GestureDetector(
            onTap: _isDownloading ? null : _saveAndShare,
            child: Container(
              height: 50,
              decoration: BoxDecoration(
                color: isComic ? C.primaryHi : null,
                gradient: isComic
                    ? null
                    : LinearGradient(colors: [C.primaryHi, C.primaryLo]),
                borderRadius: BorderRadius.circular(isComic ? 12 : 14),
                border: Border.all(
                  color: isComic ? Colors.black : C.primaryHi,
                  width: isComic ? 3.5 : 1.5,
                ),
              ),
              child: Center(
                child: _isDownloading
                    ? SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          color: isComic ? C.contrastTextOn(C.primaryHi) : Colors.white,
                          strokeWidth: 2.5,
                        ),
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.save_alt_rounded,
                              color: isComic ? C.contrastTextOn(C.primaryHi) : Colors.white,
                              size: 20),
                          const SizedBox(width: 8),
                          Text(
                            'SIMPAN / SHARE',
                            style: TextStyle(
                              color: isComic ? C.contrastTextOn(C.primaryHi) : Colors.white,
                              fontFamily: isComic ? 'Bangers' : 'Orbitron',
                              fontWeight: FontWeight.w900,
                              fontSize: isComic ? 14 : 12,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // INFO CARD
  // ═══════════════════════════════════════════════════════════
  Widget _buildInfoCard(AppPalette C, bool isComic) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isComic ? C.bgDark : C.bgDark.withOpacity(0.5),
        borderRadius: BorderRadius.circular(isComic ? 14 : 12),
        border: Border.all(
          color: isComic ? Colors.black : C.textSub.withOpacity(0.4),
          width: isComic ? 3 : 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.info_outline, color: C.accent, size: 18),
              const SizedBox(width: 8),
              Text(
                'PANDUAN',
                style: TextStyle(
                  color: isComic ? C.comicText : C.accent,
                  fontFamily: isComic ? 'Bangers' : 'Orbitron',
                  fontWeight: FontWeight.w900,
                  fontSize: isComic ? 13 : 11,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _buildBullet(C, isComic, 'Paste URL video TikTok atau YouTube'),
          _buildBullet(C, isComic, 'Klik DOWNLOAD MP3, tunggu proses (30-90 detik)'),
          _buildBullet(C, isComic, 'Klik SIMPAN / SHARE buat simpen ke galeri atau share'),
          _buildBullet(C, isComic, 'File MP3 auto-hapus dari server dalam 10 menit'),
        ],
      ),
    );
  }

  Widget _buildBullet(AppPalette C, bool isComic, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Container(
              width: 4,
              height: 4,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: C.accent,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: isComic ? C.comicTextSub : C.textSub,
                fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                fontSize: 11,
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}