// lib/wifi_external.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'app_theme.dart';

class WifiInternalPage extends StatefulWidget {
  final String sessionKey;
  const WifiInternalPage({super.key, required this.sessionKey});

  @override
  State<WifiInternalPage> createState() => _WifiInternalPageState();
}

class _WifiInternalPageState extends State<WifiInternalPage> {
  String publicIp = "-";
  String region = "-";
  String asn = "-";
  bool isVpn = false;
  bool isLoading = true;
  bool isAttacking = false;

  @override
  void initState() {
    super.initState();
    _loadPublicInfo();
  }

  Future<void> _loadPublicInfo() async {
    setState(() => isLoading = true);

    try {
      final ipRes =
          await http.get(Uri.parse("https://api.ipify.org?format=json"));
      final ipJson = jsonDecode(ipRes.body);
      final ip = ipJson['ip'];

      final infoRes = await http.get(Uri.parse(
          "http://ip-api.com/json/$ip?fields=as,regionName,status,query"));
      final info = jsonDecode(infoRes.body);

      final asnRaw = (info['as'] as String).toLowerCase();
      final isBlockedAsn = asnRaw.contains("vpn") ||
          asnRaw.contains("cloud") ||
          asnRaw.contains("digitalocean") ||
          asnRaw.contains("aws") ||
          asnRaw.contains("google");

      if (!mounted) return;
      setState(() {
        publicIp = ip;
        region = info['regionName'] ?? "-";
        asn = info['as'] ?? "-";
        isVpn = isBlockedAsn;
        isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        publicIp = region = asn = "Error";
        isLoading = false;
      });
    }
  }

  Future<void> _attackTarget(AppPalette C) async {
    setState(() => isAttacking = true);
    final url = Uri.parse(
        "https://evo.nullxteam.fun/killWifi?key=${widget.sessionKey}&target=$publicIp&duration=120");
    try {
      final res = await http.get(url);
      if (res.statusCode == 200) {
        _showAlert("✅ Attack Sent", "WiFi attack sent to $publicIp", C);
      } else {
        _showAlert("❌ Failed", "Server rejected request.", C);
      }
    } catch (e) {
      _showAlert("Error", "Network error: $e", C);
    } finally {
      setState(() => isAttacking = false);
    }
  }

  void _showAlert(String title, String message, AppPalette C) {
    final isComic = AppTheme.currentStyle.value == ThemeStyle.comic3d;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: C.bgDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(isComic ? 20 : 16),
          side: BorderSide(
            color: isComic ? Colors.black : C.accent,
            width: isComic ? 3.5 : 1.5,
          ),
        ),
        title: Text(
          title,
          style: TextStyle(
            color: isComic ? C.comicText : C.accent,
            fontFamily: isComic ? 'Bangers' : 'Orbitron',
            fontWeight: FontWeight.w900,
            fontSize: isComic ? 18 : 15,
          ),
        ),
        content: Text(
          message,
          style: TextStyle(
            color: isComic ? C.comicTextSub : C.textSub,
            fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
            fontSize: 12,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "OK",
              style: TextStyle(
                color: C.accent,
                fontFamily: isComic ? 'Bangers' : 'Orbitron',
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoCard(
      AppPalette C, bool isComic, String title, String value, IconData icon) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isComic ? C.bgDark : null,
        gradient: isComic
            ? null
            : LinearGradient(
                colors: [C.bg, C.bgDark, C.bgDeep],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
        borderRadius: BorderRadius.circular(isComic ? 16 : 12),
        border: Border.all(
          color: isComic ? Colors.black : C.accent.withOpacity(0.4),
          width: isComic ? 3.5 : 1.5,
        ),
        boxShadow: isComic
            ? const [
                BoxShadow(
                    color: Colors.black, offset: Offset(4, 4), blurRadius: 0),
              ]
            : [
                BoxShadow(
                  color: C.accent.withOpacity(0.15),
                  blurRadius: 15,
                ),
              ],
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: isComic ? BoxShape.rectangle : BoxShape.circle,
              borderRadius: isComic ? BorderRadius.circular(8) : null,
              color: C.accent,
              border: Border.all(
                color: isComic ? Colors.black : C.accentHi,
                width: isComic ? 2.5 : 1.2,
              ),
            ),
            child: Icon(
              icon,
              color: isComic ? C.contrastTextOn(C.accent) : Colors.white,
              size: 18,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: isComic ? C.comicTextSub : C.textSub,
                    fontWeight: FontWeight.w900,
                    fontSize: 10,
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: TextStyle(
                    color: isComic ? C.comicText : C.text,
                    fontSize: 13,
                    fontFamily: isComic ? 'ComicNeue' : 'ShareTechMono',
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppPalette>(
      valueListenable: AppTheme.current,
      builder: (context, C, _) {
        return ValueListenableBuilder<ThemeStyle>(
          valueListenable: AppTheme.currentStyle,
          builder: (context, style, __) {
            final isComic = style == ThemeStyle.comic3d;

            return Scaffold(
              backgroundColor: C.bgDeep,
              appBar: AppBar(
                backgroundColor: C.bgDark,
                elevation: 0,
                iconTheme: IconThemeData(color: C.accent),
                title: Text(
                  "📡 WiFi Killer (External)",
                  style: TextStyle(
                    fontFamily: isComic ? 'Bangers' : 'Orbitron',
                    color: isComic ? C.comicText : C.accentHi,
                    fontWeight: FontWeight.w900,
                    fontSize: isComic ? 18 : 15,
                    letterSpacing: isComic ? 1.5 : 2,
                    shadows: isComic
                        ? [
                            Shadow(
                              color: C.comicTextOutline,
                              offset: const Offset(2, 2),
                              blurRadius: 0,
                            ),
                          ]
                        : null,
                  ),
                ),
              ),
              body: Container(
                decoration: BoxDecoration(
                  gradient: isComic
                      ? null
                      : LinearGradient(
                          colors: [C.bg, C.bgDark, C.bgDeep],
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                        ),
                  color: isComic ? C.bg : null,
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: isLoading
                      ? Center(
                          child: CircularProgressIndicator(
                            color: C.accent,
                          ),
                        )
                      : SingleChildScrollView(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Text(
                                "🎯 SYSTEM INFORMATION",
                                style: TextStyle(
                                  fontSize: isComic ? 18 : 14,
                                  color: isComic ? C.comicText : C.accent,
                                  fontWeight: FontWeight.w900,
                                  fontFamily:
                                      isComic ? 'Bangers' : 'Orbitron',
                                  letterSpacing: isComic ? 1.5 : 2.5,
                                  shadows: isComic
                                      ? [
                                          Shadow(
                                            color: C.comicTextOutline,
                                            offset: const Offset(2, 2),
                                            blurRadius: 0,
                                          ),
                                        ]
                                      : null,
                                ),
                              ),
                              const SizedBox(height: 12),
                              _infoCard(C, isComic, "IP ADDRESS", publicIp,
                                  Icons.language),
                              _infoCard(C, isComic, "REGION", region,
                                  Icons.map),
                              _infoCard(C, isComic, "ASN", asn,
                                  Icons.storage),
                              const SizedBox(height: 18),
                              if (isVpn)
                                Container(
                                  padding: const EdgeInsets.all(16),
                                  decoration: BoxDecoration(
                                    color: C.primaryLo,
                                    borderRadius:
                                        BorderRadius.circular(isComic ? 14 : 12),
                                    border: Border.all(
                                      color: isComic
                                          ? Colors.black
                                          : C.primaryHi,
                                      width: isComic ? 3.5 : 1.5,
                                    ),
                                  ),
                                  child: Text(
                                    "⚠️ Target berasal dari VPN/Hosting.\nSerangan dibatalkan.",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: isComic
                                          ? C.contrastTextOn(C.primaryLo)
                                          : Colors.white,
                                      fontFamily: isComic
                                          ? 'ComicNeue'
                                          : 'ShareTechMono',
                                      fontSize: 12,
                                      fontWeight: FontWeight.w700,
                                      height: 1.5,
                                    ),
                                  ),
                                ),
                              if (!isVpn)
                                Center(
                                  child: GestureDetector(
                                    onTap: isAttacking
                                        ? null
                                        : () => _attackTarget(C),
                                    child: Opacity(
                                      opacity: isAttacking ? 0.5 : 1,
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 40, vertical: 16),
                                        decoration: BoxDecoration(
                                          color: isComic ? C.primaryHi : null,
                                          gradient: isComic
                                              ? null
                                              : LinearGradient(
                                                  colors: [
                                                    C.primaryHi,
                                                    C.primaryLo,
                                                  ],
                                                ),
                                          borderRadius:
                                              BorderRadius.circular(
                                                  isComic ? 14 : 30),
                                          border: Border.all(
                                            color: isComic
                                                ? Colors.black
                                                : C.primaryHi,
                                            width: isComic ? 3.5 : 1.5,
                                          ),
                                          boxShadow: isComic
                                              ? const [
                                                  BoxShadow(
                                                    color: Colors.black,
                                                    offset: Offset(5, 5),
                                                    blurRadius: 0,
                                                  ),
                                                ]
                                              : [
                                                  BoxShadow(
                                                    color: C.primaryHi
                                                        .withOpacity(0.5),
                                                    blurRadius: 20,
                                                  ),
                                                ],
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Icon(
                                              Icons.wifi_off,
                                              color: isComic
                                                  ? C.contrastTextOn(
                                                      C.primaryHi)
                                                  : Colors.white,
                                              size: 20,
                                            ),
                                            const SizedBox(width: 10),
                                            Text(
                                              isAttacking
                                                  ? "ATTACKING..."
                                                  : "START KILL",
                                              style: TextStyle(
                                                color: isComic
                                                    ? C.contrastTextOn(
                                                        C.primaryHi)
                                                    : Colors.white,
                                                fontFamily: isComic
                                                    ? 'Bangers'
                                                    : 'Orbitron',
                                                fontWeight: FontWeight.w900,
                                                fontSize: isComic ? 15 : 13,
                                                letterSpacing:
                                                    isComic ? 1.5 : 2,
                                                shadows: isComic
                                                    ? [
                                                        Shadow(
                                                          color: C
                                                                      .contrastTextOn(
                                                                          C
                                                                              .primaryHi) ==
                                                                  Colors.white
                                                              ? Colors.black
                                                              : Colors.white,
                                                          offset:
                                                              const Offset(
                                                                  1, 1),
                                                          blurRadius: 0,
                                                        ),
                                                      ]
                                                    : null,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                ),
              ),
            );
          },
        );
      },
    );
  }
}