// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:cached_network_image/cached_network_image.dart';

import 'vip_upgrade_page.dart';

// ── COLOR SCHEME ─────────────────────────────────────────────────────────────
class _C {
  static const bg      = Color(0xFF000000);
  static const bg2     = Color(0xFF0a0a0a);
  static const surface = Color(0xFF111111);
  static const card    = Color(0xFF111111);
  static const accent  = Color(0xFFFF3B30);
  static const accent2 = Color(0xFFFF6B6B);
  static const gold    = Color(0xFFFFB800);
  static const blue    = Color(0xFF00BFFF);
  static const text    = Color(0xFFE0E7FF);
  static const muted   = Color(0x73E0E7FF);
  static const muted2  = Color(0x38E0E7FF);
  static const border  = Color(0x1AFF3B30);
  static const border2 = Color(0x0FFFFFFF);
}

// ── API CONFIG ───────────────────────────────────────────────────────────────
class _Api {
  static const base = 'https://omhc-host-premium.yakuza.biz.id';
  static const checkVip   = '$base/meByKey';
  static const uploadQr   = '$base/qrdox/scan';
  static const lookupPhone = '$base/qrdox/lookup'; // Untuk fitur WA (opsional)
  static const processOcr  = '$base/qrdox/ocr';    // Endpoint OCR Baru
}

// ═══════════════════════════════════════════════════════════════════════════
// YAKUZA INTELEJEN PAGE
// ═══════════════════════════════════════════════════════════════════════════
class DoxQrPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const DoxQrPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<DoxQrPage> createState() => _DoxQrPageState();
}

class _DoxQrPageState extends State<DoxQrPage> with TickerProviderStateMixin {
  // ── State ──
  bool _isVip = false;
  bool _checkingRole = true;
  String _currentRole = '';

  String _searchMode = 'qr'; // 'qr', 'ocr', atau 'phone'
  final TextEditingController _phoneController = TextEditingController();

  File? _selectedImage;
  Uint8List? _selectedBytes;

  bool _isScanning = false;
  bool _isLookingUp = false;

  String _scanStage = '';
  double _scanProgress = 0.0;
  int _scanLogLine = 0;

  Map<String, dynamic>? _result;
  String? _errorMsg;

  final ImagePicker _picker = ImagePicker();

  // Animation controllers
  late AnimationController _bgPulseController;
  late AnimationController _scanLineController;
  late AnimationController _glitchController;
  late AnimationController _radarController;
  late AnimationController _matrixController;

  final List<_MatrixDrop> _drops = [];
  Timer? _matrixTimer;

  static const _logSteps = [
    '> INITIALIZING INTEL ENGINE v4.2...',
    '> LOADING NEURAL DECODER...',
    '> CONNECTING TO CENTRAL REGISTRY...',
    '> PARSING QR PAYLOAD...',
    '> EXTRACTING OWNER IDENTITY...',
    '> CROSS-REFERENCING NATIONAL RECORDS...',
    '> VERIFYING DATA INTEGRITY...',
    '> RETRIEVING DOSSIER RECORD...',
    '> DECRYPTING SECURE ATTACHMENT...',
    '> IDENTITY VERIFIED ✓',
  ];

  @override
  void initState() {
    super.initState();
    _bgPulseController = AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat(reverse: true);
    _scanLineController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1600))..repeat();
    _glitchController = AnimationController(vsync: this, duration: const Duration(milliseconds: 4000))..repeat();
    _radarController = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat();
    _matrixController = AnimationController(vsync: this, duration: const Duration(seconds: 6))..repeat();

    _initMatrix();
    _checkRole();
  }

  @override
  void dispose() {
    _bgPulseController.dispose();
    _scanLineController.dispose();
    _glitchController.dispose();
    _radarController.dispose();
    _matrixController.dispose();
    _matrixTimer?.cancel();
    _phoneController.dispose();
    super.dispose();
  }

  void _initMatrix() {
    final rand = math.Random();
    for (int i = 0; i < 18; i++) {
      _drops.add(_MatrixDrop(x: rand.nextDouble(), y: rand.nextDouble(), speed: 0.4 + rand.nextDouble() * 0.8, charCode: 0x30A0 + rand.nextInt(96)));
    }
    _matrixTimer = Timer.periodic(const Duration(milliseconds: 80), (_) {
      if (!mounted) return;
      for (final d in _drops) {
        d.y += d.speed * 0.01;
        if (d.y > 1.2) { d.y = -0.1; d.x = rand.nextDouble(); }
      }
      setState(() {});
    });
  }

  Future<void> _checkRole() async {
    setState(() { _checkingRole = true; _currentRole = widget.role; });
    try {
      final res = await http.get(Uri.parse('${_Api.checkVip}?key=${Uri.encodeComponent(widget.sessionKey)}')).timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          _currentRole = (data['role'] ?? widget.role).toString();
        } else {
          _showSnack('Sesi habis, silakan login ulang.', isError: true);
          Navigator.of(context).pop();
          return;
        }
      }
    } catch (_) {}

    final roleLower = _currentRole.toLowerCase();
    final vipRoles = ['vip', 'owner', 'founder', 'dev', 'high owner', 'high admin', 'seles', 'reseller'];
    _isVip = vipRoles.contains(roleLower);

    if (!mounted) return;
    setState(() => _checkingRole = false);

    if (!_isVip) {
      WidgetsBinding.instance.addPostFrameCallback((_) { if (mounted) _showVipGatePopup(); });
    }
  }

  void _showVipGatePopup() {
    showModalBottomSheet(
      context: context, backgroundColor: Colors.transparent, isScrollControlled: true, isDismissible: false, enableDrag: false,
      builder: (ctx) => PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, _) {
          if (!didPop) { Navigator.of(ctx).pop(); Navigator.of(context).pop(); }
        },
        child: Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 20),
            decoration: BoxDecoration(color: _C.card, borderRadius: BorderRadius.circular(24), border: Border.all(color: _C.gold.withOpacity(0.4), width: 1.5), boxShadow: [BoxShadow(color: _C.gold.withOpacity(0.18), blurRadius: 40, offset: const Offset(0, 12))]),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(width: 40, height: 3, decoration: BoxDecoration(color: _C.gold, borderRadius: BorderRadius.circular(2))),
                  const SizedBox(height: 20),
                  AnimatedBuilder(
                    animation: _bgPulseController,
                    builder: (context, _) {
                      final p = _bgPulseController.value;
                      return Container(width: 84, height: 84, decoration: BoxDecoration(shape: BoxShape.circle, color: _C.gold.withOpacity(0.08 + p * 0.06), border: Border.all(color: _C.gold.withOpacity(0.3 + p * 0.2), width: 2), boxShadow: [BoxShadow(color: _C.gold.withOpacity(0.15 + p * 0.15), blurRadius: 22 + p * 14, spreadRadius: 2)]), child: const Icon(Icons.workspace_premium_rounded, color: _C.gold, size: 40));
                    },
                  ),
                  const SizedBox(height: 20),
                  Text('FITUR KHUSUS VIP', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 18, fontWeight: FontWeight.bold, color: _C.gold, letterSpacing: 3)),
                  const SizedBox(height: 6),
                  Container(width: 40, height: 2, decoration: BoxDecoration(color: _C.gold.withOpacity(0.4), borderRadius: BorderRadius.circular(1))),
                  const SizedBox(height: 16),
                  Container(
                    width: double.infinity, padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: _C.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: _C.border2)),
                    child: Column(
                      children: [
                        Icon(Icons.security_rounded, color: _C.gold.withOpacity(0.5), size: 26),
                        const SizedBox(height: 10),
                        Text('YAKUZA INTELEJEN adalah fitur eksklusif VIP untuk verifikasi identitas. Upgrade sekarang untuk mengakses seluruh fitur premium YakuzaXsilence.', textAlign: TextAlign.center, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: _C.muted, height: 1.6)),
                        const SizedBox(height: 12),
                        Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(color: _C.gold.withOpacity(0.1), borderRadius: BorderRadius.circular(6), border: Border.all(color: _C.gold.withOpacity(0.25))), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.info_outline, color: _C.gold, size: 12), const SizedBox(width: 6), Text('Role kamu: ${_currentRole.toUpperCase()}', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _C.gold))])),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(child: GestureDetector(onTap: () { Navigator.of(ctx).pop(); Navigator.of(context).pop(); }, child: Container(padding: const EdgeInsets.symmetric(vertical: 14), decoration: BoxDecoration(color: _C.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.border2)), child: Center(child: Text('TUTUP', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.5, color: _C.muted)))))),
                      const SizedBox(width: 10),
                      Expanded(
                        flex: 2,
                        child: GestureDetector(
                          onTap: () { Navigator.of(ctx).pop(); Navigator.of(context).pop(); Navigator.of(context).push(MaterialPageRoute(builder: (_) => VipUpgradePage(username: widget.username, role: _currentRole, expiredDate: '-', sessionKey: widget.sessionKey))); },
                          child: Container(padding: const EdgeInsets.symmetric(vertical: 14), decoration: BoxDecoration(gradient: LinearGradient(colors: [_C.gold, const Color(0xFFCC8A00)]), borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: _C.gold.withOpacity(0.35), blurRadius: 16)]), child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [const Icon(Icons.workspace_premium_rounded, color: Colors.black, size: 16), const SizedBox(width: 8), Text('UPGRADE VIP', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.5, color: Colors.black))])),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final picked = await _picker.pickImage(source: source, imageQuality: 95, maxWidth: 2000);
      if (picked == null) return;
      final bytes = await picked.readAsBytes();
      setState(() { _selectedImage = File(picked.path); _selectedBytes = bytes; _result = null; _errorMsg = null; });
    } catch (e) { _showSnack('Gagal memilih gambar: $e', isError: true); }
  }

  void _showPickerSheet() {
    showModalBottomSheet(
      context: context, backgroundColor: _C.card, shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => Container(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 40, height: 4, decoration: BoxDecoration(color: _C.muted2, borderRadius: BorderRadius.circular(2))),
            const SizedBox(height: 16),
            Text('PILIH SUMBER GAMBAR', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.bold, color: _C.text, letterSpacing: 2)),
            const SizedBox(height: 20),
            _pickerOption(icon: Icons.photo_library_rounded, label: 'Galeri', onTap: () { Navigator.of(ctx).pop(); _pickImage(ImageSource.gallery); }),
            const SizedBox(height: 10),
            _pickerOption(icon: Icons.camera_alt_rounded, label: 'Kamera', onTap: () { Navigator.of(ctx).pop(); _pickImage(ImageSource.camera); }),
            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }

  Widget _pickerOption({required IconData icon, required String label, required VoidCallback onTap}) {
    return Material(color: Colors.transparent, child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(12), child: Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14), decoration: BoxDecoration(color: _C.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.border)), child: Row(children: [Container(width: 38, height: 38, decoration: BoxDecoration(color: _C.accent.withOpacity(0.12), borderRadius: BorderRadius.circular(10)), child: Icon(icon, color: _C.accent, size: 18)), const SizedBox(width: 14), Expanded(child: Text(label, style: TextStyle(color: _C.text, fontSize: 14, fontWeight: FontWeight.w600))), Icon(Icons.chevron_right, color: _C.muted, size: 20)]))));
  }

  // ── START SCAN (QR) ──
  Future<void> _startScan() async {
    if (_selectedBytes == null) { _showSnack('Pilih gambar QR terlebih dahulu', isError: true); return; }
    setState(() { _isScanning = true; _scanProgress = 0.0; _scanStage = _logSteps[0]; _scanLogLine = 0; _result = null; _errorMsg = null; });
    for (int i = 0; i < _logSteps.length; i++) {
      if (!mounted) return;
      setState(() { _scanLogLine = i; _scanStage = _logSteps[i]; _scanProgress = (i + 1) / _logSteps.length; });
      await Future.delayed(const Duration(milliseconds: 260));
    }
    try {
      final req = http.MultipartRequest('POST', Uri.parse(_Api.uploadQr));
      req.fields['key'] = widget.sessionKey;
      req.fields['username'] = widget.username;
      req.files.add(http.MultipartFile.fromBytes('qr_image', _selectedBytes!, filename: 'qr_${DateTime.now().millisecondsSinceEpoch}.jpg'));
      final streamed = await req.send().timeout(const Duration(seconds: 30));
      final res = await http.Response.fromStream(streamed);
      if (!mounted) return;
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['found'] == true) {
          setState(() { _result = data['data'] as Map<String, dynamic>?; _isScanning = false; });
          await Future.delayed(const Duration(milliseconds: 300));
          if (mounted) _showResultPopup();
        } else if (data['valid'] == false && data['reason'] == 'notVip') {
          setState(() { _isScanning = false; _errorMsg = 'Akses ditolak: akun bukan VIP.'; }); _showVipGatePopup();
        } else {
          setState(() { _isScanning = false; _errorMsg = data['message']?.toString() ?? 'Data tidak ditemukan.'; });
        }
      } else { setState(() { _isScanning = false; _errorMsg = 'Server error (${res.statusCode}). Coba lagi.'; }); }
    } catch (e) { if (!mounted) return; setState(() { _isScanning = false; _errorMsg = 'Koneksi gagal: $e'; }); }
  }

  // ── START OCR (Gambar Profil) ──
  Future<void> _startOcr() async {
    if (_selectedBytes == null) { _showSnack('Pilih gambar terlebih dahulu', isError: true); return; }
    setState(() { _isScanning = true; _result = null; _errorMsg = null; });
    
    try {
      final req = http.MultipartRequest('POST', Uri.parse(_Api.processOcr));
      req.fields['key'] = widget.sessionKey;
      req.files.add(http.MultipartFile.fromBytes('image', _selectedBytes!, filename: 'ocr_${DateTime.now().millisecondsSinceEpoch}.jpg'));
      
      final streamed = await req.send().timeout(const Duration(seconds: 60)); // Timeout lebih lama
      final res = await http.Response.fromStream(streamed);
      
      if (!mounted) return;
      final data = jsonDecode(res.body);
      
      if (res.statusCode == 200 && data['valid'] == true) {
        if (data['found'] == true) {
          setState(() { _result = data['data'] as Map<String, dynamic>?; _isScanning = false; });
          await Future.delayed(const Duration(milliseconds: 300));
          if (mounted) _showResultPopup();
        } else {
          setState(() { _isScanning = false; _errorMsg = data['message']?.toString() ?? 'Tidak ada nama/nomor terdeteksi.'; });
        }
      } else if (res.statusCode == 429 && data['limitReached'] == true) {
        setState(() { _isScanning = false; _errorMsg = data['message']?.toString() ?? 'Limit habis.'; });
        _showLimitPopup(data['message']?.toString() ?? 'Limit habis.');
      } else {
        setState(() { _isScanning = false; _errorMsg = data['message']?.toString() ?? 'Gagal memproses OCR.'; });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() { _isScanning = false; _errorMsg = 'Koneksi gagal: $e'; });
    }
  }

  void _showResultPopup() {
    if (_result == null) return;
    showDialog(context: context, barrierDismissible: true, builder: (ctx) => _IntelResultDialog(data: _result!));
  }

  void _showLimitPopup(String message) {
    showDialog(
      context: context, barrierDismissible: true,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(color: _C.card, borderRadius: BorderRadius.circular(20), border: Border.all(color: _C.gold.withOpacity(0.5), width: 1.5), boxShadow: [BoxShadow(color: _C.gold.withOpacity(0.2), blurRadius: 30)]),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(width: 64, height: 64, decoration: BoxDecoration(shape: BoxShape.circle, color: _C.gold.withOpacity(0.1), border: Border.all(color: _C.gold.withOpacity(0.4))), child: const Icon(Icons.timer_rounded, color: _C.gold, size: 32)),
              const SizedBox(height: 16),
              Text('LIMIT TERCAPAI', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 16, fontWeight: FontWeight.bold, color: _C.gold, letterSpacing: 2)),
              const SizedBox(height: 10),
              Text(message, textAlign: TextAlign.center, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: _C.muted, height: 1.5)),
              const SizedBox(height: 20),
              SizedBox(width: double.infinity, height: 44, child: ElevatedButton(onPressed: () => Navigator.of(ctx).pop(), style: ElevatedButton.styleFrom(backgroundColor: _C.gold, foregroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('MENGERTI', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1.5)))),
            ],
          ),
        ),
      ),
    );
  }

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: Colors.white)), backgroundColor: isError ? _C.accent : _C.card, behavior: SnackBarBehavior.floating, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        backgroundColor: _C.bg2, elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _C.text, size: 18), onPressed: () => Navigator.of(context).pop()),
        title: Row(
          children: [
            Container(width: 3, height: 14, decoration: BoxDecoration(color: _C.accent, borderRadius: BorderRadius.circular(2))),
            const SizedBox(width: 8),
            Text('YAKUZA INTELEJEN', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 14, fontWeight: FontWeight.bold, color: _C.text, letterSpacing: 2)),
            const SizedBox(width: 8),
            Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: _C.accent.withOpacity(0.15), borderRadius: BorderRadius.circular(4), border: Border.all(color: _C.accent.withOpacity(0.4))), child: Text('VIP', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: _C.accent, fontWeight: FontWeight.bold, letterSpacing: 1))),
          ],
        ),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(height: 1, color: _C.border)),
      ),
      body: _checkingRole ? const Center(child: CircularProgressIndicator(color: _C.accent)) : !_isVip ? _buildLockedView() : _buildMainView(),
    );
  }

  Widget _buildLockedView() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedBuilder(
              animation: _bgPulseController,
              builder: (context, _) {
                final p = _bgPulseController.value;
                return Container(width: 100, height: 100, decoration: BoxDecoration(shape: BoxShape.circle, color: _C.gold.withOpacity(0.08 + p * 0.05), border: Border.all(color: _C.gold.withOpacity(0.3 + p * 0.2), width: 2)), child: const Icon(Icons.lock_rounded, color: _C.gold, size: 40));
              },
            ),
            const SizedBox(height: 24),
            Text('AKSES TERKUNCI', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 18, fontWeight: FontWeight.bold, color: _C.gold, letterSpacing: 3)),
            const SizedBox(height: 10),
            Text('Fitur ini hanya untuk VIP.\nUpgrade akun untuk mengakses.', textAlign: TextAlign.center, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: _C.muted, height: 1.6)),
            const SizedBox(height: 28),
            GestureDetector(
              onTap: _showVipGatePopup,
              child: Container(padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14), decoration: BoxDecoration(gradient: LinearGradient(colors: [_C.gold, const Color(0xFFCC8A00)]), borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: _C.gold.withOpacity(0.35), blurRadius: 18)]), child: const Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.workspace_premium_rounded, color: Colors.black, size: 18), SizedBox(width: 8), Text('UPGRADE VIP', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 2, color: Colors.black))])),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMainView() {
    return Stack(
      children: [
        _buildCyberBackground(),
        SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeaderBanner(),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(child: GestureDetector(onTap: () => setState(() => _searchMode = 'qr'), child: Container(padding: const EdgeInsets.symmetric(vertical: 12), decoration: BoxDecoration(color: _searchMode == 'qr' ? _C.accent : _C.surface, borderRadius: BorderRadius.circular(10)), child: Center(child: Text('SCAN QR', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, color: _searchMode == 'qr' ? Colors.white : _C.muted, fontWeight: FontWeight.bold)))))),
                    const SizedBox(width: 8),
                    Expanded(child: GestureDetector(onTap: () => setState(() => _searchMode = 'ocr'), child: Container(padding: const EdgeInsets.symmetric(vertical: 12), decoration: BoxDecoration(color: _searchMode == 'ocr' ? _C.accent : _C.surface, borderRadius: BorderRadius.circular(10)), child: Center(child: Text('OCR GAMBAR', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, color: _searchMode == 'ocr' ? Colors.white : _C.muted, fontWeight: FontWeight.bold)))))),
                    const SizedBox(width: 8),
                    Expanded(child: GestureDetector(onTap: () => setState(() => _searchMode = 'phone'), child: Container(padding: const EdgeInsets.symmetric(vertical: 12), decoration: BoxDecoration(color: _searchMode == 'phone' ? _C.accent : _C.surface, borderRadius: BorderRadius.circular(10)), child: Center(child: Text('NOMOR WA', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, color: _searchMode == 'phone' ? Colors.white : _C.muted, fontWeight: FontWeight.bold)))))),
                  ],
                ),
                const SizedBox(height: 16),
                if (_searchMode == 'qr') _buildUploadCard() 
                else if (_searchMode == 'ocr') _buildOcrCard() 
                else _buildPhoneCard(),
                const SizedBox(height: 16),
                if (_isScanning || _isLookingUp) _buildScanningPanel(),
                if (_errorMsg != null) _buildErrorPanel(),
                if (_result != null) _buildResultSummaryCard(),
                const SizedBox(height: 24),
                _buildInfoFooter(),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCyberBackground() {
    return Positioned.fill(child: Stack(children: [
      Container(decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF000000), Color(0xFF0a0a0a), Color(0xFF050505)]))),
      AnimatedBuilder(animation: _matrixController, builder: (context, _) { return CustomPaint(painter: _MatrixPainter(drops: _drops, progress: _matrixController.value), size: Size.infinite); }),
      CustomPaint(painter: _GridPainter(), size: Size.infinite),
      AnimatedBuilder(animation: _bgPulseController, builder: (context, _) { final p = _bgPulseController.value; return Container(decoration: BoxDecoration(gradient: RadialGradient(center: const Alignment(0, -0.3), radius: 0.9, colors: [_C.accent.withOpacity(0.05 + p * 0.03), Colors.transparent]))); }),
    ]));
  }

  Widget _buildHeaderBanner() {
    return AnimatedBuilder(
      animation: _glitchController,
      builder: (context, _) {
        final glitch = math.sin(_glitchController.value * math.pi * 8);
        final offset = glitch.abs() > 0.92 ? 2.0 : 0.0;
        return Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: Colors.white.withOpacity(0.03), borderRadius: BorderRadius.circular(18), border: Border.all(color: _C.accent.withOpacity(0.25), width: 1), boxShadow: [BoxShadow(color: _C.accent.withOpacity(0.08), blurRadius: 24, spreadRadius: 1)]),
          child: Row(
            children: [
              AnimatedBuilder(animation: _radarController, builder: (context, _) { return SizedBox(width: 52, height: 52, child: CustomPaint(painter: _RadarPainter(progress: _radarController.value, color: _C.accent), child: const Center(child: Icon(FontAwesomeIcons.fingerprint, color: _C.accent, size: 20)))); }),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Transform.translate(
                      offset: Offset(offset, 0),
                      child: ShaderMask(
                        shaderCallback: (bounds) { return const LinearGradient(colors: [Colors.white, _C.accent, Colors.white], stops: [0.0, 0.5, 1.0]).createShader(bounds); },
                        blendMode: BlendMode.srcIn,
                        child: const Text('YAKUZA INTELEJEN', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white, letterSpacing: 2)),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text('Multi-source intelligence → secure identity lookup', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _C.muted, letterSpacing: 0.3)),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildUploadCard() {
    final hasImage = _selectedBytes != null;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: Colors.white.withOpacity(0.03), borderRadius: BorderRadius.circular(18), border: Border.all(color: hasImage ? _C.accent.withOpacity(0.4) : Colors.white.withOpacity(0.08), width: 1)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(FontAwesomeIcons.image, color: hasImage ? _C.accent : _C.muted, size: 14),
              const SizedBox(width: 8),
              Text('QR IMAGE INPUT', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: hasImage ? _C.accent : _C.muted, letterSpacing: 2, fontWeight: FontWeight.bold)),
              const Spacer(),
              if (hasImage) GestureDetector(onTap: () { setState(() { _selectedImage = null; _selectedBytes = null; _result = null; _errorMsg = null; }); }, child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: _C.accent.withOpacity(0.15), borderRadius: BorderRadius.circular(6), border: Border.all(color: _C.accent.withOpacity(0.4))), child: const Row(children: [Icon(Icons.close_rounded, color: _C.accent, size: 12), SizedBox(width: 4), Text('RESET', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: _C.accent, fontWeight: FontWeight.bold))]))),
            ],
          ),
          const SizedBox(height: 14),
          GestureDetector(
            onTap: _isScanning ? null : () => _showPickerSheet(),
            child: Container(
              width: double.infinity, height: 200,
              decoration: BoxDecoration(color: Colors.black.withOpacity(0.4), borderRadius: BorderRadius.circular(14), border: Border.all(color: hasImage ? _C.accent.withOpacity(0.3) : Colors.white.withOpacity(0.08), width: 1.5)),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(13),
                child: hasImage
                    ? Stack(fit: StackFit.expand, children: [
                        Image.memory(_selectedBytes!, fit: BoxFit.contain),
                        if (_isScanning) AnimatedBuilder(animation: _scanLineController, builder: (context, _) { return Positioned(top: _scanLineController.value * 200, left: 0, right: 0, child: Container(height: 2, decoration: BoxDecoration(gradient: const LinearGradient(colors: [Colors.transparent, _C.accent, Colors.transparent]), boxShadow: [BoxShadow(color: _C.accent.withOpacity(0.8), blurRadius: 12, spreadRadius: 2)]))); }),
                      ])
                    : Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        AnimatedBuilder(animation: _bgPulseController, builder: (context, _) { final p = _bgPulseController.value; return Icon(Icons.add_photo_alternate_rounded, color: _C.accent.withOpacity(0.4 + p * 0.4), size: 42); }),
                        const SizedBox(height: 10),
                        Text('Tap to upload QR image', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: _C.muted)),
                        const SizedBox(height: 4),
                        Text('JPG / PNG · max 5MB', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _C.muted2)),
                      ]),
              ),
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity, height: 52,
            child: ElevatedButton(
              onPressed: (_isScanning || !hasImage) ? null : _startScan,
              style: ElevatedButton.styleFrom(backgroundColor: _C.accent, foregroundColor: Colors.white, disabledBackgroundColor: _C.surface, disabledForegroundColor: _C.muted2, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)), shadowColor: _C.accent.withOpacity(0.5)),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [if (_isScanning) const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)) else const Icon(FontAwesomeIcons.magnifyingGlass, size: 16), const SizedBox(width: 10), Text(_isScanning ? 'SCANNING...' : 'SCAN QR', style: const TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 13, fontWeight: FontWeight.bold, letterSpacing: 2))]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOcrCard() {
    final hasImage = _selectedBytes != null;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: Colors.white.withOpacity(0.03), borderRadius: BorderRadius.circular(18), border: Border.all(color: hasImage ? _C.accent.withOpacity(0.4) : Colors.white.withOpacity(0.08), width: 1)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.image_search, color: hasImage ? _C.accent : _C.muted, size: 14),
              const SizedBox(width: 8),
              Text('OCR IMAGE INPUT', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: hasImage ? _C.accent : _C.muted, letterSpacing: 2, fontWeight: FontWeight.bold)),
              const Spacer(),
              if (hasImage) GestureDetector(onTap: () { setState(() { _selectedImage = null; _selectedBytes = null; _result = null; _errorMsg = null; }); }, child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: _C.accent.withOpacity(0.15), borderRadius: BorderRadius.circular(6), border: Border.all(color: _C.accent.withOpacity(0.4))), child: const Row(children: [Icon(Icons.close_rounded, color: _C.accent, size: 12), SizedBox(width: 4), Text('RESET', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: _C.accent, fontWeight: FontWeight.bold))]))),
            ],
          ),
          const SizedBox(height: 14),
          GestureDetector(
            onTap: _isScanning ? null : () => _showPickerSheet(),
            child: Container(
              width: double.infinity, height: 200,
              decoration: BoxDecoration(color: Colors.black.withOpacity(0.4), borderRadius: BorderRadius.circular(14), border: Border.all(color: hasImage ? _C.accent.withOpacity(0.3) : Colors.white.withOpacity(0.08), width: 1.5)),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(13),
                child: hasImage
                    ? Image.memory(_selectedBytes!, fit: BoxFit.contain)
                    : Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        AnimatedBuilder(animation: _bgPulseController, builder: (context, _) { final p = _bgPulseController.value; return Icon(Icons.document_scanner_rounded, color: _C.accent.withOpacity(0.4 + p * 0.4), size: 42); }),
                        const SizedBox(height: 10),
                        Text('Upload Screenshot Profil WA', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: _C.muted)),
                        const SizedBox(height: 4),
                        Text('JPG / PNG · max 5MB', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _C.muted2)),
                      ]),
              ),
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity, height: 52,
            child: ElevatedButton(
              onPressed: (_isScanning || !hasImage) ? null : _startOcr,
              style: ElevatedButton.styleFrom(backgroundColor: _C.accent, foregroundColor: Colors.white, disabledBackgroundColor: _C.surface, disabledForegroundColor: _C.muted2, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)), shadowColor: _C.accent.withOpacity(0.5)),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [if (_isScanning) const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)) else const Icon(Icons.document_scanner_rounded, size: 16), const SizedBox(width: 10), Text(_isScanning ? 'ANALYZING...' : 'OCR SCAN', style: const TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 13, fontWeight: FontWeight.bold, letterSpacing: 2))]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPhoneCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: Colors.white.withOpacity(0.03), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white.withOpacity(0.08))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [Icon(Icons.phone_android_rounded, color: _C.accent, size: 14), const SizedBox(width: 8), Text('PHONE NUMBER INPUT', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _C.accent, letterSpacing: 2, fontWeight: FontWeight.bold))]),
          const SizedBox(height: 14),
          TextField(
            controller: _phoneController,
            keyboardType: TextInputType.phone,
            style: TextStyle(fontFamily: 'ShareTechMono', color: _C.text),
            decoration: InputDecoration(
              hintText: '628xxxxxxxxxx', hintStyle: TextStyle(color: _C.muted, fontFamily: 'ShareTechMono'), filled: true, fillColor: Colors.black.withOpacity(0.4),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: _C.accent.withOpacity(0.3))),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: _C.accent.withOpacity(0.2))),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: _C.accent)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              prefixIcon: Icon(Icons.tag, color: _C.muted),
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity, height: 52,
            child: ElevatedButton(
              onPressed: _isLookingUp ? null : () {
                // Fungsi phone lookup lama tetap ada di backend, tapi di UI kita arahkan
                // user untuk pakai OCR atau Scan QR saja.
                _showSnack('Gunakan fitur OCR atau Scan QR untuk hasil terbaik.', isError: false);
              },
              style: ElevatedButton.styleFrom(backgroundColor: _C.surface, foregroundColor: _C.muted, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)), elevation: 0),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [const Icon(Icons.search_rounded, size: 16), const SizedBox(width: 10), const Text('LACAK NOMOR (NONAKTIF)', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 2))]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScanningPanel() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.black.withOpacity(0.6), borderRadius: BorderRadius.circular(16), border: Border.all(color: _C.accent.withOpacity(0.4), width: 1), boxShadow: [BoxShadow(color: _C.accent.withOpacity(0.15), blurRadius: 24, spreadRadius: 1)]),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [AnimatedBuilder(animation: _scanLineController, builder: (context, _) { return Transform.rotate(angle: _scanLineController.value * math.pi * 2, child: const Icon(FontAwesomeIcons.arrowsRotate, color: _C.accent, size: 14)); }), const SizedBox(width: 8), Text('ANALYZING...', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 11, fontWeight: FontWeight.bold, color: _C.accent, letterSpacing: 2)), const Spacer(), Text('${(_scanProgress * 100).toInt()}%', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: _C.accent, fontWeight: FontWeight.bold))]),
          const SizedBox(height: 12),
          ClipRRect(borderRadius: BorderRadius.circular(4), child: LinearProgressIndicator(value: _scanProgress, minHeight: 4, backgroundColor: Colors.white.withOpacity(0.05), valueColor: AlwaysStoppedAnimation(_C.accent))),
          const SizedBox(height: 14),
          Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: Colors.black.withOpacity(0.4), borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.white.withOpacity(0.05))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: List.generate(_scanLogLine + 1, (i) { final isLast = i == _scanLogLine; return Padding(padding: EdgeInsets.only(bottom: isLast ? 0 : 3), child: Text(_logSteps[i], style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: isLast ? _C.accent : Colors.white.withOpacity(0.4), height: 1.4))); }))),
        ],
      ),
    );
  }

  Widget _buildErrorPanel() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: _C.accent.withOpacity(0.08), borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.accent.withOpacity(0.35))),
      child: Row(children: [const Icon(Icons.error_outline_rounded, color: _C.accent, size: 18), const SizedBox(width: 10), Expanded(child: Text(_errorMsg ?? '', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: _C.text, height: 1.5)))]),
    );
  }

  Widget _buildResultSummaryCard() {
    final name = _result?['name']?.toString() ?? '-';
    final nik = _result?['nik']?.toString() ?? '-';
    final type = _result?['type']?.toString() ?? 'unknown';
    
    IconData icon = Icons.person_search_rounded;
    Color typeColor = _C.accent;
    String typeLabel = 'IDENTITY MATCHED';
    
    if (type == 'merchant') { icon = Icons.storefront_rounded; typeColor = _C.gold; typeLabel = 'MERCHANT MATCHED'; }
    else if (type == 'whatsapp') { icon = FontAwesomeIcons.whatsapp; typeColor = const Color(0xFF25D366); typeLabel = 'WHATSAPP MATCHED'; }
    else if (type == 'url') { icon = Icons.link_rounded; typeColor = _C.blue; typeLabel = 'URL MATCHED'; }

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white.withOpacity(0.04), borderRadius: BorderRadius.circular(16), border: Border.all(color: typeColor.withOpacity(0.4)), boxShadow: [BoxShadow(color: typeColor.withOpacity(0.12), blurRadius: 20)]),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [Icon(icon, color: typeColor, size: 18), const SizedBox(width: 8), Text(typeLabel, style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 11, fontWeight: FontWeight.bold, color: typeColor, letterSpacing: 2))]),
          const SizedBox(height: 12),
          _resultRow('NAME', name),
          const SizedBox(height: 8),
          _resultRow('NIK / PHONE', nik),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity, height: 42, child: OutlinedButton(onPressed: _showResultPopup, style: OutlinedButton.styleFrom(foregroundColor: typeColor, side: BorderSide(color: typeColor.withOpacity(0.5)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))), child: Text('VIEW FULL DOSSIER', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 2)))),
        ],
      ),
    );
  }

  Widget _resultRow(String label, String value) {
    return Row(children: [SizedBox(width: 90, child: Text(label, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _C.muted, letterSpacing: 1))), Expanded(child: Text(value, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 13, color: _C.text, fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis))]);
  }

  Widget _buildInfoFooter() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white.withOpacity(0.03), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.white.withOpacity(0.08))),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.info_outline_rounded, color: _C.muted, size: 14), const SizedBox(width: 8), Expanded(child: Text('Sistem akan membaca identitas dari QR Code (WhatsApp, Merchant, Link) atau Gambar via OCR secara aman, lalu mencocokkan dengan data resmi pada database terpusat.', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _C.muted, height: 1.5)))]),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// INTEL RESULT DIALOG
// ═══════════════════════════════════════════════════════════════════════════
class _IntelResultDialog extends StatefulWidget {
  final Map<String, dynamic> data;
  const _IntelResultDialog({required this.data});
  @override
  State<_IntelResultDialog> createState() => _IntelResultDialogState();
}

class _IntelResultDialogState extends State<_IntelResultDialog> with SingleTickerProviderStateMixin {
  late AnimationController _scaleController;
  late AnimationController _glowController;

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(duration: const Duration(milliseconds: 500), vsync: this)..forward();
    _glowController = AnimationController(duration: const Duration(milliseconds: 1500), vsync: this)..repeat(reverse: true);
  }

  @override
  void dispose() { _scaleController.dispose(); _glowController.dispose(); super.dispose(); }

  String _v(String key) {
    final v = widget.data[key];
    return (v == null || v.toString().isEmpty) ? '-' : v.toString();
  }

  @override
  Widget build(BuildContext context) {
    final type = widget.data['type']?.toString() ?? 'unknown';
    Color primary = _C.accent;
    IconData icon = Icons.person_search_rounded;
    String label = 'DOSSIER FOUND';
    String title = 'DATA PEMILIK QR';

    if (type == 'merchant') { primary = _C.gold; icon = Icons.storefront_rounded; label = 'MERCHANT FOUND'; title = 'DATA MERCHANT'; }
    else if (type == 'whatsapp') { primary = const Color(0xFF25D366); icon = FontAwesomeIcons.whatsapp; label = 'WHATSAPP FOUND'; title = 'PROFIL WHATSAPP'; }
    else if (type == 'url') { primary = _C.blue; icon = Icons.link_rounded; label = 'URL FOUND'; title = 'INFORMASI URL'; }

    final profilePic = widget.data['profilePic']?.toString() ?? '';
    final primaryDark = Color.lerp(primary, Colors.black, 0.4)!;

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 20),
      child: ScaleTransition(
        scale: Tween<double>(begin: 0.7, end: 1.0).animate(CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut)),
        child: Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.topCenter,
          children: [
            Positioned(top: -20, child: AnimatedBuilder(animation: _glowController, builder: (_, __) => Container(width: 80, height: 80, decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [BoxShadow(color: primary.withOpacity(0.4 + _glowController.value * 0.3), blurRadius: 30 + _glowController.value * 20, spreadRadius: 4)])))),
            Container(
              margin: const EdgeInsets.only(top: 40),
              padding: const EdgeInsets.fromLTRB(20, 36, 20, 20),
              decoration: BoxDecoration(gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF1a1a1a), Color(0xFF0a0a0a)]), borderRadius: BorderRadius.circular(24), border: Border.all(color: primary.withOpacity(0.4), width: 1.5), boxShadow: [BoxShadow(color: primary.withOpacity(0.2), blurRadius: 40), BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 30)]),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (profilePic.isNotEmpty)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(36),
                      child: CachedNetworkImage(imageUrl: profilePic, width: 72, height: 72, fit: BoxFit.cover, placeholder: (_, __) => Container(width: 72, height: 72, decoration: BoxDecoration(gradient: LinearGradient(colors: [primary, primaryDark]), shape: BoxShape.circle), child: Icon(icon, color: Colors.white, size: 32)), errorWidget: (_, __, ___) => Container(width: 72, height: 72, decoration: BoxDecoration(gradient: LinearGradient(colors: [primary, primaryDark]), shape: BoxShape.circle), child: Icon(icon, color: Colors.white, size: 32))),
                    )
                  else
                    Container(width: 72, height: 72, decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [primary, primaryDark]), shape: BoxShape.circle, boxShadow: [BoxShadow(color: primary.withOpacity(0.5), blurRadius: 20)]), child: Icon(icon, color: Colors.white, size: 32)),
                  const SizedBox(height: 14),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4), decoration: BoxDecoration(color: primary.withOpacity(0.15), borderRadius: BorderRadius.circular(8), border: Border.all(color: primary.withOpacity(0.3))), child: Text(label, style: TextStyle(color: primary, fontFamily: 'MADEEvolveSansEVO', fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 2))),
                  const SizedBox(height: 14),
                  Text(title, style: const TextStyle(color: Colors.white, fontFamily: 'MADEEvolveSansEVO', fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                  const SizedBox(height: 6),
                  Container(width: 40, height: 2, color: primary.withOpacity(0.5)),
                  const SizedBox(height: 16),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: Colors.black.withOpacity(0.4), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.white.withOpacity(0.06))),
                    child: Column(
                      children: [
                        _dialogRow('NAMA', _v('name')),
                        _divider(),
                        _dialogRow(type == 'whatsapp' ? 'NOMOR WA' : 'NIK', _v('nik')),
                        _divider(),
                        _dialogRow('ALAMAT / BIO', _v('address')),
                        _divider(),
                        _dialogRow('TANGGAL LAHIR', _v('birthDate')),
                        _divider(),
                        _dialogRow('JENIS KELAMIN', _v('gender')),
                        _divider(),
                        _dialogRow('PEKERJAAN', _v('job')),
                        _divider(),
                        _dialogRow('KEWARGANEGARAAN', _v('nationality')),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(width: double.infinity, height: 46, child: ElevatedButton(onPressed: () => Navigator.of(context).pop(), style: ElevatedButton.styleFrom(backgroundColor: primary, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), elevation: 0), child: const Text('TUTUP', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 2)))),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _dialogRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [SizedBox(width: 110, child: Text(label, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _C.muted, letterSpacing: 0.5))), Expanded(child: Text(value, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: _C.text, fontWeight: FontWeight.w600, height: 1.4)))]),
    );
  }

  Widget _divider() => Container(height: 1, color: Colors.white.withOpacity(0.05));
}

// ═══════════════════════════════════════════════════════════════════════════
// CUSTOM PAINTERS
// ═══════════════════════════════════════════════════════════════════════════
class _MatrixDrop { double x; double y; final double speed; final int charCode; _MatrixDrop({required this.x, required this.y, required this.speed, required this.charCode}); }
class _MatrixPainter extends CustomPainter {
  final List<_MatrixDrop> drops; final double progress;
  _MatrixPainter({required this.drops, required this.progress});
  @override
  void paint(Canvas canvas, Size size) {
    final tp = TextPainter(textDirection: TextDirection.ltr);
    for (final d in drops) {
      final px = d.x * size.width; final py = d.y * size.height; final char = String.fromCharCode(d.charCode);
      tp.text = TextSpan(text: char, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: const Color(0xFFFF3B30).withOpacity(0.15))); tp.layout(); tp.paint(canvas, Offset(px, py));
      tp.text = TextSpan(text: char, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: const Color(0xFFFF3B30).withOpacity(0.06))); tp.layout(); tp.paint(canvas, Offset(px, py - 14));
    }
  }
  @override
  bool shouldRepaint(covariant _MatrixPainter oldDelegate) => true;
}
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white.withOpacity(0.025)..strokeWidth = 0.5;
    const step = 40.0;
    for (double x = 0; x < size.width; x += step) { canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint); }
    for (double y = 0; y < size.height; y += step) { canvas.drawLine(Offset(0, y), Offset(size.width, y), paint); }
  }
  @override
  bool shouldRepaint(covariant _GridPainter oldDelegate) => false;
}
class _RadarPainter extends CustomPainter {
  final double progress; final Color color;
  _RadarPainter({required this.progress, required this.color});
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2); final radius = size.width / 2;
    final ringPaint = Paint()..color = color.withOpacity(0.2)..style = PaintingStyle.stroke..strokeWidth = 1;
    canvas.drawCircle(center, radius * 0.9, ringPaint); canvas.drawCircle(center, radius * 0.6, ringPaint); canvas.drawCircle(center, radius * 0.3, ringPaint);
    final sweepPaint = Paint()..shader = SweepGradient(startAngle: 0, endAngle: math.pi * 2, colors: [color.withOpacity(0.4), color.withOpacity(0.0)]).createShader(Rect.fromCircle(center: center, radius: radius));
    canvas.save(); canvas.translate(center.dx, center.dy); canvas.rotate(progress * math.pi * 2); canvas.translate(-center.dx, -center.dy); canvas.drawCircle(center, radius, sweepPaint); canvas.restore();
  }
  @override
  bool shouldRepaint(covariant _RadarPainter oldDelegate) => oldDelegate.progress != progress;
}