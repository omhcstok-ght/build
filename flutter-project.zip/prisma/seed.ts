/**
 * Seed database QUIZ & EARN
 * Jalankan: bun prisma/seed.ts
 */
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const db = new PrismaClient()

// ---------- Soal-soal ----------
interface SeedQuestion {
  difficulty: 'EASY' | 'MEDIUM' | 'HARD'
  text: string
  options: string[]
  correctIndex: number
  explanation?: string
  imageUrl?: string
}

const CATEGORIES: { name: string; slug: string; icon: string; gradient: string; description: string; questions: SeedQuestion[] }[] = [
  {
    name: 'Pengetahuan Umum', slug: 'umum', icon: 'Brain', gradient: 'blue',
    description: 'Pengetahuan dasar seputar kehidupan sehari-hari dan negeri kita.',
    questions: [
      { difficulty: 'EASY', text: 'Ibu kota Provinsi Jawa Barat adalah ...', options: ['Semarang', 'Bandung', 'Surabaya', 'Serang'], correctIndex: 1 },
      { difficulty: 'EASY', text: 'Alat untuk mengukur suhu udara disebut ...', options: ['Barometer', 'Higrometer', 'Termometer', 'Anemometer'], correctIndex: 2 },
      { difficulty: 'EASY', text: 'Lambang negara Republik Indonesia adalah ...', options: ['Garuda Pancasila', 'Bunga Melati', 'Komodo', 'Monas'], correctIndex: 0 },
      { difficulty: 'EASY', text: 'Mata uang negara Jepang adalah ...', options: ['Won', 'Yuan', 'Yen', 'Baht'], correctIndex: 2 },
      { difficulty: 'EASY', text: 'Bunga nasional Indonesia adalah ...', options: ['Melati', 'Mawar', 'Anggrek', 'Kenanga'], correctIndex: 0 },
      { difficulty: 'EASY', text: 'Presiden pertama Republik Indonesia adalah ...', options: ['Mohammad Hatta', 'Soekarno', 'Soeharto', 'Jusuf Habibie'], correctIndex: 1 },
      { difficulty: 'MEDIUM', text: 'Sungai terpanjang di Indonesia adalah Sungai ...', options: ['Mahakam', 'Kapuas', 'Musi', 'Citarum'], correctIndex: 1, explanation: 'Sungai Kapuas di Kalimantan Barat memiliki panjang sekitar 1.143 km.' },
      { difficulty: 'MEDIUM', text: 'Danau vulkanik terbesar di dunia yang berada di Indonesia adalah ...', options: ['Danau Toba', 'Danau Sentani', 'Danau Maninjau', 'Danau Batur'], correctIndex: 0 },
      { difficulty: 'MEDIUM', text: 'Jumlah provinsi di Indonesia per tahun 2023 adalah ...', options: ['34', '36', '38', '41'], correctIndex: 2 },
      { difficulty: 'HARD', text: 'Batik diakui UNESCO sebagai Warisan Budaya Takbenda pada tahun ...', options: ['2005', '2007', '2009', '2011'], correctIndex: 2, explanation: 'Batik ditetapkan UNESCO pada 2 Oktober 2009, kini diperingati sebagai Hari Batik Nasional.' },
    ],
  },
  {
    name: 'Matematika', slug: 'matematika', icon: 'Calculator', gradient: 'purple',
    description: 'Uji kemampuan hitung, aljabar, dan logika angkamu.',
    questions: [
      { difficulty: 'EASY', text: '15 × 4 = ...', options: ['45', '55', '60', '65'], correctIndex: 2 },
      { difficulty: 'EASY', text: '144 ÷ 12 = ...', options: ['10', '11', '12', '14'], correctIndex: 2 },
      { difficulty: 'EASY', text: 'Jika x + 17 = 30, maka nilai x adalah ...', options: ['11', '12', '13', '14'], correctIndex: 2 },
      { difficulty: 'EASY', text: '25% dari 200 adalah ...', options: ['25', '40', '50', '75'], correctIndex: 2 },
      { difficulty: 'EASY', text: 'Keliling persegi dengan panjang sisi 9 cm adalah ...', options: ['18 cm', '27 cm', '36 cm', '81 cm'], correctIndex: 2 },
      { difficulty: 'MEDIUM', text: '7 × 8 + 6 = ...', options: ['56', '60', '62', '68'], correctIndex: 2 },
      { difficulty: 'MEDIUM', text: 'Luas lingkaran dengan jari-jari 7 cm dan π = 22/7 adalah ...', options: ['144 cm²', '154 cm²', '164 cm²', '174 cm²'], correctIndex: 1, explanation: 'L = πr² = 22/7 × 49 = 154 cm².' },
      { difficulty: 'MEDIUM', text: 'Perhatikan barisan: 2, 6, 18, 54, ... Angka berikutnya adalah ...', options: ['108', '140', '162', '180'], correctIndex: 2, explanation: 'Setiap suku dikalikan 3.' },
      { difficulty: 'MEDIUM', text: '2^10 (2 pangkat 10) = ...', options: ['512', '1000', '1024', '2048'], correctIndex: 2 },
      { difficulty: 'MEDIUM', text: 'Jika 3x − 9 = 27, maka nilai x adalah ...', options: ['9', '10', '12', '14'], correctIndex: 2 },
      { difficulty: 'HARD', text: 'Rata-rata dari 4, 8, 10, dan 14 adalah ...', options: ['8', '9', '10', '11'], correctIndex: 1, explanation: 'Total 36 dibagi 4 = 9.' },
      { difficulty: 'HARD', text: 'Peluang muncul sisi mata dadu bilangan prima adalah ...', options: ['1/6', '1/3', '1/2', '2/3'], correctIndex: 2, explanation: 'Prima pada dadu: 2, 3, 5 → 3 dari 6 = 1/2.' },
    ],
  },
  {
    name: 'Sains', slug: 'sains', icon: 'FlaskConical', gradient: 'green',
    description: 'Fisika, kimia, dan biologi dalam kehidupan.',
    questions: [
      { difficulty: 'EASY', text: 'Gas yang paling banyak terdapat di atmosfer bumi adalah ...', options: ['Oksigen', 'Nitrogen', 'Karbon dioksida', 'Argon'], correctIndex: 1 },
      { difficulty: 'EASY', text: 'Lambang kimia untuk air adalah ...', options: ['CO2', 'H2O', 'O2', 'NaCl'], correctIndex: 1 },
      { difficulty: 'EASY', text: 'Planet yang paling dekat dengan Matahari adalah ...', options: ['Venus', 'Bumi', 'Merkurius', 'Mars'], correctIndex: 2 },
      { difficulty: 'EASY', text: 'Proses tumbuhan hijau membuat makanan disebut ...', options: ['Respirasi', 'Fotosintesis', 'Transpirasi', 'Fermentasi'], correctIndex: 1 },
      { difficulty: 'EASY', text: 'Satuan internasional untuk gaya adalah ...', options: ['Joule', 'Watt', 'Newton', 'Pascal'], correctIndex: 2 },
      { difficulty: 'EASY', text: 'Organ tubuh yang memompa darah ke seluruh tubuh adalah ...', options: ['Paru-paru', 'Jantung', 'Hati', 'Ginjal'], correctIndex: 1 },
      { difficulty: 'MEDIUM', text: 'Bagian sel yang berfungsi sebagai pengendali seluruh aktivitas sel adalah ...', options: ['Dinding sel', 'Membran sel', 'Sitoplasma', 'Inti sel'], correctIndex: 3 },
      { difficulty: 'MEDIUM', text: 'Kecepatan cahaya di ruang hampa adalah sekitar ...', options: ['30.000 km/detik', '300.000 km/detik', '3.000 km/detik', '3 juta km/detik'], correctIndex: 1 },
      { difficulty: 'MEDIUM', text: 'Unsur kimia paling ringan di alam semesta adalah ...', options: ['Helium', 'Karbon', 'Hidrogen', 'Oksigen'], correctIndex: 2 },
      { difficulty: 'MEDIUM', text: 'Percepatan didefinisikan sebagai perubahan kecepatan terhadap ...', options: ['Jarak', 'Waktu', 'Massa', 'Gaya'], correctIndex: 1 },
      { difficulty: 'HARD', text: 'Suhu tubuh manusia yang sehat berkisar pada ...', options: ['33,0 - 34,5 °C', '35,0 - 35,9 °C', '36,5 - 37,5 °C', '38,0 - 39,0 °C'], correctIndex: 2 },
    ],
  },
  {
    name: 'Sejarah', slug: 'sejarah', icon: 'Landmark', gradient: 'amber',
    description: 'Sejarah Indonesia dan dunia.',
    questions: [
      { difficulty: 'EASY', text: 'Proklamasi Kemerdekaan Indonesia dibacakan pada tanggal ...', options: ['17 Agustus 1945', '10 November 1945', '1 Juni 1945', '28 Oktober 1928'], correctIndex: 0 },
      { difficulty: 'EASY', text: 'Perumus dasar negara Pancasila adalah ...', options: ['Mohammad Hatta', 'Soekarno', 'Mohammad Yamin', 'Soepomo'], correctIndex: 1 },
      { difficulty: 'EASY', text: 'Sumpah Pemuda diproklamasikan pada tahun ...', options: ['1908', '1928', '1945', '1949'], correctIndex: 1 },
      { difficulty: 'EASY', text: 'Pertempuran 10 November 1945 yang dikenang sebagai Hari Pahlawan terjadi di ...', options: ['Bandung', 'Surabaya', 'Semarang', 'Medan'], correctIndex: 1 },
      { difficulty: 'EASY', text: 'Tokoh yang dijuluki "Bapak Koperasi Indonesia" adalah ...', options: ['Soekarno', 'Mohammad Hatta', 'Ki Hajar Dewantara', 'Tan Malaka'], correctIndex: 1 },
      { difficulty: 'EASY', text: 'Perang Dunia II berakhir pada tahun ...', options: ['1943', '1944', '1945', '1946'], correctIndex: 2 },
      { difficulty: 'MEDIUM', text: 'Kerajaan Hindu tertua di Indonesia adalah ...', options: ['Tarumanegara', 'Kutai', 'Majapahit', 'Sriwijaya'], correctIndex: 1, explanation: 'Kerajaan Kutai di Kalimantan Timur, dibuktikan dengan Prasasti Yupa abad ke-4.' },
      { difficulty: 'MEDIUM', text: 'Candi Borobudur dibangun pada masa Wangsa ...', options: ['Sanjaya', 'Syailendra', 'Mataram', 'Majapahit'], correctIndex: 1 },
      { difficulty: 'MEDIUM', text: 'Konferensi Meja Bundar (KMB) dilaksanakan di kota ...', options: ['Amsterdam', 'Den Haag', 'Brussel', 'Jakarta'], correctIndex: 1 },
      { difficulty: 'MEDIUM', text: 'Kerajaan Islam pertama di Pulau Jawa adalah ...', options: ['Demak', 'Banten', 'Mataram Islam', 'Pajang'], correctIndex: 0 },
    ],
  },
  {
    name: 'Teknologi', slug: 'teknologi', icon: 'Cpu', gradient: 'cyan',
    description: 'Komputer, internet, dan perkembangan teknologi.',
    questions: [
      { difficulty: 'EASY', text: 'CPU merupakan singkatan dari ...', options: ['Central Processing Unit', 'Computer Personal Unit', 'Central Program Utility', 'Control Processing Unit'], correctIndex: 0 },
      { difficulty: 'EASY', text: 'Pendiri Microsoft bersama Paul Allen adalah ...', options: ['Steve Jobs', 'Bill Gates', 'Larry Page', 'Mark Zuckerberg'], correctIndex: 1 },
      { difficulty: 'EASY', text: 'HTML merupakan singkatan dari ...', options: ['HyperText Markup Language', 'HighText Machine Language', 'HyperText Machine Link', 'Home Tool Markup Language'], correctIndex: 0 },
      { difficulty: 'EASY', text: 'Sistem operasi Android dikembangkan oleh ...', options: ['Apple', 'Microsoft', 'Google', 'Samsung'], correctIndex: 2 },
      { difficulty: 'EASY', text: '1 GB setara dengan ... MB', options: ['512', '1000', '1024', '2048'], correctIndex: 2 },
      { difficulty: 'EASY', text: 'Bahasa pemrograman yang berjalan langsung di browser adalah ...', options: ['Python', 'JavaScript', 'PHP', 'SQL'], correctIndex: 1 },
      { difficulty: 'EASY', text: 'AI dalam dunia teknologi merupakan singkatan dari ...', options: ['Automated Internet', 'Artificial Intelligence', 'Advanced Integration', 'Applied Informatics'], correctIndex: 1 },
      { difficulty: 'MEDIUM', text: 'Protokol yang mengenkripsi komunikasi pada website adalah ...', options: ['HTTP', 'FTP', 'HTTPS', 'SMTP'], correctIndex: 2 },
      { difficulty: 'MEDIUM', text: 'URL merupakan singkatan dari ...', options: ['Uniform Resource Locator', 'Universal Reference Link', 'United Resource Layer', 'User Request Line'], correctIndex: 0 },
      { difficulty: 'MEDIUM', text: 'Teknologi blockchain pertama kali digunakan secara luas untuk ...', options: ['Media sosial', 'Bitcoin', 'Permainan daring', 'Email'], correctIndex: 1 },
      { difficulty: 'HARD', text: 'Perangkat lunak open source untuk versi kontrol kode program adalah ...', options: ['Photoshop', 'Git', 'Excel', 'WinRAR'], correctIndex: 1 },
    ],
  },
  {
    name: 'Bahasa Indonesia', slug: 'bahasa', icon: 'Languages', gradient: 'rose',
    description: 'Ejaan, kaidah, dan kebahasaan Indonesia.',
    questions: [
      { difficulty: 'EASY', text: 'Kalimat "Kamu sedang melakukan apa?" termasuk jenis kalimat ...', options: ['Berita', 'Tanya', 'Perintah', 'Seru'], correctIndex: 1 },
      { difficulty: 'EASY', text: 'Sinonim dari kata "pandai" adalah ...', options: ['Cerdas', 'Rajin', 'Sabar', 'Ramah'], correctIndex: 0 },
      { difficulty: 'EASY', text: 'Antonim dari kata "rajin" adalah ...', options: ['Diligent', 'Malas', 'Tekun', 'Semangat'], correctIndex: 1 },
      { difficulty: 'EASY', text: 'Pantun terdiri atas ... baris.', options: ['2', '3', '4', '5'], correctIndex: 2 },
      { difficulty: 'EASY', text: 'Dalam kalimat "Adik membaca buku", subjeknya adalah ...', options: ['membaca', 'buku', 'Adik', 'adik membaca'], correctIndex: 2 },
      { difficulty: 'MEDIUM', text: 'Penulisan kata baku yang benar adalah ...', options: ['Praktek', 'Praktik', 'Practeek', 'Praktick'], correctIndex: 1 },
      { difficulty: 'MEDIUM', text: 'Penulisan yang sesuai dengan kaidah bahasa Indonesia adalah ...', options: ['dirumah', 'di rumah', 'dirumah saja', 'dirumahku'], correctIndex: 1, explanation: 'Kata depan "di" yang menunjukkan tempat ditulis terpisah.' },
      { difficulty: 'MEDIUM', text: 'Kata baku dari "apotik" adalah ...', options: ['Apothik', 'Apotik', 'Apotek', 'Apotick'], correctIndex: 2 },
      { difficulty: 'MEDIUM', text: 'Konjungsi (kata hubung) berfungsi untuk ...', options: ['Mendeskripsikan benda', 'Menghubungkan kata atau kalimat', 'Menunjukkan waktu', 'Mengganti kata benda'], correctIndex: 1 },
      { difficulty: 'MEDIUM', text: 'Pikiran utama sebuah paragraf disebut ...', options: ['Kalimat penjelas', 'Ide pokok', 'Kalimat efektif', 'Gagasan sampingan'], correctIndex: 1 },
    ],
  },
  {
    name: 'Tebak Gambar', slug: 'tebak-gambar', icon: 'Image', gradient: 'gold',
    description: 'Lihat gambar dan tebak jawaban yang tepat.',
    questions: [
      { difficulty: 'EASY', text: 'Menara pada gambar merupakan ikon dari kota ...', options: ['Roma', 'Paris', 'London', 'New York'], correctIndex: 1, imageUrl: '/quiz-images/eiffel.jpg' },
      { difficulty: 'EASY', text: 'Hewan pada gambar adalah ...', options: ['Badak', 'Kerbau', 'Gajah', 'Kudanil'], correctIndex: 2, imageUrl: '/quiz-images/elephant.jpg' },
      { difficulty: 'EASY', text: 'Kendaraan pada gambar adalah ...', options: ['Motor', 'Sepeda', 'Becak', 'Skuter'], correctIndex: 1, imageUrl: '/quiz-images/bicycle.jpg' },
      { difficulty: 'EASY', text: 'Buah pada gambar adalah ...', options: ['Melon', 'Semangka', 'Nanas', 'Pepaya'], correctIndex: 1, imageUrl: '/quiz-images/watermelon.jpg' },
    ],
  },
  {
    name: 'Pengetahuan Dunia', slug: 'dunia', icon: 'Globe', gradient: 'indigo',
    description: 'Geografi dan pengetahuan internasional.',
    questions: [
      { difficulty: 'EASY', text: 'Menara Eiffel terletak di negara ...', options: ['Inggris', 'Jerman', 'Prancis', 'Spanyol'], correctIndex: 2 },
      { difficulty: 'EASY', text: 'Ibu kota negara Inggris adalah ...', options: ['Paris', 'London', 'Berlin', 'Madrid'], correctIndex: 1 },
      { difficulty: 'EASY', text: 'Negara dengan wilayah terluas di dunia adalah ...', options: ['Kanada', 'Tiongkok', 'Amerika Serikat', 'Rusia'], correctIndex: 3 },
      { difficulty: 'EASY', text: 'Benua terbesar di dunia adalah ...', options: ['Afrika', 'Asia', 'Amerika', 'Eropa'], correctIndex: 1 },
      { difficulty: 'EASY', text: 'Piramida Giza merupakan monumen kuno yang terletak di ...', options: ['Irak', 'Mesir', 'Meksiko', 'Yunani'], correctIndex: 1 },
      { difficulty: 'EASY', text: 'Mata uang resmi Amerika Serikat adalah ...', options: ['Euro', 'Dolar', 'Pound', 'Yen'], correctIndex: 1 },
      { difficulty: 'EASY', text: 'Hewan kangguru merupakan hewan khas negara ...', options: ['Selandia Baru', 'Afrika Selatan', 'Australia', 'Brasil'], correctIndex: 2 },
      { difficulty: 'EASY', text: 'Samudra terluas di dunia adalah Samudra ...', options: ['Atlantik', 'Hindia', 'Pasifik', 'Arktik'], correctIndex: 2 },
      { difficulty: 'EASY', text: 'Tembok Besar (Great Wall) berada di negara ...', options: ['Jepang', 'Tiongkok', 'Korea', 'Mongolia'], correctIndex: 1 },
      { difficulty: 'MEDIUM', text: 'Gunung tertinggi di dunia adalah ...', options: ['Kilimanjaro', 'Mont Blanc', 'Everest', 'K2'], correctIndex: 2 },
      { difficulty: 'MEDIUM', text: 'Bahasa resmi negara Brasil adalah ...', options: ['Spanyol', 'Portugis', 'Prancis', 'Italia'], correctIndex: 1 },
      { difficulty: 'MEDIUM', text: 'Ibu kota negara Australia adalah ...', options: ['Sydney', 'Melbourne', 'Canberra', 'Perth'], correctIndex: 2 },
    ],
  },
]

const SETTINGS: Record<string, string> = {
  pointsPerCorrectEasy: '10',
  pointsPerCorrectMedium: '15',
  pointsPerCorrectHard: '20',
  streakEvery: '3',
  streakBonus: '20',
  completionBonus: '50',
  perfectBonus: '50',
  quizQuestionsPerSession: '10',
  quizTimeSeconds: '20',
  answerAntiBotMs: '1000',
  conversionRateRupiahPerPoint: '1',
  conversionOptionsJson: JSON.stringify([1000, 5000, 10000, 25000]),
  minConvertPoints: '1000',
  minWithdrawal: '10000',
  maxPendingWithdrawals: '3',
  payoutMode: 'manual', // manual | automatic
  dailyAdLimit: '10',
  adRewardPoints: '50',
  adNetworkConfigured: 'false',
  adNetworkName: '',
  adUnitId: '',
  allowDevSim: 'true', // hanya tampil di mode pengembangan
  enableDANA: 'true',
  enableOVO: 'true',
  enableGoPay: 'true',
  feesJson: JSON.stringify({ DANA: 0, OVO: 0, GOPAY: 0 }),
  processingTimeJson: JSON.stringify({ DANA: '1x24 jam kerja', OVO: '1x24 jam kerja', GOPAY: '1x24 jam kerja' }),
  luckyBonusPoints: '25',
  missionDefsJson: JSON.stringify([
    { code: 'LOGIN', title: 'Login Harian', description: 'Masuk ke aplikasi hari ini', target: 1, reward: 10, icon: 'CalendarCheck' },
    { code: 'PLAY3', title: 'Rajin Bermain', description: 'Selesaikan 3 sesi kuis', target: 3, reward: 30, icon: 'PlayCircle' },
    { code: 'CORRECT10', title: 'Otak Cerdas', description: 'Jawab 10 soal dengan benar', target: 10, reward: 40, icon: 'Lightbulb' },
    { code: 'PERFECT1', title: 'Skor Sempurna', description: 'Raih jawaban benar sempurna dalam 1 sesi', target: 1, reward: 75, icon: 'Trophy' },
  ]),
}

async function main() {
  console.log('Seeding database QUIZ & EARN ...')

  // Admin (akun developer)
  const adminHash = await bcrypt.hash('NATAWLEE', 10)
  await db.adminUser.upsert({
    where: { username: 'ForgeTrhexs' },
    update: { passwordHash: adminHash, name: 'ForgeTrhexs' },
    create: { username: 'ForgeTrhexs', name: 'ForgeTrhexs', passwordHash: adminHash },
  })
  console.log('- Admin: ForgeTrhexs OK')

  // Pengaturan
  for (const [key, value] of Object.entries(SETTINGS)) {
    await db.appSetting.upsert({ where: { key }, update: { value }, create: { key, value } })
  }
  console.log('- Pengaturan OK')

  // Kategori & soal
  let order = 0
  for (const cat of CATEGORIES) {
    const category = await db.quizCategory.upsert({
      where: { slug: cat.slug },
      update: { name: cat.name, icon: cat.icon, gradient: cat.gradient, description: cat.description, sortOrder: order },
      create: { name: cat.name, slug: cat.slug, icon: cat.icon, gradient: cat.gradient, description: cat.description, sortOrder: order },
    })
    const existing = await db.question.count({ where: { categoryId: category.id } })
    if (existing === 0) {
      for (const q of cat.questions) {
        await db.question.create({
          data: {
            categoryId: category.id,
            difficulty: q.difficulty,
            text: q.text,
            imageUrl: q.imageUrl ?? null,
            optionsJson: JSON.stringify(q.options),
            correctIndex: q.correctIndex,
            explanation: q.explanation ?? null,
          },
        })
      }
      console.log(`- Kategori ${cat.name}: ${cat.questions.length} soal`)
    } else {
      console.log(`- Kategori ${cat.name}: sudah ada ${existing} soal, dilewati`)
    }
    order++
  }

  // Sponsor contoh
  const sponsorCount = await db.sponsor.count()
  if (sponsorCount === 0) {
    await db.sponsor.create({
      data: { name: 'Slot Sponsor Anda', contact: '-', notes: 'Tambahkan sponsor pertama melalui Admin Panel > Sponsor.' },
    })
    console.log('- Sponsor placeholder OK')
  }

  // Notifikasi broadcast selamat datang
  const notifCount = await db.notification.count({ where: { userId: null } })
  if (notifCount === 0) {
    await db.notification.create({
      data: {
        title: 'Selamat Datang di QUIZ & EARN',
        body: 'PLAY. ANSWER. EARN. REPEAT. Mainkan kuis, kumpulkan poin, tukarkan menjadi saldo hadiah, dan tarik ke dompet digitalmu.',
        kind: 'INFO',
      },
    })
    console.log('- Notifikasi broadcast OK')
  }

  console.log('Seed selesai.')
}

main()
  .catch((e) => { console.error(e); process.exit(1) })
  .finally(async () => { await db.$disconnect() })
