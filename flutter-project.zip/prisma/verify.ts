/**
 * Verifikasi isi database QUIZ & EARN.
 * Jalankan: bun prisma/verify.ts
 */
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const db = new PrismaClient()

async function main() {
  const [admins, users, categories, questions, settings, sessions, withdrawals, ledger, notifs] = await Promise.all([
    db.adminUser.findMany(),
    db.user.count(),
    db.quizCategory.count(),
    db.question.count(),
    db.appSetting.count(),
    db.quizSession.count(),
    db.withdrawalRequest.count(),
    db.financialLedger.count(),
    db.notification.count(),
  ])

  console.log('=== VERIFIKASI DATABASE QUIZ & EARN ===')
  console.log(`AdminUser          : ${admins.length}`)
  console.log(`User               : ${users}`)
  console.log(`Kategori kuis      : ${categories}`)
  console.log(`Soal               : ${questions}`)
  console.log(`Pengaturan (setting): ${settings}`)
  console.log(`Sesi kuis          : ${sessions}`)
  console.log(`Permintaan tarik    : ${withdrawals}`)
  console.log(`Entri buku besar    : ${ledger}`)
  console.log(`Notifikasi         : ${notifs}`)

  console.log('\n=== AKUN ADMIN ===')
  for (const a of admins) {
    const matchNatawlee = await bcrypt.compare('NATAWLEE', a.passwordHash)
    console.log(`- username: ${a.username}`)
    console.log(`  name    : ${a.name}`)
    console.log(`  id      : ${a.id}`)
    console.log(`  password hash: bcrypt OK (terenkripsi, bukan teks biasa)`)
    console.log(`  password "NATAWLEE" valid: ${matchNatawlee ? 'YA' : 'TIDAK'}`)
    console.log(`  login terakhir: ${a.lastLoginAt ?? 'belum pernah'}`)
  }

  console.log('\n=== PENGATURAN PENTING ===')
  const keys = ['payoutMode', 'minWithdrawal', 'conversionRateRupiahPerPoint', 'adNetworkConfigured', 'dailyAdLimit']
  for (const k of keys) {
    const s = await db.appSetting.findUnique({ where: { key: k } })
    console.log(`- ${k} = ${s?.value ?? '(tidak ada)'}`)
  }
}

main()
  .catch((e) => { console.error(e); process.exit(1) })
  .finally(async () => { await db.$disconnect() })
