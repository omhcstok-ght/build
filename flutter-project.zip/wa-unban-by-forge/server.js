require("dotenv").config();
const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const db = new Database(path.join(ROOT, "forge.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user',
 access_until TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS plans (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, price INTEGER NOT NULL,
 duration_days INTEGER NOT NULL, description TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS payments (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, plan_id INTEGER NOT NULL,
 amount INTEGER NOT NULL, method TEXT NOT NULL, payer_name TEXT NOT NULL,
 reference TEXT, proof_path TEXT, status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, reviewed_at TEXT,
 FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(plan_id) REFERENCES plans(id)
);
CREATE TABLE IF NOT EXISTS appeals (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, wa_number TEXT NOT NULL,
 issue_type TEXT NOT NULL, details TEXT NOT NULL, generated_text TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'draft', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
`);

const planCount = db.prepare("SELECT COUNT(*) n FROM plans").get().n;
if (!planCount) {
  const add = db.prepare("INSERT INTO plans(name,price,duration_days,description) VALUES(?,?,?,?)");
  add.run("Starter", 15000, 7, "Akses Smart Appeal selama 7 hari");
  add.run("Pro", 35000, 30, "Akses Smart Appeal selama 30 hari");
  add.run("Lifetime", 99000, 3650, "Akses jangka panjang");
}
const setDefault = db.prepare("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)");
setDefault.run("payment_instructions", "Hubungi admin untuk mendapatkan QRIS atau nomor pembayaran resmi.");
setDefault.run("owner_contact", "Ganti dengan kontak owner");
setDefault.run("hero_title", "Pulihkan akses. Ajukan dengan benar.");
setDefault.run("appeal_limit_note", "Satu pengajuan yang jelas lebih baik daripada mengirim pesan berulang.");

const adminEmail = (process.env.ADMIN_EMAIL || "admin@example.com").toLowerCase();
if (!db.prepare("SELECT id FROM users WHERE email=?").get(adminEmail)) {
  const hash = bcrypt.hashSync(process.env.ADMIN_PASSWORD || "ChangeThisAdminPassword123!", 12);
  db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'admin')")
    .run(process.env.ADMIN_NAME || "Forge Owner", adminEmail, hash);
}

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: ROOT }),
  secret: process.env.SESSION_SECRET || "development-only-change-this-secret",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 7*24*60*60*1000 }
}));
app.use(express.static(path.join(ROOT, "public")));

const authLimiter = rateLimit({ windowMs: 15*60*1000, limit: 12, standardHeaders: true, legacyHeaders: false });
const uploadDir = path.join(ROOT, "private_uploads");
fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({
 destination: (_req, _file, cb) => cb(null, uploadDir),
 filename: (_req, file, cb) => cb(null, `${Date.now()}-${Math.random().toString(36).slice(2)}${path.extname(file.originalname).toLowerCase()}`)
});
const upload = multer({
 storage, limits: { fileSize: 4*1024*1024 },
 fileFilter: (_req, file, cb) => cb(null, ["image/jpeg","image/png","image/webp","application/pdf"].includes(file.mimetype))
});

function requireAuth(req,res,next){ if(!req.session.user) return res.status(401).json({error:"Silakan login terlebih dahulu."}); next(); }
function requireAdmin(req,res,next){ if(!req.session.user || req.session.user.role!=="admin") return res.status(403).json({error:"Akses admin ditolak."}); next(); }
function activeAccess(userId){
 const row = db.prepare("SELECT access_until FROM users WHERE id=?").get(userId);
 return !!(row && row.access_until && new Date(row.access_until).getTime() > Date.now());
}
function safeUser(u){ return {id:u.id,name:u.name,email:u.email,role:u.role,access_until:u.access_until,access_active:!!(u.access_until && new Date(u.access_until)>new Date())}; }

app.get("/api/config", (_req,res)=>{
 const settings = Object.fromEntries(db.prepare("SELECT key,value FROM settings").all().map(x=>[x.key,x.value]));
 res.json({brand:"WA UNBAN BY FORGE", settings});
});
app.post("/api/register", authLimiter, async (req,res)=>{
 const {name,email,password}=req.body||{};
 if(!name || !email || !password || password.length<10) return res.status(400).json({error:"Isi nama, email, dan password minimal 10 karakter."});
 try{
  const hash=await bcrypt.hash(password,12);
  const info=db.prepare("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)").run(name.trim().slice(0,80),email.trim().toLowerCase(),hash);
  req.session.user={id:info.lastInsertRowid,role:"user"};
  res.json({ok:true});
 }catch(e){res.status(409).json({error:"Email sudah terdaftar atau data tidak valid."});}
});
app.post("/api/login", authLimiter, async (req,res)=>{
 const {email,password}=req.body||{};
 const user=db.prepare("SELECT * FROM users WHERE email=?").get(String(email||"").trim().toLowerCase());
 if(!user || !(await bcrypt.compare(password||"",user.password_hash))) return res.status(401).json({error:"Email atau password salah."});
 req.session.regenerate(err=>{
  if(err) return res.status(500).json({error:"Gagal membuat sesi."});
  req.session.user={id:user.id,role:user.role};
  res.json({ok:true});
 });
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",requireAuth,(req,res)=>{
 const u=db.prepare("SELECT * FROM users WHERE id=?").get(req.session.user.id);
 res.json({user:safeUser(u)});
});
app.get("/api/plans",(_req,res)=>res.json({plans:db.prepare("SELECT id,name,price,duration_days,description FROM plans WHERE active=1 ORDER BY price").all()}));
app.get("/api/dashboard",requireAuth,(req,res)=>{
 const uid=req.session.user.id;
 res.json({
  user:safeUser(db.prepare("SELECT * FROM users WHERE id=?").get(uid)),
  payments:db.prepare("SELECT p.id,p.amount,p.method,p.status,p.created_at,pl.name plan FROM payments p JOIN plans pl ON pl.id=p.plan_id WHERE p.user_id=? ORDER BY p.id DESC").all(uid),
  appeals:db.prepare("SELECT id,wa_number,issue_type,status,created_at FROM appeals WHERE user_id=? ORDER BY id DESC").all(uid)
 });
});
app.post("/api/payments",requireAuth,upload.single("proof"),(req,res)=>{
 const {plan_id,method,payer_name,reference}=req.body;
 const plan=db.prepare("SELECT * FROM plans WHERE id=? AND active=1").get(Number(plan_id));
 if(!plan || !method || !payer_name || !req.file) return res.status(400).json({error:"Pilih paket, metode, nama pengirim, dan unggah bukti pembayaran."});
 const result=db.prepare("INSERT INTO payments(user_id,plan_id,amount,method,payer_name,reference,proof_path) VALUES(?,?,?,?,?,?,?)")
 .run(req.session.user.id,plan.id,plan.price,String(method).slice(0,40),String(payer_name).slice(0,80),String(reference||"").slice(0,100),req.file.filename);
 res.json({ok:true,id:result.lastInsertRowid,message:"Bukti pembayaran dikirim untuk verifikasi admin."});
});
app.post("/api/appeals",requireAuth,(req,res)=>{
 if(!activeAccess(req.session.user.id)) return res.status(403).json({error:"Akses belum aktif. Silakan beli paket dan tunggu persetujuan admin."});
 const {wa_number,issue_type,details}=req.body||{};
 if(!wa_number || !issue_type || !details || details.trim().length<20) return res.status(400).json({error:"Lengkapi nomor WhatsApp, jenis masalah, dan kronologi minimal 20 karakter."});
 let number=String(wa_number).replace(/[^\d]/g,"").slice(0,18);
 if(number.startsWith("0")) number="62"+number.slice(1);
 if(!number.startsWith("62")) number="62"+number;
 if(number.length<9 || number.length>18) return res.status(400).json({error:"Masukkan nomor WhatsApp Indonesia yang valid, misalnya 62812xxxxxxxx."});
 const safeDetails=String(details).trim().slice(0,1500);
 const safeIssue=String(issue_type).slice(0,80);
 const generated=`إلى فريق دعم واتساب المحترم،
السلام عليكم ورحمة الله وبركاته.

أرجو منكم مراجعة حسابي وإعادة النظر في حالة تقييده. أصبح حسابي غير قادر على العمل بشكل مفاجئ، ولا أعرف السبب الدقيق وراء ذلك. إذا حدثت مخالفة غير مقصودة، فأنا أعتذر عنها بصدق، وأتعهد بالالتزام بجميع شروط وسياسات واتساب مستقبلاً.

رقم الهاتف المرتبط بالحساب: +${number}
نوع المشكلة: ${safeIssue}

تفاصيل المشكلة:
${safeDetails}

أرجو التحقق من حالة الحساب ومراجعة الأمر بعناية، وإبلاغي إن كانت هناك خطوات مطلوبة من جانبي. أشكركم على وقتكم وتفهمكم ومساعدتكم.

مع خالص التقدير والاحترام.

────────────────────────

WhatsApp 고객 지원팀 담당자님께,

안녕하세요. 제 WhatsApp 계정이 갑자기 정상적으로 작동하지 않아 정중하게 재검토를 요청드립니다. 계정 이용이 제한된 정확한 이유를 아직 알지 못하고 있습니다. 혹시 제가 의도하지 않게 WhatsApp의 정책이나 이용 약관을 위반했다면 진심으로 사과드립니다.

계정 전화번호: +${number}
문제 유형: ${safeIssue}

문제 발생 경위:
${safeDetails}

제 계정 상태와 제한 사유를 다시 한번 확인해 주시기를 부탁드립니다. 필요한 조치가 있다면 안내해 주시면 성실히 따르겠습니다. 앞으로 WhatsApp의 모든 정책과 이용 규칙을 존중하고 준수하겠습니다.

바쁘신 가운데 제 요청을 검토해 주셔서 진심으로 감사드립니다. 가능하다면 제 계정을 다시 사용할 수 있도록 재검토해 주시기를 정중히 부탁드립니다.

감사합니다.

────────────────────────

尊敬的 WhatsApp 客服团队：

您好！我的 WhatsApp 账号突然无法正常使用，我目前还不清楚具体原因。如果我在无意中违反了平台政策，我对此表示诚挚的歉意，并承诺今后认真遵守 WhatsApp 的相关规定。

账号号码：+${number}
问题类型：${safeIssue}

问题说明：
${safeDetails}

恳请贵团队重新核实我的账号状态，并告知我是否需要采取进一步措施。感谢您的时间、理解与帮助。

此致，敬礼。

────────────────────────

Kepada Tim Dukungan WhatsApp yang terhormat,

Halo Tim WhatsApp. Saya ingin mengajukan permohonan peninjauan kembali atas akun saya yang tiba-tiba tidak dapat digunakan. Saya belum mengetahui penyebab pasti pembatasan tersebut.

Nomor akun: +${number}
Jenis kendala: ${safeIssue}

Kronologi dan keterangan:
${safeDetails}

Apabila terdapat aktivitas yang tidak sesuai dengan kebijakan WhatsApp, saya memohon maaf. Saya bersedia memahami dan memperbaiki hal yang diperlukan serta berkomitmen mematuhi Ketentuan Layanan WhatsApp ke depannya.

Saya memohon agar akun saya diperiksa kembali secara objektif. Terima kasih atas waktu, perhatian, dan bantuan tim dukungan.

Hormat saya,
Pemilik akun WhatsApp.

────────────────────────

Catatan: Pesan ini adalah draf permohonan. Pesan tidak dikirim otomatis oleh website.`;
 const info=db.prepare("INSERT INTO appeals(user_id,wa_number,issue_type,details,generated_text) VALUES(?,?,?,?,?)")
 .run(req.session.user.id,number,safeIssue,safeDetails,generated);
 res.json({ok:true,id:info.lastInsertRowid,message:generated});
});
app.get("/api/appeals/:id",requireAuth,(req,res)=>{
 const a=db.prepare("SELECT * FROM appeals WHERE id=? AND user_id=?").get(Number(req.params.id),req.session.user.id);
 if(!a) return res.status(404).json({error:"Pengajuan tidak ditemukan."});
 res.json({appeal:a});
});

// Admin endpoints
app.get("/api/admin/overview",requireAdmin,(_req,res)=>{
 res.json({
  users:db.prepare("SELECT COUNT(*) n FROM users WHERE role='user'").get().n,
  pending:db.prepare("SELECT COUNT(*) n FROM payments WHERE status='pending'").get().n,
  revenue:db.prepare("SELECT COALESCE(SUM(amount),0) n FROM payments WHERE status='approved'").get().n,
  appeals:db.prepare("SELECT COUNT(*) n FROM appeals").get().n,
  payments:db.prepare("SELECT p.*,u.name,u.email,pl.name plan FROM payments p JOIN users u ON u.id=p.user_id JOIN plans pl ON pl.id=p.plan_id ORDER BY p.id DESC LIMIT 100").all(),
  usersList:db.prepare("SELECT id,name,email,role,access_until,created_at FROM users ORDER BY id DESC LIMIT 100").all(),
  appealsList:db.prepare("SELECT a.*,u.name,u.email FROM appeals a JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 100").all(),
  plans:db.prepare("SELECT * FROM plans ORDER BY price").all(),
  settings:Object.fromEntries(db.prepare("SELECT key,value FROM settings").all().map(x=>[x.key,x.value]))
 });
});
app.get("/api/admin/proof/:id",requireAdmin,(req,res)=>{
 const p=db.prepare("SELECT proof_path FROM payments WHERE id=?").get(Number(req.params.id));
 if(!p || !p.proof_path) return res.sendStatus(404);
 res.sendFile(path.join(uploadDir,p.proof_path));
});
app.post("/api/admin/payments/:id/review",requireAdmin,(req,res)=>{
 const {decision}=req.body||{};
 const p=db.prepare("SELECT * FROM payments WHERE id=?").get(Number(req.params.id));
 if(!p || p.status!=="pending" || !["approved","rejected"].includes(decision)) return res.status(400).json({error:"Pembayaran tidak dapat diproses."});
 const tx=db.transaction(()=>{
  db.prepare("UPDATE payments SET status=?,reviewed_at=CURRENT_TIMESTAMP WHERE id=?").run(decision,p.id);
  if(decision==="approved"){
   const user=db.prepare("SELECT access_until FROM users WHERE id=?").get(p.user_id);
   const start=user.access_until && new Date(user.access_until)>new Date()?new Date(user.access_until):new Date();
   start.setDate(start.getDate()+db.prepare("SELECT duration_days FROM plans WHERE id=?").get(p.plan_id).duration_days);
   db.prepare("UPDATE users SET access_until=? WHERE id=?").run(start.toISOString(),p.user_id);
  }
 });
 tx(); res.json({ok:true});
});
app.post("/api/admin/plans",requireAdmin,(req,res)=>{
 const {id,name,price,duration_days,description,active}=req.body||{};
 if(!name || Number(price)<0 || Number(duration_days)<1) return res.status(400).json({error:"Data paket tidak valid."});
 if(id) db.prepare("UPDATE plans SET name=?,price=?,duration_days=?,description=?,active=? WHERE id=?").run(name,Number(price),Number(duration_days),description||"",active?1:0,Number(id));
 else db.prepare("INSERT INTO plans(name,price,duration_days,description,active) VALUES(?,?,?,?,?)").run(name,Number(price),Number(duration_days),description||"",active===false?0:1);
 res.json({ok:true});
});
app.post("/api/admin/settings",requireAdmin,(req,res)=>{
 const allowed=["payment_instructions","owner_contact","hero_title","appeal_limit_note"];
 const up=db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
 for(const k of allowed) if(typeof req.body[k]==="string") up.run(k,req.body[k].slice(0,500));
 res.json({ok:true});
});
app.post("/api/admin/appeals/:id/status",requireAdmin,(req,res)=>{
 const {status}=req.body||{};
 if(!["draft","submitted","in_review","resolved","closed"].includes(status)) return res.status(400).json({error:"Status tidak valid."});
 db.prepare("UPDATE appeals SET status=? WHERE id=?").run(status,Number(req.params.id));
 res.json({ok:true});
});

app.get("*",(req,res)=>res.sendFile(path.join(ROOT,"public","index.html")));
app.listen(PORT,()=>console.log(`WA UNBAN BY FORGE running at http://localhost:${PORT}`));
