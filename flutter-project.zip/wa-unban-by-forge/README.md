# WA UNBAN BY FORGE

Aplikasi full-stack untuk mengelola akses berbayar dan membantu pengguna menyusun **draft** permohonan peninjauan akun WhatsApp secara bertanggung jawab.

## Fitur
- Registrasi/login dengan hash password bcrypt dan session cookie.
- Database SQLite.
- Paket akses yang dapat dikelola admin.
- Bukti pembayaran upload (file disimpan privat, maksimal 4 MB).
- Persetujuan/penolakan pembayaran manual oleh admin.
- Akses membership aktif setelah pembayaran disetujui.
- Smart Appeal membuat draft pesan, bukan mengirim email massal atau menghubungi WhatsApp secara otomatis.
- Riwayat pembayaran dan pengajuan.
- Panel admin untuk statistik, pembayaran, pengguna, status pengajuan, paket, dan pengaturan.
- Video hero `public/hero.mp4`.

## Menjalankan lokal
1. Install Node.js 20 atau lebih baru.
2. Ekstrak ZIP.
3. Salin `.env.example` menjadi `.env`.
4. Ubah `SESSION_SECRET`, `ADMIN_EMAIL`, dan `ADMIN_PASSWORD`.
5. Jalankan:
   ```bash
   npm install
   npm start
   ```
6. Buka `http://localhost:3000`.

Admin awal dibuat dari variabel `ADMIN_EMAIL` dan `ADMIN_PASSWORD` saat server pertama kali berjalan. Jangan gunakan password contoh pada server publik.

## Pembayaran
Aplikasi ini sengaja tidak menampilkan QRIS/DANA palsu. Atur instruksi pembayaran dari Admin Panel setelah login. Untuk pembayaran otomatis, integrasikan payment gateway resmi dan verifikasi callback server-to-server; jangan mengandalkan screenshot saja.

## Deploy
Gunakan hosting Node.js yang mendukung persistent disk. SQLite dan folder `private_uploads` harus berada pada volume persisten. Atur:
- `NODE_ENV=production`
- `SESSION_SECRET` acak yang panjang
- `ADMIN_EMAIL` dan `ADMIN_PASSWORD` yang kuat
- HTTPS aktif

Untuk skala produksi multi-instance, pindahkan SQLite ke PostgreSQL dan session store ke Redis/PostgreSQL. Tambahkan CSRF protection, audit log, backup database, pemeriksaan MIME file yang lebih ketat, antivirus upload, dan kebijakan privasi sebelum menerima pembayaran nyata.

## Catatan penting
- Layanan ini independen dan tidak berafiliasi dengan WhatsApp/Meta.
- Tidak ada sistem yang dapat menjamin pemulihan akun. Hanya WhatsApp yang dapat memutuskan hasil peninjauan.
- Jangan pernah meminta password WhatsApp, PIN two-step verification, atau OTP.
- Jangan mengirim permohonan berulang/otomatis. Gunakan kanal resmi dan ikuti petunjuk di aplikasi WhatsApp.
- Harga paket adalah contoh dan perlu disesuaikan oleh pemilik sebelum digunakan.


## Smart Appeal multibahasa
Fitur Smart Appeal menghasilkan satu draf surat peninjauan dalam bahasa Arab, Korea, Mandarin, dan Indonesia. Nomor Indonesia dinormalisasi ke format +62. Pengguna tetap harus memeriksa isi dan mengirim sendiri melalui kanal resmi WhatsApp; aplikasi tidak mengirim pesan otomatis.
