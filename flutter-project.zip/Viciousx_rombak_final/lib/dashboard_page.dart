import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:math' show Random;
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:audioplayers/audioplayers.dart';

import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';

import 'api_config.dart';
import 'core/data/theme.dart';
import 'voltgram_page.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'al_quran.dart';
import 'anime_home.dart';
import 'chat_room_page.dart';
import 'notification_page.dart';
import 'bug_group_page.dart';
import 'custom_payload.dart';
import 'ular.dart';
import 'game_page.dart';
import 'sadap_whatsapp.dart';

// ─── COLORS — Ocean Light Theme ────────────────────────────────────────────────
const Color kBg        = Color(0xFFE8F4FD);   // laut terang
const Color kBgDeep    = Color(0xFFCDE8F6);
const Color kCard      = Color(0xFFFFFFFF);
const Color kCardAlt   = Color(0xFFF0F8FF);
const Color kBorder    = Color(0xFFB0D4EE);
const Color kBlue      = Color(0xFF0077C2);   // biru laut
const Color kBlueMid   = Color(0xFF0288D1);
const Color kBlueLight = Color(0xFF29B6F6);   // biru muda cerah
const Color kBlueSky   = Color(0xFF81D4FA);
const Color kGold      = Color(0xFFFFB300);
const Color kPink      = Color(0xFF039BE5);
const Color kPurple    = Color(0xFF0091EA);
const Color kYellow    = Color(0xFFFFD600);
const Color kWhite     = Color(0xFF0D2137);   // text gelap di bg terang
const Color kWhiteBg   = Colors.white;
const Color kWhite54   = Color(0xFF4A7FA5);
const Color kWhite24   = Color(0xFFB0CDE0);

// ─── Prayer Time Service ───────────────────────────────────────────────────────
class PrayerTimeService {
  static Future<Map<String, dynamic>> fetchPrayerTimes(String city) async {
    final now = DateTime.now();
    final uri = Uri.https('api.aladhan.com', '/v1/timingsByCity', {
      'city': city, 'country': 'ID', 'method': '11',
      'day': '${now.day}', 'month': '${now.month}', 'year': '${now.year}',
    });
    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return {};
  }
}

// ─── Role helpers ─────────────────────────────────────────────────────────────
Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'owner':    return const Color(0xFFF59E0B);
    case 'admin':    return const Color(0xFFEF4444);
    case 'reseller': return kBlue;
    case 'vip':      return kPurple;
    default:         return kBlue;
  }
}

IconData _roleIcon(String role) {
  switch (role.toLowerCase()) {
    case 'owner':    return Icons.workspace_premium_rounded;
    case 'admin':    return Icons.admin_panel_settings_rounded;
    case 'reseller': return Icons.storefront_rounded;
    case 'vip':      return Icons.star_rounded;
    default:         return Icons.person_rounded;
  }
}

// ─── ANIMATED DOT ──────────────────────────────────────────────────────────────
class _AnimatedDot extends StatefulWidget {
  final Color color;
  final double size;
  const _AnimatedDot({required this.color, this.size = 6});
  @override
  State<_AnimatedDot> createState() => _AnimatedDotState();
}

class _AnimatedDotState extends State<_AnimatedDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _a;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
    _a = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => FadeTransition(
    opacity: _a,
    child: Container(
      width: widget.size, height: widget.size,
      decoration: BoxDecoration(
        shape: BoxShape.circle, color: widget.color,
        boxShadow: [BoxShadow(color: widget.color.withOpacity(0.6), blurRadius: 6, spreadRadius: 1)],
      ),
    ),
  );
}

// ─── HEXAGON PATTERN PAINTER (Fixed - mirip gambar asli) ──────────────────────
class _HexagonPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = kBlue.withOpacity(0.12)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;

    const double w = 72.0;  // lebar diamond
    const double h = 52.0;  // tinggi diamond

    for (double row = -1; row * h < size.height + h * 2; row++) {
      for (double col = -1; col * w < size.width + w * 2; col++) {
        final double offsetX = (row.toInt() % 2 == 0) ? 0 : w * 0.5;
        final cx = col * w + offsetX;
        final cy = row * h;
        _drawDiamond(canvas, paint, Offset(cx, cy), w * 0.5, h * 0.5);
      }
    }
  }

  void _drawDiamond(Canvas canvas, Paint paint, Offset center, double hw, double hh) {
    final path = Path()
      ..moveTo(center.dx, center.dy - hh)   // top
      ..lineTo(center.dx + hw, center.dy)   // right
      ..lineTo(center.dx, center.dy + hh)   // bottom
      ..lineTo(center.dx - hw, center.dy)   // left
      ..close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

// ─── GRID PATTERN PAINTER ─────────────────────────────────────────────────────
class _GridPatternPainter extends CustomPainter {
  final Color gridColor;
  final Color lineColor;
  final double spacing;
  const _GridPatternPainter({required this.gridColor, required this.lineColor, required this.spacing});
  @override
  void paint(Canvas canvas, Size size) {
    final paintGrid = Paint()..color = gridColor..strokeWidth = 0.8..style = PaintingStyle.stroke;
    final paintLines = Paint()..color = lineColor..strokeWidth = 0.4..style = PaintingStyle.stroke;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paintGrid);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paintGrid);
    }
    for (double x = -size.height; x < size.width + size.height; x += spacing * 2) {
      canvas.drawLine(Offset(x, 0), Offset(x + size.height, size.height), paintLines);
    }
    for (double x = -size.height; x < size.width + size.height; x += spacing * 2) {
      canvas.drawLine(Offset(x, size.height), Offset(x + size.height, 0), paintLines);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

// ─── OCEAN WAVE PAINTER ───────────────────────────────────────────────────────
class _OceanWavePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF29B6F6).withOpacity(0.07)
      ..style = PaintingStyle.fill;
    // wave 1
    final path1 = Path();
    path1.moveTo(0, size.height * 0.72);
    path1.quadraticBezierTo(size.width * 0.25, size.height * 0.65, size.width * 0.5, size.height * 0.72);
    path1.quadraticBezierTo(size.width * 0.75, size.height * 0.79, size.width, size.height * 0.72);
    path1.lineTo(size.width, size.height);
    path1.lineTo(0, size.height);
    path1.close();
    canvas.drawPath(path1, paint);
    // wave 2
    final paint2 = Paint()
      ..color = const Color(0xFF0288D1).withOpacity(0.05)
      ..style = PaintingStyle.fill;
    final path2 = Path();
    path2.moveTo(0, size.height * 0.82);
    path2.quadraticBezierTo(size.width * 0.3, size.height * 0.76, size.width * 0.6, size.height * 0.83);
    path2.quadraticBezierTo(size.width * 0.85, size.height * 0.9, size.width, size.height * 0.84);
    path2.lineTo(size.width, size.height);
    path2.lineTo(0, size.height);
    path2.close();
    canvas.drawPath(path2, paint2);
  }
  @override
  bool shouldRepaint(_) => false;
}

// ─── Dashboard Page ───────────────────────────────────────────────────────────
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  // ── State ────────────────────────────────────────────────────────────────
  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;

  late WebSocketChannel channel;
  String androidId = 'unknown';
  File? _profileImage;
  // Banner slider
  int _bannerIndex = 0;
  late PageController _bannerCtrl;
  Timer? _bannerTimer;

  // ── Music Player ──────────────────────────────────────────────────────────
  late final AudioPlayer _audioPlayer;
  bool _musicPlaying = false;
  Offset _cassettePos = const Offset(20, 200);
  late AnimationController _cassetteSpinCtrl;

  int _navIndex   = 0;
  List<Map<String, dynamic>> _notifications = [];
  bool _hasNewNotif = false;
  int onlineUsers = 2789;
  int activeConns = 321;

  // ── Animation controllers ─────────────────────────────────────────────────
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  // Online Users polling
  Timer? _statsTimer;

  // News carousel
  late PageController _newsPageCtrl;
  int _newsPageViewKey = 0;
  double _currentNewsPage = 0.0;

  // Quick Actions carousel
  late PageController _qaPageCtrl;
  double _currentQaPage = 0.0;

  // ── Location ──
  bool _locationLoading = false;
  bool _locationGranted = false;

  // ── Prayer times ──
  String _prayerCity = 'Tangerang';
  Map<String, String> _prayerTimes = {};
  String _nextPrayerLabel = '';
  String _nextPrayerTime  = '';
  bool _prayerLoading = true;

  // ── Hadith ──
  Map<String, dynamic>? _hadith;
  bool _hadithLoading = true;
  int _lastHadithNumber = 0;

  @override
  void initState() {
    super.initState();
    sessionKey  = widget.sessionKey;
    username    = widget.username;
    password    = widget.password;
    role        = widget.role;
    expiredDate = widget.expiredDate;
    listBug     = widget.listBug;
    listDoos    = widget.listDoos;
    newsList    = widget.news;

    // Load saved theme
    getTheme().then((id) { if (mounted) setState(() => _currentThemeId = id); });

    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    // ── Music Player auto-play on open ──────────────────────────────────────
    _cassetteSpinCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat();
    _audioPlayer = AudioPlayer();
    Future.delayed(const Duration(milliseconds: 800), () async {
      if (!mounted) return;
      try {
        await _audioPlayer.setReleaseMode(ReleaseMode.loop);
        await _audioPlayer.play(UrlSource('https://files.catbox.moe/dae19d.mp3'));
        if (mounted) setState(() => _musicPlaying = true);
      } catch (_) {}
    });

    _newsPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _newsPageCtrl.addListener(() {
      if (mounted) setState(() => _currentNewsPage = _newsPageCtrl.page ?? 0.0);
    });

    _qaPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _qaPageCtrl.addListener(() {
      if (mounted) setState(() => _currentQaPage = _qaPageCtrl.page ?? 0.0);
    });

    // Banner slider init
    _bannerCtrl = PageController();
    _bannerTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (mounted && _bannerCtrl.hasClients) {
        final next = (_bannerIndex + 1) % 2;
        _bannerCtrl.animateToPage(next,
            duration: const Duration(milliseconds: 500), curve: Curves.easeInOut);
        setState(() => _bannerIndex = next);
      }
    });

    _initAndroidId();
    _loadProfileImage();
    _detectLocationAndFetchPrayer(); 
    _fetchRandomHadith();
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    _cassetteSpinCtrl.dispose();
    _statsTimer?.cancel();
    _bannerTimer?.cancel();
    _bannerCtrl.dispose();
    channel.sink.close(status.goingAway);
    _fadeCtrl.dispose();
    _pulseCtrl.dispose();
    _newsPageCtrl.dispose();
    _qaPageCtrl.dispose();
    super.dispose();
  }

  // ── Init helpers ──────────────────────────────────────────────────────────
  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path  = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  Future<void> _initAndroidId() async {
    final info = await DeviceInfoPlugin().androidInfo;
    androidId = info.id;
    _connectWS();
  }

  void _connectWS() {
  channel = WebSocketChannel.connect(Uri.parse('$baseUrl'));

  // Kirim validate dulu, stats menyusul setelah delay
  channel.sink.add(jsonEncode({
    'type': 'validate',
    'key': sessionKey,
    'androidId': androidId,
  }));

  channel.stream.listen((event) {
    final data = jsonDecode(event);

    // Setelah validate sukses, baru minta stats pertama kali
    if (data['type'] == 'myInfo' && data['valid'] == true && mounted) {
      channel.sink.add(jsonEncode({'type': 'stats'}));
    }

    if (data['type'] == 'stats' && mounted) {
      setState(() {
        onlineUsers = data['onlineUsers'] ?? 0;
        activeConns = data['activeConnections'] ?? 0;
      });
    }

    // Handle force logout
    if (data['type'] == 'myInfo' && data['valid'] == false && mounted) {
      _handleInvalidSession(data['reason'] ?? 'Session invalid');
    }

    if (data['type'] == 'forceLogout' && mounted) {
      _handleInvalidSession(data['reason'] ?? 'Logged out');
    }
  }, onError: (_) {
    // Reconnect kalau putus
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) _connectWS();
    });
  });

  // Polling setiap 5 detik
  _statsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
    try {
      channel.sink.add(jsonEncode({'type': 'stats'}));
    } catch (_) {}
  });
}

  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  // ── Fetch Prayer Times ────────────────────────────────────────────────────
  Future<void> _fetchPrayerTimes() async {
    if (!mounted) return;
    setState(() => _prayerLoading = true);
    final data = await PrayerTimeService.fetchPrayerTimes(_prayerCity);
    if (!mounted) return;
    if (data.isNotEmpty) {
      final timings = data['data']?['timings'] ?? {};
      final Map<String, String> times = {
        'Subuh'  : timings['Fajr']    ?? '--:--',
        'Dzuhur' : timings['Dhuhr']   ?? '--:--',
        'Ashar'  : timings['Asr']     ?? '--:--',
        'Maghrib': timings['Maghrib'] ?? '--:--',
        'Isya'   : timings['Isha']    ?? '--:--',
      };
      final now = TimeOfDay.now();
      String nextLabel = 'Isya';
      String nextTime  = times['Isya'] ?? '--:--';
      for (final entry in times.entries) {
        final parts = entry.value.split(':');
        if (parts.length >= 2) {
          final h = int.tryParse(parts[0]) ?? 0;
          final m = int.tryParse(parts[1]) ?? 0;
          if (h > now.hour || (h == now.hour && m > now.minute)) {
            nextLabel = entry.key;
            nextTime  = entry.value;
            break;
          }
        }
      }
      setState(() {
        _prayerTimes     = times;
        _nextPrayerLabel = nextLabel;
        _nextPrayerTime  = nextTime;
        _prayerLoading   = false;
      });
    } else {
      setState(() => _prayerLoading = false);
    }
  }

  // ── Detect Location ───────────────────────────────────────────────────────
  Future<void> _detectLocationAndFetchPrayer() async {
    if (!mounted) return;
    setState(() => _locationLoading = true);

    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Tangerang';
          });
          await _fetchPrayerTimes();
        }
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          if (mounted) {
            setState(() {
              _locationLoading = false;
              _prayerCity = 'Tangerang';
            });
            await _fetchPrayerTimes();
          }
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Tangerang';
          });
          await _fetchPrayerTimes();
        }
        return;
      }

      // Ambil koordinat
      final position = await Geolocator.getCurrentPosition(
  desiredAccuracy: LocationAccuracy.medium,
);

      // Konversi koordinat -> nama kota
      final placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );

      if (placemarks.isNotEmpty && mounted) {
        final place = placemarks.first;
        final city = place.subAdministrativeArea?.isNotEmpty == true
            ? place.subAdministrativeArea!
            : place.locality?.isNotEmpty == true
                ? place.locality!
                : place.administrativeArea ?? 'Tangerang';

        setState(() {
          _prayerCity     = city;
          _locationGranted = true;
          _locationLoading = false;
        });

        await _fetchPrayerTimes();

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(children: [
                const Icon(Icons.location_on_rounded, color: Colors.white, size: 16),
                const SizedBox(width: 8),
                Text('Lokasi terdeteksi: $city'),
              ]),
              backgroundColor: kBlue,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              duration: const Duration(seconds: 3),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _locationLoading = false;
          _prayerCity = 'Tangerang';
        });
        await _fetchPrayerTimes();
      }
    }
  }

  // ── Fetch Hadith ──────────────────────────────────────────────────────────
  Future<void> _fetchRandomHadith() async {
    if (!mounted) return;
    setState(() => _hadithLoading = true);
    try {
      int randomNumber;
      do {
        randomNumber = Random().nextInt(100) + 1;
      } while (randomNumber == _lastHadithNumber);
      _lastHadithNumber = randomNumber;
      final response = await http
          .get(Uri.parse('https://api.hadith.gading.dev/books/muslim/$randomNumber'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200 && mounted) {
        setState(() { _hadith = json.decode(response.body); _hadithLoading = false; });
      } else {
        if (mounted) setState(() => _hadithLoading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _hadithLoading = false);
    }
  }

  // ── Change City Dialog ────────────────────────────────────────────────────
  void _showChangeCityDialog() {
    final ctrl = TextEditingController(text: _prayerCity);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('Ganti Lokasi',
            style: TextStyle(color: kWhite, fontFamily: 'Orbitron', fontSize: 14)),
        content: TextField(
          controller: ctrl,
          style: const TextStyle(color: kWhite),
          decoration: InputDecoration(
            hintText: 'Nama kota (misal: Jakarta)',
            hintStyle: const TextStyle(color: kWhite54),
            filled: true, fillColor: kBg,
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            prefixIcon: const Icon(Icons.location_city_rounded, color: kBlue),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal', style: TextStyle(color: kWhite54))),
          ElevatedButton(
            onPressed: () {
              if (ctrl.text.trim().isNotEmpty) {
                setState(() {
                  _prayerCity = ctrl.text.trim();
                  _locationGranted = false; // reset icon lokasi
                });
                _fetchPrayerTimes();
                Navigator.pop(context);
              }
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: kBlue,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            child: const Text('Simpan',
                style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  // ── Hadith Full Dialog ────────────────────────────────────────────────────
  void _showHadithFullDialog(String arabic, String indo, String source, String number, String grade) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
        child: Container(
          decoration: BoxDecoration(
            color: kCard, borderRadius: BorderRadius.circular(24),
            border: Border.all(color: kBlue.withOpacity(0.3)),
            boxShadow: [
              BoxShadow(color: kBlue.withOpacity(0.08), blurRadius: 30, spreadRadius: 2),
              BoxShadow(color: Colors.black.withOpacity(0.6), blurRadius: 20, offset: const Offset(0, 8)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                  color: kBlue.withOpacity(0.08),
                  border: Border(bottom: BorderSide(color: kBorder.withOpacity(0.5))),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 42, height: 42,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: kBlue.withOpacity(0.2)),
                      child: const Icon(Icons.menu_book_rounded, color: kBlue, size: 22),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('HADITH LENGKAP',
                            style: TextStyle(color: kWhite, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'Orbitron')),
                        Text(grade, style: const TextStyle(color: kBlue, fontSize: 11)),
                      ]),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        width: 34, height: 34,
                        decoration: BoxDecoration(shape: BoxShape.circle, color: kWhite.withOpacity(0.08)),
                        child: const Icon(Icons.close_rounded, color: kWhite54, size: 18),
                      ),
                    ),
                  ],
                ),
              ),
              ConstrainedBox(
                constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.62),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: double.infinity, padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: const Color(0xFF18181B),
                          border: Border.all(color: kBorder.withOpacity(0.3)),
                        ),
                        child: Text(arabic,
                            textAlign: TextAlign.right, textDirection: TextDirection.rtl,
                            style: const TextStyle(color: kWhite, fontSize: 19, height: 2.2)),
                      ),
                      const SizedBox(height: 14),
                      Row(children: [
                        Container(width: 3, height: 18,
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(2), color: kBlue)),
                        const SizedBox(width: 8),
                        const Text('ARTINYA:', style: TextStyle(color: kBlue, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                      ]),
                      const SizedBox(height: 10),
                      Container(
                        width: double.infinity, padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: const Color(0xFF111113),
                          border: Border.all(color: kBorder.withOpacity(0.2)),
                        ),
                        child: Text(indo,
                            style: const TextStyle(color: kWhite, fontSize: 14, fontStyle: FontStyle.italic, height: 1.8)),
                      ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: kBlue.withOpacity(0.5)),
                          color: kBlue.withOpacity(0.08),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          const Icon(Icons.receipt_long_rounded, color: kBlue, size: 14),
                          const SizedBox(width: 6),
                          Text('${source.isNotEmpty ? source : "Muslim"} #$number',
                              style: const TextStyle(color: kBlue, fontSize: 12, fontWeight: FontWeight.bold)),
                        ]),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('⚠️ Session Expired', style: TextStyle(color: kWhite)),
        content: Text(message, style: const TextStyle(color: kWhite54)),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false),
            child: const Text('OK', style: TextStyle(color: kBlue)),
          ),
        ],
      ),
    );
  }

  // ── Navigation ────────────────────────────────────────────────────────────
  void _onNavTap(int index) {
    setState(() => _navIndex = index);
    if (index == 0) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_newsPageCtrl.hasClients) {
          setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
          _newsPageCtrl.jumpToPage(0);
        }
      });
    }
  }

  void _onDrawerNav(int index) {
    Widget page;
    switch (index) {
      case 1: page = SellerPage(keyToken: sessionKey); break;
      case 2: page = AdminPage(sessionKey: sessionKey); break;
      case 3: page = OwnerPage(sessionKey: sessionKey, username: username); break;
      default: return;
    }
    Navigator.pop(context);
    Navigator.push(context, MaterialPageRoute(builder: (_) => page)).then((_) {
      if (mounted) {
        setState(() => _navIndex = 0);
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_newsPageCtrl.hasClients) {
            setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
            _newsPageCtrl.jumpToPage(0);
          }
        });
      }
    });
  }

  // ── Current Page ──────────────────────────────────────────────────────────
  Widget _buildCurrentPage() {
    switch (_navIndex) {
      case 1:
        return _buildWhatsAppMenuPage();
      case 2:
        return _buildToolsMenuPage();
      case 3:
        return ChatRoomPage(username: username);
      case 4:
        return _buildTemaPage();
      case 0:
      default:
        return _buildHomePage();
    }
  }

  // ── TEMA / WARNA PAGE ──────────────────────────────────────────────────────
  int _currentThemeId = 1; // 1=putih-biru, 2=hitam-putih, 3=merah-cyan, 4=biru-hijau

  static const _themes = [
    {'id': 1, 'name': 'PUTIH BIRU', 'sub': 'Normal', 'c1': Color(0xFF0077C2), 'c2': Color(0xFF29B6F6), 'bg': Color(0xFFF0F8FF)},
    {'id': 2, 'name': 'HITAM PUTIH', 'sub': 'Dark', 'c1': Color(0xFF111111), 'c2': Color(0xFFE0E0E0), 'bg': Color(0xFF0A0A0A)},
    {'id': 3, 'name': 'MERAH CYAN', 'sub': 'Fire & Ice', 'c1': Color(0xFFEF4444), 'c2': Color(0xFF00FFF7), 'bg': Color(0xFF150008)},
    {'id': 4, 'name': 'BIRU HIJAU', 'sub': 'Ocean', 'c1': Color(0xFF1565C0), 'c2': Color(0xFF22C55E), 'bg': Color(0xFF021018)},
  ];

  Widget _buildTemaPage() {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('UBAH TEMA WARNA', style: TextStyle(
          color: Colors.white, fontFamily: 'Orbitron', fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 2,
        )),
        const SizedBox(height: 6),
        const Text('Pilih tema — perubahan permanen sampai kamu ganti lagi', style: TextStyle(
          color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 11,
        )),
        const SizedBox(height: 24),

        ...(_themes.map((t) {
          final id = t['id'] as int;
          final c1 = t['c1'] as Color;
          final c2 = t['c2'] as Color;
          final bg = t['bg'] as Color;
          final isActive = _currentThemeId == id;

          return GestureDetector(
            onTap: () async {
              setState(() => _currentThemeId = id);
              await setTheme(id);
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text('Tema "${t['name']}" aktif!',
                    style: const TextStyle(fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)),
                  backgroundColor: c1,
                  duration: const Duration(seconds: 2),
                ));
              }
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              margin: const EdgeInsets.only(bottom: 14),
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: isActive ? c1.withOpacity(0.12) : const Color(0xFF0D1B2E),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: isActive ? c1 : Colors.white10,
                  width: isActive ? 2 : 1,
                ),
                boxShadow: isActive ? [BoxShadow(color: c1.withOpacity(0.25), blurRadius: 20)] : [],
              ),
              child: Row(children: [
                // Color preview
                Container(
                  width: 56, height: 56,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    gradient: LinearGradient(colors: [c1, c2], begin: Alignment.topLeft, end: Alignment.bottomRight),
                    boxShadow: [BoxShadow(color: c1.withOpacity(0.4), blurRadius: 10)],
                  ),
                  child: isActive ? const Icon(Icons.check_rounded, color: Colors.white, size: 26) : null,
                ),
                const SizedBox(width: 16),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(t['name'] as String, style: TextStyle(
                    color: isActive ? c1 : Colors.white70,
                    fontFamily: 'Orbitron', fontSize: 13, fontWeight: FontWeight.w900,
                  )),
                  const SizedBox(height: 4),
                  Text(t['sub'] as String, style: const TextStyle(
                    color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 11,
                  )),
                ])),
                // Mini preview
                Column(children: [
                  Container(width: 18, height: 18, decoration: BoxDecoration(color: c1, borderRadius: BorderRadius.circular(4))),
                  const SizedBox(height: 4),
                  Container(width: 18, height: 18, decoration: BoxDecoration(color: c2, borderRadius: BorderRadius.circular(4))),
                  const SizedBox(height: 4),
                  Container(width: 18, height: 18, decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: Colors.white12))),
                ]),
              ]),
            ),
          );
        }).toList()),

        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFF0D1B2E),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.white10),
          ),
          child: const Row(children: [
            Icon(Icons.info_outline_rounded, color: Colors.white24, size: 16),
            SizedBox(width: 10),
            Expanded(child: Text('Tema tersimpan permanen. Restart app untuk full effect di semua komponen.',
              style: TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 10, height: 1.4))),
          ]),
        ),
      ]),
    );
  }

  // ── TOOLS MENU PAGE (vertikal list kaya foto 4) ───────────────────────────
  Widget _buildToolsMenuPage() {
    final toolItems = [
      {'icon': Icons.terminal_rounded, 'label': 'Termux', 'sub': 'Guide & Scripts', 'color': const Color(0xFF1565C0),
       'onTap': () => Navigator.push(context, _slideRoute(BugSenderPage(sessionKey: sessionKey, username: username, role: role)))},
      {'icon': Icons.dns_rounded, 'label': 'VPS Tool', 'sub': 'Server Manager', 'color': const Color(0xFFD32F2F),
       'onTap': () => Navigator.push(context, _slideRoute(ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos)))},
      {'icon': Icons.sports_esports_rounded, 'label': 'Game Hub', 'sub': 'Mini Games', 'color': const Color(0xFFE65100),
       'onTap': () => Navigator.push(context, _slideRoute(const GamePage()))},
      {'icon': Icons.chat_bubble_rounded, 'label': 'Sadap WA', 'sub': 'Pairing + Chat Log', 'color': const Color(0xFF128C7E),
       'onTap': () => Navigator.push(context, _slideRoute(SadapWhatsappPage(sessionKey: sessionKey, username: username)))},
      {'icon': Icons.send_rounded, 'label': 'Blast Message', 'sub': 'Mass Sender', 'color': const Color(0xFF6A1B9A),
       'onTap': () {}},
      {'icon': Icons.bug_report_rounded, 'label': 'Bug Sender', 'sub': 'Crash & Freeze', 'color': const Color(0xFF00838F),
       'onTap': () => Navigator.push(context, _slideRoute(BugSenderPage(sessionKey: sessionKey, username: username, role: role)))},
    ];

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(14, 16, 14, 100),
      itemCount: toolItems.length + 1,
      itemBuilder: (ctx, i) {
        if (i == 0) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('MENU TOOLS', style: TextStyle(
                color: Colors.white, fontFamily: 'Orbitron', fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 2,
              )),
              const SizedBox(height: 4),
              const Text('Semua alat tersedia di sini', style: TextStyle(
                color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 11,
              )),
            ]),
          );
        }
        final item = toolItems[i - 1];
        final color = item['color'] as Color;
        return GestureDetector(
          onTap: item['onTap'] as VoidCallback,
          child: Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [color.withOpacity(0.15), color.withOpacity(0.05)],
                begin: Alignment.centerLeft, end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: color.withOpacity(0.35)),
              boxShadow: [BoxShadow(color: color.withOpacity(0.12), blurRadius: 10, offset: const Offset(0, 4))],
            ),
            child: Row(children: [
              Container(
                width: 50, height: 50,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: color.withOpacity(0.4)),
                ),
                child: Icon(item['icon'] as IconData, color: color, size: 24),
              ),
              const SizedBox(width: 16),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(item['label'] as String, style: TextStyle(
                  color: color, fontFamily: 'Orbitron', fontSize: 13, fontWeight: FontWeight.w900,
                )),
                const SizedBox(height: 3),
                Text(item['sub'] as String, style: const TextStyle(
                  color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 11,
                )),
              ])),
              Icon(Icons.arrow_forward_ios_rounded, color: color.withOpacity(0.5), size: 14),
            ]),
          ),
        );
      },
    );
  }

  // ── WhatsApp BUG Menu ─────────────────────────────────────────────────────
  Widget _buildWhatsAppMenuPage() {
    final menuOptions = [
      {
        'title': 'VICIOUSX BUG',
        'subtitle': 'Bug tanpa custom',
        'description': 'Gunakan langsung tanpa custom delay dan loops',
        'icon': Icons.bug_report_rounded,
        'iconColor': const Color(0xFF1565C0),
        'gradient': [const Color(0xFF0A2472), const Color(0xFF1565C0)],
        'badge': 'RECOMMENDED',
        'badgeColor': const Color(0xFF1565C0),
        'features': ['Mudah digunakan', 'Function terbaru', 'All work gacor', 'VICIOUSX BUG'],
        'onTap': () => Navigator.push(context, _slideRoute(HomePage(
          username: username, password: password, listBug: listBug,
          role: role, expiredDate: expiredDate, sessionKey: sessionKey,
        ))),
      },
      {
        'title': 'TOOLS',
        'subtitle': 'Alat bantu system',
        'description': 'Kumpulan tools OSINT dan utilities lengkap',
        'icon': Icons.build_circle_rounded,
        'iconColor': const Color(0xFF6366F1),
        'gradient': [const Color(0xFF1E1B4B), const Color(0xFF6366F1)],
        'badge': 'TOOLS',
        'badgeColor': const Color(0xFF6366F1),
        'features': ['OSINT tools', 'IP scanner', 'Port scanner', 'Utilities'],
        'onTap': () => Navigator.push(context, _slideRoute(ToolsPage(
          sessionKey: sessionKey, userRole: role, listDoos: listDoos,
        ))),
      },
      {
        'title': 'CUSTOM BUG',
        'subtitle': 'Custom delay & loops',
        'description': 'Setting custom delay dan jumlah loops sebelum kirim',
        'icon': Icons.tune_rounded,
        'iconColor': const Color(0xFFEC4899),
        'gradient': [const Color(0xFF831843), const Color(0xFFEC4899)],
        'badge': 'CUSTOM',
        'badgeColor': const Color(0xFFEC4899),
        'features': ['Custom delay', 'Custom loops', 'Target spesifik', 'Kontrol penuh'],
        'onTap': () => Navigator.push(context, _slideRoute(CustomPayloadPage(
          sessionKey: sessionKey, role: role, listBug: listBug,
          username: username, password: password, expiredDate: expiredDate,
        ))),
      },
      {
        'title': 'BUG GROUP',
        'subtitle': 'Kirim ke grup WhatsApp',
        'description': 'Target grup WhatsApp dengan berbagai bug pilihan',
        'icon': Icons.group_rounded,
        'iconColor': const Color(0xFF22C55E),
        'gradient': [const Color(0xFF14532D), const Color(0xFF22C55E)],
        'badge': 'GROUP',
        'badgeColor': const Color(0xFF22C55E),
        'features': ['Target grup WA', 'Multi sender', 'Bug pilihan', 'Efektif'],
        'onTap': () => Navigator.push(context, _slideRoute(BugGroupPage(
          sessionKey: sessionKey, role: role,
        ))),
      },
    ];

    return FadeTransition(
      opacity: _fadeAnim,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Info Akun di atas menu bug ─────────────────────────────────
          Container(
            margin: const EdgeInsets.fromLTRB(14, 14, 14, 0),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF0054A6), Color(0xFF29B6F6)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(18),
              boxShadow: [BoxShadow(color: kBlue.withOpacity(0.3), blurRadius: 16, offset: const Offset(0, 6))],
            ),
            child: Row(children: [
              Container(
                width: 50, height: 50,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white.withOpacity(0.5), width: 2),
                  boxShadow: [BoxShadow(color: Colors.white.withOpacity(0.2), blurRadius: 8)],
                ),
                child: ClipOval(
                  child: _profileImage != null
                      ? Image.file(_profileImage!, fit: BoxFit.cover)
                      : Image.asset('assets/images/logo.png', fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const Icon(Icons.person_rounded, color: Colors.white, size: 24)),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Whatsapp', style: TextStyle(color: Colors.white70, fontSize: 11, fontFamily: 'Orbitron')),
                Text(username, style: const TextStyle(
                  color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900, fontFamily: 'Orbitron',
                )),
                const SizedBox(height: 3),
                Row(children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.white.withOpacity(0.35)),
                    ),
                    child: Text(role.toUpperCase(), style: const TextStyle(
                      color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', letterSpacing: 1,
                    )),
                  ),
                  const SizedBox(width: 6),
                  Text('Exp: $expiredDate', style: const TextStyle(color: Colors.white60, fontSize: 9)),
                ]),
              ])),
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.15),
                  border: Border.all(color: Colors.white.withOpacity(0.3)),
                ),
                child: const Icon(Icons.bug_report_rounded, color: Colors.white, size: 20),
              ),
            ]),
          ),
          const SizedBox(height: 12),
          // ── Label geser ───────────────────────────────────────────────
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 18),
            child: Row(children: [
              Icon(Icons.swipe_rounded, color: Color(0xFF0077C2), size: 14),
              SizedBox(width: 6),
              Text('GESER PILIH MENU', style: TextStyle(
                color: Color(0xFF0077C2), fontSize: 10, fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron', letterSpacing: 1,
              )),
            ]),
          ),
          const SizedBox(height: 10),
          // ── Horizontal swipe menu ─────────────────────────────────────
          Expanded(
            child: PageView.builder(
              controller: PageController(viewportFraction: 0.88),
              physics: const BouncingScrollPhysics(),
              itemCount: menuOptions.length,
              itemBuilder: (ctx, i) {
                final opt = menuOptions[i];
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
                  child: GestureDetector(
                    onTap: opt['onTap'] as VoidCallback,
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: (opt['gradient'] as List).cast<Color>(),
                          begin: Alignment.topLeft, end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(24),
                        boxShadow: [BoxShadow(
                          color: (opt['iconColor'] as Color).withOpacity(0.3),
                          blurRadius: 20, offset: const Offset(0, 8),
                        )],
                      ),
                      padding: const EdgeInsets.all(24),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Container(
                            width: 56, height: 56,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white.withOpacity(0.15),
                              border: Border.all(color: Colors.white.withOpacity(0.3)),
                            ),
                            child: Icon(opt['icon'] as IconData, color: Colors.white, size: 28),
                          ),
                          const SizedBox(width: 14),
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(opt['title'] as String, style: const TextStyle(
                              color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.w900,
                              fontSize: 16, letterSpacing: 0.5,
                            )),
                            const SizedBox(height: 3),
                            Text(opt['subtitle'] as String, style: TextStyle(
                              color: Colors.white.withOpacity(0.75), fontSize: 12,
                            )),
                          ])),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.18),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: Colors.white.withOpacity(0.3)),
                            ),
                            child: Text(opt['badge'] as String, style: const TextStyle(
                              color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold, fontFamily: 'Orbitron',
                            )),
                          ),
                        ]),
                        const Spacer(),
                        Text(opt['description'] as String, style: TextStyle(
                          color: Colors.white.withOpacity(0.7), fontSize: 13, height: 1.5,
                        )),
                        const SizedBox(height: 14),
                        Wrap(
                          spacing: 8, runSpacing: 6,
                          children: (opt['features'] as List<String>).map((f) => Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.12),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: Colors.white.withOpacity(0.2)),
                            ),
                            child: Text(f, style: const TextStyle(color: Colors.white, fontSize: 11)),
                          )).toList(),
                        ),
                        const Spacer(),
                        Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                          const Text('BUKA', style: TextStyle(
                            color: Colors.white, fontFamily: 'Orbitron', fontSize: 12,
                            fontWeight: FontWeight.bold, letterSpacing: 2,
                          )),
                          const SizedBox(width: 8),
                          Container(
                            width: 32, height: 32,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white.withOpacity(0.2),
                            ),
                            child: const Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 16),
                          ),
                        ]),
                      ]),
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 8),
          // page dots
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(menuOptions.length, (i) => Container(
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: 6, height: 6,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: kBlue.withOpacity(0.3),
              ),
            )),
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }

  // ── HOME PAGE ─────────────────────────────────────────────────────────────
  Widget _buildHomePage() {
    return FadeTransition(
      opacity: _fadeAnim,
      child: Stack(
        children: [
          SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildBannerVideo(),
                const SizedBox(height: 14),
                _buildVoltgramSection(),
                const SizedBox(height: 14),
                _buildWelcomeCard(),
                const SizedBox(height: 14),
                _buildQuickActionsSection(),
                const SizedBox(height: 14),
                _buildWorldNewsSection(),
                const SizedBox(height: 14),
                _buildVoltexInfoCard(),
                const SizedBox(height: 14),
                _buildPrayerSection(),
                const SizedBox(height: 14),
                _buildHadithSection(),
                const SizedBox(height: 24),
                Center(child: Text('VICIOUSX EXECUTIVE',
                  style: TextStyle(color: const Color(0xFF0077C2).withOpacity(0.25), fontSize: 13, letterSpacing: 4, fontFamily: 'Orbitron'))),
                const SizedBox(height: 80),
              ],
            ),
          ),
          // ── Floating Cassette Music Button ────────────────────────────
          _buildFloatingCassette(),
        ],
      ),
    );
  }

  // ── Floating Cassette ─────────────────────────────────────────────────────
  Widget _buildFloatingCassette() {
    return Positioned(
      left: _cassettePos.dx,
      top: _cassettePos.dy,
      child: GestureDetector(
        onPanUpdate: (d) => setState(() => _cassettePos += d.delta),
        onTap: () => _showMusicControl(),
        child: AnimatedBuilder(
          animation: _cassetteSpinCtrl,
          builder: (_, child) => Transform.rotate(
            angle: _musicPlaying ? _cassetteSpinCtrl.value * 2 * math.pi : 0,
            child: child,
          ),
          child: Container(
            width: 58, height: 58,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: _musicPlaying
                    ? [const Color(0xFF0054A6), const Color(0xFF29B6F6)]
                    : [const Color(0xFF546E7A), const Color(0xFF37474F)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: (_musicPlaying ? const Color(0xFF0077C2) : Colors.black).withOpacity(0.4),
                  blurRadius: _musicPlaying ? 16 : 8, spreadRadius: 1,
                ),
              ],
            ),
            child: Stack(alignment: Alignment.center, children: [
              // Cassette reel circles
              Positioned(left: 10, top: 18,
                child: Container(width: 10, height: 10, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.3), border: Border.all(color: Colors.white54, width: 1)))),
              Positioned(right: 10, top: 18,
                child: Container(width: 10, height: 10, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.3), border: Border.all(color: Colors.white54, width: 1)))),
              Icon(_musicPlaying ? Icons.music_note_rounded : Icons.music_off_rounded, color: Colors.white, size: 22),
            ]),
          ),
        ),
      ),
    );
  }

  void _showMusicControl() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        margin: const EdgeInsets.all(14),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: const Color(0xFF0D1B3E),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: const Color(0xFF29B6F6).withOpacity(0.3)),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 16),
          const Icon(Icons.music_note_rounded, color: Color(0xFF29B6F6), size: 40),
          const SizedBox(height: 8),
          const Text('VICIOUSX BGM', style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 3)),
          const SizedBox(height: 4),
          const Text('dae19d.mp3', style: TextStyle(color: Colors.white54, fontSize: 11)),
          const SizedBox(height: 20),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            GestureDetector(
              onTap: () async {
                if (_musicPlaying) {
                  await _audioPlayer.pause();
                  if (mounted) setState(() { _musicPlaying = false; _cassetteSpinCtrl.stop(); });
                } else {
                  await _audioPlayer.resume();
                  if (mounted) setState(() { _musicPlaying = true; _cassetteSpinCtrl.repeat(); });
                }
                if (mounted) Navigator.pop(context);
              },
              child: Container(
                width: 64, height: 64,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(colors: _musicPlaying
                      ? [const Color(0xFFD32F2F), const Color(0xFFB71C1C)]
                      : [const Color(0xFF0054A6), const Color(0xFF29B6F6)]),
                  boxShadow: [BoxShadow(color: (_musicPlaying ? Colors.red : const Color(0xFF0077C2)).withOpacity(0.4), blurRadius: 16)],
                ),
                child: Icon(_musicPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded, color: Colors.white, size: 32),
              ),
            ),
          ]),
          const SizedBox(height: 12),
          Text(_musicPlaying ? 'Musik Sedang Diputar' : 'Musik Dijeda',
            style: TextStyle(color: _musicPlaying ? const Color(0xFF29B6F6) : Colors.white54, fontSize: 12)),
        ]),
      ),
    );
  }

  // ── World News (GNews API real) ───────────────────────────────────────────
  List<Map<String, dynamic>> _worldNews = [];
  bool _newsLoading = false;

  Future<void> _fetchWorldNews() async {
    if (_newsLoading) return;
    setState(() => _newsLoading = true);
    try {
      // RSS2JSON proxy — free, no key needed, reliable
      final r = await http.get(Uri.parse(
        'https://api.rss2json.com/v1/api.json?rss_url=https%3A%2F%2Fnews.google.com%2Frss%3Fhl%3Did%26gl%3DID%26ceid%3DID%3Aid&api_key=public&count=10',
      )).timeout(const Duration(seconds: 12));
      if (r.statusCode == 200) {
        final d = json.decode(r.body);
        final items = List<dynamic>.from(d['items'] ?? []);
        final arts = items.map<Map<String, dynamic>>((e) => {
          'title': e['title'] ?? '',
          'url': e['link'] ?? '',
          'image': e['thumbnail'],
          'source': {'name': e['author'] ?? 'Google News'},
        }).toList();
        if (mounted) setState(() { _worldNews = arts; _newsLoading = false; });
        return;
      }
    } catch (_) {}
    // Fallback: headline statis
    try {
      if (mounted) setState(() {
        _worldNews = [
          {'title': 'Berita sedang dimuat ulang...', 'url': '', 'source': {'name': 'VICIOUSX'}, 'image': null},
        ];
      });
    } catch (_) {}
    if (mounted) setState(() => _newsLoading = false);
  }

  Widget _buildWorldNewsSection() {
    if (_worldNews.isEmpty && !_newsLoading) _fetchWorldNews();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Header
        Row(children: [
          Container(width: 8, height: 8, decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFF2E7D32))),
          const SizedBox(width: 8),
          const Text('BERITA DUNIA', style: TextStyle(color: Color(0xFF0D2137), fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 1)),
          const SizedBox(width: 8),
          const Text('REAL • ANTI HOAX', style: TextStyle(color: Color(0xFF2E7D32), fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
          const Spacer(),
          if (_worldNews.isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(color: const Color(0xFF2E7D32).withOpacity(0.1), borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFF2E7D32).withOpacity(0.3))),
              child: Text('${_worldNews.length} Berita', style: const TextStyle(color: Color(0xFF2E7D32), fontSize: 10, fontWeight: FontWeight.bold)),
            ),
        ]),
        const SizedBox(height: 12),
        if (_newsLoading)
          const Center(child: CircularProgressIndicator(color: Color(0xFF0077C2)))
        else if (_worldNews.isEmpty)
          Container(
            height: 80, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
            child: const Center(child: Text('Memuat berita...', style: TextStyle(color: Color(0xFF4A7FA5)))),
          )
        else
          SizedBox(
            height: 200,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              itemCount: _worldNews.length,
              itemBuilder: (ctx, i) => _buildNewsCard(_worldNews[i]),
            ),
          ),
      ]),
    );
  }

  Widget _buildNewsCard(Map<String, dynamic> article) {
    final title = article['title'] ?? article['name'] ?? 'Berita';
    final source = article['source']?['name'] ?? '';
    final url = article['url'] ?? '';
    final img = article['image'] ?? article['urlToImage'];
    return GestureDetector(
      onTap: () => _openUrl(url),
      child: Container(
        width: 200,
        margin: const EdgeInsets.only(right: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 10, offset: const Offset(0, 4))],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
            child: img != null
                ? Image.network(img, height: 100, width: 200, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(height: 100, color: const Color(0xFF0077C2).withOpacity(0.15), child: const Icon(Icons.article_rounded, color: Color(0xFF0077C2), size: 32)))
                : Container(height: 100, color: const Color(0xFF0077C2).withOpacity(0.12), child: const Center(child: Icon(Icons.article_rounded, color: Color(0xFF0077C2), size: 32))),
          ),
          Padding(
            padding: const EdgeInsets.all(10),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              if (source.isNotEmpty) Text(source, style: const TextStyle(color: Color(0xFF0077C2), fontSize: 9, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
              const SizedBox(height: 4),
              Text(title, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFF0D2137), fontSize: 11, fontWeight: FontWeight.w600, height: 1.3)),
            ]),
          ),
        ]),
      ),
    );
  }

  // ── VOLTEX Info Card (deskripsi + TokTok/owner) ───────────────────────────
  Widget _buildVoltexInfoCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF1A0B00), Color(0xFF4A1800), Color(0xFF2D1000)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: const Color(0xFFFF6D00).withOpacity(0.4), width: 1.5),
          boxShadow: [BoxShadow(color: const Color(0xFFFF6D00).withOpacity(0.2), blurRadius: 24, offset: const Offset(0, 8))],
        ),
        child: Column(children: [
          // ─ Header ─────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
            child: Row(children: [
              // Animated logo ring
              Container(
                width: 58, height: 58,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const SweepGradient(colors: [Color(0xFFFF6D00), Color(0xFFFFAB40), Color(0xFFFF6D00)]),
                  boxShadow: [BoxShadow(color: const Color(0xFFFF6D00).withOpacity(0.5), blurRadius: 12)],
                ),
                child: Padding(
                  padding: const EdgeInsets.all(3),
                  child: Container(
                    decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFF1A0B00)),
                    child: ClipOval(child: Image.asset('assets/images/logo.png', fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const Icon(Icons.bolt_rounded, color: Color(0xFFFF6D00), size: 28))),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('CONNECT WITH', style: TextStyle(
                    color: Colors.white38, fontFamily: 'Orbitron', fontSize: 9, letterSpacing: 2,
                  )),
                  const Text('VICIOUSX TEAM', style: TextStyle(
                    color: Color(0xFFFF6D00), fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 18, letterSpacing: 1,
                  )),
                ]),
              ),
              // notification dot
              Container(
                width: 10, height: 10,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFF22C55E),
                  boxShadow: [BoxShadow(color: const Color(0xFF22C55E).withOpacity(0.6), blurRadius: 6)],
                ),
              ),
            ]),
          ),

          const SizedBox(height: 16),
          // ─ Divider ────────────────────────────────────────────
          Container(height: 1, color: const Color(0xFFFF6D00).withOpacity(0.2)),
          const SizedBox(height: 16),

          // ─ 3 Channel Buttons (kaya foto 3) ────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(children: [
              // TikTok
              Expanded(child: _buildChannelBtn(
                icon: Icons.music_note_rounded,
                label: 'TikTok',
                color: const Color(0xFFEE1D52),
                onTap: () => _openUrl('https://www.tiktok.com/@danzz0122'),
              )),
              const SizedBox(width: 10),
              // Pemilik
              Expanded(child: _buildChannelBtn(
                icon: Icons.star_rounded,
                label: 'Pemilik',
                color: const Color(0xFFFF6D00),
                onTap: () => _openUrl('https://t.me/danzz0122'),
              )),
              const SizedBox(width: 10),
              // Developer
              Expanded(child: _buildChannelBtn(
                icon: Icons.send_rounded,
                label: 'Channel',
                color: const Color(0xFF0088CC),
                onTap: () => _openUrl('https://t.me/Viciousx_information'),
              )),
            ]),
          ),
          const SizedBox(height: 14),

          // ─ Info text ─────────────────────────────────────────
          Container(
            padding: const EdgeInsets.all(14),
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            decoration: BoxDecoration(
              color: const Color(0xFF2A1200),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFFFF6D00).withOpacity(0.2)),
            ),
            child: Row(children: [
              const Icon(Icons.info_outline_rounded, color: Color(0xFFFF6D00), size: 16),
              const SizedBox(width: 10),
              const Expanded(child: Text(
                'Selalu nantikan project terbaru dari VICIOUSX TEAM',
                style: TextStyle(color: Colors.white60, fontFamily: 'ShareTechMono', fontSize: 11, height: 1.4),
              )),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _buildChannelBtn({required IconData icon, required String label, required Color color, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 70,
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.4)),
          boxShadow: [BoxShadow(color: color.withOpacity(0.1), blurRadius: 8)],
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(
            width: 34, height: 34,
            decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(0.2)),
            child: Icon(icon, color: color, size: 18),
          ),
          const SizedBox(height: 4),
          Text(label, style: TextStyle(color: color, fontFamily: 'Orbitron', fontSize: 9, fontWeight: FontWeight.bold)),
        ]),
      ),
    );
  }

  Widget _buildOwnerChip(String name, IconData icon, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
    decoration: BoxDecoration(
      color: color.withOpacity(0.15),
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: color.withOpacity(0.4)),
    ),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, color: color, size: 16),
      const SizedBox(width: 6),
      Text(name, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'Orbitron')),
    ]),
  );

  // ── VOLTGRAM Section ─────────────────────────────────────────────────────
  List<Map<String, dynamic>> _voltgramUsers = []; // kept for compat, not used in UI

  Future<void> _fetchVoltgramUsers() async {
    // No longer fetches user list — only status uploads are shown
  }

  Widget _buildVoltgramSection() {
    return GestureDetector(
      onTap: () => Navigator.push(context, _slideRoute(VoltgramPage(sessionKey: sessionKey, username: username))),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF0054A6), Color(0xFF0077C2), Color(0xFF29B6F6)],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [BoxShadow(color: const Color(0xFF0077C2).withOpacity(0.3), blurRadius: 14, offset: const Offset(0, 6))],
          ),
          child: Row(children: [
            Container(
              width: 52, height: 52,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withOpacity(0.2),
                border: Border.all(color: Colors.white.withOpacity(0.5), width: 2),
              ),
              child: const Icon(Icons.add_a_photo_rounded, color: Colors.white, size: 24),
            ),
            const SizedBox(width: 14),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('VICIGRAM', style: TextStyle(
                color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 2,
              )),
              SizedBox(height: 3),
              Text('Upload status, foto & video', style: TextStyle(
                color: Colors.white70, fontFamily: 'ShareTechMono', fontSize: 11,
              )),
            ])),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Text('BUKA', style: TextStyle(
                color: Color(0xFF0054A6), fontFamily: 'Orbitron', fontSize: 10, fontWeight: FontWeight.w900,
              )),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _buildVoltgramAvatar({bool isAdd = false, String initial = '', Color color = Colors.blue}) {
    return const SizedBox.shrink(); // legacy stub
  }

  // ── Banner Video ──────────────────────────────────────────────────────────
  Widget _buildBannerVideo() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: SizedBox(
              height: 190, width: double.infinity,
              child: PageView.builder(
                controller: _bannerCtrl,
                onPageChanged: (i) => setState(() => _bannerIndex = i),
                itemCount: 2,
                itemBuilder: (ctx, i) => Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.asset(
                      i == 0 ? 'assets/images/ornes_1.png' : 'assets/images/ornes_2.png',
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: const Color(0xFF09090B),
                        child: Center(child: Icon(Icons.image_rounded, color: kBlue, size: 48)),
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.black.withOpacity(0.6), Colors.transparent, Colors.black.withOpacity(0.3)],
                          begin: Alignment.bottomCenter, end: Alignment.topCenter,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          // Dots indicator + text
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.anchor_rounded, color: kBlue.withOpacity(0.5), size: 16),
              const SizedBox(width: 8),
              Text('VICIOUSX', style: TextStyle(
                color: kBlue, fontSize: 14, fontFamily: 'Orbitron',
                letterSpacing: 2, fontWeight: FontWeight.bold,
              )),
              const SizedBox(width: 8),
              Icon(Icons.anchor_rounded, color: kBlue.withOpacity(0.5), size: 16),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(2, (i) => AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: _bannerIndex == i ? 20 : 6, height: 6,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(3),
                color: _bannerIndex == i ? kBlue : kBorder,
              ),
            )),
          ),
        ],
      ),
    );
  }

  // ── Welcome Card ──────────────────────────────────────────────────────────
  Widget _buildWelcomeCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: const Color(0xFF1C1C2E).withOpacity(0.88), // dark semi-transparan kaya foto
          border: Border.all(color: const Color(0xFF29B6F6).withOpacity(0.25)),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.35), blurRadius: 20, offset: const Offset(0, 8)),
          ],
        ),
        child: Stack(
          children: [
            Positioned.fill(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: Image.asset('assets/images/user_card.jpg', fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const SizedBox()),
              ),
            ),
            Positioned.fill(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.black.withOpacity(0.65),
                        Colors.black.withOpacity(0.5),
                      ],
                      begin: Alignment.topLeft, end: Alignment.bottomRight,
                    ),
                  ),
                ),
              ),
            ),
            Column(
              children: [
                Row(
                  children: [
                    ScaleTransition(
                      scale: _pulseAnim,
                      child: Container(
                        width: 58, height: 58,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const LinearGradient(colors: [Color(0xFF1565C0), Color(0xFF0D3B8E)]),
                          boxShadow: [BoxShadow(color: kBlue.withOpacity(0.5), blurRadius: 24, spreadRadius: 2)],
                        ),
                        child: _profileImage != null
                            ? ClipOval(child: Image.file(_profileImage!, fit: BoxFit.cover, width: 58, height: 58))
                            : ClipOval(child: Image.asset('assets/images/logo.png', fit: BoxFit.cover, width: 58, height: 58,
                                errorBuilder: (_, __, ___) => const Icon(Icons.person_rounded, color: kWhite, size: 28))),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Whatsapp,',
                              style: TextStyle(color: Colors.white60, fontSize: 12, fontFamily: 'Orbitron')),
                          Text(username,
                              style: const TextStyle(
                                color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                          const SizedBox(height: 4),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: const Color(0xFF29B6F6).withOpacity(0.6)), 
                              color: const Color(0xFF29B6F6).withOpacity(0.15),
                            ),
                            child: Text(role.toUpperCase(),
                                style: const TextStyle(
                                  color: Color(0xFF81D4FA), fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: 48, height: 48,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: kBlue.withOpacity(0.1),
                        border: Border.all(color: kBlue.withOpacity(0.3)),
                      ),
                      child: ClipOval(
                        child: Image.asset('assets/images/mobil.png', fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const Icon(Icons.directions_car_rounded, color: kBlue, size: 24)),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    // DIUBAH: Border DASHBOARD ikut Soft Teal
                    border: Border.all(color: const Color(0xFF1565C0).withOpacity(0.3)),
                    color: const Color(0xFF1565C0).withOpacity(0.04),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _AnimatedDot(color: const Color(0xFF29B6F6)),
                      const SizedBox(width: 10),
                      const Text('VICIOUSX DASHBOARD',
                          style: TextStyle(
                            color: Color(0xFF81D4FA), fontSize: 11, fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron', letterSpacing: 1.5)),
                      const SizedBox(width: 10),
                      _AnimatedDot(color: const Color(0xFF29B6F6)),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    _buildCircleStatItem(
                        icon: Icons.people_alt_rounded,
                        value: '$onlineUsers',
                        label: 'Online Users',
                        // DIUBAH: Dari Hijau Neon jadi GOLD PREMIUM (Senada tombol Send)
                        color: const Color(0xFFFFD700)), 
                    _buildStatDivider(),
                    _buildCircleStatItem(
                        icon: Icons.link_rounded,
                        value: '$activeConns',
                        label: 'Total Owner',
                        // DIUBAH: Dari Biru Elektrik jadi Soft Magenta/Elegant Pink
                        color: const Color(0xFFCE93D8)), 
                    _buildStatDivider(),
                    _buildCircleStatItem(
                        icon: Icons.calendar_month_rounded,
                        value: expiredDate.length > 10 ? expiredDate.substring(0, 10) : expiredDate,
                        label: 'Expiration',
                        // DIUBAH: Opacity glow dikurangi biar nggak norak, tetap keep warna oranye aslinya
                        color: const Color(0xFFFFAB40)), 
                  ],
                ),
                const SizedBox(height: 12),
                Align(
                  alignment: Alignment.centerLeft,
                  child: ScaleTransition(
                    scale: _pulseAnim,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        // DIUBAH: Dari Hijau jadi BORDER GOLD PREMIUM
                        border: Border.all(color: const Color(0xFFFFD700).withOpacity(0.5)),
                        color: const Color(0xFFFFD700).withOpacity(0.08),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // DIUBAH: Dot LIVE jadi Gold
                          _AnimatedDot(color: const Color(0xFFFFD700)),
                          const SizedBox(width: 6),
                          const Text('LIVE',
                              style: TextStyle(
                                  // DIUBAH: Teks LIVE jadi Gold
                                  color: Color(0xFFFFD700), fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1)),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCircleStatItem({
    required IconData icon,
    required String value,
    required String label,
    required Color color,
  }) {
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 62, height: 62,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              // DIUBAH: Opacity background lingkaran diperhalus
              color: color.withOpacity(0.12),
              border: Border.all(color: color.withOpacity(0.5), width: 2),
              // DIUBAH: Blur radius diperlebar biar efek melayang/3D nya keliatan mewah
              boxShadow: [BoxShadow(color: color.withOpacity(0.3), blurRadius: 22, spreadRadius: 2)], 
            ),
            child: Center(child: Icon(icon, color: color, size: 28)),
          ),
          const SizedBox(height: 8),
          Text(value,
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13, fontFamily: 'Orbitron')),
          const SizedBox(height: 2),
          Text(label, style: const TextStyle(color: Colors.white60, fontSize: 9), textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _buildStatDivider() =>
      Container(width: 1, height: 60, color: Colors.white24);

  // ── Quick Actions ─────────────────────────────────────────────────────────
  Widget _buildQuickActionsSection() {
    // Grid 2 kolom kaya foto — warna solid cerah
    final gridItems = [
      {
        'title': 'GUIDE TERMUX',
        'icon': Icons.terminal_rounded,
        'color': const Color(0xFF1565C0), // biru
        'badge': null as String?,
        'onTap': () => Navigator.push(context, _slideRoute(BugSenderPage(sessionKey: sessionKey, username: username, role: role))),
      },
      {
        'title': 'GUIDE VPS',
        'icon': Icons.dns_rounded,
        'color': const Color(0xFFD32F2F), // merah
        'badge': null as String?,
        'onTap': () => Navigator.push(context, _slideRoute(ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos))),
      },
      {
        'title': 'MUSIK',
        'icon': Icons.music_note_rounded,
        'color': const Color(0xFF2E7D32), // hijau
        'badge': null,
        'onTap': () => _showMusicControl(),
      },
      {
        'title': 'VICIGRAM',
        'icon': Icons.camera_alt_rounded,
        'color': const Color(0xFF6A1B9A), // ungu
        'badge': null,
        'onTap': () => Navigator.push(context, _slideRoute(VoltgramPage(sessionKey: sessionKey, username: username))),
      },
      {
        'title': 'GAME HUB',
        'icon': Icons.sports_esports_rounded,
        'color': const Color(0xFFE65100), // oranye
        'badge': null,
        'onTap': () => Navigator.push(context, _slideRoute(const GamePage())),
      },
      {
        'title': 'SADAP WA',
        'icon': Icons.chat_bubble_rounded,
        'color': const Color(0xFF128C7E), // whatsapp green
        'badge': null,
        'onTap': () => Navigator.push(context, _slideRoute(SadapWhatsappPage(sessionKey: sessionKey, username: username))),
      },
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                color: const Color(0xFFFFB300).withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFFFB300).withOpacity(0.4)),
              ),
              child: const Icon(Icons.bolt_rounded, color: Color(0xFFFFB300), size: 20),
            ),
            const SizedBox(width: 10),
            const Text('QUICK ACTIONS',
              style: TextStyle(
                color: Color(0xFF0D2137), fontWeight: FontWeight.w900, fontSize: 14,
                fontFamily: 'Orbitron', letterSpacing: 1,
              ),
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFFFFB300).withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFFFB300).withOpacity(0.4)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                _AnimatedDot(color: const Color(0xFFFFB300)),
                const SizedBox(width: 5),
                const Text('VICIOUSX', style: TextStyle(
                  color: Color(0xFFFFB300), fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Orbitron',
                )),
              ]),
            ),
          ]),
          const SizedBox(height: 14),
          // 2-column grid kaya foto
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 1.35,
            ),
            itemCount: gridItems.length,
            itemBuilder: (ctx, i) {
              final item = gridItems[i];
              final color = item['color'] as Color;
              return GestureDetector(
                onTap: item['onTap'] as VoidCallback,
                child: Container(
                  decoration: BoxDecoration(
                    color: color,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(color: color.withOpacity(0.35), blurRadius: 12, offset: const Offset(0, 5)),
                    ],
                  ),
                  child: Stack(
                    children: [
                      // Big bg icon
                      Positioned(
                        right: -8, bottom: -8,
                        child: Icon(item['icon'] as IconData, color: Colors.white.withOpacity(0.12), size: 70),
                      ),
                      // Badge
                      if (item['badge'] != null)
                        Positioned(
                          top: 8, right: 8,
                          child: Container(
                            width: 22, height: 22,
                            decoration: const BoxDecoration(
                              color: Color(0xFFFF6F00),
                              shape: BoxShape.circle,
                            ),
                            child: Center(child: Text(item['badge'] as String,
                              style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                            )),
                          ),
                        ),
                      Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 36, height: 36,
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Icon(item['icon'] as IconData, color: Colors.white, size: 20),
                            ),
                            const Spacer(),
                            Text(item['title'] as String,
                              style: const TextStyle(
                                color: Colors.white, fontFamily: 'Orbitron',
                                fontWeight: FontWeight.w900, fontSize: 11, letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionCard(_QuickActionData action) {
    return GestureDetector(
      onTap: action.onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(
              colors: action.gradient,
              begin: Alignment.topLeft,
              end: Alignment.bottomRight),
          boxShadow: [
            BoxShadow(
                color: action.gradient.first.withOpacity(0.25),
                blurRadius: 24, offset: const Offset(0, 10))
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -12, bottom: -12,
              child: Icon(action.bgIcon, color: Colors.white.withOpacity(0.05), size: 110),
            ),
            Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 50, height: 50,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle, color: Colors.white.withOpacity(0.15)),
                    child: Icon(action.icon, color: Colors.white, size: 24),
                  ),
                  const Spacer(),
                  Text(action.title,
                      style: const TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold, fontSize: 17, fontFamily: 'Orbitron')),
                  const SizedBox(height: 4),
                  Text(action.subtitle,
                      style: const TextStyle(color: Colors.white70, fontSize: 12)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Latest Updates ────────────────────────────────────────────────────────
  Widget _buildLatestUpdates() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              const Icon(Icons.dashboard_customize_rounded, color: Color(0xFF0077C2), size: 22),
              const SizedBox(width: 8),
              const Text('LATEST UPDATES',
                  style: TextStyle(
                    color: Color(0xFF0D2137), fontWeight: FontWeight.bold, fontSize: 15,
                    fontFamily: 'Orbitron', letterSpacing: 1)),
              const Spacer(),
              if (newsList.isNotEmpty)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: kBlue.withOpacity(0.15),
                    border: Border.all(color: kBlue.withOpacity(0.4)),
                  ),
                  child: Text('${newsList.length} Updates',
                      style: const TextStyle(
                          color: kBlue, fontSize: 11, fontWeight: FontWeight.bold)),
                ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (newsList.isNotEmpty)
          SizedBox(
            height: 200,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 14),
              itemCount: newsList.length,
              itemBuilder: (ctx, i) => _buildNewsCardHorizontal(newsList[i]),
            ),
          ),
        if (newsList.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Container(
              height: 120,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: kCard,
                  border: Border.all(color: kBorder.withOpacity(0.4))),
              child: const Center(
                  child: Text('No updates available', style: TextStyle(color: kWhite54))),
            ),
          ),
      ],
    );
  }

  Widget _buildNewsCardHorizontal(dynamic item) {
    final imgUrl   = item['image']?.toString() ?? '';
    final title    = item['title']?.toString() ?? 'No Title';
    final date     = item['date']?.toString() ?? item['created_at']?.toString() ?? '';
    final cardWidth = (MediaQuery.of(context).size.width / 2) - 22;

    return Container(
      width: cardWidth,
      margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: kCard,
        border: Border.all(color: kBorder.withOpacity(0.4)),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 12, offset: const Offset(0, 6))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
            child: Stack(
              children: [
                Container(
                  height: 110, width: double.infinity, color: kCardAlt,
                  child: imgUrl.isNotEmpty
                      ? Image.network(imgUrl, fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const Center(
                              child: Icon(Icons.image_not_supported, color: kWhite54, size: 30)))
                      : const Center(
                          child: Icon(Icons.article_rounded, color: kWhite54, size: 30)),
                ),
                Positioned(
                  top: 8, right: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.black.withOpacity(0.65),
                      border: Border.all(color: kBlue.withOpacity(0.7)),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.circle_notifications_rounded, color: kBlue, size: 10),
                        SizedBox(width: 3),
                        Text('NEW',
                            style: TextStyle(
                                color: kBlue, fontSize: 9, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 6),
            child: Text(title,
                style: const TextStyle(
                  color: kWhite, fontSize: 16, fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron', height: 1.3),
                maxLines: 2, overflow: TextOverflow.ellipsis),
          ),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
            child: Row(
              children: [
                const Icon(Icons.access_time_rounded, color: kWhite54, size: 11),
                const SizedBox(width: 4),
                if (date.isNotEmpty)
                  Expanded(
                    child: Text(
                        date.length > 10 ? date.substring(0, 10) : date,
                        style: const TextStyle(color: kWhite54, fontSize: 10)),
                  ),
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: kBlue.withOpacity(0.18)),
                  child: const Icon(Icons.arrow_forward_ios_rounded, color: kBlue, size: 9),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Prayer Section ────────────────────────────────────────────────────────
    Widget _buildPrayerSection() {
    final prayerColors = [
      const Color(0xFF2D2D3D), // Hitam keabu-abuan gelap (Subuh)
      const Color(0xFF3A3A4A), // Abu-abu lebih terang (Dzuhur)
      const Color(0xFF353545), // Abu-abu tengah (Ashar)
      const Color(0xFF252535), // Hitam keabu sangat gelap (Maghrib)
      const Color(0xFF18181B), // Nuansa hitam paling dalam (Isya)
    ];
    final prayerIcons = [
      Icons.nights_stay_rounded,
      Icons.wb_sunny_rounded,
      Icons.cloud_rounded,
      Icons.wb_twilight_rounded,
      Icons.nightlight_round,
    ];
    final prayerKeys = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFF1C1C1E), // Background card hitam keabu-abuan premium
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF3A3A3C).withOpacity(0.5)), // Border abu-abu sangat samar
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.6), blurRadius: 18, offset: const Offset(0, 8))
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Header row ──
            Row(
              children: [
                Container(
                  width: 48, height: 48,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: const Color(0xFF48484A).withOpacity(0.3), // Warna abu redup untuk background icon
                    border: Border.all(color: const Color(0xFF48484A).withOpacity(0.5)),
                  ),
                  child: const Center(child: Icon(Icons.mosque, color: Color(0xFF8E8E93), size: 26)), // Icon abu-abu soft
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('JADWAL SHOLAT',
                          style: TextStyle(
                            color: Color(0xFFE5E5EA), // Teks putih keabu sangat halus
                            fontWeight: FontWeight.bold, fontSize: 15,
                            fontFamily: 'Orbitron', letterSpacing: 1)),
                      Text(_prayerCity,
                          style: const TextStyle(color: Color(0xFF636366), fontSize: 12)), // Teks kota abu-abu sekunder
                    ],
                  ),
                ),
                // Tombol auto-detect lokasi
                GestureDetector(
                  onTap: _locationLoading ? null : _detectLocationAndFetchPrayer,
                  child: Container(
                    width: 38, height: 38,
                    margin: const EdgeInsets.only(right: 8),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _locationGranted
                          ? const Color(0xFF48484A).withOpacity(0.3)
                          : const Color(0xFF2C2C2E).withOpacity(0.5),
                      border: Border.all(
                        color: _locationGranted
                            ? const Color(0xFF48484A).withOpacity(0.6)
                            : const Color(0xFF3A3A3C).withOpacity(0.3),
                      ),
                    ),
                    child: _locationLoading
                        ? const Padding(
                            padding: EdgeInsets.all(10),
                            child: CircularProgressIndicator(color: Color(0xFF8E8E93), strokeWidth: 2),
                          )
                        : Icon(
                            _locationGranted
                                ? Icons.my_location_rounded
                                : Icons.location_searching_rounded,
                            color: _locationGranted ? const Color(0xFF8E8E93) : const Color(0xFF48484A),
                            size: 18,
                          ),
                  ),
                ),
                // Tombol ganti manual
                GestureDetector(
                  onTap: _showChangeCityDialog,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: const Color(0xFF3A3A3C), // Warna tombol abu-abu moderat
                    ),
                    child: const Row(children: [
                      Icon(Icons.edit_location_alt_rounded, color: Color(0xFFE5E5EA), size: 14), // Icon putih keabu
                      SizedBox(width: 5),
                      Text('GANTI',
                          style: TextStyle(
                              color: Color(0xFFE5E5EA), fontSize: 12, fontWeight: FontWeight.bold)),
                    ]),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),

            // ── Next prayer badge ──
            if (_nextPrayerLabel.isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: const Color(0xFF2C2C2E), // Background hitam keabu untuk badge
                  border: Border.all(color: const Color(0xFF48484A).withOpacity(0.6)),
                ),
                child: Row(
                  children: [
                    ScaleTransition(
                      scale: _pulseAnim,
                      child: _AnimatedDot(color: const Color(0xFF8E8E93), size: 10), // Titik animasi abu-abu
                    ),
                    const SizedBox(width: 10),
                    Text('Menuju $_nextPrayerLabel : $_nextPrayerTime',
                        style: const TextStyle(
                          color: Color(0xFFE5E5EA), fontSize: 13, fontWeight: FontWeight.w600,
                          fontFamily: 'Orbitron')),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: const Color(0xFF636366).withOpacity(0.5)),
                      ),
                      child: const Text('VICIOUSX',
                          style: TextStyle(color: Color(0xFF636366), fontSize: 10, fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 14),

            // ── Prayer time cards ──
            if (_prayerLoading)
              const Center(child: CircularProgressIndicator(color: Color(0xFF8E8E93), strokeWidth: 2)) // Loader abu-abu
            else
              SizedBox(
                height: 118,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  itemCount: prayerKeys.length,
                  itemBuilder: (ctx, i) {
                    final key   = prayerKeys[i];
                    final time  = _prayerTimes[key] ?? '--:--';
                    final color = prayerColors[i];
                    final icon  = prayerIcons[i];
                    final isNext = key == _nextPrayerLabel;
                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 400),
                      curve: Curves.easeOut,
                      margin: EdgeInsets.only(right: 10, bottom: isNext ? 0 : 6, top: isNext ? 0 : 6),
                      width: 105,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(18),
                        color: color,
                        boxShadow: [
                          BoxShadow(
                              color: color.withOpacity(isNext ? 0.65 : 0.3),
                              blurRadius: isNext ? 18 : 8, offset: const Offset(0, 4))
                        ],
                        border: isNext
                            ? Border.all(color: const Color(0xFF636366).withOpacity(0.8), width: 1.5) // Border card aktif abu-abu lebih terang
                            : null,
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(icon, color: const Color(0xFFE5E5EA), size: 24), // Icon putih keabu di dalam card
                            const SizedBox(height: 5),
                            Text(key.toUpperCase(),
                                style: const TextStyle(
                                    color: Color(0xFF8E8E93), fontSize: 9, // Nama sholat abu-abu soft
                                    fontWeight: FontWeight.bold, letterSpacing: 0.8)),
                            const SizedBox(height: 5),
                            Text(time,
                                style: const TextStyle(
                                    color: Color(0xFFE5E5EA), fontSize: 19, // Waktu putih keabu terang
                                    fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ── Hadith Section ────────────────────────────────────────────────────────
  Widget _buildHadithSection() {
    if (_hadithLoading) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Container(
          height: 200,
          decoration: BoxDecoration(
            color: kCard, borderRadius: BorderRadius.circular(20),
            border: Border.all(color: kBorder.withOpacity(0.5)),
          ),
          child: const Center(child: CircularProgressIndicator(color: kBlue, strokeWidth: 2)),
        ),
      );
    }

    final arabic = _hadith?['data']?['text']?['ar'] ??
        'إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى';
    final indo   = _hadith?['data']?['text']?['id'] ??
        'Sesungguhnya setiap amalan tergantung pada niatnya.';
    final number = _hadith?['data']?['id']?.toString() ?? '1';
    final source = _hadith?['data']?['source']?.toString() ?? 'Muslim';
    final grade  = _hadith?['data']?['grade']?.toString() ?? 'Sahih Muslim';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: kCard, borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kBorder.withOpacity(0.5)),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 18, offset: const Offset(0, 8))
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 50, height: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle, color: kBlue.withOpacity(0.18)),
                  child: const Center(child: Icon(Icons.menu_book_rounded, color: kBlue, size: 26)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('HADITH OF THE DAY',
                        style: TextStyle(
                          color: kWhite, fontWeight: FontWeight.bold, fontSize: 15,
                          fontFamily: 'Orbitron', letterSpacing: 0.5)),
                    const SizedBox(height: 2),
                    Text('$grade · Tap card to read full',
                        style: const TextStyle(color: kWhite54, fontSize: 11)),
                  ]),
                ),
              ],
            ),
            const SizedBox(height: 14),
            GestureDetector(
              onTap: () => _showHadithFullDialog(arabic, indo, source, number, grade),
              child: Column(
                children: [
                  Container(
                    width: double.infinity, padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      color: const Color(0xFF18181B),
                      border: Border.all(color: kBorder.withOpacity(0.3)),
                    ),
                    child: Text(arabic,
                        textAlign: TextAlign.right, textDirection: TextDirection.rtl,
                        style: const TextStyle(color: kWhite, fontSize: 17, height: 2.0)),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    width: double.infinity, padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14), color: const Color(0xFF111113)),
                    child: Text(indo,
                        style: const TextStyle(
                          color: kWhite54, fontSize: 12, fontStyle: FontStyle.italic, height: 1.7),
                        maxLines: 3, overflow: TextOverflow.ellipsis),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: kBlue.withOpacity(0.45)),
                    color: kBlue.withOpacity(0.07),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.receipt_long_rounded, color: kBlue, size: 13),
                    const SizedBox(width: 5),
                    Text('${source.isNotEmpty ? source : "Muslim"} #$number',
                        style: const TextStyle(
                            color: kBlue, fontSize: 11, fontWeight: FontWeight.bold)),
                  ]),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: _fetchRandomHadith,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: kWhite54.withOpacity(0.3)),
                    ),
                    child: const Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.touch_app_rounded, color: kWhite54, size: 14),
                      SizedBox(width: 4),
                      Text('Tap card', style: TextStyle(color: kWhite54, fontSize: 11)),
                    ]),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ── Build ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      extendBodyBehindAppBar: false,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          // ── Manga/comic background kaya foto ──────────────────────────
          Positioned.fill(
            child: Image.asset('assets/images/background.jpg', fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                color: const Color(0xFFE8F4FD),
              ),
            ),
          ),
          // Soft white overlay agar teks tetap terbaca tapi manga keliatan
          Positioned.fill(
            child: Container(color: Colors.white.withOpacity(0.62)),
          ),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 350),
            transitionBuilder: (child, anim) =>
                FadeTransition(opacity: anim, child: child),
            child: KeyedSubtree(
              key: ValueKey(_navIndex),
              child: _buildCurrentPage(),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  Widget _buildBackgroundGrid() {
    return const SizedBox.shrink(); // ocean bg replaces grid
  }

  // ── AppBar ────────────────────────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: const Color(0xFF0077C2),
      elevation: 0,
      iconTheme: const IconThemeData(color: Colors.white),
      titleSpacing: 0,
      flexibleSpace: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF0054A6), Color(0xFF0288D1), Color(0xFF29B6F6)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
        ),
      ),
      title: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 34, height: 34,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withOpacity(0.5), width: 1.5),
              boxShadow: [BoxShadow(color: Colors.white.withOpacity(0.2), blurRadius: 8)],
            ),
            child: ClipOval(
              child: Image.asset('assets/images/logo.png', fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const Icon(Icons.bolt_rounded, color: Colors.white, size: 18)),
            ),
          ),
          const SizedBox(width: 10),
          const Text('VICIOUSX',
            style: TextStyle(
              color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900,
              fontFamily: 'Orbitron', letterSpacing: 4,
              shadows: [Shadow(color: Colors.black26, blurRadius: 8)],
            ),
          ),
        ],
      ),
      actions: [
        GestureDetector(
          onTap: () => Navigator.push(context, _slideRoute(const ContactPage())),
          child: Container(
            margin: const EdgeInsets.only(right: 6),
            width: 36, height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withOpacity(0.15),
              border: Border.all(color: Colors.white.withOpacity(0.3)),
            ),
            child: const Icon(Icons.headset_mic_rounded, color: Colors.white, size: 18),
          ),
        ),
        GestureDetector(
          onTap: () => Navigator.push(context, _slideRoute(ProfilePage(
            username: username, password: password,
            role: role, expiredDate: expiredDate, sessionKey: sessionKey,
          ))).then((_) { _loadProfileImage(); }),
          child: Container(
            margin: const EdgeInsets.only(right: 12),
            width: 36, height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withOpacity(0.5), width: 1.5),
              boxShadow: [BoxShadow(color: kBlue.withOpacity(0.3), blurRadius: 8)],
            ),
            child: ClipOval(
              child: _profileImage != null
                  ? Image.file(_profileImage!, fit: BoxFit.cover)
                  : const Icon(Icons.person_rounded, color: Colors.white, size: 20),
            ),
          ),
        ),
      ],
    );
  }

  // ── Bottom Nav ────────────────────────────────────────────────────────────
  Widget _buildBottomNav() {
    // Nav items: nama, icon, warna aktif (sesuai foto — Beranda=merah/biru, Menu=biru, RAT=teal, Tools=orange, Tema=purple)
    final items = [
      {'label': 'Beranda', 'icon': Icons.home_rounded,              'color': const Color(0xFF0077C2)},
      {'label': 'Menu',    'icon': Icons.grid_view_rounded,          'color': const Color(0xFF1565C0)},
      {'label': 'RAT',     'icon': Icons.router_rounded,             'color': const Color(0xFF00838F)},
      {'label': 'Tools',   'icon': Icons.build_rounded,              'color': const Color(0xFFE65100)},
      {'label': 'Tema',    'icon': Icons.palette_rounded,            'color': const Color(0xFF6A1B9A)},
    ];

    // Tinggi total bar: 68 (bar) + 28 (floating bubble menonjol ke atas)
    const double barH   = 64.0;
    const double bubbleD = 52.0;
    const double floatLift = 22.0; // seberapa tinggi bubble naik dari bar

    return SizedBox(
      height: barH + floatLift,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          // ── Bar utama (krem/putih tipis, kaya foto) ──────────────────
          Positioned(
            bottom: 0, left: 0, right: 0,
            child: Container(
              height: barH,
              decoration: BoxDecoration(
                color: const Color(0xFFF5F0E8), // krem warm seperti foto
                borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.12), blurRadius: 16, offset: const Offset(0, -4)),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: List.generate(items.length, (i) {
                  final isActive = _navIndex == i;
                  final color = items[i]['color'] as Color;
                  return GestureDetector(
                    onTap: () => _onNavTap(i),
                    child: SizedBox(
                      width: 62,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          // Ruang untuk floating bubble
                          SizedBox(height: isActive ? floatLift + 4 : 0),
                          if (!isActive)
                            Icon(items[i]['icon'] as IconData,
                              color: const Color(0xFF8A8A8A), size: 22),
                          const SizedBox(height: 4),
                          Text(items[i]['label'] as String,
                            style: TextStyle(
                              color: isActive ? color : const Color(0xFF8A8A8A),
                              fontSize: 10,
                              fontWeight: isActive ? FontWeight.w800 : FontWeight.normal,
                              fontFamily: isActive ? 'Orbitron' : null,
                            ),
                          ),
                          const SizedBox(height: 8),
                        ],
                      ),
                    ),
                  );
                }),
              ),
            ),
          ),

          // ── Floating bubbles per item (hanya active yg besar & menonjol) ──
          ...List.generate(items.length, (i) {
            final isActive = _navIndex == i;
            final color = items[i]['color'] as Color;
            // posisi X center tiap item
            final screenW = MediaQueryData.fromView(WidgetsBinding.instance.platformDispatcher.implicitView!).size.width;
            final itemW = screenW / items.length;
            final cx = itemW * i + itemW / 2;

            return AnimatedPositioned(
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeOutBack,
              bottom: isActive ? barH - bubbleD / 2 + floatLift - 6 : barH - 20,
              left: cx - bubbleD / 2,
              child: AnimatedOpacity(
                duration: const Duration(milliseconds: 200),
                opacity: isActive ? 1.0 : 0.0,
                child: GestureDetector(
                  onTap: () => _onNavTap(i),
                  child: TweenAnimationBuilder<double>(
                    key: ValueKey(isActive ? 'active_$i' : 'idle_$i'),
                    tween: Tween(begin: 0.6, end: 1.0),
                    duration: const Duration(milliseconds: 380),
                    curve: Curves.easeOutBack,
                    builder: (_, t, child) => Transform.scale(scale: t, child: child),
                    child: Container(
                      width: bubbleD, height: bubbleD,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: color,
                        boxShadow: [
                          BoxShadow(color: color.withOpacity(0.45), blurRadius: 14, spreadRadius: 2, offset: const Offset(0, 4)),
                          BoxShadow(color: Colors.black.withOpacity(0.15), blurRadius: 6, offset: const Offset(0, 2)),
                        ],
                      ),
                      child: Icon(items[i]['icon'] as IconData, color: Colors.white, size: 24),
                    ),
                  ),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }

  // ── Drawer ────────────────────────────────────────────────────────────────
  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: kBg,
      width: MediaQuery.of(context).size.width * 0.8,
      child: Column(
        children: [
          Container(
            height: 240,
            color: Colors.black,
            child: Stack(
              children: [
                // Drawer banner - pakai ornes_1.png
                Positioned.fill(
                  child: Image.asset('assets/images/background.jpg', fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(color: Colors.black)),
                ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter, end: Alignment.bottomCenter,
                      colors: [Colors.black.withOpacity(0.3), Colors.black.withOpacity(0.85)],
                    ),
                  ),
                ),
                SafeArea(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 80, height: 80,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: kBlue.withOpacity(0.6), width: 2.5),
                            boxShadow: [BoxShadow(color: kBlue.withOpacity(0.3), blurRadius: 14, spreadRadius: 2)],
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(_profileImage!, fit: BoxFit.cover)
                                : const Icon(FontAwesomeIcons.userAstronaut, size: 38, color: kWhite),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(username,
                            style: const TextStyle(
                                color: kWhite, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                        Text(role.toUpperCase(),
                            style: const TextStyle(color: kBlue, fontSize: 12, letterSpacing: 2)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              color: kBg,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 16),
                children: [
                  // Notifikasi
                  _buildDrawerItem(
                    icon: Icons.notifications_rounded,
                    label: 'Notifikasi',
                    badge: _hasNewNotif,
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, _slideRoute(NotificationPage(
                        notifications: _notifications,
                        role: role,
                        onClear: () => setState(() {
                          _notifications.clear();
                          _hasNewNotif = false;
                        }),
                      ))).then((_) => setState(() => _hasNewNotif = false));
                    },
                  ),
                  // Info Page
                  _buildDrawerItem(
                    icon: Icons.info_outline_rounded,
                    label: 'Informasi App',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, _slideRoute(InfoPage(sessionKey: sessionKey)));
                    },
                  ),
                  const Divider(color: Color(0xFF27272A), indent: 16, endIndent: 16),
                  if (role.toLowerCase() == 'reseller')
                    _buildDrawerItem(
                        icon: Icons.storefront_rounded,
                        label: 'Seller Page',
                        onTap: () => _onDrawerNav(1)),
                  if (role.toLowerCase() == 'admin')
                    _buildDrawerItem(
                        icon: Icons.admin_panel_settings_rounded,
                        label: 'Admin Page',
                        onTap: () => _onDrawerNav(2)),
                  if (role.toLowerCase() == 'owner')
                    _buildDrawerItem(
                        icon: Icons.workspace_premium_rounded,
                        label: 'Owner Page',
                        onTap: () => _onDrawerNav(3)),
                  if (role.toLowerCase() == 'developer')
                    _buildDrawerItem(
                        icon: Icons.developer_mode_rounded,
                        label: 'Developer Panel',
                        color: const Color(0xFFEC4899),
                        onTap: () => _onDrawerNav(3)),
                  _buildDrawerItem(
                    icon: Icons.history_rounded,
                    label: 'Riwayat Aktivitas',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                          context,
                          _slideRoute(RiwayatPage(sessionKey: sessionKey, role: role))).then((_) {
                        if (mounted && _newsPageCtrl.hasClients) {
                          setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
                          _newsPageCtrl.jumpToPage(0);
                        }
                      });
                    },
                  ),
                  _buildDrawerItem(
                    icon: Icons.lock_outline_rounded,
                    label: 'Ganti Password',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(ChangePasswordPage(username: username, sessionKey: sessionKey)),
                      );
                    },
                  ),
                  const SizedBox(height: 16),
                  _buildDrawerItem(
                    icon: Icons.logout_rounded,
                    label: 'Keluar',
                    isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false);
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
    bool badge = false,
    Color? color,
  }) {
    final iconColor = isLogout ? Colors.redAccent : (color ?? kBlue);
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      decoration: BoxDecoration(
        color: isLogout ? Colors.red.withOpacity(0.08) : kCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: isLogout ? Colors.red.withOpacity(0.3) : kBorder.withOpacity(0.4)),
      ),
      child: ListTile(
        leading: Stack(
          clipBehavior: Clip.none,
          children: [
            Icon(icon, color: iconColor, size: 20),
            if (badge)
              Positioned(top: -4, right: -4,
                child: Container(
                  width: 8, height: 8,
                  decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                ),
              ),
          ],
        ),
        title: Text(label,
            style: TextStyle(
                color: isLogout ? Colors.redAccent : kWhite,
                fontWeight: FontWeight.w600, fontSize: 14)),
        trailing: const Icon(Icons.arrow_forward_ios_rounded, color: kWhite24, size: 13),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        onTap: onTap,
      ),
    );
  }
}

// ─── Quick Action Data ─────────────────────────────────────────────────────────
class _QuickActionData {
  final IconData icon;
  final IconData bgIcon;
  final String title;
  final String subtitle;
  final List<Color> gradient;
  final VoidCallback onTap;
  const _QuickActionData({
    required this.icon,
    required this.bgIcon,
    required this.title,
    required this.subtitle,
    required this.gradient,
    required this.onTap,
  });
}

// ─── Nav Item ─────────────────────────────────────────────────────────────────
class _NavItem {
  final IconData icon;
  final String label;
  const _NavItem({required this.icon, required this.label});
}

// ─── Slide Route ──────────────────────────────────────────────────────────────
PageRoute _slideRoute(Widget page) => PageRouteBuilder(
  pageBuilder: (_, __, ___) => page,
  transitionDuration: const Duration(milliseconds: 350),
  transitionsBuilder: (_, anim, __, child) => SlideTransition(
    position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
        .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
    child: FadeTransition(opacity: anim, child: child),
  ),
);

// ─── NewsMedia ────────────────────────────────────────────────────────────────
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});
  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _ctrl;
  bool _isVideo(String url) =>
      url.endsWith('.mp4') || url.endsWith('.webm') ||
      url.endsWith('.mov') || url.endsWith('.mkv');
  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) setState(() {});
          _ctrl?.setLooping(true);
          _ctrl?.setVolume(0.0);
          _ctrl?.play();
        });
    }
  }
  @override
  void dispose() { _ctrl?.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_ctrl != null && _ctrl!.value.isInitialized) {
        return AspectRatio(aspectRatio: _ctrl!.value.aspectRatio, child: VideoPlayer(_ctrl!));
      }
      return const Center(child: CircularProgressIndicator(color: kBlue, strokeWidth: 2));
    }
    return Image.network(
      widget.url, fit: BoxFit.cover,
      errorBuilder: (_, __, ___) =>
          Container(color: kCard, child: const Icon(Icons.error_rounded, color: kWhite24)),
    );
  }
}
