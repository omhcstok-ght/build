import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'login_page.dart';

// ─── Palette: White + Blue + Gold ─────────────────────────────────────────────
class _C {
  static const bg         = Color(0xFFFFFFFF);      // pure white
  static const bgSoft     = Color(0xFFF0F4FF);      // soft blue-white
  static const surface    = Color(0xFFF8FAFF);      // surface white
  static const card       = Color(0xFFFFFFFF);      // card white
  static const border     = Color(0xFFDDE3F0);      // border soft blue

  static const blue       = Color(0xFF1565C0);      // primary blue
  static const blueLight  = Color(0xFF42A5F5);      // light blue
  static const blueDark   = Color(0xFF0D47A1);      // dark blue
  static const blueAccent = Color(0xFF1E88E5);      // accent blue

  static const gold       = Color(0xFFD4A017);      // gold/emas
  static const goldLight  = Color(0xFFFFD700);      // bright gold
  static const goldDark   = Color(0xFFB8860B);      // dark gold

  static const text       = Color(0xFF0D1B3E);      // deep navy text
  static const textSub    = Color(0xFF4A6FA5);      // blue-grey sub
  static const textDim    = Color(0xFF8BA3C7);      // dim blue

  static const LinearGradient blueGrad = LinearGradient(
    colors: [Color(0xFF1565C0), Color(0xFF0D47A1)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );
  static const LinearGradient goldGrad = LinearGradient(
    colors: [Color(0xFFD4A017), Color(0xFFB8860B)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );
  static const LinearGradient heroGrad = LinearGradient(
    colors: [Color(0xFF1565C0), Color(0xFF0D47A1), Color(0xFFD4A017)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );
}

// ─── Package Store ──────────────────────────────────────────────────────────
final List<Map<String, dynamic>> _packages = [
  {'name': 'BASIC',     'role': 'User',      'price': 'Rp ???.???', 'icon': Icons.person_rounded,               'color': const Color(0xFF4A6FA5)},
  {'name': 'VIP',       'role': 'VIP',       'price': 'Rp ???.???', 'icon': Icons.star_rounded,                 'color': _C.blue},
  {'name': 'RESELLER',  'role': 'Reseller',  'price': 'Rp ???.???', 'icon': Icons.storefront_rounded,           'color': _C.gold},
  {'name': 'ADMIN',     'role': 'Admin',     'price': 'Rp ???.???', 'icon': Icons.admin_panel_settings_rounded, 'color': const Color(0xFFEF4444)},
  {'name': 'DEVELOPER', 'role': 'Developer', 'price': 'Rp ???.???', 'icon': Icons.code_rounded,                 'color': const Color(0xFF7C3AED)},
];

// ─── Intro Slide (kaya foto 1: ORANES style) ────────────────────────────────
class _IntroSlide extends StatelessWidget {
  final String bigText;
  final String smallText;
  final IconData icon;
  final Color accentColor;
  final int totalSlides;
  final int currentIndex;
  final VoidCallback onTap;

  const _IntroSlide({
    required this.bigText,
    required this.smallText,
    required this.icon,
    required this.accentColor,
    required this.totalSlides,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFE1F5FE), // langit cerah
              Color(0xFFB3E5FC),
              Color(0xFF81D4FA),
              Color(0xFF4FC3F7),
            ],
          ),
        ),
        child: Stack(
          children: [
            // Bubble/particle pattern bright
            Positioned.fill(child: CustomPaint(painter: _StarPainter(accentColor))),

            // Diagonal colored shape — kaya foto 1
            Positioned(
              top: 0, right: 0, left: 0,
              child: ClipPath(
                clipper: _DiagonalClipper(),
                child: Container(
                  height: MediaQuery.of(context).size.height * 0.42,
                  color: accentColor.withOpacity(0.22),
                ),
              ),
            ),

            // Content
            SafeArea(
              child: Column(
                children: [
                  const Spacer(flex: 3),
                  // Icon — kaya foto 1 bug icon
                  Container(
                    width: 72, height: 72,
                    decoration: BoxDecoration(
                      color: accentColor.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: accentColor.withOpacity(0.3), width: 1.5),
                    ),
                    child: Icon(icon, color: accentColor, size: 36),
                  ),
                  const SizedBox(height: 32),
                  // Big text — dark navy on light ocean bg
                  Text(
                    bigText,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Color(0xFF0D2137),
                      fontSize: 52, fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron', letterSpacing: 4,
                      height: 1.05,
                    ),
                  ),
                  const SizedBox(height: 14),
                  // Small text — accent color
                  Text(
                    smallText,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: accentColor,
                      fontSize: 11, letterSpacing: 4.5,
                      fontFamily: 'Orbitron', fontWeight: FontWeight.w700,
                    ),
                  ),
                  const Spacer(flex: 4),
                  // Dots indicator
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(totalSlides, (i) => AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      width: currentIndex == i ? 28 : 8, height: 4,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(2),
                        color: currentIndex == i ? accentColor : accentColor.withOpacity(0.25),
                      ),
                    )),
                  ),
                  const SizedBox(height: 18),
                  Text(
                    'KETUK UNTUK LANJUTKAN',
                    style: const TextStyle(
                      color: Color(0x660D2137),
                      fontSize: 10, letterSpacing: 3.5, fontFamily: 'Orbitron',
                    ),
                  ),
                  const SizedBox(height: 48),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Catatan Popup (kaya foto 2: paper note) ────────────────────────────────
class _CatatanSlide extends StatelessWidget {
  final VoidCallback onLanjut;
  const _CatatanSlide({required this.onLanjut});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black.withOpacity(0.85),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Stack(
            children: [
              // popup_paper.png background
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  image: const DecorationImage(
                    image: AssetImage('assets/images/popup_paper.png'),
                    fit: BoxFit.fill,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.4),
                      blurRadius: 30, offset: const Offset(0, 12),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(28, 32, 28, 28),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                            decoration: BoxDecoration(
                              border: Border.all(color: const Color(0xFF333333), width: 1),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: const Text('CATATAN PEMBUKA',
                              style: TextStyle(
                                color: Color(0xFF333333), fontSize: 9,
                                fontWeight: FontWeight.w600, letterSpacing: 1.5,
                              ),
                            ),
                          ),
                          const Text('VICIOUSX',
                            style: TextStyle(
                              color: _C.gold, fontSize: 12,
                              fontWeight: FontWeight.w800,
                              fontFamily: 'Orbitron', letterSpacing: 2,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      const Text('APK VICIOUSX',
                        style: TextStyle(
                          color: Color(0xFF111111), fontSize: 22,
                          fontWeight: FontWeight.w900, letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(height: 4),
                      const Text('berbeda dari project lama',
                        style: TextStyle(
                          color: Color(0xFF222222), fontSize: 18,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.symmetric(vertical: 14),
                        height: 2,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [_C.gold, _C.blue, Colors.transparent],
                          ),
                          borderRadius: BorderRadius.circular(1),
                        ),
                      ),
                      const Text(
                        'Karena pengalaman yang dahulu mengurus VPS sendiri — pembelian banyak VPS yang tidak menghasilkan pencapaian maksimal. Ada buang duit dan member terus mengeluh.',
                        style: TextStyle(
                          color: Color(0xFF333333), fontSize: 12.5, height: 1.6,
                        ),
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'Dan sekarang VICIOUSX dibangun dengan metode khusus — biar server tetap bisa jalan di Termux, tanpa nuntut VPS yang terus nggak stabil dan ada masalah.',
                        style: TextStyle(
                          color: Color(0xFF333333), fontSize: 12.5, height: 1.6,
                        ),
                      ),
                      const SizedBox(height: 14),
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.06),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.black.withOpacity(0.1)),
                        ),
                        child: const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(children: [
                              Icon(Icons.phone_android_rounded, size: 16, color: Color(0xFF555555)),
                              SizedBox(width: 10),
                              Expanded(child: Text(
                                'Dulu: proxy VPS — ribet + sia sia.\nSekarang: jalan di Termux / VPS sendiri.\nMeminimalisir ketidakstabilan.',
                                style: TextStyle(color: Color(0xFF444444), fontSize: 11.5, height: 1.5),
                              )),
                            ]),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'VICIOUSX bakal terus disempurnakan — menambah fitur dan benefit biar project VICIOUSX ini makin nyaman dipake oleh kalian.',
                        style: TextStyle(
                          color: Color(0xFF333333), fontSize: 12.5, height: 1.6,
                        ),
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        '— VICIOUSX',
                        style: TextStyle(
                          color: Color(0xFF222222), fontSize: 13, fontWeight: FontWeight.w700,
                        ),
                      ),
                      const Text(
                        '@danzz0122',
                        style: TextStyle(color: Color(0xFF666666), fontSize: 11),
                      ),
                      const SizedBox(height: 20),
                      // Button OKE, LANJUT
                      GestureDetector(
                        onTap: onLanjut,
                        child: Container(
                          width: double.infinity, height: 50,
                          decoration: BoxDecoration(
                            color: const Color(0xFF111111),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Center(
                            child: Text('OKE, LANJUT',
                              style: TextStyle(
                                color: Colors.white, fontSize: 13,
                                fontWeight: FontWeight.w800, letterSpacing: 2,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Center(
                        child: GestureDetector(
                          onTap: onLanjut,
                          child: const Text('Lewati catatan',
                            style: TextStyle(
                              color: Color(0xFF888888), fontSize: 11, height: 1.5,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Star painter ─────────────────────────────────────────────────────────────
class _StarPainter extends CustomPainter {
  final Color accentColor;
  _StarPainter(this.accentColor);

  @override
  void paint(Canvas canvas, Size size) {
    final rng = math.Random(42);
    // Ocean bubbles / foam dots — light on light bg
    final paint = Paint()..color = Colors.white.withOpacity(0.55);
    for (int i = 0; i < 40; i++) {
      final x = rng.nextDouble() * size.width;
      final y = rng.nextDouble() * size.height;
      final r = rng.nextDouble() * 5 + 1.5;
      canvas.drawCircle(Offset(x, y), r, paint);
    }
    // Accent foam
    final paintAcc = Paint()
      ..color = accentColor.withOpacity(0.12)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    for (int i = 0; i < 15; i++) {
      final x = rng.nextDouble() * size.width;
      final y = rng.nextDouble() * size.height;
      final r = rng.nextDouble() * 18 + 6;
      canvas.drawCircle(Offset(x, y), r, paintAcc);
    }
  }

  @override
  bool shouldRepaint(_) => false;
}

// ─── Diagonal clipper ─────────────────────────────────────────────────────────
class _DiagonalClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.moveTo(0, 0);
    path.lineTo(size.width, 0);
    path.lineTo(size.width, size.height * 0.7);
    path.lineTo(0, size.height);
    path.close();
    return path;
  }
  @override
  bool shouldReclip(_) => false;
}

// ─── Slide definitions ────────────────────────────────────────────────────────
final _introSlides = [
  // Slide 1 — VOLTEX
  {
    'bigText': 'VICIOUSX',
    'smallText': 'VICIOUSX WHATSAPP EXECUTIVE',
    'icon': Icons.bolt_rounded,
    'accent': const Color(0xFF0077C2),
  },
  // Slide 2 — MYSTICNOY DEV
  {
    'bigText': 'DANZZ',
    'smallText': '[ DEV ] — BUILT FROM THE VOID',
    'icon': Icons.code_rounded,
    'accent': const Color(0xFFE65100),
  },
  // Slide 3 — SECURE & AMAN
  {
    'bigText': 'SECURE\nAMAN',
    'smallText': 'SISTEM TERENKRIPSI — NO LOGS',
    'icon': Icons.shield_rounded,
    'accent': const Color(0xFF22C55E),
  },
  // Slide 4 — SYSTEM ACTIVE
  {
    'bigText': 'SYSTEM\nACTIVE',
    'smallText': 'TERPANTAU • TERKENDALI • SIAP',
    'icon': Icons.radar_rounded,
    'accent': const Color(0xFF6A1B9A),
  },
];

// ─── Flow State ───────────────────────────────────────────────────────────────
enum _FlowStep { intro, catatan, mainLanding }

// ─── Landing Page ─────────────────────────────────────────────────────────────
class LandingPage extends StatefulWidget {
  const LandingPage({super.key});
  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {

  _FlowStep _step = _FlowStep.intro;
  int _slideIndex = 0;
  final _pageCtrl = PageController();

  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _floatCtrl;
  late AnimationController _bgCtrl;

  // Video background for main landing
  VideoPlayerController? _videoCtrl;
  bool _videoReady = false;

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOutCubic);
    _floatCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))
      ..repeat(reverse: true);
    _bgCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 20))
      ..repeat();
    WidgetsBinding.instance.addPostFrameCallback((_) => _fadeCtrl.forward());
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    _floatCtrl.dispose();
    _bgCtrl.dispose();
    _videoCtrl?.dispose();
    _pageCtrl.dispose();
    super.dispose();
  }

  void _nextIntroSlide() {
    if (_slideIndex < _introSlides.length - 1) {
      _slideIndex++;
      _pageCtrl.animateToPage(_slideIndex,
          duration: const Duration(milliseconds: 450), curve: Curves.easeInOut);
      setState(() {});
    } else {
      // Selesai intro → catatan
      setState(() => _step = _FlowStep.catatan);
    }
  }

  void _toCatatanDone() {
    setState(() {
      _step = _FlowStep.mainLanding;
    });
    _fadeCtrl.forward(from: 0);
    _initVideo();
  }

  void _initVideo() async {
    try {
      _videoCtrl = VideoPlayerController.asset('assets/videos/background.mp4');
      await _videoCtrl!.initialize();
      if (mounted) {
        setState(() => _videoReady = true);
        _videoCtrl!.setLooping(true);
        _videoCtrl!.setVolume(0.0);
        _videoCtrl!.play();
      }
    } catch (_) {}
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {}
  }

  @override
  Widget build(BuildContext context) {
    switch (_step) {
      case _FlowStep.intro:
        return _buildIntroFlow();
      case _FlowStep.catatan:
        return _buildCatatanFlow();
      case _FlowStep.mainLanding:
        return _buildMainLanding();
    }
  }

  // ─── INTRO FLOW (kaya foto 1, 3 slides tap-to-advance) ──────────────────
  Widget _buildIntroFlow() {
    return Scaffold(
      backgroundColor: Colors.black,
      body: PageView.builder(
        controller: _pageCtrl,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: _introSlides.length,
        onPageChanged: (i) => setState(() => _slideIndex = i),
        itemBuilder: (ctx, i) {
          final s = _introSlides[i];
          return _IntroSlide(
            bigText: s['bigText'] as String,
            smallText: s['smallText'] as String,
            icon: s['icon'] as IconData,
            accentColor: s['accent'] as Color,
            totalSlides: _introSlides.length,
            currentIndex: _slideIndex,
            onTap: _nextIntroSlide,
          );
        },
      ),
    );
  }

  // ─── CATATAN FLOW (kaya foto 2) ──────────────────────────────────────────
  Widget _buildCatatanFlow() {
    return Scaffold(
      backgroundColor: Colors.black,
      body: _CatatanSlide(onLanjut: _toCatatanDone),
    );
  }

  // ─── MAIN LANDING (kaya foto 3: VOLTEX-style, video background) ────────────
  Widget _buildMainLanding() {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          // Video background
          Positioned.fill(
            child: _videoReady && _videoCtrl != null
                ? FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _videoCtrl!.value.size.width,
                      height: _videoCtrl!.value.size.height,
                      child: VideoPlayer(_videoCtrl!),
                    ),
                  )
                : Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter, end: Alignment.bottomCenter,
                        colors: [
                          Color(0xFF81D4FA), Color(0xFF29B6F6),
                          Color(0xFF0288D1), Color(0xFF01579B),
                        ],
                      ),
                    ),
                  ),
          ),
          // Subtle dark overlay — ringan saja biar tetap cerah
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.22),
                    Colors.black.withOpacity(0.40),
                    Colors.black.withOpacity(0.55),
                  ],
                ),
              ),
            ),
          ),
          // Content
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(
                  children: [
                    const SizedBox(height: 40),
                    _buildLandingLogo(),
                    const SizedBox(height: 28),
                    _buildLandingTitle(),
                    const SizedBox(height: 24),
                    _buildFeatureChips(),
                    const SizedBox(height: 36),
                    _buildMasukBtn(),
                    const SizedBox(height: 14),
                    _buildBeliAksesBtn(),
                    const SizedBox(height: 14),
                    _buildHubungiBtn(),
                    const SizedBox(height: 28),
                    _buildSocialRow(),
                    const SizedBox(height: 48),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLandingLogo() {
    return AnimatedBuilder(
      animation: _floatCtrl,
      builder: (_, __) => Transform.translate(
        offset: Offset(0, 5 * (_floatCtrl.value - 0.5)),
        child: Container(
          width: 140, height: 140,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: _C.gold.withOpacity(0.5), width: 2.5),
            boxShadow: [
              BoxShadow(color: _C.blue.withOpacity(0.4), blurRadius: 30, spreadRadius: 5),
              BoxShadow(color: _C.gold.withOpacity(0.2), blurRadius: 20, spreadRadius: 2),
            ],
          ),
          child: ClipOval(
            child: Image.asset(
              'assets/images/logo.png',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                color: _C.blueDark,
                child: const Icon(Icons.bolt_rounded, color: _C.gold, size: 60),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLandingTitle() {
    return Column(children: [
      const Text('VICIOUSX',
        style: TextStyle(
          color: Colors.white, fontSize: 42, fontWeight: FontWeight.w900,
          fontFamily: 'Orbitron', letterSpacing: 7,
          shadows: [Shadow(color: Color(0xFF1565C0), blurRadius: 18)],
        ),
      ),
      const SizedBox(height: 10),
      Container(
        height: 2.5, width: 80,
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [_C.gold, _C.blue]),
          borderRadius: BorderRadius.circular(2),
          boxShadow: [BoxShadow(color: _C.gold.withOpacity(0.4), blurRadius: 8)],
        ),
      ),
      const SizedBox(height: 14),
      const Text('APK Terbaru dengan fitur lengkap',
        style: TextStyle(color: Colors.white60, fontSize: 12, letterSpacing: 0.5),
      ),
    ]);
  }

  Widget _buildFeatureChips() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _chip('TERMUX', Icons.phone_android_rounded, 'install di HP, langsung'),
        const SizedBox(width: 10),
        _chip('VPS', Icons.dns_rounded, 'server 24/7 stabil'),
        const SizedBox(width: 10),
        _chip('UBOT', Icons.smart_toy_rounded, 'Bot per user'),
      ],
    );
  }

  Widget _chip(String title, IconData icon, String sub) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.12), width: 1),
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, color: _C.blueLight, size: 20),
        const SizedBox(height: 5),
        Text(title, style: const TextStyle(
          color: Colors.white, fontSize: 9, fontWeight: FontWeight.w800,
          fontFamily: 'Orbitron', letterSpacing: 1,
        )),
        const SizedBox(height: 2),
        Text(sub, style: const TextStyle(color: Colors.white38, fontSize: 8)),
      ]),
    );
  }

  Widget _buildMasukBtn() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        width: double.infinity, height: 58,
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [_C.blue, _C.blueDark]),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: _C.blue.withOpacity(0.45), blurRadius: 20, offset: const Offset(0, 8))],
          border: Border.all(color: _C.blueLight.withOpacity(0.3), width: 1),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginPage())),
            borderRadius: BorderRadius.circular(16),
            child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.login_rounded, color: Colors.white, size: 22),
              SizedBox(width: 12),
              Text('MASUK', style: TextStyle(
                color: Colors.white, fontSize: 14, fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron', letterSpacing: 3,
              )),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _buildBeliAksesBtn() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        width: double.infinity, height: 54,
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [_C.gold, _C.goldDark]),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: _C.gold.withOpacity(0.35), blurRadius: 16, offset: const Offset(0, 6))],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: _showBuySheet,
            borderRadius: BorderRadius.circular(16),
            child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.shopping_cart_rounded, color: Colors.white, size: 20),
              SizedBox(width: 10),
              Text('BELI AKSES', style: TextStyle(
                color: Colors.white, fontSize: 13, fontWeight: FontWeight.w800,
                fontFamily: 'Orbitron', letterSpacing: 2,
              )),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _buildHubungiBtn() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        width: double.infinity, height: 50,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.07),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(0.18), width: 1.5),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => _openUrl('https://t.me/danzz0122'),
            borderRadius: BorderRadius.circular(16),
            child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.headset_mic_rounded, color: Colors.white60, size: 18),
              SizedBox(width: 10),
              Text('HUBUNGI SUPPORT', style: TextStyle(
                color: Colors.white60, fontSize: 11, fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron', letterSpacing: 1.5,
              )),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _buildSocialRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _socialItem(FontAwesomeIcons.telegram, const Color(0xFF29B6F6), 'Developer',
                () => _openUrl('https://t.me/@danzz0122')),
            _socialItem(FontAwesomeIcons.telegram, _C.gold, 'Channel',
                () => _openUrl('https://t.me/Viciousx_information')),
            _socialItem(FontAwesomeIcons.whatsapp, const Color(0xFF25D366), 'WhatsApp',
                () => _openUrl('https://wa.me/6285789599670')),
          ],
        ),
      ),
    );
  }

  Widget _socialItem(IconData icon, Color color, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(children: [
        Container(
          width: 54, height: 54,
          decoration: BoxDecoration(
            shape: BoxShape.circle, color: color.withOpacity(0.1),
            border: Border.all(color: color.withOpacity(0.4), width: 1.5),
          ),
          child: Center(child: FaIcon(icon, color: color, size: 22)),
        ),
        const SizedBox(height: 8),
        Text(label, style: const TextStyle(color: Colors.white60, fontSize: 10)),
      ]),
    );
  }

  void _showBuySheet() {
    showModalBottomSheet(
      context: context, backgroundColor: Colors.transparent, isScrollControlled: true,
      builder: (_) => _BuySheet(onOpenTelegram: () => _openUrl('https://t.me/danzz0122')),
    );
  }
}

// ─── Buy Access Sheet ─────────────────────────────────────────────────────────
class _BuySheet extends StatefulWidget {
  final VoidCallback onOpenTelegram;
  const _BuySheet({required this.onOpenTelegram});
  @override
  State<_BuySheet> createState() => _BuySheetState();
}

class _BuySheetState extends State<_BuySheet> {
  Map<String, dynamic>? _selected;
  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();

  @override
  void dispose() { _userCtrl.dispose(); _passCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 30)],
      ),
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
        top: 24, left: 24, right: 24,
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Center(child: Container(
              width: 40, height: 4,
              decoration: BoxDecoration(color: _C.border, borderRadius: BorderRadius.circular(2)),
            )),
            const SizedBox(height: 20),
            Row(children: [
              Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [_C.gold, _C.goldDark]),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.shopping_bag_rounded, color: Colors.white, size: 18),
              ),
              const SizedBox(width: 12),
              const Text('PILIH PAKET', style: TextStyle(
                color: _C.text, fontSize: 16, fontWeight: FontWeight.w800,
                fontFamily: 'Orbitron', letterSpacing: 2,
              )),
            ]),
            const SizedBox(height: 16),
            GridView.builder(
              shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.35,
              ),
              itemCount: _packages.length,
              itemBuilder: (ctx, i) {
                final pkg = _packages[i];
                final sel = _selected == pkg;
                final c = pkg['color'] as Color;
                return GestureDetector(
                  onTap: () => setState(() => _selected = pkg),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    decoration: BoxDecoration(
                      color: sel ? c.withOpacity(0.08) : _C.surface,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: sel ? c : _C.border, width: sel ? 2 : 1),
                      boxShadow: sel ? [BoxShadow(color: c.withOpacity(0.15), blurRadius: 12)] : null,
                    ),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(pkg['icon'] as IconData, color: c, size: 26),
                      const SizedBox(height: 7),
                      Text(pkg['name'] as String, style: TextStyle(
                        color: c, fontSize: 12, fontWeight: FontWeight.w800,
                        fontFamily: 'Orbitron', letterSpacing: 1,
                      )),
                      const SizedBox(height: 3),
                      Text(pkg['price'] as String,
                        style: const TextStyle(color: _C.textSub, fontSize: 10)),
                    ]),
                  ),
                );
              },
            ),
            if (_selected != null) ...[
              const SizedBox(height: 20),
              const Text('ISI DATA AKUN', style: TextStyle(
                color: _C.text, fontSize: 13, fontWeight: FontWeight.w700,
                fontFamily: 'Orbitron', letterSpacing: 1,
              )),
              const SizedBox(height: 10),
              _field(_userCtrl, 'Username', Icons.person_outline_rounded),
              const SizedBox(height: 10),
              _field(_passCtrl, 'Password', Icons.lock_outline_rounded, obscure: true),
              const SizedBox(height: 18),
              GestureDetector(
                onTap: widget.onOpenTelegram,
                child: Container(
                  width: double.infinity, height: 52,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [_C.gold, _C.goldDark]),
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [BoxShadow(color: _C.gold.withOpacity(0.3), blurRadius: 14, offset: const Offset(0, 5))],
                  ),
                  child: const Center(child: Text('LANJUTKAN', style: TextStyle(
                    color: Colors.white, fontSize: 13, fontWeight: FontWeight.w800,
                    fontFamily: 'Orbitron', letterSpacing: 2,
                  ))),
                ),
              ),
            ],
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController c, String label, IconData icon, {bool obscure = false}) {
    return Container(
      decoration: BoxDecoration(
        color: _C.surface, borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _C.border),
      ),
      child: TextField(
        controller: c, obscureText: obscure,
        style: const TextStyle(color: _C.text, fontSize: 13),
        decoration: InputDecoration(
          labelText: label, labelStyle: const TextStyle(color: _C.textSub, fontSize: 12),
          prefixIcon: Icon(icon, color: _C.blue, size: 18),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        ),
      ),
    );
  }
}
