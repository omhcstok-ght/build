import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'api_config.dart';

// ─── Orange Palette ─────────────────────────────────────────────
const _kBlue      = Color(0xFF1565C0);
const _kBlueDark  = Color(0xFF0D47A1);
const _kBlueLight = Color(0xFF42A5F5);
const _kBg          = Color(0xFF09090B);
const _kCard        = Color(0xFF18181B);
const _kBorder      = Color(0xFF27272A);
const _kWhite       = Colors.white;
const _kGrey        = Color(0xFF8BAAB8);

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  late VideoPlayerController _videoCtrl;
  late AnimationController _pulseCtrl;

  final _targetCtrl = TextEditingController();
  final _bugPageCtrl = PageController(viewportFraction: 0.88);

  String? _selectedBugId;
  bool _isSending = false;
  String? _responseMessage;
  int _currentBugPage = 0;

  List<String> _globalSenders = [];
  bool _isLoadingSenders = false;
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  bool _loadingSender = false;
  Timer? _senderTimer;
  String _selectedSender = 'private';

  // Remaining quota (hari ini)
  int _remainingQuota = 7;
  int _maxQuota = 7;

  bool get canAccessGlobalSender {
    final r = widget.role.toLowerCase();
    return r == 'owner' || r == 'admin' || r == 'moderator' ||
        r == 'partner' || r == 'vip';
  }

  @override
  void initState() {
    super.initState();

    // Video banner — pakai banner.mp4
    _videoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _videoCtrl.setLooping(true);
        _videoCtrl.setVolume(0.0);
        _videoCtrl.play();
      });

    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);

    _fetchSenderStats();
    _loadGlobalSenders();
    _senderTimer = Timer.periodic(const Duration(seconds: 30), (_) => _fetchSenderStats());

    if (widget.listBug.isNotEmpty) {
      _selectedBugId = widget.listBug[0]['bug_id'] as String? ?? '0';
    }
  }

  @override
  void dispose() {
    _videoCtrl.dispose();
    _pulseCtrl.dispose();
    _targetCtrl.dispose();
    _bugPageCtrl.dispose();
    _senderTimer?.cancel();
    super.dispose();
  }

  Future<void> _fetchSenderStats() async {
    if (_loadingSender) return;
    setState(() => _loadingSender = true);
    try {
      final res = await http.get(Uri.parse(
        'http://public.queen-official.com:2139/getSenderStats?key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount  = data['global'] ?? 0;
            _remainingQuota     = data['remaining'] ?? 7;
            _maxQuota           = data['max'] ?? 7;
          });
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _loadingSender = false);
  }

  Future<void> _loadGlobalSenders() async {
    setState(() => _isLoadingSenders = true);
    try {
      final res = await http.get(Uri.parse(
        'http://public.queen-official.com:2139/getActiveSenders?key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['senders'] != null && mounted) {
        setState(() {
          _globalSenders     = List<String>.from(data['senders']);
          _globalSenderCount = _globalSenders.length;
        });
      } else if (mounted) {
        setState(() => _globalSenders = []);
      }
    } catch (_) {
      if (mounted) setState(() => _globalSenders = []);
    } finally {
      if (mounted) setState(() => _isLoadingSenders = false);
    }
  }

  String? _formatPhone(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  void _setResponse(String type, String msg) {
    if (!mounted) return;
    setState(() => _responseMessage = '$type|$msg');
  }

  Future<void> _sendBug() async {
    final raw = _targetCtrl.text.trim();
    if (_formatPhone(raw) == null) {
      _showAlert('❌ Nomor Tidak Valid', 'Gunakan format internasional.\nContoh: +62812xxxxxxxx');
      return;
    }
    if (_selectedSender == 'global' && !canAccessGlobalSender) {
      _showAlert('❌ Akses Ditolak', 'Sender Global hanya untuk VIP, Admin, Owner.');
      return;
    }
    if (_selectedBugId == null || _selectedBugId!.isEmpty) {
      _showAlert('❌ No Bug Selected', 'Pilih 1 bug untuk dikirim.');
      return;
    }
    if (_selectedSender == 'private' && _privateSenderCount == 0) {
      _showAlert('❌ No Private Sender', 'Tidak ada private sender tersedia.');
      return;
    }
    if (_selectedSender == 'global' && _globalSenderCount == 0) {
      _showAlert('❌ No Global Sender', 'Tidak ada global sender tersedia.');
      return;
    }

    setState(() { _isSending = true; _responseMessage = null; });
    try {
      final encodedTarget = Uri.encodeComponent(raw);
      final res = await http.get(Uri.parse(
        'http://public.queen-official.com:2139/sendBug'
        '?key=${widget.sessionKey}'
        '&target=$encodedTarget'
        '&bug=${_selectedBugId}'
        '${_selectedSender == 'global' ? '&senderMode=global' : '&sender=private'}',
      )).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      if (data['valid'] == false) {
        _setResponse('error', 'Session key tidak valid. Silakan login ulang.');
      } else if (data['cooldown'] == true) {
        _setResponse('warning', 'Cooldown aktif! Tunggu ${data['wait'] ?? 0} detik lagi.');
      } else if (data['sended'] == true) {
        _setResponse('success', 'Bug berhasil dikirim ke $raw! [${data['role'] ?? widget.role}]');
        _targetCtrl.clear();
        _fetchSenderStats();
      } else {
        _setResponse('error', 'Gagal mengirim. Server sedang maintenance.');
      }
    } on Exception catch (e) {
      _setResponse('error', e.toString().contains('Timeout')
          ? 'Request timeout. Periksa koneksi internet.'
          : 'Koneksi error. Coba lagi.');
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: AlertDialog(
          backgroundColor: const Color(0xFF18181B),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: _kBlue.withOpacity(0.5), width: 1.5),
          ),
          title: Text(title, style: const TextStyle(
            color: _kBlue, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 15,
          )),
          content: Text(msg, style: const TextStyle(
            color: _kGrey, fontFamily: 'ShareTechMono', fontSize: 13, height: 1.5,
          )),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('OK', style: TextStyle(
                color: _kBlue, fontWeight: FontWeight.bold, fontFamily: 'Orbitron',
              )),
            ),
          ],
        ),
      ),
    );
  }

  // ─── BANNER VIDEO ────────────────────────────────────────────
  Widget _buildBannerVideo() {
    return Container(
      height: 210,
      width: double.infinity,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Video
          ClipRRect(
            child: _videoCtrl.value.isInitialized
                ? FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _videoCtrl.value.size.width,
                      height: _videoCtrl.value.size.height,
                      child: VideoPlayer(_videoCtrl),
                    ),
                  )
                : Container(color: const Color(0xFF18181B)),
          ),
          // Gradient overlay bottom
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter, end: Alignment.bottomCenter,
                colors: [Colors.transparent, Colors.black54],
              ),
            ),
          ),
          // Title text - SUPERIORITY style
          Positioned(
            bottom: 20, left: 0, right: 0,
            child: Center(
              child: Text(
                'DARK CORE',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.9),
                  fontSize: 34,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  letterSpacing: 8,
                  shadows: [
                    Shadow(color: _kBlue.withOpacity(0.8), blurRadius: 20),
                    const Shadow(color: Colors.black, blurRadius: 4),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── NOMOR TARGET CARD ────────────────────────────────────────
  Widget _buildNomorTarget() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: _kBlue.withOpacity(0.92),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withOpacity(0.2),
              ),
              child: const Icon(Icons.phone_android_rounded, color: Colors.white, size: 20),
            ),
            const SizedBox(width: 12),
            const Text('NOMOR TARGET', style: TextStyle(
              color: Colors.white, fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 2,
            )),
          ]),
          const SizedBox(height: 14),
          Container(
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.5),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.white.withOpacity(0.1)),
            ),
            child: TextField(
              controller: _targetCtrl,
              style: const TextStyle(
                color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 15,
              ),
              cursorColor: Colors.white,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(
                hintText: '62xxxxxxxxxxx',
                hintStyle: TextStyle(color: Colors.white.withOpacity(0.35), fontFamily: 'ShareTechMono'),
                prefixIcon: Icon(Icons.language_rounded, color: Colors.white.withOpacity(0.5), size: 20),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── PILIH BUG PANEL ─────────────────────────────────────────
  Widget _buildPilihBug() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: _kBlue.withOpacity(0.92),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row
          Row(
            children: [
              Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  shape: BoxShape.circle, color: Colors.white.withOpacity(0.2),
                ),
                child: const Icon(Icons.bug_report_rounded, color: Colors.white, size: 20),
              ),
              const SizedBox(width: 10),
              const Text('PILIH BUG', style: TextStyle(
                color: Colors.white, fontFamily: 'Orbitron',
                fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 2,
              )),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withOpacity(0.3)),
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Container(width: 7, height: 7,
                    decoration: const BoxDecoration(color: Color(0xFF00FF88), shape: BoxShape.circle),
                  ),
                  const SizedBox(width: 6),
                  const Text('Sender : online', style: TextStyle(
                    color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 11,
                  )),
                ]),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // Bug Carousel
          SizedBox(
            height: 160,
            child: widget.listBug.isEmpty
                ? Center(child: Text('Tidak ada bug tersedia.',
                    style: TextStyle(color: Colors.white.withOpacity(0.5), fontFamily: 'ShareTechMono')))
                : PageView.builder(
                    controller: _bugPageCtrl,
                    itemCount: widget.listBug.length,
                    onPageChanged: (i) => setState(() {
                      _currentBugPage = i;
                      _selectedBugId = widget.listBug[i]['bug_id'] as String? ?? '$i';
                    }),
                    itemBuilder: (ctx, i) {
                      final bug = widget.listBug[i];
                      final bugId = bug['bug_id'] as String? ?? '$i';
                      final isSelected = _selectedBugId == bugId;

                      return GestureDetector(
                        onTap: () => setState(() => _selectedBugId = bugId),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          margin: const EdgeInsets.only(right: 10),
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? Colors.white.withOpacity(0.18)
                                : Colors.black.withOpacity(0.35),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: isSelected ? Colors.white : Colors.white.withOpacity(0.15),
                              width: isSelected ? 1.5 : 1,
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    width: 40, height: 40,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Colors.white.withOpacity(isSelected ? 0.25 : 0.1),
                                    ),
                                    child: Icon(Icons.shield_rounded,
                                      color: isSelected ? Colors.white : Colors.white60, size: 22),
                                  ),
                                  if (isSelected)
                                    Container(
                                      width: 28, height: 28,
                                      decoration: const BoxDecoration(
                                        color: Color(0xFF00CC66), shape: BoxShape.circle,
                                      ),
                                      child: const Icon(Icons.check_rounded, color: Colors.white, size: 16),
                                    ),
                                ],
                              ),
                              const Spacer(),
                              Text(
                                (bug['bug_name'] as String? ?? 'BUG').toUpperCase(),
                                style: const TextStyle(
                                  color: Colors.white, fontFamily: 'Orbitron',
                                  fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 0.5,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.4),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  bug['bug_id']?.toString().toLowerCase() ?? 'bug',
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.6),
                                    fontFamily: 'ShareTechMono', fontSize: 11,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
          const SizedBox(height: 12),

          // Dots
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(widget.listBug.length, (i) {
              final active = i == _currentBugPage;
              return AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: active ? 22 : 7, height: 7,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4),
                  color: active ? Colors.white : Colors.white.withOpacity(0.3),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }

  // ─── PILIH SENDER PANEL ───────────────────────────────────────
  Widget _buildSenderPanel() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(children: [
            Container(
              width: 34, height: 34,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _kBlue.withOpacity(0.12),
                border: Border.all(color: _kBlue.withOpacity(0.3)),
              ),
              child: const Icon(Icons.swap_horiz_rounded, color: _kBlue, size: 18),
            ),
            const SizedBox(width: 10),
            const Text('PILIH SENDER', style: TextStyle(
              color: Color(0xFF1A1A1A), fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 1,
            )),
            const Spacer(),
            GestureDetector(
              onTap: () { _fetchSenderStats(); _loadGlobalSenders(); },
              child: _isLoadingSenders || _loadingSender
                  ? const SizedBox(width: 16, height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2, color: _kBlue))
                  : const Icon(Icons.refresh_rounded, color: _kBlue, size: 20),
            ),
            const SizedBox(width: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: const Color(0xFF00CC66).withOpacity(0.1),
                border: Border.all(color: const Color(0xFF00CC66).withOpacity(0.4)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.circle, color: Color(0xFF00CC66), size: 7),
                const SizedBox(width: 5),
                Text(
                  _loadingSender
                      ? '-- sender online'
                      : '${_privateSenderCount + _globalSenderCount} sender online',
                  style: const TextStyle(
                    color: Color(0xFF00CC66), fontFamily: 'ShareTechMono', fontSize: 11,
                  ),
                ),
              ]),
            ),
          ]),
          const SizedBox(height: 16),

          // Cards
          Row(children: [
            // PRIBADI
            Expanded(
              child: GestureDetector(
                onTap: () => setState(() => _selectedSender = 'private'),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  height: 150,
                  decoration: BoxDecoration(
                    color: _selectedSender == 'private'
                        ? _kBlue.withOpacity(0.1)
                        : const Color(0xFFF5F5F5),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: _selectedSender == 'private' ? _kBlue : const Color(0xFFE0E0E0),
                      width: _selectedSender == 'private' ? 2 : 1,
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.person_rounded,
                        color: _selectedSender == 'private' ? _kBlue : const Color(0xFF9E9E9E),
                        size: 40),
                      const SizedBox(height: 8),
                      Text('Pribadi', style: TextStyle(
                        color: _selectedSender == 'private' ? _kBlue : const Color(0xFF424242),
                        fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 14,
                      )),
                      const SizedBox(height: 6),
                      _privateSenderCount == 0
                          ? Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                              const Icon(Icons.close_rounded, color: Colors.redAccent, size: 14),
                              const SizedBox(width: 4),
                              const Text('Kosong', style: TextStyle(
                                color: Colors.redAccent, fontFamily: 'ShareTechMono',
                                fontWeight: FontWeight.bold, fontSize: 12,
                              )),
                            ])
                          : Text('$_privateSenderCount sender', style: TextStyle(
                              color: _selectedSender == 'private' ? _kBlueDark : _kGrey,
                              fontFamily: 'ShareTechMono', fontSize: 12,
                            )),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),

            // GLOBAL
            Expanded(
              child: GestureDetector(
                onTap: () {
                  if (!canAccessGlobalSender) {
                    _showAlert('❌ Akses Ditolak', 'Sender Global hanya untuk VIP, Admin, Owner.');
                    return;
                  }
                  setState(() => _selectedSender = 'global');
                  _loadGlobalSenders();
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  height: 150,
                  decoration: BoxDecoration(
                    color: _selectedSender == 'global'
                        ? _kBlue.withOpacity(0.1)
                        : const Color(0xFFF5F5F5),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: _selectedSender == 'global' ? _kBlue : const Color(0xFFE0E0E0),
                      width: _selectedSender == 'global' ? 2 : 1,
                    ),
                  ),
                  child: Stack(
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const SizedBox(width: double.infinity),
                          Icon(Icons.public_rounded,
                            color: _selectedSender == 'global' ? _kBlue : const Color(0xFF9E9E9E),
                            size: 40),
                          const SizedBox(height: 8),
                          Text('Global', style: TextStyle(
                            color: _selectedSender == 'global' ? _kBlue : const Color(0xFF424242),
                            fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 14,
                          )),
                          const SizedBox(height: 6),
                          _globalSenderCount == 0
                              ? Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                  const Icon(Icons.close_rounded, color: Colors.redAccent, size: 14),
                                  const SizedBox(width: 4),
                                  const Text('Kosong', style: TextStyle(
                                    color: Colors.redAccent, fontFamily: 'ShareTechMono',
                                    fontWeight: FontWeight.bold, fontSize: 12,
                                  )),
                                ])
                              : Text('$_globalSenderCount sender', style: TextStyle(
                                  color: _selectedSender == 'global' ? _kBlueDark : _kGrey,
                                  fontFamily: 'ShareTechMono', fontSize: 12,
                                )),
                        ],
                      ),
                      if (!canAccessGlobalSender)
                        Positioned(top: 8, right: 8,
                          child: Container(
                            width: 22, height: 22,
                            decoration: const BoxDecoration(color: Colors.amber, shape: BoxShape.circle),
                            child: const Icon(Icons.lock_rounded, color: Colors.white, size: 12),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ]),
          const SizedBox(height: 14),

          // Sisa kirim info
          Row(children: [
            Icon(Icons.info_outline_rounded, color: _kGrey.withOpacity(0.7), size: 14),
            const SizedBox(width: 6),
            Text(
              'Sisa kirim global hari ini: $_remainingQuota / $_maxQuota',
              style: TextStyle(
                color: _kGrey.withOpacity(0.8), fontFamily: 'ShareTechMono', fontSize: 11,
              ),
            ),
          ]),

          // Sender list (when global selected)
          if (_selectedSender == 'global' && _globalSenders.isNotEmpty) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _kBlue.withOpacity(0.05),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _kBlue.withOpacity(0.2)),
              ),
              child: Column(
                children: [
                  ..._globalSenders.take(3).map((s) => Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Row(children: [
                      const Icon(Icons.circle, color: Color(0xFF00CC66), size: 7),
                      const SizedBox(width: 8),
                      Text(s, style: const TextStyle(
                        color: _kBlue, fontFamily: 'ShareTechMono', fontSize: 11,
                      )),
                    ]),
                  )),
                  if (_globalSenders.length > 3)
                    Text('+ ${_globalSenders.length - 3} lainnya...',
                      style: TextStyle(color: _kGrey.withOpacity(0.6), fontSize: 10)),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ─── RESPONSE BANNER ──────────────────────────────────────────
  Widget _buildResponse() {
    if (_responseMessage == null) return const SizedBox.shrink();
    final parts = _responseMessage!.split('|');
    final type  = parts[0];
    final msg   = parts.length > 1 ? parts[1] : '';

    // Popup parchment style kaya foto ke-6 "MENGIRIM BUG"
    return GestureDetector(
      onTap: () => setState(() => _responseMessage = null),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 14),
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Parchment background
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
              decoration: BoxDecoration(
                image: const DecorationImage(
                  image: AssetImage('assets/images/popup_paper.png'),
                  fit: BoxFit.fill,
                ),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 20, offset: const Offset(0, 8)),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Title
                  Text(
                    type == 'success' ? 'MENGIRIM BUG' : type == 'warning' ? 'PERINGATAN' : 'GAGAL',
                    style: TextStyle(
                      color: type == 'success' ? const Color(0xFFCC2200) : type == 'warning' ? const Color(0xFFB8860B) : const Color(0xFFCC2200),
                      fontFamily: 'Orbitron', fontWeight: FontWeight.w900,
                      fontSize: 14, letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 10),
                  // Circular icon / checkmark
                  Container(
                    width: 60, height: 60,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: type == 'success' ? const Color(0xFFCC2200) : Colors.amber,
                        width: 3,
                      ),
                    ),
                    child: Center(
                      child: Icon(
                        type == 'success' ? Icons.check_rounded : type == 'warning' ? Icons.warning_rounded : Icons.close_rounded,
                        color: type == 'success' ? const Color(0xFFCC2200) : Colors.amber,
                        size: 30,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  // Message
                  Text(msg,
                    style: const TextStyle(
                      color: Color(0xFF333333), fontSize: 12.5, height: 1.5,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 6),
                  Text('Jangan tutup aplikasi',
                    style: const TextStyle(
                      color: Color(0xFF555555), fontSize: 10.5, fontStyle: FontStyle.italic,
                    ),
                  ),
                  Text('Payload jalan di background',
                    style: const TextStyle(
                      color: Color(0xFF555555), fontSize: 10.5, fontStyle: FontStyle.italic,
                    ),
                  ),
                  const SizedBox(height: 12),
                  // Close button
                  GestureDetector(
                    onTap: () => setState(() => _responseMessage = null),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFF111111),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Text('TUTUP', style: TextStyle(
                        color: Colors.white, fontFamily: 'Orbitron',
                        fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 2,
                      )),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── KIRIM BUG BUTTON ─────────────────────────────────────────
  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (_, __) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Container(
          height: 62,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: const LinearGradient(
              colors: [_kBlue, _kBlueDark],
              begin: Alignment.centerLeft, end: Alignment.centerRight,
            ),
            boxShadow: [BoxShadow(
              color: _kBlue.withOpacity(0.2 + _pulseCtrl.value * 0.3),
              blurRadius: 24 + _pulseCtrl.value * 12, spreadRadius: 1,
            )],
          ),
          child: ElevatedButton(
            onPressed: _isSending ? null : _sendBug,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent, shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)), elevation: 0,
            ),
            child: _isSending
                ? const SizedBox(width: 26, height: 26,
                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3))
                : const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.play_arrow_rounded, color: Colors.white, size: 26),
                      SizedBox(width: 10),
                      Text('🚀KIRIM BUG', style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.w900,
                        fontSize: 16, fontFamily: 'Orbitron', letterSpacing: 2,
                      )),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  // ─── FOOTER ───────────────────────────────────────────────────
  Widget _buildFooter() {
    return Column(children: [
      Text('DARK CORE TEAM', style: TextStyle(
        color: Colors.white.withOpacity(0.3), fontFamily: 'Orbitron',
        fontSize: 11, letterSpacing: 2,
      )),
      const SizedBox(height: 4),
      Text('© 2026 DARK CORE EXECUTIVE BY CELL', style: TextStyle(
        color: Colors.white.withOpacity(0.2), fontFamily: 'ShareTechMono', fontSize: 10,
      )),
    ]);
  }

  // ─── APP BAR ──────────────────────────────────────────────────
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.black.withOpacity(0.4),
              border: Border.all(color: Colors.white.withOpacity(0.15)),
            ),
            child: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 16),
          ),
        ),
        const Spacer(),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
          decoration: BoxDecoration(
            color: _kBlue,
            borderRadius: BorderRadius.circular(30),
            boxShadow: [BoxShadow(color: _kBlue.withOpacity(0.4), blurRadius: 16, offset: const Offset(0, 4))],
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 20, height: 20,
              decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
              child: const Icon(Icons.circle, color: _kBlue, size: 10),
            ),
            const SizedBox(width: 8),
            const Text('DARKCORE BUG', style: TextStyle(
              color: Colors.white, fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 1,
            )),
          ]),
        ),
        const Spacer(),
        GestureDetector(
          onTap: () { _fetchSenderStats(); _loadGlobalSenders(); },
          child: Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.black.withOpacity(0.4),
              border: Border.all(color: Colors.white.withOpacity(0.15)),
            ),
            child: const Icon(Icons.refresh_rounded, color: Colors.white, size: 18),
          ),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      body: Stack(
        children: [
          // Background overlay
          Positioned.fill(child: Container(color: const Color(0xFF0D0D0D))),

          SafeArea(
            child: Column(children: [
              _buildAppBar(),
              Expanded(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  child: Column(children: [
                    // Banner video
                    _buildBannerVideo(),
                    const SizedBox(height: 14),

                    // Nomor target
                    _buildNomorTarget(),
                    const SizedBox(height: 14),

                    // Pilih bug
                    _buildPilihBug(),
                    const SizedBox(height: 14),

                    // Pilih sender
                    _buildSenderPanel(),
                    const SizedBox(height: 20),

                    // Response banner
                    _buildResponse(),
                    if (_responseMessage != null) const SizedBox(height: 14),

                    // Kirim bug button
                    _buildSendButton(),
                    const SizedBox(height: 20),

                    // Footer
                    _buildFooter(),
                    const SizedBox(height: 30),
                  ]),
                ),
              ),
            ]),
          ),
        ],
      ),
    );
  }
}
