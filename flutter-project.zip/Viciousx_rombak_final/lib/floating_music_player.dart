import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

const String _kMusicUrl = 'https://files.catbox.moe/dae19d.mp3';

// ─── GLOBAL PLAYER STATE ─────────────────────────────────────────────────────
class MusicPlayerService {
  static final MusicPlayerService _instance = MusicPlayerService._();
  factory MusicPlayerService() => _instance;
  MusicPlayerService._() {
    _player.setReleaseMode(ReleaseMode.loop);
  }

  final AudioPlayer _player = AudioPlayer();
  bool isPlaying = false;
  bool _initialized = false;

  Future<void> autoPlay() async {
    if (_initialized) return;
    _initialized = true;
    try {
      await _player.setSourceUrl(_kMusicUrl);
      await _player.resume();
      isPlaying = true;
    } catch (_) {}
  }

  Future<void> toggle() async {
    if (!_initialized) { await autoPlay(); return; }
    if (isPlaying) {
      await _player.pause();
      isPlaying = false;
    } else {
      await _player.resume();
      isPlaying = true;
    }
  }

  void dispose() { _player.dispose(); }
}

// ─── FLOATING CASSETTE WIDGET ─────────────────────────────────────────────────
class FloatingMusicPlayer extends StatefulWidget {
  const FloatingMusicPlayer({Key? key}) : super(key: key);
  @override
  State<FloatingMusicPlayer> createState() => _FloatingMusicPlayerState();
}

class _FloatingMusicPlayerState extends State<FloatingMusicPlayer>
    with TickerProviderStateMixin {
  final _service = MusicPlayerService();
  late AnimationController _spinCtrl;
  late AnimationController _bounceCtrl;
  late Animation<double> _bounceAnim;

  Offset _position = const Offset(16, 200);
  bool _expanded = false;

  @override
  void initState() {
    super.initState();
    _spinCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat();
    _bounceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat(reverse: true);
    _bounceAnim = Tween<double>(begin: 0, end: 8).animate(CurvedAnimation(parent: _bounceCtrl, curve: Curves.easeInOut));
    _service.autoPlay().then((_) { if (mounted) setState(() {}); });
  }

  @override
  void dispose() {
    _spinCtrl.dispose();
    _bounceCtrl.dispose();
    super.dispose();
  }

  void _toggleExpanded() => setState(() => _expanded = !_expanded);

  void _togglePlay() async {
    await _service.toggle();
    if (mounted) setState(() {
      if (_service.isPlaying) _spinCtrl.repeat();
      else _spinCtrl.stop();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: _position.dx,
      top: _position.dy,
      child: AnimatedBuilder(
        animation: _bounceAnim,
        builder: (_, child) => Transform.translate(
          offset: Offset(0, _service.isPlaying ? _bounceAnim.value : 0),
          child: child,
        ),
        child: GestureDetector(
          onPanUpdate: (d) => setState(() => _position += d.delta),
          onTap: _toggleExpanded,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOutBack,
            width: _expanded ? 180 : 60,
            height: 60,
            decoration: BoxDecoration(
              color: const Color(0xFF0D1B3E),
              borderRadius: BorderRadius.circular(_expanded ? 30 : 30),
              border: Border.all(color: const Color(0xFF29B6F6).withOpacity(0.5), width: 1.5),
              boxShadow: [
                BoxShadow(color: const Color(0xFF0077C2).withOpacity(0.4), blurRadius: 16, spreadRadius: 1),
                BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 4)),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(30),
              child: Row(
                children: [
                  // Cassette reel — spins when playing
                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: AnimatedBuilder(
                      animation: _spinCtrl,
                      builder: (_, __) => Transform.rotate(
                        angle: _service.isPlaying ? _spinCtrl.value * 2 * math.pi : 0,
                        child: CustomPaint(
                          size: const Size(40, 40),
                          painter: _CassettePainter(isPlaying: _service.isPlaying),
                        ),
                      ),
                    ),
                  ),
                  // Expanded controls
                  if (_expanded) ...[
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('VICIOUSX THEME',
                            style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1),
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 2),
                          Text(_service.isPlaying ? 'Sedang Putar ▶' : 'Dijeda ⏸',
                            style: const TextStyle(color: Color(0xFF29B6F6), fontSize: 8),
                          ),
                        ],
                      ),
                    ),
                    // Play/Pause button
                    GestureDetector(
                      onTap: _togglePlay,
                      child: Container(
                        width: 36, height: 36,
                        margin: const EdgeInsets.only(right: 8),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _service.isPlaying ? Colors.redAccent.withOpacity(0.2) : const Color(0xFF0077C2).withOpacity(0.2),
                          border: Border.all(
                            color: _service.isPlaying ? Colors.redAccent : const Color(0xFF29B6F6),
                          ),
                        ),
                        child: Icon(
                          _service.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                          color: _service.isPlaying ? Colors.redAccent : const Color(0xFF29B6F6),
                          size: 18,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─── CASSETTE PAINTER ─────────────────────────────────────────────────────────
class _CassettePainter extends CustomPainter {
  final bool isPlaying;
  _CassettePainter({required this.isPlaying});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r = size.width / 2;

    // Outer ring
    canvas.drawCircle(Offset(cx, cy), r,
      Paint()..color = const Color(0xFF29B6F6).withOpacity(0.25)..style = PaintingStyle.fill);
    canvas.drawCircle(Offset(cx, cy), r,
      Paint()..color = isPlaying ? const Color(0xFF29B6F6) : const Color(0xFF0077C2).withOpacity(0.5)
             ..style = PaintingStyle.stroke..strokeWidth = 2);

    // Inner hub
    canvas.drawCircle(Offset(cx, cy), r * 0.35,
      Paint()..color = const Color(0xFF0D1B3E)..style = PaintingStyle.fill);
    canvas.drawCircle(Offset(cx, cy), r * 0.35,
      Paint()..color = isPlaying ? const Color(0xFF29B6F6) : Colors.white24
             ..style = PaintingStyle.stroke..strokeWidth = 1.5);

    // Reel spokes x3
    final spokePaint = Paint()
      ..color = (isPlaying ? const Color(0xFF29B6F6) : Colors.white38).withOpacity(0.7)
      ..strokeWidth = 1.5..strokeCap = StrokeCap.round;
    for (int i = 0; i < 3; i++) {
      final angle = i * 2 * math.pi / 3;
      canvas.drawLine(
        Offset(cx + math.cos(angle) * r * 0.38, cy + math.sin(angle) * r * 0.38),
        Offset(cx + math.cos(angle) * r * 0.8,  cy + math.sin(angle) * r * 0.8),
        spokePaint,
      );
    }

    // Center dot
    canvas.drawCircle(Offset(cx, cy), r * 0.12,
      Paint()..color = isPlaying ? const Color(0xFF29B6F6) : Colors.white38);
  }

  @override
  bool shouldRepaint(_CassettePainter old) => old.isPlaying != isPlaying;
}
