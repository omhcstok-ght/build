import 'dart:math';
import 'package:flutter/material.dart';
import 'dashboard_page.dart';

// ─── AUDIO INTRO PAGE (kaya foto 8 — MANTA style) ────────────────────────────
class AudioIntroPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const AudioIntroPage({
    Key? key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  }) : super(key: key);

  @override
  State<AudioIntroPage> createState() => _AudioIntroPageState();
}

class _AudioIntroPageState extends State<AudioIntroPage> with TickerProviderStateMixin {
  late AnimationController _vinylCtrl;   // vinyl rotation
  late AnimationController _waveCtrl;    // audio wave
  late AnimationController _glowCtrl;    // glow pulse
  late AnimationController _enterCtrl;   // enter button pulse

  bool _isPlaying = true;

  void _enterDashboard() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _vinylCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat();
    _waveCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))..repeat(reverse: true);
    _glowCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 1600))..repeat(reverse: true);
    _enterCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _vinylCtrl.dispose();
    _waveCtrl.dispose();
    _glowCtrl.dispose();
    _enterCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF060D1A),
      body: Stack(children: [
        // ─── Animated BG grid ───────────────────────────────────────────────
        Positioned.fill(child: CustomPaint(painter: _GridBgPainter())),

        // ─── Content ────────────────────────────────────────────────────────
        SafeArea(
          child: Column(children: [
            // ─── Top bar ──────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: Row(children: [
                // App icon + name
                Container(
                  width: 36, height: 36,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(colors: [Color(0xFF0077C2), Color(0xFF29B6F6)]),
                  ),
                  child: const Icon(Icons.bolt_rounded, color: Colors.white, size: 18),
                ),
                const SizedBox(width: 10),
                const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('VOLTEX AUDIO ENGINE', style: TextStyle(
                    color: Color(0xFF00FFF7), fontFamily: 'Orbitron', fontSize: 10,
                    fontWeight: FontWeight.bold, letterSpacing: 1,
                  )),
                  Text('USER // MYSTICNOY', style: TextStyle(
                    color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 9,
                  )),
                ]),
                const Spacer(),
                // STEREO badge
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFF00FFF7).withOpacity(0.12),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: const Color(0xFF00FFF7).withOpacity(0.4)),
                  ),
                  child: const Row(mainAxisSize: MainAxisSize.min, children: [
                    CircleAvatar(radius: 3, backgroundColor: Color(0xFF00FFF7)),
                    SizedBox(width: 5),
                    Text('STEREO', style: TextStyle(
                      color: Color(0xFF00FFF7), fontFamily: 'Orbitron', fontSize: 8, fontWeight: FontWeight.bold,
                    )),
                  ]),
                ),
              ]),
            ),

            const SizedBox(height: 20),

            // ─── Soundtrack label ─────────────────────────────────────────
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                border: Border.all(color: const Color(0xFF00FFF7).withOpacity(0.4)),
                borderRadius: BorderRadius.circular(6),
              ),
              child: const Text('SOUNDTRACK', style: TextStyle(
                color: Color(0xFF00FFF7), fontFamily: 'Orbitron', fontSize: 9,
                fontWeight: FontWeight.bold, letterSpacing: 3,
              )),
            ),
            const SizedBox(height: 14),

            const Text('DENGARKAN MUSIC', style: TextStyle(
              color: Colors.white, fontFamily: 'Orbitron', fontSize: 22,
              fontWeight: FontWeight.w900, letterSpacing: 2,
            )),
            const SizedBox(height: 8),
            const Text('Nikmati lagu pembuka sebelum masuk ke\ndashboard utama.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 12, height: 1.5)),

            const SizedBox(height: 30),

            // ─── Vinyl disc ──────────────────────────────────────────────
            Expanded(
              child: Center(
                child: AnimatedBuilder(
                  animation: Listenable.merge([_vinylCtrl, _glowCtrl]),
                  builder: (_, __) {
                    return Container(
                      width: 240, height: 240,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF0077C2).withOpacity(0.3 + _glowCtrl.value * 0.25),
                            blurRadius: 40 + _glowCtrl.value * 20,
                            spreadRadius: 4,
                          ),
                          BoxShadow(
                            color: const Color(0xFF00FFF7).withOpacity(0.1 + _glowCtrl.value * 0.1),
                            blurRadius: 60,
                            spreadRadius: 8,
                          ),
                        ],
                      ),
                      child: Transform.rotate(
                        angle: _isPlaying ? _vinylCtrl.value * 2 * pi : 0,
                        child: CustomPaint(
                          painter: _VinylPainter(),
                          child: Center(
                            child: Container(
                              width: 76, height: 76,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: const Color(0xFF0A1628),
                                border: Border.all(color: const Color(0xFF00FFF7).withOpacity(0.6), width: 2),
                                boxShadow: [BoxShadow(color: const Color(0xFF00FFF7).withOpacity(0.3), blurRadius: 12)],
                              ),
                              child: Center(child: Image.asset(
                                'assets/images/logo.png', width: 44, height: 44, fit: BoxFit.contain,
                                errorBuilder: (_, __, ___) => const Icon(Icons.bolt_rounded, color: Color(0xFF00FFF7), size: 30),
                              )),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),

            const SizedBox(height: 20),

            // ─── Audio wave bars ─────────────────────────────────────────
            AnimatedBuilder(
              animation: _waveCtrl,
              builder: (_, __) => _buildWaveBars(),
            ),

            const SizedBox(height: 20),

            // ─── Now playing pill ─────────────────────────────────────────
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xFF00FFF7).withOpacity(0.08),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFF00FFF7).withOpacity(0.3)),
              ),
              child: const Row(mainAxisSize: MainAxisSize.min, children: [
                CircleAvatar(radius: 4, backgroundColor: Color(0xFF00FFF7)),
                SizedBox(width: 8),
                Text('SEDANG DIPUTAR', style: TextStyle(
                  color: Color(0xFF00FFF7), fontFamily: 'Orbitron', fontSize: 10,
                  fontWeight: FontWeight.bold, letterSpacing: 2,
                )),
              ]),
            ),

            const SizedBox(height: 16),

            // ─── Enter dashboard button ────────────────────────────────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: AnimatedBuilder(
                animation: _enterCtrl,
                builder: (_, __) => GestureDetector(
                  onTap: _enterDashboard,
                  child: Container(
                    height: 56,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          const Color(0xFF0077C2),
                          Color.lerp(const Color(0xFF00FFF7), const Color(0xFF0077C2), 1 - _enterCtrl.value * 0.4)!,
                        ],
                        begin: Alignment.centerLeft, end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF0077C2).withOpacity(0.3 + _enterCtrl.value * 0.3),
                          blurRadius: 20 + _enterCtrl.value * 10,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 20),
                      SizedBox(width: 12),
                      Text('MASUK DASHBOARD', style: TextStyle(
                        color: Colors.white, fontFamily: 'Orbitron', fontSize: 13,
                        fontWeight: FontWeight.w900, letterSpacing: 1,
                      )),
                      SizedBox(width: 8),
                      Icon(Icons.chevron_right_rounded, color: Colors.white70, size: 18),
                    ]),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 16),

            // ─── Bottom status bar ────────────────────────────────────────
            const Padding(
              padding: EdgeInsets.only(bottom: 16),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                _StatusDot(color: Color(0xFF00FFF7), label: 'BACKGROUND AUDIO ENGINE'),
                SizedBox(width: 16),
                _StatusDot(color: Color(0xFF22C55E), label: 'AUTO-SYNC ACTIVE'),
              ]),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _buildWaveBars() {
    const barCount = 28;
    final t = _waveCtrl.value;
    return SizedBox(
      height: 44,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: List.generate(barCount, (i) {
          final phase = (i / barCount) * pi * 2;
          final height = 8.0 + sin(phase + t * pi * 2) * 14 + sin(phase * 2 + t * pi) * 6;
          final h = height.clamp(4.0, 36.0);
          final opacity = 0.4 + (h / 36) * 0.6;
          return Container(
            width: 3, height: h,
            margin: const EdgeInsets.symmetric(horizontal: 1.5),
            decoration: BoxDecoration(
              color: const Color(0xFF00FFF7).withOpacity(opacity),
              borderRadius: BorderRadius.circular(2),
              boxShadow: h > 24 ? [BoxShadow(color: const Color(0xFF00FFF7).withOpacity(0.4), blurRadius: 4)] : null,
            ),
          );
        }),
      ),
    );
  }
}

// ─── Status dot widget ────────────────────────────────────────────────────────
class _StatusDot extends StatelessWidget {
  final Color color;
  final String label;
  const _StatusDot({required this.color, required this.label});

  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
    CircleAvatar(radius: 3, backgroundColor: color),
    const SizedBox(width: 5),
    Text(label, style: TextStyle(color: color.withOpacity(0.8), fontFamily: 'ShareTechMono', fontSize: 8, letterSpacing: 0.5)),
  ]);
}

// ─── Vinyl disc painter ──────────────────────────────────────────────────────
class _VinylPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2;

    // Main disc
    canvas.drawCircle(center, r, Paint()..color = const Color(0xFF0A1628));

    // Grooves
    for (int i = 1; i <= 12; i++) {
      final gr = r * (0.4 + i * 0.045);
      if (gr > r) break;
      canvas.drawCircle(center, gr, Paint()
        ..color = const Color(0xFF1A3050).withOpacity(0.7)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.8);
    }

    // Cyan arc highlight
    final arcPaint = Paint()
      ..color = const Color(0xFF00FFF7).withOpacity(0.25)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    canvas.drawArc(Rect.fromCircle(center: center, radius: r * 0.75), -0.5, 1.5, false, arcPaint);

    // Outer glow ring
    canvas.drawCircle(center, r - 2, Paint()
      ..color = const Color(0xFF0077C2).withOpacity(0.3)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3);
  }

  @override
  bool shouldRepaint(_) => false;
}

// ─── Grid background painter ─────────────────────────────────────────────────
class _GridBgPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF0077C2).withOpacity(0.06)
      ..strokeWidth = 0.5;

    const spacing = 40.0;
    for (double x = 0; x <= size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y <= size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }

    // Corner dots
    final dotPaint = Paint()..color = const Color(0xFF00FFF7).withOpacity(0.12);
    for (double x = spacing; x < size.width; x += spacing) {
      for (double y = spacing; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), 1, dotPaint);
      }
    }
  }

  @override
  bool shouldRepaint(_) => false;
}
