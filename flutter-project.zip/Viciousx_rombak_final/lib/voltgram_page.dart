import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'dart:io';
import 'api_config.dart';

// ─── VOLTGRAM PAGE ────────────────────────────────────────────────────────────
class VoltgramPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  const VoltgramPage({Key? key, required this.sessionKey, required this.username}) : super(key: key);
  @override State<VoltgramPage> createState() => _VoltgramPageState();
}

class _VoltgramPageState extends State<VoltgramPage> with TickerProviderStateMixin {
  List<Map<String, dynamic>> _statuses = [];
  bool _loading = true;
  late AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat(reverse: true);
    _loadStatuses();
  }

  @override void dispose() { _pulseCtrl.dispose(); super.dispose(); }

  Future<void> _loadStatuses() async {
    try {
      final r = await http.get(Uri.parse('$baseUrl/voltgram/list?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 15));
      if (r.statusCode == 200) {
        final d = json.decode(r.body);
        if (mounted) setState(() { _statuses = List<Map<String,dynamic>>.from(d['statuses'] ?? []); _loading = false; });
      }
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _pickAndUpload(bool isVideo) async {
    final picker = ImagePicker();
    final file = isVideo
        ? await picker.pickVideo(source: ImageSource.gallery)
        : await picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (file == null) return;
    // Show caption dialog
    final caption = await _showCaptionDialog();
    if (!mounted) return;
    _showUploadingSnack();
    try {
      final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/voltgram/upload?key=${widget.sessionKey}'));
      req.fields['caption'] = caption ?? '';
      req.fields['type'] = isVideo ? 'video' : 'photo';
      req.files.add(await http.MultipartFile.fromPath('media', file.path));
      final res = await req.send().timeout(const Duration(seconds: 120));
      if (res.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('✓ Status berhasil diupload!'), backgroundColor: Color(0xFF0077C2)));
        _loadStatuses();
      }
    } catch (_) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Gagal upload. Coba lagi.'), backgroundColor: Colors.red));
    }
  }

  Future<String?> _showCaptionDialog() async {
    final ctrl = TextEditingController();
    return showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: const Color(0xFF1C1C2E),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      title: const Text('Tambah Caption', style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 13)),
      content: TextField(
        controller: ctrl, maxLines: 3, maxLength: 150,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          hintText: 'Tulis sesuatu...',
          hintStyle: const TextStyle(color: Colors.white54),
          filled: true, fillColor: Colors.white12,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Skip', style: TextStyle(color: Colors.white54))),
        ElevatedButton(
          onPressed: () => Navigator.pop(ctx, ctrl.text),
          style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0077C2), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
          child: const Text('Upload'),
        ),
      ],
    ));
  }

  void _showUploadingSnack() => ScaffoldMessenger.of(context).showSnackBar(
    const SnackBar(content: Row(children: [SizedBox(width:16,height:16,child:CircularProgressIndicator(strokeWidth:2,color:Colors.white)), SizedBox(width:10), Text('Mengupload...')]), duration: Duration(seconds: 20), backgroundColor: Color(0xFF0054A6)),
  );

  Future<void> _likeStatus(String id) async {
    try { await http.post(Uri.parse('$baseUrl/voltgram/like?key=${widget.sessionKey}&id=$id')); _loadStatuses(); } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE8F4FD),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0054A6),
        flexibleSpace: Container(decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF0054A6), Color(0xFF0288D1)]))),
        title: const Text('VICIGRAM', style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, letterSpacing: 3, fontSize: 16)),
        centerTitle: true,
        actions: [
          IconButton(icon: const Icon(Icons.refresh_rounded, color: Colors.white), onPressed: _loadStatuses),
        ],
      ),
      floatingActionButton: Column(mainAxisSize: MainAxisSize.min, children: [
        FloatingActionButton.small(
          heroTag: 'vid',
          backgroundColor: const Color(0xFFE65100),
          onPressed: () => _pickAndUpload(true),
          child: const Icon(Icons.videocam_rounded, color: Colors.white),
        ),
        const SizedBox(height: 8),
        FloatingActionButton(
          heroTag: 'photo',
          backgroundColor: const Color(0xFF0077C2),
          onPressed: () => _pickAndUpload(false),
          child: const Icon(Icons.add_photo_alternate_rounded, color: Colors.white),
        ),
      ]),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFF0077C2)))
          : _statuses.isEmpty
              ? _buildEmpty()
              : ListView.builder(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 80),
                  itemCount: _statuses.length,
                  itemBuilder: (ctx, i) => _buildStatusCard(_statuses[i]),
                ),
    );
  }

  Widget _buildEmpty() => Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    Icon(Icons.photo_library_outlined, size: 64, color: const Color(0xFF0077C2).withOpacity(0.4)),
    const SizedBox(height: 16),
    const Text('Belum ada status', style: TextStyle(color: Color(0xFF4A7FA5), fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
    const SizedBox(height: 8),
    const Text('Jadilah yang pertama upload!', style: TextStyle(color: Color(0xFF90CAF9), fontSize: 12)),
  ]));

  Widget _buildStatusCard(Map<String, dynamic> s) {
    final isVideo = s['type'] == 'video';
    final likes = s['likes'] ?? 0;
    final views = s['views'] ?? 0;
    final viewers = List<String>.from(s['viewers'] ?? []);
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: const Color(0xFF0077C2).withOpacity(0.1), blurRadius: 16, offset: const Offset(0, 4))],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Header
        Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(colors: [Color(0xFF0054A6), Color(0xFF29B6F6)]),
              ),
              child: Center(child: Text(
                (s['username'] ?? 'U').substring(0, 1).toUpperCase(),
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontFamily: 'Orbitron'),
              )),
            ),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(s['username'] ?? 'Unknown', style: const TextStyle(color: Color(0xFF0D2137), fontWeight: FontWeight.bold, fontSize: 13)),
              Text(s['time'] ?? '', style: const TextStyle(color: Color(0xFF90CAF9), fontSize: 11)),
            ])),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(color: isVideo ? const Color(0xFFE65100).withOpacity(0.1) : const Color(0xFF0077C2).withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(isVideo ? Icons.videocam_rounded : Icons.image_rounded, size: 12, color: isVideo ? const Color(0xFFE65100) : const Color(0xFF0077C2)),
                const SizedBox(width: 4),
                Text(isVideo ? 'Video' : 'Foto', style: TextStyle(fontSize: 10, color: isVideo ? const Color(0xFFE65100) : const Color(0xFF0077C2), fontWeight: FontWeight.bold)),
              ]),
            ),
          ]),
        ),
        // Media
        ClipRRect(
          borderRadius: BorderRadius.zero,
          child: Container(
            height: 220, color: const Color(0xFF0D2137),
            child: s['url'] != null
                ? Image.network(s['url'], fit: BoxFit.cover, width: double.infinity,
                    errorBuilder: (_, __, ___) => Center(child: Icon(isVideo ? Icons.videocam_rounded : Icons.broken_image_rounded, color: Colors.white54, size: 48)))
                : Center(child: Icon(isVideo ? Icons.videocam_rounded : Icons.image_rounded, color: Colors.white54, size: 48)),
          ),
        ),
        // Caption
        if ((s['caption'] ?? '').isNotEmpty)
          Padding(padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
            child: Text(s['caption'], style: const TextStyle(color: Color(0xFF0D2137), fontSize: 13, height: 1.4))),
        // Stats + actions
        Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              _statChip(Icons.remove_red_eye_rounded, '$views tontonan', const Color(0xFF0077C2)),
              const SizedBox(width: 10),
              GestureDetector(
                onTap: () => _likeStatus(s['id'] ?? ''),
                child: _statChip(Icons.favorite_rounded, '$likes suka', Colors.pinkAccent),
              ),
            ]),
            if (viewers.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text('Ditonton oleh: ${viewers.take(3).join(', ')}${viewers.length > 3 ? " +${viewers.length - 3} lainnya" : ""}',
                style: const TextStyle(color: Color(0xFF90CAF9), fontSize: 11)),
            ],
          ]),
        ),
      ]),
    );
  }

  Widget _statChip(IconData icon, String label, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
    decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(10), border: Border.all(color: color.withOpacity(0.3))),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 13, color: color),
      const SizedBox(width: 5),
      Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold)),
    ]),
  );
}
