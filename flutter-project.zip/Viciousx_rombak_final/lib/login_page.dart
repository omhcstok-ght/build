import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'api_config.dart';
import 'splash.dart';

// ─── Palette: White + Blue-Grey + Blue + Gold ─────────────────────────────────
class _C {
  static const bg         = Color(0xFFF0F4FF);    // light blue-grey background
  static const bgDeep     = Color(0xFFE8EEF9);    // slightly deeper bg
  static const surface    = Color(0xFFFFFFFF);    // white surface
  static const card       = Color(0xFFFFFFFF);    // card white
  static const border     = Color(0xFFCDD5E8);    // border soft blue
  static const borderLit  = Color(0xFFAEC0DC);    // border lit

  static const blue       = Color(0xFF1565C0);    // primary blue
  static const blueLight  = Color(0xFF42A5F5);    // light blue
  static const blueDark   = Color(0xFF0D47A1);    // dark blue
  static const chrome     = Color(0xFF1565C0);
  static const frost      = Color(0xFF90CAF9);

  static const gold       = Color(0xFFD4A017);    // gold accent
  static const goldLight  = Color(0xFFFFD700);
  static const goldDark   = Color(0xFFB8860B);

  static const green      = Color(0xFF22C55E);
  static const amber      = Color(0xFFF59E0B);
  static const red        = Color(0xFFEF4444);

  static const text       = Color(0xFF0D1B3E);    // deep navy
  static const textSub    = Color(0xFF4A6FA5);    // blue-grey sub
  static const textDim    = Color(0xFF8BA3C7);    // dim

  static const LinearGradient metalGrad = LinearGradient(
    colors: [Color(0xFF1565C0), Color(0xFF0D47A1), Color(0xFF0A2F6B)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );
  static const LinearGradient accentGrad = LinearGradient(
    colors: [Color(0xFF1565C0), Color(0xFF0D47A1), Color(0xFFD4A017)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );
  static const LinearGradient goldGrad = LinearGradient(
    colors: [Color(0xFFD4A017), Color(0xFFB8860B)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with TickerProviderStateMixin {
  final userCtrl    = TextEditingController();
  final passCtrl    = TextEditingController();
  final _formKey    = GlobalKey<FormState>();

  bool _isLoading       = false;
  bool _obscurePass     = true;
  String? _androidId;

  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _logoCtrl;
  late AnimationController _btnCtrl;
  late AnimationController _shakeCtrl;

  late Animation<double> _fade;
  late Animation<Offset>  _slide;
  late Animation<double>  _logoGlow;
  late Animation<double>  _btnPulse;
  late Animation<double>  _shake;

  @override
  void initState() {
    super.initState();

    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 18))
      ..repeat();

    _entranceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1000));
    _fade  = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _entranceCtrl, curve: Curves.easeOutCubic));

    _logoCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2200))
      ..repeat(reverse: true);
    _logoGlow = Tween<double>(begin: 0.4, end: 1.0)
        .animate(CurvedAnimation(parent: _logoCtrl, curve: Curves.easeInOut));

    _btnCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1600))
      ..repeat(reverse: true);
    _btnPulse = Tween<double>(begin: 1.0, end: 1.05)
        .animate(CurvedAnimation(parent: _btnCtrl, curve: Curves.easeInOut));

    _shakeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    _shake = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -8.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -8.0, end: 8.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 8.0, end: -5.0),  weight: 2),
      TweenSequenceItem(tween: Tween(begin: -5.0, end: 5.0),   weight: 2),
      TweenSequenceItem(tween: Tween(begin: 5.0, end: 0.0),    weight: 1),
    ]).animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.easeInOut));

    _entranceCtrl.forward();
    _initLogin();
  }

  @override
  void dispose() {
    _bgCtrl.dispose(); _entranceCtrl.dispose(); _logoCtrl.dispose();
    _btnCtrl.dispose(); _shakeCtrl.dispose();
    userCtrl.dispose(); passCtrl.dispose();
    super.dispose();
  }

  Future<void> _initLogin() async {
    final info = await DeviceInfoPlugin().androidInfo;
    _androidId = info.id;

    final prefs     = await SharedPreferences.getInstance();
    final savedUser = prefs.getString('username');
    final savedPass = prefs.getString('password');
    final savedKey  = prefs.getString('key');

    if (savedUser != null && savedPass != null && savedKey != null) {
      try {
        final res  = await http.get(Uri.parse(
            'http://public.queen-official.com:2139/myInfo?username=$savedUser&password=$savedPass&androidId=$_androidId&key=$savedKey'));
        final data = jsonDecode(res.body);

        if (data['valid'] == true && mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => SplashScreen(
              username: savedUser, password: savedPass,
              role: data['role'], sessionKey: data['key'],
              expiredDate: data['expiredDate'],
              listBug:  _parseList(data['listBug']),
              listDoos: _parseList(data['listDDoS']),
              news:     _parseList(data['news']),
            )),
          );
        }
      } catch (_) {}
    }
  }

  List<Map<String, dynamic>> _parseList(dynamic raw) =>
      (raw as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;

    final username = userCtrl.text.trim();
    final password = passCtrl.text.trim();

    setState(() => _isLoading = true);

    try {
      final res  = await http.post(
          Uri.parse('http://public.queen-official.com:2139/validate'),
          body: {
            'username': username,
            'password': password,
            'androidId': _androidId ?? 'unknown',
          });
      final data = jsonDecode(res.body);

      if (data['expired'] == true) {
        _shakeCtrl.forward(from: 0);
        _showAlert(title: 'Akses Habis',
            message: 'Masa akses Anda telah berakhir. Silakan perpanjang.',
            type: _AlertType.warning, showContact: true);
      } else if (data['valid'] != true) {
        _shakeCtrl.forward(from: 0);
        final msg = (data['message'] ?? '').toString().toLowerCase();
        if (msg.contains('perangkat') || msg.contains('device') || msg.contains('another')) {
          _showAlert(title: 'Sesi Aktif',
              message: 'Akun ini sedang login di perangkat lain.',
              type: _AlertType.warning);
        } else {
          _showAlert(title: 'Login Gagal',
              message: 'Username atau password salah.',
              type: _AlertType.error);
        }
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString('username', username);
        prefs.setString('password', password);
        prefs.setString('key', data['key']);

        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => SplashScreen(
              username: username, password: password,
              role: data['role'], sessionKey: data['key'],
              expiredDate: data['expiredDate'],
              listBug:  _parseList(data['listBug']),
              listDoos: _parseList(data['listDDoS']),
              news:     _parseList(data['news']),
            )),
          );
        }
      }
    } catch (_) {
      _shakeCtrl.forward(from: 0);
      _showAlert(title: 'Koneksi Error',
          message: 'Gagal terhubung ke server. Periksa jaringan Anda.',
          type: _AlertType.error);
    }

    if (mounted) setState(() => _isLoading = false);
  }

  void _showAlert({
    required String title,
    required String message,
    required _AlertType type,
    bool showContact = false,
  }) {
    final color = type == _AlertType.error ? _C.red
        : type == _AlertType.warning ? _C.amber
        : _C.green;
    final icon = type == _AlertType.error ? Icons.error_outline_rounded
        : type == _AlertType.warning ? Icons.warning_amber_rounded
        : Icons.check_circle_outline_rounded;

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.4),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: _C.surface,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: color.withOpacity(0.3), width: 1.5),
            boxShadow: [BoxShadow(color: color.withOpacity(0.15), blurRadius: 30)],
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 56, height: 56,
              decoration: BoxDecoration(
                shape: BoxShape.circle, color: color.withOpacity(0.1),
                border: Border.all(color: color.withOpacity(0.3)),
              ),
              child: Icon(icon, color: color, size: 28),
            ),
            const SizedBox(height: 16),
            Text(title, style: TextStyle(color: _C.text, fontSize: 16,
                fontWeight: FontWeight.w800, letterSpacing: 0.5)),
            const SizedBox(height: 10),
            Text(message, textAlign: TextAlign.center,
                style: const TextStyle(color: _C.textSub, fontSize: 13, height: 1.5)),
            if (showContact) ...[
              const SizedBox(height: 16),
              GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                  launchUrl(Uri.parse('https://t.me/@Cellsture'),
                      mode: LaunchMode.externalApplication);
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [_C.gold, _C.goldDark]),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Text('Hubungi Admin', style: TextStyle(
                      color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
                ),
              ),
            ],
            const SizedBox(height: 16),
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
                decoration: BoxDecoration(
                  color: _C.bgDeep, borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _C.border),
                ),
                child: const Text('Tutup', style: TextStyle(
                    color: _C.textSub, fontSize: 13, fontWeight: FontWeight.w600)),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  // ─── Build ──────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF060D1A),
      body: Stack(
        children: [
          // Animated blue-grey background
          Positioned.fill(child: _AnimatedBg(controller: _bgCtrl)),
          SafeArea(
            child: FadeTransition(
              opacity: _fade,
              child: SlideTransition(
                position: _slide,
                child: Center(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        AnimatedBuilder(
                          animation: _shake,
                          builder: (_, child) => Transform.translate(
                            offset: Offset(_shake.value, 0), child: child),
                          child: _buildForm(),
                        ),
                        const SizedBox(height: 24),
                        _buildFooter(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Logo ────────────────────────────────────────────────────────────────────
  Widget _buildLogo() {
    return AnimatedBuilder(
      animation: _logoGlow,
      builder: (_, __) => Stack(
        alignment: Alignment.center,
        children: [
          // Outer glow
          Container(
            width: 140, height: 140,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(colors: [
                _C.blue.withOpacity(_logoGlow.value * 0.12),
                Colors.transparent,
              ], radius: 0.8),
            ),
          ),
          // Gold ring
          Container(
            width: 116, height: 116,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: _C.gold.withOpacity(_logoGlow.value * 0.5),
                width: 2,
              ),
            ),
          ),
          // Blue ring
          Container(
            width: 96, height: 96,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: _C.blue.withOpacity(_logoGlow.value * 0.6),
                width: 2,
              ),
            ),
          ),
          // Core logo
          Hero(
            tag: 'logo',
            child: Container(
              width: 78, height: 78,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22),
                boxShadow: [
                  BoxShadow(
                    color: _C.blue.withOpacity(_logoGlow.value * 0.3),
                    blurRadius: 16, spreadRadius: 2,
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(22),
                child: Image.asset(
                  'assets/images/logo.png',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [_C.blue, _C.blueDark],
                        begin: Alignment.topLeft, end: Alignment.bottomRight,
                      ),
                    ),
                    child: const Icon(Icons.bolt_rounded, color: _C.gold, size: 36),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Heading ─────────────────────────────────────────────────────────────────
  // Robot eye state
  bool _robotWatchingPassword = false;

  Widget _buildHeading() {
    // Robot style kaya foto 7
    return Column(children: [
      // Robot body
      _buildRobot(),
      const SizedBox(height: 18),
      // Greeting text
      AnimatedSwitcher(
        duration: const Duration(milliseconds: 300),
        child: Text(
          key: ValueKey(_robotWatchingPassword),
          _robotWatchingPassword ? '*menutup mata*' : 'Beep boop. Who goes there?',
          style: TextStyle(
            color: _robotWatchingPassword ? Colors.white38 : Colors.white,
            fontFamily: 'ShareTechMono',
            fontSize: _robotWatchingPassword ? 13 : 16,
            fontWeight: FontWeight.bold,
            fontStyle: _robotWatchingPassword ? FontStyle.italic : FontStyle.normal,
          ),
        ),
      ),
    ]);
  }

  Widget _buildRobot() {
    return AnimatedBuilder(
      animation: _logoGlow,
      builder: (_, __) {
        final glowColor = const Color(0xFF00FFF7);
        return SizedBox(
          width: 120, height: 120,
          child: Stack(alignment: Alignment.center, children: [
            // Glow background
            Container(
              width: 100, height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF1A2B4A),
                boxShadow: [BoxShadow(color: glowColor.withOpacity(0.15 + _logoGlow.value * 0.15), blurRadius: 30, spreadRadius: 4)],
              ),
            ),
            // Robot head
            Container(
              width: 80, height: 68,
              decoration: BoxDecoration(
                color: const Color(0xFF1E3A5F),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFF2A4F7C), width: 2),
              ),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                // Antenna
                const SizedBox(height: 2),
                // Eyes row
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  _buildRobotEye(glowColor),
                  const SizedBox(width: 14),
                  _buildRobotEye(glowColor),
                ]),
                const SizedBox(height: 6),
                // Mouth
                Container(
                  width: 28, height: 5,
                  decoration: BoxDecoration(
                    color: glowColor.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ]),
            ),
            // Antenna on top
            Positioned(
              top: 4,
              child: Container(
                width: 3, height: 16,
                decoration: BoxDecoration(color: const Color(0xFF2A4F7C), borderRadius: BorderRadius.circular(2)),
                child: Align(alignment: Alignment.topCenter,
                  child: Container(width: 7, height: 7, decoration: BoxDecoration(shape: BoxShape.circle, color: glowColor, boxShadow: [BoxShadow(color: glowColor, blurRadius: 6)]))),
              ),
            ),
          ]),
        );
      },
    );
  }

  Widget _buildRobotEye(Color glowColor) {
    if (_robotWatchingPassword) {
      // Eyes closed — horizontal line
      return Container(
        width: 22, height: 4,
        decoration: BoxDecoration(
          color: Colors.white38,
          borderRadius: BorderRadius.circular(2),
        ),
      );
    }
    return AnimatedBuilder(
      animation: _logoGlow,
      builder: (_, __) => Container(
        width: 22, height: 22,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0xFF0A1A30),
          border: Border.all(color: glowColor.withOpacity(0.4), width: 1.5),
          boxShadow: [BoxShadow(color: glowColor.withOpacity(0.4 + _logoGlow.value * 0.4), blurRadius: 8 + _logoGlow.value * 4)],
        ),
        child: Center(child: Container(
          width: 10, height: 10,
          decoration: BoxDecoration(shape: BoxShape.circle, color: glowColor),
        )),
      ),
    );
  }

  // ─── Form ────────────────────────────────────────────────────────────────────
  Widget _buildForm() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF0D1B30),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: const Color(0xFF00FFF7).withOpacity(0.15)),
        boxShadow: [
          BoxShadow(color: const Color(0xFF00FFF7).withOpacity(0.06), blurRadius: 40, offset: const Offset(0, 15)),
        ],
      ),
      child: Form(
        key: _formKey,
        child: Column(children: [
          // Robot heading
          _buildHeading(),
          const SizedBox(height: 24),
          _RobotLoginField(
            controller: userCtrl,
            hint: 'Your username',
            icon: Icons.person_outline_rounded,
            isPassword: false,
            onChanged: (v) {
              if (v.length >= 3) {
                final coolNames = ['mystic', 'noy', 'DARKCORE', 'admin', 'owner', 'vip', 'god', 'boss', 'elite', 'ultra'];
                final lame = ['test', 'aaa', 'user', 'abc', '123', 'pass', 'asdf'];
                final low = v.toLowerCase();
                final cool = coolNames.any((n) => low.contains(n));
                final bad = lame.any((n) => low == n);
                if (cool && mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                    content: Text('Nama keren!', style: TextStyle(fontFamily: 'ShareTechMono')),
                    backgroundColor: Color(0xFF0077C2), duration: Duration(seconds: 1),
                  ));
                } else if (bad && mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                    content: Text('Username lo jelek banget bro', style: TextStyle(fontFamily: 'ShareTechMono')),
                    backgroundColor: Color(0xFFEF4444), duration: Duration(seconds: 1),
                  ));
                }
              }
            },
            validator: (v) => (v == null || v.isEmpty) ? 'Username tidak boleh kosong' : null,
          ),
          const SizedBox(height: 16),
          _RobotLoginField(
            controller: passCtrl,
            hint: 'Super secret password',
            icon: Icons.lock_outline_rounded,
            isPassword: true,
            obscure: _obscurePass,
            onToggleObscure: () => setState(() => _obscurePass = !_obscurePass),
            onFocus: (focused) => setState(() => _robotWatchingPassword = focused),
            validator: (v) => (v == null || v.isEmpty) ? 'Password tidak boleh kosong' : null,
          ),
          const SizedBox(height: 28),
          _LoginButton(isLoading: _isLoading, pulseAnim: _btnPulse, onTap: _login),
        ]),
      ),
    );
  }

  // ─── Footer ──────────────────────────────────────────────────────────────────
  Widget _buildFooter() {
    return Column(children: [
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Text('Belum Punya Access? ', style: TextStyle(color: _C.textSub, fontSize: 13)),
        GestureDetector(
          onTap: () => launchUrl(Uri.parse('https://t.me/@Cellsture'),
              mode: LaunchMode.externalApplication),
          child: const Text('BUY SEKARANG', style: TextStyle(
              color: _C.gold, fontSize: 13, fontWeight: FontWeight.w800, letterSpacing: 0.5)),
        ),
      ]),
      const SizedBox(height: 20),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(width: 6, height: 6,
          decoration: const BoxDecoration(shape: BoxShape.circle, color: _C.gold)),
        const SizedBox(width: 8),
        const Text('DARKCORE EXECUTIVE',
            style: TextStyle(color: _C.textDim, fontSize: 11,
                fontWeight: FontWeight.w600, letterSpacing: 1.5, fontFamily: 'Orbitron')),
        const SizedBox(width: 8),
        Container(width: 6, height: 6,
          decoration: const BoxDecoration(shape: BoxShape.circle, color: _C.blue)),
      ]),
    ]);
  }
}

// ─── Login Field ───────────────────────────────────────────────────────────────
class _LoginField extends StatefulWidget {
  final TextEditingController controller;
  final String label;
  final IconData icon;
  final bool obscure;
  final VoidCallback? onToggleObscure;
  final String? Function(String?)? validator;

  const _LoginField({
    required this.controller, required this.label, required this.icon,
    this.obscure = false, this.onToggleObscure, this.validator,
  });

  @override
  State<_LoginField> createState() => _LoginFieldState();
}

class _LoginFieldState extends State<_LoginField> {
  bool _focused = false;
  final _focus = FocusNode();

  @override
  void initState() {
    super.initState();
    _focus.addListener(() => setState(() => _focused = _focus.hasFocus));
  }
  @override
  void dispose() { _focus.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        color: _focused ? Colors.white : const Color(0xFFF8FAFF),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _focused ? _C.blue : _C.border,
          width: _focused ? 1.8 : 1.0,
        ),
        boxShadow: _focused
            ? [BoxShadow(color: _C.blue.withOpacity(0.12), blurRadius: 16, offset: const Offset(0, 4))]
            : [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: TextFormField(
        controller: widget.controller, focusNode: _focus,
        obscureText: widget.obscure, validator: widget.validator,
        style: const TextStyle(color: _C.text, fontSize: 15, fontWeight: FontWeight.w500),
        cursorColor: _C.blue,
        decoration: InputDecoration(
          labelText: widget.label,
          labelStyle: TextStyle(
              color: _focused ? _C.blue : _C.textSub, fontSize: 13, fontWeight: FontWeight.w500),
          floatingLabelStyle: const TextStyle(color: _C.blue, fontSize: 11),
          prefixIcon: Icon(widget.icon, color: _focused ? _C.blue : _C.textSub, size: 20),
          suffixIcon: widget.onToggleObscure != null
              ? IconButton(
                  icon: Icon(
                    widget.obscure ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                    color: _focused ? _C.blue : _C.textSub, size: 20,
                  ),
                  onPressed: widget.onToggleObscure,
                )
              : null,
          errorStyle: const TextStyle(color: _C.red, fontSize: 11),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        ),
      ),
    );
  }
}

// ─── Robot Login Field (foto 7 style) ─────────────────────────────────────────
class _RobotLoginField extends StatefulWidget {
  final TextEditingController controller;
  final String hint;
  final IconData icon;
  final bool isPassword;
  final bool obscure;
  final VoidCallback? onToggleObscure;
  final Function(bool)? onFocus;
  final Function(String)? onChanged;
  final String? Function(String?)? validator;

  const _RobotLoginField({
    required this.controller,
    required this.hint,
    required this.icon,
    this.isPassword = false,
    this.obscure = false,
    this.onToggleObscure,
    this.onFocus,
    this.onChanged,
    this.validator,
  });

  @override State<_RobotLoginField> createState() => _RobotLoginFieldState();
}

class _RobotLoginFieldState extends State<_RobotLoginField> {
  final _focus = FocusNode();

  @override
  void initState() {
    super.initState();
    _focus.addListener(() {
      widget.onFocus?.call(_focus.hasFocus);
    });
  }

  @override
  void dispose() { _focus.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: widget.controller,
      focusNode: _focus,
      obscureText: widget.isPassword && widget.obscure,
      onChanged: widget.onChanged,
      validator: widget.validator,
      style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 15),
      cursorColor: const Color(0xFF00FFF7),
      decoration: InputDecoration(
        hintText: widget.hint,
        hintStyle: const TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 13),
        prefixIcon: Icon(widget.icon, color: const Color(0xFF00FFF7).withOpacity(0.7), size: 20),
        suffixIcon: widget.isPassword
          ? GestureDetector(
              onTap: widget.onToggleObscure,
              child: Icon(widget.obscure ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                color: Colors.white38, size: 20))
          : null,
        filled: true,
        fillColor: const Color(0xFF1A2B4A),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Color(0xFF00FFF7), width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Colors.redAccent, width: 1),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Colors.redAccent, width: 1.5),
        ),
        errorStyle: const TextStyle(color: Colors.redAccent, fontFamily: 'ShareTechMono', fontSize: 10),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      ),
    );
  }
}

// ─── Login Button ──────────────────────────────────────────────────────────────
class _LoginButton extends StatefulWidget {
  final bool isLoading;
  final Animation<double> pulseAnim;
  final VoidCallback onTap;

  const _LoginButton({required this.isLoading, required this.pulseAnim, required this.onTap});

  @override
  State<_LoginButton> createState() => _LoginButtonState();
}

class _LoginButtonState extends State<_LoginButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) { setState(() => _down = false); if (!widget.isLoading) widget.onTap(); },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedBuilder(
        animation: widget.pulseAnim,
        builder: (_, __) => Transform.scale(
          scale: widget.isLoading || _down ? 1.0 : widget.pulseAnim.value,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            height: 56, width: double.infinity,
            decoration: BoxDecoration(
              gradient: widget.isLoading
                ? const LinearGradient(colors: [Color(0xFF0D1B30), Color(0xFF1A2B4A)])
                : const LinearGradient(colors: [Color(0xFF00C8C8), Color(0xFF00FFF7)], begin: Alignment.centerLeft, end: Alignment.centerRight),
              borderRadius: BorderRadius.circular(18),
              boxShadow: _down || widget.isLoading ? [] : [
                BoxShadow(
                  color: const Color(0xFF00FFF7).withOpacity(widget.pulseAnim.value * 0.45),
                  blurRadius: 24, offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Center(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 220),
                child: widget.isLoading
                    ? const SizedBox(
                        key: ValueKey('loading'),
                        width: 22, height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                    : const Row(
                        key: ValueKey('idle'),
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.login_rounded, color: Color(0xFF0A1628), size: 20),
                          SizedBox(width: 12),
                          Text('LOGIN', style: TextStyle(
                              color: Color(0xFF0A1628), fontSize: 16,
                              fontWeight: FontWeight.w900, letterSpacing: 2,
                              fontFamily: 'Orbitron')),
                        ],
                      ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Animated Background (blue-grey soft) ────────────────────────────────────
class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) => CustomPaint(painter: _BgPainter(controller.value)),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    // Base gradient
    final bgPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFFF0F4FF), Color(0xFFE4ECFF), Color(0xFFF0F4FF)],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), bgPaint);

    // Subtle grid
    final grid = Paint()
      ..color = const Color(0xFF1565C0).withOpacity(0.04)
      ..strokeWidth = 0.6;
    const step = 44.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    // Blue glow top
    final glow = Paint()
      ..shader = RadialGradient(colors: [
        const Color(0xFF1565C0).withOpacity(0.10 + math.sin(t * math.pi * 2) * 0.03),
        Colors.transparent,
      ], radius: 0.7).createShader(Rect.fromCircle(
          center: Offset(size.width / 2, size.height * 0.25),
          radius: size.width * 0.6));
    canvas.drawCircle(Offset(size.width / 2, size.height * 0.25), size.width * 0.6, glow);

    // Gold accent bottom-right
    final glow2 = Paint()
      ..shader = RadialGradient(colors: [
        const Color(0xFFD4A017).withOpacity(0.07 + math.cos(t * math.pi * 2) * 0.02),
        Colors.transparent,
      ], radius: 0.5).createShader(Rect.fromCircle(
          center: Offset(size.width * 0.85, size.height * 0.8),
          radius: size.width * 0.4));
    canvas.drawCircle(Offset(size.width * 0.85, size.height * 0.8), size.width * 0.4, glow2);
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}

enum _AlertType { error, warning, success }
